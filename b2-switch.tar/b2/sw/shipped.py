"""b2 switch commit: tests/route.test.ts SHIPPED and hooks/notes.ts MODEL_SWITCHES equal the decision table (judge/decision.json
and 견본.md batch 1 + batch 2 decisions: isRuleWide true both rows; haiku rungChangedStep 2; every other cell off)."""
import json, re, sys
R = "/home/user/learn-notes"
D = json.load(open("/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/judge/decision.json"))
OFF = {"isRuleDrill": False, "isRuleWide": False, "rungNewStep": "Infinity", "rungChangedStep": "Infinity", "workedAfterTimes": "Infinity", "workedPlainAfterTimes": "Infinity", "isBaseAsked": False, "isThinkAsked": False}
want = {m: {**OFF, "isRuleWide": True} for m in ("haiku", "sonnet")}
for m in want:
    v = D[m]["rungChangedStep"]
    want[m]["rungChangedStep"] = v if v != "Infinity" else "Infinity"
t = open(f"{R}/tests/route.test.ts", encoding="utf-8").read()
blk = t[t.index("const SHIPPED"):]
got = {}
for m in ("haiku", "sonnet"):
    row = re.search(m + r": \{([^}]*)\}", blk).group(1)
    got[m] = {k.strip(): (True if v.strip() == "true" else False if v.strip() == "false" else ("Infinity" if v.strip() == "Infinity" else int(v))) for k, v in (p.split(":") for p in row.split(","))}
n = open(f"{R}/hooks/notes.ts", encoding="utf-8").read()
ms = {m: re.search(r"  " + m + r": Object\.freeze\(\{ \.\.\.SWITCHES_OFF(.*?) \}\),", n).group(1) for m in ("haiku", "sonnet")}
code = {}
for m, extra in ms.items():
    row = dict(OFF)
    for p in [x for x in extra.split(",") if x.strip()]:
        k, v = p.split(":")
        v = v.strip()
        row[k.strip()] = True if v == "true" else False if v == "false" else int(v)
    code[m] = row
ok = got == want == code
print(json.dumps({"want": want, "SHIPPED": got, "MODEL_SWITCHES": code, "equal": ok}, ensure_ascii=False))
sys.exit(0 if ok else 1)
