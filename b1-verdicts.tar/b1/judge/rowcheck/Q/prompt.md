너는 판정 스크립트가 아래 입장 글대로 셌는지 행마다 확인하는 사람이다. 너는 꼬리표 Q 하나의 판정 파일(회 A · 회 B)만 받는다. 코드를 돌릴 수 없다. 판정 파일의 행마다 적힌 근거(돌린 출력 · 들인 규칙 · 짚은 규칙 · 맞춘 주장 꼴 · 고칠 줄 · 예시 답 · 확인 줄)를 입장과 세부의 글에 견주어, 스크립트가 글대로 세지 않은 행만 적는다. 근거만으로 가릴 수 없으면 적지 않는다. 입장 글을 새로 해석하거나 더하지 않는다.

## 입장과 세부 (이 글대로만)

#### 판정의 입장

설계의 입장(stance) 글입니다. '공통'의 다섯 항목, 확인 줄(S-a), 견본(S-c), 판정 대상(S-b), 경계 꼴 E1 ~ E18, N2 입장을 설계 글자 그대로 옮겼습니다. 판정은 이 글자대로만 셉니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 '다시 잴 때'에 적습니다(M-11).

공통 (1.10.0 입장 §0–§15와 세부 1–24를 그대로 다시 커밋하고, 아래만 바꾸거나 더함)
- §0 · §15 그대로: 판정 스크립트를 이 글대로 먼저 짓고 sha256을 바 커밋에 적습니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 견본.md '다시 잴 때'에 적습니다. 판정 파일을 쓴 뒤에는 입장 · 열쇠 · 기준을 바꾸지 않습니다.
- §1 (바꿈) 켠 읽기: 노트 답 → fixEscapedTicks → keptNoteText(답, names) → noteRuleOf가 읽히면 그 판 트리의 ruleFixPlan(screened, rules, 그 줄). 1단이면 ruleFixMade(글, fix, changes) ?? 글, 2단이면 RULE_DRILL_SYSTEM · redactText(ruleDrillPrompt(screened, rules, 그 줄, cands)) · 3500 · 90000으로 부르고 fixEscapedTicks → ruleFixReply가 받은 글 ?? 글, 건너뜀이면 글 그대로. 끈 읽기: 같은 노트 답의 keptNoteText 글 그대로.
- §2 그대로: 노트 호출이 답하지 않은 견본은 그 회 L · O에서 빼고 수만 적습니다. 규칙 연습 호출의 상한 닿음 · 빈 답(API 거절 포함) · 시간 한도는 '답 없음' 줄에 셉니다(n = 그 모델 두 회의 2단 호출 수). 닿았어도 글이 읽히면 읽힌 대로 매깁니다. 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.12.0 보정).
- §3 · §4 · §5 · §6 · §8 · §9 · §10 · §11 · §12 · §13 그대로(채점 열쇠 §5는 같은 팀 파일에서 나온 그대로).
- §14 (더함, 엄격하게): 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988에 3d2f251 · de98243을 더한 여섯입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.

확인 줄 (S-a, §7에 더함)
- 켠 판의 확인 줄은 코드가 쓴 '고친 줄이 돌 때 `U` 쪽을 거칩니다' 하나뿐입니다. 세부 6: 코드 칸에 호출이 없으므로 견본 demo를 돌립니다. 세부 8: 쓰라는 이름 하나만 든 코드 칸은 값이 아닙니다. 세부 10: 효과 말이며 U의 규칙이 그 규칙입니다.
- 효과 주장은 줄 단위로 매깁니다: 그 줄만 예시 답으로 바꾼 파일로 demo를 돌린 기록에 그 규칙 대역 줄(`[apiRequest] ` · `[log.info] ` · `[toDateText] ` · `[config] `로 시작)이, 원래 줄 그대로 돌린 기록보다 많아야 참입니다(파일이 다른 줄에서 이미 대역을 부르는 경우를 가름). 같으면 거짓입니다.
- 확인 줄이 이 꼴이 아닌 규칙 연습(켠 창에서 읽히지 않으므로 나올 수 없음)이 나오면 1.10.0 §7 그대로 매깁니다.

견본 (S-c)
- 얼리기 전: violations마다 fix로 바꾼 demo가 원래 demo보다 그 규칙 대역 줄을 더 많이 써야 합니다(엄격한 S1). 못 넘은 견본은 같은 무리 예비로 id 차례대로 채우고 고쳐 쓰지 않으며, 바뀐 수를 견본.md에 무리마다 적습니다(모집단 기록). 개발 견본 1–4의 짧은 어긴 줄 92개에서는 0개였습니다.
- F 견본에서 표지 글자가 문자열 글자나 주석 안에만 있는 줄은 어긴 줄이 아닙니다(F의 정해진 꼴). 그 줄에 규칙 연습이 나오면 h2(해로움)입니다.

판정 대상 (S-b)
- 연습은 저장된 노트 글로만 매깁니다. 1단(코드가 만든 예시 답)이든 2단(모델이 준 예시 답)이든 같은 §6 · §10을 씁니다. 1단이라고 덜 보지 않습니다.
- 갈래 · 건너뜀 까닭 · 2단 잘못 코드는 기록만 하고 판정에 쓰지 않습니다(S-d).

옛 기록과 개발 답에서 나온 경계 꼴 (미리 정함)
- E1 인자를 바꾼 예시 답(`toDateText(e.endsAt)`, 줄은 `d.toLocaleDateString('en-CA')`): 표지가 없고 쓰라는 이름이 있으면 (iv)의 출력 비교가 정합니다. 출력이 expected_fixed와 같으면 바름, 다르면 바르지 않음(해롭지 않음).
- E2 결과에 사슬을 남긴 예시 답(`toDateText(end).slice(0, 10)`): 남은 것이 §5 표지가 아니면 h3가 아니고 (iv) 출력이 정합니다. `.slice(0, 4)`처럼 출력이 바뀌면 바르지 않음(1.12.0 개발 D1A14).
- E3 감싼 예시 답(`toDateText(end.toJSON())`)과 옆에 남긴 예시 답(`toDateText(d) || d.toISOString()`): 표지가 남으므로 h3. 코드가 막으므로 나오면 코드 결함이며 해로움으로 셉니다.
- E4 multi: 어느 violations 줄이든 짚은 규칙의 줄이면 바를 수 있습니다. 다른 규칙의 줄이면 (ii)나 (iii)에서 바르지 않고, 들인 규칙의 violations 줄이 아니면 h2입니다.
- E5 double(같은 규칙 둘): 둘 가운데 어느 줄이든 됩니다. 다른 한 줄의 표지가 파일에 남는 것은 예시 답의 표지가 아니므로 h3가 아니고, (iv)는 그 violation의 expected_fixed로 견줍니다.
- E6 `config["X"]` · `config.get("X")` · `Number(config.X)`: 쓰라는 이름 config를 품으므로 지킴입니다(§8 대역이 모두 받침). 확인 줄의 U는 `config`입니다.
- E7 os.getenv 줄(규칙 글이 이름 짓지 않은 표지): 코드가 후보로 올리지 않아 연습 없음이면 den의 바르지 않음이고 해롭지 않습니다. 연습이 나오면 보통처럼 매깁니다.
- E8 2단 답이 스스로 고쳐 쓴 꼴(같은 라벨에 다른 값, 'Wait —'): 코드가 받지 않아 연습 없음입니다. 판정은 저장된 글만 봅니다.
- E9 노트 호출이 스스로 고쳐 쓴 꼴로 직접 해 보기 칸에 할 일 줄이 둘(1.12.0 개발 D4B02 · D4B21, 끈 읽기): §13대로 할 일 줄 둘인 노트로 셉니다(두 읽기 모두, 답한 모든 노트). 이 설계가 바꿀 수 없는 끈 읽기의 일이어도 기준 줄은 그대로입니다.
- E10 노트 호출이 상한에 닿았지만 답한 경우(개발 D3B11 haiku 5548): 읽힌 대로 매기고 상한 닿음은 노트 호출 쪽 기록입니다(규칙 연습 '답 없음' 줄은 2단 호출만 셈).
- E11 켠 창에서 W2가 표지를 단 자기 칸(코드가 만들지 않은 규칙 연습): 켠 읽기에서 연습 없음입니다. 그 노트가 den이면 바르지 않음, 표지 없는 규칙 연습(§9)도 아님(개념 연습이 아니므로). 끈 읽기의 W 오탐(§11)은 그대로 셉니다.
- E12 1단이 만든 연습이 demo가 지나지 않는 줄에 있음: (v) · (vi)에서 거짓(효과 기록이 늘지 않음). 엄격한 S1이 견본의 열쇠 줄을 보장하므로 열쇠 줄이 아니면 (iii)에서 이미 바르지 않음입니다.
- E13 1단 이름 바꿈이 같은 줄의 쓰지 말라는 다른 이름을 남김: 코드가 막음. 나오면 h3.
- E14 확인 줄 U가 예시 답의 가장 짧은 쓰라는 이름(`config`)이고 예시 답은 `config.API_URL`: 효과 말 config로 매깁니다.
- E15 규칙 연습 호출 답이 `- 줄: 없음`이고 그 노트가 den: 연습 없음 → 바르지 않음, 해롭지 않음.
- E16 N2: 학습자 줄이 예시 답과 같거나 고칠 줄과 같으면 gradeDrill이 부르지 않으므로 n2verify가 뺍니다(세부 22). 판정 셈은 세부 23 그대로.
- E17 노트 글의 `다를 수 있음` 줄이 규칙 이름을 하나도 품지 않음(코드는 건너뜀): 연습 없음. den이면 바르지 않음.
- E18 sonnet API 거절(stop_reason refusal): 빈 답으로 '답 없음'에 셉니다. 탭 기록은 따로 적는 기록입니다.

N2 입장
- 1.9.0 · 1.10.0 N2 입장 그대로(세부 22 · 23). 문제 글의 할 일 · 확인 줄은 코드가 쓴 것이며, 채점 프롬프트의 나머지 바이트는 1.9.0과 같습니다(rule19 고정, 만든 연습의 채점 요청 고정 시험 추가).

다시 커밋하는 1.10.0 입장 §0 ~ §15 (432ced4 글 그대로; 바꾼 곳은 ~~ ~~와 1.12.0 글)

§0 커밋과 스크립트
- 판정 스크립트(저장소 밖)를 이 입장대로 먼저 쓰고, 그 sha256을 이 커밋에 적습니다.
- 출력을 본 뒤 스크립트가 이 글과 다르게 센 것이 드러나면 글대로 다시 세고 스크립트 diff를 견본.md에 남깁니다. 글(입장 · 열쇠 · 기준)은 바꾸지 않습니다.

§1 부르기와 읽기는 플러그인과 같습니다 (1.12.0에서 바꿈: 켠 읽기 한 줄)
- 팀 파일은 그 판 트리의 parseTeamFile로 읽습니다. names = ruleNamesOf(team.rules)(잰 모델의 isRuleWide를 켠 상태).
- 노트: SYSTEM, notePrompt(screened, 'beginner', [], team), maxTokens NOTE_TOKENS(3500).
- 노트 답: fixEscapedTicks → keptNoteText(답, names).
- ~~켠 읽기: noteRuleOf가 읽히면 RULE_DRILL_SYSTEM · ruleDrillPrompt(screened, team.rules, 그 줄), maxTokens RULE_DRILL_TOKENS(3500)로 부르고, fixEscapedTicks → withRuleDrill(글, 답, changes, names) ?? 글.~~
- 켠 읽기(1.12.0): 노트 답 → fixEscapedTicks → keptNoteText(답, names) → noteRuleOf가 읽히면 그 판 트리의 ruleFixPlan(screened, rules, 그 줄). 1단이면 ruleFixMade(글, fix, changes) ?? 글, 2단이면 RULE_DRILL_SYSTEM · redactText(ruleDrillPrompt(screened, rules, 그 줄, cands)) · 3500 · 90000으로 부르고 fixEscapedTicks → ruleFixReply가 받은 글 ?? 글, 건너뜀이면 글 그대로.
- 끈 읽기: 같은 노트 답의 keptNoteText 글 그대로.
- 두 호출 모두 redactText, effort low, timeoutMs 90000이고, 그 판 notes.ts 사본의 함수를 그대로 부릅니다.

§2 답이 없거나 상한에 닿은 답
- 노트 호출이 답하지 않으면(빈 답 · 시간 한도 · 오류) 그 견본은 그 회의 L · O에 넣지 않고 수만 적습니다. 그래서 den이 20 아래면 (b), O가 20 아래면 (a)가 못 넘음입니다.
- 규칙 연습 호출이 답하지 않으면 그 노트는 자기 칸 그대로(플러그인과 같음)이고, 그 꼴대로 매깁니다. 상한 닿음 · 빈 답 · 시간 한도는 '답 없음' 줄에 셉니다. API 오류는 수를 적고 다시 부르지 않습니다.
- 상한 닿음은 output_tokens ≥ maxTokens + H_M입니다(계획 고침 D4, M-5: G6의 상한 몫 = H_M, ~~haiku 2048 · sonnet 0, 묶음 1 보정 기록~~ 1.12.0 보정 기록의 haiku 2048 · sonnet 2048). 닿았어도 글이 읽히면 읽힌 대로 매깁니다.
- (1.12.0, 설계 §2를 옮김) 노트 호출이 답하지 않은 견본은 그 회 L · O에서 빼고 수만 적습니다. 규칙 연습 호출의 상한 닿음 · 빈 답(API 거절 포함) · 시간 한도는 '답 없음' 줄에 셉니다(n = 그 모델 두 회의 2단 호출 수). 닿았어도 글이 읽히면 읽힌 대로 매깁니다. 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.12.0 보정).

§3 L과 O
- 노트 답의 keptNoteText 글에서 noteRuleOf(연습 제목 앞, 제목이 없으면 글 전체)가 `팀 규칙과 다를 수 있음:` 줄(없음 아님)을 읽으면 L, 아니면 O입니다. 한 번 정해 켠 읽기와 끈 읽기에 함께 씁니다.
- `팀 규칙:` 줄만 있으면 O입니다.
- den = L 가운데 그 견본의 violations에 들여쓰기 빼고 40자 이하인 줄이 하나라도 있는 노트.

§4 연습의 종류
- 최종 글(켠 읽기는 withRuleDrill 뒤, 끈 읽기는 keptNoteText 글)에 drillOf(글, changes, 그 읽기의 켬 여부)를 돌립니다.
- rule을 주면 규칙 연습, rule 없이 주면 개념 연습, undefined면 연습 없음입니다.

§5 채점 열쇠 (팀 파일에서 나오며 함께 얼림)
| 규칙 | 쓰라는 이름 | 쓰지 말라는 표지 | 낱말 |
| --- | --- | --- | --- |
| 요청 | apiRequest · api_request | fetch( · requests. | 요청 · API · 서버 |
| 기록 | log.info | console.log · print( | 기록 · 로그 |
| 날짜 | toDateText · to_date_text | toISOString · toJSON · toLocaleDateString · toDateString · getFullYear · getMonth · getDate · getUTCFullYear · getUTCMonth · getUTCDate · strftime · isoformat | 날짜 |
| 설정 | config | process.env · os.environ · os.getenv | 설정 · 환경 변수 |
- 이름과 표지는 holdsName처럼 온전한 이름으로 찾습니다(`fetch(`는 `fetch` 뒤에 공백 없이 여는 괄호, `fetcher(` 안이 아님).
- 들인 규칙: 예시 답이 고칠 줄에는 없는 그 규칙의 쓰라는 이름을 품는 규칙들.
- 짚은 규칙: 노트의 `다를 수 있음` 줄 글에 그 규칙의 쓰라는 이름이나 표지가 있는 규칙들. 하나도 없으면 낱말이 있는 규칙들. 그것도 없으면 없음입니다.

§6 바름 (모두 맞아야 함. 다음을 모두 만족하는 규칙 r이 있어야 함)
- (i) 규칙 연습입니다.
- (ii) r이 들인 규칙이고 짚은 규칙입니다.
- (iii) 고칠 줄이 r의 violations 줄입니다(같은 파일, 공백 · 끝 `;` · `,` 빼고 같음).
- (iv) 예시 답이 r을 지킵니다: r의 쓰라는 이름을 품고, r의 표지가 남지 않으며, 그 줄만 예시 답으로 바꾼 파일의 demo 표준 출력(두 번)이 그 violation의 expected_fixed와 §7 정규화로 같습니다. 규칙과 상관없는 부분을 바꿔 출력이 달라지면 지키지 않음입니다.
- (v) 그 파일이 두 번 모두 오류 없이 돕니다. 원래 파일은 얼리기 전에 대역에서 돈다는 것이 확인되었으므로, 오류는 예시 답 탓으로 셉니다(정의되지 않은 이름 · import 없는 이름 포함).
- (vi) 확인 줄이 있고 그 주장이 §7로 참입니다.

§7 확인 줄
- 돌리는 것: 확인 줄 백틱 안의 첫 호출이 바꾼 파일에 정의된 함수를 부르면 그 호출을 돌립니다. 자리표시(`…` · `[A]` · `<…>`)이거나 말로만 쓴 확인이면 견본의 demo를 돌립니다.
- 변경의 파일에 없는 함수를 부르면 거짓입니다(1.9.0 G15). 확인 줄이 없으면 거짓입니다(A01).
- 돌린 결과 = 호출 값(await한 값) · 표준 출력 줄 · 대역 기록 줄(표준 출력과 따로 모음, §8).
- 주장의 꼴
  - (1) 값(백틱 · 따옴표 안, 또는 수): 정규화한 값이 호출 값과 같거나, 표준 출력이나 기록의 한 줄과 같아야 합니다. 값이 여럿이면 모두입니다(1.9.0 C18).
  - (2) 같음 말('같은 · 그대로 · 똑같이 · 변함없이 · 달라지지 않')만 있으면: 호출 값과 표준 출력이 원래 줄로 돌린 것과 같아야 합니다.
  - (3) 효과 말(그 규칙의 쓰라는 이름, '기록 · 로그가 남', '인증 · 재시도', '설정에서 읽', '날짜 글자로'): 기록 줄에 그 규칙 함수가 그 호출 동안 불린 줄이 있어야 합니다.
  - (4) 섞이면 각 부분이 다 맞아야 합니다.
  - (5) '…라고 가정 · …이면' 같은 조건: 견본 env · responses로 돌린 결과로만 매깁니다. 견본이 그 조건을 주지 않으면 거짓입니다.
  - (6) 그 밖의 꼴(값 · 같음 말 · 효과 말이 없음)은 거짓입니다.
- 정규화: 앞뒤 공백을 떼고 공백을 하나로 줄이며, `'`를 `"`로, 끝 `;`를 뗍니다. 둘 다 JSON으로 읽히면 값으로 견주고, 수는 값으로, 파이썬 True · False · None은 true · false · null로 봅니다.
- 줄인 출력: 말한 값이 맞으면 맞음이고, 말한 값이 하나라도 틀리면 거짓입니다.
- 날짜는 TZ=UTC입니다.

§8 대역과 돌리기
- 팀 모듈 넷(js · ts · py)을 둡니다. apiRequest · api_request, 미리 심은 globalThis.fetch, requests.get이 견본 responses로 같은 응답을 줍니다.
- config와 환경 변수는 견본 env로 같은 글자를 줍니다(`config.X` · `config["X"]` · `config.get("X")` 모두). log.info는 console.log · print와 같은 글을 표준 출력에 찍습니다. toDateText는 UTC YYYY-MM-DD를 줍니다.
- 대역은 불릴 때마다 `[apiRequest] 주소` · `[log.info] 인자` · `[config] 이름` · `[toDateText] 값`을 표준 출력이 아닌 기록 파일에 씁니다.
- 빈 임시 폴더에서 `unshare -n timeout 5`, js `node`, ts `node --experimental-transform-types`, py `python3 -I`로 돌립니다. 파일에 import를 덧붙이지 않습니다. 호출 값은 돌리는 틀이 사본 끝에 붙인 한 줄이 `[value] JSON`으로 찍습니다. (계획 고침 D14: py는 B-14대로 `env -i PATH LANG=C.UTF-8 PYTHONHASHSEED=<n> python3 -s -P -B`를 n = 1~5로 다섯 번 돌려 다섯이 모두 같아야 하고, ts 실행은 B-15의 `node --experimental-transform-types`입니다.)
- 구문 오류 = 바꾼 파일을 불러올 때 SyntaxError(파이썬은 py_compile 실패).
- 돌지 않는 연습(대역이 받치지 못한 경우 포함)은 (v)나 (vi)에서 거짓입니다. 읽어서 매기는 갈래는 없습니다.

§9 표지 없는 규칙 연습
- 개념 연습 가운데, 예시 답이 어떤 규칙의 쓰라는 이름을 고칠 줄에 없이 품는 것입니다.
- 할 일 글은 보지 않습니다. 할 일이 팀을 말하지만 이름을 들이지 않는 연습(1.9.0 G19 꼴)은 개념 연습입니다.
- 켠 읽기와 끈 읽기에서 모두 셉니다.

§10 해로움 (규칙 연습인데 다음 가운데 하나)
- (h1) 들인 규칙이 없음(규칙이 아닌 일을 시킴)
- (h2) 고칠 줄이 들인 규칙 어느 것의 violations 줄도 아님(헛짚은 L · 함정 · R_long에서 낸 규칙 연습 포함)
- (h3) 예시 답에 들인 규칙의 표지가 남음(거꾸로 바꿈 포함)
- (h4) 바꾼 파일에 구문 오류
- 확인 줄만 거짓이거나 (ii) · (iv)의 출력만 다른 것은 바르지 않음이지 해로움이 아닙니다.

§11 W 오탐
- 끈 읽기에서 HEAD fca5988의 ruleLabelled 글과 keptNoteText 글이 다른 노트를 봅니다.
- 그 노트의 연습(HEAD 글을 drillOf(…, false)로 읽은 것)이 다음을 모두 만족하지 않으면 오탐입니다: 고칠 줄이 어떤 규칙 r의 violations 줄이고, 예시 답이 r의 쓰라는 이름을 고칠 줄에 없이 품습니다.
- HEAD 글에서 연습이 읽히지 않던 노트(연습 없음)에 표지가 붙은 것은 오탐이 아닙니다.

§12 (c): O 노트마다 켠 읽기와 끈 읽기의 최종 글을 바이트로 견주고, 켠 회의 호출 기록에 O 노트의 규칙 연습 호출이 없는지 봅니다.

§13 할 일 줄 둘: 최종 노트의 직접 해 보기 칸(합친 칸 포함)에 할 일 줄이 둘 이상인 경우입니다.

§14 옛 창: 3f2b4fb · 7a7b08c · 3690021 · fca5988의 notes.ts 사본(꺼진 상수 그대로)으로 모든 회의 켠 · 끈 최종 글에 drillOf · hideDrillAnswer를 돌립니다.
- (1.12.0에서 더함, 엄격하게) 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988에 3d2f251 · de98243을 더한 여섯입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.

§15 판정 파일
- 스크립트가 행마다 근거(돌린 출력 · 들인 규칙 · 짚은 규칙 · 맞춘 주장 꼴)를 verdicts-<꼬리표>-<회>.md에 먼저 쓰고, 표는 그 파일만 셉니다. (계획 고침 D7: 꼬리표마다 따로 돌려 얼리고, N2는 verdicts-<꼬리표>-n2.md. 모든 판정 파일이 얼려진 뒤 짝 파일을 엽니다.)
- 판정 파일을 쓴 뒤에는 입장 · 열쇠 · 기준을 바꾸지 않습니다.
- 이 글이 정하지 않은 꼴이 나오면 넘는 쪽에 불리하게(바르지 않음 · 해로움 · 오탐 · 표지 없는 규칙 연습) 세고, 그 꼴을 견본.md에 적습니다.
- 기록만 하는 것(판정에 넣지 않음): 할 일이 라벨 설명을 옮겨 적었거나 어느 줄을 어떻게 고칠지 말한 것, 1.9.0 정의의 (b), L 노트가 개념 연습을 규칙 연습으로 바꾼 수, 규칙 연습 호출의 출력 토큰 · 시간.

N2 입장: 1.9.0 N2와 같습니다. 얼린 기대 판정과 견주고, parseCheck(text, { rule: true }) 뒤 '안 지킴 + 맞음 → 거의' 낮추기를 거친 판정으로 셉니다. 바른 판정은 지키고 동작함 → 맞음, 어겼지만 동작함 → 거의 또는 틀림, 깨짐 → 틀림 또는 거의, 엉뚱함 → 틀림입니다.

읽는 법(1.10.0 글의 이름을 1.12.0에서 읽는 자리; 글은 바꾸지 않음)
- §4 '켠 읽기는 withRuleDrill 뒤': 1.12.0에는 withRuleDrill이 없습니다(a4ac818에서 지움). 켠 읽기의 최종 글은 §1의 1.12.0 켠 읽기 글입니다(설계 '공통' §1).
- §11 · 세부 15의 'HEAD fca5988': 1.10.0 때의 말 그대로 fca5988(1.9.0)의 ruleLabelled · drillOf입니다.
- '그 판 트리': 짓기 커밋 a4ac818의 트리(`impl112/b1/mtree`, git archive)입니다.
- 1.10.0 글의 '2단 견본'(N2)은 둘째 스테이지 견본입니다. 1.12.0 글의 '1단' · '2단'(코드가 만든 고침 · 연습 호출)과 다릅니다.
- 세부 21의 '못 넘음 → 넘음이면 새 하위 에이전트가 … 확인해야 그 수를 씀': 1.12.0에서는 결정 규칙 5('못 넘음이 켬으로 바뀌지 않음')와 계획 judges(판정자와 확인자가 갈리면 넘는 쪽에 불리하게, M-9)를 따릅니다. 확인자가 적은 행은 넘는 쪽에 불리하게 세고, 도구 결함을 고쳐 다시 센 수가 못 넘음을 넘음으로 바꾸면 그 수를 쓰지 않고 못 넘음으로 둡니다(더 엄한 쪽).
- 세부 20의 label.py · count.py · route.py, 세부 22의 n2verify.py, 세부 23의 n2judge.mjs, 세부 12의 runlib: 아래 '틀과 도구' 표의 1.12.0 도구입니다. N2 요청을 꼬리표의 모델로 보내는 일은 route.py 대신 `tools/n2build.mjs lines`가 짝 파일을 읽어 하고 짝을 찍지 않습니다.

다시 커밋하는 1.10.0 세부 1 ~ 24 (판정 스크립트가 정한 세부, 432ced4 글 그대로; 바꾼 곳은 ~~ ~~와 1.12.0 글)

1. §5 찾기: 쓰라는 이름은 holdsName 그대로 찾습니다(바로 앞이 글자 · 숫자 · `_` · `$` · `.`이 아니고 바로 뒤가 글자 · 숫자 · `_` · `$`가 아님). 표지도 온전한 이름으로 찾되 바로 앞의 `.`은 됩니다(열쇠의 날짜 표지는 `d.toISOString()`처럼 메서드라서). `(` · `.`로 끝나는 표지(`fetch(` · `print(` · `requests.`)는 그 글자가 이름 바로 뒤에 와야 합니다. 낱말은 글자 그대로 들어 있으면 찾은 것이고, `API`는 대소문자를 가리지 않습니다.
2. §5 짚은 규칙: 노트의 `다를 수 있음` 줄(규칙 연습이 든 rule 줄, noteRuleOf가 읽은 것) 글에서 찾습니다.
3. §6 (iii) 같은 파일: drillOf가 준 file(저장소 기준 경로)과 violations의 file이 같고, 두 줄에서 공백을 모두 빼고 끝 `;` · `,`를 뗀 글이 같음.
4. §6 (iv) · (v) 돌리기: 그 연습 줄(drillOf의 n행, 들여쓰기 그대로)만 예시 답으로 바꾼 파일들로 견본 demo를 첫 파일 끝에서 돌립니다. js · ts 두 번, py 다섯 번(B-14)이 종료 코드 · 표준 출력 · 기록 줄 모두 같아야 하고 종료 코드 0이어야 합니다. 표준 출력은 줄마다(빈 줄 빼고) §7 정규화로 expected_fixed와 견주고, 줄 수도 같아야 합니다. 돌리는 틀이 찍는 `[value] …` 줄도 출력에 듭니다(expected · expected_fixed도 그 줄을 품음).
5. 오류: 종료 코드가 0이 아님(시간 한도 124 포함).
6. §7 첫 호출: 확인 줄의 코드 칸(`` ` `` · `` `` ``) 가운데 `이름(`이 처음 나오는 칸에서, 그 이름부터 짝 괄호까지(앞의 `await`는 뗌). 그 호출이 자리표시(`…` · `...` · `[A]` 꼴 · `<…>`)를 품거나 코드 칸에 호출이 없으면 견본 demo를 돌립니다. 호출한 이름이 바꾼 파일의 맨 위 수준에 정의되어 있으면(js · ts의 function · const · let · var · class, py의 def · class · 이름 =) 그 호출을 바꾼 파일 끝에서 돌리고, 아니면(팀 모듈 · 내장 함수 · 변경의 다른 파일에 있는 함수 포함) 거짓입니다(§7 둘째 줄, 다른 파일의 함수는 글이 정하지 않아 §15).
7. §7 주장: 확인 줄에서 처음 나오는 `→`(또는 `->` · `=>`) 뒤의 글. 화살표가 없으면 확인 줄에서 그 호출의 코드 칸을 뺀 글.
8. §7 (1) 값: 주장 안의 코드 칸(규칙의 쓰라는 이름이나 표지 하나만 든 칸은 빼고), 따옴표(`"` · `'` · `“”` · `‘’` · `「」`) 안의 글, 수(앞뒤에 ASCII 글자 · 숫자 · `_` · `.` · `-`가 붙지 않은 것: `3개`의 3은 수, `2026-10-22`는 수가 아님). 값마다 호출 값(JSON으로 읽히면 값으로, 아니면 글자열 값의 글자나 JSON 글과), 표준 출력의 한 줄(돌리는 틀의 `[value]` 줄 빼고), 기록의 한 줄(`[apiRequest] …` 꼴 그 줄 전체) 가운데 하나와 §7 정규화로 같아야 합니다. 조건(§7 (5))의 값도 값으로 셉니다(조건을 기계로 가르는 글이 없어 §15).
9. §7 (2) 같음 말: 코드 칸 · 따옴표 밖의 글에 `같은` · `그대로` · `똑같이` · `변함없이` · `달라지지 않`이 있으면, 같은 호출을 원래 파일(견본 after)로 돌려 호출 값(§7 정규화)과 표준 출력(줄마다)이 같아야 합니다. 둘 다 오류 없이 돌아야 합니다.
10. §7 (3) 효과 말: 코드 칸 · 따옴표 밖의 글에 그 규칙의 쓰라는 이름이 있거나 쓰라는 이름 하나만 든 코드 칸이 있음, 또는 `(기록|로그)…남` → 기록, `인증` · `재시도` → 요청, `설정에서 읽` → 설정, `날짜 글자로` → 날짜. 말한 규칙마다 그 호출의 기록 줄에 그 대역의 줄(`[apiRequest] ` · `[log.info] ` · `[toDateText] ` · `[config] `로 시작)이 있어야 합니다.
11. §7 (4) · (6): 값 · 같음 말 · 효과 말 가운데 있는 것이 모두 맞아야 참이고, 하나도 없으면 거짓입니다. 확인 호출도 js · ts 두 번, py 다섯 번이 모두 같아야 하며, 다르면 거짓입니다.
12. §8 틀: 빈 임시 폴더에 대역(아래 runlib)과 견본 파일(같은 경로면 견본 파일이 대역을 갈음)을 두고, `unshare -n timeout 5 env -i PATH=… LANG=C.UTF-8 TZ=UTC <견본 env>`로 돌립니다(py는 PYTHONHASHSEED=1~5를 더하고 `python3 -s -P -B`로 폴더 맨 위의 실행 파일을 돌려, 그 파일이 폴더를 sys.path에 넣고 모듈을 run_name `__learnrun__`로 돌림. 그래서 `if __name__ == "__main__":` 아래는 돌지 않음). js · ts는 `node`(ts는 `--experimental-transform-types`)에 `--import`로 미리 심은 globalThis.fetch(견본 responses, 기록 없음)를 둡니다. 호출 값 줄은 js · ts `console.log('[value] ' + (JSON.stringify(await (호출)) ?? 'null'))`, py `print('[value] ' + __import__('json').dumps((호출), ensure_ascii=False, default=str))`이고(파일에 import 문을 더하지 않음), 응답은 주소가 품은 첫 키의 값(상태 200), 맞는 키가 없으면 404와 `{}`입니다.
13. §8 구문 오류: js · ts는 바꾼 파일을 그것 하나만 진입점으로 불러(호출 없이) 종료 코드가 0이 아니고 stderr에 `SyntaxError`가 있음(node `--check`는 ts를 검사하지 않음), py는 py_compile이 실패함.
14. §9: 켠 읽기와 끈 읽기의 개념 연습마다, §5 '들인 규칙'이 하나라도 있으면 셉니다.
15. §11: fca5988의 조합 `ruleLabelled(closeConceptBold(cut(답, 9000)))`(= keptNoteText(답, []), 시험으로 고정)과 keptNoteText(답, names)가 다른 노트에서, fca5988 글을 fca5988의 drillOf(…, false)로 읽은 연습을 봅니다.
16. §13: 직접 해 보기 칸(제목에서 다음 제목까지, ruleLabelled가 칸을 가르는 그대로)마다 taskLineOf가 읽는 할 일 줄을 셉니다. 한 칸이라도 둘 이상이면 셉니다. 켠 읽기 · 끈 읽기 모두, 답한 모든 노트에서 셉니다(B-6).
17. (b)의 '해로운 연습 0' · '할 일 줄 둘인 노트 0'은 den만이 아니라 그 회의 답한 모든 노트에서 셉니다(B-6). '바른 규칙 연습 80%'는 den 노트의 켠 읽기 규칙 연습 가운데 바름 수 ÷ den입니다.
18. 규칙 연습 호출의 답 없음 줄: 두 회를 합친 규칙 연습 호출 n번 가운데 상한 닿음 · 빈 답 · 시간 한도인 것이 max(1, ⌊n / 60⌋)개 이하. 상한 닿음은 output_tokens ≥ maxTokens + H_M(~~haiku 2048 · sonnet 0~~ 1.12.0 보정: haiku 2048 · sonnet 2048, 곧 2단 호출 5548)이고, 답한 호출도 닿았으면 셉니다. (1.12.0) 규칙 연습 호출은 2단 호출이고(1단 · 건너뜀은 호출 없음), 빈 답은 API 거절을 포함합니다(E18).
19. §14: 표지 노트 = 최종 글에 `- 할 일 (팀 규칙):`로 시작하는 줄이 있는 노트. 옛 창 ~~넷~~ 여섯(1.12.0, §14)의 drillOf가 연습을 주지 않고, 그 창 패널이 부르는 꼴의 hideDrillAnswer 글에 `고칠 줄` · `예시 답` 라벨 줄이 없어야 합니다. 표지 없는 노트는 그 창의 drillOf가 ~~1.10.0의 그 읽기(켬 · 끔)~~ 3d2f251의 drillOf로 그 읽기(켬 · 끔)를 한 것(1.12.0, §14)과 같은 할 일 · 고칠 줄 · 예시 답 · 파일 · 행을 줘야 합니다. 켠 · 끈 최종 글 모두, ~~네~~ 여섯 창 모두입니다.
20. 꼬리표(M-8, 결정 D7): 회 A · B와 헷갈리지 않게 P · Q로 씁니다. 이 G의 모든 스테이지(N1′ 회 A · B와 N2)에 한 번 뽑은 짝을 쓰고(N2 견본이 그 꼬리표 회 A에서 나오므로), pair.json을 얼려 sha256만 적습니다. label.py가 꼬리표 파일에서 모델 이름 · 시간 · 토큰 · 상한을 빼고, 그 수는 count.py만 셉니다. N2 요청을 그 꼬리표의 모델로 보내는 일은 route.py가 짝 파일을 읽어 하고 짝을 찍지 않습니다. 부르는 쪽(이 묶음을 짓는 쪽)은 어느 모델을 부르는지 압니다. 그래서 두 모델의 그 스테이지 답이 얼려지기 전에는 답 글을 열지 않고(M-3), 판정은 스크립트가 꼬리표 파일로만 합니다.
21. 판정 파일 행 확인(설계 '사람은 스크립트가 입장 글대로 셌는지를 행마다 확인'): 꼬리표마다 새 하위 에이전트 하나(`claude -p --model opus --tools ''`, 그 꼬리표의 판정 파일과 이 절의 입장 · 세부만 받음, 한 하위 에이전트가 두 꼬리표를 보지 않음)가 글대로 세지 않은 행을 적습니다. 적힌 행이 있으면 M-15대로 합니다(글이 이김, 도구를 고쳐 두 꼬리표를 다시 세고 전후 수를 모두 적으며, 못 넘음 → 넘음이면 새 하위 에이전트가 '글을 옮긴 고침'임을 확인해야 그 수를 씀).
22. N2 대역 확인(n2verify.py, 결정 D8 (2)): gradeDrill이 부르지 않는 줄(빈 줄, sameLine으로 예시 답 · 고칠 줄과 같음, 한글 자판)은 못 넘음. 그 연습 줄만 답 줄로 바꾼 파일로 demo를 돌려(js · ts 두 번, py 다섯 번) 갈래마다: keep = 모두 같음 · 종료 0 · r의 쓰라는 이름 있음 · r의 표지 없음 · 출력이 예시 답의 출력과 같음, break = 모두 같음 · 종료 0 · (r의 표지 있음 또는 쓰라는 이름 없음), broken = 쓰라는 이름 있음 · (돌릴 때마다 다름 또는 종료가 0이 아님 또는 출력이 예시 답과 다름), off = 쓰라는 이름 없음 · (종료가 0이 아님 또는 출력이 예시 답과 다름). 못 넘은 본 답은 그 연습의 같은 갈래 예비가 넘으면 그것으로 채우고, 아니면 빼고 그 수를 적습니다(고쳐 쓰지 않음). 기대 판정: keep 맞음, break 거의 · 틀림, broken 틀림 · 거의, off 틀림(N2 입장).
23. N2 셈(n2judge.mjs): 답 없음 · 읽지 못한 답은 바른 판정이 아니고 `규칙:` 줄 빠짐으로도 셉니다(B-8). 회마다 바른 판정 27개 이상 · 어김(break)→맞음 1개 이하 · 깨짐(broken)→맞음 0 · `규칙:` 줄 빠짐 1개 이하, 두 번 모두 넘어야 N2 넘음.
24. 기록만 하는 것(판정에 넣지 않음): 1.9.0 정의의 (b)(L 전체를 분모로), L 노트가 개념 연습인 수 · 연습 없는 수, 할 일에 `한 문장으로` · `어느 줄을`이 든 규칙 연습 수(라벨 설명을 옮긴 꼴의 어림), 규칙 연습 호출 결과의 꼴, 호출마다의 output_tokens · 시간(count.py).


## 판정 파일 (꼬리표 Q)

# verdicts Q round A

- GA01 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const res = await fetch(saleUrl);", "example": "const res = await apiRequest(saleUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GA02 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const res = await fetch(url, opts);", "example": "const res = await apiRequest(url, opts);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GA03 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const res = await fetch(url);", "example": "const res = await apiRequest(url);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GA04 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "res = requests.get(url)", "example": "res = api_request(url)", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GA05 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "res = requests.post(url, json=body)", "example": "res = api_request(url, json=body)", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GA06 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('capped', order.id);", "example": "log.info('capped', order.id);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GA07 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('new hold', memberId);", "example": "log.info('new hold', memberId);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GA08 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "console.log(`missed ${missed} days`);", "example": "log.info(`missed ${missed} days`);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GA09 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('heavy:', heavy.length);", "example": "log.info('heavy:', heavy.length);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GA10 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "print(f\"on sale: {on_sale}\")", "example": "log.info(f\"on sale: {on_sale}\")", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GA11 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const due = end.toJSON().slice(0, 10);", "example": "const due = toDateText(end);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GA12 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "return when.toISOString().slice(0, 10);", "example": "return toDateText(value);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GA13 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "not-anchored"}
- GA14 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "back_text = back.strftime(\"%Y-%m-%d\")", "example": "back_text = to_date_text(back)", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GA15 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "first_day = upcoming.isoformat()", "example": "first_day = to_date_text(upcoming)", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GA16 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const hideFlag = process.env.HIDE_SOLD;", "example": "const hideFlag = config.HIDE_SOLD;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GA17 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "not-one-span"}
- GA18 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const kb = Number(process.env.MAX_KB);", "example": "const kb = Number(config.MAX_KB);", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GA19 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "goal = int(os.environ[\"FREE_SHIP_AT\"])", "example": "goal = int(config.FREE_SHIP_AT)", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GA20 {"kind": "R", "isL": true, "den": true, "tier": 0, "why": "no-line"}
- GB01 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const pinRes = await fetch(PINNED_API);", "example": "const pinRes = await apiRequest(PINNED_API);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GB02 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const resp = await fetch(lookupUrl);", "example": "const resp = await apiRequest(lookupUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GB03 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const r = await fetch(REVIEW_API, opts);", "example": "const r = await apiRequest(REVIEW_API, opts);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GB04 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "stock = requests.get(STOCK_API).json()", "example": "stock = api_request(STOCK_API).json()", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GB05 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "resp = requests.get(url, timeout=5)", "example": "resp = api_request(url, timeout=5)", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GB06 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('earned points:', earned);", "example": "log.info('earned points:', earned);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GB07 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('step ->', upcoming);", "example": "log.info('step ->', upcoming);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GB08 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('short', l.sku, gap);", "example": "log.info('short', l.sku, gap);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GB09 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "print('discount', off)", "example": "log.info('discount', off)", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GB10 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "print('late count:', len(late))", "example": "log.info('late count:', len(late))", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GB11 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "parse"}
- GB12 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const dayStr = d.toJSON().slice(0, 10);", "example": "const dayStr = toDateText(latestMs);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GB13 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "return when.toISOString().split('T')[0];", "example": "return toDateText(m.renewedAt ?? m.joinedAt);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GB14 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "due_text = back_on.strftime('%Y-%m-%d')", "example": "due_text = to_date_text(back_on)", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GB15 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "plan.append(when.date().isoformat())", "example": "plan.append(to_date_text(when))", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GB16 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const home = process.env.SUPPORT_URL;", "example": "const home = config.SUPPORT_URL;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GB17 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const k = Number(process.env.PAGE_ROWS);", "example": "const k = Number(config.PAGE_ROWS);", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GB18 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const flag = process.env.SHOW_PROMO;", "example": "const flag = config.SHOW_PROMO;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GB19 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const v = process.env['MAX_PHOTO_MB'];", "example": "const v = config['MAX_PHOTO_MB'];", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GB20 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "addr = os.environ['REPLY_TO']", "example": "addr = config['REPLY_TO']", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GB21 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GB22 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GB23 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-hint"}
- GB24 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GC01 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC02 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC03 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC04 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC05 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC06 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC07 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC08 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC09 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC10 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC11 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC12 {"kind": "F", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GC13 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC14 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC15 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC16 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC17 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC18 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC19 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC20 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC21 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC22 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC23 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC24 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GD01 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- GD02 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- GD03 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- GD04 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- GD05 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GD06 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GD07 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GD08 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GD09 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GD10 {"kind": "multi", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const soonRes = await fetch(soonUrl);", "example": "const soonRes = await apiRequest(soonUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GD11 {"kind": "multi", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const helpUrl = process.env.HELP_URL;", "example": "const helpUrl = config.HELP_URL;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GD12 {"kind": "multi", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "eta = requests.get(eta_url).json()", "example": "eta = api_request(eta_url).json()", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GD13 {"kind": "multi", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "print(\"hours\", hours_text)", "example": "log.info(\"hours\", hours_text)", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GD14 {"kind": "double", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('item kinds', cart.length);", "example": "log.info('item kinds', cart.length);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GD15 {"kind": "double", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const inRes = await fetch(inUrl);", "example": "const inRes = await apiRequest(inUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GD16 {"kind": "double", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "rent_on = rented_at.strftime(\"%Y-%m-%d\")", "example": "rent_on = to_date_text(rented_at)", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GD17 {"kind": "double", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const cdnHost = process.env.CDN_URL;", "example": "const cdnHost = config.CDN_URL;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}

## counts

{
 "answered": 85,
 "unanswered": [],
 "L": 58,
 "O": 27,
 "den": 48,
 "correct": 44,
 "harmful": [],
 "twoTask": [
  "GD15"
 ],
 "O_rule": [],
 "c_bad": [],
 "trap_rule": [],
 "noShort_rule": [],
 "unlabelled": [],
 "old_bad": [],
 "idem_bad": [],
 "off_not_kept": [],
 "w_changed": 0,
 "w_fp": [],
 "undecided": [],
 "miss": {
  "no rule practice (not-anchored)": 1,
  "no rule practice (not-one-span)": 1,
  "no rule practice (no-line)": 1,
  "no rule practice (parse)": 1
 },
 "tiers": {
  "tier1": 15,
  "tier2": 32,
  "tier0-no-line": 10,
  "tier0-no-hint": 1
 },
 "drill_called": 32,
 "offW0_differs_tree": []
}


# verdicts Q round B

- GA01 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const res = await fetch(saleUrl);", "example": "const res = await apiRequest(saleUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GA02 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const res = await fetch(url, opts);", "example": "const res = await apiRequest(url, opts);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GA03 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const res = await fetch(url);", "example": "const res = await apiRequest(url);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GA04 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "res = requests.get(url)", "example": "res = api_request(url)", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GA05 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "res = requests.post(url, json=body)", "example": "res = api_request(url, json=body)", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GA06 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('capped', order.id);", "example": "log.info('capped', order.id);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GA07 {"kind": "R", "isL": false, "den": false, "tier": null, "why": null}
- GA08 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "console.log(`missed ${missed} days`);", "example": "log.info(`missed ${missed} days`);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GA09 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('heavy:', heavy.length);", "example": "log.info('heavy:', heavy.length);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GA10 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "print(f\"on sale: {on_sale}\")", "example": "log.info(f\"on sale: {on_sale}\")", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GA11 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const due = end.toJSON().slice(0, 10);", "example": "const due = toDateText(end);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GA12 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "return when.toISOString().slice(0, 10);", "example": "return toDateText(value);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GA13 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "return at.toISOString().split('T')[0];", "example": "return toDateText(at);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GA14 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "back_text = back.strftime(\"%Y-%m-%d\")", "example": "back_text = to_date_text(back)", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GA15 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "first_day = upcoming.isoformat()", "example": "first_day = to_date_text(upcoming)", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GA16 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const hideFlag = process.env.HIDE_SOLD;", "example": "const hideFlag = config.HIDE_SOLD;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GA17 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "not-one-span"}
- GA18 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const kb = Number(process.env.MAX_KB);", "example": "const kb = Number(config.MAX_KB);", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GA19 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "goal = int(os.environ[\"FREE_SHIP_AT\"])", "example": "goal = int(config.FREE_SHIP_AT)", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GA20 {"kind": "R", "isL": true, "den": true, "tier": 0, "why": "no-line"}
- GB01 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const pinRes = await fetch(PINNED_API);", "example": "const pinRes = await apiRequest(PINNED_API);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GB02 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const resp = await fetch(lookupUrl);", "example": "const resp = await apiRequest(lookupUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GB03 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const r = await fetch(REVIEW_API, opts);", "example": "const r = await apiRequest(REVIEW_API, opts);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GB04 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "stock = requests.get(STOCK_API).json()", "example": "stock = api_request(STOCK_API).json()", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GB05 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "resp = requests.get(url, timeout=5)", "example": "resp = api_request(url, timeout=5)", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GB06 {"kind": "R", "isL": false, "den": false, "tier": null, "why": null}
- GB07 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('step ->', upcoming);", "example": "log.info('step ->', upcoming);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GB08 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('short', l.sku, gap);", "example": "log.info('short', l.sku, gap);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GB09 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "print('discount', off)", "example": "log.info('discount', off)", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GB10 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "print('late count:', len(late))", "example": "log.info('late count:', len(late))", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GB11 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "return eta.toISOString().slice(0, 10);", "example": "return toDateText(ms);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GB12 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const dayStr = d.toJSON().slice(0, 10);", "example": "const dayStr = toDateText(d);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GB13 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "return when.toISOString().split('T')[0];", "example": "return toDateText(m.renewedAt ?? m.joinedAt);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GB14 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "due_text = back_on.strftime('%Y-%m-%d')", "example": "due_text = to_date_text(back_on)", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GB15 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "plan.append(when.date().isoformat())", "example": "plan.append(to_date_text(when))", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GB16 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const home = process.env.SUPPORT_URL;", "example": "const home = config.SUPPORT_URL;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GB17 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const k = Number(process.env.PAGE_ROWS);", "example": "const k = Number(config.PAGE_ROWS);", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GB18 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const flag = process.env.SHOW_PROMO;", "example": "const flag = config.SHOW_PROMO;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GB19 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const v = process.env['MAX_PHOTO_MB'];", "example": "const v = config['MAX_PHOTO_MB'];", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GB20 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "addr = os.environ['REPLY_TO']", "example": "addr = config['REPLY_TO']", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GB21 {"kind": "R_long", "isL": false, "den": false, "tier": null, "why": null}
- GB22 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GB23 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-hint"}
- GB24 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GC01 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC02 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC03 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC04 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC05 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC06 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC07 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC08 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC09 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC10 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC11 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC12 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC13 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC14 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC15 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC16 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC17 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC18 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC19 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC20 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC21 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC22 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC23 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC24 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GD01 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- GD02 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- GD03 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- GD04 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- GD05 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GD06 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- GD07 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GD08 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GD09 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GD10 {"kind": "multi", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const soonRes = await fetch(soonUrl);", "example": "const soonRes = await apiRequest(soonUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GD11 {"kind": "multi", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const helpUrl = process.env.HELP_URL;", "example": "const helpUrl = config.HELP_URL;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GD12 {"kind": "multi", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "eta = requests.get(eta_url).json()", "example": "eta = api_request(eta_url).json()", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GD13 {"kind": "multi", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "print(\"hours\", hours_text)", "example": "log.info(\"hours\", hours_text)", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GD14 {"kind": "double", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('item kinds', cart.length);", "example": "log.info('item kinds', cart.length);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GD15 {"kind": "double", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const inRes = await fetch(inUrl);", "example": "const inRes = await apiRequest(inUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GD16 {"kind": "double", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "renew_on = renew_at.date().isoformat()", "example": "renew_on = to_date_text(renew_at)", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GD17 {"kind": "double", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const cdnHost = process.env.CDN_URL;", "example": "const cdnHost = config.CDN_URL;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}

## counts

{
 "answered": 85,
 "unanswered": [],
 "L": 53,
 "O": 32,
 "den": 46,
 "correct": 44,
 "harmful": [],
 "twoTask": [],
 "O_rule": [],
 "c_bad": [],
 "trap_rule": [],
 "noShort_rule": [],
 "unlabelled": [],
 "old_bad": [],
 "idem_bad": [],
 "off_not_kept": [],
 "w_changed": 0,
 "w_fp": [],
 "undecided": [],
 "miss": {
  "no rule practice (not-one-span)": 1,
  "no rule practice (no-line)": 1
 },
 "tiers": {
  "tier1": 15,
  "tier2": 30,
  "tier0-no-line": 7,
  "tier0-no-hint": 1
 },
 "drill_called": 30,
 "offW0_differs_tree": []
}


## 출력

JSON 하나만 ```json 블록으로 쓴다. 글대로 세지 않은 행이 없으면 빈 배열이다.
[{"round": "A|B", "id": "<견본 id>", "field": "correct|harm|unlabelled|O_rule|trap_rule|noShort_rule|twoTask|w_fp|old_bad|c_bad|other", "script": "<스크립트가 센 것>", "text": "<글대로면 무엇인지>", "clause": "<조항 · 세부 번호>", "why": "<한두 문장>"}]
