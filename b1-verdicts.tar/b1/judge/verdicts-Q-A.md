# verdicts Q round A

- GA01 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const res = await fetch(saleUrl);", "example": "const res = await apiRequest(saleUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GA02 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const res = await fetch(url, opts);", "example": "const res = await apiRequest(url, opts);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GA03 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const res = await fetch(url);", "example": "const res = await apiRequest(url);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GA04 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "res = requests.get(url)", "example": "res = api_request(url)", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GA05 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "res = requests.post(url, json=body)", "example": "res = api_request(url, json=body)", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GA06 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('capped', order.id);", "example": "log.info('capped', order.id);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GA07 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('new hold', memberId);", "example": "log.info('new hold', memberId);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GA08 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "console.log(`missed ${missed} days`);", "example": "log.info(`missed ${missed} days`);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GA09 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('heavy:', heavy.length);", "example": "log.info('heavy:', heavy.length);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GA10 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "print(f\"on sale: {on_sale}\")", "example": "log.info(f\"on sale: {on_sale}\")", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GA11 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const due = end.toJSON().slice(0, 10);", "example": "const due = toDateText(end);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GA12 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "return when.toISOString().slice(0, 10);", "example": "return toDateText(value);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GA13 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "not-anchored"}
- GA14 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "back_text = back.strftime(\"%Y-%m-%d\")", "example": "back_text = to_date_text(back)", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GA15 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "first_day = upcoming.isoformat()", "example": "first_day = to_date_text(upcoming)", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GA16 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const hideFlag = process.env.HIDE_SOLD;", "example": "const hideFlag = config.HIDE_SOLD;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GA17 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "not-one-span"}
- GA18 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const kb = Number(process.env.MAX_KB);", "example": "const kb = Number(config.MAX_KB);", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GA19 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "goal = int(os.environ[\"FREE_SHIP_AT\"])", "example": "goal = int(config.FREE_SHIP_AT)", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GA20 {"kind": "R", "isL": true, "den": true, "tier": 0, "why": "no-line"}
- GB01 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const pinRes = await fetch(PINNED_API);", "example": "const pinRes = await apiRequest(PINNED_API);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GB02 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const resp = await fetch(lookupUrl);", "example": "const resp = await apiRequest(lookupUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GB03 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const r = await fetch(REVIEW_API, opts);", "example": "const r = await apiRequest(REVIEW_API, opts);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GB04 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "stock = requests.get(STOCK_API).json()", "example": "stock = api_request(STOCK_API).json()", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GB05 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "resp = requests.get(url, timeout=5)", "example": "resp = api_request(url, timeout=5)", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GB06 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('earned points:', earned);", "example": "log.info('earned points:', earned);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GB07 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('step ->', upcoming);", "example": "log.info('step ->', upcoming);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GB08 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('short', l.sku, gap);", "example": "log.info('short', l.sku, gap);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GB09 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "print('discount', off)", "example": "log.info('discount', off)", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GB10 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "print('late count:', len(late))", "example": "log.info('late count:', len(late))", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GB11 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "parse"}
- GB12 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const dayStr = d.toJSON().slice(0, 10);", "example": "const dayStr = toDateText(latestMs);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GB13 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "return when.toISOString().split('T')[0];", "example": "return toDateText(m.renewedAt ?? m.joinedAt);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GB14 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "due_text = back_on.strftime('%Y-%m-%d')", "example": "due_text = to_date_text(back_on)", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GB15 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "plan.append(when.date().isoformat())", "example": "plan.append(to_date_text(when))", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GB16 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const home = process.env.SUPPORT_URL;", "example": "const home = config.SUPPORT_URL;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GB17 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const k = Number(process.env.PAGE_ROWS);", "example": "const k = Number(config.PAGE_ROWS);", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GB18 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const flag = process.env.SHOW_PROMO;", "example": "const flag = config.SHOW_PROMO;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GB19 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const v = process.env['MAX_PHOTO_MB'];", "example": "const v = config['MAX_PHOTO_MB'];", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GB20 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "addr = os.environ['REPLY_TO']", "example": "addr = config['REPLY_TO']", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GB21 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GB22 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GB23 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-hint"}
- GB24 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GC01 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC02 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC03 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC04 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC05 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC06 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC07 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC08 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC09 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC10 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC11 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- GC12 {"kind": "F", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GC13 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC14 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC15 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC16 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC17 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC18 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC19 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC20 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC21 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC22 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC23 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GC24 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- GD01 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- GD02 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- GD03 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- GD04 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- GD05 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GD06 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GD07 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GD08 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GD09 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- GD10 {"kind": "multi", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const soonRes = await fetch(soonUrl);", "example": "const soonRes = await apiRequest(soonUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GD11 {"kind": "multi", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const helpUrl = process.env.HELP_URL;", "example": "const helpUrl = config.HELP_URL;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- GD12 {"kind": "multi", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "eta = requests.get(eta_url).json()", "example": "eta = api_request(eta_url).json()", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GD13 {"kind": "multi", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "print(\"hours\", hours_text)", "example": "log.info(\"hours\", hours_text)", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GD14 {"kind": "double", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('item kinds', cart.length);", "example": "log.info('item kinds', cart.length);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- GD15 {"kind": "double", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const inRes = await fetch(inUrl);", "example": "const inRes = await apiRequest(inUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- GD16 {"kind": "double", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "rent_on = rented_at.strftime(\"%Y-%m-%d\")", "example": "rent_on = to_date_text(rented_at)", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- GD17 {"kind": "double", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const cdnHost = process.env.CDN_URL;", "example": "const cdnHost = config.CDN_URL;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}

## counts

{
 "answered": 85,
 "unanswered": [],
 "L": 58,
 "O": 27,
 "den": 48,
 "correct": 44,
 "harmful": [],
 "twoTask": [
  "GD15"
 ],
 "O_rule": [],
 "c_bad": [],
 "trap_rule": [],
 "noShort_rule": [],
 "unlabelled": [],
 "old_bad": [],
 "idem_bad": [],
 "off_not_kept": [],
 "w_changed": 0,
 "w_fp": [],
 "undecided": [],
 "miss": {
  "no rule practice (not-anchored)": 1,
  "no rule practice (not-one-span)": 1,
  "no rule practice (no-line)": 1,
  "no rule practice (parse)": 1
 },
 "tiers": {
  "tier1": 15,
  "tier2": 32,
  "tier0-no-line": 10,
  "tier0-no-hint": 1
 },
 "drill_called": 32,
 "offW0_differs_tree": []
}
