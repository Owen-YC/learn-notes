#!/bin/bash
# usage: gate.sh <name>   tsc, validate and the full suite on /home/user/learn-notes through the pinned CLI; test names to <name>.names
X=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/xr/fix1
P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh
N=$1
cd /home/user/learn-notes || exit 9
npx tsc -p . --noEmit > "$X/gate-$N.tsc" 2>&1; T=$?
$P claude plugin validate . > "$X/gate-$N.validate" 2>&1; V=$?
$P claude plugin test . > "$X/gate-$N.test" 2>&1; E=$?
grep -E '^\((pass|fail)\)' "$X/gate-$N.test" | sed -E 's/^\((pass|fail)\) //; s/ \[[0-9.]+m?s\]$//' | sort > "$X/gate-$N.names"
echo "$N tsc=$T validate=$V test=$E pass=$(grep -c '^(pass)' "$X/gate-$N.test") fail=$(grep -c '^(fail)' "$X/gate-$N.test") $(tail -1 "$X/gate-$N.validate")"
