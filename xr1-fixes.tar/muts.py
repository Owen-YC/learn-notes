# Mutations for cross-review round 1 (robustness lens). Each: (name, file, old, new). old must occur exactly once.
R = 'hooks/register.tsx'
PROBE = '(aliasRead !== undefined && remap === "kept" ? (await remapState($, aliasRead.model), true) : remap === "kept")'
MUTS = [
 ('M01-quizRecheckReadOnly', R,
  "if (Number.isFinite(build.rungChangedStep) || Number.isFinite(build.rungNewStep)) await recheckRemap($)",
  "if (Number.isFinite(build.rungChangedStep) || Number.isFinite(build.rungNewStep)) await " + PROBE),
 ('M02-numberUnsureReadOnly', R,
  "if (!Number.isFinite(build.rungChangedStep) || !(await recheckRemap($)) || !Number.isFinite(build.rungChangedStep)) return undefined",
  "if (!Number.isFinite(build.rungChangedStep) || !(" + "await " + PROBE + ") || !Number.isFinite(build.rungChangedStep)) return undefined"),
 ('M03-startResetDropsMissed', R,
  "await update($, quizRun, run => ({ isMaking: false, error: null, checking: null, ...missedKept(run) }))",
  "await update($, quizRun, run => ({ isMaking: false, error: null, checking: null }))"),
 ('M04-startQuizFirstDropsMissed', R,
  "await update($, quizRun, run => ({ isMaking: true, error: null, ...missedKept(run) }))",
  "await update($, quizRun, run => ({ isMaking: true, error: null }))"),
 ('M05-changedNotOnlyCreate', R,
  "const isChanged = change.kind === 'create' && !missed.has(one.key) && isChangedAskable(",
  "const isChanged = !missed.has(one.key) && isChangedAskable("),
 ('M06-missedIgnored', R,
  "const isChanged = change.kind === 'create' && !missed.has(one.key) && isChangedAskable(",
  "const isChanged = change.kind === 'create' && isChangedAskable("),
 ('M07-typedAnswerRaw', R,
  "      answerShown(done),\n",
  "      done.answer,\n"),
 ('M08-timeoutNotMissed', R,
  "if (asked.fail?.reason === 'empty-reply' || asked.fail?.isTimeout === true) {",
  "if (asked.fail?.reason === 'empty-reply') {"),
 ('M09-ruleWideRecheckReadOnly', R,
  "text !== keptNoteText(asked.text) && !(await recheckRemap($))) {",
  "text !== keptNoteText(asked.text) && !(await " + PROBE + ")) {"),
 ('M10-diagRecheckReadOnly', R,
  "  // The route as it stands now: an alias or a provider's switch set since session start turns every switch off.\n  await recheckRemap($)",
  "  // The route as it stands now: an alias or a provider's switch set since session start turns every switch off.\n  await " + PROBE),
 ('M11-askNoteRecheckReadOnly', R,
  "const isThinkAsked = wasThinkAsked && (await recheckRemap($))",
  "const isThinkAsked = wasThinkAsked && (await " + PROBE + ")"),
 ('M12-gradeNewRecheckReadOnly', R,
  "if (Number.isFinite(build.rungNewStep) && isExactGrade(item)) await recheckRemap($)",
  "if (Number.isFinite(build.rungNewStep) && isExactGrade(item)) await " + PROBE),
 ('M13-drillRecheckAfterCallReadOnly', R,
  "          if (!(await recheckRemap($))) text = off\n",
  "          if (!(await " + PROBE + ")) text = off\n"),
 ('M14-drillRecheckBeforeCallReadOnly', R,
  "      if (!(await recheckRemap($))) text = off\n      else {",
  "      if (!(await " + PROBE + ")) text = off\n      else {"),
 ('M15-missedNotKeptOnParseGone', R,
  "  await miss('changedMissed', keysOf(gone, 'changed'))\n",
  "\n"),
]
MUTS.append(('M16-quizRecheckG2ReadOnly', R,
  "if (Number.isFinite(build.rungChangedStep) || Number.isFinite(build.rungNewStep)) await recheckRemap($)",
  "if (Number.isFinite(build.rungNewStep)) await recheckRemap($)\n  else if (Number.isFinite(build.rungChangedStep)) await " + PROBE))
N = 'hooks/notes.ts'
MUTS.append(('M17-wholeIgnoresRedacted', N,
  "if (change.kind !== 'create' || change.isCut || (change.redacted ?? 0) > 0) return false",
  "if (change.kind !== 'create' || change.isCut) return false"))
MUTS.append(('M18-wholeIgnoresCut', N,
  "if (change.kind !== 'create' || change.isCut || (change.redacted ?? 0) > 0) return false",
  "if (change.kind !== 'create' || (change.redacted ?? 0) > 0) return false"))
MUTS.append(('M19-missedSliceDropped', R,
  "[...new Set([...(run[list] ?? []), ...keys])].slice(-50)",
  "[...new Set([...(run[list] ?? []), ...keys])]"))
MUTS.append(('M20-answerTextRaw', R,
  "return `${n}번 정답\\n\\n${answerShown(item)}",
  "return `${n}번 정답\\n\\n${item.answer}"))
MUTS.append(('M21-answerAllRaw', R,
  "listItem(i + 1, `${answerShown(item)}\\n(개념:",
  "listItem(i + 1, `${item.answer}\\n(개념:"))
MUTS.append(('M22-paneGradedRaw', R, "              <Markdown text={answerShown(item)} />\n              <Box flexWrap", "              <Markdown text={item.answer} />\n              <Box flexWrap"))
MUTS.append(('M23-paneShownRaw', R, "                <Markdown text={answerShown(item)} />\n                <Text dimColor>", "                <Markdown text={item.answer} />\n                <Text dimColor>"))
MUTS.append(('U1-blankAskedBack', R, "  if (isBlankAnswer(after)) return undefined\n  const shown", "  const shown"))
MUTS.append(('U2-anyTextAskedBack', R, "  if (shown && outputLines(rest, shown.code, shown.lang) === undefined) return undefined\n", ""))
MUTS.append(('U3-noQuotes', R, '`${open + 1}번 답이 "${flat(rest)}"라면:', '`${open + 1}번 답이 ${flat(rest)}이면:'))
MUTS.append(('U4-shownNeverRead', N, "  if (!question.startsWith(`${CHANGED_LEAD}\\n`)) return undefined\n", "  return undefined\n"))
MUTS.append(('S1-oldName', R, "퀴즈를 내지 못했습니다: 비슷한 코드 문제를 확인하지 못했습니다.", "퀴즈를 내지 못했습니다: 바꾼 코드 문제를 확인하지 못했습니다."))
MUTS.append(('B1-blankKept', N, "  if (N.includes('')) return { reason: 'N-blank' }\n", ""))
MUTS.append(('B2-blankOnlyFirst', N, "  if (N.includes('')) return { reason: 'N-blank' }\n", "  if (N[0] === '' && N.length === 1) return { reason: 'N-blank' }\n"))
