import sys
p=sys.argv[1]+'/hooks/notes.ts'; s=open(p,encoding='utf8').read()
a="      if (tries >= CHANGED_RUN_TRIES || Date.now() > until) break places\n"
assert s.count(a)==1; s=s.replace(a,"      if (Date.now() > until) break places\n"); open(p,'w',encoding='utf8').write(s); print('m6 ok')
