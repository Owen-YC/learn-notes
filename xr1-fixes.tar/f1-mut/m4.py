import sys
p=sys.argv[1]+'/hooks/register.tsx'; s=open(p,encoding='utf8').read()
a="""{ system: QUIZ_SYSTEM, prompt: quizPrompt(picks, cfg.level), maxTokens"""
assert s.count(a)==1; s=s.replace(a,"""{ system: build.isChangedRun ? QUIZ_SYSTEM + '\\n(MUTANT)' : QUIZ_SYSTEM, prompt: quizPrompt(picks, cfg.level), maxTokens"""); open(p,'w',encoding='utf8').write(s); print('m4 ok')
