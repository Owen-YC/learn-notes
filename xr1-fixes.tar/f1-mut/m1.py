import sys
p=sys.argv[1]+'/hooks/register.tsx'; s=open(p,encoding='utf8').read()
a="""  if (build.isRuleDrill) await recheckRemap($)
  const drill = drillOf(note.text, note.changes, build.isRuleDrill)"""
assert s.count(a)==1; s=s.replace(a,"""  const drill = drillOf(note.text, note.changes, build.isRuleDrill)"""); open(p,'w',encoding='utf8').write(s); print('m1 ok')
