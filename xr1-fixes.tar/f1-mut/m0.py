print('m0 (no mutation) ok')
