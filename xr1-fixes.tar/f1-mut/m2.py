import sys
p=sys.argv[1]+'/hooks/register.tsx'; s=open(p,encoding='utf8').read()
a="""  if (build.isRuleDrill) await recheckRemap($)
  const sent = drillOf("""
assert s.count(a)==1; s=s.replace(a,"""  const sent = drillOf("""); open(p,'w',encoding='utf8').write(s); print('m2 ok')
