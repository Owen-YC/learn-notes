#!/bin/bash
X=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/xr
for m in m1 m2 m3; do "$X/f1-mut/mk.sh" r11-$m "$X/f1-mut/$m.py" tests/flow110.test.ts & done
wait
date -u +%FT%TZ > "$X/f1-mut/r11-DONE"
