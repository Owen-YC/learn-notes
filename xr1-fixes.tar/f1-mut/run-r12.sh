#!/bin/bash
X=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/xr
"$X/f1-mut/mk.sh" r12-m0 "$X/f1-mut/m0.py" tests/run113.test.ts &
"$X/f1-mut/mk.sh" r12-m6 "$X/f1-mut/m6.py" tests/run113.test.ts &
wait
date -u +%FT%TZ > "$X/f1-mut/r12-DONE"
