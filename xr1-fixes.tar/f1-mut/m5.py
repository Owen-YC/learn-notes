import sys
p=sys.argv[1]+'/hooks/register.tsx'; s=open(p,encoding='utf8').read()
a="""{ system: QUIZ_SYSTEM, prompt: quizPrompt(picks, cfg.level), maxTokens"""
assert s.count(a)==1; s=s.replace(a,"""{ system: QUIZ_SYSTEM, prompt: quizPrompt(picks, cfg.level) + (build.isChangedRun ? '\\nMUTANT LINE' : ''), maxTokens"""); open(p,'w',encoding='utf8').write(s); print('m5 ok')
