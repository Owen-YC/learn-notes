const H = await import(process.argv[2]), N = await import(process.argv[3])
const arr = (k, per) => `const d${k} = [${Array.from({ length: per }, (_, i) => (i % 7) + 1).join(', ')}]`
for (const per of [40, 5]) {
  const lines = []
  for (let k = 0; k < 4; k++) lines.push(arr(k, per))
  lines.push('let t = 0', 'for (let i = 0; i < 10; i++) { t += 1 }', "console.log('합계:', t)")
  const text = lines.join('\n')
  const blurb = '배열 — `' + arr(0, per).slice(0, 12) + '`'
  const a = H.changedRunFor(text, 'a.js', blurb), b = N.changedRunFor(text, 'a.js', blurb)
  console.log(per, text.length, JSON.stringify(a?.out), a?.certs.map(c => c.site.token + '>' + c.value).join(' '), '|', b?.certs.map(c => c.site.token + '>' + c.value).join(' '))
}
