# usage: part.py <repo> <file> <out> <keep: comma list of old-start ranges lo-hi>  -- HEAD's file with only the -U0 hunks whose old start is in a range
import sys, subprocess, re
repo, f, out, keep = sys.argv[1:5]
ranges = [tuple(map(int, r.split('-'))) for r in keep.split(',')]
head = subprocess.run(['git', '-C', repo, 'show', f'HEAD:{f}'], capture_output=True, check=True).stdout.decode('utf8').split('\n')
diff = subprocess.run(['git', '-C', repo, '-c', 'core.quotePath=false', 'diff', '-U0', '--', f], capture_output=True, check=True).stdout.decode('utf8').split('\n')
hunks = []
cur = None
for line in diff:
    m = re.match(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', line)
    if m:
        cur = {'os': int(m[1]), 'oc': int(m[2]) if m[2] is not None else 1, 'new': []}
        hunks.append(cur)
    elif cur is not None and line.startswith('+') and not line.startswith('+++'):
        cur['new'].append(line[1:])
sel = [h for h in hunks if any(lo <= h['os'] <= hi for lo, hi in ranges)]
lines = head[:]
for h in sorted(sel, key=lambda h: -h['os']):
    start = h['os'] - 1 if h['oc'] > 0 else h['os']  # count 0: insert after line os
    lines[start:start + h['oc']] = h['new']
open(out, 'w', encoding='utf8').write('\n'.join(lines))
print(f, 'hunks', len(hunks), 'kept', len(sel))
