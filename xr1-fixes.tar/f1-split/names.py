import sys,re
out=[]
for line in open(sys.argv[1],encoding='utf8'):
    m=re.match(r'^\((pass|fail|skip)\) (.*?)(?: \[[0-9.]+m?s\])?\s*$',line)
    if m: out.append(m[1]+'\t'+m[2])
for x in sorted(out): print(x)
