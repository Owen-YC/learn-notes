#!/bin/bash
# usage: snap.sh <name> <file=src>...  -- HEAD tree + overlays, then tsc, validate, full test through the pin
X=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/xr
PIN=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/cli/pinned.sh
N="$1"; shift
D="$X/f1-split/$N"
[ -n "$N" ] && [ ! -e "$D" ] || { echo "refuse $D"; exit 2; }
mkdir -p "$D" && git -C /home/user/learn-notes archive HEAD | tar -x -C "$D"
cp -r /home/user/learn-notes/.claude-plugin/types "$D/.claude-plugin/"
ln -s /home/user/learn-notes/node_modules "$D/node_modules"
for kv in "$@"; do cp "${kv#*=}" "$D/${kv%%=*}"; done
cd "$D" || exit 1
date -u +%FT%TZ > "$D.start"
npx tsc -p . --noEmit > "$D.tsc" 2>&1; echo "tsc exit=$?" >> "$D.tsc"
$PIN claude plugin validate . > "$D.validate" 2>&1; echo "validate exit=$?" >> "$D.validate"
$PIN claude plugin test . > "$D.test" 2>&1; echo "test exit=$?" >> "$D.test"
python3 - "$D.test" > "$D.sum" <<'PY'
import sys,json
tot=fail=0; files=0
for line in open(sys.argv[1],encoding='utf8'):
    if line.startswith('claude-plugin-test-report '):
        r=json.loads(line[len('claude-plugin-test-report '):]); files+=1
        tot+=len(r['results']); f=[x for x in r['results'] if x['failure']]; fail+=len(f)
        for x in f: print('FAIL', r['file'], x['title'][-160:])
print('files',files,'tests',tot,'failed',fail)
PY
date -u +%FT%TZ > "$D.end"
