#!/bin/bash
# usage: one.sh <run name> <test file under tests/> [mutation name]   copy the repo tree (hooks, types, .claude-plugin,
# tsconfig, tests/flowkit.ts, fixtures and the one test file) to fix1/run-<name>, apply a mutation from fix1/muts.py,
# run that file through the pinned CLI; output fix1/<name>.out
X=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/xr/fix1
R=/home/user/learn-notes
N=$1; F=$2; M=$3
D="$X/run-$N"
rm -rf "${D:?}"
mkdir -p "$D/tests"
cp -r "$R/hooks" "$R/types" "$R/.claude-plugin" "$R/tsconfig.json" "$D/"
cp -r "$R/tests/fixtures" "$R/tests/flowkit.ts" "$D/tests/"
cp "$R/tests/$F" "$D/tests/"
if [ -n "$M" ]; then python3 "$X/mut.py" "$D" "$M" || exit 3; fi
cd "$D" && /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh claude plugin test . > "$X/$N.out" 2>&1
echo "$N exit=$? pass=$(grep -c '^(pass)' "$X/$N.out") fail=$(grep -c '^(fail)' "$X/$N.out")"
