"""Patch the unpacked 1.12.0 intro deck (0af3abf) for the G3 haiku retry outcome (docs step of the G3 retry).

Usage: python3 -I patch112g3.py <unpacked-dir> <changes-out.md> <modified-utc>

The engine of docs112/deck/scripts/patch112.py (exact, unique replacements; notes edits on the unescaped text of each
notes slide's single body run; slide XML untouched). Fact: docs/qa/견본.md 1.12.0 G3 '결과와 결정 (G3 다시 …)':
haiku Q1 26/30 (bar 29) -> rungNewStep Infinity; sonnet not measured.
"""
import html
import re
import sys
from pathlib import Path

ROOT = Path(sys.argv[1])
CHANGES = Path(sys.argv[2])
MODIFIED = sys.argv[3]


def esc(text: str) -> str:
    return (text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            .replace('"', '&quot;').replace("'", '&apos;'))


PROPS = [
    ('docProps/core.xml',
     re.compile(r'<dcterms:modified xsi:type="dcterms:W3CDTF">[^<]*</dcterms:modified>'),
     f'<dcterms:modified xsi:type="dcterms:W3CDTF">{MODIFIED}</dcterms:modified>',
     '문서 속성 modified를 고친 시각으로'),
]

NOTES = {
    9: [
        ('처음 보는 코드는 haiku로 재려 했지만 견본을 쓰는 단계에서 멈춰 재지 않았고, 생각해 보기는 sonnet으로',
         '처음 보는 코드는 haiku로 한 번 재었지만, 처음 보는 코드 문제 30개 가운데 판정 조건을 모두 갖춘 것이 26개로 기준인 29개에 못 미쳐 꺼 두었습니다. '
         '생각해 보기는 sonnet으로',
         '처음 보는 코드 haiku: "견본 쓰기에서 멈춰 재지 않음" → "한 번 재었고 30개 가운데 26개로 기준 29개에 못 미쳐 끔" (주인 답 뒤 다시 잰 결과)'),
        ('관문인 7개에 못 미쳐 재지 않았습니다. 풀이 보고 풀기와',
         '관문인 7개에 못 미쳐 재지 않았습니다. 풀이 보고 풀기와',
         '(확인만: 뒤 문장 그대로)'),
    ],
}

AT = re.compile(r'(<a:p><a:r><a:rPr lang="en-US" dirty="0"/><a:t>)([^<]*)(</a:t></a:r>)')


def main() -> None:
    log: list[str] = []
    pending: dict[Path, str] = {}

    def text_of(path: Path) -> str:
        if path not in pending:
            pending[path] = path.read_text(encoding='utf-8')
        return pending[path]

    for rel, rx, new, what in PROPS:
        path = ROOT / rel
        xml = text_of(path)
        n = len(rx.findall(xml))
        if n != 1:
            sys.exit(f'{rel}: expected 1 match, found {n}')
        pending[path] = rx.sub(new, xml)
        log.append(f'- {rel}: {what}')

    for num, edits in NOTES.items():
        rel = f'ppt/notesSlides/notesSlide{num}.xml'
        path = ROOT / rel
        xml = text_of(path)
        found = AT.findall(xml)
        if len(found) != 1:
            sys.exit(f'{rel}: expected one body run, found {len(found)}')
        body = html.unescape(found[0][1])
        for old, new, what in edits:
            n = body.count(old)
            if n != 1:
                sys.exit(f'{rel}: expected 1 match, found {n}: {old[:80]}')
            body = body.replace(old, new)
            if old != new:
                log.append(f'- 슬라이드 {num} 발표 대본: {what}')
        m = AT.search(xml)
        pending[path] = xml[: m.start(2)] + esc(body) + xml[m.end(2):]

    for path, xml in pending.items():
        path.write_text(xml, encoding='utf-8')
    CHANGES.write_text('\n'.join(log) + '\n', encoding='utf-8')
    print(f'{len(PROPS)} property edits, {sum(len(v) for v in NOTES.values())} notes edits, {len(pending)} files')


main()
