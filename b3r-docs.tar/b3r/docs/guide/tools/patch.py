"""learn-notes guide 1.11.0 -> 1.12.0 (G3 retry docs: p2 card item 5 says G3 haiku was measured and failed Q1 26/30): every change, by page. Run: python3 -I patch.py <tools dir> [--measure]

The source is the 1.11.0 guide as released (de98243, docs/team/learn-notes-guide.pdf), itself patched from 1.9.0 by the
1.10.0 and 1.11.0 runs' engine. Text those runs set (Pretendard / DejaVu Sans Mono as Type 0 fonts, code boxes as
vector boxes) is re-laid with the same engine and styles, so unchanged text lands where it was. Text still as Chromium
printed it (Type 3) is removed by its glyphs' boxes; where its code boxes or a reflow must go, the area is covered with
the background's own fill. Facts: hooks/notes.ts and hooks/register.tsx at HEAD (cited per change).
"""
import json, sys
sys.path.insert(0, sys.argv[1])
import pymupdf
import engine as E

MEASURE = "--measure" in sys.argv
SRC = f"{E.G}/orig/learn-notes-guide.orig.pdf"
OUT = f"{E.G}/learn-notes-guide.pdf"
doc = pymupdf.open(SRC)
MIN_XREF = doc.xref_length()   # fonts this run inserts come after every object of the 1.11.0 file
pages, changes = {}, []

def P(pno):
    if pno not in pages: pages[pno] = E.Page(doc, pno)
    return pages[pno]

def text_of(chars):
    return "".join(c["c"] for c in sorted(chars, key=lambda c: (round(c["y"]), c["x"])))

def log(pno, where, old, new):
    changes.append({"page": pno, "where": where, "old": old, "new": new})

def runs_text(runs):
    return "".join(t for t, _ in runs).replace(" ", " ")

def show(label, para, runs, width, first_width=None):
    lines = para.layout(runs, width, first_width=first_width)
    print(f"--- {label}: {len(lines)} lines")
    for l in lines: print("   |", "".join(t for t, _ in l), f"[{para._line_width(l):.1f}/{width:.1f}]")
    return lines

def nobreak_draw(para, runs, x, baselines, width, pitch=None, max_lines=None, label=""):
    """Para.draw where U+00A0 in a run keeps its two words on one line, then is set as a plain space."""
    lines = para.layout(runs, width)
    if MEASURE: show(label or f"p{para.pg.pno}", para, runs, width)
    if max_lines is not None and len(lines) > max_lines:
        raise ValueError(f"p{para.pg.pno} {label}: {len(lines)} lines > {max_lines}: {[''.join(t for t, _ in l) for l in lines]}")
    ys = list(baselines)
    while len(ys) < len(lines): ys.append(ys[-1] + pitch)
    for line, y in zip(lines, ys):
        para.draw_line(x, y, [(t.replace(" ", " "), k) for t, k in line])
    return lines, ys[:len(lines)]

# --- styles (the 1.10.0 / 1.11.0 runs'; H3 · TAG · TH measured on this file by pixels, tools/wtest.py) ---------------
INK = "#1b2a2f"
BODY = E.Style("R", 10.394, INK); BOLD = E.Style("B", 10.394, INK)
CODE = E.Code(9.146, top=8.81, bottom=3.19)
CELL = E.Style("R", 9.6, INK); CELLCODE = E.Code(8.448, top=8.07, bottom=3.18)
CARD = E.Style("R", 9.397, INK); CARDB = E.Style("B", 9.397, INK); CARDCODE = E.Code(8.27, top=8.07, bottom=3.18)
BOXT = E.Style("R", 9.6, "#33464b"); BOXB = E.Style("B", 9.6, "#33464b")
TITLE_ORANGE = E.Style("B", 8.999, "#a8650b", 0.48, False)
FOOT = E.Style("M", 8.497, "#8a9a9e")
DARK = E.Code(8.999, color="#d6ddd6", box=None, mono="MONO", fallback="WQY")
PATH = E.Code(9.149, color=INK, box=None); PATH.pad = 0.0; PATH.base_shift = 0.0   # p17's docs/qa/견본.md: mono, no box
H3 = E.Style("B", 12.494, "#0f3d3e"); TAG = E.Style("SB", 8.497, "#2e8b6e")
TH = E.Style("B", 9.599, "#0f3d3e"); TD = E.Style("R", 9.599, INK)
WHITE, CARD_BG, MINT, ORANGE_BG = "#ffffff", "#fdf3e2", "#eef4f1", "#fdf3e2"

# =================================================================================================
# Running footers p2-p35: "learn-notes 안내서 · v1.11.0" -> v1.12.0
for pno in range(2, 36):
    pg = P(pno)
    cs = [c for c in pg.chars(base=816.8, tol=0.5) if c["x"] < 300]
    assert text_of(cs) == "learn-notes 안내서 · v1.11.0", (pno, text_of(cs))
    pg.redact_chars(cs)
    pg.put(cs[0]["x"], cs[0]["y"], "learn-notes 안내서 · v1.12.0", FOOT)
log("2-35", "running footer (34 pages)", "learn-notes 안내서 · v1.11.0", "learn-notes 안내서 · v1.12.0")

# =================================================================================================
# p1 cover pills: 버전 1.11.0 -> 버전 1.12.0 (pill 1 grows by the digit's width, the other two move right by it);
# 2026년 11월 stays (the release month). The pills are the 1.11.0 run's strokes (the last three drawn): covered with
# the page's own fill there, as the earlier runs did, and drawn again.
pg = P(1)
PILL = E.Style("R", 8.999, "#e6f1ec")
row = pg.chars(base=335.23, tol=0.4)
p1t = [c for c in row if c["x"] < 120]; p2t = [c for c in row if 120 < c["x"] < 200]; p3t = [c for c in row if c["x"] > 200]
assert text_of(p1t) == "버전 1.11.0" and text_of(p2t) == "2026년 11월" and text_of(p3t) == "github.com/Owen-YC/learn-notes", [text_of(p1t), text_of(p2t), text_of(p3t)]
w = lambda s: sum(E.advances(s, "R", 8.999))
d1 = w("버전 1.12.0") - w("버전 1.11.0")
strokes = [d["rect"] for d in pg.page.get_drawings() if d.get("color") == (1.0, 1.0, 1.0) and 315 < d["rect"].y0 < 350]
pills = [(r.x0, r.x1) for r in strokes[-3:]]   # the 1.11.0 run's, drawn last
assert [round(a, 2) for a, _ in pills] == [57.37, 127.12, 205.86] and [round(b, 2) for _, b in pills] == [118.12, 196.11, 367.10], pills
for x0, x1 in pills: pg.redact(pymupdf.Rect(x0 - 0.6, 320.7, x1 + 0.6, 344.5), "#0f3d3e")
new_pills = [(pills[0][0], pills[0][1] + d1), (pills[1][0] + d1, pills[1][1] + d1), (pills[2][0] + d1, pills[2][1] + d1)]
for x0, x1 in new_pills: pg.stroke((x0, 321.35, x1, 343.85), "#ffffff", 0.75, 0.2784, radius=11.25)
pg.put(p1t[0]["x"], 335.23, "버전 1.12.0", PILL)
pg.put(p2t[0]["x"] + d1, 335.23, "2026년 11월", PILL)
for c in p3t:   # unchanged text, moved: its own glyph offsets kept
    pg.glyphs.append((c["x"] + d1, c["y"], c["c"], "R", 8.999, "#e6f1ec"))
log(1, "cover pills", "버전 1.11.0 | 2026년 11월", f"버전 1.12.0 | 2026년 11월 (pill 1 {d1:.2f} pt wider; date and github pills {d1:.2f} pt right)")

# =================================================================================================
# p2 card "1.11.0에서 달라진 것" -> "1.12.0에서 달라진 것". Same box, heading style, dots and six 2-line slots.
# Facts: MODEL_SWITCHES (notes.ts 10327: haiku isRuleWide + rungChangedStep 2, sonnet isRuleWide), rungOf/isChangedShaped/
# codeFor (16 lines, 700 chars, whole created .js/.py file), remapState (register.tsx 748: CLAUDE_CODE_USE_GATEWAY),
# docs/qa/견본.md 1.12.0 (18/20, 0 wrong; the other cells' outcomes).
pg = P(2)
title = pg.chars(base=664.46, tol=0.3)
old_title = text_of(title)
assert old_title == "1.11.0에서 달라진 것 · 새 키 · 새 명령 · 새 설정 없음", old_title
pg.redact_chars(title)
pg.put(60.75, 664.46, "1.12.0에서 달라진 것 · 새 키 · 새 명령 · 새 설정 없음", TITLE_ORANGE)
old_items = []
for b0, b1 in [(683.96, 698.95), (716.2, 730.45), (747.7, 762.7)]:
    for x0, x1 in [(70, 300), (309, 545)]:
        cs = [c for c in pg.chars(y0=b0 - 0.6, y1=b1 + 0.3) if x0 <= c["x"] <= x1]
        old_items.append(text_of(cs))
        pg.redact(pymupdf.Rect(x0 + 1.5, b0 - 9.2, x1 - 1.0, b1 + 3.6), CARD_BG)   # the old code boxes go too
old_items = [old_items[k] for k in (0, 2, 4, 1, 3, 5)]   # column order, as the card reads
card = E.Para(pg, CARD, bold=CARDB, code=CARDCODE)
items = [
    (73.5, (683.96, 698.95), [("비슷한 코드", "b"), ("를 haiku · beginner 창에서 켭니다. 7일 간격부터 내 코드의 한 곳을 바꿔 묻습니다(6장).", "t")]),
    (73.5, (716.2, 730.45), [("Claude가 새로 만든 작은 .js · .py 파일 가운데 조건(6장)에 맞는 것에서 만난 개념만이고, 그 밖은 내 코드로 묻습니다.", "t")]),
    (73.5, (747.7, 762.7), [("haiku로 잰 20자리 중 18자리가 기준을 갖췄고 틀린 정답은 없었습니다. sonnet은 재지 않아 끕니다.", "t")]),
    (312.6, (683.96, 698.95), [("팀 규칙 연습", "b"), ("은 haiku · sonnet 모두 기준 한 줄씩을 못 넘어 끕니다. 표지 넓힘은 두 모델 모두(beginner) 켭니다.", "t")]),
    (312.6, (716.2, 730.45), [("처음 보는 코드(haiku)는 쟀지만 26/30(기준 29)에 그쳤고, 생각해\u00a0보기(sonnet)는 관문에서 멈춰 두 모델 모두 끕니다.", "t")]),
    (312.6, (747.7, 762.7), [("풀이 보고 풀기 · 바탕 개념은 재지 않아 끕니다. 별칭 · 제공자처럼 게이트웨이 스위치를 둔 창도 모두 끕니다(9장).", "t")]),
]
for x, ys, runs in items:
    if MEASURE: show(f"p2 card {x} {ys[0]}", card, runs, 220.6)
    nobreak_draw(card, runs, x, list(ys), 220.6, max_lines=2, label=f"p2 card {x} {ys[0]}")
log(2, "card heading", old_title, "1.12.0에서 달라진 것 · 새 키 · 새 명령 · 새 설정 없음")
log(2, "card bullets (6, same boxes and dots; left column top to bottom, then right)", " // ".join(old_items), " // ".join(runs_text(r) for _, _, r in items))

# =================================================================================================
# p12 문제는 세 가지 유형, its second line: the title's 비슷한 코드 is a haiku · beginner window's from 1.12.0 (rungName,
# register.tsx 4867; RUNG_LABEL notes.ts), 풀이 보고 풀기 still only a 1.8.0 window's (workedAfterTimes off in both rows).
pg = P(12)
line = sorted(pg.chars(y0=277.2, y1=278.3), key=lambda c: c["x"])
old_text = "".join(c["c"] for c in line)
assert old_text.startswith("(10장)도 붙습니다. 1.8.0 창이 만든 퀴즈라면") and old_text.endswith("도 보입니다(이 장 끝)."), old_text
pg.redact(pymupdf.Rect(46.0, 266.2, 549.0, 281.6), WHITE)   # Chromium's code boxes on this line go too
para = E.Para(pg, BODY, bold=BOLD, code=CODE)
p12 = [("(10장)도 붙습니다. haiku · beginner 창은 ", "t"), ("· 비슷한 코드", "c"), (", 1.8.0 창의 퀴즈는 ", "t"), ("· 풀이 보고 풀기", "c"), ("도 보입니다(이 장 끝).", "t")]
nobreak_draw(para, p12, 48.0, [277.48], 499.4, max_lines=1, label="p12 line 2")
log(12, "문제는 세 가지 유형, line 2", old_text, runs_text(p12))

# =================================================================================================
# p16 the box heading and its paragraph: 1.12.0 asks code changed in a haiku · beginner window from step 2 (7일)
pg = P(16)
head = sorted(pg.chars(base=686.21, tol=0.3), key=lambda c: c["x"])
old_head = text_of(head)
assert old_head == "1.9.0은 늘 내 코드로 묻습니다 1.8.0의 비슷한 코드 · 풀이 보고 풀기는 끔", old_head
h = [c for c in head if c["size"] > 12]; t = [c for c in head if c["size"] < 12]
gap = t[0]["x"] - (h[0]["x"] + sum(E.advances("".join(c["c"] for c in h), "B", 12.494)))
pg.redact_chars(head)
new_h, new_t = "복습 문제는 내 코드로 묻습니다", "1.12.0 · haiku 창은 비슷한 코드도"
end = pg.put(48.0, 686.21, new_h, H3)
pg.put(end + gap, 686.21, new_t, TAG)
log(16, "heading", old_head, f"{new_h} {new_t}")
old = pg.chars(y0=709.0, y1=762.5)
old_text = text_of(old)
assert old_text.startswith("복습 문제는 복습 단계와 상관없이") and old_text.endswith("팀 노트로 묻습니다(10장)."), old_text
pg.redact_chars(old)
p16 = [("복습 문제는 복습 단계와 상관없이(1일부터 60일 간격, 졸업 복습까지) 노트의 내 코드를 그대로 보여 주고 묻고, 제목에 따로 붙는 말이 없습니다. 1.12.0부터 haiku · beginner 창은 7일 간격부터 ", "t"),
       ("비슷한 코드", "b"), ("로도 묻습니다(다음 쪽). 헷갈린 개념은 다음 퀴즈에서 ", "t"), ("다시 도전", "b"),
       ("으로, 다른 코드나 값으로 묻습니다. 같은 곳을 두 번 연달아 헷갈려도 풀이 없이 다시 도전입니다. 노트에 코드가 없는 개념은 \"왜\"로 묻고, 팀 용어는 팀 코드 · 팀 노트로 묻습니다(10장).", "t")]
para = E.Para(pg, BODY, bold=BOLD, code=CODE)
nobreak_draw(para, p16, 48.0, [709.45, 727.45, 744.7, 761.95], 499.4, pitch=17.25, max_lines=5, label="p16 paragraph")
log(16, "paragraph under the heading", old_text, runs_text(p16))

# =================================================================================================
# p17 the 1.8.0 / 1.9.0 table: the right column is from 1.9.0 on (header), its first row names the haiku window;
# the orange box '왜 껐나요' becomes what 1.12.0 turned on, for which window, in what scope, measured how.
pg = P(17)
hd = [c for c in pg.chars(base=67.5, tol=0.3) if c["x"] > 400]
assert text_of(hd) == "1.9.0", text_of(hd)
pg.redact_chars(hd)
pg.put(hd[0]["x"], 67.5, "1.9.0부터", TH)
log(17, "table header, right column", "1.9.0", "1.9.0부터")
c1 = [c for c in pg.chars(base=96.0, tol=0.3) if c["x"] > 400]
assert text_of(c1) == "내 코드", text_of(c1)
pg.redact_chars(c1)
end = pg.put(c1[0]["x"], 96.0, "내 코드(haiku 창은 아래)", TD)
assert end < 538.0, end
log(17, "table row 7일 간격부터, right column", "내 코드", "내 코드(haiku 창은 아래)")
tt = pg.chars(base=168.74, tol=0.3)
assert text_of(tt) == "왜 껐나요", text_of(tt)
body = pg.chars(y0=188.5, y1=260.0)
old_text = text_of(tt) + " | " + text_of(body)
pg.redact_chars(tt); pg.redact_chars(body)
new_title = "haiku 창의 비슷한 코드 · 1.12.0"
pg.put(62.17, 168.74, new_title, TITLE_ORANGE)
p17 = [("haiku · beginner 창은 7일 간격부터, Claude가 새로 만든 작은 .js · .py 파일(16줄 · 700자 안, 출력 줄 1~4개, import 없음 등)에서 만난 개념을 그 파일의 한 곳을 바꾼 코드로 묻습니다. 팀 용어가 없는 세 문제 퀴즈에서만 묻고, 힌트는 바뀐 줄을 짚습니다. 코드는 플러그인이 바꾸지만 출력의 정답은 모델이 씁니다. haiku로 잰 20자리 중 18자리가 기준을 다 갖췄고 틀린 정답은 없어 켰습니다. sonnet은 재지 않아 끕니다. 대화창에서 숫자로 시작하는 답은 문제 번호인지 알 수 없으면 되묻습니다. 1.9.0이 두 칸을 끈 까닭과 잰 숫자는 ", "t"), ("docs/qa/견본.md", "c"), ("에 있습니다.", "t")]
para = E.Para(pg, BODY, bold=BOLD, code=PATH)
nobreak_draw(para, p17, 62.17, [188.99, 206.99, 224.24, 241.49, 259.49], 533.29 - 62.17, max_lines=5, label="p17 orange box")
log(17, "orange box (was '왜 껐나요')", old_text, new_title + " | " + runs_text(p17))

# =================================================================================================
# p20 /learn 도움말 row: learn-notes 1.11.0 명령 -> 1.12.0 (DejaVu Sans Mono: one glyph, same advance)
pg = P(20)
code = sorted([c for c in pg.chars(base=425.03, tol=0.08) if c["x"] > 318], key=lambda c: c["x"])
close = [c for c in pg.chars(base=425.22, tol=0.1) if c["c"] == ")" and c["x"] > 430]
assert "".join(c["c"] for c in code) == "learn-notes 1.11.0 명령" and len(close) == 1, ("".join(c["c"] for c in code), close)
pg.redact_chars(code); pg.redact_chars(close)   # fill None: the code box (same width) stays
pg.put_code_text(code[0]["x"], code[0]["y"], "learn-notes 1.12.0 명령", CELLCODE)
pg.put(close[0]["x"], close[0]["y"], ")", CELL)
log(20, "table row /learn 도움말", "첫 줄에 버전이 나옵니다( learn-notes 1.11.0 명령)", "첫 줄에 버전이 나옵니다( learn-notes 1.12.0 명령)")

# =================================================================================================
# p21: the note under the settings table; the callout's body (비슷한 코드 haiku; seven switches with the gateway's)
pg = P(21)
old = pg.chars(y0=607.9, y1=625.8)
old_text = text_of(old)
assert old_text.startswith("1.11.0에서도 새로 생긴 설정과 키는 없습니다."), old_text
for b in (608.21, 625.46): pg.redact_chars([c for c in old if abs(c["y"] - b) < 0.4])
para = E.Para(pg, BODY, bold=BOLD, code=CODE)
p21 = [("1.12.0에서도 새로 생긴 설정과 키는 없습니다. 노트 아래 \"지난번 헷갈린 개념\" 줄, 아래의 자동 다시 쓰기, 계정 한도 양보, 되묻기는 따로 끄는 설정 없이 동작합니다.", "t")]
para.draw(p21, 48.0, [608.21, 625.46], 499.4, max_lines=2)
log(21, "paragraph under the settings table", old_text, runs_text(p21))
old = pg.chars(y0=688.0, y1=758.0)
old_text = text_of(old)
assert old_text.startswith("팀 규칙 표지 넓힘(10장)은") and old_text.endswith("보내지 않습니다."), old_text
pg.redact(pymupdf.Rect(56.0, 677.0, 540.0, 761.5), MINT)   # the callout's code boxes move
p21c = [("팀 규칙 표지 넓힘(10장)은 ", "t"), ("model", "c"), ("이 haiku · sonnet, 비슷한 코드(6장)는 haiku이고 ", "t"), ("level", "c"),
        ("이 beginner인 창에서만 켜집니다. 셸이나 설정 파일 ", "t"), ("env", "c"),
        ("에 그 모델의 별칭 변수(", "t"), ("ANTHROPIC_DEFAULT_HAIKU_MODEL", "c"), (" · ", "t"), ("…_SONNET_MODEL", "c"), (")나 제공자 스위치(", "t"),
        ("CLAUDE_CODE_USE_BEDROCK", "c"), (" · ", "t"), ("…_GATEWAY", "c"), (" 등 일곱)가 비어 있지 않거나, ", "t"), ("modelOverrides", "c"),
        ("가 비어 있지 않으면 모델별 기능을 끕니다(11장, 호스트가 제공자를 관리하는 클라우드 세션의 설정 파일 env와 회사 관리 설정은 빼고). 로그인만으로 켠 게이트웨이는 알아채지 못합니다.", "t")]
nobreak_draw(para, p21c, 62.17, [688.74 + 17.25 * k for k in range(5)], 533.29 - 62.17, max_lines=5, label="p21 callout")
log(21, "callout model · level과 모델별 기능, its body", old_text, runs_text(p21c))

# =================================================================================================
# p22: 얼마나 썼는지 box (its last paragraph) and 무엇이 어디로 가나요 (from its 3rd line)
# Facts: no new call kind; the quiz prompt of a haiku window with code changed is the one new text sent
# (RUNG_ASK 'changed', siteLines; QUIZ_TRACE_TOKENS 4600 register.tsx); remapState reads CLAUDE_CODE_USE_GATEWAY.
pg = P(22)
old = [c for c in pg.chars(y0=327.0, y1=343.5) if c["x"] > 310]
old_text = text_of(old)
assert old_text == "1.10.0 · 1.11.0도 새 모델 호출 · 모델에게 가는 새 문장이없습니다. 넓힌 노트(10장)는 t 확인 호출도 없습니다.", old_text
for b in (327.48, 342.98): pg.redact_chars([c for c in old if abs(c["y"] - b) < 0.6])
para = E.Para(pg, BOXT, bold=BOXB, code=CELLCODE)
p22a = [("1.12.0", "b"), ("도 새 모델 호출은 없습니다. 새 문장은 haiku 창의 비슷한 코드 퀴즈뿐이고 상한은 4,600토큰입니다.", "t")]
if MEASURE: show("p22 box", para, p22a, 218.0)
para.draw(p22a, 315.47, [327.48, 342.98], 218.0, max_lines=2)
log(22, "box 얼마나 썼는지, its last paragraph", old_text, runs_text(p22a))
old = pg.chars(y0=553.9, y1=677.0)
old_text = text_of(old)
assert old_text.startswith("모두 비밀값을 가린 뒤 보냅니다. 1.11.0에서 새로 나가거나 읽는 것은 없습니다.") and old_text.endswith("기본으로 동작합니다."), old_text
pg.redact(pymupdf.Rect(46.0, 544.6, 549.0, 680.6), WHITE)   # the code boxes move
para = E.Para(pg, BODY, bold=BOLD, code=CODE)
p22b = [("모두 비밀값을 가린 뒤 보냅니다. 1.12.0에서 새로 나가는 것은 haiku · beginner 창의 비슷한 코드 퀴즈 요청(내 코드 칸이 싣던 그 파일과 바꿀 수 있는 곳 목록)이고, 새로 읽는 것은 게이트웨이 스위치가 비었는지뿐입니다. 1.10.0에서 새로 나가는 것은 ", "t"), ("/learn 진단", "c"),
        ("을 칠 때 대화창에 적히는 모델별 기능 갈래(켠 기능 이름이나 끈 까닭)뿐입니다. 그 갈래를 정하려고 haiku · sonnet, beginner 창은 별칭 변수 · 제공자 스위치와 설정의 ", "t"),
        ("modelOverrides", "c"), ("가 비었는지만 보고, 값은 남기거나 보이거나 보내지 않습니다(9장). 1.9.0부터 퀴즈 호출에는 두 번 연달아 막힌 개념의 내 코드가 1.8.0의 언어 이름 대신 1.7처럼 다시 실립니다(다른 복습 문제에 싣던 것과 같은 코드). 리더의 보고서 모으기는 적은 파일 하나를 읽지만 모델에 보내지 않고, 만든 지도도 어디에도 저장하지 않습니다(10장). 다만 복사할 수 없는 화면에서 대화창에 적은 지도는 다른 ", "t"),
        ("/learn", "c"), (" 답처럼 메인 Claude도 읽습니다(사람별 줄 · 사람 이름 · 코드 없음). 노트 · 일지 · 기록은 내 컴퓨터에만 저장됩니다. 설정 없이도 아래 두 가지가 기본으로 동작합니다.", "t")]
nobreak_draw(para, p22b, 48.0, [554.22, 572.21, 589.46, 606.71, 624.71, 641.96, 659.21], 499.4, pitch=17.25, max_lines=9, label="p22 무엇이 어디로")
log(22, "무엇이 어디로 가나요 (reflowed from its 3rd line, '모두 비밀값을…')", old_text, runs_text(p22b))

# =================================================================================================
# p24 callout 팀 규칙 표지 넓힘: its last two lines ("1.10.0 · 1.11.0이 그렇게 저장한 노트" -> "1.10.0~1.12.0이 …")
pg = P(24)
l5 = pg.chars(base=736.24, tol=0.3); l6 = pg.chars(base=753.49, tol=0.3)
old_text = text_of(l5) + " " + text_of(l6)
assert old_text == "달라지지 않습니다. 다른 창(9장), 지난 노트, 옛 창(1.5~1.9)이 쓰는 노트는 넓히지 않고, 1.10.0 · 1.11.0이 그렇게 저장한 노트는 1.9.0 창에서도 직접 해 보기가 없고 1.7 · 1.8 창에서는 할 일 · 확인만 보입니다.", old_text
pg.redact_chars(l5); pg.redact_chars(l6)
para = E.Para(pg, BODY, bold=BOLD, code=CODE)
p24 = [("달라지지 않습니다. 다른 창(9장), 지난 노트, 옛 창(1.5~1.9)이 쓰는 노트는 넓히지 않고, 1.10.0~1.12.0이 그렇게 저장한 노트는 1.9.0 창에서도 직접 해 보기가 없고 1.7 · 1.8 창에서는 할 일 · 확인만 보입니다.", "t")]
para.draw(p24, 62.17, [736.24, 753.49], 533.29 - 62.17, max_lines=2)
log(24, "callout 팀 규칙 표지 넓힘, its last two lines", old_text, runs_text(p24))

# =================================================================================================
# p30 진단 sample: version line (1.12.0 · 2.1.323) and the settings line (routeText: both features of haiku's row,
# FEATURE_NAMES in SWITCH_KINDS' order: 팀 규칙 표지 넓힘 · 비슷한 코드)
pg = P(30)
v = pg.chars(base=142.49, tol=0.3)
s = text_of(v)
assert s == "- 버전: learn-notes 1.11.0 · Claude Code 2.1.318", s
pg.redact_chars(v)
pg.put_code_text(60.75, 142.49, "- 버전: learn-notes 1.12.0 · Claude Code 2.1.323", DARK)
log(30, "진단 sample, 버전 line", s, "- 버전: learn-notes 1.12.0 · Claude Code 2.1.323")
sl = pg.chars(y0=185.7, y1=200.5)
old_s = text_of(sl)
assert old_s.startswith("- 설정: 자동 노트 켬 · haiku(이 모델에서 켠 기능: 팀 규칙 표지 넓힘)"), old_s
for b in (185.99, 200.24): pg.redact_chars([c for c in sl if abs(c["y"] - b) < 0.4])
words = "- 설정: 자동 노트 켬 · haiku(이 모델에서 켠 기능: 팀 규칙 표지 넓힘 · 비슷한 코드) · 하루 한도 없음 · 일지 켬(기본 폴더) · 패널 자동 열기 켬 · 설명 수준 beginner".split(" ")
lines, cur = [], ""
for wd in words:
    t_ = (cur + " " + wd) if cur else wd
    if cur and 60.75 + pg.code_width(t_, DARK) > 534.75: lines.append(cur); cur = wd
    else: cur = t_
lines.append(cur)
assert len(lines) == 2, lines
for y, t_ in zip((185.99, 200.24), lines): pg.put_code_text(60.75, y, t_, DARK)
log(30, "진단 sample, 설정 line (2 lines)", old_s, " / ".join(lines))

# =================================================================================================
# p32: reload notice sample, schema sentence's second line, callout on what turns the model features off
pg = P(32)
l2 = pg.chars(y0=570.0, y1=571.0); l3 = pg.chars(y0=587.5, y1=588.3)
old_text = text_of(l2) + text_of(l3)
assert old_text.startswith("learn-notes 새 버전(1.11.0)이 다른 창에서 쓰이고 있습니다 · 이 창은 1.10.0입니다"), old_text
pg.redact(pymupdf.Rect(46.0, 561.0, 549.0, 592.2), WHITE)   # the code boxes change
para = E.Para(pg, BODY, bold=BOLD, code=CODE)
p32a = [("learn-notes 새 버전(1.12.0)이 다른 창에서 쓰이고 있습니다 · 이 창은 1.11.0입니다 · /reload-plugins로 바꿉니다", "c"),
        (". 그 창에서 ", "t"), ("/reload-plugins", "c"), ("를 입력하면 됩니다.", "t")]
para.draw(p32a, 48.0, [570.71, 587.96], 499.4, max_lines=2)
log(32, "옛 창에 다시 불러오기 알림, sample line", old_text, runs_text(p32a))
b = pg.chars(base=647.96, tol=0.3)
old_text = text_of(b)
assert old_text.startswith("1.11.0까지 저장 구조를 바꾸지 않습니다(3 그대로)."), old_text   # STORE_SCHEMA 3 (notes.ts 10650)
pg.redact_chars(b)
p32b = "1.12.0까지 저장 구조를 바꾸지 않습니다(3 그대로). 1.6.x 창에는 이 알림이 없으니, 1.6.x에서 올릴 때는 열려 있던 창마다"
end = pg.put(48.0, 647.96, p32b, BODY)
assert end <= 547.4, end
log(32, "schema sentence, its second line ('1.8.0부터' ends the line above)", old_text, p32b)
old = pg.chars(y0=728.0, y1=764.0)
old_text = text_of(old)
assert old_text.startswith("진단의 모델 뒤 괄호가 까닭을 말합니다") and old_text.endswith("다시 확인)."), old_text
pg.redact(pymupdf.Rect(56.0, 717.0, 540.0, 767.0), MINT)   # the modelOverrides box moves
p32c = [("진단의 모델 뒤 괄호가 까닭을 말합니다: 설명 수준이 beginner가 아님 · 별칭 변수를 둠 · 제공자 변수를 둠(게이트웨이 포함) · ", "t"), ("modelOverrides", "c"),
        (" 설정을 둠 · 별칭을 확인하지 못함(9장). 세션 도중 그런 값이 생기면 진단 · 표지를 넓힐 노트 · haiku 창의 퀴즈 앞에서 알아채 끄고, 저절로 다시 켜지 않습니다(Claude Code를 다시 켜면 다시 확인).", "t")]
nobreak_draw(para, p32c, 62.17, [728.74, 745.99, 763.24], 533.29 - 62.17, max_lines=3, label="p32 callout")
log(32, "callout 모델별 기능이 꺼지는 창, its body", old_text, runs_text(p32c))

# =================================================================================================
# p33 box 팀의 창이 모두 1.9.0 이상이 되었는지 볼 때: 1.11.0도 사본 쓰기를 멈추지 않습니다 -> 1.12.0도
pg = P(33)
line = sorted(pg.chars(base=760.45, tol=0.3), key=lambda c: c["x"])
s = text_of(line)
k = s.rindex("1.11.0도")
tail = line[k:]
assert text_of(tail) == "1.11.0도 사본 쓰기를 멈추지 않습니다.", text_of(tail)
pg.redact_chars(tail)
end = pg.put(tail[0]["x"], 760.45, "1.12.0도 사본 쓰기를 멈추지 않습니다.", BODY)
assert end < 533.3, end
log(33, "box 팀의 창이 모두 1.9.0 이상이 되었는지 볼 때, its last sentence", "1.11.0도 사본 쓰기를 멈추지 않습니다.", "1.12.0도 사본 쓰기를 멈추지 않습니다.")

# =================================================================================================
# p35: 업데이트 line's code; 옛 판에서 올라온 분께: first bullet, the 1.8 bullet (reflowed), open-windows bullet line 1
pg = P(35)
code = sorted([c for c in pg.chars(y0=80.3, y1=80.7) if c["x"] > 320], key=lambda c: c["x"])
tail = sorted([c for c in pg.chars(y0=80.75, y1=80.9) if c["x"] > code[-1]["x"]], key=lambda c: c["x"])
assert "".join(c["c"] for c in code) == "learn-notes 1.11.0 명령", "".join(c["c"] for c in code)
assert "".join(c["c"] for c in tail) == ")로 판을 확인합니다.", "".join(c["c"] for c in tail)
pg.redact_chars(code); pg.redact_chars(tail)   # fill None: the code box (same width) stays
pg.put_code_text(code[0]["x"], code[0]["y"], "learn-notes 1.12.0 명령", CODE)
end = pg.put(tail[0]["x"], tail[0]["y"], ")로 판을 확인합니다.", BODY)
assert end < 547.0, end
log(35, "업데이트 paragraph", "( learn-notes 1.11.0 명령 )로 판을 확인합니다.", "( learn-notes 1.12.0 명령 )로 판을 확인합니다.")
first = pg.chars(base=140.25, tol=0.3)
old_text = text_of(first)
assert old_text == "1.9 · 1.10에서: 키 · 명령 · 설정은 그대로입니다. 1.9에서는 표지 넓힘(10장) · 진단 괄호(11장)가 새로 생깁니다.", old_text
pg.redact_chars(first)
para = E.Para(pg, BODY, bold=BOLD, code=CODE)
p35n = [("1.9~1.11에서", "b"), (": 키 · 명령 · 설정은 그대로이고, 새것은 2쪽 카드와 표지 넓힘 · 진단 괄호(1.9에서, 10 · 11장)입니다.", "t")]
nobreak_draw(para, p35n, 74.92, [140.25], 533.3 - 74.92, max_lines=1, label="p35 first bullet")
log(35, "옛 판에서 올라온 분께, first bullet", old_text, runs_text(p35n))
b18 = pg.chars(y0=159.0, y1=230.0)
old_text = text_of(b18)
assert old_text.startswith("1.8에서: 키 · 명령 · 설정은 그대로입니다. 1.8.0의 비슷한 코드와") and old_text.endswith("붙습니다(11장)."), old_text
pg.redact(pymupdf.Rect(73.0, 148.6, 541.0, 233.4), MINT)   # Chromium's code boxes in this bullet move
p35b = [("1.8에서", "b"), (": 키 · 명령 · 설정은 그대로입니다. 1.8.0의 비슷한 코드와 풀이 보고 풀기를 껐습니다. 7일 간격부터의 복습도 내 코드로(1.12.0 haiku 창은 범위 안이면 비슷한 코드, 6장), 두 번 연달아 헷갈린 개념도 다시 도전으로 묻고, 채점 아래에 ", "t"),
        ("다음 복습 퀴즈는 풀이부터 보여 줍니다", "c"), ("가 붙지 않습니다. 1.8.0 창이 만들어 둔 두 칸의 문제는 그대로 풀면 되고, 채점과 복습 단계는 같습니다(6장). 노트 끝이 잘리던 일이 줄었습니다(9장). ", "t"),
        ("/learn 진단", "c"), ("의 저장소 줄 끝에 ", "t"), ("옛 판 창의 개념 모음 쓰기", "c"), ("가 붙습니다(11장).", "t")]
nobreak_draw(para, p35b, 74.92, [159.75, 176.99, 194.24, 211.49, 229.49], 533.3 - 74.92, max_lines=5, label="p35 1.8 bullet")
log(35, "옛 판에서 올라온 분께, 1.8 bullet (reflowed)", old_text, runs_text(p35b))
ow = pg.chars(y0=431.5, y1=432.3)
old_text = text_of(ow)
assert old_text.startswith("열려 있던 1.7~1.10 창에는") and old_text.endswith("그 전에도"), old_text
pg.redact(pymupdf.Rect(73.5, 422.1, 541.0, 435.7), MINT)   # the /reload-plugins box moves right
end = para.draw_line(74.92, 431.98, [("열려 있던 1.7~1.11 창에는 다시 불러오기 알림이 뜹니다. 그 창에서 ", "t"), ("/reload-plugins", "c"), ("를 입력하세요. 그 전에도", "t")])
assert end <= 533.3, end
log(35, "옛 판에서 올라온 분께, open-windows bullet, line 1", old_text, "열려 있던 1.7~1.11 창에는 다시 불러오기 알림이 뜹니다. 그 창에서 /reload-plugins를 입력하세요. 그 전에도")

# =================================================================================================
# p36 quick reference footer
pg = P(36)
line = sorted(pg.chars(base=802.45, tol=0.3), key=lambda c: c["x"])
k = text_of(line).index("learn-notes 1.11.0")
tail = line[k:]
col = f"#{tail[0]['color']:06x}"
assert len(set(c["color"] for c in tail)) == 1 and text_of(tail) == "learn-notes 1.11.0 · MIT 라이선스", text_of(tail)
pg.redact_chars(tail)
end = pg.put(tail[0]["x"], 802.45, "learn-notes 1.12.0 · MIT 라이선스", E.Style("R", tail[0]["size"], col))
log(36, "quick reference footer", "learn-notes 1.11.0 · MIT 라이선스", "learn-notes 1.12.0 · MIT 라이선스")

# =================================================================================================
if __name__ == "__main__" and not MEASURE:
    fonts = E.Fonts(); fonts.build(pages.values())
    E.apply(doc, list(pages.values()), fonts)
    fixed = E.fix_widths(doc, fonts, min_xref=MIN_XREF)
    print('W rewritten:', {k: (v[0], v[1]) for k, v in fixed.items()})
    doc.save(OUT, garbage=4, deflate=True)
    with open(f"{E.G}/changes.json", "w") as f: json.dump(changes, f, ensure_ascii=False, indent=1)
    print("saved", OUT, "pages", doc.page_count, "changed pages", sorted(pages))
