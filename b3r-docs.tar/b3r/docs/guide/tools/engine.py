"""Patch engine for the learn-notes guide PDF (1.10.0 run; 1.11.0 run: fix_widths limited to this run's fonts) (Chromium/Skia print, Pretendard as Type 3 subsets).

Layout model, checked against the original glyph origins (0.01 pt): Pretendard text is shaped with HarfBuzz
(kerning on) and every glyph advance is rounded to whole CSS px (0.75 pt), plus the CSS letter-spacing in px;
titles carry letter-spacing 0.48 px and no kerning. DejaVu Sans Mono (code) and WenQuanYi Zen Hei (Korean in
dark code blocks) keep their unrounded advances. Inline code: 0.88 em, #1d5a49 on a #e7eeeb rounded box, the code
text starting 3.4 pt after the text before it and the text after it starting 3.4 pt after the code.
"""
import io, os
import pymupdf
import uharfbuzz as hb
from fontTools import subset as ftsubset
from fontTools.ttLib import TTFont

G = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3r/docs/guide"
FONT_FILES = {
    "R": (f"{G}/fonts/Pretendard-Regular.ttf", 0), "M": (f"{G}/fonts/Pretendard-Medium.ttf", 0),
    "SB": (f"{G}/fonts/Pretendard-SemiBold.ttf", 0), "B": (f"{G}/fonts/Pretendard-Bold.ttf", 0),
    "XB": (f"{G}/fonts/Pretendard-ExtraBold.ttf", 0),
    "MONO": ("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 0),
    "WQY": ("/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc", 0),
}
PRETENDARD = {"R", "M", "SB", "B", "XB"}

def rgb(h):
    """A hex color as Chromium/Skia writes it: each channel /255 rounded to 4 decimals (`.0588 .2392 .2431 rg`),
    so a fill renders exactly like the page's own."""
    h = h.lstrip("#"); return tuple(round(int(h[i:i + 2], 16) / 255, 4) for i in (0, 2, 4))

_hb = {}
def hbfont(key):
    if key not in _hb:
        path, idx = FONT_FILES[key]
        face = hb.Face(hb.Blob.from_file_path(path), idx)
        _hb[key] = (hb.Font(face), face.upem)
    return _hb[key]

_cmap = {}
def has_glyph(key, ch):
    if key not in _cmap:
        path, idx = FONT_FILES[key]
        _cmap[key] = set(TTFont(path, fontNumber=idx, lazy=True).getBestCmap().keys())
    return ord(ch) in _cmap[key]

def advances(text, key, size, kern=True, letter_px=0.0):
    """Advance (pt) of each char of text in font key at size pt, Chromium-like: shaped word by word (no kerning
    across a space), each Pretendard advance rounded to whole px."""
    out, i = [], 0
    while i < len(text):
        j = i + 1
        if text[i] != " ":
            while j < len(text) and text[j] != " ": j += 1
        out += _advances(text[i:j], key, size, kern, letter_px)
        i = j
    return out

def _shape(text, key, kern):
    font, upem = hbfont(key)
    buf = hb.Buffer(); buf.add_str(text); buf.guess_segment_properties()
    hb.shape(font, buf, {"kern": kern, "liga": False})
    assert len(buf.glyph_infos) == len(text), (text, key)
    return [p.x_advance / upem for p in buf.glyph_positions]

def _advances(text, key, size, kern, letter_px):
    """Pretendard: the advance without kerning and the kerning each rounded to whole px (scored on the whole
    guide: 99.8-100 % of body glyph steps exact); other fonts unrounded."""
    px = size / 0.75
    plain = _shape(text, key, False)
    kerned = _shape(text, key, True) if kern else plain
    out = []
    for a, b in zip(kerned, plain):
        if key in PRETENDARD: v = round(b * px) + round((a - b) * px)
        else: v = a * px
        out.append((v + letter_px) * 0.75)
    return out


class Style:
    def __init__(self, key, size, color, letter_px=0.0, kern=True):
        self.key, self.size, self.color, self.letter_px, self.kern = key, size, color, letter_px, kern

class Code:
    """Inline code: Latin in DejaVu Sans Mono, the rest in Pretendard Regular, both at size, on a box."""
    def __init__(self, size, color="#1d5a49", box="#e7eeeb", top=None, bottom=None, mono="MONO", fallback="R"):
        self.size, self.color, self.box, self.mono, self.fallback = size, color, box, mono, fallback
        self.top = top if top is not None else 0.96 * size      # box top above the code baseline
        self.bottom = bottom if bottom is not None else 3.19     # box bottom below it
        self.base_shift = -0.19                                  # code baseline sits 0.19 pt above the text's


class Page:
    """Collects redactions, glyphs and drawings for one page."""
    def __init__(self, doc, pno):
        self.doc, self.pno, self.page = doc, pno, doc[pno - 1]
        self.redacts = []       # (rect, fill hex or None)
        self.glyphs = []        # (x, y, ch, key, size, color hex)
        self.boxes = []         # (rect, fill hex, radius pt)
        self.strokes = []       # (rect, color hex, width, opacity, radius relative)
        self.graphics = pymupdf.PDF_REDACT_LINE_ART_NONE

    # --- reading the original -------------------------------------------------------------------
    def chars(self, base=None, tol=0.45, x0=-1e9, x1=1e9, y0=None, y1=None):
        out = []
        for b in self.page.get_text("rawdict")["blocks"]:
            if b["type"] != 0: continue
            for l in b["lines"]:
                for s in l["spans"]:
                    for c in s["chars"]:
                        ox, oy = c["origin"]
                        if base is not None and abs(oy - base) > tol: continue
                        if y0 is not None and not (y0 <= oy <= y1): continue
                        if x0 <= ox <= x1:
                            out.append(dict(x=ox, y=oy, c=c["c"], bbox=pymupdf.Rect(c["bbox"]), size=s["size"], color=s["color"], font=s["font"]))
        out.sort(key=lambda d: (round(d["y"]), d["x"]))
        return out

    # --- edits ----------------------------------------------------------------------------------
    def redact(self, rect, fill=None):
        self.redacts.append((pymupdf.Rect(rect), fill))

    def redact_chars(self, chars, fill=None, pad_y=(0.0, 0.0)):
        """Remove exactly these glyphs: a rect inside their union, so neighbours touching it stay."""
        r = pymupdf.Rect(chars[0]["bbox"])
        for c in chars[1:]: r |= c["bbox"]
        r = pymupdf.Rect(r.x0 + 0.4, r.y0 + 1.0 - pad_y[0], r.x1 - 0.4, r.y1 - 1.0 + pad_y[1])
        self.redact(r, fill)
        return r

    def put(self, x, y, text, st):
        """Set text in one style from origin (x, y); returns the end x."""
        if text == "": return x
        for ch, a in zip(text, advances(text, st.key, st.size, st.kern, st.letter_px)):
            self.glyphs.append((x, y, ch, st.key, st.size, st.color))   # spaces too: copy, search and screen readers need them
            x += a
        return x

    def put_code_text(self, x, y, text, code):
        """Code characters only (no box, no padding), font by glyph coverage; returns end x."""
        i = 0
        while i < len(text):
            key = code.mono if has_glyph(code.mono, text[i]) else code.fallback
            j = i
            while j < len(text) and (code.mono if has_glyph(code.mono, text[j]) else code.fallback) == key: j += 1
            seg = text[i:j]
            for ch, a in zip(seg, advances(seg, key, code.size, True, 0.0)):
                self.glyphs.append((x, y, ch, key, code.size, code.color))
                x += a
            i = j
        return x

    def code_width(self, text, code):
        w, i = 0.0, 0
        while i < len(text):
            key = code.mono if has_glyph(code.mono, text[i]) else code.fallback
            j = i
            while j < len(text) and (code.mono if has_glyph(code.mono, text[j]) else code.fallback) == key: j += 1
            w += sum(advances(text[i:j], key, code.size)); i = j
        return w

    def box(self, rect, fill, radius=2.84):
        self.boxes.append((pymupdf.Rect(rect), fill, radius))

    def stroke(self, rect, color, width, opacity, radius):
        """An outline; radius in pt."""
        self.strokes.append((pymupdf.Rect(rect), color, width, opacity, radius))


# --- paragraphs ---------------------------------------------------------------------------------
# A run is (text, kind): kind 't' body, 'b' bold, 'c' inline code. Breaks only at spaces (keep-all).
PAD = 3.4

def _tokens(runs):
    """Split runs into words (lists of (text, kind)) separated by single spaces (kind of the space kept)."""
    words, cur, spaces = [], [], []
    for text, kind in runs:
        parts = text.split(" ")
        for k, part in enumerate(parts):
            if k > 0:
                words.append(cur); spaces.append(kind); cur = []
            if part: cur.append((part, kind))
    words.append(cur)
    return words, spaces

class Para:
    def __init__(self, pg, body, bold=None, code=None):
        self.pg, self.body, self.bold, self.code = pg, body, bold or body, code

    def _style(self, kind):
        return self.bold if kind == "b" else self.body

    def _measure_piece(self, text, kind):
        if kind == "c": return self.pg.code_width(text, self.code)
        st = self._style(kind)
        return sum(advances(text, st.key, st.size, st.kern, st.letter_px))

    def _space(self, kind):
        if kind == "c": return self.pg.code_width(" ", self.code)
        st = self._style(kind)
        return advances(" ", st.key, st.size, st.kern, st.letter_px)[0]

    def _line_width(self, items):
        """items: list of (text, kind) for a line, spaces included as their own pieces."""
        w, prev = 0.0, None
        pad = getattr(self.code, "pad", PAD)
        for text, kind in items:
            if kind == "c" and prev != "c": w += pad
            if kind != "c" and prev == "c": w += pad
            w += self._measure_piece(text, kind)
            prev = kind
        if prev == "c": w += pad
        return w

    def layout(self, runs, width, first_width=None):
        """Greedy line breaking; returns list of lines, each a list of (text, kind) pieces."""
        words, spaces = _tokens(runs)
        lines, cur = [], []
        for i, word in enumerate(words):
            trial = cur + ([(" ", spaces[i - 1])] if cur else []) + word
            limit = first_width if (first_width is not None and not lines) else width
            if not cur and not lines and first_width is not None and self._line_width(word) > first_width:
                lines.append([]); cur = list(word)   # nothing fits after first_x: the text starts on the next line
            elif cur and self._line_width(trial) > limit:
                lines.append(cur); cur = list(word)
            else:
                cur = trial
        if cur: lines.append(cur)
        return [self._merge(l) for l in lines]

    @staticmethod
    def _merge(items):
        out = []
        for text, kind in items:
            if out and out[-1][1] == kind: out[-1] = (out[-1][0] + text, kind)
            else: out.append((text, kind))
        return out

    def draw_line(self, x, y, items, code_open_at_start=False):
        """Set one line from x on baseline y; returns end x."""
        prev = None
        for idx, (text, kind) in enumerate(items):
            if kind == "c":
                pad = getattr(self.code, "pad", PAD)
                if prev != "c": x += pad
                start = x
                x = self.pg.put_code_text(x, y + self.code.base_shift, text, self.code)
                end = x
                cy = y + self.code.base_shift
                if self.code.box is not None:   # 1.12.0 run: code with no box (a path in body text)
                    self.pg.box((start - PAD + 0.05, cy - self.code.top, end + PAD - 0.25, cy + self.code.bottom), self.code.box)
                x += pad
                prev = "c"
            else:
                x = self.pg.put(x, y, text, self._style(kind))
                prev = kind
        return x

    def draw(self, runs, x, baselines, width, pitch=None, first_x=None, max_lines=None):
        """Lay out and set runs; baselines are reused, then continued with pitch. Returns (lines, baselines used)."""
        fx = first_x if first_x is not None else x
        lines = self.layout(runs, width, first_width=width - (fx - x))
        if max_lines is not None and len(lines) > max_lines:
            raise ValueError(f"p{self.pg.pno}: {len(lines)} lines > {max_lines}: {[''.join(t for t, _ in l) for l in lines]}")
        ys = list(baselines)
        while len(ys) < len(lines): ys.append(ys[-1] + pitch)
        for k, (line, y) in enumerate(zip(lines, ys)):
            self.draw_line(fx if k == 0 else x, y, line)
        return lines, ys[:len(lines)]


# --- writing ------------------------------------------------------------------------------------
class Fonts:
    """fontTools subsets of every font key, for exactly the characters set."""
    def __init__(self):
        self.objs = {}

    def build(self, pages):
        need = {}
        for pg in pages:
            for _, _, ch, key, _, _ in pg.glyphs: need.setdefault(key, set()).add(ch)
        os.makedirs(f"{G}/fonts/subsets", exist_ok=True)
        for key, chars in need.items():
            path, idx = FONT_FILES[key]
            opts = ftsubset.Options(); opts.font_number = idx; opts.layout_features = []; opts.name_IDs = ["*"]
            opts.notdef_outline = True; opts.hinting = False; opts.desubroutinize = False
            font = ftsubset.load_font(path, opts)
            sub = ftsubset.Subsetter(opts); sub.populate(unicodes=[ord(c) for c in chars]); sub.subset(font)
            bio = io.BytesIO(); font.save(bio)
            data = bio.getvalue()
            with open(f"{G}/fonts/subsets/{key}.bin", "wb") as f: f.write(data)
            self.objs[key] = pymupdf.Font(fontbuffer=data)
            missing = [c for c in chars if not self.objs[key].has_glyph(ord(c))]
            assert not missing, (key, missing)


def fix_widths(doc, fonts, min_xref=1):
    """Rewrite each inserted font's /W from its subset's hmtx (CID = GID, Identity): MuPDF wrote a compact
    `[0 65535 260]` for the monospaced DejaVu subset, and TextWriter's TJ spacing assumes the real advances.
    Only fonts at xref >= min_xref, the ones this run inserted: a patched PDF already holds earlier runs' subsets
    under the same BaseFont names, whose /W must stay theirs. Returns {BaseFont: (old W, glyphs)}."""
    by_name = {}
    for key, f in fonts.objs.items():
        tt = TTFont(f"{G}/fonts/subsets/{key}.bin")
        upem = tt["head"].unitsPerEm
        ws = [round(tt["hmtx"][g][0] * 1000 / upem, 3) for g in tt.getGlyphOrder()]
        by_name["/" + f.name.replace(" ", "#20")] = ws
        by_name["/" + f.name] = ws
    done = {}
    for x in range(min_xref, doc.xref_length()):
        try:
            if doc.xref_get_key(x, "Subtype")[1] != "/CIDFontType2": continue
            bf = doc.xref_get_key(x, "BaseFont")[1]
        except Exception:
            continue
        parent = [p for p in range(min_xref, doc.xref_length()) if doc.xref_get_key(p, "DescendantFonts")[1].strip("[] ").startswith(f"{x} 0 R")]
        names = [doc.xref_get_key(p, "BaseFont")[1] for p in parent]
        hit = next((n for n in names if n in by_name), None)
        if hit is None: continue
        old = doc.xref_get_key(x, "W")
        doc.xref_set_key(x, "W", "[0 [" + " ".join(f"{w:g}" for w in by_name[hit]) + "]]")
        done[hit] = (old, len(by_name[hit]))
    return done


def apply(doc, pages, fonts):
    for pg in pages:
        p = pg.page
        for rect, fill in pg.redacts:
            p.add_redact_annot(rect, fill=rgb(fill) if fill else False, cross_out=False)
        if pg.redacts:
            p.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_NONE, graphics=pg.graphics, text=pymupdf.PDF_REDACT_TEXT_REMOVE)
        # Chromium's content leaves its scaling transform active: wrap it in q/Q before appending anything.
        if not p.is_wrapped: p.wrap_contents()
        # draw_rect's radius is a fraction of the width and of the height, each: convert the radius in pt.
        rel = lambda r, rect: (min(0.5, r / rect.width), min(0.5, r / rect.height)) if r else None
        for rect, fill, radius in pg.boxes:
            p.draw_rect(rect, color=None, fill=rgb(fill), width=0, radius=rel(radius, rect), overlay=True)
        for rect, color, width, opacity, radius in pg.strokes:
            p.draw_rect(rect, color=rgb(color), fill=None, width=width, radius=rel(radius, rect), stroke_opacity=opacity, overlay=True)
        by_color = {}
        for x, y, ch, key, size, color in pg.glyphs: by_color.setdefault(color, []).append((x, y, ch, key, size))
        for color, gl in by_color.items():
            tw = pymupdf.TextWriter(p.rect)
            for x, y, ch, key, size in gl: tw.append((x, y), ch, font=fonts.objs[key], fontsize=size)
            tw.write_text(p, color=rgb(color))
