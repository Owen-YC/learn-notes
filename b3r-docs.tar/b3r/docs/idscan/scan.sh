#!/bin/bash
# Model-id scan: tracked files except docs/qa/견본.md (binary-safe grep -a), guide PDF text, deck XML, release body, commit messages de98243..HEAD.
D=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3r/docs/idscan
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad
RX='claude-(opus|sonnet|haiku|fable|instant)[-a-z0-9.]*|claude-[0-9]+[-.][0-9]|anthropic\.claude|claude-[a-z]+-[0-9]+-[0-9]+|[a-z]+-[0-9]-[0-9]-20[0-9]{6}'
cd /home/user/learn-notes
n=0
f=$(git ls-files -z | grep -zv '^docs/qa/견본.md$' | xargs -0 grep -aEl "$RX" 2>/dev/null); echo "files: ${f:-none}"; [ -n "$f" ] && n=$((n+1))
pdftotext docs/team/learn-notes-guide.pdf "$D/guide.txt"; c=$(grep -cE "$RX" "$D/guide.txt"); echo "guide text: $c"; n=$((n+c))
rm -rf "${D:?}/pptx"; mkdir -p "$D/pptx"; (cd "$D/pptx" && unzip -q /home/user/learn-notes/docs/team/learn-notes-intro.pptx); c=$(grep -rlE "$RX" "$D/pptx" | wc -l); echo "pptx parts: $c"; n=$((n+c))
c=$(grep -cE "$RX" "$S/release-body-1120.md"); echo "release body: $c"; n=$((n+c))
c=$(git log de98243..HEAD --format=%B | grep -cE "$RX"); echo "commit messages de98243..HEAD: $c"; n=$((n+c))
echo "TOTAL $n"
