#!/bin/bash
# learn-notes 1.12.0 G3 retry docs step: plan112 afterBatches.finalRecheck on the working tree (docs changed, code as HEAD), then gates.
B="/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112"; F="$B/b3r/docs/final"; R=/home/user/learn-notes; P="$B/cli/pinned.sh"
L="/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/docs112/land"
export DISABLE_AUTOUPDATER=1
cd "$R"
"$P" --record > "$F/pin-before.txt" 2>&1
# 1. isRuleWide haiku/sonnet vs de98243
"$P" node --experimental-transform-types "$B/d26/rulewide.mjs" "$R" "$F/rw" --extra "$B/b1/audit/d26x/extra.json" > "$F/rulewide.log" 2>&1; echo $? > "$F/rulewide.exit"
# 2. G2 haiku (가)(나): measured requests re-made from the working tree with the shipped haiku row, no harness row
python3 -I "$B/b2/sw/remake.py" "$B/b2/frozen" "$F/remake" > "$F/remake.log" 2>&1; echo $? > "$F/remake.exit"
# 3. G2 haiku (다): frozen answers re-read with the working tree's parseQuiz / changedItem
mkdir -p "$F/reread/mtree" "$F/reread/jtree"
cp -r "$R/hooks" "$R/types" "$F/reread/mtree/"; cp -r "$R/hooks" "$R/types" "$F/reread/jtree/"
sed -i -E 's/^function (shownCode|codeTokens|codeAsRead|quizParts)\(/export function \1(/' "$F/reread/jtree/hooks/notes.ts"
diff "$F/reread/mtree/hooks/notes.ts" "$F/reread/jtree/hooks/notes.ts" > "$F/reread/jtree.diff"
NOTES="$F/reread/mtree/hooks/notes.ts" JNOTES="$F/reread/jtree/hooks/notes.ts" "$P" node --experimental-transform-types "$B/b2/tools/read.mjs" "$B/b2/stage/quiz/haiku" "$B/b2/frozen" "$F/reread/read.json" > "$F/reread/read.log" 2>&1; echo $? > "$F/reread.exit"
# 4. G3 selection with other-window stamps after the bump (the Land test, copied)
G="$F/g3copy"; mkdir -p "$G/tests"
cp -r "$R/.claude-plugin" "$R/hooks" "$R/types" "$G/"; cp "$R/tsconfig.json" "$G/"; ln -sfn "$R/node_modules" "$G/node_modules"
cp -r "$R/tests/fixtures" "$G/tests/"; cp "$R/tests/flowkit.ts" "$G/tests/"; cp "$L/g3copy/tests/final112.test.ts" "$G/tests/"
(cd "$G" && "$P" claude plugin test . > "$F/g3copy.log" 2>&1; echo $? > "$F/g3copy.exit")
# 5. gates
cd "$R"
npx tsc -p . --noEmit > "$F/tsc.log" 2>&1; echo $? > "$F/tsc.exit"
"$P" claude plugin validate . > "$F/validate.log" 2>&1; echo $? > "$F/validate.exit"
"$P" claude plugin test . > "$F/test.log" 2>&1; echo $? > "$F/test.exit"
"$P" --record > "$F/pin-after.txt" 2>&1
echo DONE > "$F/status"
