// learn-notes 1.12.0 Land finalRecheck: G3 selection with other-window stamps, the window's own version from the bumped plugin.json.
import { describe, expect, test } from 'claude-code/testing'
import type { Engine } from 'claude-code/testing'
import type { On } from 'claude-code'
import { compareVersions, conceptKey, newerBuild, newerText, isOldGraderOpen, NEW_GRADER_SINCE } from '../hooks/notes'
import { CHECK_ITEM_110 } from './fixtures/check110'
import { CONCEPT_NOTE, NOW, finish, learn, ownSteps, start, turn, world } from './flowkit'

const MANIFEST = '1.12.0'
const DAY = 86_400_000
const NAME = CHECK_ITEM_110.name
const KLA_REPLY = ['K1:', '```js', 'const scores = [5, 1, 4]', 'let best = 0', 'for (const s of scores) best += s', 'console.log(best)', '```', 'L1: for (const s of scores) best += s', 'T1: 예측', 'Q1: 아래 코드는 무엇을 찍을까요?\n```js\nconsole.log(1 + 9)\n```', 'A1:', '10', 'T2: 왜', 'Q2: 문제 2', 'A2: 답 2', 'T3: 왜', 'Q3: 문제 3', 'A3: 답 3'].join('\n')
const FILLERS = ['채움 하나', '채움 둘']
const LINES = ['const nums = [1, 2]', 'for (const n of nums) console.log(n)', ...Array.from({ length: 14 }, (_, i) => `// line ${i + 1}`)]

async function quizOf($: Engine, on: On, other: string) {
  const concepts = Object.fromEntries([
    [conceptKey(NAME), { name: NAME, count: 2, firstAt: NOW - 200 * DAY, lastAt: NOW - 200 * DAY, blurb: `${NAME} 설명 — \`for (const n of nums)\``, files: [], step: 4, reviewedAt: NOW - 31 * DAY }],
    ...FILLERS.map(name => [conceptKey(name), { name, count: 1, firstAt: NOW - 200 * DAY, lastAt: NOW - 200 * DAY, blurb: `${name} 설명`, files: [], step: 3, reviewedAt: NOW }]),
  ])
  const store = new Map<string, unknown>([['stepsFrom', 0], ['concepts', concepts], ['steps', ownSteps(concepts as never)]])
  const w = world(on, 'ok', null, true, store)
  w.version = MANIFEST
  w.harness = { rungNewStep: 4 }
  store.set('sessions', { 'session-other': { v: other, at: NOW - 20 * 60_000 } })
  await start($)
  w.answer = CONCEPT_NOTE([NAME])
  await turn($, () => $.tool.call({ tool: 'Write', tool_use_id: 'w1', file_path: '/proj/src/a.js', content: [...LINES, ''].join('\n') }))
  await finish(w)
  w.answer = KLA_REPLY
  await learn($, '퀴즈 새로')
  return { store, prompt: w.models.at(-1)!, maxTokens: w.budgets.at(-1)! }
}

describe('1.12.0 Land finalRecheck: G3 selection after the bump', () => {
  test('the manifest is 1.12.0 and versions compare by number', () => {
    expect(MANIFEST).toBe('1.12.0')
    expect(NEW_GRADER_SINCE).toBe('1.12.0')
    expect(compareVersions('1.12.0', '1.11.0')).toBeGreaterThan(0)
    expect(compareVersions('1.11.0', '1.9.0')).toBeGreaterThan(0)
    expect(compareVersions('1.12.0', '1.9.0')).toBeGreaterThan(0)
    expect(compareVersions('1.12.0', '1.12.0')).toBe(0)
    const at = NOW - 60_000
    expect(newerBuild({ a: { v: '1.12.0', at } }, 'me', '1.11.0', NOW)).toBe('1.12.0')
    expect(newerBuild({ a: { v: '1.12.0', at } }, 'me', '1.9.0', NOW)).toBe('1.12.0')
    expect(newerBuild({ a: { v: '1.11.0', at }, b: { v: '1.9.0', at } }, 'me', MANIFEST, NOW)).toBeUndefined()
    expect(newerText(newerBuild({ a: { v: '1.12.0', at } }, 'me', '1.11.0', NOW), '1.11.0', false)).toBe('learn-notes 새 버전(1.12.0)이 다른 창에서 쓰이고 있습니다 · 이 창은 1.11.0입니다 · /reload-plugins로 바꿉니다')
    expect(isOldGraderOpen({ a: { v: '1.11.0', at } }, 'me', NOW)).toBe(true)
    expect(isOldGraderOpen({ a: { v: '1.12.0', at } }, 'me', NOW)).toBe(false)
  })
  for (const [v, isOpen] of [['1.11.0', true], ['1.12.0', false]] as const) {
    test(`a ${MANIFEST} window, another window of ${v} stamped 20 minutes ago: rung new ${isOpen ? 'kept off' : 'allowed'}`, async ($, on) => {
      const { store, prompt, maxTokens } = await quizOf($, on, v)
      console.log('FINAL112 ' + JSON.stringify({ other: v, own: (store.get('sessions') as Record<string, { v: string }>), newSlot: prompt.includes('   칸: 처음 보는 코드 (js로)'), maxTokens, rung: (store.get('quiz') as { items: { rung?: string }[] }).items[0]!.rung ?? null }))
      expect(Object.values(store.get('sessions') as Record<string, { v: string }>).map(one => one.v).sort()).toEqual([v, MANIFEST].sort())
      expect(prompt.includes('   칸: 처음 보는 코드 (js로)')).toBe(!isOpen)
      expect(prompt.includes('\n   칸: 내 코드\n   학습자가 만든 코드 (a.js):')).toBe(isOpen)
      expect(maxTokens).toBe(isOpen ? 3400 : 4600)
      expect((store.get('quiz') as { items: { rung?: string }[] }).items[0]!.rung ?? null).toBe(isOpen ? 'mine' : 'new')
    })
  }
  test('a 1.11.0 window whose other window is this 1.12.0 build: told a newer build is open', async ($, on) => {
    const w = world(on)
    w.version = '1.11.0'
    ;(w as any).store?.set?.('sessions', { 'session-other': { v: MANIFEST, at: NOW - 60_000 } })
    expect(newerBuild({ 'session-other': { v: MANIFEST, at: NOW - 60_000 } }, 'me', '1.11.0', NOW)).toBe('1.12.0')
  })
  test('the help line names the manifest version', async ($, on) => {
    const w = world(on)
    w.version = MANIFEST
    await start($)
    expect(((await learn($, '도움말')).text ?? '').split('\n')[0]).toBe('learn-notes 1.12.0 명령')
  })
})
