너는 새로 불린 판정자다. 학습 노트 앱이 만든 '비슷한 코드' 문항이 아래 '판정의 입장'을 갖추는지 매긴다. 너는 이 문항을 만든 모델이 무엇인지, 문항을 어떻게 불렀는지 모르며 알 필요도 없다. 도구는 없다. 코드를 돌리지 말고, 도구 호출도 쓰지 마라. 돌린 결과는 보고서에 이미 있다.

할 일
- 보고서의 '읽힌 문항 없음'이 아닌 자리마다 한 줄씩 매긴다. 읽힌 문항이 없는 자리는 적지 않는다.
- 도구(⚙)가 센 조항은 도구 결과를 그대로 받는다. 너는 ✎ 부분만 매긴다:
  - "ga": 조항 7 (ㅇ)과 조항 10의 문제 글(lead와 hint, 보인 코드와 학습자 코드의 한 줄 차이, hint의 줄 번호와 따온 줄)이 맞는지 보고, 입장의 다른 조항에 비추어 (가) 놓침이어야 할 까닭이 있는지 본다. 넘음이면 "pass", 놓침이면 "miss". 도구가 이미 놓침으로 센 자리도 네 판단을 적는다.
  - "na": 보고서가 '(나) 도구 결과: 도구가 같다고 하지 못함 → 판정자가 조항 11로 매김'이라고 한 자리만 조항 11로 "right" 또는 "wrong"을 적는다. 도구가 맞음이나 틀림으로 정한 자리는 "tool"이라고 적는다.
- 판정마다 근거가 된 조항 번호를 적는다(예: "10(iii)", "11", "6").
- 이 입장이 가르지 못하는 경우는 "undecided"라고 적고 까닭을 쓴다(그 자리는 기능에 불리한 쪽으로 셈).
- 입장에 없는 조항을 더하거나 조항을 다르게 읽지 않는다.

답의 꼴: JSON 배열 하나만 쓴다. 다른 글, 코드 펜스를 쓰지 않는다. 자리마다
{"slot": "c1", "ga": "pass" | "miss" | "undecided", "ga_clause": "…", "na": "right" | "wrong" | "tool" | "undecided", "na_clause": "…", "why": "한두 문장"}


# 판정의 입장

#### 판정의 입장

설계의 입장(stance) 글입니다. 머리말과 조항 0–15, 조항 15의 미리 가른 경계 사례를 설계 글자 그대로 옮겼습니다. 판정은 이 글자대로만 셉니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 '다시 잴 때'에 적습니다(M-11).

판정의 입장 (G2, 1.12.0 G2-C). 기준 · 결정 규칙 · 짜임 · 견본 쓰기 프롬프트와 함께, 견본을 쓰거나 부르기 전에 docs/qa/견본.md 새 절로 한 커밋에 넣습니다(UTC 시각, 가리키는 코드 커밋 해시). 매기는 쪽은 이 글의 조항만 따르고 판정마다 조항 번호를 적습니다. ⚙ 조항은 eval 도구(부르기 전에 sha256으로 얼림)가 세고, ✎ 조항만 매기는 하위 에이전트가 매깁니다. 1.10.0의 조항 번호와 뜻을 그대로 두고, 이 설계에서 쓰이지 않는 갈래는 "쓰이지 않음"으로 적었습니다.

0 셈의 단위: 비슷한 코드로 고른 20자리(퀴즈 9개). 같은 퀴즈의 내 코드 · 왜 · 다시 도전 문항은 셈 밖이고 기록만 합니다.

1 읽기 ⚙: 플러그인처럼 fixEscapedTicks → 그 커밋의 parseQuiz로 읽어 저장될 문항(question · hint · answer · kind · rung)만 매깁니다. 모델의 C · O · N 줄, 되풀이 줄(R), 바꿀 수 있는 곳 목록과 날글은 저장되지 않으므로 판정 대상이 아니며, O가 틀리고 N이 맞은 자리도 저장된 문항(N)만으로 매깁니다. 읽힌 문항은 그 번호 자리의 개념으로 플러그인이 짠 문항입니다.

2 답이 없는 자리 ⚙: 빈 답(empty-reply · API 거절), 시간 한도(90초)에 끊긴 답, 읽히지 않은 자리, 플러그인의 읽기(changedItem)가 문항을 내지 않은 자리는 (가)에서 놓침, (나)에서는 셈 밖입니다(학습자에게 보이지 않음). 상한에 닿았어도 읽힌 문항은 읽힌 그대로 매깁니다. 다시 보내는 것은 글이 하나도 없고 출력 토큰이 0인 api-error(상태 429 · 5xx)뿐이며 같은 프롬프트로 두 번까지, 모두 기록합니다. 그래도 실패하면 그 퀴즈의 자리는 모두 놓침입니다. 빈 답 · 시간 끊김 · 상한 닿음 · 읽기가 거른 자리는 다시 보내지 않습니다. 빈 답은 기록으로만 탭으로 한 번 더 보내 stop_reason을 적습니다.

3 돌리기 ⚙: 문제의 코드: question의 펜스 블록(플러그인이 넣은 하나)입니다. 언어는 펜스 이름(js · python)입니다. 빈 임시 폴더에서 `unshare -n timeout 5`로, 표준 입력을 비우고 돌립니다. js: `node 파일` 두 번. py: `env -i PATH="$PATH" LANG=C.UTF-8 PYTHONHASHSEED=<n> python3 -s -P -B 파일`을 n = 1..5로 다섯 번. 결과는 표준 출력의 줄들입니다(마지막 줄이 줄바꿈 없이 끝나도 한 줄). 끝 코드가 0이 아니면 그 앞까지의 출력 뒤에 마지막 예외의 이름(메시지는 뺌) 한 줄을 더합니다. 표준 오류는 결과에 넣지 않습니다. 돌린 결과가 서로 하나라도 다르거나 5초를 넘으면 그 문항은 (가) 놓침이고 A는 틀림입니다. 학습자 결과: 견본을 얼리기 전 확인 때 학습자 파일 전체(= 바꾸기 전의 보인 코드)를 같은 규칙으로 돌려 얼린 줄들입니다. 도구 판(node · python · Claude Code)을 적습니다.

4 채우지 않음: 블록에 없는 정의 · import · 입력 · 파일 · 준비를 덧붙이지 않습니다. 나는 오류도 결과입니다. (이 설계의 문제 코드는 학습자 파일 전체라 채울 것이 생기지 않지만 규칙은 그대로 둡니다.) 4의 "글로 말한 바꿈"은 쓰이지 않습니다(바꿈은 플러그인이 코드에 넣음).

5 물은 것 ⚙: 문제 글은 플러그인의 고정 글(CHANGED_LEAD)이고 "이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름"을 묻습니다. 그래서 물은 것은 언제나 결과 전체(오류로 멈추면 그 앞 출력과 오류 이름)입니다. 매기는 쪽이 Q만 보고 물은 것을 정하는 단계는 쓰이지 않습니다. question이 이 글로 시작하지 않으면 10에서 놓침이고, (나)는 결과 전체와 견줍니다.

6 표기 맞춤 ⚙: 1.10.0 조항 6을 글자 그대로 씁니다(A와 결과, 결과끼리 견줄 때 모두). 줄마다 앞뒤 공백을 지우고, 이어진 공백은 하나로, 글자 · 숫자(한글 포함)가 아닌 문자 바로 옆의 공백은 지웁니다. 따옴표 종류는 가리지 않습니다. 결과 줄이 따옴표로 시작하고 끝나지 않을 때만 A 줄 전체를 감싼 따옴표 · 백틱을 뗍니다. js에서 결과 줄에 따옴표로 감싼 객체 키가 없을 때만 A의 `"a":` · `'a':`를 `a:`로 봅니다(py는 그대로). 줄 끝 마침표 하나와 true · false · none · null · undefined · nan의 대소문자는 보지 않습니다. 결과 끝의 빈 줄은 견주지 않고, 가운데 빈 줄은 A의 빈 줄이나 '(빈 줄)'과 같습니다. 결과가 여러 줄이고 A가 한 줄이면 결과 줄들을 ', ' · ' ' · '과 ' · '와 ' · ' 그리고 ' · ' → ' 가운데 하나로 이어 맞춘 것이 A와 같으면 같음입니다(학습자가 쉼표로 이어 쓴 답과 같은 규칙). 그 밖의 글자 · 값 · 차례 · 줄 수 · 괄호 · 숫자 표기 · 대소문자는 그대로 견줍니다. 앞 공백만 다른 줄(padStart · ljust · rjust가 찍은 `   5`와 `5`)은 이 규칙으로 같음입니다(1.10.0과 같음, 바꾸지 않음).

7 (가) 코드 다름 · 답 다름: 아래를 모두 갖춘 자리만 넘음으로 셉니다. (ㄱ) ⚙ 읽힌 문항의 rung이 changed. (ㄴ) ⚙ 코드를 바꿨음: 3의 문제 코드가 학습자 조각(= 파일 전체)과 6의 맞춤과 줄 끝 `;` · 주석 뺌 뒤 줄 단위로 (i) 같지 않고 (ii) 찍는 줄(한 줄짜리 console.log(…) · print(…))을 뺀 나머지 줄이 학습자 줄들의 부분열이 아님. (ㄷ) ⚙ 그 개념의 코드에서 왔음: 학습자 조각의 핵심 줄(토큰 4개 이상, 괄호뿐 · else · `return 이름` · 이름 하나만 찍는 줄이 아님; 없으면 토큰 2개 이상) 가운데 하나 이상이 보인 코드의 어느 줄과 토큰이 같거나 하나만 다름(codeAsRead 토큰). (ㄹ) ⚙ 정의 빠짐이 아님: 결과가 ReferenceError/NameError로 끝나고 그 이름이 블록 안에서 한 번도 선언 · 대입 · 매개변수 · for 변수 · catch 변수로 나오지 않으면 놓침(TDZ · UnboundLocalError는 들지 않음). (ㅁ) ⚙ kind가 predict. (ㅂ) ⚙ 펜스 블록이 하나. (ㅅ) ⚙ 답이 다름(8). (ㅇ) ⚙/✎ 문제 글이 맞음(10). (ㅈ) ⚙ 3의 여러 번 돌린 결과가 모두 같고 5초 안(ts 갈래는 쓰이지 않음: 12).

8 답 다름 ⚙: 학습자 결과: 3의 얼린 학습자 결과. 조각 결과: 1.10.0 조항 8의 정의를 그대로 씁니다 — 학습자 결과 가운데, 보낸 codeFor 조각이 파일에서 차지하는 줄 범위 안의 print 호출이 찍은 줄들. 이 설계의 조각은 파일 전체이므로(isWholeShown) 모든 호출이 범위 안에 있고, 조각 결과는 학습자 결과와 같습니다(새 해석이 아니라 정의를 그대로 적용한 것). 견줄 것은 물은 것(5: 결과 전체)입니다. 6으로 맞춘 뒤 아래 가운데 하나면 같음(놓침): (a) 결과 전체가 학습자 결과 전체와 같음. (b) 결과 줄들이 차례 그대로 학습자 결과 안에 이어진 줄들로 있음(어디서 시작해도; 한 줄이면 학습자 결과의 어느 줄과 같아도). (c) 결과 줄마다 학습자 결과의 같은 순번 줄과 같음. (d) · (e)(찍지 않는 이름, 줄 수 · 횟수를 물음)는 물은 것이 언제나 결과 전체라 쓰이지 않습니다. 결과가 오류 이름으로 끝나면 그 줄은 학습자 결과의 어느 줄과도 다릅니다. 결과가 오류 이름 한 줄뿐이면 다름입니다.

9 예측이 아닌 문항: 쓰이지 않음: 플러그인이 kind를 predict로 씁니다. 도구 결함으로 다른 kind가 저장되면 7(ㅁ) 놓침, (나)는 11로 매깁니다.

10 문제 글 ⚙: lead와 hint는 플러그인이 쓴 고정 글이지만 모델 글처럼 매깁니다(1.10.0보다 엄격: 그때 H는 기록만). (ㅇ)를 갖추려면 모두: (i) question이 CHANGED_LEAD 글 그대로로 시작하고 그 뒤에 펜스 블록 하나만 있음; (ii) 보인 코드와 학습자 코드가 정확히 한 줄에서만 다름("한 곳을 바꿨습니다"가 참); (iii) hint의 "k번째 줄"이 그 다른 줄의 번호(보인 블록의 첫 줄을 1로, 빈 줄 포함)와 같음; (iv) hint가 줄을 따왔으면 따온 글이 그 줄의 앞뒤 공백을 뺀 것과 글자 그대로 같음. hint는 바뀐 줄을 알려 줄 뿐 결과나 따라간 과정을 말하지 않으므로 답을 미리 말한 것으로 보지 않습니다. 하나라도 어긋나면 (가) 놓침입니다.

11 (나) A 맞음: ⚙ 먼저 도구가 A 전체를 6으로 맞춰 결과 전체와 같은지 봅니다. 같으면 맞음. ✎ 아니면 매기는 쪽이 봅니다: A가 결과의 줄을 모두 차례대로 말하고(6의 "그대로 견주는 것"으로) 다른 틀린 말이 없으면 맞음. 틀림: 결과 전체 가운데 일부만 쓴 A(반복이 찍는 여러 줄 중 마지막 줄만 등), 줄여 쓴 A(… · 등 · 생략), 오류로 멈추는 결과에 출력만 쓴 A, 오류가 첫 출력 전에 나는데 그 앞에 찍힌 줄을 쓴 A, 오류 이름을 다르게 댄 A, 둘 이상을 답으로 내놓은 A, 학습자 원래 코드의 답을 쓴 A, node가 여러 줄로 펼쳐 찍는 값을 한 줄로 쓴 A(결과가 여러 줄이고 A도 여러 줄이면 줄 수가 달라 틀림; A 전체가 한 줄일 때만 6의 잇기 규칙). 맞음: 오류 메시지 글은 견주지 않음(이름만). 저장된 A에는 언제나 오류 이름이 있습니다(읽기가 이름 없는 오류 줄을 받지 않음).

12 ts: 쓰이지 않음: ts는 범위 밖이고(RUNG_CHANGED_EXTS = js, py) 견본에 넣지 않습니다. 도구 결함으로 ts 문항이 저장되면 (가) 놓침, (나)는 3으로 돌린 결과와 견줍니다.

13 번호가 엇갈린 답 ⚙: parseQuiz가 짝지은 번호대로 매깁니다. changedItem은 그 번호 자리 개념의 코드로만 문항을 짜고 C의 번호가 자리 번호와 다르면 문항을 내지 않으므로, 엇갈린 답은 읽히지 않은 자리(2)로만 셉니다. C · O · N을 다시 쓴 답은 플러그인처럼 마지막 글로 읽습니다(1).

14 매기는 차례와 갈림: 꼬리표마다 매기는 하위 에이전트 둘이 따로 매깁니다. 둘 다 설계 · 견본 쓰기 · 부르기에 끼지 않은 새 하위 에이전트이고, 이 글과 도구가 낸 파일만 봅니다(모델 이름, 토큰, 시간은 빠짐). 두 판정이 갈린 문항과 이 글이 가르지 못하는 경우는 기능에 불리한 쪽((가) 놓침, (나) 틀림)으로 셉니다. 재는 세션은 판정을 바꾸지 않고, 출력을 본 뒤 조항을 더하거나 고치거나 다시 읽지 않습니다. 고칠 것은 '다시 잴 때'에 적기만 합니다.

15 미리 가른 경계 사례
- 1.10.0 기록: W10 부모 클래스가 블록에 없음 → 7(ㄹ) (이 범위에서는 생기지 않음). 줄인 출력 → 11 틀림. 되돌리기 · 바꿔 보기 · 왜 → 9(쓰이지 않음). Q가 지금 출력을 틀리게 말함 → 10. Object.freeze A length 1 vs TypeError → 11 틀림. 빈 답 · 상한에 잘린 끝 → 2. 그대로 보임 · 몇 줄만 떼어 보임 → 7(ㄴ). 1.8.0 ===/== 출력 그대로 → 8 같음. node `[ 1, 2, 3, [ 4 ] ]` vs A `[1, 2, 3, [4]]` → 6 같음. 산문 A → 11. pythonista[7:]를 ista로 → 11 틀림. 두 블록으로 보임 → 7(ㅂ). 두 번 돌린 결과가 다름 → 3. node가 깊은 배열을 `[Array]`로 줄여 찍음 → 3 · 6 · 11(통째로 쓴 A는 틀림). 끝에 빈 줄을 찍음 → 6 견주지 않음. `1 2`와 `12` → 6 다름. JSON.stringify의 `{"a":1}`을 `{a:1}`로 쓴 A → 6 다름. T 줄만 있고 유형이 빔 → 쓰이지 않음(9).
- (dev) for-else: 바꾼 뒤 'hana 없음' 줄이 빠지고 결과가 학습자 결과의 둘째 줄 하나만 남음 → 8(b) 같음, (가) 놓침(지금 읽기는 이런 N을 'subset'으로 거르므로 읽히지 않은 자리, 2와 같은 결과).
- (dev) continue · sum · min: 결과가 학습자 결과의 앞 줄들 또는 가운데 한 줄 → 8(b) 같음.
- (dev) 반복이 네 줄을 찍는데 A가 마지막 줄만 씀 → 11 틀림.
- (dev) repeat(-1)이 첫 출력 전에 RangeError를 내는데 A가 그 앞에 찍힌 줄을 씀 → 11 틀림. 결과가 오류 이름 한 줄이면 A도 그 이름 한 줄이어야 맞음.
- (dev) 기준 점수를 바꾼 grade()의 흐름을 잘못 따라 '서아 B'라고 씀(결과 '서아 A') → 11 틀림.
- (dev) JSON.stringify 문자열의 길이 비교(text.length > 30)를 잘못 셈 → 11 틀림.
- (dev) A 줄 끝 마침표(`true.`)·대소문자(`TRUE`/`True` in js) → 6: 마침표 하나와 true/false 대소문자는 보지 않음.
- (dev) py `<class 'bool'>`, js typeof의 `number` → 결과 그대로; 6으로 견줌.
- 앞 공백(padStart · rjust)만 다른 줄 → 6 같음(1.10.0 그대로).
- 가운데 빈 줄: 저장된 A의 빈 줄('(빈 줄)'을 읽기가 빈 줄로 바꿈)은 결과의 가운데 빈 줄과 같음; 결과에 가운데 빈 줄이 있는데 A에 없으면 줄 수가 달라 11 틀림.
- py 집합 · 사전 차례: 다섯 번의 결과 가운데 하나라도 다르면 3 → (가) 놓침 · A 틀림(범위에서 집합은 빠짐; 사전은 넣은 차례로 같음).
- node가 클래스 인스턴스를 `Point { x: 1 }`로 찍는데 A가 `{ x: 1 }` → 6 그대로 견주는 것이라 다름 → 11 틀림.
- 실수 표기(0.30000000000000004, 9240.0) → 6 그대로; 다르게 쓴 A는 틀림.
- A가 여러 줄 결과를 쉼표로 이어 한 줄로 씀(lead가 허용) → 6의 잇기 규칙으로 같으면 맞음.
- 보인 코드가 학습자 코드와 두 줄 이상에서 다름(도구 결함) → 10(ii) 놓침.
- hint의 줄 번호나 따온 줄이 바뀐 줄과 다름(도구 결함) → 10(iii)/(iv) 놓침.
- O가 틀리고 N이 맞음 / O가 맞고 N이 틀림 → 1: 저장된 N만 매김(N이 틀리면 11 틀림).
- 모델이 C · O · N을 다시 써서 읽기가 마지막 글을 씀 → 1 · 13: 저장된 문항만 매김.
- 바꾼 코드가 5초 안에 끝나지 않음 → 3: (가) 놓침 · A 틀림(범위 규칙으로 dev 951 + 330 변형에서 0번).
- 바꾼 결과가 node에서 여러 줄로 펼쳐짐(배열 7개 이상 등) → 3의 결과 그대로; 읽기가 그런 줄을 거르므로 저장된 문항이 있으면 11로 매김.

# 보고서

# 꼬리표 B: 비슷한 코드 자리 20개 (도구 결과)

도구(⚙)가 센 것과 판정자(✎)가 볼 것을 자리마다 적었습니다. 모델 이름 · 토큰 · 시간은 없습니다.

## c1 (Q1의 1번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const sizes = [20, 25, 30];
function areaOf(cm) {
  const r = cm / 2;
  return Math.round(Math.PI * r * r);
}
for (const size of sizes) {
  console.log(size + 'cm 피자: ' + areaOf(size) + '㎠');
}
```
학습자 결과(조항 3, 얼린 것):
```
20cm 피자: 314㎠
25cm 피자: 491㎠
30cm 피자: 707㎠
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const sizes = [40, 25, 30];
function areaOf(cm) {
  const r = cm / 2;
  return Math.round(Math.PI * r * r);
}
for (const size of sizes) {
  console.log(size + 'cm 피자: ' + areaOf(size) + '㎠');
}
```
````
hint:
````
바뀐 곳은 1번째 줄 `const sizes = [40, 25, 30];`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
40cm 피자: 1257㎠
25cm 피자: 491㎠
30cm 피자: 707㎠
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
40cm 피자: 1257㎠
25cm 피자: 491㎠
30cm 피자: 707㎠
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c2 (Q1의 2번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
def mode_label(mode):
    if mode == 'hard':
        return '어려움: 점수 2배'
    if mode == 'easy':
        return '쉬움: 기본 점수'
    return '알 수 없는 모드'
for m in ['hard', 'easy', 'zen']:
    print(m, '→', mode_label(m))
```
학습자 결과(조항 3, 얼린 것):
```
hard → 어려움: 점수 2배
easy → 쉬움: 기본 점수
zen → 알 수 없는 모드
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
def mode_label(mode):
    if mode == 'hard':
        return '어려움: 점수 2배'
    if mode == 'easy':
        return '쉬움: 기본 점수'
    return '알 수 없는 모드'
for m in ['expert', 'easy', 'zen']:
    print(m, '→', mode_label(m))
```
````
hint:
````
바뀐 곳은 7번째 줄 `for m in ['expert', 'easy', 'zen']:`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
expert → 알 수 없는 모드
easy → 쉬움: 기본 점수
zen → 알 수 없는 모드
````
kind predict · rung changed · 펜스 이름 'python' → 언어 py
### 보인 코드를 돌린 결과(조항 3)
```
expert → 알 수 없는 모드
easy → 쉬움: 기본 점수
zen → 알 수 없는 모드
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c3 (Q1의 3번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const books = [
  { title: '어린 왕자', pages: 120 },
  { title: '모모', pages: 300 },
  { title: '데미안', pages: 340 },
];
console.log(books[1].title);
let longest = books[0];
for (const b of books) {
  if (b.pages > longest.pages) {
    longest = b;
  }
}
console.log('가장 긴 책: ' + longest.title);
```
학습자 결과(조항 3, 얼린 것):
```
모모
가장 긴 책: 데미안
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const books = [
  { title: '어린 왕자', pages: 120 },
  { title: '모모', pages: 400 },
  { title: '데미안', pages: 340 },
];
console.log(books[1].title);
let longest = books[0];
for (const b of books) {
  if (b.pages > longest.pages) {
    longest = b;
  }
}
console.log('가장 긴 책: ' + longest.title);
```
````
hint:
````
바뀐 곳은 3번째 줄 `{ title: '모모', pages: 400 },`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
모모
가장 긴 책: 모모
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
모모
가장 긴 책: 모모
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c4 (Q2의 1번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const laps = [62.4, 59.8, 61.2, 60.5];
let best = Infinity;
for (const t of laps) {
  if (t < best) {
    best = t;
  }
}
console.log('최고 기록: ' + best + '초');
console.log(best < Infinity);
```
학습자 결과(조항 3, 얼린 것):
```
최고 기록: 59.8초
true
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const laps = [62.4, 59.8, 61.2, 60.5];
let best = Infinity;
for (const t of laps) {
  if (t >= best) {
    best = t;
  }
}
console.log('최고 기록: ' + best + '초');
console.log(best < Infinity);
```
````
hint:
````
바뀐 곳은 4번째 줄 `if (t >= best) {`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
최고 기록: Infinity초
false
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
최고 기록: Infinity초
false
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c5 (Q2의 2번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
results = [('민지', 88), ('준호', 95), ('서연', 79)]
best = results[0]
for item in results:
    if item[1] > best[1]:
        best = item
best_name, best_score = best
print('최고 점수:', best_name, best_score)
```
학습자 결과(조항 3, 얼린 것):
```
최고 점수: 준호 95
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
results = [('민지', 88), ('준호', 95), ('서연', 79)]
best = results[0]
for item in results:
    if item[1] < best[1]:
        best = item
best_name, best_score = best
print('최고 점수:', best_name, best_score)
```
````
hint:
````
바뀐 곳은 4번째 줄 `if item[1] < best[1]:`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
최고 점수: 서연 79
````
kind predict · rung changed · 펜스 이름 'python' → 언어 py
### 보인 코드를 돌린 결과(조항 3)
```
최고 점수: 서연 79
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c6 (Q2의 3번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
function fillNick(user) {
  user.nick ||= '손님' + user.id;
  return user;
}
const users = [{ id: 1, nick: '하늘' }, { id: 2, nick: '' }];
const filled = users.map(fillNick);
console.log(filled);
```
학습자 결과(조항 3, 얼린 것):
```
[ { id: 1, nick: '하늘' }, { id: 2, nick: '손님2' } ]
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
function fillNick(user) {
  user.nick ||= '고객' + user.id;
  return user;
}
const users = [{ id: 1, nick: '하늘' }, { id: 2, nick: '' }];
const filled = users.map(fillNick);
console.log(filled);
```
````
hint:
````
바뀐 곳은 2번째 줄 `user.nick ||= '고객' + user.id;`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
[ { id: 1, nick: '하늘' }, { id: 2, nick: '고객2' } ]
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
[ { id: 1, nick: '하늘' }, { id: 2, nick: '고객2' } ]
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c7 (Q3의 1번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const hero = { name: '루나', level: 5, hp: 80 };
const bonus = { hp: 20 };
hero.hp = hero.hp + bonus.hp;
console.log(hero.name + ' 레벨 ' + hero.level);
console.log(hero);
console.log(typeof hero);
```
학습자 결과(조항 3, 얼린 것):
```
루나 레벨 5
{ name: '루나', level: 5, hp: 100 }
object
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const hero = { name: '밤비', level: 5, hp: 80 };
const bonus = { hp: 20 };
hero.hp = hero.hp + bonus.hp;
console.log(hero.name + ' 레벨 ' + hero.level);
console.log(hero);
console.log(typeof hero);
```
````
hint:
````
바뀐 곳은 1번째 줄 `const hero = { name: '밤비', level: 5, hp: 80 };`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
밤비 레벨 5
{ name: '밤비', level: 5, hp: 100 }
object
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
밤비 레벨 5
{ name: '밤비', level: 5, hp: 100 }
object
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c8 (Q3의 2번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
basket = {'apple': 3, 'pear': 2}
basket['grape'] = 5
basket['apple'] = basket['apple'] + 1
print(basket)
print(len(basket))
print('grape' in basket)
```
학습자 결과(조항 3, 얼린 것):
```
{'apple': 4, 'pear': 2, 'grape': 5}
3
True
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
basket = {'apple': 3, 'pear': 2}
basket['kiwi'] = 5
basket['apple'] = basket['apple'] + 1
print(basket)
print(len(basket))
print('grape' in basket)
```
````
hint:
````
바뀐 곳은 2번째 줄 `basket['kiwi'] = 5`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
{'apple': 4, 'pear': 2, 'kiwi': 5}
3
False
````
kind predict · rung changed · 펜스 이름 'python' → 언어 py
### 보인 코드를 돌린 결과(조항 3)
```
{'apple': 4, 'pear': 2, 'kiwi': 5}
3
False
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c9 (Q4의 2번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const PASS_LINE = 60;
const results = { 민지: 72, 준호: 58, 서연: 60 };
for (const name in results) {
  const score = results[name];
  if (score >= PASS_LINE) {
    console.log(name + ': 합격');
  } else {
    console.log(name + ': 불합격 (' + score + '점)');
  }
}
```
학습자 결과(조항 3, 얼린 것):
```
민지: 합격
준호: 불합격 (58점)
서연: 합격
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const PASS_LINE = 60;
const results = { 민지: 72, 준호: 58, 서연: 60 };
for (const name in results) {
  const score = results[name];
  if (score > PASS_LINE) {
    console.log(name + ': 합격');
  } else {
    console.log(name + ': 불합격 (' + score + '점)');
  }
}
```
````
hint:
````
바뀐 곳은 5번째 줄 `if (score > PASS_LINE) {`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
민지: 합격
준호: 불합격 (58점)
서연: 불합격 (60점)
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
민지: 합격
준호: 불합격 (58점)
서연: 불합격 (60점)
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c10 (Q4의 3번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
function lineTotal(item) {
  return item.price * item.qty;
}
const order = [
  { menu: '아메리카노', price: 4500, qty: 2 },
  { menu: '라테', price: 5000, qty: 1 },
];
let total = 0;
for (const item of order) {
  total += lineTotal(item);
  console.log(item.menu + ' x' + item.qty + ' = ' + lineTotal(item));
}
console.log('합계: ' + total + '원');
```
학습자 결과(조항 3, 얼린 것):
```
아메리카노 x2 = 9000
라테 x1 = 5000
합계: 14000원
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
function lineTotal(item) {
  return item.price * item.qty;
}
const order = [
  { menu: '아메리카노', price: 4500, qty: 3 },
  { menu: '라테', price: 5000, qty: 1 },
];
let total = 0;
for (const item of order) {
  total += lineTotal(item);
  console.log(item.menu + ' x' + item.qty + ' = ' + lineTotal(item));
}
console.log('합계: ' + total + '원');
```
````
hint:
````
바뀐 곳은 5번째 줄 `{ menu: '아메리카노', price: 4500, qty: 3 },`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
아메리카노 x3 = 13500
라테 x1 = 5000
합계: 18500원
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
아메리카노 x3 = 13500
라테 x1 = 5000
합계: 18500원
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c11 (Q5의 1번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
riders = [('하준', 135, 9), ('지우', 118, 7), ('도윤', 142, 12)]
for name, height, age in riders:
    if height >= 120 and age >= 8:
        print(name + ': 탑승 가능')
    else:
        print(name + ': 탑승 불가')
```
학습자 결과(조항 3, 얼린 것):
```
하준: 탑승 가능
지우: 탑승 불가
도윤: 탑승 가능
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
riders = [('서연', 135, 9), ('지우', 118, 7), ('도윤', 142, 12)]
for name, height, age in riders:
    if height >= 120 and age >= 8:
        print(name + ': 탑승 가능')
    else:
        print(name + ': 탑승 불가')
```
````
hint:
````
바뀐 곳은 1번째 줄 `riders = [('서연', 135, 9), ('지우', 118, 7), ('도윤', 142, 12)]`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
서연: 탑승 가능
지우: 탑승 불가
도윤: 탑승 가능
````
kind predict · rung changed · 펜스 이름 'python' → 언어 py
### 보인 코드를 돌린 결과(조항 3)
```
서연: 탑승 가능
지우: 탑승 불가
도윤: 탑승 가능
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c12 (Q5의 3번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const rows = ['A', 'B', 'C'];
const cols = [1, 2, 3, 4];
for (const r of rows) {
  let line = '';
  for (const c of cols) {
    line += r + c + ' ';
  }
  console.log(line.trim());
}
```
학습자 결과(조항 3, 얼린 것):
```
A1 A2 A3 A4
B1 B2 B3 B4
C1 C2 C3 C4
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const rows = ['A', 'B', 'C'];
const cols = [1, 2, 3, 9];
for (const r of rows) {
  let line = '';
  for (const c of cols) {
    line += r + c + ' ';
  }
  console.log(line.trim());
}
```
````
hint:
````
바뀐 곳은 2번째 줄 `const cols = [1, 2, 3, 9];`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
A1 A2 A3 A9
B1 B2 B3 B9
C1 C2 C3 C9
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
A1 A2 A3 A9
B1 B2 B3 B9
C1 C2 C3 C9
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c13 (Q6의 1번째 자리)

- 읽힌 문항 없음(조항 2 · 13). (가) 놓침, (나) 셈 밖. 판정자는 이 자리를 적지 않습니다.

## c14 (Q6의 3번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
def ship_fee(total, is_member):
    if total >= 30000 or is_member:
        return 0
    return 3000
orders = [(25000, False), (32000, False), (12000, True)]
for total, member in orders:
    print(str(total) + '원 배송비: ' + str(ship_fee(total, member)))
```
학습자 결과(조항 3, 얼린 것):
```
25000원 배송비: 3000
32000원 배송비: 0
12000원 배송비: 0
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
def ship_fee(total, is_member):
    if total < 30000 or is_member:
        return 0
    return 3000
orders = [(25000, False), (32000, False), (12000, True)]
for total, member in orders:
    print(str(total) + '원 배송비: ' + str(ship_fee(total, member)))
```
````
hint:
````
바뀐 곳은 2번째 줄 `if total < 30000 or is_member:`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
25000원 배송비: 0
32000원 배송비: 3000
12000원 배송비: 0
````
kind predict · rung changed · 펜스 이름 'python' → 언어 py
### 보인 코드를 돌린 결과(조항 3)
```
25000원 배송비: 0
32000원 배송비: 3000
12000원 배송비: 0
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c15 (Q7의 1번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const prices = { sword: 300, shield: 250, potion: 50 };
const cart = ['sword', 'potion', 'potion'];
let total = 0;
for (const item of cart) {
  total = total + prices[item];
}
console.log('총 가격: ' + total);
console.log(prices['shield']);
```
학습자 결과(조항 3, 얼린 것):
```
총 가격: 400
250
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const prices = { sword: 100, shield: 250, potion: 50 };
const cart = ['sword', 'potion', 'potion'];
let total = 0;
for (const item of cart) {
  total = total + prices[item];
}
console.log('총 가격: ' + total);
console.log(prices['shield']);
```
````
hint:
````
바뀐 곳은 1번째 줄 `const prices = { sword: 100, shield: 250, potion: 50 };`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
총 가격: 200
250
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
총 가격: 200
250
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c16 (Q7의 3번째 자리)

- 읽힌 문항 없음(조항 2 · 13). (가) 놓침, (나) 셈 밖. 판정자는 이 자리를 적지 않습니다.

## c17 (Q8의 2번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
correct = ['B', 'C', 'A', 'D']
marked = ['B', 'A', 'A', 'C']
wrong = []
for i in range(4):
    if marked[i] != correct[i]:
        wrong.append(str(i + 1))
print('틀린 문제: ' + ', '.join(wrong))
```
학습자 결과(조항 3, 얼린 것):
```
틀린 문제: 2, 4
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
correct = ['B', 'C', 'A', 'D']
marked = ['D', 'A', 'A', 'C']
wrong = []
for i in range(4):
    if marked[i] != correct[i]:
        wrong.append(str(i + 1))
print('틀린 문제: ' + ', '.join(wrong))
```
````
hint:
````
바뀐 곳은 2번째 줄 `marked = ['D', 'A', 'A', 'C']`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
틀린 문제: 1, 2, 4
````
kind predict · rung changed · 펜스 이름 'python' → 언어 py
### 보인 코드를 돌린 결과(조항 3)
```
틀린 문제: 1, 2, 4
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c18 (Q8의 3번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const todos = [
  { title: '장보기', done: true },
  { title: '빨래', done: false },
  { title: '운동', done: true },
];
let allDone = true;
for (const t of todos) {
  if (!t.done) {
    allDone = false;
    console.log('남은 일: ' + t.title);
  }
}
console.log(allDone);
```
학습자 결과(조항 3, 얼린 것):
```
남은 일: 빨래
false
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const todos = [
  { title: '장보기', done: false },
  { title: '빨래', done: false },
  { title: '운동', done: true },
];
let allDone = true;
for (const t of todos) {
  if (!t.done) {
    allDone = false;
    console.log('남은 일: ' + t.title);
  }
}
console.log(allDone);
```
````
hint:
````
바뀐 곳은 2번째 줄 `{ title: '장보기', done: false },`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
남은 일: 장보기
남은 일: 빨래
false
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
남은 일: 장보기
남은 일: 빨래
false
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c19 (Q9의 2번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const pet = { name: '콩이', kind: '강아지' };
console.log(Object.keys(pet).length);
pet.age = 3;
pet.weight = 4.2;
console.log(Object.keys(pet).length);
console.log(pet);
```
학습자 결과(조항 3, 얼린 것):
```
2
4
{ name: '콩이', kind: '강아지', age: 3, weight: 4.2 }
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const pet = { name: '콩이', kind: '강아지' };
console.log(Object.keys(pet).length);
pet.age = 9;
pet.weight = 4.2;
console.log(Object.keys(pet).length);
console.log(pet);
```
````
hint:
````
바뀐 곳은 3번째 줄 `pet.age = 9;`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
2
4
{ name: '콩이', kind: '강아지', age: 9, weight: 4.2 }
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
2
4
{ name: '콩이', kind: '강아지', age: 9, weight: 4.2 }
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c20 (Q9의 3번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
present = {'민지': True, '준호': False, '서연': True}
count = 0
for name, here in present.items():
    if here:
        count = count + 1
print(present['준호'])
print(type(present['민지']))
print(count, '명 출석')
```
학습자 결과(조항 3, 얼린 것):
```
False
<class 'bool'>
2 명 출석
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
present = {'민지': True, '준호': False, '서연': True}
count = 5
for name, here in present.items():
    if here:
        count = count + 1
print(present['준호'])
print(type(present['민지']))
print(count, '명 출석')
```
````
hint:
````
바뀐 곳은 2번째 줄 `count = 5`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
False
<class 'bool'>
7 명 출석
````
kind predict · rung changed · 펜스 이름 'python' → 언어 py
### 보인 코드를 돌린 결과(조항 3)
```
False
<class 'bool'>
7 명 출석
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

