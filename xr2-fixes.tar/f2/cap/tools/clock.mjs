// usage: node --experimental-transform-types clock.mjs <notes.ts path> <per> <clock scale>
// changedRunFor on one fixed input; Date.now runs `scale` times faster (a device that slow) when scale > 1.
const [, , notesPath, perArg, scaleArg] = process.argv
const scale = Number(scaleArg)
if (scale !== 1) { const real = Date.now.bind(Date); const t0 = real(); Date.now = () => t0 + (real() - t0) * scale }
const { changedRunFor } = await import(notesPath)
const per = Number(perArg)
const arr = (k, n) => `const d${k} = [${Array.from({ length: n }, (_, i) => (i % 7) + 1).join(', ')}]`
const loops = Number(process.argv[5] ?? 3000)
const code = [arr(0, per), 'let s = 0', `for (let i = 0; i < ${loops}; i++) { s = s + 1 }`, 'const price = 3', 'const count = 4', "console.log('합계:', price * count + s)"].join('\n')
const blurb = `배열 — \`${arr(0, per).slice(0, 12)}\``
const t = performance.now()
const r = changedRunFor(code, 'a.js', blurb)
console.log(JSON.stringify({ per, scale, chars: code.length, ms: Math.round(performance.now() - t), certs: r?.certs.map(c => [c.site.line + 1, c.site.token, c.value]) }))
