// cross-review 2 (robust-2-1): changedRunFor a9abb53 (clock cap) vs no clock, over the G2 wide-gate records (records only, 0 model calls).
// usage: cmp.mjs <head notes.ts> <new notes.ts> <count notes.ts> <records.jsonl>
import { readFileSync } from 'node:fs'
const [h, n, c, rec] = process.argv.slice(2)
const H = await import(h), N = await import(n), C = await import(c)
const rows = readFileSync(rec, 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l))
let same = 0, differ = 0, runs = 0, maxTries = 0, over = 0, slowHead = 0, maxMsHead = 0, maxMsNew = 0
const hist = {}
for (const r of rows) {
  const blurb = r.blurb || '— `x`'
  let t0 = performance.now()
  const a = H.changedRunFor(r.code, r.file, blurb)
  const msH = performance.now() - t0
  t0 = performance.now()
  const b = N.changedRunFor(r.code, r.file, blurb)
  const msN = performance.now() - t0
  globalThis.__tries = undefined
  C.changedRunFor(r.code, r.file, blurb)
  const tries = globalThis.__tries
  if (tries !== undefined) { runs++; maxTries = Math.max(maxTries, tries); if (tries >= N.CHANGED_RUN_TRIES) over++; const k = Math.min(100, Math.ceil(tries / 10) * 10); hist[k] = (hist[k] ?? 0) + 1 }
  maxMsHead = Math.max(maxMsHead, msH); maxMsNew = Math.max(maxMsNew, msN)
  if (JSON.stringify(a) === JSON.stringify(b)) same++
  else { differ++; console.log('DIFFER', r.id, tries) }
}
console.log(JSON.stringify({ records: rows.length, same, differ, withRun: runs, maxTries, reachedCap: over, triesHist: hist, maxMsHead: Math.round(maxMsHead), maxMsNew: Math.round(maxMsNew), cap: N.CHANGED_RUN_TRIES, capMs: N.CHANGED_RUN_MS ?? null }))
