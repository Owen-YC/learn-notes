// cross-review 2: find a code shape where the cap's edge (tries >= 80 vs > 80) changes the certified places.
const A = await import(process.argv[2]), B = await import(process.argv[3])
const f = r => r ? r.certs.map(c => c.site.token + '>' + c.value).join(' ') : 'undef'
for (const mod of [1, 2, 5, 9]) for (let per = 1; per <= 120; per++) {
  const arr = `const d = [${Array.from({ length: per }, (_, i) => mod * 10 + (i % 3)).join(', ')}]`
  const code = [arr, 'let t = 0', 'for (let i = 0; i < 10; i++) { t += 1 }', "console.log('합계:', t)"].join('\n')
  const blurb = `배열 — \`${arr.slice(0, 12)}\``
  const a = A.changedRunFor(code, 'a.js', blurb), b = B.changedRunFor(code, 'a.js', blurb)
  if (f(a) !== f(b)) { console.log(JSON.stringify({ mod, per, len: code.length, fixed: f(a), mC: f(b) })); }
}
