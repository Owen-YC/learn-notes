// cross-review 2: find a code shape where the cap's edge (tries >= 80 vs > 80) changes the certified places.
const A = await import(process.argv[2]), B = await import(process.argv[3])
const arr = (k, per) => `const d${k} = [${Array.from({ length: per }, (_, i) => (i % 7) + 1).join(', ')}]`
for (let n = 1; n <= 4; n++) for (let per = 1; per <= 40; per++) {
  const lines = []; for (let k = 0; k < n; k++) lines.push(arr(k, per))
  lines.push('let t = 0', 'for (let i = 0; i < 10; i++) { t += 1 }', "console.log('합계:', t)")
  const code = lines.join('\n'), blurb = `배열 — \`${arr(0, per).slice(0, 12)}\``
  const a = A.changedRunFor(code, 'a.js', blurb), b = B.changedRunFor(code, 'a.js', blurb)
  const f = r => r.certs.map(c => c.site.token + '>' + c.value).join(' ')
  if (f(a) !== f(b)) console.log(JSON.stringify({ n, per, fixed: f(a), mC: f(b) }))
}
