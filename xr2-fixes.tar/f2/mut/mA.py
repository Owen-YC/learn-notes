# mA: the clock cap back (a9abb53's two lines) on the fixed code
import sys
p=sys.argv[1]+'/hooks/notes.ts'; s=open(p,encoding='utf8').read()
a='  let tries = 1\n  const ran = newRun(text, lang, { printArgs: true })\n'; assert s.count(a)==1
s=s.replace(a,'  const until = Date.now() + 600\n'+a)
a='      if (tries >= CHANGED_RUN_TRIES) break places\n'; assert s.count(a)==1
s=s.replace(a,'      if (tries >= CHANGED_RUN_TRIES || Date.now() > until) break places\n')
open(p,'w',encoding='utf8').write(s); print('mA ok')
