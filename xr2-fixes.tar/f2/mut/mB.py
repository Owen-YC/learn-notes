# mB: no cap over the whole run at all
import sys
p=sys.argv[1]+'/hooks/notes.ts'; s=open(p,encoding='utf8').read()
a='      if (tries >= CHANGED_RUN_TRIES) break places\n'; assert s.count(a)==1
s=s.replace(a,'')
open(p,'w',encoding='utf8').write(s); print('mB ok')
