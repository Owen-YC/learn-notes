# Mutations for cross-review round 2. Each: (name, file, old, new). old must occur exactly once (on the fixed tree).
R = 'hooks/register.tsx'
GW = "      await $.env.get('CLAUDE_CODE_USE_GATEWAY'),\n"
MUTS = [
 ('G1-gatewayNotRead', R, GW, ''),
 ('G2-gatewayReadIgnored', R,
  GW + "    ]\n    if (providers.some(isSet)) return 'provider'",
  "    ]\n    await $.env.get('CLAUDE_CODE_USE_GATEWAY')\n    if (providers.some(isSet)) return 'provider'"),
 ('G3-gatewayOnlyWithAddress', R,
  GW,
  "      (await $.env.get('ANTHROPIC_BASE_URL')) ? await $.env.get('CLAUDE_CODE_USE_GATEWAY') : undefined,\n"),
 ('U1-oldParticleLines', R,
  "    `숫자부터 모두 ${open + 1}번 답이면: /learn 퀴즈 ${open + 1} ${flat(rest)}`,\n    ...(other && isOpen(current, other) ? [`숫자가 문제 번호면: /learn 퀴즈 ${n}번 ${flat(after)}`] : []),",
  "    `${open + 1}번 답이 \"${flat(rest)}\"라면: /learn 퀴즈 ${open + 1} ${flat(rest)}`,\n    ...(other && isOpen(current, other) ? [`${n}번 답이 \"${flat(after)}\"라면: /learn 퀴즈 ${n}번 ${flat(after)}`] : []),"),
 ('U2-secondLineDropped', R,
  "    ...(other && isOpen(current, other) ? [`숫자가 문제 번호면: /learn 퀴즈 ${n}번 ${flat(after)}`] : []),\n",
  ""),
 ('U3-readingsSwapped', R,
  "    `숫자부터 모두 ${open + 1}번 답이면: /learn 퀴즈 ${open + 1} ${flat(rest)}`,\n    ...(other && isOpen(current, other) ? [`숫자가 문제 번호면: /learn 퀴즈 ${n}번 ${flat(after)}`] : []),",
  "    `숫자가 문제 번호면: /learn 퀴즈 ${open + 1} ${flat(rest)}`,\n    ...(other && isOpen(current, other) ? [`숫자부터 모두 ${n}번 답이면: /learn 퀴즈 ${n}번 ${flat(after)}`] : []),"),
]
