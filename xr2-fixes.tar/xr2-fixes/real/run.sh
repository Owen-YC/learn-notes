#!/bin/bash
# runs every job of jobs.txt (tag|host|settings|VAR=v ...) through one.sh, 3 at a time, with the pinned CLI
A=/tmp/<model-id>/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/xr/fix2/real
P=/tmp/<model-id>/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh
job() { IFS='|' read -r tag host settings vars <<< "$1"; s=(); [ -n "$settings" ] && s=(--settings "$settings"); read -r -a v <<< "$vars"; "$P" "$A/one.sh" "$tag" "$host" "${s[@]}" -- "${v[@]}"; }
export -f job; export A P
grep -v '^$' "$A/jobs.txt" | xargs -d '\n' -P 3 -I{} bash -c 'job "$@"' _ {} > "$A/table.unsorted"
sort "$A/table.unsorted" > "$A/table-real.txt"
