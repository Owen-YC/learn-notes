#!/bin/bash
# usage: one.sh <tag> <host:keep|unset> [--settings JSON] [-- VAR=value ...]
# Online (a fresh config needs the network to start), isolated config and home, no model call (result modelUsage {} · num_turns 0 checked): '/learn 진단' answered by the mod itself; prints its 설정 line.
R=/tmp/<model-id>/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/xr/fix2/real
tag="$1"; host="$2"; shift 2
settings=()
if [ "$1" = "--settings" ]; then settings=(--settings "$2"); shift 2; fi
[ "$1" = "--" ] && shift
unset_host=()
[ "$host" = "unset" ] && unset_host=(-u CLAUDE_CODE_PROVIDER_MANAGED_BY_HOST)
w="$R/w/$tag"; mkdir -p "$w/cfg" "$w/home" "$w/proj"
cd "$w/proj" || exit 1
env "${unset_host[@]}" DISABLE_AUTOUPDATER=1 CLAUDE_CONFIG_DIR="$w/cfg" HOME="$w/home" "$@" timeout 150 claude -p --plugin-dir "$R/mod" --tools '' "${settings[@]}" --output-format stream-json --verbose '/learn 진단' < /dev/null > "$R/out/$tag.jsonl" 2>"$R/out/$tag.err"
python3 -I - "$R/out/$tag.jsonl" "$tag" <<'PY'
import sys, json
said = None; init = None
for line in open(sys.argv[1]):
    try: d = json.loads(line)
    except Exception: continue
    if d.get('type') == 'system' and d.get('subtype') == 'init': init = d.get('model')
    if d.get('type') == 'result':
        print('usage', json.dumps(d.get('modelUsage')), 'turns', d.get('num_turns'), 'cost', d.get('total_cost_usd'), end=' ')
        for l in str(d.get('result', '')).split('\n'):
            if l.startswith('- 설정:') or l.startswith('- 버전:'): said = (said or '') + l + ' | '
print(sys.argv[2], 'init', init, '\t', said)
PY
