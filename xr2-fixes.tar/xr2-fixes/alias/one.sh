#!/bin/bash
# usage: one.sh <tag> <alias> <host:keep|unset> [--settings JSON] [-- VAR=value ...]
# Offline (unshare -n): records the stream's system/init model only; no request can leave the machine.
S=/tmp/<model-id>/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/xr/fix2/alias
tag="$1"; alias="$2"; host="$3"; shift 3
settings=()
if [ "$1" = "--settings" ]; then settings=(--settings "$2"); shift 2; fi
[ "$1" = "--" ] && shift
unset_host=()
[ "$host" = "unset" ] && unset_host=(-u CLAUDE_CODE_PROVIDER_MANAGED_BY_HOST)
cd "$S/cwd" || exit 1
start=$(date +%s.%N)
env "${unset_host[@]}" DISABLE_AUTOUPDATER=1 "$@" timeout 45 unshare -n claude -p --model "$alias" --tools '' "${settings[@]}" --output-format stream-json --verbose ok 2>"$S/out/$tag.err" \
 | python3 -I -c '
import sys,json
for line in sys.stdin:
    try: d=json.loads(line)
    except Exception: continue
    if d.get("type")=="system" and d.get("subtype")=="init": print(d.get("model")); break
' > "$S/out/$tag.model"
end=$(date +%s.%N)
printf '%s\t%s\t%s\t%s\n' "$tag" "$alias" "$(cat "$S/out/$tag.model")" "$(python3 -c "print(round($end-$start,1))")"
