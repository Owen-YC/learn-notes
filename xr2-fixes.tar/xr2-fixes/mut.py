import sys
sys.path.insert(0, '/tmp/<model-id>/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/xr/fix2')
from muts import MUTS
d, n = sys.argv[1], sys.argv[2]
m = [x for x in MUTS if x[0] == n][0]
p = f'{d}/{m[1]}'; s = open(p).read(); c = s.count(m[2])
if c != 1: print('COUNT', c); sys.exit(1)
open(p, 'w').write(s.replace(m[2], m[3]))
