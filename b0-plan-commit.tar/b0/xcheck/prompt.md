You are a careful bilingual (English → Korean) checker. You did not write the Korean text. Do not edit any file. Only read and report.

Korean text to check: /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b0/sec112.md
It is a new section for a QA record file. It must translate English plan fields into Korean WITHOUT changing any number or clause (no clause added, dropped, weakened or strengthened; no number changed).

English sources (JSON; read the fields named):
- /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/plan112.json
  - calibration.commits[0] (what this section must contain), calibration.perBatchUse, calibration.settlesTheSonnetDiscrepancy, calibration.procedure, calibration.modelRecord, calibration.stop, calibration.calls, calibration.namesRegistry
  - order (sequence, why)
  - batches[1].jointBuildWithG3 (what, why, conflictRule), batches[*].d26Recheck, commonPerBatch.d26Procedure
  - notMeasured (rule, cells[*] reason/evidence/whatWouldHaveToChange/designName, conditional, recordIn견본)
  - base.installedCli, base.cliPin, base.commitNumbering
  - commonPerBatch.usageGate, commonPerBatch.cutStageRule, commonPerBatch.runnerRules, commonPerBatch.backup
  - ownerQuestions (q, default), ownerQuestionsRule
- Design files for the per-cell dev evidence lines: /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/design/G1.json, G2.json, G3.json, G4.json, G5.json (fields perModel, recommend.evidence, pilot).

Facts the Korean text adds that are NOT in the plan (they record work already done; check only that they do not contradict the plan): pinned CLI copy time, sha256 values and wrapper; names registry line count, sha256, per-tag counts and script hashes; the note that the 205-name avoid file no longer exists.

Method: go through the Korean section by section. For every sentence, find its English source and compare: numbers, comparison signs (≤, <, ≥, ≠), model names, batch numbers, conditions (if/only if/otherwise), lists (every item present), and meaning. Also check that every item calibration.commits[0].content asks for is present, and that every notMeasured cell and every owner question is present.

Report, in Korean, a numbered list of findings. For each: the Korean line (quote a short piece), the English source field, what differs, and a suggested corrected Korean wording. Classify each as 'number', 'clause', 'missing', 'added', or 'wording'. If you find nothing in a section, say so in one line. End with one line: 'FINDINGS: <n>'.
