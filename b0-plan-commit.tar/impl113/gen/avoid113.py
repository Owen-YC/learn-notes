"""learn-notes 1.13.0 frozen avoid builder (plan calibration.avoidBuilder), made in batch 0 from
impl112/b3r/gen/avoid.py (a1aeca10…0e5f). The writers' avoid section, from the 1.13.0 registry as it stands when a
writer stage starts (env NAMES, default impl113/NAMES-all.txt; its sha256 is printed and kept with the stage), plus
impl111/b7/gen/names.json (1.8.0, 1.9.0 file and function names). Three lists:
- (a) concept names: only from rows whose tag is not '견본' (record files); the topic before ': ' of a dev name,
  2-30 characters, Hangul, not a file, not starting with a quote (as avoid.py). '견본' rows never give a concept.
- (c) files (an entry with a code or document extension, its last path part) and code names (an identifier of 3+
  characters, not an id like K01 or pT01) come from record-file rows (tag != '견본') and names.json. A '견본' row gives a
  file or code name only if it holds no whitespace, no path part equals one of SKIPDIRS or b<digits> / b<digits>r /
  impl11<digit>, and its last path part is not a file name listed in any tools.sha256 / SHA256SUMS table under impl111,
  impl112 or impl113 (the tool-name list, built here at run time and hashed with this builder). A '견본' entry holding
  whitespace (a prose fragment) is never used.
- (c') a file name equal to a tool-name-list entry is left out of the file list whatever row it came from (record rows
  hold check.py, report.py and tally.py, which are also measurement-tool names). This resolves the conflict between
  (c) and the plan's synthetic test (1) ('0 hits for any tool-table file name') toward test (1); the registry keeps
  those rows, so the freeze-time path and name checks still reject a sample that reuses them.
- (b) every entry (concept, file or code name, from any row) that matches WORDS, case-insensitive, is dropped
  (avoid.py's WORDS plus isChanged, stance, judge, verdict, calib, impl11).
Sorted, joined with ' · '. The avoid section text is avoid.py's, unchanged.
usage: NAMES=<registry> python3 -I avoid113.py <out.md> <names.txt out> [<toolnames.txt out>]
  (refuses to overwrite; the second file keeps the three lists, one a line; the third, if given, the tool-name list)
Prints JSON: counts, the registry's sha256, the tool-name list's sha256 and the tables it was built from."""
import glob, hashlib, json, os, re, sys

SP = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad"
NAMES = os.environ.get("NAMES") or SP + "/impl113/NAMES-all.txt"
OLD = SP + "/impl111/b7/gen/names.json"
IDENT = re.compile(r"^[A-Za-z_$][\w$]*$")
ID = re.compile(r"^[A-Za-z]{1,4}\d+[A-Za-z]?\d*$")
FILE = re.compile(r"^[\w./@-]+\.(js|mjs|cjs|ts|mts|cts|tsx|jsx|py|json|md|css|scss|html|go|rb|sh|vue|txt|yml|yaml|toml)$")
HANGUL = re.compile(r"[가-힣]")
WORDS = re.compile(r"(?i)haiku|sonnet|opus|fable|claude|anthropic|model|isRule|rung|isThink|isBase|isChanged|worked|stance|judge|verdict|calib|impl11|alias|gateway|bedrock|vertex|override|provider|모델|채점|견본|판정|프롬프트")
SKIPDIRS = {"judge", "tools", "calib", "gen", "stage", "frozen", "pilot", "audit", "review", "fix", "sw", "cli", "probe",
            "d26", "oldprobe", "proofs", "design"}
SKIPDIR_RX = re.compile(r"^(b\d+|b\d+r|impl11\d)$")


def tool_tables():
    out = []
    for base in ("impl111", "impl112", "impl113"):
        for name in ("tools.sha256", "SHA256SUMS"):
            out += glob.glob(f"{SP}/{base}/**/{name}", recursive=True)
    return sorted(set(out))


def tool_names(tables):
    names = set()
    for t in tables:
        for line in open(t, encoding="utf-8", errors="replace"):
            parts = line.strip().split(None, 1)
            if len(parts) == 2 and re.fullmatch(r"[0-9a-f]{64}", parts[0]):
                names.add(parts[1].lstrip("*").rsplit("/", 1)[-1])
    return sorted(n for n in names if n)


def gyeonbon_ok(n, tnames):
    if re.search(r"\s", n):
        return False
    parts = [p for p in n.split("/") if p]
    if any(p in SKIPDIRS or SKIPDIR_RX.match(p) for p in parts):
        return False
    return (parts[-1] if parts else n) not in tnames


def lists(tnames):
    rows = [l.rstrip("\n").split("\t") for l in open(NAMES, encoding="utf-8") if l.strip()]
    old = json.load(open(OLD, encoding="utf-8"))
    tset = set(tnames)
    src = [r[0] for r in rows if (r[1] if len(r) > 1 else "") != "견본"]
    src += [r[0] for r in rows if (r[1] if len(r) > 1 else "") == "견본" and gyeonbon_ok(r[0], tset)]
    files = sorted({r.rsplit("/", 1)[-1] for r in src + old["files"] if FILE.match(r)} - tset)
    names = sorted({r for r in src + old["functions"] if IDENT.match(r) and len(r) >= 3 and not ID.match(r)})
    concepts = set()
    for r in rows:
        n, tag = r[0], (r[1] if len(r) > 1 else "")
        if tag == "견본" or not HANGUL.search(n) or FILE.match(n):
            continue
        n = n.split(": ")[0].strip()
        if 2 <= len(n) <= 30 and n[0] not in "'\"`":
            concepts.add(n)
    keep = lambda xs: [x for x in xs if not WORDS.search(x)]
    return keep(sorted(concepts)), keep(files), keep(names)


def section(concepts, files, names):
    q = lambda xs: " · ".join(f"`{x}`" for x in xs)
    return ("\nNames already used by earlier sample sets. Do not use any of these concept names as a record's name, and do not"
            " write a record about any of these concepts; do not use any of these file names as a record's file name (the last"
            " part of its path); do not name a function or class you define with any of these code names.\n\n- concept names: "
            + q(concepts) + "\n- file names: " + q(files) + "\n- code names: " + q(names) + "\n")


if __name__ == "__main__":
    outs = sys.argv[1:4]
    if len(outs) < 2:
        sys.exit(__doc__)
    for p in outs:
        if os.path.exists(p):
            sys.exit(f"refuse: {p} exists")
    tables = tool_tables()
    tnames = tool_names(tables)
    concepts, files, names = lists(tnames)
    open(outs[0], "w", encoding="utf-8").write(section(concepts, files, names))
    open(outs[1], "w", encoding="utf-8").write("\n".join(["# concepts"] + concepts + ["# files"] + files + ["# names"] + names) + "\n")
    tl = "\n".join(tnames) + "\n"
    if len(outs) > 2:
        open(outs[2], "w", encoding="utf-8").write(tl)
    print(json.dumps({"concepts": len(concepts), "files": len(files), "names": len(names),
                      "NAMES": NAMES, "NAMES_sha256": hashlib.sha256(open(NAMES, "rb").read()).hexdigest(),
                      "toolTables": [os.path.relpath(t, SP) for t in tables], "toolNames": len(tnames),
                      "toolNames_sha256": hashlib.sha256(tl.encode("utf-8")).hexdigest()}, ensure_ascii=False))
