"""Synthetic tests of the frozen avoid builder (plan calibration.avoidBuilder.test), learn-notes 1.13.0. Model calls: none.
usage: python3 -I avoidtest113.py <dir with section.md lists.txt toolnames.txt> <NAMES registry used> [<frame.md> ...]
(1) each assembled writer prompt (a frame + the avoid section) has 0 case-insensitive hits for the (b) pattern and 0
    hits for any tool-name-list file name (as a whole backticked or space/punctuation-delimited token). With no frame
    given, a neutral synthetic frame is used (batch 0 has no writers; each bar commit passes its batch's real frames).
(2) the seven 견본 lines named in namesRegistry.verify (4), and every whitespace-holding entry of a 견본 row, are absent
    from all three lists, except an entry that is also the concept name of a record-file row (tag != '견본'), which
    filter (a) takes from that row (counted and reported separately).
(3) for each '<G>-dev-113' tag: one record-file concept name, one file name and one code name of that tag are present
    (a kind the tag has no eligible entry of is reported as n/a, not as a pass).
Prints JSON and exits 1 on any failure."""
import json, re, sys

WORDS = re.compile(r"(?i)haiku|sonnet|opus|fable|claude|anthropic|model|isRule|rung|isThink|isBase|isChanged|worked|stance|judge|verdict|calib|impl11|alias|gateway|bedrock|vertex|override|provider|모델|채점|견본|판정|프롬프트")
FILE = re.compile(r"^[\w./@-]+\.(js|mjs|cjs|ts|mts|cts|tsx|jsx|py|json|md|css|scss|html|go|rb|sh|vue|txt|yml|yaml|toml)$")
IDENT = re.compile(r"^[A-Za-z_$][\w$]*$")
ID = re.compile(r"^[A-Za-z]{1,4}\d+[A-Za-z]?\d*$")
HANGUL = re.compile(r"[가-힣]")
SEVEN = ["calib/hm-sonnet.json", "haiku 줄을 다시 모두 끔", "isRuleWide", "judge/stance-G5.md", "sonnet 줄에 isRuleDrill도 켬",
         "tools/stance.py", "판정은 얼린 n2judge.mjs가 기계로 했습니다"]
NEUTRAL = "Write ten short sample records as JSON. Each record has a name, a file and a small piece of code.\n"

d, reg = sys.argv[1], sys.argv[2]
frames = sys.argv[3:]
section = open(d + "/section.md", encoding="utf-8").read()
L = open(d + "/lists.txt", encoding="utf-8").read().split("\n")
concepts = L[L.index("# concepts") + 1:L.index("# files")]
files = L[L.index("# files") + 1:L.index("# names")]
names = [x for x in L[L.index("# names") + 1:] if x]
allx = set(concepts) | set(files) | set(names)
tnames = [x for x in open(d + "/toolnames.txt", encoding="utf-8").read().split("\n") if x]
fails, out = [], {}

prompts = [(f, open(f, encoding="utf-8").read() + section) for f in frames] or [("synthetic-neutral", NEUTRAL + section)]
t1 = []
for f, p in prompts:
    hits = sorted(set(m.group(0) for m in WORDS.finditer(p)))
    toks = set(re.findall(r"[\w./@-]+", p))
    th = sorted(t for t in tnames if t in toks and FILE.match(t))
    t1.append({"prompt": f, "patternHits": hits[:10], "toolNameHits": th[:10]})
    if hits or th:
        fails.append(f"(1) {f}")
out["test1"] = t1

rows = [l.rstrip("\n").split("\t") for l in open(reg, encoding="utf-8") if l.strip()]
gb_ws = sorted({r[0] for r in rows if r[1] == "견본" and re.search(r"\s", r[0])})
present7 = [s for s in SEVEN if s in allx or s in section]
# a whitespace-holding 견본 entry may be present only as the concept name of a record-file row (the same sample name
# quoted in 견본.md and kept in a dev or measured record); anything else came from 견본 prose and fails.
rec_concepts = set()
for r in rows:
    if r[1] != "견본" and HANGUL.search(r[0]) and not FILE.match(r[0]):
        rec_concepts.add(r[0].split(": ")[0].strip())
present_rec = [s for s in gb_ws if s in allx and s in rec_concepts]
present_ws = [s for s in gb_ws if s in allx and s not in rec_concepts]
out["test2"] = {"seven": SEVEN, "sevenPresent": present7, "gyeonbonWhitespaceEntries": len(gb_ws),
                "presentAsRecordConcept": len(present_rec), "presentFromGyeonbonOnly": present_ws[:10]}
if present7 or present_ws:
    fails.append("(2)")

t3 = {}
for tag in sorted({r[1] for r in rows if r[1].endswith("-dev-113")}):
    mine = [r[0] for r in rows if r[1] == tag]
    c = [n.split(": ")[0].strip() for n in mine if HANGUL.search(n) and not FILE.match(n)]
    c = [x for x in c if 2 <= len(x) <= 30 and x[0] not in "'\"`" and not WORDS.search(x)]
    fl = [n.rsplit("/", 1)[-1] for n in mine if FILE.match(n)]
    fl = [x for x in fl if not WORDS.search(x) and x not in tnames]
    nm = [n for n in mine if IDENT.match(n) and len(n) >= 3 and not ID.match(n) and not WORDS.search(n)]
    res = {}
    for kind, cand, pool in (("concept", c, set(concepts)), ("file", fl, set(files)), ("code", nm, set(names))):
        if not cand:
            res[kind] = "n/a"
        else:
            got = next((x for x in sorted(cand) if x in pool), None)
            res[kind] = ("present: " + got) if got else "MISSING"
            if not got:
                fails.append(f"(3) {tag} {kind}")
    t3[tag] = res
out["test3"] = t3
out["fails"] = fails
print(json.dumps(out, ensure_ascii=False, indent=1))
sys.exit(1 if fails else 0)
