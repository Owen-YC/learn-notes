#!/bin/bash
# learn-notes 1.13.0 G6 design pilot: one fresh blind dev-sample writer (records only, B-12).
# usage: run.sh <set> <part A|B|C|D>
# prompt = gen/common.md (1.12.0 b1 writer frame, unchanged) + gen/set<set>-part-<part>.md + the avoid section (names only,
# from impl113/NAMES-all.txt), on stdin to `claude -p --model opus --tools ''` in an empty dir (installed CLI,
# DISABLE_AUTOUPDATER=1). The writer never sees a prompt, the rule drill code, the stance, the design or which model runs.
G=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6/dev
N=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/NAMES-all.txt
SET="$1"; PART="$2"
O="${G:?}/gen/out/set$SET-$PART"
[ -e "$O" ] && { echo "refuse: $O exists"; exit 1; }
mkdir -p "$O" "${G:?}/work/gen-$SET-$PART"
python3 -I - "$N" "$O/avoid.md" <<'PY'
import re, sys
CODE = re.compile(r"^([A-Za-z_$][A-Za-z0-9_$.]*|[A-Za-z0-9_./$-]+/[A-Za-z0-9_./$-]+)$")
names = sorted({l.split("\t", 1)[0] for l in open(sys.argv[1], encoding="utf-8") if l.strip() and CODE.match(l.split("\t", 1)[0])})
open(sys.argv[2], "w", encoding="utf-8").write("\n## 피할 이름 (함수 · 파일 이름, 경로로 쓰지 마라)\n\n" + ", ".join(names) + "\n")
print(len(names))
PY
cat "${G:?}/gen/common.md" "${G:?}/gen/set$SET-part-$PART.md" "$O/avoid.md" > "$O/prompt.md"
sha256sum "$O/prompt.md" > "$O/prompt.sha256"
cd "${G:?}/work/gen-$SET-$PART" || exit 1
export DISABLE_AUTOUPDATER=1
date -u +%FT%TZ > "$O/started.txt"
timeout 2400 claude -p --model opus --tools "" --output-format json < "$O/prompt.md" > "$O/out.json" 2> "$O/err.txt"
echo "exit=$?" > "$O/exit.txt"
date -u +%FT%TZ > "$O/ended.txt"
python3 -I - "$O" <<'PY'
import json, sys
o = sys.argv[1]
d = json.load(open(o + "/out.json", encoding="utf-8"))
open(o + "/result.txt", "w", encoding="utf-8").write(d.get("result") or "")
print("writer", o, "is_error", d.get("is_error"))
PY
