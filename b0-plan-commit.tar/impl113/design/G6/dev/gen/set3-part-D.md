
## 이번에 쓸 견본: 10개 (id E3D01 ~ E3D10)

trap 견본(kind "trap")은 `"trap": "module | test | script | export | config"` 칸을 더한다. violations는 빈 배열이다.

| id | kind | 꼴 |
| --- | --- | --- |
| E3D01 | trap (module) | 팀 모듈 자신을 고침(js 또는 ts): 위 표의 모듈 파일 하나(그 경로)가 안에서 그 규칙의 표지를 씀. 규칙은 네가 고른다 |
| E3D02 | trap (module) | 팀 모듈 자신을 고침(py): 위 표의 py 모듈 파일 하나가 안에서 그 규칙의 표지를 씀. 규칙은 네가 고른다 |
| E3D03 | trap (test) | 테스트 파일(새 파일)이 표지를 씀. 테스트 틀 없이 `export function`이나 `def` 꼴 |
| E3D04 | trap (script) | 빌드 · 도구 스크립트(앱 코드가 아닌 곳, 예: 스크립트 폴더)가 표지를 씀. `export function`이나 `def` 꼴 |
| E3D05 | trap (export) | 팀 모듈이 아닌 앱 모듈 하나(예: `src/utils/` 아래 파일)가 규칙의 쓰라는 이름과 같은 이름을 export하고, 그 안에서 표지를 씀 |
| E3D06 | trap (config) | 이름에 `.config.`가 든 설정 파일(예: `something.config.js`)이 `process.env`를 읽음 |
| E3D07 · E3D08 | multi | 서로 다른 두 규칙을 어긴 줄 둘(각각 들여쓰기 빼고 40자 이하). violations 둘. 두 규칙의 팀 모듈을 그 파일이 이미 import함 |
| E3D09 · E3D10 | double | 같은 규칙 하나를 어긴 줄 둘(각각 들여쓰기 빼고 40자 이하, 서로 다른 줄). violations 둘. 그 팀 모듈을 그 파일이 이미 import함 |

- multi · double의 lang은 네가 고르되 서로 다르게, 규칙도 고루 섞이게 한다.
- 요청 견본은 `responses`에 그 주소의 JSON을 준다. 설정 견본은 `env`에 그 이름의 값을 준다.
