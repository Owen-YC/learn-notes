"""Mutation probes on the 1.13.0 G6 prototype (each in a fresh copy of proto/repo; the named test file must fail)."""
import json, os, re, shutil, subprocess, sys
G = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6"
MUTS = [
  ("M1 cap also lowers 거의/틀림", "hooks/register.tsx", "build.isRuleDrill && sent.rule !== undefined && parsed.verdict === 'right' ?", "build.isRuleDrill && sent.rule !== undefined && parsed.verdict !== undefined ?", "flow110.test.ts"),
  ("M2 drop the f-string prefix handling", "hooks/notes.ts", "const isF = pre !== undefined && /f/i.test(pre)", "const isF = false", "rulecap.test.ts"),
  ("M3 drop the kwarg skip", "hooks/notes.ts", "    if (lang !== 'js' && /^=(?!=)/.test(after) && (before.match(/\\(/g)?.length ?? 0) > (before.match(/\\)/g)?.length ?? 0)) continue\n", "", "rulecap.test.ts"),
  ("M4 drop the file's names from the known set", "hooks/notes.ts", "  for (const m of (file ?? '').matchAll(CAP_NAME)) words.add(m[0])\n", "", "rulecap.test.ts"),
  ("M5 destructuring branch accepts f(process.env)", "hooks/notes.ts", "const DESTRUCTURE_HEAD = /^\\s*(?:const|let|var)\\s*\\{[^{}]*\\}\\s*=\\s*$/", "const DESTRUCTURE_HEAD = /^.*$/", "rulefix.test.ts"),
  ("M6 parse takes the first answer", "hooks/notes.ts", "const got = isSaidOnce ? all : answers[answers.length - 1]!", "const got = isSaidOnce ? all : answers[0]!", "rulefix.test.ts"),
  ("M7 list unanchored lines for a no-avoid rule", "hooks/notes.ts", "...(isNoAvoid ? [] : found.filter", "...(false ? [] : found.filter", "rulefix.test.ts"),
  ("M8 drop the same-shape swap", "hooks/notes.ts", "    if (isShape && moved.length > 0 && !isReorder) return { why: 'swap', from: moved[0]!.from, to: moved[0]!.to }\n", "", "rulecap.test.ts"),
  ("M9 a reorder of the example's own entries is a swap", "hooks/notes.ts", "const isReorder = isShape && moved.length > 0 && isLooseReorder(a, b, moved.map(one => one.at), lang)", "const isReorder = false", "rulecap.test.ts"),
  ("M10 a duplicate of the example's own entry is a reorder (set, not multiset)", "hooks/notes.ts", "  if (sorted(ea.list) !== sorted(eb.list)) return false\n", "  if (!eb.list.every(one => ea.list.includes(one))) return false\n", "rulecap.test.ts"),
  ("M11 the old way is any name the example dropped (not only the rule's avoid names)", "hooks/notes.ts", "find(name => roots.has(name) && !exWords.has(name)", "find(name => !exWords.has(name)", "rulecap.test.ts"),
  ("M12 a reorder anywhere is no swap (a call's places too)", "hooks/notes.ts", "  if (open === -1 || (a[open]!.text !== '{' && !(a[open]!.text === '(' && lang === 'py'))) return false\n", "  if (open === -1) return false\n", "rulecap.test.ts"),
  ("M12b a spread entry reordered in { … } is no swap", "hooks/notes.ts", "  if (a[open]!.text === '{') return ea.list.every(one => !one.startsWith('mark:. mark:. mark:.'))\n", "  if (a[open]!.text === '{') return true\n", "rulecap.test.ts"),
  ("M18 a Python call's positional entries reordered are no swap", "hooks/notes.ts", "  return ea.list.every((one, i) => one === eb.list[i] || (/^name:\\S+ mark:= /.test(one) && !/^name:\\S+ mark:= mark:= /.test(one)))\n", "  return true\n", "rulecap.test.ts"),
  ("M19 a spread read as a member (its name never looked up)", "hooks/notes.ts", "(before.endsWith('.') && !(lang !== 'py' && before.endsWith('...')))", "before.endsWith('.')", "rulecap.test.ts"),
  ("M13 string escapes not read", "hooks/notes.ts", "const text = prefix.includes('r') ? body : body.replace(/\\\\(.)/gsu, '$1')", "const text = body", "rulecap.test.ts"),
  ("M14 a function's parameters not bound", "hooks/notes.ts", "  for (const m of code.matchAll(/\\bfunction\\b\\s*\\*?\\s*(?:[\\p{L}_$][\\p{L}\\p{N}_$]*)?\\s*\\(([^()]*)\\)/gu)) bind(m[1]!)\n", "", "rulecap.test.ts"),
  ("M15 a cap's code not cut", "hooks/notes.ts", "[...text].length > RULE_CAP_CODE ?", "false ?", "rulecap.test.ts"),
  ("M16 a try again not held to the cap", "hooks/register.tsx", "build.isRuleDrill && sent.rule !== undefined && parsed.verdict === 'right' ?", "build.isRuleDrill && sent.rule !== undefined && parsed.verdict === 'right' && first === undefined ?", "flow110.test.ts"),
  ("M17 no avoid names passed at grading (team file not read)", "hooks/register.tsx", "const avoids = use === undefined || team === undefined ? [] : ruleAvoidsOf(team.rules, use)", "const avoids: string[] = []", "flow110.test.ts"),
]
only = sys.argv[1:] 
res = []
for name, f, a, b, test in MUTS:
    if only and name.split()[0] not in only:
        continue
    d = f"{G}/final/mut/{name.split()[0]}"
    shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(f"{G}/proto/repo", d, ignore=shutil.ignore_patterns(".git"))
    p = f"{d}/{f}"
    s = open(p, encoding="utf-8").read()
    assert s.count(a) == 1, (name, s.count(a))
    open(p, "w", encoding="utf-8").write(s.replace(a, b))
    out = subprocess.run(["/opt/claude-code/bin/claude", "plugin", "test", "--file", f"{d}/tests/{test}", d], capture_output=True, text=True, timeout=1200); out = out.stdout + out.stderr
    open(f"{G}/final/mut/{name.split()[0]}.out", "w", encoding="utf-8").write(out)
    # The summary lines (`(fail) <title>`, ` N fail`) are read; the JSON report can be cut in a long run.
    fails = [l[7:].rsplit(" [", 1)[0].split(" > ")[-1][:90] for l in out.split("\n") if l.startswith("(fail)")]
    nfail = [l for l in out.split("\n") if l.strip().endswith(" fail") and l.strip().split()[0].isdigit()]
    if not fails and nfail and nfail[-1].strip().split()[0] != "0": fails = [nfail[-1].strip()]
    if not fails:
        i = out.find("claude-plugin-test-report ")
        try:
            rep, _ = json.JSONDecoder().raw_decode(out[i + 26:].replace("\n", ""))
            fails = [r["title"].split(" > ")[-1][:90] for r in rep["results"] if r["failure"]]
        except Exception:
            # A cut report: each result's failure field read where it stands.
            fails = [f"failure at {m.start()}" for m in re.finditer(r'"failure"\s*:\s*(?!null)', out)]
    res.append({"mutation": name, "test": test, "caught": len(fails) > 0, "failing": fails})
    print(json.dumps(res[-1], ensure_ascii=False), flush=True)
    shutil.rmtree(d, ignore_errors=True)
json.dump(res, open(f"{G}/final/mut/result-{'-'.join(only) or 'all'}.json", "w"), ensure_ascii=False, indent=1)
