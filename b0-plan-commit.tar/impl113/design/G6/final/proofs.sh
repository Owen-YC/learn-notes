#!/bin/bash
# final proofs (records): mutation probes, then D26 isRuleWide (639 cases), then G2 haiku 9/9
G=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6
export DISABLE_AUTOUPDATER=1
cd $G/final && python3 mut.py > mut/mut.log 2>&1; echo mut=$? >> $G/final/proofs.status
rm -rf $G/final/d26; node --experimental-transform-types --no-warnings /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/d26/rulewide.mjs $G/proto/repo $G/final/d26 --extra /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1/audit/d26x/extra.json > $G/final/d26.log 2> $G/final/d26.err; echo d26=$? >> $G/final/proofs.status
rm -rf $G/final/g2; python3 $G/proofs/remake-g2.py /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/frozen $G/final/g2 > $G/final/g2.log 2>&1; echo g2=$? >> $G/final/proofs.status
echo ALLDONE >> $G/final/proofs.status
