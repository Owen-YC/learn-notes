const N = await import('/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6/proto/repo/hooks/notes.ts')
const RULES = (await import("node:fs")).readFileSync("/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6/team.md","utf8").split("## 규칙")[1].split("## 용어")[0].split("\n").filter((l: string) => l.startsWith("- ")).map((l: string) => l.slice(2))
type C = [string, any, string, string, 'js'|'py', string]
const T = (label: string, drill: any, use: string, mine: string, lang: 'js'|'py', file: string) => {
  const known = N.capKnownNames([], file)
  console.log(label.padEnd(10), JSON.stringify(N.ruleGradeCap(drill, use, mine, known, lang, file, N.ruleAvoidsOf(RULES, use))) ?? 'none', '|', mine)
}
// date rule where line builds a Date
const fD = "import { toDateText } from './date.js';\nexport function label(at) {\n  const label = new Date(at).toLocaleDateString('ko-KR');\n  return label;\n}\n"
const dD = { line: "  const label = new Date(at).toLocaleDateString('ko-KR');", example: '  const label = toDateText(at);' }
T('date1', dD, 'toDateText', 'const label = toDateText(new Date(at));', 'js', fD)
T('date2', dD, 'toDateText', 'const label = toDateText(at);', 'js', fD)
// GA12 shape
const fG = "import { toDateText } from './date';\nexport function stamp(when: Date, value: string) {\n  return when.toISOString().slice(0, 10);\n}\n"
T('GA12', { line: '  return when.toISOString().slice(0, 10);', example: '  return toDateText(value);' }, 'toDateText', 'return toDateText(when);', 'js', fG)
// log rule with str() dropped by a tier-2 example
const fL = "from log import log\ndef report(total):\n    print('total: ' + str(total))\n"
T('pystr', { line: "    print('total: ' + str(total))", example: "    log.info('total: %s', total)" }, 'log.info', "log.info('total: ' + str(total))", 'py', fL)
// escapes
const fE = "import { log } from './log.js';\nconsole.log('it\\'s done');\n"
T('escape', { line: "console.log('it\\'s done');", example: "log.info('it\\'s done');" }, 'log.info', 'log.info("it\'s done");', 'js', fE)
// argument order reorder exemption: meaningful order
const fA = "import { apiRequest } from './api.js';\nconst url = BASE + '/x';\nconst opts = {};\nconst res = await fetch(url, opts);\n"
T('argorder', { line: 'const res = await fetch(url, opts);', example: 'const res = await apiRequest(url, opts);' }, 'apiRequest', 'const res = await apiRequest(opts, url);', 'js', fA)
// subtraction order
const fS = "import { log } from './log.js';\nconst left = total - used;\nconsole.log('left', total - used);\n"
T('minus', { line: "console.log('left', total - used);", example: "log.info('left', total - used);" }, 'log.info', "log.info('left', used - total);", 'js', fS)
// py missing builtins
const fP = "from log import log\ndef f(x):\n    print('bad', x)\n"
T('pyNIE', { line: "    print('bad', x)", example: "    log.info('bad', x)" }, 'log.info', "log.info('bad', repr(x))", 'py', fP)
T('pyascii', { line: "    print('bad', x)", example: "    log.info('bad', x)" }, 'log.info', "log.info('bad', ascii(x))", 'py', fP)
// JS missing globals
const fJ = "import { log } from './log.js';\nconsole.log('w', width);\n"
T('innerW', { line: "console.log('w', width);", example: "log.info('w', width);" }, 'log.info', "log.info('w', width ?? innerWidth);", 'js', fJ)
// ts annotation in non-declaration (function call generic without parens)
const fT = "import { config } from './config';\nconst max = Number(process.env.MSG_MAX);\n"
T('tsSat', { line: 'const max = Number(process.env.MSG_MAX);', example: 'const max = Number(config.MSG_MAX);' }, 'config', 'const max = Number(config.MSG_MAX) satisfies number;', 'js', fT)
T('tsNon', { line: 'const max = Number(process.env.MSG_MAX);', example: 'const max = Number(config.MSG_MAX);' }, 'config', 'const max = Number(config.MSG_MAX!);', 'js', fT)
T('tsAsC', { line: 'const max = Number(process.env.MSG_MAX);', example: 'const max = Number(config.MSG_MAX);' }, 'config', 'const max: number = Number(config.MSG_MAX);', 'js', fT)
T('parseInt', { line: 'const max = Number(process.env.MSG_MAX);', example: 'const max = Number(config.MSG_MAX);' }, 'config', 'const max = parseInt(config.MSG_MAX, 10);', 'js', fT)
T('plus', { line: 'const max = Number(process.env.MSG_MAX);', example: 'const max = Number(config.MSG_MAX);' }, 'config', 'const max = Number(config["MSG_MAX"]);', 'js', fT)
// python dict-key / kwargs inside dict()
const fR = "from api import api_request\nimport requests\nhot = requests.get(HOT_API, params=opts)\n"
T('pyKw', { line: 'hot = requests.get(HOT_API, params=opts)', example: 'hot = api_request(HOT_API, params=opts)' }, 'api_request', 'hot = api_request(HOT_API, params=opts, timeout=5)', 'py', fR)
T('pyKw2', { line: 'hot = requests.get(HOT_API, params=opts)', example: 'hot = api_request(HOT_API, params=opts)' }, 'api_request', 'hot = api_request(url=HOT_API, params=opts)', 'py', fR)
// numeric equal value
T('num', { line: "console.log('w', 5000);", example: "log.info('w', 5000);" }, 'log.info', "log.info('w', 5e3);", 'js', fJ)
// extra: function params, reorder in braces vs call args, escapes display, number display, brace object shorthand
T('fnparam', { line: "console.log('ids', rows.map(r => r.id));", example: "log.info('ids', rows.map(r => r.id));" }, 'log.info', "log.info('ids', rows.map(function (it) { return it.id; }));", 'js', "import { log } from './log.js';\nconsole.log('ids', rows.map(r => r.id));\n")
T('objshort', { line: 'const res = await fetch(url, { headers, body });', example: 'const res = await apiRequest(url, { headers, body });' }, 'apiRequest', 'const res = await apiRequest(url, { body, headers });', 'js', "const headers = {}; const body = ''; const url = 'x';\n")
T('objkeys', { line: 'const res = await fetch(url, { a: x, b: y });', example: 'const res = await apiRequest(url, { a: x, b: y });' }, 'apiRequest', 'const res = await apiRequest(url, { a: y, b: x });', 'js', "const x = 1, y = 2, url = 'u';\n")
T('numdisp', { line: "console.log('w', 5000);", example: "log.info('w', 5000);" }, 'log.info', "log.info('w', 5_001);", 'js', fJ)
T('rawstr', { line: "print(r'a\\d')", example: "log.info(r'a\\d')" }, 'log.info', "log.info('a\\d')", 'py', fP)
T('dtpy', { line: 'day = ends_at.date().isoformat()', example: 'day = to_date_text(ends_at)' }, 'to_date_text', 'day = to_date_text(datetime.fromisoformat(str(ends_at)))', 'py', "from datetime import datetime\nfrom dates import to_date_text\nday = ends_at.date().isoformat()\n")
T('oldleft', { line: 'const res = await fetch(url, opts);', example: 'const res = await apiRequest(url, opts);' }, 'apiRequest', 'const res = await apiRequest(url, opts) || await fetch(url);', 'js', fA)
T('envleft', { line: 'const max = Number(process.env.MSG_MAX);', example: 'const max = Number(config.MSG_MAX);' }, 'config', 'const max = Number(config.MSG_MAX ?? process.env.MSG_MAX);', 'js', fT)
