// Record-only replay (B-12) of the built ruleGradeCap (proto/repo) over recorded 1.12.0 N2 answers (measured + design
const TEAM = (await import(process.env.TREE ?? '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6/proto/repo/hooks/notes.ts')).parseTeamFile((await import('node:fs')).readFileSync('/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6/team.md', 'utf8')).rules
// pilot), the sample's after-file as the drill file text. No model call.
import { readFileSync, existsSync } from 'node:fs'
const N = await import(process.env.TREE ?? '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6/proto/repo/hooks/notes.ts')
const K = await import('/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1/tools/notekit.mjs')
const S = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112'
const jl = (p: string) => readFileSync(p, 'utf8').trim().split('\n').map(l => JSON.parse(l))
type Src = { tag: string; model: string; prompts: Map<string, string>; answers: { id: string; kind: string; line: string }[]; samples: any[]; hunks: any }
const srcs: Src[] = []
const b1 = `${S}/b1`
const b1s = JSON.parse(readFileSync(`${b1}/frozen/samples.json`, 'utf8'))
const b1h = Object.fromEntries(JSON.parse(readFileSync(`${b1}/frozen/hunks.json`, 'utf8')).map((x: any) => [x.id, x]))
for (const [L, model] of [['P', 'haiku'], ['Q', 'sonnet']]) srcs.push({ tag: 'measured', model, prompts: new Map(jl(`${b1}/frozen/n2-lines-${model}.jsonl`).map((x: any) => [x.id, x.prompt])), answers: JSON.parse(readFileSync(`${b1}/audit/n2j/${L}/n2-answers.json`, 'utf8')).answers, samples: b1s, hunks: b1h })
for (const set of ['set1', 'set2', 'set3', 'set4']) {
  const p = `${S}/design/G6/pilot/${set}`
  const ss = JSON.parse(readFileSync(`${S}/design/G6/dev/${set}/samples.json`, 'utf8'))
  const hh = existsSync(`${S}/design/G6/dev/${set}/hunks.json`) ? Object.fromEntries(JSON.parse(readFileSync(`${S}/design/G6/dev/${set}/hunks.json`, 'utf8')).map((x: any) => [x.id, x])) : {}
  for (const model of ['haiku', 'sonnet']) {
    if (!existsSync(`${p}/n2/answers-${model}.json`)) continue
    srcs.push({ tag: 'dev', model, prompts: new Map(jl(`${p}/n2/lines-${model}.jsonl`).map((x: any) => [x.id, x.prompt])), answers: JSON.parse(readFileSync(`${p}/n2/answers-${model}.json`, 'utf8')).answers, samples: ss, hunks: hh })
  }
}
const tally: Record<string, [number, number]> = {}
const why: Record<string, number> = {}
const rows: any[] = []
for (const src of srcs) {
  src.answers.forEach((a, i) => {
    const key = [...src.prompts.keys()].find(k => k.startsWith(`${a.id}-${String(i).padStart(2, '0')}-`) || k.startsWith(`${a.id}-${i}-`))
    if (!key) return
    const pr = src.prompts.get(key)!
    const m = /학습자가 고칠 줄 \((\S+) (\d+)행\): `(.*)`/.exec(pr)!
    const example = /## 모범 답\n(.*)\n/.exec(pr)![1]!
    const use = /확인: 고친 줄이 돌 때 `([^`]+)` 쪽을 거칩니다/.exec(pr)?.[1] ?? ''
    const fence = /그 둘레 코드[^\n]*\n```\n([\s\S]*?)\n```/.exec(pr)![1]!.split('\n')
    const at = fence.findIndex(l => l.trim() === m[3]!.trim())
    const above = at > 0 ? fence[at - 1] : undefined
    const below = at >= 0 && at < fence.length - 1 ? fence[at + 1] : undefined
    const s = src.samples.find((x: any) => x.id === a.id)
    const file = s.files.find((f: any) => f.path.endsWith(m[1]!)) ?? s.files[0]
    const h = src.hunks[a.id]
    const diffs: string[] = K.changesOf(N, h).changes.map((c: any) => c.diff)
    const lang = m[1]!.endsWith('.py') ? 'py' : 'js'
    const known = N.capKnownNames(diffs, process.env.NOFILE ? undefined : file.after)
    const cap = N.ruleGradeCap({ line: m[3]!, example, above, below }, use, a.line.trim(), known, lang, file.after, N.ruleAvoidsOf(TEAM, use))
    const k = `${src.tag}/${src.model}/${a.kind}`
    tally[k] ??= [0, 0]; tally[k][0]++; if (cap) { tally[k][1]++; why[`${a.kind}:${cap.why}`] = (why[`${a.kind}:${cap.why}`] ?? 0) + 1 }
    rows.push({ key, kind: a.kind, model: src.model, tag: src.tag, line: a.line, cap: cap ?? null })
    if ((cap && a.kind === 'keep') || (!cap && a.kind !== 'keep')) console.log(cap ? 'CAP on keep' : 'no cap', src.tag, key, JSON.stringify(cap), '|', a.line, '| ex:', example)
  })
}
for (const [k, [n, c]] of Object.entries(tally).sort()) console.log(k, `${c}/${n} capped`)
console.log(JSON.stringify(why))
if (process.env.OUT) (await import('node:fs')).writeFileSync(process.env.OUT, JSON.stringify(rows, null, 1))
