// P1 (ii): the built ruleGradeCap over the classified corpus (records only).
import { readFileSync, writeFileSync } from 'node:fs'
const G = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6'
const N = await import(`${G}/proto/repo/hooks/notes.ts`)
const K = await import(`${G}/tools113/notekit.mjs`)
const rows = JSON.parse(readFileSync(`${G}/capcorpus/rows.json`, 'utf8'))
const TEAM = N.parseTeamFile(readFileSync(`${G}/team.md`, 'utf8')).rules
const prac = Object.fromEntries(JSON.parse(readFileSync(`${G}/capcorpus/practices.json`, 'utf8')).map(p => [p.id, p]))
const samples = Object.fromEntries(JSON.parse(readFileSync(`${G}/dev/set1/frozen/samples.json`, 'utf8')).map(s => [s.id, s]))
const hunks = Object.fromEntries(JSON.parse(readFileSync(`${G}/dev/set1/frozen/hunks.json`, 'utf8')).map(s => [s.id, s]))
const tally = {}
for (const r of rows) {
  const p = prac[r.id]
  const s = samples[r.id]
  const after = s.files.find(f => f.path === p.file).after
  const lines = after.split('\n')
  const at = p.n - 1
  const diffs = K.changesOf(N, hunks[r.id]).changes.map(c => c.diff)
  const known = N.capKnownNames(diffs, after)
  const lang = N.pairLangOf(p.file)
  r.cap = N.ruleGradeCap({ line: p.line, example: p.example, above: lines[at - 1], below: lines[at + 1] }, p.use, r.line, known, lang, after, N.ruleAvoidsOf(TEAM, p.use)) ?? null
  r.capNoFile = N.ruleGradeCap({ line: p.line, example: p.example, above: lines[at - 1], below: lines[at + 1] }, p.use, r.line, N.capKnownNames(diffs), lang, '', N.ruleAvoidsOf(TEAM, p.use)) ?? null
  const k = r.actual
  tally[k] ??= { n: 0, capped: 0, cappedNoFile: 0 }
  tally[k].n++; if (r.cap) tally[k].capped++; if (r.capNoFile) tally[k].cappedNoFile++
  if (k === 'keep' && r.cap) console.log('KEEP CAPPED', r.id, JSON.stringify(r.cap), '|', r.line, '| ex', p.example)
  if (k === 'broken' && !r.cap) console.log('broken not capped', r.id, r.sub, '|', r.line, '| ex', p.example)
}
writeFileSync(`${G}/final/capcorpus-capped-final.json`, JSON.stringify(rows, null, 1))
console.log(JSON.stringify(tally))
const sub = {}
for (const r of rows.filter(x => x.actual === 'broken')) { const k = (r.sub ?? '?').slice(0, 14); sub[k] ??= [0, 0]; sub[k][0]++; if (r.cap) sub[k][1]++ }
console.log('broken by sub (n, capped):', JSON.stringify(sub))
