// 1.13.0 G6 final (records only, B-12): the dev sets' recorded N2 grades re-read with the FINAL ruleGradeCap (proto/repo,
// avoid names from the team file), no model call. Same counting as tools113/n2build.mjs judge; writes only under final/.
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
const G = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6'
const F = await import(pathToFileURL(`${G}/proto/repo/hooks/notes.ts`).href)
const rj = p => JSON.parse(readFileSync(p, 'utf8'))
const team = F.parseTeamFile(readFileSync(`${G}/team.md`, 'utf8'))
const all = {}
for (const set of ['set1', 'set2']) {
  const S = `${G}/dev/${set}`
  const N = await import(pathToFileURL(`${S}/mtree/hooks/notes.ts`).href)
  const pair = rj(`${S}/judge/pair.json`).labels
  for (const [m, label] of Object.entries(pair)) {
    const outp = `${S}/stage/N2-1/${m}/n2/out.json`
    if (!existsSync(outp)) continue
    const out = rj(outp).results
    const rows2 = rj(`${S}/judge/${label}/read2-A.json`)
    const meta = rj(`${S}/frozen/n2-meta-${m}.json`).answers
    const samples = Object.fromEntries(rj(`${S}/frozen/samples.json`).map(x => [x.id, x]))
    const t = { set, label, n: 0, correct: 0, breakRight: 0, brokenRight: 0, noRuleLine: 0, keepCapped: 0, modelRight: 0, capped: 0, preCapBadRight: 0, rows: [] }
    for (const r of out) {
      const kind = r.id.split('-').at(-1)
      const g0 = r.isAnswered ? F.parseCheck(r.text, { rule: true }) : undefined
      const sid = meta[r.id].sid
      const sent = N.drillOf(rows2[sid].on, rows2[sid].changes, true)
      const fileText = samples[sid].files.find(f => f.path === sent.file || f.path.endsWith('/' + sent.file))?.after
      const use = F.ruleFixUse(sent.check)
      const cap = g0?.verdict === 'right' && use !== undefined ? F.ruleGradeCap(sent, use, meta[r.id].mine, F.capKnownNames(rows2[sid].changes.map(c => c.diff), fileText), F.pairLangOf(sent.file), fileText ?? '', F.ruleAvoidsOf(team.rules, use)) : undefined
      const v = cap ? 'partial' : g0?.verdict
      const ok = { keep: v === 'right', break: v === 'partial' || v === 'wrong', broken: v === 'wrong' || v === 'partial', off: v === 'wrong' }[kind] === true
      t.n++; t.correct += ok ? 1 : 0
      if (g0?.verdict === 'right') t.modelRight++
      if ((kind === 'break' || kind === 'broken') && g0?.verdict === 'right') t.preCapBadRight++
      if (cap) t.capped++
      if (cap && kind === 'keep') t.keepCapped++
      if (kind === 'break' && v === 'right') t.breakRight++
      if (kind === 'broken' && v === 'right') t.brokenRight++
      if (!g0 || g0.rule === undefined) t.noRuleLine++
      t.rows.push({ id: r.id, kind, model: g0?.verdict ?? null, cap: cap ?? null, shown: v ?? null, ok, mine: meta[r.id].mine })
      if (cap) console.log(set, label, r.id, kind, JSON.stringify(cap), '|', meta[r.id].mine)
    }
    t.pass = t.correct >= 27 && t.breakRight <= 1 && t.brokenRight === 0 && t.noRuleLine <= 1 && t.keepCapped === 0 && t.preCapBadRight <= 2
    all[`${set}/${label}`] = t
    console.log(set, label, JSON.stringify({ ...t, rows: undefined }))
  }
}
writeFileSync(`${G}/final/rejudge-dev-n2.json`, JSON.stringify(all, null, 1))
