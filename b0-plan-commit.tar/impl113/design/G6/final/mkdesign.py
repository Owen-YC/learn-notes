import json, hashlib, os, sys
S = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad'
G = f'{S}/impl113/design/G6'
P = json.load(open(f'{G}/final/proofs.json')) if os.path.exists(f'{G}/final/proofs.json') else {}
diff = f'{G}/final/G6-113-final.diff'
dsha = hashlib.sha256(open(diff, 'rb').read()).hexdigest()

D = {}
D['id'] = 'G6'
D['name'] = "팀 규칙 연습 (isRuleDrill) — 1.13.0 '코드도 채점을 보는 규칙 연습': 1.12.0의 코드가 만드는 연습은 그대로 두고, 모델이 '맞음'이라 한 만든 규칙 연습의 줄을 코드가 다시 보아 규칙 이름이 없거나, 규칙이 쓰지 말라는 방식이 남았거나, 노트의 코드에 없는 이름이 있거나, 괄호가 다르게 닫히거나, 규칙 밖의 자리가 바뀌었으면 '거의'로 낮춥니다(올리지 않음, 채점 요청 바이트는 그대로). 연습 만들기에는 일반 읽기 규칙 셋을 더합니다(한 줄 구조 분해 = 객체 읽기, 스스로 고친 답은 마지막 온전한 답, 피할 이름 없는 규칙은 노트가 인용한 줄만 후보)."
D['recommendationInOneLine'] = "haiku: measure (the 1.12.0 failing kind, a broken line graded 맞음, is now caught by code: dev showed haiku alone grading 맞음 on one broken and one break answer and the cap catching both; every N1′ line 0 / den 92.3% over 75 dev notes; final cap keep-caps 0 of 168 keep answers). sonnet: do-not-measure in 1.13.0 unless the owner answers ownerQuestions[0] otherwise: its only 1.12.0 failure (two task lines in the OFF reading of its own shipped 1.8.0 note call) is outside every isRuleDrill path, so a round would re-roll the same failure line at ≈ 39% odds (≈ 30% overall)."

D['what'] = {
 'whenOn': [
  "켜지는 곳: MODEL_SWITCHES[m].isRuleDrill이 true인 창(정확히 haiku 또는 sonnet, 수준 beginner, 별칭 · 제공자 · 게이트웨이 변수와 modelOverrides가 없고 읽힘)에서, 노트가 `팀 규칙과 다를 수 있음:` 줄로 읽히는 규칙을 짚은 경우만. 1.12.0과 같이 코드가 연습을 만듭니다(1단: 규칙 글이 주는 이름 하나를 바꿈, 호출 없음; 2단: 코드가 고른 줄 목록에서 모델이 규칙 · 줄 · 예시 답 세 줄로 답하고 코드가 확인).",
  "노트 칸(저장 꼴, 1.12.0과 바이트까지 같음): '### 직접 해 보기 · <파일>' / '- 할 일 (팀 규칙): 바뀐 한 줄을 규칙대로 고쳐 보세요.' / '- 고칠 줄: `<줄>`' / '- 확인: 고친 줄이 돌 때 `<쓰라는 이름>` 쪽을 거칩니다' / '- 예시 답: `<예시>`' (예시 답은 a를 누르기 전에는 숨김).",
  "새로 보이는 것(채점 뒤에만): 모델이 '맞음'이라 했지만 코드가 아래 가운데 하나를 보면, 판정이 '거의'로 바뀌고 모델의 피드백 대신 코드가 쓴 한 줄이 보입니다. 한 번 더 고쳐 적을 수 있습니다(되묻기).",
  "  · 규칙이 쓰라는 이름이 없음: '규칙이 쓰라는 `log.info` 없이 고쳤습니다' (되묻기 = 기존 drillRuleHint: '팀 규칙과 다를 수 있음: <규칙 줄> · 이 줄에서 바꿀 곳 한 군데를 찾아보세요')",
  "  · 규칙이 쓰지 말라는 방식이 남음: '고친 줄에 원래 방식이 남아 있습니다: `fetch`' (되묻기 = drillRuleHint)",
  "  · 노트의 코드에 없는 이름: '이 노트의 코드에 없는 이름입니다: `options`' (되묻기 = '고칠 줄과 견주어 규칙 말고 바뀐 곳을 찾아보세요')",
  "  · 괄호 · 따옴표: '괄호나 따옴표가 고칠 줄과 다르게 닫힙니다' (되묻기 = 같은 문장)",
  "  · 규칙 밖의 자리가 바뀜: '규칙 밖에서 바뀐 곳이 있습니다: `url` → `BASE`' (되묻기 = 같은 문장)",
  "  이름 · 값은 줄에 적힌 글자 그대로 보이며 16자를 넘으면 15자 + '…'로 자릅니다. 고정 글은 32칸 이하이고, 이름 16자까지 한 줄은 50칸 이하입니다(바꿈 줄만 이름 둘이 길면 67칸까지 가며, 피드백은 Markdown으로 창 너비에서 접힙니다. 이미 쓰는 drillRuleHint도 접힘).",
  "두 번째 시도도 같은 코드 점검을 거칩니다: 코드가 반대하는 줄은 첫 시도든 두 번째든 '맞음'이 되지 않습니다. 첫 줄과 같은 줄을 다시 적으면 1.7.0부터 그렇듯 부르지 않고 '바뀐 것이 없습니다' 쪽 알림만 나옵니다(checkDrill). 두 번째 시도의 채점 요청에는 학습자가 본 그대로 '첫 판정: 거의'와 코드가 쓴 한 줄이 '받은 피드백'으로 들어갑니다.",
  "더 많은 노트가 연습을 얻음(1.12.0이 건너뛴 꼴): 한 줄 구조 분해 `const { API_URL, CDN } = process.env;` → `const { API_URL, CDN } = config;`(1단), 그 꼴의 2단 답, 스스로 고쳐 다시 쓴 2단 답(마지막 온전한 답을 받음). 날짜 규칙처럼 피할 이름이 없는 규칙은 노트가 인용한 줄만 2단 후보로 보냅니다(받을 수 없는 줄은 보내지 않음)."
 ],
 'unchanged': [
  "노트 요청(notePrompt / DRILL_ASK, 1.8.0 바이트, 두 상태 모두), keptNoteText · ruleLabelled · ruleNamesOf · holdsName(isRuleWide D26), RULE_DRILL_SYSTEM(1.10.0 바이트), RULE_DRILL_TOKENS 3500, 90000ms, 2단 호출 종류('note', 'manual')와 그 프롬프트의 짜임(ruledrill112가 피할 이름이 있는 모든 경우를 그대로 고정), RULE_FIX_TASK · ruleFixCheck · isMadeRuleDrill · drillOf · hideDrillAnswer, 저장되는 다섯 줄 칸.",
  "채점 요청 첫 시도: CHECK_SYSTEM + checkPrompt(…, { rule }) + RULE_CHECK, 480, 60000ms, 1.9.0 rule19 바이트 그대로; parseCheck(…, { rule: true })와 그 '안 지킴 + 맞음 → 거의'. drillQuestion(줄 위아래 한 줄) 그대로.",
  "askPrompt(D31: 규칙 연습 없음), shareText, 개념 연습의 채점(코드 점검 없음), 모든 OFF 창(isRuleDrill false, 다른 모델 글자, beginner가 아닌 수준, 별칭 · 제공자 · 게이트웨이 · modelOverrides · 읽지 못함)의 모든 요청 · maxTokens · 읽기 · 저장 글."
 ]
}

D['why'] = [
 "1.12.0 measured (2026-11-14, labels P = haiku, Q = sonnet, decision 17c291f): both OFF, each failing exactly ONE zero-tolerance line; every other line passed (den correct 89.2/90.5% haiku, 91.7/95.7% sonnet vs 80%).",
 "MISS 1 — haiku N2 broken→맞음 1/30 in both runs (GA02-10 `const res = await apiRequest(url, options);`, `options` undefined). Mechanism: an INFORMATION limit, not a reasoning one: drillQuestion shows the line and one line above/below, so the grader cannot know `options` is not defined. The same kind came back on 1.13.0 dev set 1 (haiku 맞음 on broken E1A09-27 `return toDateText(lateDate);`) and a rule-break kind on dev set 2 (haiku 맞음 with 규칙: 지킴 on E2B03-26 `const raw = process.env['PAY_TIMEOUT'];`). Code holds what the grader lacks (the note's diff, the drill file, the team rule's names), so a code-side, after-the-call check removes this kind deterministically without changing the measured request. Margin: haiku correct was exactly 27/30 in 1.12.0, so the check must never lower a right (keep) line.",
 "MISS 2 — sonnet two-task note in the OFF reading (GD15, round A): its own shipped 1.8.0 note call (isRuleWide sonnet, D26-protected) wrote '- 할 일:' three times while correcting itself. The OFF reading is keptNoteText of that reply; no isRuleDrill code path can reach it, and changing the note request would turn the shipped isRuleWide sonnet cell OFF. History 3 in 548 sonnet notes (1.10.0 166 + 1.12.0 dev 137 + 1.12.0 measured 170 + 1.13.0 dev 75; 0 in 75 this pilot), so P(0 in 170) ≈ e^(−170·3/548) ≈ 39%. This design cannot change that number.",
 "den misses of 1.12.0 addressed by general reading rules (each a mechanism, not a sample patch): GA17 not-one-span 4 of 5 (a one-line destructuring declaration is a `.NAME` read per listed name, but tier 1 and usePlaces had no place for the whole object) → destructuring branch; GB11 parse (sonnet self-correction, also dev D4A15: a label written twice with different values made the reply unreadable) → the last complete answer wins; GA13 not-anchored (for a rule with no avoid names ruleFixFault accepts only anchored lines, yet unanchored ones were listed and picked) → list only anchored lines for such rules.",
 "Declined den misses (structural costs, ≈ 1 den note per round against a ≈ 10-point margin; each fix adds h2 risk on wrong-guess notes or refuses right fixes): GA20 os.getenv (not named by the rule; a family table borders on fitting the key), GA12/GB13 date notes with no quoted code (a code-side candidate source raises h2), GA05 api_request argument order (code cannot know the signature; an argument-count guard would refuse the sample's own `method=\"POST\"` fix)."
]

D['whyNew'] = [
 "First design in which CODE checks the GRADE. 1.9.0 asked for the rule in the note prompt; 1.10.0 used a free four-line call where the model wrote task and check; 1.12.0 moved task, check and the fix into code (tier 1/2, closed three-line reply, fault checks, isMadeRuleDrill gate) but left grading entirely to the model with a three-line window. 1.13.0 keeps 1.12.0's practice-making path and adds ruleGradeCap: a deterministic, post-call, lower-only check that uses what the grader never sees (the note's diff and the drill file's names, the team rule's avoid names, the example's token shape). It never raises a verdict, never changes the first-try request bytes, never runs on a concept practice or an OFF window.",
 "General mechanisms (none tied to a dev sample): (a) a fix that drops the rule's use name is not the rule's fix; (b) a fix that still reaches the first part of a name the rule says not to use (where the original line did and the example dropped it) keeps the old way; (c) a name looked up that neither the note's code, the lines shown, the line's own bindings nor the language gives is undefined; (d) unbalanced brackets/quotes vs the example are a syntax error; (e) the example's own token shape with a different name or value outside the use name changes something besides the rule (only an entry reorder where order means nothing is exempt: object/destructuring entries, Python keyword arguments).",
 "Three reading rules on the practice side (destructuring as an object read; last complete answer wins; anchored-only candidates for no-avoid rules), each the general form of a measured 1.12.0 miss."
]

D['how'] = {
 'notes.ts (ON-only code; every function below is reached only from ON paths)': [
  "ruleGradeCap(drill, use, mine, known, lang, file = '', avoids = []): RuleGradeCap | undefined — the first that holds, in order: (a) 'rule-use': holdsName(nameCode(mine), root of use) false (`log` of `log.info`); (b) 'rule-old': a name reached (called, indexed or member-read: `x(`, `x.`, `x[`) in the practice line's code, absent from the example's code, that is the FIRST PART OF AN AVOID NAME OF THE RULE ASKING FOR `use` (ruleAvoidsOf: fetch, requests, console, print, process, os) and is still reached in mine; none for a rule with no avoid names (date) and none when no team rule is read; (c) 'name': usedNames(mine) holds a name not in known ∪ names of line/example/above/below ∪ GIVEN_NAMES[lang] (skipped after a Python `from x import *` in the file), or a member read (not a call) of the use object the known set never shows when the example reads a member of it (`config.FREE_SHIP`); (d) 'brackets': balanceOf(codeOf(mine)) ≠ balanceOf(codeOf(example)); (e) 'swap': shapeTokens of mine and example have the same length and every differing position outside the use name's tokens is name-vs-name or value-vs-value, unless isLooseReorder.",
  "ruleAvoidsOf(rules, use): the avoid names of every rule whose ruleSidesOf (fail-closed) use list holds `use`.",
  "GIVEN_NAMES {js, py}: closed lists from the languages' own references — JS keywords, ECMAScript globals, Node globals (not module names: `fs`, `path`, `os`, `url` excluded), browser globals that are not plain words (`innerWidth`, `requestAnimationFrame`; not `name`, `status`, `open`), TypeScript primitive/lib/utility types; Python keywords (soft ones too) and every builtin of `dir(builtins)` (exceptions included) plus `self`, `cls`, dunder module names.",
  "nameCode(line, lang): strings blanked (Python prefixes too), JS regex literals blanked, end comment cut; `${…}` in templates and f-string fields before `!`/`:` kept as code.",
  "usedNames(line, lang): names looked up, skipping members (`.x`, `?.x`; a JS spread `...x` IS looked up), object keys/`x:`, Python kwargs inside a call, decorators, TS type positions (`as T`, `satisfies T`, `<T>(`, declaration `: T`), and names the line binds (arrow/lambda/`function (…)` parameters, for-of/in and comprehension targets, catch, Python `as`/`:=`, declaration targets).",
  "capKnownNames(diffs, file?): words (case kept, string words too) of every screened change's new side and context lines plus the drill file's current text.",
  "shapeTokens(code, lang): tokens with `text` (compared: spaces and final `;` dropped; string escapes read and quote kind ignored — `'it\\'s'` = `\"it's\"`; raw strings keep backslashes; templates/f-strings holding code are `live`; numbers by value) and `raw` (what the line wrote, shown in the cap).",
  "isLooseReorder(a, b, moved, lang): the moved positions lie in one bracket whose comma-split entries are the same multiset in both, and the bracket is `{ … }` with no spread entry, or a Python call whose entries in another place are keyword arguments. A call's positional places and operation sides stay a swap (`apiRequest(opts, url)`, `used - total`).",
  "ruleFixUse(check): the use name RULE_FIX_CHECK reads from the code-written check.",
  "ruleCapText(cap) and constants RULE_CAP_BRACKETS '괄호나 따옴표가 고칠 줄과 다르게 닫힙니다', RULE_CAP_NUDGE '고칠 줄과 견주어 규칙 말고 바뀐 곳을 찾아보세요', RULE_CAP_CODE 16 (names/values cut to 15 + '…').",
  "renamedLine (tier 1) and usePlaces / isOneSpanFix (tier 2): DESTRUCTURE_HEAD `^\\s*(?:const|let|var)\\s*\\{[^{}]*\\}\\s*=\\s*$` before the avoid object and DESTRUCTURE_TAIL `^\\s*;?\\s*$` after it → swap the whole object (`= process.env;` → `= config;`, JS only); a tier-2 example's whole use object at that place stands only for an avoid name, whole. Still refused: `{ env: process.env }`, `f(process.env)`, writes, deletes, `Object.keys(process.env)`, nested patterns. NOT_APP_PATH / isRuleModuleFile / definesName unchanged.",
  "parseRuleFix: answers split where a label already in the current answer repeats; when two values of one label disagree, the LAST answer is the reply only if whole (줄, and 예시 답 unless 줄: 없음, and 규칙 when the first answer had one), else undefined. Same-value repeats read as 1.12.0; the two repairs unchanged; ruleFixFault decides as before.",
  "ruleFixLines: isNoAvoid (every pointed rule has no avoid name) → only anchored (note-quoted) lines are listed; order and RULE_FIX_LINES_MAX 12 unchanged; ruleFixPlan's skip is 'no-hint' when lines were left out only for being unquoted. The only tier-2 prompt byte change, and only in the no-avoid case."
 ],
 'register.tsx gradeDrill (ON-only, ≈ 20 lines after parseCheck and the existing latest-note check)': [
  "use = build.isRuleDrill ∧ sent.rule set ∧ parsed.verdict === 'right' ? ruleFixUse(sent.check) : undefined (undefined for any practice whose check code did not write, i.e. never on a concept practice or an OFF window).",
  "file = importsText($, sent.path, CAP_FILE_MAX 200_000) — the existing guarded reader (permission rules, realPath, NUL check); undefined → diff names only. Read only when use is set; nothing of it is shown, kept or sent.",
  "team = teamOf($, note.root) (the team file screened() just read; cached by path/mtime/size, a stat only); avoids = ruleAvoidsOf(team.rules, use) or [] when none.",
  "cap = ruleGradeCap(sent, use, mine, capKnownNames(shown.changes diffs, file), pairLangOf(sent.file), file, avoids); a cap → verdict 'partial', feedback ruleCapText(cap); on a first try the nudge is drillRuleHint(sent.rule) for rule-use/rule-old, RULE_CAP_NUDGE otherwise (keptNudge skipped), so keepDrillTry stores the first try and the existing 1.9.0 try-again flow runs; on a second try the capped verdict goes to secondVerdict (partial+partial → partial).",
  "importsText gains an optional max argument (default IMPORTS_READ_MAX, so every existing caller is byte-identical); pairLangOf is exported."
 ],
 'promptConstants': "No prompt constant changes. Grading first try: CHECK_SYSTEM, checkPrompt(…, { rule }), RULE_CHECK, 480 tokens, 60000 ms (rule19). Tier 2: RULE_DRILL_SYSTEM (1.10.0), ruleDrillPrompt (1.12.0 builder; only its candidate list differs for no-avoid rules), RULE_DRILL_TOKENS 3500, 90000 ms. Note: notePrompt 1.8.0, NOTE_TOKENS 3500.",
 'caps': "Cap hit = output_tokens ≥ maxTokens + H_M with H_M from the 1.13.0 M-5 calibration on a fresh pinned copy of the installed Claude Code (2.1.327 today): note 3500 + H_M, tier 2 3500 + H_M, N2 480 + H_M.",
 'switchCells': "Unchanged until a passing decision: IS_RULE_DRILL = false; SWITCHES_OFF.isRuleDrill = IS_RULE_DRILL; MODEL_SWITCHES.haiku = { ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2 }, MODEL_SWITCHES.sonnet = { ...SWITCHES_OFF, isRuleWide: true }. Only if haiku passes: the commit after the decision sets MODEL_SWITCHES.haiku.isRuleDrill = true (with isRuleWide true; old-window check incl. 30adc2f and coexist19 re-run with the ON value, R9; the 68 tests that assert the shipped OFF rows are rewritten there and listed by name). sonnet stays as it is in 1.13.0 (not measured) unless the owner answers ownerQuestions[0] otherwise."
}

D['prototypePatch'] = diff
D['prototypePatchSha256'] = dsha
D['prototypeFiles'] = [
 f'{G}/proto/repo (copy of /home/user/learn-notes at 30adc2f with the patch applied; the real repo is untouched)',
 f'{G}/proto/G6-113-proto-iter1.diff (the pilot\'s refinement-1 state, for comparison)',
 f'{G}/final/rejudge.mjs · replay-final.mts · cap-final.mjs · probe2.mts (offline re-reads with the final cap)',
 f'{G}/final/mut.py and final/mut/ (mutation probes), final/d26, final/g2, final/probe_off-final.json, final/oldwin113-final.json (proofs)'
]

D['samples'] = {
 'measured': [
  "One fresh frozen sample set, the 1.12.0 composition word for word (85 + spares): R 40 (10 per rule; js 14 · ts 12 · py 14), R_long 4, F 12, N 12, traps 9 (rule module ×4, one per rule, py ≥ 1, ts ≥ 1; tests ×2; build script ×1; a non-stem module exporting a use name ×1; a `*.config.*` file reading process.env ×1), multi 4, double 4. Same team file (the 4 rules + `## 용어` 2, unchanged) and key §5. Written for both models (sonnet uses the same set only if the owner turns it on, ownerQuestions[0]); haiku stage first.",
  "Writers: fresh `claude -p --model opus --tools ''` sub-agents, at most 10 records per call, one set kind per call (G3 STOP lesson: ~12 calls, e.g. R 4 calls of 10, R_long+F 2, N 2, traps 1 of 9, multi+double 1, plus spares), each given only the team file, the module table, the sample JSON form, the 1.10.0 writing rules (markers per rule; free choice of marker, call shape, argument count) and a NAMES-ONLY avoid list (never 견본.md prose). They never see RULE_DRILL_SYSTEM, ruleDrillPrompt, ruleFixPlan, ruleGradeCap, notePrompt, RULE_CHECK, ruleLabelled, this design, the stance or which model is measured. A writer that prints tool-call text or is refused is re-run once with the same input (records), never edited.",
  "Freeze-time checks (0 model calls), as 1.12.0: JSON reads; demo runs per §8 = expected; each violation's fix-run runs and writes MORE stub records than as written (strict S1) with its stdout frozen as expected_fixed; violation lines in `after`, hold a §5 marker, fix holds a use name and no marker; every marker line of a non-trap sample is a violation (F: comment/string-only marker text allowed); R/multi/double ≤ 40 chars without indent, R_long ≥ 41; R/multi/double import the module; F/N/trap violations empty; a file path equal to a dev path is rejected. Failing samples are replaced by the same group's spares in id order, never rewritten; replacement counts are recorded. samples.json, team.md, key frozen (chmod 444, sha256, writer, UTC time in 견본.md)."
 ],
 'secondStage': "N2 per measured label: pick.py takes 5 correct practices from that label's round A (all 4 rules, py ≥ 1, ts ≥ 1; unfillable conditions dropped and recorded; < 5 correct → N2 fails). One fresh opus writer per picked practice (≤ 10 answers per call, the frozen 1.12.0 frame with that practice alone; sees only the practice as gradeDrill shows it — code task and check, line, example, rule line, file, demo — and the team file) writes keep 2 · break 2 · broken 1 · off 1 + one spare per kind; n2verify (detail 22) runs them before freezing; spares fill, never rewritten.",
 'devNamesNotToOverlap': [
  "1.13.0 dev ids: E1A01-E1A10, E1B01-E1B10, E1C01-E1C08, E1D01-E1D10 (set 1, 36 frozen, sha256 10491a07…) and E2A01-E2A10, E2B01-E2B10, E2C01-E2C10, E2D01-E2D10 (set 2, 39 frozen + dropped E2A08, sha256 c3d309c5…); cap-corpus answers on E1A01-E1A10, E1B04, E1B06.",
  f"Names (file basenames and identifiers): the 209 entries tagged 'G6-dev-113' in {S}/impl113/NAMES-all.txt ({G}/dev/set1/names.txt 94, {G}/dev/set2/names.txt 115).",
  f"Earlier G6 names: every 'G6-dev' (1.12.0 dev D1A01–D4B24, 1214 names) and 'G6-measured' (1.12.0 GA–GD, 337 names) entry of {S}/impl113/NAMES-all.txt, every 견본.md id (TA/TB/TC/TD 1.10.0; 1.9.0 C/G ids; 1.12.0 GA–GD). The measured writers get the union as a names-only avoid list; check.py rejects a sample whose file path equals any of those paths."
 ]
}

D['calls'] = [
 "Exactly as the plugin (D20), through the probe mod calling $.model.complete({ model: 'haiku' (setting string as is), effort: 'low', system, prompt: redactText(prompt).text, maxTokens, timeoutMs }), 4 at a time, $.clock timing, replies through fixEscapedTicks. The pinned CLI copy of the 1.13.0 calibration; DISABLE_AUTOUPDATER=1; claude --version, init model and modelUsage keys before and after each round (M-10).",
 "Note: SYSTEM, notePrompt(screened, 'beginner', [], team) (1.8.0 bytes), maxTokens NOTE_TOKENS 3500, timeoutMs 90000.",
 "Practice: the build tree's writeNote path: keptNoteText(reply, ruleNamesOf(rules)) → noteRuleOf → ruleFixPlan(screened, rules, said). Tier 1: no call. Tier 2: system RULE_DRILL_SYSTEM, prompt redactText(ruleDrillPrompt(screened, rules, said, cands)).text, maxTokens RULE_DRILL_TOKENS 3500, timeoutMs 90000, kind 'note', 'manual', then ruleFixReply. Skip: no call.",
 "N2 grading (first try only): CHECK_SYSTEM, redactText(checkPrompt({ name: '팀 규칙', question: drillQuestion(sent), answer: sent.example, kind: 'modify' }, `${sent.indent}${mine}`, 'beginner', undefined, undefined, { rule: sent.rule })).text, maxTokens 480, timeoutMs 60000, two runs; then parseCheck(text, { rule: true }) and the build tree's ruleGradeCap(sent, ruleFixUse(sent.check), mine, capKnownNames(screened diffs, after-file), pairLangOf(sent.file), after-file, ruleAvoidsOf(team.rules, use)) — no call.",
 "Not re-sent: empty reply, cap hit, timeout. API errors recorded, not re-sent; > 10% of a model-stage → M-4 (void, OFF). After each stage every empty reply is re-sent once through the tap for stop_reason/stop_details only (record).",
 "D34 before the first call: from the build tree's plugin test harness (level beginner, model 'haiku', harness row turning isRuleDrill + isRuleWide on; and with no harness) capture the note request, every tier-2 request and, after the N2 freeze, every N2 grading request (model, effort, system, prompt, maxTokens, timeoutMs) and byte-compare with the tool's lines. Tier-1 and skipped notes show no second request; the no-harness capture has the note request only."
]

D['bar'] = {
 'source': "The last committed bar: 1.12.0 G6 (commit 2f95fe1, docs/qa/견본.md '## 1.12.0 팀 규칙 연습 (G6)' > '#### 기준'), which re-commits 1.10.0's (432ced4). Every line below is that bar word for word unless marked NEW (stricter) or STANCE (an explicit, justified counting statement). den is the committed den; the scope is not narrowed.",
 'lines': [
  "Samples: the same fresh frozen samples for both models (85 + spares: R 40 [10 per rule; js 14 · ts 12 · py 14], R_long 4, F 12, N 12, traps 9, multi 4, double 4). Per model two independent rounds A and B; every N1′ line must pass in BOTH rounds; per model only, never combined or transferred.",
  "N1′ (a): O ≥ 20 and rule practices in O notes = 0 (O = a note whose keptNoteText has no `팀 규칙과 다를 수 있음:` line before the practice heading; a `팀 규칙:` line alone is O).",
  "N1′ (b) den: L notes whose sample has a violations line ≤ 40 chars without indent; den ≥ 20.",
  "N1′ (b) correct: correct rule practices (§6 (i)–(vi) all true) ≥ 80% of den; a den note with no practice made (skip, `줄: 없음`, reply not taken, failed call) is not correct.",
  "N1′ (b) harmful = 0 over ALL answered notes of the round (h1 no rule brought in; h2 line not a violations line of a brought rule, incl. traps / R_long / wrong-guess notes; h3 a marker of the brought rule left in the example, incl. reversal/wrap; h4 syntax error in the changed file).",
  "N1′ (b) two-task = 0: notes whose final 직접 해 보기 section(s) hold ≥ 2 task lines (taskLineOf), over ALL answered notes, in BOTH the ON reading and the OFF reading (OFF reading = keptNoteText(same note reply, names), the shipped isRuleWide path; owner question default: keep counting it).",
  "N1′ (c): O notes: note prompt byte-identical ON vs OFF (tests + D34), no practice call for any O note (call log), every O note's final text byte-identical in the ON and OFF readings.",
  "Traps (9) → rule practices = 0.",
  "R_long notes and L notes with no ≤ 40-char violation (F · N · traps) → rule practices = 0 (their own concept practice allowed as in OFF).",
  "Unlabelled rule practice (§9) = 0 in the ON and OFF readings.",
  "Rule-practice no-answer: cap hit (output_tokens ≥ 3500 + H_M), empty reply (API refusal included, E18) or timeout ≤ max(1, ⌊n/60⌋), n = that model's tier-2 calls over both rounds; API errors counted, never re-sent.",
  "Old windows (0 calls): notes.ts of 3f2b4fb · 7a7b08c · 3690021 · fca5988 · 3d2f251 · de98243 + NEW 30adc2f (1.12.0; stricter): on every marked final text (ON and OFF) drillOf gives no practice and hideDrillAnswer shows no `고칠 줄` / `예시 답` line; on every unmarked text each window gives the same task · line · example · file · row as 3d2f251's drillOf.",
  "W gate (isRuleDrill only): in both rounds' OFF reading §11 W false positives = 0 and keptNoteText idempotent on every answer; a W FP blocks isRuleDrill only, never re-decides isRuleWide.",
  "N2 (per measured label, second-stage samples from that model's round A): 5 correct practices picked (all 4 rules, py ≥ 1, ts ≥ 1; < 5 → N2 fails); 30 answers (per practice keep 2 · break 2 · broken 1 · off 1, n2verify-checked, spares fill), graded twice exactly as gradeDrill grades (480, 60000 ms, first try). EACH run: correct verdicts ≥ 27/30, break→맞음 ≤ 1, broken→맞음 = 0, missing `규칙:` line ≤ 1 (unanswered/unreadable = not correct and missing). Excluded answers shrink the denominator but 27 correct are still required.",
  "STANCE (N2 counting, decided before any sample): 'graded exactly as gradeDrill grades' is the 1.13.0 build tree's gradeDrill, i.e. the verdict the learner is shown: parseCheck's 안 지킴 + 맞음 → 거의, THEN ruleGradeCap's 맞음 → 거의. The committed 1.12.0 stance text named only the first lowering because 1.12.0's gradeDrill had only that one; this design states the change openly (it would turn 1.12.0's GA02-10 into 거의). The two NEW lines below make sure the cap can neither hide a grader collapse nor cost a right line.",
  "NEW (stricter), each run: ruleGradeCap on an n2verify keep answer = 0 (a code cap on a right line fails N2).",
  "NEW (stricter), each run: pre-cap (break + broken)→맞음 ≤ 2, counted on parseCheck's verdict before ruleGradeCap (a grader that calls many wrong lines right fails N2 even when code catches them). 1.12.0 measured haiku had 1 per run; 1.13.0 dev haiku 1 per run; sonnet 0.",
  "Decision rule (mechanical, decide.py): isRuleDrill_m = MODEL_SWITCHES[m].isRuleWide true at the bar commit ∧ W passes both rounds ∧ every N1′ line passes in A and B ∧ N2 passes both runs (all its lines, the two NEW included); else false. Invalid round (M-4 infrastructure 10%, M-10 before/after record ≠ the 1.13.0 calibration) → OFF, not re-measured. An undecided case (§15 / M-11) counts toward failing. Stance, key, judge and scripts frozen at the bar commit; tool defects per M-15 (a fail never becomes a pass).",
  "Cap thresholds: 3500 + H_M (note, tier 2) and 480 + H_M (N2) from the 1.13.0 M-5 calibration on a fresh pinned copy of the installed Claude Code (2.1.327 now); every round's before and after record must equal it (M-10), else the round is void and the cell OFF.",
  "Recorded only (S-d / B-12, never in the decision): tier per note, skip reasons, tier-2 fault codes, candidate counts, 1.9.0-definition (b), den misses in 1.10.0 shape, output tokens/time, strict-S1 replacements, practice calls per L note, refusal column; NEW records: cap reason and pre-cap verdict per N2 item, destructuring tier-1/tier-2 hits, last-answer parses, anchored-only lists (and notes skipped 'no-hint' by them)."
 ],
 'statedRisk': "Sonnet's two-task line counts the OFF reading of its own shipped 1.8.0 note call, which this design cannot touch (≈ 39% to pass that line alone, ≈ 30% overall). That is why sonnet is not measured here unless the owner decides otherwise (ownerQuestions[0])."
}

D['stance'] = {
 'intro': "판정의 입장(1.13.0 G6). 1.12.0 G6 입장(2f95fe1, 견본.md '## 1.12.0 팀 규칙 연습 (G6)' > '#### 판정의 입장')의 모든 글 — 공통 다섯 항목, 확인 줄(S-a), 견본(S-c), 판정 대상(S-b), 경계 꼴 E1 ~ E18, N2 입장, 다시 커밋하는 1.10.0 입장 §0 ~ §15와 세부 1 ~ 24, '읽는 법' — 을 글자 그대로 다시 커밋합니다. 그 글의 '1.12.0'은 '1.13.0'으로, '1.12.0 보정 기록'은 '1.13.0 보정 기록'으로, '그 판 트리'는 1.13.0 짓기 커밋의 트리로 읽습니다. 아래는 바꾸거나 더하는 곳뿐이며, 바꾼 곳은 1.12.0이 한 대로 원문을 지운 줄(~~ ~~)로 남기고 1.13.0 글을 붙입니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 견본.md '다시 잴 때'에 적습니다(M-11).",
 'changed': [
  "§1 켠 읽기(1.13.0): 1.12.0 글 그대로이고, 그 판 트리의 ruleFixLines · renamedLine · usePlaces · isOneSpanFix · parseRuleFix가 1.13.0 것입니다(피할 이름 없는 규칙은 인용된 줄만 후보, 한 줄 구조 분해의 객체 바꿈, 스스로 고친 답은 마지막 온전한 답). 끈 읽기는 같은 노트 답의 keptNoteText 글 그대로입니다.",
  "§2: 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.13.0 보정 기록). 그 밖은 그대로.",
  "§14 (더함, 엄격하게): 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988 · 3d2f251 · de98243에 30adc2f(1.12.0)를 더한 일곱입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.",
  "E8 (바꿈): ~~2단 답이 스스로 고쳐 쓴 꼴(같은 라벨에 다른 값, 'Wait —'): 코드가 받지 않아 연습 없음입니다.~~ 1.13.0: 코드가 마지막 온전한 답(줄, 줄: 없음이 아니면 예시 답, 첫 답에 규칙이 있었으면 규칙)을 받아 같은 확인(ruleFixFault)을 거칩니다. 마지막 답이 온전하지 않으면 연습 없음입니다. 판정은 언제나 저장된 글만 봅니다.",
  "N2 입장 (바꿈, 재기 전에 밝힘): ~~parseCheck(text, { rule: true }) 뒤 '안 지킴 + 맞음 → 거의' 낮추기를 거친 판정으로 셉니다.~~ 1.13.0: 기준의 'gradeDrill이 매기는 대로'는 1.13.0 짓기 트리의 gradeDrill이 학습자에게 보이는 판정입니다. 곧 parseCheck(text, { rule: true })의 '안 지킴 + 맞음 → 거의'를 거친 뒤, 그 판정이 맞음이면 짓기 트리의 ruleGradeCap(sent, ruleFixUse(sent.check), 답 줄, capKnownNames(그 노트의 screened 변경 diff, 그 견본 파일의 after 글), pairLangOf(sent.file), after 글, ruleAvoidsOf(얼린 팀 파일의 규칙, use))이 무엇을 내면 거의로 셉니다. 바른 판정은 그대로(지키고 동작함 → 맞음, 어겼지만 동작함 → 거의 · 틀림, 깨짐 → 틀림 · 거의, 엉뚱함 → 틀림). 낮추기 전 판정(parseCheck의 판정)은 따로 적고, 새 줄 '낮추기 전 (어김 + 깨짐)→맞음 ≤ 2'만 그것으로 셉니다."
 ],
 'added': [
  "E19 한 줄 구조 분해 예시 답(`const { API_URL, CDN } = config;`, 줄은 `= process.env;`): 쓰라는 이름 config를 품고 표지가 없으므로 (iv)의 출력 비교가 정합니다. 1단이 만들었어도 같은 §6 · §10으로 매깁니다.",
  "E20 GA17 꼴에서 2단 답이 꼴을 바꾼 것(`const SUPPORT_EMAIL = config.SUPPORT_EMAIL;`): 한 자리 고침이 아니라 코드가 받지 않음 → 연습 없음. den이면 바르지 않음, 해롭지 않음.",
  "E21 스스로 고친 2단 답에서 첫 답과 마지막 답이 다른 줄을 고름: 코드가 마지막 온전한 답만 봅니다. 저장된 글의 줄 · 예시로만 §6 · §10을 매기며, 첫 답의 줄은 보지 않습니다.",
  "E22 피할 이름 없는 규칙(날짜)을 짚은 노트에서 인용된 줄이 없음: 후보 없음 → 건너뜀(no-hint) → 연습 없음. den이면 바르지 않음, 해롭지 않음(E17과 같은 셈).",
  "E23 날짜 규칙 2단 예시 답이 값을 다시 감쌈(`toDateText(new Date(at))`): `new Date(`는 §5 표지가 아니므로 h3가 아니고 (iv)의 출력이 정합니다(E1 · E2와 같음).",
  "E24 N2: n2verify keep 답에 ruleGradeCap이 무엇이든 내면 그 답은 바른 판정이 아니고 '지킴 답 낮춤' 줄에 1로 셉니다(그 줄은 0이어야 함).",
  "E25 N2: off(엉뚱함) 답을 모델이 맞음이라 하고 코드가 거의로 낮춤: off의 바른 판정은 틀림뿐이므로 바르지 않음(1.12.0 그대로, 예: 1.13.0 개발 E1A09-28 off → 거의 ✗).",
  "E26 N2: break · broken 답을 모델이 맞음이라 하고 코드가 거의로 낮춤: 바른 판정(거의)으로 세고, 낮추기 전 (어김 + 깨짐)→맞음 줄에 1로 셉니다.",
  "E27 N2: 모델이 거의 · 틀림이라 한 답에 코드는 아무 일도 하지 않습니다(낮추기만, 올리지 않음). 코드가 무엇을 냈을지는 적지 않습니다.",
  "E28 N2: 견본 파일의 after 글을 찾지 못하면(경로가 다름) 코드는 diff 이름만으로 봅니다(플러그인이 파일을 읽지 못한 때와 같음). 그 수를 적습니다.",
  "E29 N2: 도구가 짓기 트리의 ruleGradeCap과 다르게 센 것이 드러나면 M-15로 두 꼬리표를 다시 세고, 못 넘음이 넘음으로 바뀌지 않습니다.",
  "E30 N2는 첫 시도만 잽니다(1.9.0부터 그대로). 낮춘 뒤의 두 번째 시도 요청(첫 판정: 거의 + 코드가 쓴 피드백)은 재지 않고 '위험'에 적습니다.",
  "E31 sonnet 노트가 스스로 고쳐 할 일 줄을 여럿 씀(1.12.0 GD15 꼴, 끈 읽기): E9 그대로 할 일 줄 둘인 노트로 셉니다(두 읽기, 답한 모든 노트). 이 설계가 바꿀 수 없는 끈 읽기의 일이어도 기준 줄은 그대로입니다.",
  "E32 N2 keep 답이 예시 답과 다른 뜻의 같은 꼴(같은 모양에 다른 이름, 예: `toDateText(when)` ↔ 예시 `toDateText(value)`)이고 n2verify가 keep(출력 같음)으로 가름: 코드가 swap으로 낮추면 E24대로 셉니다(넘는 쪽에 불리하게, 미리 정함)."
 ],
 'unchangedNote': "§3 L과 O, §4 연습의 종류, §5 채점 열쇠(요청 · 기록 · 날짜 · 설정의 쓰라는 이름 · 표지 · 낱말 표), §6 바름 (i)–(vi), §7 확인 줄, §8 대역과 돌리기(B-14 py 다섯 번, B-15), §9 표지 없는 규칙 연습, §10 h1–h4, §11 W 오탐, §12 (c), §13 할 일 줄 둘, §15 판정 파일, S-a · S-b · S-c, E1–E7 · E9–E18, 세부 1–24는 1.12.0 글자 그대로입니다."
}

D['decisionRule'] = [
 "Per model m ∈ {haiku, sonnet}, from m's counts only, no re-rolls: isRuleDrill_m = MODEL_SWITCHES[m].isRuleWide is true at the bar commit ∧ the W line passes in both rounds ∧ every N1′ line passes in round A and in round B ∧ N2 passes in both runs (correct ≥ 27, break→맞음 ≤ 1, broken→맞음 = 0, missing 규칙 ≤ 1, keep caps = 0, pre-cap (break+broken)→맞음 ≤ 2) — else false.",
 "A model not measured in 1.13.0 (sonnet by default) stays OFF; no transfer from haiku.",
 "A void round (M-4, M-10) → that model OFF, not re-measured in 1.13.0. An undecided case counts toward failing.",
 "isRuleWide_m is not re-decided; a W false positive blocks isRuleDrill_m only (recorded).",
 "The switch row changes only in the commit after the decision commit, with the old-window probe (seven notes.ts incl. 30adc2f) and coexist19 re-run on the ON value (R9). Any later change to code or sentences building a measured request turns the cell OFF (D26 recheck)."
]

D['perModel'] = {
 'haiku': "Measure. Dev records (B-12, 2 fresh sets, 75 notes; final cap re-read): every N1′ zero-tolerance line 0 (harmful 0, two-task 0 in both readings, traps 0/12, unlabelled 0, (c) 0, W FP 0), den 26 correct 24 = 92.3% (92.9% / 91.7%), tier-2 no-answer 0/19, refusals 0; mini-N2 28/29 and 30/30 with break→맞음 0, broken→맞음 0, missing 0, keep caps 0, pre-cap (break+broken)→맞음 1 and 1 (≤ 2). The 1.12.0 failing kind recurred twice on dev and the cap caught both. Pass odds ≈ 55–60% (risks: a broken sub-kind the cap cannot see graded 맞음, ≈ 10–20% per N2; a keep form the cap lowers, ≈ 5%; den margin).",
 'sonnet': "Do not measure in 1.13.0 (default). Dev numbers are at or above every line (den 41 correct 38 = 92.7%, every zero-tolerance line 0 over 75 notes, N2 29/30 twice, refusals 0) but the cap gives sonnet no measured benefit (sonnet alone made 0 break/broken→맞음 in 1.12.0 measured and 1.13.0 dev), and its only 1.12.0 failure, the two-task OFF reading of its shipped note call, is unchanged by this design: a round would re-roll the same failure line (P(pass that line) ≈ 39%, overall ≈ 30%). What would have to change: the owner decides the isRuleDrill two-task line counts only the ON (stored) reading (ownerQuestions[0] (a)), or explicitly accepts measuring at these odds (b), or a separate isRuleWide/note-call design for sonnet removes the self-correcting two-task note (its own D26 consequences)."
}

D['cost'] = {
 'perLearner': "Only on an ON window (haiku by default if it passes), beginner, a note whose `다를 수 있음` line names a read rule. Note side: as 1.12.0 — tier 1 and skips no extra call; tier 2 one extra call per such note (kind 'note', 'manual', ≤ 3500 tokens, ≤ 90 s; dev tier-2 calls haiku 19 on 35 answered L notes, sonnet 23 on 56, max output 477 / 49 tokens). Fewer skips now (destructuring, self-corrected replies) and no tier-2 call when a no-avoid rule has no quoted line (skip instead). Grading side: one grading call per try as before (480 tokens, 60 s); a cap turns a would-be final 맞음 into a first try 거의 with one try again, so AT MOST ONE EXTRA grading call per capped practice (only if the learner tries again). Local work: one file read ≤ 200 KB (existing guarded reader) and a team-file stat (cached) per made rule practice graded 맞음 — nothing new leaves the device; the cap text quotes only the learner's or the example's tokens.",
 'measurement': "haiku only (default): 2 rounds × 85 note calls + ≈ 2 × 20 tier-2 calls + N2 2 × 30 = ≈ 270 haiku calls; calibration (M-5) on a fresh pinned 2.1.327 copy; opus writers ≈ 12 sample calls (≤ 10 records each) + 5 N2 answer calls + taps for empty replies. If the owner turns sonnet on, the same again for sonnet on the same samples (+ ≈ 270 calls, + 5 N2 writers).",
 'pilotSpent': "Pilot (records): haiku 153 calls, sonnet 158 calls (note 75 + tier-2 19/23 + N2 59/60), ≈ 46 opus writer calls (2 reasoning_extraction refusals re-sent once, 3 fake-tool-call writers re-run). Final phase: 0 model calls (offline re-reads only)."
}

D['compat'] = [
 "Stored shape: the 1.9.0/1.12.0 marked five-line section, no new label, line, key, field or structure number; first tries keep their 1.7.0 fields (mine, verdict, feedback, nudge, at) — the code-written feedback/nudge are plain strings in the existing fields.",
 "Old windows (0 calls): 3f2b4fb · 7a7b08c · 3690021 · fca5988 · 3d2f251 · de98243 · 30adc2f over 819 recorded texts of the dev sets (ON and OFF readings): 0 bad (final tree, oldwin113). A 1.12.0 window reading a 1.13.0 first try with code feedback shows it as any first try's feedback.",
 "OFF bytes: probe_off on the final tree, 11879 comparisons over 904 texts vs 30adc2f: 0 differ (drillOf, hideDrillAnswer, askPrompt, checkPrompt, parseCheck, shareText, keptNoteText, notePrompt). importsText's default max keeps every existing caller identical; ruleGradeCap, teamOf-for-avoids and the file read run only when build.isRuleDrill is true and the model said 맞음 on a made rule practice.",
 "D26: isRuleWide haiku + sonnet (impl112/d26/rulewide.mjs, 639 cases) and G2 haiku rungChangedStep 2 (9/9 requests) byte-identical on the final tree (see pilot.finalProofs).",
 "coexist19 / route19 / quiz18 / prompts18 / rule19 / ruledrill110 / ruledrill112 fixtures pass unchanged (full suite 1547/1547 on the final tree)."
]

D['budget'] = {
 'newKeys': 0, 'newCommands': 0, 'newInputFields': 0, 'newSettings': 0, 'newStoreKeys': 0, 'newStoreFields': 0, 'newConceptFields': 0, 'newEnvReads': 0,
 'newModelCalls': "0 new call kinds; the tier-2 call is 1.12.0's; at most one extra grading call (existing kind) per capped practice, only if the learner tries again.",
 'newReads': "1 local read on ON windows only: the drill file (≤ 200 KB, importsText with its permission and realPath guards) when a made rule practice is graded 맞음; the team file is the one screened() already read (teamOf, cached; one stat). Never sent, kept or shown.",
 'newUserStrings': 6,
 'newUserStringsList': ["규칙이 쓰라는 `…` 없이 고쳤습니다", "고친 줄에 원래 방식이 남아 있습니다: `…`", "이 노트의 코드에 없는 이름입니다: `…`", "괄호나 따옴표가 고칠 줄과 다르게 닫힙니다", "규칙 밖에서 바뀐 곳이 있습니다: `…` → `…`", "고칠 줄과 견주어 규칙 말고 바뀐 곳을 찾아보세요"]
}

D['tests'] = {
 'add': [
  "tests/rulecap.test.ts (10 tests in the prototype): each reason in order and its text; reorder exempt only for object/destructuring entries and Python kwargs (`{ CDN, API_URL } = config`, `{ b: y, a: x }`, `f(u, headers=h, params=o)` not capped; `apiRequest(opts, url)`, `used - total`, positional py reorder, duplicates `{ API_URL, API_URL }`, swapped kwarg values capped); the old way only for the rule's avoid roots (`toDateText(new Date(at))`, `to_date_text(datetime.fromisoformat(str(x)))`, `str(` dropped by the example not capped; `print(` / `process.env` left capped; no rule read → no rule-old); escapes and quote kinds compare by value, raw shown, 16-char cut, the nudge wording; GIVEN_NAMES families (ascii, NotImplementedError, innerWidth, requestAnimationFrame, ReadonlyArray, PropertyKey…) and plain words not given (name, status, path, fs, os, url, options, data, config); `function (it)` parameters bound; a spread `...options` looked up; spread order `{ ...base, ...opts }` reversed is a swap; keep syntax forms never capped (spread, keys, template, a name only in the file, a global, regex, TS as/annotation/generics, String(), f-string format specs, lambdas, comprehensions, kwargs, `from x import *`); member of the rule object unknown to the code; nameCode/usedNames; ruleFixUse.",
  "tests/flow110.test.ts: ON flow — model 맞음 on `options` → stored first try 거의 + code feedback + RULE_CAP_NUDGE, grading request = the 1.12.0 one (480); the try-again request PINNED ('## 학습자의 첫 답과 받은 되묻기 / 첫 답 / 첫 판정: 거의 / 받은 피드백: 이 노트의 코드에 없는 이름입니다: `options` / 받은 되묻기: …'); a right second line → right, isRetried; the same line again is not sent (unchanged), another line with the same unknown name ends partial (secondVerdict); the cap never lowers 거의/틀림 nor raises; rule-old uses drillRuleHint; OFF a 맞음 stays.",
  "tests/rulefix.test.ts: destructuring const/let/var tier 1 and tier 2 `= config;`, the refusals (`{ env: process.env }`, `f(process.env)`, writes, Object.keys); parseRuleFix last-whole-answer cases (and a short last answer → none); anchored-only lists for no-avoid rules and the 'no-hint' skip.",
  "Build phase (not in the prototype): tests/fixtures/ruledrill113.ts pinning the full tier-2 prompt for a no-avoid (date) note, hand-written from this design (ruledrill112 keeps pinning every case with an avoid name); a test that the ON grading first-try request equals rule19's bytes for a made practice (exists for 1.12.0, re-run)."
 ],
 'rewrittenOrRemoved': "None in the prototype (1547 = 1543 + 4 new, 0 removed). In a switch commit the 68 tests that assert the shipped OFF rows (G7 switch tables 54, 1.10.0 G6 10, F2 1, 진단 1, G6 writeNote 1, G2 1) are rewritten and listed by name.",
 'mutationProbes': "final/mut.py, each in a fresh copy, the named test file must fail: M1 cap also lowers 거의/틀림 · M2 f-string prefix dropped · M3 kwarg skip dropped · M4 file names dropped from the known set · M5 destructuring accepts f(process.env) · M6 parse takes the first answer · M7 unanchored lines listed for a no-avoid rule · M8 swap dropped · M9 reorder counted as swap · M10 set instead of multiset · M11 the old way is any dropped name · M12b spread order in { … } exempt (M12 'reorder exempt in a JS call's places' is an equivalent mutant: the keyword-argument check refuses positional entries too) · M13 string escapes not read · M14 function parameters not bound · M15 cap code not cut · M16 try again not capped · M17 no avoid names at grading · M18 Python positional reorder exempt · M19 spread read as a member. Results in pilot.finalProofs.",
 'gates': "`npx tsc -p . --noEmit` 0, `claude plugin validate .`, `claude plugin test .` (1547 on the prototype) before every commit; D26 rulewide.mjs 639 cases 0 diff; G2 9/9; probe_off 0 differ; old windows 0 bad."
}

D['pilot'] = {
 'recordsOnly': "Everything here is a design-time record (B-12): never in a decision; dev names never reused as measured samples.",
 'devSets': "Set 1 (36 samples E1*, sha256 10491a07…) and set 2 (39 samples E2*, sha256 c3d309c5…), frozen before any call; written blind by fresh opus writers (≤ 10 records per call).",
 'haiku': "153 calls. Answered 75/75. O 40, practices in O 0. den 26, correct 24 = 92.3% (set 1 14/13 = 92.9%, set 2 12/11 = 91.7%; misses: E1A10 not-one-span (haiku wrapped `toDateText(at.getTime())`, correctly refused), E2B04 os.getenv no-line (declined GA20 family)). Harmful 0, two-task 0 in ON and OFF, (c) 0, traps 0/12, R_long/no-short 0, unlabelled 0, tier-2 no-answer 0/19 (max 477 tokens vs 3500+2048), refusals 0, note cap hits 2 (E1D05, E2D07; recorded), old windows 0, W changed 4 / FP 0 / idempotent. Mini-N2 (one run per set): set 1 28/29, set 2 30/30; break→맞음 0, broken→맞음 0, missing 0, keep caps 0; haiku alone said 맞음 on broken E1A09-27 (`lateDate` undefined; cap 'name') and on break E2B03-26 (`process.env['PAY_TIMEOUT']`, 규칙: 지킴; cap 'rule-use') → pre-cap (break+broken)→맞음 1 per set.",
 'sonnet': "158 calls. Answered 75/75. O 19, practices in O 0. den 41, correct 38 = 92.7% (20/20, 21/18; misses no-hint 2 (E2A09, E2D10), os.getenv no-line 1 (E2B04)). Harmful 0, two-task 0 in ON and OFF, traps 0/12, unlabelled 0, tier-2 no-answer 0/23 (max 49 tokens), refusals 0, note cap hits 0, W changed 0. Mini-N2: set 1 29/30, set 2 29/30, break→맞음 0, broken→맞음 0, missing 0, keep caps 0 with the final cap (iteration 0 capped one reordered destructuring keep E1A07-18; fixed by the entry-reorder rule), cap never fired on a real sonnet error.",
 'iterations': "Iteration 0 = the given design; refinement 1 (pilot) = reorder of the example's own names not a swap (too broad); final (this file, after the critique, offline only): (b) rule-old limited to the rule's avoid roots; reorder exempt only for object/destructuring entries and Python kwargs; string escapes read and raw tokens shown; GIVEN_NAMES from the languages' references; `function (…)` parameters bound; a JS spread looked up (found while pinning the try-again flow); cap tokens cut at 16; nudge reworded; avoid names passed from the team file; try again held to the cap and its request pinned. None changes a prompt the pilot measured (note, tier-2 and first-try grading requests are byte-identical), so the pilot's request-side numbers stand; the post-call reading was re-run offline on every recorded answer.",
 'finalReReads': "Final cap (offline, 0 calls): dev N2 re-judged — haiku set 1 28/29, set 2 30/30; sonnet 29/30, 29/30; keep caps 0; pre-cap (break+broken)→맞음 haiku 1 · 1, sonnet 0 · 0 (unchanged from refinement 1). 201 recorded 1.12.0 N2 answers (60 measured + 141 dev mini-N2): keep 0/68 capped, break 66/66, broken 33/34 (miss: a dropped `await`, D1A05-16), off 33/33; GA02-10 capped ('name' `options`) in both runs → haiku's 1.12.0 N2 would read 28/30 with broken→맞음 0 and pre-cap 1. Blind 120-answer opus corpus: keep 0/60, broken 17/28 (uncaught: argument order with a literal, a dropped inner call/member, a dropped argument, a wrapper), break 25/25, off 7/7. Critique probes: `toDateText(new Date(at))`, `str(total)`, escaped quotes, ascii, innerWidth, `function (it)`, `{ body, headers }`, kwargs reorder → not capped; `apiRequest(opts, url)`, `used - total` → swap.",
 'finalProofs': P.get('text', 'pending')
}

D['critiqueResolution'] = [
 "1 (sonnet is a re-roll) — ACCEPTED: sonnet do-not-measure by default; owner question 0 is the only lever.",
 "2 (rule-old over-reach) — ACCEPTED and fixed: (b) uses only roots of the avoid names of the rule asking for `use` (ruleAvoidsOf from the team file screened() reads); none for no-avoid rules; tests + M11 + M17; replays unchanged (keep 0/68, 0/60).",
 "3 (second-try bytes unmeasured, sticky false cap) — ACCEPTED as stated risk + pin: the try again is held to the cap (choice: a line code sees against is never right on either try); its request pinned in flow110; a test shows the same line is not re-sent (DRILL_UNCHANGED, so the critique's 'retype the same line' path does not call) and another line with the same unknown name ends partial. Harm of a false sticky 거의 is small: a rule practice marks no concept and keeps no slip (finishDrill), only the day's count and journal. Recorded as E30 and a risk; second-try records are a build-phase pilot item (records only).",
 "4 (refinement 1 too broad) — ACCEPTED and fixed better than proposed: isLooseReorder exempts an entry-level reorder only in `{ … }` (no spread) and Python keyword arguments (a kwargs reorder is also a right form the critique's brace-list fix would have capped); call places and operands stay swaps; M9, M10, M12, M18.",
 "5 (bar change (ii) is a stance change) — ACCEPTED: written as an explicit STANCE line with two NEW stricter lines (keep caps = 0; pre-cap (break+broken)→맞음 ≤ 2) and pre-cap columns recorded; also owner question 1.",
 "6 (escapes / display) — ACCEPTED and fixed (escapes read, raw shown, raw strings keep backslashes); M13.",
 "7 (GIVEN_NAMES gaps, function params) — ACCEPTED and fixed from the languages' references; `function (…)` bound; plain-word globals deliberately left out; M14.",
 "8 (56-column claim, nudge) — ACCEPTED: tokens cut at 16 (M15), nudge reworded to compare with 고칠 줄; widths stated honestly (fixed parts ≤ 32 columns, name lines ≤ 50; a swap line with two long tokens can reach 67 and wraps like the existing hint).",
 "9 (cost/measurement statements) — ACCEPTED: one extra grading call per capped practice stated; the real-file-only-laxer risk stated; one base rate (3/548, ≈ 39%) used throughout.",
 "Found while applying: a JS spread `...x` was read as a member, so `apiRequest(url, { ...options })` escaped the name check — fixed (M19) and tested."
]

D['risks'] = [
 "haiku N2: a broken sub-kind the cap cannot see (argument order with a literal, a dropped inner call/member or argument, a dropped `await`, a wrapper) graded 맞음 → broken→맞음 1 fails N2. Corpus: 11 of 28 such broken answers uncaught; every haiku false-맞음 seen so far (3) was a name or rule kind. ≈ 10–20% per measured N2.",
 "haiku N2: a keep written in a form the cap lowers (a defined-but-different name in the example's shape, a raw/escaped string variant) fails the NEW keep-caps line: 0 of 168 keeps capped with the final cap, 1 before refinement; ≈ 5%.",
 "The real plugin reads the drill file as it is NOW; N2 passes the frozen after-file. The union with the diff can only add names, so the real cap is at most as strict as the measured one (a learner's broken line using a name that exists elsewhere in the real file is not caught).",
 "Second-try requests carry code-written '첫 판정: 거의' and feedback; never measured by N2 (first tries only, as in every earlier round). A falsely capped right line stays 거의 on a different right retry with the same cause (sticky); a rule practice marks no concept, so the cost is the day's count and the journal line.",
 "den margin: two rounds each ≥ 80% with ≈ 1 structural den miss per round declined (os.getenv, no-quote date notes, api_request argument order).",
 "Sonnet: not measured by default; if measured, P(two-task line passes) ≈ 39% regardless of this design.",
 "isRuleWide W false positive in either round blocks isRuleDrill (shared W2; 0 in 1.12.0 measured and 1.13.0 dev for haiku).",
 "Another 1.13.0 design touching checkPrompt/parseCheck, notePrompt, keptNoteText/ruleLabelled/ruleNamesOf or drillOf/hideDrillAnswer OFF paths would change measured bytes (D26) — must be ordered or re-pinned before this bar commit.",
 "Sonnet trace-refusal fact: no new prompt wording, so no new refusal risk (tier-2 and grading prompts unchanged; 0 refusals in 1.12.0 measured and 1.13.0 dev)."
]

D['dependsOn'] = [
 "MODEL_SWITCHES[m].isRuleWide true (shipped 1.10.0, unchanged code).",
 "1.13.0 calibration (M-5) on a fresh pinned copy of the installed Claude Code: H_haiku (and H_sonnet if sonnet is measured) and the version record.",
 "No other 1.13.0 design changes notePrompt, the W2 helpers (ruleLabelled, keptNoteText, ruleNamesOf, holdsName), checkPrompt/RULE_CHECK/CHECK_SYSTEM/parseCheck, drillOf/hideDrillAnswer OFF paths or askPrompt; if one does, D26 rules apply and N2 is measured on the resulting bytes.",
 "G2 haiku's shipped cell (rungChangedStep 2): its measured requests, picks and reading stay byte-identical (proved on the prototype; re-proved at the build commit)."
]

D['whatWouldHaveToChange'] = {
 'sonnet': "An owner decision on the two-task line for isRuleDrill (count only the ON/stored reading), or the owner explicitly accepting a ≈ 30% round, or a separate isRuleWide/note-call design for sonnet that removes self-correcting multi-task notes (with its own D26 consequence for the shipped isRuleWide sonnet cell).",
 'haiku': "Nothing before measuring. If it fails on a broken sub-kind the cap cannot see, the next lever is wider grading context (the grading request with the file's defined names), which changes ON grading bytes and is a new N2."
}

D['recommend'] = {
 'haiku': 'measure',
 'sonnet': 'do-not-measure',
 'evidence': {
  'haiku': "Dev (records, 75 notes, 2 fresh sets): every N1′ zero-tolerance line 0, den 92.3%, mini-N2 28/29 and 30/30 with broken→맞음 0, break→맞음 0, keep caps 0, pre-cap 1 per set; the 1.12.0 failing kind recurred twice and the cap caught both. Offline: GA02-10 now 거의 in both 1.12.0 runs; keep caps 0/68 + 0/60 + 0/40 (dev N2 keeps) with the final cap.",
  'sonnet': "Dev numbers at or above every line, but the deciding 1.12.0 failure line (two-task, OFF reading of the shipped note call) is untouched by every change here; the cap gave sonnet no measured benefit (0 break/broken→맞음 alone). Measuring would be a re-roll at ≈ 39% on that line (≈ 30% overall), against the owner rule 'one measured round per design per model; no re-rolls'."
 }
}

D['ownerQuestions'] = [
 "0. 팀 규칙 연습(isRuleDrill)의 '할 일 줄 둘 = 0' 줄은 지금 켠 읽기와 끈 읽기를 모두 셉니다. 끈 읽기는 이미 켜져 나가는 isRuleWide sonnet의 노트 호출 그대로라 이 기능이 바꿀 수 없고, 1.12.0 sonnet은 그 한 줄(GD15)로만 못 넘었습니다. (a) isRuleDrill 기준에서는 켠 읽기(저장되는 글)만 세고 끈 읽기의 할 일 줄 둘은 isRuleWide 쪽 기록으로 옮길까요? 그러면 sonnet도 같은 견본으로 1.13.0에서 잽니다(기준 줄이 너그러워지는 것은 주인 결정으로만 가능). (b) 끈 읽기도 그대로 세되, 넘을 확률 약 30%를 알고 sonnet을 잴까요? (c) 기본값: 그대로 세고 sonnet은 1.13.0에서 재지 않습니다.",
 "1. N2를 '학습자에게 보이는 판정'(모델 판정 뒤 코드가 맞음을 거의로 낮춘 것)으로 세고, 대신 더 엄격한 줄 둘(지킴 답을 코드가 낮추면 못 넘음, 낮추기 전 어김 + 깨짐→맞음 ≤ 2)을 더하는 것을 1.13.0 기준으로 커밋해도 될까요? 기본값: 예(기준 표의 'gradeDrill이 매기는 대로'를 1.13.0 gradeDrill로 읽고, 입장 바꿈을 재기 전에 밝힘). '아니오'면 이 설계는 haiku의 1.12.0 실패를 고치지 못하므로 haiku도 재지 않습니다."
]
json.dump(D, open(f'{S}/impl113/design/G6.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('written', len(json.dumps(D, ensure_ascii=False)))
