import re,sys
p='/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6/proto/repo/hooks/notes.ts'
t=open(p,encoding='utf-8').read()
def rep(old,new,count=1):
    global t
    n=t.count(old)
    if n!=count: sys.exit(f'count {n} for {old[:80]!r}')
    t=t.replace(old,new)

# ---- GIVEN_NAMES: from the languages' references
start=t.index('/**\n * Names a language gives with no file making them')
end=t.index('/** Where a JavaScript `/` opens a regular expression')
JS_KW='await async const let var return new typeof instanceof in of if else function class this super null undefined true false void delete yield throw try catch finally switch case default break continue do while for import export from as extends static get set with debugger arguments'
JS_ES='globalThis Infinity NaN Math JSON Number String Boolean Array Object Function Symbol BigInt Promise Date RegExp Error TypeError RangeError SyntaxError ReferenceError EvalError URIError AggregateError Map Set WeakMap WeakSet WeakRef FinalizationRegistry Proxy Reflect Intl Atomics Iterator ArrayBuffer SharedArrayBuffer DataView Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array BigInt64Array BigUint64Array parseInt parseFloat isNaN isFinite encodeURIComponent decodeURIComponent encodeURI decodeURI escape unescape eval'
JS_NODE='console process require module exports Buffer global __dirname __filename setTimeout clearTimeout setInterval clearInterval setImmediate clearImmediate queueMicrotask structuredClone performance crypto fetch Response Request Headers FormData Blob File URL URLSearchParams AbortController AbortSignal TextEncoder TextDecoder TextEncoderStream TextDecoderStream atob btoa Event EventTarget CustomEvent MessageEvent MessageChannel MessagePort BroadcastChannel DOMException WebSocket WebAssembly ReadableStream WritableStream TransformStream CompressionStream DecompressionStream Crypto CryptoKey SubtleCrypto Navigator Performance PerformanceObserver'
JS_DOM='window document self navigator location localStorage sessionStorage alert confirm innerWidth innerHeight outerWidth outerHeight scrollX scrollY pageXOffset pageYOffset devicePixelRatio requestAnimationFrame cancelAnimationFrame requestIdleCallback cancelIdleCallback getComputedStyle getSelection matchMedia indexedDB customElements visualViewport HTMLElement Element Node NodeList Document DocumentFragment ShadowRoot Image Audio FileReader FileList XMLHttpRequest Worker SharedWorker IntersectionObserver MutationObserver ResizeObserver KeyboardEvent MouseEvent PointerEvent InputEvent FocusEvent UIEvent ErrorEvent ProgressEvent StorageEvent PopStateEvent DOMParser XMLSerializer Notification ClipboardItem EventSource Storage HTMLInputElement HTMLFormElement HTMLButtonElement HTMLDivElement HTMLAnchorElement HTMLImageElement HTMLCanvasElement HTMLSelectElement HTMLTextAreaElement SVGElement CanvasRenderingContext2D OffscreenCanvas ImageData AudioContext MediaStream'
JS_TS='string number boolean any unknown never object bigint symbol keyof readonly satisfies type interface enum namespace declare abstract implements private public protected override is asserts infer unique Partial Required Readonly Record Pick Omit Exclude Extract NonNullable ReturnType Parameters ConstructorParameters InstanceType Awaited ThisType ThisParameterType OmitThisParameter Uppercase Lowercase Capitalize Uncapitalize NoInfer ReadonlyArray ReadonlyMap ReadonlySet ArrayLike PropertyKey PromiseLike Iterable IterableIterator AsyncIterable AsyncIterator AsyncIterableIterator Generator AsyncGenerator TemplateStringsArray PropertyDescriptor RequestInit HeadersInit BodyInit ResponseInit RequestInfo NodeJS'
PY_KW='False None True and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield match case type _'
PY_B='ArithmeticError AssertionError AttributeError BaseException BaseExceptionGroup BlockingIOError BrokenPipeError BufferError BytesWarning ChildProcessError ConnectionAbortedError ConnectionError ConnectionRefusedError ConnectionResetError DeprecationWarning EOFError Ellipsis EncodingWarning EnvironmentError Exception ExceptionGroup FileExistsError FileNotFoundError FloatingPointError FutureWarning GeneratorExit IOError ImportError ImportWarning IndentationError IndexError InterruptedError IsADirectoryError KeyError KeyboardInterrupt LookupError MemoryError ModuleNotFoundError NameError NotADirectoryError NotImplemented NotImplementedError OSError OverflowError PendingDeprecationWarning PermissionError ProcessLookupError PythonFinalizationError RecursionError ReferenceError ResourceWarning RuntimeError RuntimeWarning StopAsyncIteration StopIteration SyntaxError SyntaxWarning SystemError SystemExit TabError TimeoutError TypeError UnboundLocalError UnicodeDecodeError UnicodeEncodeError UnicodeError UnicodeTranslateError UnicodeWarning UserWarning ValueError Warning ZeroDivisionError abs aiter all anext any ascii bin bool breakpoint bytearray bytes callable chr classmethod compile complex copyright credits delattr dict dir divmod enumerate eval exec exit filter float format frozenset getattr globals hasattr hash help hex id input int isinstance issubclass iter len license list locals map max memoryview min next object oct open ord pow print property quit range repr reversed round set setattr slice sorted staticmethod str sum super tuple type vars zip self cls __name__ __file__ __doc__ __debug__ __import__ __builtins__ __spec__ __package__'
def wrap(words, indent='      '):
    out=[];line=''
    for w in words.split():
        if len(line)+len(w)+1>110: out.append(line); line=''
        line+=w+' '
    out.append(line)
    out[-1]=out[-1].rstrip()
    return ' +\n'.join(f"{indent}'{l}'" for l in out)
new='''/**
 * Names a language gives with no file making them (1.13.0 G6, ruleGradeCap), from the languages' own references:
 * JavaScript's keywords, ECMAScript's globals, Node's globals (not its modules: `fs`, `path`, `os` are a file's names),
 * the browser's that are no plain word (`innerWidth`, not `name` or `status`), TypeScript's primitive, lib and utility
 * types; Python's keywords (soft ones too) and every builtin (`dir(builtins)`, exceptions and all). A closed list of
 * the languages' own names, never one of a project's: a name in it is never held against a typed line.
 */
export const GIVEN_NAMES: Readonly<Record<'js' | 'py', ReadonlySet<string>>> = {
  js: new Set(
    (
'''+wrap(' '.join([JS_KW,JS_ES,JS_NODE,JS_DOM,JS_TS]))+'''
    ).split(' '),
  ),
  py: new Set(
    (
'''+wrap(' '.join([PY_KW,PY_B]))+'''
    ).split(' '),
  ),
}

'''
t=t[:start]+new+t[end:]

# ---- bind function (...) parameters
rep("""  for (const m of code.matchAll(/([\\p{L}_$][\\p{L}\\p{N}_$]*)\\s*=>/gu)) bound.add(m[1]!)
""","""  for (const m of code.matchAll(/([\\p{L}_$][\\p{L}\\p{N}_$]*)\\s*=>/gu)) bound.add(m[1]!)
  for (const m of code.matchAll(/\\bfunction\\b\\s*\\*?\\s*(?:[\\p{L}_$][\\p{L}\\p{N}_$]*)?\\s*\\(([^()]*)\\)/gu)) bind(m[1]!)
""")
rep(""" * `catch (e)`, Python's `as` and `:=`,""",""" * `catch (e)`, a `function (…)`'s parameters, Python's `as` and `:=`,""")

# ---- shapeTokens: raw kept, string bodies unescaped
rep("""/** A line's code as tokens a grade's shape check compares (1.13.0 G6): names, keywords, values, marks. */
type ShapeToken = { kind: 'name' | 'word' | 'value' | 'live' | 'mark'; text: string }""","""/**
 * A line's code as tokens a grade's shape check compares (1.13.0 G6): names, keywords, values, marks; `text` what is
 * compared, `raw` what the line wrote (what a cap shows).
 */
type ShapeToken = { kind: 'name' | 'word' | 'value' | 'live' | 'mark'; text: string; raw: string }""")
rep(""" * A line's code as tokens (1.13.0 G6, ruleGradeCap): spaces and a last `;` dropped; a string by its text (', " and a
 * template with no `${` alike), one holding code as it is (`live`), a number by its value, a name, a keyword or one mark.""",""" * A line's code as tokens (1.13.0 G6, ruleGradeCap): spaces and a last `;` dropped; a string by its text, its escapes
 * read (', " and a template with no `${` alike: `'it\\\\'s'` is `"it's"`), one holding code as it is (`live`), a number
 * by its value, a name, a keyword or one mark.""")
rep("""      out.push(isLive ? { kind: 'live', text: m[1] } : { kind: 'value', text: `${prefix}'${body}'` })
    } else if (m[2] !== undefined) out.push({ kind: 'value', text: String(Number(m[2].replace(/_/g, ''))) })
    else if (m[3] !== undefined) out.push({ kind: words.has(m[3]) ? 'word' : 'name', text: m[3] })
    else if (m[4] !== undefined) out.push({ kind: 'mark', text: m[4] })""","""      // A raw string (`r'…'`) keeps its backslashes; any other reads `\\x` as `x` (an escaped quote, `\\\\`).
      const text = prefix.includes('r') ? body : body.replace(/\\\\(.)/gsu, '$1')
      out.push(isLive ? { kind: 'live', text: m[1], raw: m[1] } : { kind: 'value', text: `${prefix.replace('r', '')}'${text}'`, raw: m[1] })
    } else if (m[2] !== undefined) out.push({ kind: 'value', text: String(Number(m[2].replace(/_/g, ''))), raw: m[2] })
    else if (m[3] !== undefined) out.push({ kind: words.has(m[3]) ? 'word' : 'name', text: m[3], raw: m[3] })
    else if (m[4] !== undefined) out.push({ kind: 'mark', text: m[4], raw: m[4] })""")

# ---- ruleAvoidsOf helper + (b) on avoid roots only
rep("""/** Why code holds a made team-rule practice's typed line short of right (ruleGradeCap). */""","""/**
 * The names the team rules that ask for `use` say not to use (1.13.0 G6, ruleGradeCap's old way left): each rule read
 * by ruleSidesOf (fail-closed) whose use names hold `use`. None for a rule that says nothing not to use (the date
 * rule's), nor for any rule read otherwise.
 */
export function ruleAvoidsOf(rules: readonly string[], use: string): string[] {
  return [...new Set(rules.map(ruleSidesOf).filter(side => side.use.includes(use)).flatMap(side => side.avoid))]
}

/** Why code holds a made team-rule practice's typed line short of right (ruleGradeCap). */""")
rep(""" * code alone (`known`, capKnownNames), `use` the name its check names (ruleFixUse). The first that holds, in this order:
 * the line's code holds no use of that name's first part (`log` of `log.info`): `rule-use`; it still calls, indexes or
 * reads a member of a name the line to change did there and the example dropped (the old way left: `fetch(`,
 * `process.env`): `rule-old`;""",""" * code alone (`known`, capKnownNames), `use` the name its check names (ruleFixUse), `avoids` what the rule asking for
 * it says not to use (ruleAvoidsOf). The first that holds, in this order:
 * the line's code holds no use of that name's first part (`log` of `log.info`): `rule-use`; it still calls, indexes or
 * reads a member of the first part of a name the rule says not to use, where the line to change did and the example
 * dropped it (the old way left: `fetch(`, `process.env`; never another name the example dropped, `new Date(…)` or
 * `str(…)`, and none for a rule that says nothing not to use): `rule-old`;""")
rep(""" * value of its own in a place the use name is not (`apiRequest(otherUrl)`): `swap`. Undefined for none.""",""" * value of its own in a place the use name is not (`apiRequest(otherUrl)`), the example's own names in another order
 * only inside one `{ a, b }` list (a destructuring or an object's shorthand names: order there means nothing): `swap`.
 * Undefined for none.""")
rep("""  lang: CapLang,
  file = '',
): RuleGradeCap | undefined {""","""  lang: CapLang,
  file = '',
  avoids: readonly string[] = [],
): RuleGradeCap | undefined {""")
rep("""  const left = [...reached(nameCode(drill.line, lang))].find(name => !exWords.has(name) && reached(code).has(name))""","""  const roots = new Set(avoids.map(name => name.split('.')[0]!))
  const left = [...reached(nameCode(drill.line, lang))].find(name => roots.has(name) && !exWords.has(name) && reached(code).has(name))""")

# ---- (e) reorder exempt only inside one brace shorthand list; raw shown
rep("""    const moved: { from: string; to: string }[] = []""","""    const moved: { at: number; from: string; to: string }[] = []""")
rep("""      moved.push({ from: one.text, to: other.text })
    }
    // The example's own names and values in another order are no swap (`const { b, a } = config;` lists what
    // `{ a, b }` does): only a name or a value the example's places do not hold between them is.
    const sorted = (list: string[]) => JSON.stringify([...list].sort())
    const isReorder = sorted(moved.map(one => one.from)) === sorted(moved.map(one => one.to))
    if (isShape && moved.length > 0 && !isReorder) return { why: 'swap', ...moved[0]! }""","""      moved.push({ at: i, from: one.raw, to: other.raw })
    }
    // The example's own names in another order are no swap only inside one `{ … }` that lists names alone
    // (`const { b, a } = config;` reads what `{ a, b }` does; `send({ b, a })` sends it): there order means nothing.
    // In a call's arguments or an operation (`apiRequest(opts, url)`, `used - total`) it does, and stays a swap.
    const sorted = (list: string[]) => JSON.stringify([...list].sort())
    const list = isShape && moved.length > 0 ? shorthandListAt(a, moved[0]!.at) : undefined
    const isReorder =
      list !== undefined &&
      moved.every(one => one.at > list.open && one.at < list.close) &&
      sorted(moved.map(one => a[one.at]!.text)) === sorted(moved.map(one => b[one.at]!.text))
    if (isShape && moved.length > 0 && !isReorder) return { why: 'swap', from: moved[0]!.from, to: moved[0]!.to }""")
rep("""/** The use name a practice's check names (ruleFixCheck)""","""/**
 * The `{ … }` round token `at` when it lists names alone, commas between (a destructuring's names, an object's
 * shorthand ones): its brackets' places; undefined for any other place (a call's arguments, an operation, `{ a: b }`).
 */
function shorthandListAt(tokens: readonly ShapeToken[], at: number): { open: number; close: number } | undefined {
  let depth = 0
  let open = -1
  for (let i = at - 1; i >= 0; i -= 1) {
    const one = tokens[i]!
    if (one.kind !== 'mark') continue
    if ('}])'.includes(one.text)) depth += 1
    else if ('{[('.includes(one.text)) {
      if (depth === 0) {
        open = i
        break
      }
      depth -= 1
    }
  }
  if (open === -1 || tokens[open]!.text !== '{') return undefined
  let close = -1
  for (let i = open + 1; i < tokens.length; i += 1) {
    const one = tokens[i]!
    if (one.kind === 'mark' && one.text === '}') {
      close = i
      break
    }
    // Names and commas only, alternating: `{ a, b, c }`.
    const isName = (i - open) % 2 === 1
    if (isName ? one.kind !== 'name' : !(one.kind === 'mark' && one.text === ',')) return undefined
  }
  return close === -1 ? undefined : { open, close }
}

/** The use name a practice's check names (ruleFixCheck)""")

# ---- texts: cut tokens, nudge reworded
rep("""/** The question a capped grade asks back for its try again when the line is not the rule's way short (no example in it). */
export const RULE_CAP_NUDGE = '고친 줄을 위 코드와 한 글자씩 견주어 보세요'""","""/** The question a capped grade asks back for its try again when the line is not the rule's way short (no example in it). */
export const RULE_CAP_NUDGE = '고칠 줄과 견주어 규칙 말고 바뀐 곳을 찾아보세요'
/** Characters of a name or a value a capped grade's line shows at most (ruleCapText), `…` after a longer one. */
const RULE_CAP_CODE = 16""")
rep("""export function ruleCapText(cap: RuleGradeCap): string {
  switch (cap.why) {
    case 'rule-use':
      return `규칙이 쓰라는 ${tickCode(cap.name)} 없이 고쳤습니다`
    case 'rule-old':
      return `고친 줄에 원래 방식이 남아 있습니다: ${tickCode(cap.name)}`
    case 'name':
      return `이 노트의 코드에 없는 이름입니다: ${tickCode(cap.name)}`
    case 'brackets':
      return RULE_CAP_BRACKETS
    case 'swap':
      return `규칙과 상관없는 곳이 바뀌었습니다: ${tickCode(cap.from)} → ${tickCode(cap.to)}`
  }
}""","""export function ruleCapText(cap: RuleGradeCap): string {
  const code = (text: string) => tickCode([...text].length > RULE_CAP_CODE ? `${[...text].slice(0, RULE_CAP_CODE - 1).join('')}…` : text)
  switch (cap.why) {
    case 'rule-use':
      return `규칙이 쓰라는 ${code(cap.name)} 없이 고쳤습니다`
    case 'rule-old':
      return `고친 줄에 원래 방식이 남아 있습니다: ${code(cap.name)}`
    case 'name':
      return `이 노트의 코드에 없는 이름입니다: ${code(cap.name)}`
    case 'brackets':
      return RULE_CAP_BRACKETS
    case 'swap':
      return `규칙 밖에서 바뀐 곳이 있습니다: ${code(cap.from)} → ${code(cap.to)}`
  }
}""")
open(p,'w',encoding='utf-8').write(t)
print('ok')
