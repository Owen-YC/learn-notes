import { describe, expect, test } from 'claude-code/testing'
import { newRun } from '../hooks/notes'
import { CORPUS } from './fixtures/corpus3'

describe('newRun in the engine runtime equals newRun under node, chunk 3 (records only)', () => {
  test('the same lines or the same refusal', () => {
    const differ: string[] = []
    let accepted = 0
    for (const [id, lang, code, want] of CORPUS) {
      const got = newRun(code, lang)
      if ('lines' in want) accepted += 1
      if (JSON.stringify(got) !== JSON.stringify(want)) differ.push(`${id} ${JSON.stringify(got).slice(0, 120)} != ${JSON.stringify(want).slice(0, 120)}`)
    }
    console.log(`ENGINECHK chunk 3 programs ${CORPUS.length} accepted-under-node ${accepted} differ ${differ.length}`)
    for (const d of differ.slice(0, 20)) console.log('ENGINECHK ' + d)
    expect(differ.length).toBe(0)
  })
})
