// 0-call scope read of a dev or old set (records only): per change, the callees code finds and each anchor's calc result.
import { N, samples, shownOf, noteOf } from './lib.mjs'
const [dir, groupFile] = process.argv.slice(2)
const groupOf = groupFile ? (await import('node:fs')).readFileSync(groupFile, 'utf8').trim().split('\n').reduce((a, l) => { const [id, g] = l.split(/\s+/); a[id] = g; return a }, {}) : null
let inOk = 0, inAll = 0, outOpen = 0, outAll = 0
for (const { sample, entry } of samples(dir)) {
  const shown = shownOf(noteOf(entry, sample))
  const scope = N.thinkCalcScope(shown.changes)
  const g = groupOf ? groupOf[sample.id] : sample.group
  const has = scope.callees.length > 0
  if (g === 'in') { inAll++; if (has) inOk++ } else { outAll++; if (has) outOpen++ }
  const desc = scope.callees.map(c => {
    const mod = scope.mods.get(c.file)
    const r = c.anchor ? N.calcCall(mod, c.anchor) : undefined
    return `${c.name}${c.anchor ? ` @${c.anchor} -> ${r.kind === 'value' ? r.show : r.kind === 'error' ? 'ERR ' + r.name : '?' + r.why}` : ''}`
  })
  console.log(sample.id, g, sample.lang, has ? 'IN ' : '-- ', desc.join(' | '))
}
console.log(`in-scope accepted ${inOk}/${inAll}; outside opened ${outOpen}/${outAll}`)
