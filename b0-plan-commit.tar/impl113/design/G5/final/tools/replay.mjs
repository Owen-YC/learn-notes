// Offline re-read (records only, B-12): the same stored lines and the same saved check replies, read by the fixed code.
//   node replay.mjs <set> <model> <label> <round>  -> ../replay/read-<label>-<round>.json + a diff summary
import { readFileSync, writeFileSync } from 'node:fs'
import { N, samples, readJson, shownOf } from './lib.mjs'
import { keptNote, outOf, R_AT, ASKED_AT, LEVEL, DEV } from './build.mjs'
const [set, model, label, round] = process.argv.slice(2)
const D = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G5/pilot'
const P = `${D}/${set}`
const qs = Object.fromEntries(readJson(`${P}/questions-${label}.json`).questions.map(q => [q.q, q]))
const texts = readJson(`${P}/texts-${label}.json`).texts
const stored = readJson(`${P}/r/stored-${model}.json`)
const notes = outOf(`${P}/note/${model}/out.json`)
const byId = Object.fromEntries(samples(`${DEV}/${set}`).map(one => [one.sample.id, one]))
const old = Object.fromEntries(readJson(`${P}/n/read-${label}-${round}.json`).map(r => [r.id, r]))
const res = outOf(`${P}/n/${model}-${round}/out.json`)
const idOf = t => `${t.q}-${t.k}`
let same = 0, changed = 0, needCall = 0, toCode = 0
const rows = []
for (const t of texts) {
  const id = qs[t.q].id
  const { sample, entry } = byId[id]
  const note = { ...keptNote(sample, entry, notes[id].text), asks: [{ question: N.TRACE_LABEL, answer: stored[id].stored, at: R_AT }] }
  const shown = shownOf(note)
  const think = N.openThink(shown.asks, ASKED_AT, true, true)
  const masked = N.redactText(t.text).text
  const plan = N.thinkCalcPlan(shown, think, masked, LEVEL, N.thinkVariantOf(model))
  const seen = [shown.text, think.trace, masked, ...shown.changes.map(c => c.diff)].join('\n')
  const r = res[idOf(t)]
  const o = old[idOf(t)]
  let text = '', note2 = ''
  if (plan.kind === 'code') { text = N.cut(plan.text, 4000); if (o.path !== 'code') { toCode++; note2 = 'now code' } }
  else if (plan.kind === 'check') {
    if (o.path === 'code') { needCall++; note2 = 'now check (no saved reply)'; text = null }
    else if (r?.isAnswered) text = N.cut(N.thinkCalcReply(r.text, plan.facts, masked, seen), 4000)
  } else note2 = 'fallback'
  const isSame = text === o.shown
  if (text !== null) { if (isSame) same++; else changed++ }
  rows.push({ ...o, path: plan.kind, shown: text === null ? o.shown : text, oldShown: o.shown, changed: !isSame, note: note2 })
}
writeFileSync(`../replay/read-${label}-${round}.json`, JSON.stringify(rows, null, 1) + '\n')
console.log(set, label, round, 'same', same, 'changed', changed, 'toCode', toCode, 'needCall', needCall)
for (const r of rows) if (r.changed || r.note) console.log('  ', r.id, r.kind, r.note, '|', JSON.stringify(r.text).slice(0, 50), '\n     OLD', JSON.stringify(r.oldShown).slice(0, 160), '\n     NEW', JSON.stringify(r.shown).slice(0, 160))
