"""G5e pilot runner (records only): the 1.12.0 b4 runner procedure verbatim (A, else B; js twice, py five seeds,
unshare -n timeout 5) on each opened line's call, plus calc's own result for that call (equality is a STOP flag).
usage: runner.py <stored.json> <out.json>"""
import json, os, sys, importlib.util
spec = importlib.util.spec_from_file_location('runner', '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4/tools/runner.py')
R = importlib.util.module_from_spec(spec); spec.loader.exec_module(R)
R.WORK = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G5/final/work/runner'
R.EMPTY = R.WORK + '/empty-stdin'
os.makedirs(R.WORK, exist_ok=True); open(R.EMPTY, 'w').close()
src, dst = sys.argv[1], sys.argv[2]
if os.path.exists(dst): sys.exit('refuse: exists')
stored = json.load(open(src))
out = {}
for id_, e in stored.items():
    if not e.get('line'): continue
    rec = R.run_line({'line': e['line'], 'calleeFile': e['calleeFile'], 'changes': e['changes']})
    rec['calc'] = e.get('calc')
    rec['calcAgrees'] = rec['runner'] and rec['out'] == e.get('calc')
    out[id_] = {k: rec[k] for k in ('call', 'file', 'lang', 'procedure', 'runner', 'out', 'final', 'calc', 'calcAgrees') if k in rec}
    print(id_, rec['lang'], rec.get('procedure'), 'OK' if rec['runner'] else 'NO', rec['call'], '->', rec['out'], '| calc', e.get('calc'), '' if rec['calcAgrees'] else '<<< DIFF')
json.dump(out, open(dst, 'w'), ensure_ascii=False, indent=1)
print('lines', len(out), 'runner', sum(1 for r in out.values() if r['runner']), 'calc agrees', sum(1 for r in out.values() if r['calcAgrees']))
