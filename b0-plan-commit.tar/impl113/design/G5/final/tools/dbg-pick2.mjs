import { N, readJson } from './lib.mjs'
const [set, model, id] = process.argv.slice(2)
const st = readJson(`${process.env.P}/${set}/r/stored-${model}.json`)[id]
const scope = N.thinkCalcScope(st.changes)
const c = scope.callees[0]
const mod = scope.mods.get(c.file)
const ex = /예시 호출:\s*`([^`]+)`/.exec(st.raw)?.[1]
const call = N.parseThinkCall(ex, c.isPy)
const run = N.calcCall(mod, ex)
console.log('run', run.kind, run.show)
const walkText = st.raw
const spans = new Set([walkText, st.noteText].flatMap(text => [...text.matchAll(/`([^`\n]+)`/g)].map(m => m[1].trim())))
console.log([...spans].filter(s => /^[\d.]+$/.test(s)))
console.log(N.thinkPick({ call, callee: c }, run, mod, walkText, st.noteText, st.changes.map(x => x.diff)))
