// G5e pilot (records only, B-12): the lines of each call kind as the proto tree's askNote sends them.
//   note <set>             -> pilot/<set>/note/lines.jsonl          (writeNote's call; same prompt for both models)
//   r <set> <model>        -> pilot/<set>/r/lines-<model>.jsonl     (r's key on the kept note)
//   stored <set> <model>   -> pilot/<set>/r/stored-<model>.json      (what askNote keeps of r's answer; the line it opens)
// Numbers as register.tsx at 30adc2f: NOTE_TOKENS 3500, r 900, check 900, timeout 90000; effort low; level beginner.
import { existsSync, mkdirSync, writeFileSync } from 'node:fs'
import { dirname } from 'node:path'
import { N, D, noteOf, shownOf, samples, readJson } from './lib.mjs'

export const NUMS = { NOTE_TOKENS: 3500, ASK_TOKENS: 900, THINK_CHECK_TOKENS: 900, MODEL_TIMEOUT_MS: 90000 }
export const LEVEL = 'beginner'
export const NOTE_AT = Date.UTC(2026, 10, 4, 0, 0, 0)
export const R_AT = NOTE_AT + 120_000
export const ASKED_AT = R_AT + 60_000
export const DEV = `${D}/dev`
export function writeOnce(path, text) {
  if (existsSync(path)) throw new Error(`refuse: ${path} exists`)
  mkdirSync(dirname(path), { recursive: true })
  writeFileSync(path, text)
}
export const outOf = path => Object.fromEntries(readJson(path).results.map(r => [r.id, r]))
export function keptNote(sample, entry, answer) {
  return { ...noteOf(entry, sample), status: 'ready', text: N.keptNoteText(answer, []) }
}
/** askNote for r's key, ON: the scope read from the screened note; the question built from it (or 1.7.0's). */
export function rLine(model, sample, entry, noteAnswer) {
  const shown = shownOf(keptNote(sample, entry, noteAnswer))
  const scope = N.thinkCalcScope(shown.changes)
  const isCode = scope.callees.length > 0
  const masked = N.redactText(isCode ? N.traceCalcQuestion(scope.callees) : N.traceQuestion(false)).text
  return { line: { id: sample.id, model, system: N.ASK_SYSTEM, prompt: N.redactText(N.askPrompt(shown, masked, LEVEL, undefined, undefined, true)).text, maxTokens: NUMS.ASK_TOKENS, timeoutMs: NUMS.MODEL_TIMEOUT_MS }, shown, scope }
}
/** What askNote stores of r's answer, and what opens a minute on. */
export function readR(sample, entry, noteAnswer, rText) {
  const { shown, scope } = rLine('x', sample, entry, noteAnswer)
  const isCode = scope.callees.length > 0
  const stored = N.cut(isCode ? N.thinkCalcKept(rText, scope, shown.text, shown.changes.map(one => one.diff)) : N.thinkKept(rText, false), 4000)
  const asks = [{ question: N.TRACE_LABEL, answer: stored, at: R_AT }]
  const think = N.openThink(asks, ASKED_AT, true, true)
  return { isCode, scope, stored, think, shown }
}

if (process.argv[1]?.endsWith('build.mjs')) {
  const [mode, set, model] = process.argv.slice(2)
  const P = `${D}/pilot/${set}`
  if (mode === 'note') {
    const lines = samples(`${DEV}/${set}`).flatMap(({ sample, entry }) => ['haiku', 'sonnet'].map(m => {
      const shown = shownOf(noteOf(entry, sample))
      return { id: sample.id, model: m, system: N.SYSTEM, prompt: N.redactText(N.notePrompt(shown, LEVEL, N.knownNames({}), undefined)).text, maxTokens: NUMS.NOTE_TOKENS, timeoutMs: NUMS.MODEL_TIMEOUT_MS }
    }))
    for (const m of ['haiku', 'sonnet']) writeOnce(`${P}/note/lines-${m}.jsonl`, lines.filter(l => l.model === m).map(l => JSON.stringify(l)).join('\n') + '\n')
    console.log(lines.length / 2, 'per model')
  } else if (mode === 'r') {
    const notes = outOf(`${P}/note/${model}/out.json`)
    const lines = []
    const left = []
    for (const { sample, entry } of samples(`${DEV}/${set}`)) {
      const got = notes[sample.id]
      if (!got?.isAnswered || !got.text?.trim()) { left.push(sample.id); continue }
      const { line, scope } = rLine(model, sample, entry, got.text)
      const q = /## 학습자의 질문\n([\s\S]*?)\n\n/.exec(line.prompt)?.[1] ?? ''
      if (scope.callees.length && q.endsWith('…')) throw new Error(`${sample.id}: r question cut at 1000`)
      lines.push(line)
    }
    writeOnce(`${P}/r/lines-${model}.jsonl`, lines.map(l => JSON.stringify(l)).join('\n') + '\n')
    console.log(model, lines.length, 'not called:', left.join(' '))
  } else if (mode === 'stored') {
    const notes = outOf(`${P}/note/${model}/out.json`)
    const rs = outOf(`${P}/r/${model}/out.json`)
    const out = {}
    for (const { sample, entry } of samples(`${DEV}/${set}`)) {
      const n = notes[sample.id]
      const r = rs[sample.id]
      if (!n?.isAnswered || !r) continue
      const got = readR(sample, entry, n.text, r.isAnswered ? r.text : '')
      const call = got.think?.call
      const name = call ? /^([A-Za-z_$][\w$]*)\(/.exec(call)[1] : undefined
      const callee = got.scope.callees.find(c => c.name === name)
      const calc = call ? N.calcCall(got.scope.mods.get(callee.file), call) : undefined
      out[sample.id] = { group: sample.group, lang: sample.lang, line: got.think?.question, call, calleeFile: callee?.file, calc: calc ? (calc.kind === 'value' ? `RETURN ${calc.show}` : calc.kind === 'error' ? `ERROR ${calc.name}` : 'UNKNOWN') : undefined, callees: got.scope.callees, stored: got.stored, noteText: got.shown.text, changes: got.shown.changes.map(c => ({ file: c.file, kind: c.kind, diff: c.diff })), raw: r.isAnswered ? r.text : '', rOut: r.usage?.output_tokens, rAnswered: !!r.isAnswered, rReason: r.reason }
    }
    writeOnce(`/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G5/final/replay/${set}-stored-${model}.json`, JSON.stringify(out, null, 1) + '\n')
    for (const [id, o] of Object.entries(out)) console.log(id, o.group, o.rOut, o.callees.length ? 'C' : '-', o.line ? `OPEN ${o.call} -> ${o.calc}` : 'none')
    console.log(model, Object.values(out).filter(o => o.line).length, 'lines')
  }
}
