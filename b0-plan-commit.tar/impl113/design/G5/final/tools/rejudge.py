"""G5e pilot (나) judge prompt for one label and round (records only): the committed 1.11.0 stance's [같음] and the
(나) clauses, the 1.12.0 S3-S6 and the 1.13.0 design's S16-S24; two fresh blind judges per label per round.
usage: judge_n.py <set> <label> <round>"""
import json, sys
D = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G5/pilot"
B7 = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl111/b7"
st, label, rnd = sys.argv[1:4]
rows = [r for r in json.load(open(f"/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G5/final/replay/read-{label}-{rnd}.json")) if r["changed"]]
qs = {q["q"]: q for q in json.load(open(f"{D}/{st}/questions-{label}.json"))["questions"]}
pair = json.load(open(f"{D}/judge/pair-{st}.json"))
model = [m for m, l in pair.items() if l == label][0]
stored = json.load(open(f"{D}/{st}/r/stored-{model}.json"))
stance = open(f"{B7}/judge/stance-G5.md").read()
same = stance[stance.index("[같음]"):stance.index("[(가)]")]
nab = stance[stance.index("- 짐작 30:"):stance.index("- 갈래가 틀린 글")]
ADD = """[1.12.0 · 1.13.0 추가 (이 판정에 함께 씀)]
- S3/S6: 짐작 글의 답에 판정 머리(맞혔습니다 · 아쉽지만 틀렸습니다)가 없으면 짐작 (a) 놓침입니다. 질문 글의 답에 판정 머리가 붙어 답 대신 판정이 나오면 질문 (a) 놓침입니다.
- S4: 짐작이 '오류로 끝난다'고 하면, 러너가 오류로 끝날 때 오류 이름을 대지 않았으면 맞습니다. 다른 이름을 대면 틀립니다.
- S5: 머리와 바른 결과만 있어도 (e) · (f)를 만족합니다. 보인 판정이 보인 바른 결과와 어긋나면 (f) 놓침입니다.
- S16: 도구가 쓴 까닭 문장도 (e)의 세 문장에 듭니다. '- `식`의 값: `v`' 줄은 사실로 읽고, 그 값이 코드와 어긋나면 질문 (a) 놓침입니다.
- S17: 판정 머리 없이 보인 짐작은 (a) 놓침이고 (b) · (f)는 읽지 않습니다.
- S18: py의 목록과 튜플은 항목이 같아도 다름입니다. 7과 "7"은 다름입니다. py의 정수와 실수는 값이 같아도 다름입니다(600과 600.0, 4.0과 4). js는 수가 한 가지라 4와 4.0이 같음입니다. 소수 끝의 0(97.5와 97.50)은 표기라 같음입니다.
- S18b: 결과가 문자열이면, 따옴표 없이 적은 수(12.6)는 그 문자열("12.6")과 다름입니다. 단위 말을 붙인 글(5개 · 14,000원 · 25%)은 그 글자 그대로가 문자열 내용과 같으면 같음입니다(숫자와 단위 사이 띄어쓰기는 보지 않음). 결과가 수이면 단위 말은 떼고 봅니다(14,000원 = 14000).
- S20: 도구가 계산해 보인 값도 보인 값입니다. 코드와 어긋나면 놓침입니다.
- S21: '`호출`를 실행하면 …' 문장의 호출은 학습자가 말한 입력이어야 합니다(말한 종류의 아무 값이면 됩니다). 학습자가 말하지 않은 인자는 생각해 보기 물음의 호출 그대로입니다(학습자가 빼라고 한 인자는 뺍니다). 아니면 그 질문은 (a) 놓침입니다. 그 결과가 코드와 어긋나도 (a) 놓침입니다.
- S22: '네.' · '아니요.' 머리는 판정 머리가 아니지만, 그 호출에 대한 학습자의 주장에 맞아야 합니다.
- S23: 물음표 짐작에 다른 호출로 답하면 놓침입니다.
- S24: 도구가 지운 문장은 없는 것으로 봅니다.
- 질문의 답이 값을 쓰지 않고 개념만 말해도, 물은 것에 맞게 답했으면 (a)를 만족합니다. 답을 미루거나 '알 수 없다'고 하면서 코드로 정해지는 것을 답하지 않으면 (a) 놓침입니다."""
items = []
for r in rows:
    q = qs[r["q"]]
    items.append(f"### {r['id']} (종류 {r['kind']}{', 기대 판정 ' + r['expect'] if r['expect'] else ''})\n\n- 물음: {r['line']}\n- 러너 결과: {r['result']}\n- 학습자의 글: {r['text']}\n- 보인 글:\n\n{r['shown'] if r['shown'] else '(보인 글 없음)'}\n")
codes = []
for qn, q in qs.items():
    e = stored[q["id"]]
    diffs = "\n\n".join(f"{c['file']}\n```diff\n{c['diff']}\n```" for c in e["changes"])
    codes.append(f"### {qn}의 바뀐 코드와 따라가기\n\n{diffs}\n\n따라가기 글:\n\n{e['stored']}\n")
prompt = f"""# (나) 판정 (꼬리표 {label}, 한 회, 다시 읽은 항목만)

당신은 한 꼬리표의 (나) 한 회 보고서를 매기는 채점자입니다. 아래 '입장'의 글자만 따르고, 보고서 밖의 것을 짐작하지 않습니다. 코드를 돌리지 않습니다. 바른 결과는 보고서에 적힌 러너 결과입니다(반환값은 그 값, 오류로 끝남은 그 오류). 질문의 답이 코드에 맞는지는 아래 '물음별 코드'로 확인합니다.

## 입장

{same}
{nab}
{ADD}

## 매기는 칸

항목마다 종류에 따라 아래 칸을 "ok" · "miss" · "undecided" 가운데 하나로 매기세요. 입장으로 정해지지 않는 칸은 "undecided"입니다(놓침으로 셉니다).
- 짐작(guessRight · guessWrong · guessFree): 짐작 30의 a · b · c · d · e · f · g.
- 모르겠어요(blank): result.
- 질문(question · questionNoMark): 질문 20의 a · b · c.
- 물음표 짐작(questionGuess): 판정 머리가 있으면 짐작 30의 a · b · f · g와 질문의 c(칸 이름 ga · gb · gf · gg · c), 없으면 질문 (d)의 질문 갈래 기준(칸 이름 d)과 c.
- 보인 글이 없는 항목은 칸 없이 "noAnswer": true.
- why: miss · undecided인 칸마다 근거 조항과 한 줄 까닭.

```json 울타리 안에 이 꼴의 JSON 하나만 적으세요. 다른 말은 쓰지 않습니다.

{{"items": [{{"id": "Q1-g1", "checks": {{"a": "ok", "b": "ok", "c": "ok", "d": "ok", "e": "ok", "f": "ok", "g": "ok"}}, "why": {{}}}}]}}

## 물음별 코드

""" + "\n".join(codes) + "\n## 보고서\n\n" + "\n".join(items)
open(f"/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G5/final/judge/r-{st}-{label}-{rnd}.md", "w").write(prompt)
print(len(items), len(prompt))
