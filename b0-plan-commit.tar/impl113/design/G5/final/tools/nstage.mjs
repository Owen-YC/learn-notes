// G5e pilot (나): per text, what askNote does under the open line (records only).
//   plan <set> <model> <label>              -> <set>/n/plan-<label>.json (code replies, check lines) + lines-<model>.jsonl
//   read <set> <model> <label> <round>      -> <set>/n/read-<label>-<round>.json (every text as shown, code and check)
import { N, samples, readJson } from './lib.mjs'
import { keptNote, outOf, writeOnce, R_AT, ASKED_AT, LEVEL, NUMS, DEV } from './build.mjs'
import { shownOf } from './lib.mjs'
const [mode, set, model, label, round] = process.argv.slice(2)
const D = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G5/pilot'
const P = `${D}/${set}`
const qs = Object.fromEntries(readJson(`${P}/questions-${label}.json`).questions.map(q => [q.q, q]))
const texts = readJson(`${P}/texts-${label}.json`).texts
const stored = readJson(`${P}/r/stored-${model}.json`)
const notes = outOf(`${P}/note/${model}/out.json`)
const byId = Object.fromEntries(samples(`${DEV}/${set}`).map(one => [one.sample.id, one]))
const idOf = t => `${t.q}-${t.k}`
function planOf(t) {
  const id = qs[t.q].id
  const { sample, entry } = byId[id]
  const note = { ...keptNote(sample, entry, notes[id].text), asks: [{ question: N.TRACE_LABEL, answer: stored[id].stored, at: R_AT }] }
  const shown = shownOf(note)
  const think = N.openThink(shown.asks, ASKED_AT, true, true)
  if (!think) throw new Error(`${id}: line not open`)
  const masked = N.redactText(t.text).text
  const plan = N.thinkCalcPlan(shown, think, masked, LEVEL, N.thinkVariantOf(model))
  const seen = [shown.text, think.trace, masked, ...shown.changes.map(c => c.diff)].join('\n')
  return { plan, masked, seen, shown, think }
}
if (mode === 'plan') {
  const out = []
  const lines = []
  for (const t of texts) {
    const { plan } = planOf(t)
    if (plan.kind === 'code') out.push({ id: idOf(t), path: 'code', shown: N.cut(plan.text, 4000) })
    else if (plan.kind === 'check') {
      out.push({ id: idOf(t), path: 'check' })
      lines.push({ id: idOf(t), model, system: plan.system, prompt: N.redactText(plan.prompt).text, maxTokens: NUMS.THINK_CHECK_TOKENS, timeoutMs: NUMS.MODEL_TIMEOUT_MS })
    } else {
      out.push({ id: idOf(t), path: 'fallback' })
      throw new Error(`${idOf(t)}: fallback`)
    }
  }
  writeOnce(`${P}/n/plan-${label}.json`, JSON.stringify(out, null, 1) + '\n')
  writeOnce(`${P}/n/lines-${model}.jsonl`, lines.map(l => JSON.stringify(l)).join('\n') + '\n')
  console.log(label, 'texts', texts.length, 'code', out.filter(o => o.path === 'code').length, 'check', lines.length)
} else if (mode === 'read') {
  const res = outOf(`${P}/n/${model}-${round}/out.json`)
  const rows = texts.map(t => {
    const { plan, masked, seen } = planOf(t)
    const r = res[idOf(t)]
    let shown = ''
    if (plan.kind === 'code') shown = N.cut(plan.text, 4000)
    else if (r?.isAnswered) shown = N.cut(N.thinkCalcReply(r.text, plan.facts, masked, seen), 4000)
    return { id: idOf(t), q: t.q, k: t.k, kind: t.kind, expect: t.expect, claim: t.claim, text: t.text, line: qs[t.q].line, result: qs[t.q].result, path: plan.kind, out: r?.usage?.output_tokens, answered: plan.kind === 'code' ? true : !!r?.isAnswered, reason: r?.reason, raw: r?.text, shown }
  })
  writeOnce(`${P}/n/read-${label}-${round}${process.env.RR ? "-rr" : ""}.json`, JSON.stringify(rows, null, 1) + '\n')
  const g = rows.filter(r => r.kind.startsWith('guess'))
  const head = s => (/^\*\*맞혔습니다\.\*\*/.test(s) ? '맞음' : /^\*\*아쉽지만 틀렸습니다\.\*\*/.test(s) ? '틀림' : 'none')
  console.log(label, round, 'guess head=expect', g.filter(r => head(r.shown) === r.expect).length, '/', g.length, 'max out', Math.max(0, ...rows.map(r => r.out ?? 0)), 'unanswered', rows.filter(r => !r.answered).map(r => r.id + ':' + r.reason).join(' '))
}
