import { N, readJson } from './lib.mjs'
const [set, model, id] = process.argv.slice(2)
const st = readJson(`${process.env.P}/${set}/r/stored-${model}.json`)[id]
const scope = N.thinkCalcScope(st.changes)
const c = scope.callees[0]
const mod = scope.mods.get(c.file)
const ex = /예시 호출:\s*`([^`]+)`/.exec(st.raw)?.[1]
console.log('example', ex, 'parse', !!N.parseThinkCall(ex, c.isPy))
const call = N.parseThinkCall(ex, c.isPy)
if (call) for (const t of N.pickTexts(call, c)) { const r = N.calcCall(mod, t); console.log(t.length, t, '->', r.kind === 'value' ? r.show : r.kind === 'error' ? r.name : r.why) }
