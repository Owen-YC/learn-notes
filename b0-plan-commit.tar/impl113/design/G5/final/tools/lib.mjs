// G5e pilot helpers (records only, B-12): notes as the plugin keeps them, from the proto tree's notes.ts.
import { readFileSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
export const D = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G5'
export const B7 = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl111/b7'
export const N = await import(pathToFileURL(`${D}/final/tree/hooks/notes.ts`).href)
const TC = await import(pathToFileURL(`${B7}/tools/think-code.mjs`).href)
export const noteOf = (entry, sample) => TC.noteOf(N, entry, sample)
export const shownOf = note => TC.shownOf(N, note)
export const readJson = p => JSON.parse(readFileSync(p, 'utf8'))
/** A dev set's samples: its changes.json and hunks.json; `group` as the writer was asked (in / out). */
export function samples(dir) {
  const changes = readJson(`${dir}/changes.json`)
  const hunks = Object.fromEntries(readJson(`${dir}/hunks.json`).map(one => [one.id, one]))
  return changes.map(sample => ({ sample, entry: hunks[sample.id] }))
}
