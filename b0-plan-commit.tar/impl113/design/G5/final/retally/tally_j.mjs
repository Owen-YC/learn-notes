// G5e pilot (나) tally for one label and round (records only): mechanical clauses + two blind judges (a split is a miss).
//   node tally_n.mjs <set> <label> <round> <judge1 result.txt> <judge2 result.txt>
import { readFileSync, writeFileSync } from 'node:fs'
import { N } from '../../pilot/tools/lib.mjs'
const [set, label, round, j1, j2] = process.argv.slice(2)
const D = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G5/pilot'
const rows = JSON.parse(readFileSync(`${D}/${set}/n/read-${label}-${round}.json`, 'utf8'))
const qs = Object.fromEntries(JSON.parse(readFileSync(`${D}/${set}/questions-${label}.json`, 'utf8')).questions.map(q => [q.q, q]))
const pair = JSON.parse(readFileSync(`${D}/judge/pair-${set}.json`, 'utf8'))
const model = Object.keys(pair).find(m => pair[m] === label)
const stored = JSON.parse(readFileSync(`${D}/${set}/r/stored-${model}.json`, 'utf8'))
const judge = f => Object.fromEntries(JSON.parse(/\{[\s\S]*\}/.exec(readFileSync(f, 'utf8'))[0]).items.map(v => [v.id, v]))
const J = [judge(j1), judge(j2)]
const langOf = q => (stored[qs[q].id].lang.split('+')[0] === 'py' ? 'py' : 'js')
const valueOf = (text, lang) => {
  const t = String(text).trim().replace(/^`|`$/g, '')
  const lit = N.calcLiteral(t, lang) ?? N.calcLiteral(t, lang === 'py' ? 'js' : 'py')
  if (lit) return lit
  const num = /^-?[\d,]+(?:\.\d+)?/.exec(t)
  if (num && /^-?[\d,]+(?:\.\d+)?\s*[가-힣%]{0,4}$/.test(t)) return { value: Number(num[0].replace(/,/g, '')) }
  if (t === '참' || t === 'true' || t === 'True') return { value: true }
  if (t === '거짓' || t === 'false' || t === 'False') return { value: false }
  return undefined
}
/** Expected verdict by the stance's [같음] (the label check): the writer's claim against the runner's result. */
function expected(r) {
  const out = qs[r.q].out
  const lang = langOf(r.q)
  const claim = r.claim === null || r.claim === undefined ? '' : String(r.claim)
  if (out.startsWith('ERROR')) {
    const named = /([A-Z]\w*(?:Error|Exception))/.exec(claim)?.[1]
    if (/오류|에러|예외|Error|멈|터/.test(claim)) return named && named !== out.slice(6) ? '틀림' : '맞음'
    return '틀림'
  }
  if (/^(?:오류|에러|예외)/.test(claim)) return '틀림'
  const v = valueOf(out.slice(7), lang)
  const c = valueOf(claim, lang)
  if (v && c) return N.calcEqual(c.value, v.value) ? '맞음' : '틀림'
  return r.expect ?? '?'
}
const head = s => (/^\*\*맞혔습니다\.\*\*/.test(s) ? '맞음' : /^\*\*아쉽지만 틀렸습니다\.\*\*/.test(s) ? '틀림' : 'none')
const rightShown = s => /바른 결과: `([^`]+)`/.exec(s)?.[1]
const rightOk = (r, s) => {
  const out = qs[r.q].out
  const got = rightShown(s)
  if (got === undefined) return false
  if (out.startsWith('ERROR')) return got === out.slice(6)
  const lang = langOf(r.q)
  const a = valueOf(got, lang)
  const b = valueOf(out.slice(7), lang)
  return !!a && !!b && N.calcEqual(a.value, b.value) && (typeof a.value === typeof b.value || typeof a.value === 'bigint' || typeof b.value === 'bigint')
}
const sentences = s => {
  const body = s.replace(/^\*\*[^*]+\*\*\s*/, '').split('\n').filter(l => !/^바른 결과:/.test(l) && l.trim() !== '').join(' ')
  let n = 0, code = false
  for (let i = 0; i < body.length; i++) {
    const c = body[i]
    if (c === '`') code = !code
    else if (!code && '.!?。'.includes(c) && (i + 1 === body.length || /\s/.test(body[i + 1]))) n++
  }
  return body.trim() === '' ? 0 : Math.max(n, 1)
}
const both = (id, key) => J.every(j => j[id]?.checks?.[key] === 'ok')
const result = []
let guesses = 0, gOk = 0, qN = 0, qOk = 0, bN = 0, bOk = 0, cap = 0, maxOut = 0
for (const r of rows) {
  const s = r.shown ?? ''
  maxOut = Math.max(maxOut, r.out ?? 0)
  if ((r.out ?? 0) >= 900 + 2048 || (!r.answered && r.path !== 'code')) cap++
  const miss = []
  if (r.kind.startsWith('guess')) {
    guesses++
    const exp = expected(r)
    if (head(s) !== exp) miss.push(`a(head ${head(s)} vs ${exp})`)
    if (head(s) === '틀림' && !rightOk(r, s)) miss.push('b(right)')
    if (/생각해\s*보기/.test(s)) miss.push('d')
    if (sentences(s) > 3) miss.push('e')
    if (/^(?:종류|따라가기|근거|짐작값|다른 호출|식|판정)\s*:/m.test(s)) miss.push('g')
    for (const k of ['a', 'b', 'c', 'f']) if (!both(r.id, k)) miss.push(`${k}(judges)`)
    if (miss.length === 0) gOk++
  } else if (r.kind === 'blank') {
    bN++
    if (!rightOk(r, s)) miss.push('result')
    if (miss.length === 0) bOk++
  } else {
    qN++
    if (r.kind === 'questionGuess' && head(s) !== 'none') {
      const exp = expected(r)
      if (head(s) !== exp) miss.push(`ga(head ${head(s)} vs ${exp})`)
      if (head(s) === '틀림' && !rightOk(r, s)) miss.push('gb')
      for (const k of ['ga', 'gb', 'gf', 'gg', 'c']) if (!both(r.id, k)) miss.push(`${k}(judges)`)
    } else {
      const keys = r.kind === 'questionGuess' ? ['d', 'c'] : ['a', 'b', 'c']
      for (const k of keys) if (!both(r.id, k)) miss.push(`${k}(judges ${J.map(j => j[r.id]?.checks?.[k] ?? '-').join('/')})`)
      if (/생각해\s*보기/.test(s)) miss.push('c(mech)')
    }
    if (miss.length === 0) qOk++
  }
  result.push({ id: r.id, kind: r.kind, path: r.path, miss, why: J.map(j => j[r.id]?.why) })
}
const summary = { label, round, guesses: `${gOk}/${guesses}`, questions: `${qOk}/${qN}`, blanks: `${bOk}/${bN}`, capHits: cap, maxCheckOut: maxOut }
writeFileSync(`./retally-${set}-${label}-${round}.json`, JSON.stringify({ summary, items: result }, null, 1))
console.log(JSON.stringify(summary))
for (const one of result) if (one.miss.length) console.log(' MISS', one.id, one.kind, one.path, one.miss.join(' '), '|', JSON.stringify(one.why).slice(0, 300))
