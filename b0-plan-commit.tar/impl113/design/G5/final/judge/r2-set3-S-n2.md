# (나) 판정 (꼬리표 S, 한 회, 다시 읽은 항목만)

당신은 한 꼬리표의 (나) 한 회 보고서를 매기는 채점자입니다. 아래 '입장'의 글자만 따르고, 보고서 밖의 것을 짐작하지 않습니다. 코드를 돌리지 않습니다. 바른 결과는 보고서에 적힌 러너 결과입니다(반환값은 그 값, 오류로 끝남은 그 오류). 질문의 답이 코드에 맞는지는 아래 '물음별 코드'로 확인합니다.

## 입장

[같음] (러너 결과와 글 · 답을 견줄 때)
- 공백(따옴표 밖) · 따옴표 종류 · 끝 마침표 · 조사 · 숫자 표기(97.5 = 97.50, 14000 = 14,000 = 14000원)는 맞춰 봅니다. '약 · 쯤'이 붙어도 값이 같으면 같음입니다.
- 문자열 안의 글자 · 대소문자 · 공백은 다르면 다름입니다(`"hi"` ≠ `"Hi"`, `"hi-"` ≠ `"hi"`).
- 한국어 말이 그 값을 하나로 가리키면 같음입니다(빈 배열 = [], 참 = true).
- 오류 결과는 '에러 · 오류로 끝남(멈춤 · 터짐)'이면 같음이고 메시지는 보지 않습니다. 다른 오류 이름을 대면 다름입니다.
- 출력 · 반환 없음: py의 None과 '아무것도 돌려주지 않음'은 같음입니다. js에서 `undefined`가 찍힌 것과 '아무것도 출력되지 않음'은 다름입니다(찍힌 것을 따름).
- 맞는 값과 어긋난 말이 한 줄 · 한 답에 함께 있으면 다름입니다(에러가 나고 … 0이 반환).


- 짐작 30: 아래를 모두 만족해야 맞음입니다.
  - (a) 읽은 판정이 기대 판정과 같음. 맞는 짐작은 맞음, 틀린 값 · 문제 짐작은 틀림이어야 합니다. 그 밖의 거의 · 질문 · 읽지 못함은 놓침입니다.
  - (b) 거의 · 틀림이면 보인 `바른 결과:`가 러너 결과와 같습니다. 맞음이면 피드백이 다른 결과를 말하지 않습니다.
  - (c) 오류 메시지 · 코드 · 실행 결과를 달라고 하지 않습니다.
  - (d) 새 생각해 보기가 없습니다.
  - (e) 머리와 `바른 결과:` 줄을 빼고 세 문장 이하입니다. 코드 안 마침표는 문장 끝이 아니고, 목록의 항목은 한 문장으로 셉니다. 라벨 없는 따라가기 문장이 피드백에 섞이면 이 셈에만 듭니다.
  - (f) 판정 낱말과 피드백이 어긋나지 않습니다(1.9.0 J1: 틀림인데 '맞지만', J2: 바른 결과 'A'인데 피드백 'B' → 놓침).
  - (g) 라벨 붙은 따라가기 덩어리가 보인 글에 없습니다.
- 모르겠어요 4: 읽힘(thinkReply가 글을 냄)과, 보인 글의 바른 결과(`바른 결과:` 줄 또는 피드백 안)가 러너 결과와 같고 어긋난 결과가 없음. 판정 머리(아쉽지만 틀렸습니다)가 붙은 것은 놓침이 아닙니다.
- 질문 20
  - (a) 물은 것에 맞게 답함(러너 결과 · 코드로 확인). 답 안에서 스스로 어긋나면 놓침입니다(1.9.0 J5-q2: '바뀌지 않습니다 · 맞습니다' 뒤에 0).
  - (b) 오류 메시지 · 코드를 달라고 하지 않음.
  - (c) 새 생각해 보기 없음.
  - (d) 물음표 짐작 5
    - 질문 갈래로 갔으면: 학습자의 말을 되풀이하거나 짐작이라고 이름 붙이는 문장 다음, 계산 · 까닭 · 코드보다 먼저 맞는지 틀렸는지를 말하고, 그 말이 러너 결과와 맞고, 바른 결과를 씁니다. '틀렸습니다'로 시작한 뒤 맞다고 하거나(1.9.0 J6-q2 h2-1), 계산 뒤에야 말하면 놓침입니다.
    - 판정 갈래로 갔으면: 짐작 30의 (a) · (b) · (f) · (g)로 셉니다.

[1.12.0 · 1.13.0 추가 (이 판정에 함께 씀)]
- S3/S6: 짐작 글의 답에 판정 머리(맞혔습니다 · 아쉽지만 틀렸습니다)가 없으면 짐작 (a) 놓침입니다. 질문 글의 답에 판정 머리가 붙어 답 대신 판정이 나오면 질문 (a) 놓침입니다.
- S4: 짐작이 '오류로 끝난다'고 하면, 러너가 오류로 끝날 때 오류 이름을 대지 않았으면 맞습니다. 다른 이름을 대면 틀립니다.
- S5: 머리와 바른 결과만 있어도 (e) · (f)를 만족합니다. 보인 판정이 보인 바른 결과와 어긋나면 (f) 놓침입니다.
- S16: 도구가 쓴 까닭 문장도 (e)의 세 문장에 듭니다. '- `식`의 값: `v`' 줄은 사실로 읽고, 그 값이 코드와 어긋나면 질문 (a) 놓침입니다.
- S17: 판정 머리 없이 보인 짐작은 (a) 놓침이고 (b) · (f)는 읽지 않습니다.
- S18: py의 목록과 튜플은 항목이 같아도 다름입니다. 7과 "7"은 다름입니다. py의 정수와 실수는 값이 같아도 다름입니다(600과 600.0, 4.0과 4). js는 수가 한 가지라 4와 4.0이 같음입니다. 소수 끝의 0(97.5와 97.50)은 표기라 같음입니다.
- S18b: 결과가 문자열이면, 따옴표 없이 적은 수(12.6)는 그 문자열("12.6")과 다름입니다. 단위 말을 붙인 글(5개 · 14,000원 · 25%)은 그 글자 그대로가 문자열 내용과 같으면 같음입니다(숫자와 단위 사이 띄어쓰기는 보지 않음). 결과가 수이면 단위 말은 떼고 봅니다(14,000원 = 14000).
- S20: 도구가 계산해 보인 값도 보인 값입니다. 코드와 어긋나면 놓침입니다.
- S21: '`호출`를 실행하면 …' 문장의 호출은 학습자가 말한 입력이어야 합니다(말한 종류의 아무 값이면 됩니다). 학습자가 말하지 않은 인자는 생각해 보기 물음의 호출 그대로입니다(학습자가 빼라고 한 인자는 뺍니다). 아니면 그 질문은 (a) 놓침입니다. 그 결과가 코드와 어긋나도 (a) 놓침입니다.
- S22: '네.' · '아니요.' 머리는 판정 머리가 아니지만, 그 호출에 대한 학습자의 주장에 맞아야 합니다.
- S23: 물음표 짐작에 다른 호출로 답하면 놓침입니다.
- S24: 도구가 지운 문장은 없는 것으로 봅니다.
- 질문의 답이 값을 쓰지 않고 개념만 말해도, 물은 것에 맞게 답했으면 (a)를 만족합니다. 답을 미루거나 '알 수 없다'고 하면서 코드로 정해지는 것을 답하지 않으면 (a) 놓침입니다.

## 매기는 칸

항목마다 종류에 따라 아래 칸을 "ok" · "miss" · "undecided" 가운데 하나로 매기세요. 입장으로 정해지지 않는 칸은 "undecided"입니다(놓침으로 셉니다).
- 짐작(guessRight · guessWrong · guessFree): 짐작 30의 a · b · c · d · e · f · g.
- 모르겠어요(blank): result.
- 질문(question · questionNoMark): 질문 20의 a · b · c.
- 물음표 짐작(questionGuess): 판정 머리가 있으면 짐작 30의 a · b · f · g와 질문의 c(칸 이름 ga · gb · gf · gg · c), 없으면 질문 (d)의 질문 갈래 기준(칸 이름 d)과 c.
- 보인 글이 없는 항목은 칸 없이 "noAnswer": true.
- why: miss · undecided인 칸마다 근거 조항과 한 줄 까닭.

```json 울타리 안에 이 꼴의 JSON 하나만 적으세요. 다른 말은 쓰지 않습니다.

{"items": [{"id": "Q1-g1", "checks": {"a": "ok", "b": "ok", "c": "ok", "d": "ok", "e": "ok", "f": "ok", "g": "ok"}, "why": {}}]}

## 물음별 코드

### Q1의 바뀐 코드와 따라가기

src/plantGrowth.js
```diff
@@ -1,6 +1,6 @@
 // 식물 키 계산기
 function heightAfterDays(startCm, cmPerDay, days) {
-  return startCm + cmPerDay * days;
+  return Math.round(startCm + cmPerDay * days);
 }
 
 console.log(heightAfterDays(12, 0.7, 9));
```

따라가기 글:

1. 호출 `heightAfterDays(12, 0.7, 9)`에서 매개변수가 `startCm = 12`, `cmPerDay = 0.7`, `days = 9`로 정해집니다.

2. 함수 안의 `cmPerDay * days`를 계산합니다. `0.7 * 9`는 컴퓨터 안에서 `6.299999999999999`가 됩니다. 소수를 2진수로 저장하면서 생기는 아주 작은 오차(부동소수점 오차)때문입니다.

3. `startCm + cmPerDay * days`를 계산합니다. `12 + 6.299999999999999`가 되어 `18.299999999999997`이 됩니다.

4. `Math.round(...)`가 이 값을 받습니다. 가장 가까운 정수는 18이므로 반올림 결과는 `18`입니다.

5. `return` 줄이 실행되어 함수가 `18`을 돌려줍니다.

6. `console.log(...)`가 돌려받은 `18`을 화면에 출력합니다.

결과: `18`

바뀌기 전 코드였다면 3단계에서 `return startCm + cmPerDay * days;`가 `18.299999999999997`을 그대로 돌려주므로, 결과가 달라지는 곳은 5단계의 반환값입니다.

**생각해 보기:** `heightAfterDays(13, 0.7, 9)`를 실행한 결과를 값 하나로 적어 보세요 (오류면 `오류`)

### Q2의 바뀐 코드와 따라가기

src/stationeryShop.js
```diff
@@ -0,0 +1,17 @@
+// 문구점 가격표 (원)
+const PRICE_LIST = {
+  pencil: 500,
+  eraser: 300,
+  notebook: 1200,
+  glue: 800,
+};
+
+function stationeryCost(itemName, count) {
+  const price = PRICE_LIST[itemName];
+  if (price === undefined) {
+    throw new Error(itemName + "은(는) 가격표에 없어요");
+  }
+  return price * count;
+}
+
+console.log(stationeryCost("notebook", 3));
```

따라가기 글:

1. `stationeryCost("notebook", 3)`이 호출됩니다. 매개변수 `itemName`에는 `"notebook"`, `count`에는 `3`이 들어갑니다.

2. `const price = PRICE_LIST[itemName];` 줄이 실행됩니다. `PRICE_LIST["notebook"]`을 찾아 `1200`을 꺼내 `price`에 담습니다. 이때 `price`는 `1200`입니다.

3. `if (price === undefined)` 조건을 검사합니다. `price`는 `1200`이라 `undefined`가 아니므로 거짓입니다.

4. `if` 블록 안의 `throw new Error(...)` 줄은 건너뜁니다. 가격표에 없는 물건일 때만 실행되는 줄입니다.

5. `return price * count;` 줄이 실행됩니다. `1200 * 3`을 계산하고 함수는 그 값을 돌려줍니다.

6. 함수 호출이 끝나고 `3600`이 나옵니다. 마지막 줄 `console.log(...)`가 이 값을 출력합니다.

결과: `3600`

바뀌기 전에는 이 함수 자체가 없었으므로 이 호출은 오류가 납니다. 값이 달라지는 지점은 5단계의 `return price * count;`입니다.

**생각해 보기:** `stationeryCost("notebook", 4)`를 실행한 결과를 값 하나로 적어 보세요 (오류면 `오류`)

### Q3의 바뀐 코드와 따라가기

src/fishTank.js
```diff
@@ -1,6 +1,7 @@
 // 어항에 물이 몇 리터 들어가는지 계산 (cm 단위)
 function tankLiters(tank) {
-  return (tank.width * tank.depth * tank.height) / 1000;
+  const { width, depth, height } = tank;
+  return (width * depth * height) / 1000;
 }
 
 const myTank = { width: 60, depth: 30, height: 36 };
```

따라가기 글:

예시 호출: `tankLiters(myTank)`

1. 호출되면 `tankLiters` 함수가 시작되고, 인자 `tank`에 `myTank` 객체 `{ width: 60, depth: 30, height: 36 }`가 들어갑니다.
2. `const { width, depth, height } = tank;` 줄이 실행됩니다. `tank` 객체에서 `width` 속성 값 `60`을 꺼내 같은 이름의 변수 `width`에 담습니다.
3. 같은 줄에서 `depth`에는 `30`, `height`에는 `36`이 담깁니다.
4. `return (width * depth * height) / 1000;` 줄이 실행됩니다. 계산식은 `(60 * 30 * 36) / 1000`입니다.
5. 먼저 `60 * 30`이 `1800`이 되고, 이어서 `1800 * 36`이 `64800`이 됩니다.
6. 마지막으로 `64800 / 1000`이 `64.8`이 되어 함수가 이 값을 돌려줍니다.

결과: `64.8`

바뀌기 전 코드에서는 4단계에서 `tank.width * tank.depth * tank.height`를 계산하면서 같은 값을 꺼내 쓰므로 결과는 같습니다. 달라지는 단계는 없습니다. 차이는 2단계에서 값을 미리 변수에 담아 두는지 여부뿐입니다.

**생각해 보기:** `tankLiters({ width: 61, depth: 30, height: 36 })`를 실행한 결과를 값 하나로 적어 보세요 (오류면 `오류`)

### Q4의 바뀐 코드와 따라가기

src/titleTrim.js
```diff
@@ -0,0 +1,10 @@
+// 긴 제목을 줄여서 보여 주기
+function shortenTitle(title, maxLength) {
+  const clean = title.trim();
+  if (clean.length <= maxLength) {
+    return clean;
+  }
+  return clean.slice(0, maxLength) + "...";
+}
+
+console.log(shortenTitle("  오늘의 일기: 비 오는 날 산책  ", 10));
```

따라가기 글:

1. 함수 `shortenTitle`에 인자가 들어갑니다. `title`은 `"  오늘의 일기: 비 오는 날 산책  "`(앞뒤에 공백 두 칸씩이 있는 문자열), `maxLength`는 `10`입니다.

2. `const clean = title.trim();` 줄이 실행됩니다. `trim`은 글자 양 끝의 빈칸을 지우는 기능입니다. `clean`은 `"오늘의 일기: 비 오는 날 산책"`이 됩니다.

3. `clean.length`(글자 수)를 셉니다. `"오늘의 일기: 비 오는 날 산책"`은 공백을 포함해 17글자이므로 `clean.length`는 `17`입니다.

4. `if (clean.length <= maxLength)` 조건을 확인합니다. `17 <= 10`은 거짓이므로 `if` 안의 `return clean;`은 건너뜁니다.

5. `clean.slice(0, maxLength)`가 실행됩니다. 0번 자리부터 10번 자리 앞까지 잘라 `"오늘의 일기: 비 "`(끝의 공백 한 칸 포함, 10글자)를 얻습니다.

6. `+ "..."`로 뒤에 점 세 개를 이어 붙입니다. 값은 `"오늘의 일기: 비 ..."`가 됩니다.

7. `return` 줄이 실행되어 함수가 끝나고, 이 값이 호출한 곳으로 돌아갑니다.

8. `console.log(...)`가 돌려받은 값을 화면에 출력합니다.

결과: `오늘의 일기: 비 ...`

바뀌기 전에는 함수 자체가 없었으므로, 이 호출이 가능하지 않았습니다. 새로 만든 함수이기 때문에 결과가 달라지는 단계는 없습니다.

**생각해 보기:** `shortenTitle("", 10)`를 실행한 결과를 값 하나로 적어 보세요 (오류면 `오류`)

### Q5의 바뀐 코드와 따라가기

src/fuelEfficiency.ts
```diff
@@ -1,6 +1,6 @@
 // 자동차 연비 (km/L)
 function kmPerLiter(distanceKm: number, fuelUsed: number): string {
-  return String(distanceKm / fuelUsed);
+  return (distanceKm / fuelUsed).toFixed(1);
 }
 
 console.log(kmPerLiter(342, 27) + " km/L");
```

따라가기 글:

1. 함수 `kmPerLiter(342, 27)`가 호출되어 `distanceKm`에 `342`, `fuelUsed`에 `27`이 들어갑니다.

2. `return` 줄이 실행됩니다. 먼저 괄호 안의 `distanceKm / fuelUsed`가 계산됩니다. `342 / 27`은 약 `12.666666666666666`입니다.

3. 이 숫자에 `.toFixed(1)`이 붙습니다. `toFixed(1)`은 소수점 첫째 자리까지 남기고 나머지를 반올림하는 기능입니다(고정 소수점, 자릿수 맞추기). 소수점 둘째 자리의 `6`을 보고 올려서 `12.7`이 됩니다.

4. `toFixed`는 결과를 문자열(글자)로 돌려줍니다. 따라서 함수가 돌려주는 값은 `"12.7"`입니다.

5. 함수 호출이 끝나고, `console.log` 줄에서 `kmPerLiter(342, 27)` 결과 `"12.7"`에 `" km/L"`가 붙습니다.

6. 문자열 합치기가 끝나 `"12.7 km/L"`가 화면에 출력됩니다.

결과: `"12.7 km/L"`

바뀌기 전 코드에서는 2단계 뒤 `String(...)`이 숫자를 그대로 글자로 바꾸어 `"12.666666666666666"`이 되므로, 3단계에서 결과가 달라집니다.

플러그인이 직접 계산해 보니 `kmPerLiter(342, 27)`의 결과는 `"12.7"`입니다.

**생각해 보기:** `kmPerLiter(341, 27)`를 실행한 결과를 값 하나로 적어 보세요 (오류면 `오류`)

### Q6의 바뀐 코드와 따라가기

src/booksRead.ts
```diff
@@ -0,0 +1,20 @@
+type Book = {
+  title: string;
+  pages: number;
+  finished: boolean;
+};
+
+function totalPagesRead(books: Book[]): number {
+  return books
+    .filter((book) => book.finished)
+    .map((book) => book.pages)
+    .reduce((sum, pages) => sum + pages, 0);
+}
+
+const myBooks: Book[] = [
+  { title: "어린 왕자", pages: 120, finished: true },
+  { title: "모모", pages: 380, finished: false },
+  { title: "갈매기의 꿈", pages: 96, finished: true },
+];
+
+console.log(totalPagesRead(myBooks));
```

따라가기 글:

예시 호출: `totalPagesRead(myBooks)`

1. `myBooks`는 세 권의 책이 담긴 목록입니다. 함수에 들어가면 `books`라는 이름으로 불립니다.
2. `.filter((book) => book.finished)` 줄이 실행됩니다. 세 권 중 `finished`가 `true`인 "어린 왕자"(120쪽)와 "갈매기의 꿈"(96쪽)만 남고, "모모"(`finished: false`)는 빠집니다. 중간 목록은 2권입니다.
3. `.map((book) => book.pages)` 줄이 실행됩니다. 책 객체들이 쪽수 숫자로 바뀌어 `[120, 96]`이 됩니다.
4. `.reduce((sum, pages) => sum + pages, 0)` 줄이 실행됩니다. `sum`은 0에서 시작합니다.
5. 첫 번째 숫자 120이 `pages`로 들어와 `sum`은 0 + 120 = 120이 됩니다.
6. 다음 숫자 96이 `pages`로 들어와 `sum`은 120 + 96 = 216이 됩니다.
7. 더할 숫자가 더 없으므로 reduce가 끝나고 216을 돌려줍니다.
8. `console.log`가 216을 화면에 출력합니다.

결과: `216`

바뀌기 전에는 함수가 없었으므로, 이 값을 구하는 단계 자체가 없었습니다. 함수가 새로 생겼으니 2단계의 `filter`가 바로 달라지는 지점입니다. 이 조건을 뒤집으면 합계가 달라집니다.

**생각해 보기:** `totalPagesRead([])`를 실행한 결과를 값 하나로 적어 보세요 (오류면 `오류`)

### Q7의 바뀐 코드와 따라가기

water_tank.py
```diff
@@ -1,5 +1,5 @@
 def fill_percent(current, capacity):
-    return current / capacity * 100
+    return round(current / capacity * 100, 1)
 
 
 print(fill_percent(37, 120))
```

따라가기 글:

1. `fill_percent(37, 120)`가 호출됩니다. 인자 `current=37`, `capacity=120`이 함수 안으로 들어옵니다.
2. 함수 첫 줄 `return round(current / capacity * 100, 1)`이 실행됩니다. 먼저 괄호 안의 `current / capacity`가 계산됩니다. `37 / 120`은 `0.308333…`입니다.
3. 이어서 `* 100`이 계산되어 `current / capacity * 100`은 `30.8333…`이 됩니다.
4. `round(30.8333…, 1)`이 실행됩니다. `round`는 두 번째 인자 `1`에 따라 소수 첫째 자리까지만 남기고 나머지를 반올림합니다. 소수 둘째 자리가 `3`이므로 내림되어 `30.8`이 됩니다.
5. `return`이 `30.8`을 호출한 곳으로 돌려줍니다. 함수 실행은 여기서 끝납니다.
6. 돌아온 값 `30.8`이 `print(...)`의 인자가 되고, 화면에 출력됩니다.

결과: `30.8`

바뀌기 전 코드는 4단계에서 `round` 없이 `30.8333…`을 그대로 돌려주므로, 결과가 여기서 달라집니다.

**생각해 보기:** `fill_percent(38, 120)`를 실행한 결과를 값 하나로 적어 보세요 (오류면 `오류`)

### Q8의 바뀐 코드와 따라가기

match_result.py
```diff
@@ -0,0 +1,7 @@
+def goal_margin(text):
+    # "우리팀:상대팀" 모양의 글자를 받아요
+    ours, theirs = text.split(":")
+    return int(ours) - int(theirs)
+
+
+print(goal_margin("3:1"))
```

따라가기 글:

1. `print(goal_margin("3:1"))` 줄에서 `goal_margin` 함수를 부릅니다. 함수의 `text` 자리에 `"3:1"` 글자가 들어갑니다. 이 호출에는 `이름=값` 형태의 인자가 없습니다.
2. `def goal_margin(text):` 아래 본문이 실행됩니다. `# ...` 주석 줄은 코드가 아니어서 무시됩니다.
3. `text.split(":")`가 `"3:1"`을 콜론(:) 기준으로 잘라 `["3", "1"]` 목록을 만듭니다.
4. `ours, theirs = ...` 줄에서 첫 조각이 `ours`에, 둘째 조각이 `theirs`에 들어갑니다. 두 값은 아직 글자이며, `ours = "3"`, `theirs = "1"`입니다.
5. `int(ours)`가 글자 `"3"`을 숫자 `3`으로 바꿉니다.
6. `int(theirs)`가 글자 `"1"`을 숫자 `1`로 바꿉니다.
7. `return int(ours) - int(theirs)`가 `3 - 1`을 계산해 `2`를 함수 밖으로 돌려주고, 함수는 여기서 끝납니다.
8. 돌아온 `2`가 `print`에 넘어가 화면에 출력됩니다.

결과: `2`

바뀌기 전에는 `goal_margin` 함수가 없어서 1단계의 호출이 `NameError`(이름을 찾을 수 없다는 오류)로 실패합니다.

**생각해 보기:** `goal_margin('0:1')`를 실행한 결과를 값 하나로 적어 보세요 (오류면 `오류`)

### Q9의 바뀐 코드와 따라가기

rice_cooker.py
```diff
@@ -1,6 +1,10 @@
-def water_ml(rice_cups, ml_per_cup=180):
-    return rice_cups * ml_per_cup
+def water_ml(rice_cups, ml_per_cup=180, brown=False):
+    ml = rice_cups * ml_per_cup
+    if brown:
+        ml = ml * 1.2  # 현미는 물을 20% 더
+    return round(ml)
 
 
 print(water_ml(2, ml_per_cup=200))
+print(water_ml(2, brown=True))
 
```

따라가기 글:

1. 호출 `water_ml(2, ml_per_cup=200)`이 실행됩니다. 함수 머리는 `def water_ml(rice_cups, ml_per_cup=180, brown=False):`이고, `rice_cups`에 `2`, `ml_per_cup`에 `200`이 들어갑니다. `brown`은 생략되었으므로 기본값 `False`가 들어갑니다.

2. 첫 줄 `ml = rice_cups * ml_per_cup`이 실행됩니다. `ml`은 `2 * 200`이므로 `400`이 됩니다.

3. `if brown:` 줄을 확인합니다. `brown`이 `False`이므로 이 조건문 안의 `ml = ml * 1.2` 줄은 건너뜁니다. `ml`은 여전히 `400`입니다.

4. `return round(ml)`이 실행됩니다. `round(400)`은 `400`이므로 함수는 `400`을 돌려줍니다.

5. 이 값이 `print`로 출력됩니다.

결과: `400`

바뀌기 전 코드에서는 `brown` 매개변수 자체가 없었고, 반환이 `rice_cups * ml_per_cup`이라 2단계에서 곱한 값을 그대로 돌려줍니다. 결과는 같은 `400`이지만, 현미 옵션을 켜는 호출은 전 코드에서 오류가 납니다.

**생각해 보기:** `water_ml(3, ml_per_cup=200)`를 실행한 결과를 값 하나로 적어 보세요 (오류면 `오류`)

### Q10의 바뀐 코드와 따라가기

tshirt_size.py
```diff
@@ -0,0 +1,13 @@
+TSHIRT_SIZES = {
+    "S": 90,
+    "M": 95,
+    "L": 100,
+    "XL": 105,
+}
+
+
+def chest_cm(size):
+    return TSHIRT_SIZES[size]
+
+
+print(chest_cm("M"))
```

따라가기 글:

1. 파일을 위에서부터 읽습니다. `TSHIRT_SIZES = {...}` 줄이 실행되어 `TSHIRT_SIZES`에 `{"S": 90, "M": 95, "L": 100, "XL": 105}`가 저장됩니다.
2. `def chest_cm(size):` 줄은 함수를 만들어 이름표를 붙이기만 하고, 아직 실행하지 않습니다.
3. 맨 아래 `print(chest_cm("M"))`에서 `chest_cm`을 부릅니다. 이때 함수의 `size` 자리에 `size="M"`이 들어갑니다.
4. `return TSHIRT_SIZES[size]` 줄이 실행됩니다. `size`는 `"M"`이므로 `TSHIRT_SIZES["M"]`을 찾습니다.
5. 딕셔너리에서 키 `"M"`을 찾습니다. 짝이 되는 값은 `95`입니다.
6. `return`이 `95`를 돌려줍니다. 함수를 부른 자리가 `95`로 바뀝니다.
7. `print(95)`가 실행되어 화면에 `95`가 출력됩니다.

결과: `chest_cm("M")` → `95`

전 코드가 없는 새 파일이므로 결과가 처음 생기는 단계는 4번입니다(`return`이 `TSHIRT_SIZES["M"]`의 값을 돌려주는 순간).

**생각해 보기:** `chest_cm('N')`를 실행한 결과를 값 하나로 적어 보세요 (오류면 `오류`)

## 보고서

### Q9-q1 (종류 question)

- 물음: `water_ml(3, ml_per_cup=200)`를 실행한 결과를 값 하나로 적어 보세요 (오류면 `오류`)
- 러너 결과: 600
- 학습자의 글: brown=True도 같이 넣으면 계산 순서가 어떻게 돼요?
- 보인 글:

`brown=True`를 주면 `ml = rice_cups * ml_per_cup`이 먼저 계산되어 물 양이 정해지고, 그다음 `if brown:` 조건이 참이므로 `ml = ml * 1.2`가 실행되어 20%가 늘어납니다. 마지막으로 `round(ml)`이 소수를 없애 정수로 돌려줍니다.
