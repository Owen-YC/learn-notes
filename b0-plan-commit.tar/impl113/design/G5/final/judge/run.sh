#!/bin/bash
# usage: run.sh <name> <prompt file>   fresh blind judge (opus, no tools), prompt on stdin only.
J=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G5/final/judge
N="$1"; F="$2"; O="$J/out/$N"; [ -e "$O" ] && { echo refuse; exit 1; }
mkdir -p "$O" "$J/work/$N"; cp "$F" "$O/prompt.txt"; cd "$J/work/$N" || exit 1
export DISABLE_AUTOUPDATER=1
timeout 2400 claude -p --model opus --tools '' --output-format json < "$O/prompt.txt" > "$O/out.json" 2> "$O/err.txt"
echo "exit=$?" > "$O/exit.txt"
python3 -c "import json,sys; print(json.load(open('$O/out.json')).get('result',''))" > "$O/result.txt" 2>/dev/null
