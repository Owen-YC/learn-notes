import { thinkTextOf } from '../tree/hooks/notes.ts'
const names = new Set(['song_seconds', 'text', 'mins', 'secs', 'int'])
for (const q of ['lambda?', 'split?', 'f-string?', 'return요?', 'None?', 'API요?', 'print?', 'range?', '리스트?', 'git?', 'self?', 'str?', 'ValueError?', '에러?', '오류요?', 'True?', '[]?', '0?', 'console.log?'])
  console.log(JSON.stringify(q).padEnd(14), JSON.stringify(thinkTextOf(q, 'py', names), (k, v) => typeof v === 'bigint' ? v + 'n' : v))
