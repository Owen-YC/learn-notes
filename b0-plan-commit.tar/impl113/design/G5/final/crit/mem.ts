import { calcModule, calcCall } from '../tree/hooks/notes.ts'
const py = calcModule([[
  'def grid(n):', '    rows = [list(range(n)) for _ in range(n)]', '    return len(rows)',
  'def big(n):', '    s = "ab" * n', '    t = [s for _ in range(n)]', '    return len(t)',
  'def srt(n):', '    xs = list(range(n))', '    for i in range(n):', '        xs = sorted(xs, reverse=True)', '    return xs[0]',
]], 'py')
const js = calcModule([[ 'function g(n) { const rows = []; for (let i = 0; i < n; i++) rows.push("x".padEnd(n, "y").split("")); return rows.length }',
 'function h(n) { let a = []; for (let i = 0; i < n; i++) a = a.concat(Array.from({length: n}, (_, j) => j)); return a.length }',
 'function srt(n) { let xs = []; for (let i = 0; i < n; i++) xs.push(i); for (let k = 0; k < 9000; k++) xs.sort((a, b) => b - a); return xs[0] }' ]], 'js')
for (const [m, c] of [[py,'grid(9999)'],[py,'big(4999)'],[py,'srt(9999)'],[js,'g(9999)'],[js,'h(9999)'],[js,'srt(9999)']] as any) {
  const t = Date.now(); let r: any; try { r = calcCall(m, c) } catch (x) { r = { kind: 'THROW', why: String(x).slice(0, 80) } }
  console.log(c, r.kind, r.why ?? r.show, (Date.now() - t) + 'ms', Math.round(process.memoryUsage().heapUsed / 1e6) + 'MB')
}
