import { calcModule, calcCall, thinkCalcScope } from '../tree/hooks/notes.ts'
const js = calcModule([[ 'function ok(s) {', '  return /^(\\w+\\s?)*$/.test(s)', '}' ]], 'js')
for (const n of [26, 29]) { const c = `ok("${'ab '.repeat(n/2|0)}${'a'.repeat(n)}!")`
  const t = Date.now(); const r = calcCall(js, c); console.log(n, c.length, r.kind, (Date.now() - t) + 'ms') }
