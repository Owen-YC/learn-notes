import { calcModule, calcCall } from '../tree/hooks/notes.ts'
const js = calcModule([[ 'function isName(s) {', '  return /^([A-Za-z]+ ?)+$/.test(s)', '}' ]], 'js')
for (const c of ['isName("Hong Gil Dong")', 'isName("Hong Gil Dong The Third!")', 'isName("Kim Minsu Park Jiyoung Lee!")']) {
  const t = Date.now(); const r: any = calcCall(js, c); console.log(c, r.kind, r.show, (Date.now() - t) + 'ms')
}
