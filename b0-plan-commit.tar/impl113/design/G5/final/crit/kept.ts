import { thinkCalcPlan, answerKept, thinkCalcReply, valueThinkLine } from '../tree/hooks/notes.ts'
const diff = '@@ -0,0 +1,7 @@\n' + ['def song_seconds(text):', '    mins, secs = text.split(":")', '    if int(secs) >= 60:', '        return -1', '    return int(mins) * 60 + int(secs)', '', 'print(song_seconds("3:25"))'].map(l => '+' + l).join('\n')
const change: any = { file: 'song.py', path: 'song.py', kind: 'create', added: 7, removed: 0, diff, isCut: false, tool: 'Write' }
const line = valueThinkLine('song_seconds("4:25")')
const trace = `1. \`song_seconds("3:25")\`에서 \`mins\`는 \`"3"\`입니다.\n\n결과: \`205\`\n\n${line}`
const note: any = { prompt: '', text: '노트', status: 'ready', changes: [change], moreFiles: 0 }
const think = { question: line.replace(/^\*\*생각해 보기:\*\* /, ''), trace, call: 'song_seconds("4:25")' }
const p: any = thinkCalcPlan(note, think, '왜 int를 써요?', 'beginner', 'trace')
console.log('plan', p.kind)
const seen = [note.text, trace, '왜 int를 써요?', diff].join('\n')
for (const a of ['이 호출의 결과는 7이 됩니다.', '이 호출의 결과는 60이 됩니다.', '결과는 205가 됩니다.', '결과는 265가 됩니다.', '`secs`가 60 이상이면 -1을 돌려줍니다.', '`int("4:25")`는 오류가 납니다.', '결과는 9999입니다.', '분을 초로 바꾸려면 60을 곱합니다. 그래서 4분은 240초입니다.'])
  console.log(JSON.stringify(a), '=>', JSON.stringify(answerKept(a, [], p.facts, seen)))
// unrelated question with dropped answer
console.log('UNRELATED =>', thinkCalcReply('종류: 질문\n짐작값: 없음\n다른 호출: 없음\n식: 없음\n식: 없음\n답: 깃 커밋은 `git commit -m "메시지"`로 합니다. 메시지는 150자 안으로 씁니다.\n판정: 없음', p.facts, 'git 커밋은 어떻게 해요?', seen))
// learner writes literal call; model gives 없음 for 다른 호출
console.log('LITCALL =>', thinkCalcReply('종류: 짐작\n짐작값: 오류\n다른 호출: 없음\n식: 없음\n식: 없음\n답: 없음\n판정: 없음', p.facts, 'song_seconds("4:99")를 넣으면 어떻게 돼요?', seen))
