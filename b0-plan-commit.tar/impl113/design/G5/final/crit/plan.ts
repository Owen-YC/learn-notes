import { thinkCalcPlan, valueThinkLine } from '../tree/hooks/notes.ts'
function mk(file: string, lines: string[], walked: string, asked: string, walkedResult: string) {
  const diff = `@@ -0,0 +1,${lines.length} @@\n` + lines.map(l => '+' + l).join('\n')
  const change: any = { file, path: file, kind: 'create', added: lines.length, removed: 0, diff, isCut: false, tool: 'Write' }
  const line = valueThinkLine(asked)
  const trace = `1. \`${walked}\`를 따라갑니다.\n\n결과: \`${walkedResult}\`\n\n${line}`
  const note: any = { prompt: '', text: '노트', status: 'ready', changes: [change], moreFiles: 0 }
  return { note, think: { question: line.replace(/^\*\*생각해 보기:\*\* /, ''), trace, call: asked } }
}
const cases: [string, string[], string, string, string, string[]][] = [
  ['a.py', ['def label(n):', '    return f"{n}개"', '', 'print(label(3))'], 'label(3)', 'label(5)', "'3개'", ['5개', '5개요', '5 개', '5', "'5개'", '6개', 'label?', '개?']],
  ['b.py', ['def pct(a, b):', '    return f"{round(a / b * 100)}%"', '', 'print(pct(1, 2))'], 'pct(1, 2)', 'pct(1, 4)', "'50%'", ['25%', '25', '25%요']],
  ['c.js', ['function won(n) {', '  return n.toLocaleString("en-US") + "원"', '}', 'console.log(won(9000))'], 'won(9000)', 'won(14000)', '"9,000원"', ['14,000원', '14,000원이요', '14000원']],
  ['d.py', ['def half(n):', '    return n / 2', '', 'print(half(6))'], 'half(6)', 'half(8)', '3.0', ['4', '4.0', '4요', '4.0이요']],
  ['e.py', ['def total(n):', '    return n * 300', '', 'print(total(2))'], 'total(2)', 'total(5)', '600', ['1500원', '1,500원', '1500', '1500.0']],
  ['f.js', ['function grade(s) {', '  return s >= 90 ? "A" : "B"', '}', 'console.log(grade(95))'], 'grade(95)', 'grade(80)', '"A"', ['B', 'B요', 'grade?', 's?', '"B"']],
]
for (const [file, lines, walked, asked, wr, texts] of cases) {
  const { note, think } = mk(file, lines, walked, asked, wr)
  for (const t of texts) {
    const p: any = thinkCalcPlan(note, think, t, 'beginner', 'trace')
    console.log(asked.padEnd(12), JSON.stringify(t).padEnd(14), p.kind === 'code' ? p.text.split('\n')[0].slice(0, 60) : p.kind)
  }
}
