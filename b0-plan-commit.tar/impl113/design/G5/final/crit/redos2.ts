import { calcModule, calcCall } from '../tree/hooks/notes.ts'
const js = calcModule([[
  'function ok(s) {',
  '  return /^(a+)+$/.test(s)',
  '}',
]], 'js')
for (const n of [20, 24, 27]) { const c = `ok("${'a'.repeat(n)}b")`
  const t = Date.now(); const r = calcCall(js, c); console.log(n, r.kind, (Date.now() - t) + 'ms') }
const py = calcModule([['def f(n):', '    return 10 ** n']], 'py')
for (const c of ['f(25)', 'f(10**6)']) { const t = Date.now(); const r = calcCall(py, c); console.log(c, r.kind, JSON.stringify(r).slice(0,60),(Date.now() - t) + 'ms') }
