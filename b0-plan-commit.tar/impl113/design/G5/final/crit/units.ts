import { calcModule, calcCall, calcEqual, thinkTextOf } from '../tree/hooks/notes.ts'
const py = calcModule([[
  'def label(n):', '    return f"{n}개"',
  'def pct(a, b):', '    return f"{round(a / b * 100)}%"',
  'def half(n):', '    return n / 2',
  'def mins(s):', '    return s // 60',
  'def tag(n):', '    return str(n)',
  'def loop(n):', '    t = 0', '    for i in range(n):', '        t += i', '    return t',
]], 'py')
const js = calcModule([[ 'function grade(s) { return s >= 90 ? "A" : "B" }', 'function w(n) { return n + "원" }', 'function yes(n) { return n > 3 }' ]], 'js')
const cases: [any, string, string, string][] = [
  [py,'py','label(5)','5개'], [py,'py','pct(1, 4)','25%'], [py,'py','half(8)','4'], [py,'py','half(8)','4.0'], [py,'py','mins(125)','2.0'],
  [py,'py','tag(7)','7'], [py,'py','tag(7)',"'7'"], [js,'js','grade(95)','A'], [js,'js','grade(95)','A요'], [js,'js','w(500)','500원'], [js,'js','yes(5)','참'], [js,'js','yes(5)','네'],
  [py,'py','loop(4)','6이요'], [py,'py','half(8)','4요'],
]
for (const [m, lang, call, said] of cases) {
  const r = calcCall(m, call) as any; const g = thinkTextOf(said, lang as any, new Set()) as any
  console.log(call.padEnd(12), '=>', String(r.show).padEnd(8), '| said', JSON.stringify(said).padEnd(8), '| read', g ? g.kind + ':' + String(g.value) : 'check', '| code verdict', g?.kind === 'value' ? (calcEqual(g.value, r.value) ? '맞음' : '틀림') : '-')
}
// timing worst case pick-like loop
const t = Date.now(); for (let i = 0; i < 24; i++) calcCall(py, 'loop(5000)'); console.log('24 x loop(5000):', Date.now() - t, 'ms')
