import subprocess, shutil, os, sys, re
S='/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G5/final'
src=open(f'{S}/tree/hooks/notes.ts',encoding='utf-8').read()
M={
 'm6 no regex shape check': ("      if (!isSafeRegex(source)) calcNo('regex shape')\n", ""),
 'm7 answerKept falls back to the line reason': ("  return body !== '' ? body : SLOT_UNREAD\n}", "  return body !== '' ? body : calcReasons(facts, facts.asked).join(' ') || SLOT_UNREAD\n}"),
 'm8 py int equals py float': ("  if (typeof a === 'bigint' || typeof b === 'bigint') return typeof a === typeof b && a === b", "  if (typeof a === 'bigint' || typeof b === 'bigint') return Number(a) === Number(b)"),
 'm9 no unit-word match for a string result': ("  if (typeof run.value === 'string' && typeof guess.value !== 'string' && guess.said !== undefined && !guess.isPlain)", "  if (false && typeof run.value === 'string' && typeof guess.value !== 'string' && guess.said !== undefined && !guess.isPlain)"),
 'm10 learner literal call not read': ("  if (mineCalls.length === 1) return mineCalls[0]\n", ""),
 'm11 no render size check': ("    if (calcSizeOver(value, CALC_SHOW_MAX)) calcNo('size')\n", ""),
 'm12 no claimed-result check': ("    return claimed.every(v => isIn(own, v, `${code}\\n${mine}`)) && !claimed.some(isAnswer)", "    return true"),
}
out=[]
for name,(a,b) in M.items():
    assert src.count(a)==1,(name,src.count(a))
    d=f'{S}/mut/w'
    if os.path.exists(d): shutil.rmtree(d)
    shutil.copytree(f'{S}/one',d)
    open(f'{d}/hooks/notes.ts','w',encoding='utf-8').write(src.replace(a,b))
    r=subprocess.run(['timeout','600','claude','plugin','test','.'],cwd=d,capture_output=True,text=True)
    fails=[l for l in (r.stdout+r.stderr).splitlines() if l.startswith('(fail)')]
    out.append(f'{name}: {len(fails)} failing' + ''.join('\n   '+re.sub(r' \[[\d.]+ms\]$','',f.split(' > ')[-1]) for f in fails))
    print(out[-1], flush=True)
open(f'{S}/mut/mut.log','w').write('\n'.join(out)+'\n')
