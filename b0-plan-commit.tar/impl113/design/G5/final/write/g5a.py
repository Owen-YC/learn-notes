import json
F='/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G5/final'
D={}
D['id']='G5'
D['name']="생각해 보기 (isThinkAsked) · 1.13.0 G5e '플러그인이 셈하고, 모델은 읽기만'"
D['what']={
 'summary':"ON for a model (MODEL_SWITCHES[m].isThinkAsked true after recheckRemap, level beginner, exactly 'haiku'/'sonnet'), a walk-through ('예시로 따라가기') of a short js/ts/py value-returning function ends with ONE line that code picks and writes; the learner types a value, '모르겠어요' or a question in the 질문 칸; code computes every result with an in-process evaluator (calc) and writes every verdict, head, right result and reason; the model only walks the example (r), reads a typed text code cannot settle into closed slots, and answers a concept question in at most two sentences with no values.",
 'learnerStringsWhenOn':{
  'line':"**생각해 보기:** `{call}`를 실행한 결과를 값 하나로 적어 보세요 (오류면 `오류`)",
  'walkCorrection':"플러그인이 직접 계산해 보니 `{walked}`의 결과는 `{w}`입니다.  (only when r's '결과:' line contradicts calc; `{w}` is a value, or `E` 오류)",
  'heads':["**맞혔습니다.**","**아쉽지만 틀렸습니다.**  (VERDICT_TEXT, unchanged)"],
  'rightResult':["바른 결과: `{v}`","바른 결과: `{v}` (돌려주는 것 없음)  (py None / js undefined)","바른 결과: `{E}` 오류로 멈춥니다."],
  'reasonTemplates':["이번 호출에서는 `{조건}` 조건이 {참|거짓}입니다.","반복은 {n}번 돕니다.","마지막 `{식}`에서 `{이름}` = `{값}`, …이므로 결과는 `{v}`입니다.","마지막에 `{식}`의 값을 돌려주므로 결과는 `{v}`입니다.","`{문장}`에서 `{E}` 오류가 나서 멈춥니다.","실행하다가 `{E}` 오류가 나서 멈춥니다."],
  'otherCall':["`{call}`를 실행하면 결과는 `{v}`입니다.","`{call}`를 실행하면 `{E}` 오류로 끝납니다.","**네.** / **아니요.**  (only before a yes/no claim with no 왜·어떻게·뭐·무엇·어디·어느·몇·무슨)"],
  'exprLine':"- `{식}`의 값: `{v}`   /   - `{식}`: `{E}` 오류",
  'unread':"답을 제대로 읽지 못했습니다. 질문을 한 번 더 적어 주세요.  (SLOT_UNREAD, unchanged)",
  'width':"Fits the 56-column pane: the line is about 52 display columns plus the call; a call up to THINK_CALL_MAX 80 characters wraps to at most three rows, as the 1.12.0 line did."},
 'example':["(py song_seconds, walked song_seconds(\"3:25\"); code picks song_seconds(\"4:25\"))","'265초요' → **맞혔습니다.** 마지막 `int(mins) * 60 + int(secs)`에서 `mins` = `'4'`, `secs` = `'25'`이므로 결과는 `265`입니다.","'245' → **아쉽지만 틀렸습니다.** (같은 까닭) + 바른 결과: `265`","'모르겠어요' → 바른 결과: `265` + 까닭","'song_seconds(\"4:99\")를 넣으면 어떻게 돼요?' → `song_seconds(\"4:99\")`를 실행하면 결과는 `-1`입니다. + 까닭  (0 trust in the model: the learner's own literal call)","'int()는 왜 써요?' → 값 없는 두 문장 + '- `int(\"4\") * 60`의 값: `240`'","(py label → f\"{n}개\", asked label(5)) '5개' → 맞혔습니다; '5' → 아쉽지만 틀렸습니다, 바른 결과: `'5개'`","(py half → n / 2, asked half(8)) '4' → 아쉽지만 틀렸습니다, 바른 결과: `4.0`; '4.0' → 맞혔습니다"],
 'unchanged':["Hints THINK_HINT_* (which keys need 영문), THINK_PLACEHOLDER '답이나 궁금한 점 적고 Enter', THINK_FOLLOW '이어서', helpLines '(생각해 보기가 붙으면 `i`로 답하기)' only when on, VERDICT_TEXT, SLOT_UNREAD.","OFF (any model string other than exactly haiku/sonnet, level not beginner, remapped/provider incl. CLAUDE_CODE_USE_GATEWAY/modelOverrides/unreadable, or the switch false): every byte of 1.9.0 — r = TRACE_170 + ASK_SYSTEM + 900, a question after a walk-through uses THINK_RULE, no check call, r stored as received, help without the note, recheckRemap not called.","Out of scope while ON (no function code can run): r = TRACE_170 to the byte, no line.","notePrompt, writeNote, askPrompt, quiz paths: untouched (isRuleWide 2100/2100 comparisons identical, G2 haiku d34g2 tests pass)."]}
D['why']={
 'missKinds':[
  "(가) runner losses and grammar erasure (1.11.0 haiku 4 + sonnet 3 no runner; sonnet 5 erased): removed in mechanism — code picks the call (thinkPick) and writes the line; the model writes no call.",
  "(가) keyword-argument call rejected (1.12.0 PG05): namedFits/canonOf accept named arguments by declared parameters; code-written calls keep the walked call's form.",
  "(가) rounding cut (1.12.0 PG07/PG08; 3 of 8 lost): back in scope because calc computes rounding exactly (py round/format ported from feas/pyfloat.mjs, 0 wrong in 377,187; js rounding is V8's own via the host allowlist).",
  "(가) tuple-unpacked / destructured locals read as unknown (PG06): unknownNamesWide reads statement-start py tuple targets and js destructuring assignment.",
  "(가) event/UI state (K02/K18/K23): a declared product cut (no single run without invented setup); counted as must-open-0 boundary items.",
  "(가)-5 r near its token line (haiku 2,491/2,500): r writes no line and no call; dev max r haiku 2,000, sonnet 1,290.",
  "(나) haiku factual errors in values (Q6 31.3 vs 31.2, dev 42 vs 21, 4 vs 12, parseInt('1e')): no model-computed value is shown anywhere; results, right results and 식 values come from calc.",
  "(나) self-contradiction, '…맞지만' under 틀림, verdict-vs-prose, labelled trace blocks, M-11 (b)/(f): verdict, head, right result and reason are code's; the model writes none of them.",
  "(나) '?' guess answered as a question / question given a verdict: one classifier with a fixed 종류 slot (THINK_KIND narrow for haiku, wide for sonnet, verified in 1.12.0) plus code rules (a question-shaped text gets a verdict only when it states the guessed value; a '?' guess stays on the line's call unless the learner names another input).",
  "(나) '바른 결과: 없음' and missing right results on blanks: blanks are answered by code with 0 calls.",
  "(나) deferral ('run it to see'): the check prompt forbids deferral; questions about another input are computed (S11 stays a miss).",
  "(나) partly visible functions: out of scope (whole function shown is a scope condition)."],
 'mechanisms':[
  "Code is the only source of results (calc: closed evaluator, unknown never makes a claim; differential gate against node/python3: 0 mismatches on 3,262 generated expressions and 339 old-corpus calls; after the final fixes, calc = runner on 131/131 dev lines).",
  "Closed-slot reading of the model with code verdicts; free model prose only for concept answers, held to 'no values' by answerKept and checked against calc where it claims a result.",
  "0-call code path for blanks, bare values and error words (24/24 blanks and most value guesses in dev).",
  "Every number shown is reproducible by the runner procedure, so the bar's (나)-1 (b), (나)-3 and S16/S20 reduce to calc = runner, which the differential gate and the bar tooling check."]}
D['whyNew']="New versus every earlier design: 1.9.0 F6 (model free sentence + lexical split), 1.10/1.11 G5 (closed grammar `이름`을 `값`으로, lexical router, free question branch, trace-first check) and 1.12.0 G5c (model chooses one literal call slot, code writes the sentence, one slot-format classifier check carrying the model's verdict/trace/basis). In G5e the division of labour changes: code evaluates the program (no earlier design could compute a result), code picks the asked input, code decides every verdict and writes every head, right result and reason; the model never computes, never writes the call, never writes a verdict that is used (its 판정 is read only for the closed word 기타). Blanks and bare values make no model call. Concept answers carry no values. Reused sub-mechanisms only inside this new division: thinkCallees fixpoint scope (widened), the code-written sentence idea (new imperative line), VERDICT_TEXT, SLOT_UNREAD, the frozen THINK_VARIANT table (now keying only the 종류 wording), recheckRemap and the r rebuild after it."
json.dump(D,open(F+'/write/part1.json','w'),ensure_ascii=False,indent=1)
print('ok')
