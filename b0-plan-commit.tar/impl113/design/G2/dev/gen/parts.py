"""1.13.0 G2 dev writers (records only, B-12). The 1.12.0 G2 measured writer prompts (impl112/b2/gen/writer-A.md,
writer-B.md, *-end.md) word for word, except: the record count, ids and languages per part (at most 10 records per
call, the G3 safety-classifier lesson), the mix minimums scaled to the part, and the avoid section (names only, from
impl113/NAMES-all.txt via avoid.py, plus the names an earlier part of the same set already used).
A writer sees no rule, prompt, stance, scope, design or model.
usage: parts.py make <setdir> <part> <out.md>  |  parts.py read <part dir>"""
import json, os, re, subprocess, sys
G = os.path.dirname(os.path.abspath(__file__))
B2 = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/gen'
PARTS = {
  'A1': dict(js=(1, 10), py=None, after=()),
  'A3': dict(js=None, py=(21, 30), after=()),
  'A2': dict(js=(11, 20), py=None, after=('A1',)),
  'A4': dict(js=(31, 35), py=(36, 40), after=('A1', 'A2', 'A3')),
  'T1': dict(js=(41, 50), py=None, after=('A1', 'A2', 'A3', 'A4')),
  'T2': dict(js=None, py=(51, 60), after=('A1', 'A2', 'A3', 'A4')),
  'B': dict(kind='B'),
}
MIX24 = {'a': 8, 'b': 4, 'c': 4, 'd': 4, 'e': 3, 'f': 2, 'g': 2, 'h': 2, 'i': 3, 'j': 3, 'k': 3}
def scaled(n, has_js):
    out = {}
    for k, v in MIX24.items():
        if k == 'e' and not has_js: continue
        out[k] = max(1, round(v * n / 24))
    return out
def avoid(setdir, after):
    av = subprocess.run(['python3', '-I', f'{G}/avoid.py'], capture_output=True, text=True, check=True).stdout.strip('\n')
    sib = []
    for a in after:
        p = f'{setdir}/parts/{a}/reply.json'
        if os.path.exists(p): sib += [r.get('name', '') for r in json.load(open(p)) if isinstance(r, dict)]
    if sib:
        av += '\n\nThese concept names are already used by other parts of this same set; do not use them or write about the same concepts:\n' + ' · '.join(sorted(set(sib)))
    return '\n' + av + '\n'
def make(setdir, part, out):
    if os.path.exists(out): sys.exit(f'refuse: {out} exists')
    pre = open(f'{setdir}/PREFIX').read().strip()
    p = PARTS[part]
    if p.get('kind') == 'B':
        body = open(f'{B2}/writer-B.md').read()
        for k in range(1, 8): body = body.replace(f'"gf{k}"', f'"{pre}f{k}"').replace(f'gf{k}', f'{pre}f{k}')
        end = open(f'{B2}/writer-B-end.md').read()
        open(out, 'w').write(body + avoid(setdir, ()) + end); return
    A = open(f'{B2}/writer-A.md').read()
    js, py = p['js'], p['py']
    n = (js[1] - js[0] + 1 if js else 0) + (py[1] - py[0] + 1 if py else 0)
    first = (js or py)[0]; last = (py or js)[1]
    ids = f'"{pre}m{first:02d}".."{pre}m{last:02d}"'
    if js and py: langs = f'{pre}m{js[0]:02d}–{pre}m{js[1]:02d} are JavaScript (".js"), {pre}m{py[0]:02d}–{pre}m{py[1]:02d} are Python (".py").'
    elif js: langs = 'All are JavaScript (".js").'
    else: langs = 'All are Python (".py").'
    old = 'Write 24 records, ids "gm01".."gm24". gm01–gm15 are JavaScript (".js"), gm16–gm24 are Python (".py").'
    assert old in A
    A = A.replace(old, f'Write {n} records, ids {ids}. {langs} This is one part of a larger set that is written in several parts.')
    mix = scaled(n, js is not None)
    A = A.replace('Mix across the 24 records:', f'Mix across the {n} records:')
    for k, v in MIX24.items():
        m = re.search(rf'^- \({k}\) at least {v} ', A, re.M)
        assert m, k
        if k not in mix: A = re.sub(rf'^- \({k}\) at least {v} .*\n', '', A, flags=re.M)
        else: A = A[:m.start()] + f'- ({k}) at least {mix[k]} ' + A[m.end():]
    end = open(f'{B2}/writer-A-end.md').read().replace('the 24 records', f'the {n} records')
    open(out, 'w').write(A + avoid(setdir, p['after']) + end)
def read(d):
    t = json.load(open(f'{d}/full.json')).get('result', '')
    open(f'{d}/result.txt', 'w').write(t)
    s = t.strip()
    m = re.search(r'```(?:json)?\s*\n(.*?)\n```', s, re.S)
    try:
        x = json.loads(m.group(1) if m else s[s.index('['): s.rindex(']') + 1])
        assert isinstance(x, list) and x
        json.dump(x, open(f'{d}/reply.json', 'w'), ensure_ascii=False, indent=1); return True
    except Exception as e:
        print('unreadable', e); return False
if __name__ == '__main__':
    if sys.argv[1] == 'make': make(*sys.argv[2:5])
    else: sys.exit(0 if read(sys.argv[2]) else 1)
