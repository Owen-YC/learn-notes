#!/bin/bash
# usage: run.sh <setdir> <part...>   blind dev writers (records only); parts given run 4 at a time; one re-call if unreadable.
SD="$1"; shift; G=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G2/dev/gen
EMPTY=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G2/dev/empty
export DISABLE_AUTOUPDATER=1
one() {
  local part=$1 d="$SD/parts/$1"
  for t in 1 2; do
    [ -f "$d/reply.json" ] && return 0
    mkdir -p "$d"; rm -f "$d/prompt.md"
    python3 -I $G/parts.py make "$SD" "$part" "$d/prompt.md" || return 1
    ( cd "$EMPTY" && claude --version > "$d/version.txt" 2>&1; date -u +%FT%TZ > "$d/started-$t"
      timeout 1500 claude -p --model opus --tools '' --output-format json < "$d/prompt.md" > "$d/full.json" 2> "$d/err.txt"; echo "exit=$?" > "$d/exit-$t"; date -u +%FT%TZ > "$d/ended-$t" )
    python3 -I $G/parts.py read "$d" && { echo "$part ok try $t"; return 0; }
    cp "$d/full.json" "$d/full-unreadable-$t.json" 2>/dev/null; echo "$part unreadable try $t"
  done
  return 1
}
for p in "$@"; do one $p & done; wait
