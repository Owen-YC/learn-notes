#!/bin/bash
# usage: stages.sh <setdir>   writers for one dev set in stages (records only): A1 A3 B, then A2, then A4.
SD="$1"; G=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G2/dev/gen
bash $G/run.sh "$SD" A1 A3 B > "$SD/stage1.log" 2>&1
bash $G/run.sh "$SD" A2 > "$SD/stage2.log" 2>&1
bash $G/run.sh "$SD" A4 >> "$SD/stage2.log" 2>&1
date -u +%FT%TZ > "$SD/WRITERS-DONE"
