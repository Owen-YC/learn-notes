"""Avoid section for the 1.13.0 G3 dev writers: names only. Concept names of earlier sample records (every
NAMES-all row whose source is a record file, impl113/NAMES-all.txt) plus the record-name fields of docs/qa/견본.md
picked by record-id pattern (pR09 '즉시 실행 함수'; names only, never prose). Model/alias/switch words left out."""
import re
NAMES = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/NAMES-all.txt'
BON = '/home/user/learn-notes/docs/qa/견본.md'
HANGUL = re.compile(r'[가-힣]')
WORDS = re.compile(r'(?i)haiku|sonnet|opus|fable|claude|anthropic|model|rung|isrule|isbase|isthink|worked|alias|gateway|bedrock|vertex|override|provider|모델|채점|견본|판정|프롬프트')
FILE = re.compile(r'^[\w./@-]+\.(js|mjs|cjs|ts|py|json|md)$')
def names():
    out = set()
    for l in open(NAMES, encoding='utf-8'):
        r = l.rstrip('\n').split('\t')
        if len(r) < 2 or r[1] == '견본' or not HANGUL.search(r[0]) or FILE.match(r[0]): continue
        n = r[0].split(': ')[0].strip()
        if 2 <= len(n) <= 30 and n[0] not in "'\"`": out.add(n)
    for m in re.finditer(r"\b[a-zA-Z]{1,3}\d{1,2}[a-z]?\s*[‘'\"]([^'’\"\n]{2,30})[’'\"]", open(BON, encoding='utf-8').read()):
        n = m.group(1).strip()
        if HANGUL.search(n) and not re.search(r'(니다|다\.|요\.)$', n): out.add(n)
    return sorted(x for x in out if not WORDS.search(x))
if __name__ == '__main__':
    xs = names()
    print('\nConcept names already used by earlier sample sets. Do not use any of these as a record\'s name, and do not write a record about any of these concepts:\n' + ' · '.join(xs) + '\n')
