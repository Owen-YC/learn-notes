// 1.13.0 G2 final (records only): every place (changeSites isAll) of every record, each with a wide value list
// (numbers: runValues' four plus 0..5, 10, half, n+5, n+10, 10n, the bound; strings: every other string token of the
// file; others: every listed alternative), run by the evaluator with printArgs; every accepted run is a program for the
// real runner. Also reports how many accepted runs isCertified would let be asked.
// usage: gen.mjs <notes.ts> <records.jsonl> <progs.jsonl> <stat.json>
import { readFileSync, writeFileSync } from 'node:fs'
const N = await import(process.argv[2])
const rows = readFileSync(process.argv[3], 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l))
const bound = t => Math.max(10, 5 * Math.abs(Number(t)))
const progs = []
const stat = { records: rows.length, origAccepted: 0, sites: 0, tried: 0, accepted: 0, certified: 0, refused: {} }
const CAP = 80
for (const r of rows) {
  const lang = r.file.endsWith('.py') ? 'py' : 'js'
  const o = N.newRun(r.code, lang, { printArgs: true })
  if (!('lines' in o)) { stat.refused[o.refuse] = (stat.refused[o.refuse] ?? 0) + 1; continue }
  stat.origAccepted++
  progs.push({ id: `${r.id}#O`, lang, code: r.code, want: o.lines })
  let sites = []
  try { sites = N.changeSites(r.code, r.file, r.blurb || '— `x`', true) } catch { sites = [] }
  stat.sites += sites.length
  const lines = r.code.split('\n')
  let k = 0
  for (const site of sites) {
    let vals = []
    if (site.kind === 'number') {
      if (!/^\d+$/.test(site.token)) continue
      const n = Number(site.token), b = bound(site.token)
      vals = [n + 1, n - 1, n + 2, 2 * n, 0, 1, 2, 3, 4, 5, 10, Math.floor(n / 2), n + 5, n + 10, 10 * n, b].filter(v => v !== n && v >= 0 && v <= b)
    } else if (site.kind === 'string') vals = sites.filter(s => s.kind === 'string' && s.token !== site.token && s.token[0] === site.token[0]).map(s => s.token)
    else vals = [...site.alts]
    for (const v of [...new Set(vals.map(String))]) {
      if (k >= CAP) break
      const cl = lines[site.line].slice(0, site.at) + v + lines[site.line].slice(site.end)
      const code = [...lines.slice(0, site.line), cl, ...lines.slice(site.line + 1)].join('\n')
      stat.tried++
      const res = N.newRun(code, lang, { printArgs: true })
      if (!('lines' in res)) continue
      stat.accepted++
      if (N.isCertified(res.lines, o.lines)) stat.certified++
      progs.push({ id: `${r.id}#${site.line}:${site.at}=${v}`, lang, code, want: res.lines })
      k++
    }
  }
}
writeFileSync(process.argv[4], progs.map(p => JSON.stringify(p)).join('\n') + '\n')
writeFileSync(process.argv[5], JSON.stringify(stat, null, 1))
console.log(JSON.stringify({ ...stat, progs: progs.length }))
