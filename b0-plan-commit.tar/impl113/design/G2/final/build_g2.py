"""Builds impl113/design/G2.json (1.13.0 G2 sonnet, G2-RUN r2 as the design). Reads the proof files it cites.
usage: python3 build_g2.py"""
import hashlib, json, os, re

S = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad'
G = f'{S}/impl113/design/G2'
OUT = f'{S}/impl113/design/G2.json'


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def read(p, default=''):
    try:
        return open(p, encoding='utf-8').read()
    except OSError:
        return default


DIFF = f'{G}/proto/G2-run-113-final.diff'
names = json.load(open(f'{G}/dev/names-113.json'))
mut = read(f'{G}/proofs/mut3/result.txt').strip()
def rw_summary(p):
    try:
        d = json.load(open(p))
        return f"{d['cases']} cases (haiku {d['perModel']['haiku']}, sonnet {d['perModel']['sonnet']}), differ {d['differ']}"
    except Exception:
        return '(pending)'


rw_tail = (f"with --extra impl112/b1/audit/d26x/extra.json: {rw_summary(f'{G}/proofs/rulewide-final639.log')} (proofs/rulewide-final639.log); "
           f"without the extra corpus: {rw_summary(f'{G}/proofs/rulewide-final.log')} (proofs/rulewide-final.log).")
wide_cmp = read(f'{G}/final/wide/cmp.txt').strip().splitlines()[-1:]
wide_stat = json.load(open(f'{G}/final/wide/stat.json'))
own = read(f'{G}/final/own.txt').strip()

CHANGED_LEAD = '전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.'
CHANGED_HINT = '바뀐 곳은 {k}번째 줄 `{줄}`입니다. 그 줄 때문에 달라지는 값부터 보세요.'
CHANGED_RUN_ASK = '비슷한 코드: 이 칸은 문제 글을 쓰지 않는다. 문제와 바꾼 코드와 답은 플러그인이 만든다. 그 개념 아래 "바꿀 수 있는 곳" 가운데 그 개념이 쓰이는 한 곳을 골라, 괄호 안에 적힌 대로 새 값을 정한다. 바꾼 뒤 찍히는 글자가 "지금 찍히는 글자"와 달라지고, 입문자가 코드를 읽고 그 글자를 알아낼 수 있는 값을 고른다. 오류로 멈추게 되는 값은 고르지 않는다. 이 번호에는 T·Q·H·A를 쓰지 않고 C만 쓴다. C 줄에는 고른 곳의 이름과 새 값만 쓴다(예: C2: 2b >=). 다 쓴 C는 다시 쓰거나 고쳐 쓰지 않는다.'
ALL_UNREAD = '퀴즈를 내지 못했습니다: 비슷한 코드 문제를 확인하지 못했습니다. 이 창에서 다시 해 보면 그 개념은 내 코드로 냅니다.'

# ───────────────────────────── stance (Korean, committed verbatim) ─────────────────────────────
STANCE = [
    "판정의 입장 (G2 sonnet, 1.13.0 G2-RUN 실행 길). 기준 · 결정 규칙 · 짜임 · 견본 쓰기 프롬프트와 함께, 견본을 쓰거나 부르기 전에 docs/qa/견본.md 새 절로 한 커밋에 넣습니다(UTC 시각, 가리키는 코드 커밋 해시). 매기는 쪽은 이 글의 조항만 따르고 판정마다 조항 번호를 적습니다. ⚙ 조항은 eval 도구(부르기 전에 sha256으로 얼림)가 세고, ✎ 조항만 매기는 하위 에이전트가 매깁니다. 1.12.0 G2 입장(5da364c)의 조항 0–15 번호와 뜻을 그대로 두고, 실행 길에서 달라지는 것은 그 조항 안에 '(1.13.0)'으로 적고 조항 16–20을 더했습니다. 바뀐 것은 모두 중립이거나 더 엄격합니다. 이 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 '다시 잴 때'에 적습니다(M-11).",
    "0 셈의 단위: 비슷한 코드로 고른 20자리(퀴즈 9개, 견본 짜임의 잴 자리 js 13 · py 7). 같은 퀴즈의 내 코드 · 왜 · 다시 도전 문항은 셈 밖이고 기록만 합니다. (1.13.0) 짜임에서 채우지 못한 잴 자리(조항 19)도 20자리에 듭니다.",
    "1 읽기 ⚙ (1.13.0): 플러그인처럼 fixEscapedTicks → 그 커밋의 parseQuiz로 읽어 저장될 문항(question · hint · answer · kind · rung)만 매깁니다. 실행 길의 자리(build 기록에서 그 고르기에 code.run이 있음)는 parseQuiz 안에서 changedRunItem이 읽습니다. 모델이 쓰는 것은 C 줄(고른 곳의 이름과 새 값)뿐이고, O · N은 묻지도 읽지도 않습니다. 저장된 답(answer)은 모델 글이 아니라 플러그인이 기기에서 바꾼 코드를 돌린 줄들입니다. C 줄, '지금 찍히는 글자', '바꿀 수 있는 곳' 목록과 날글은 저장되지 않으므로 판정 대상이 아닙니다(조항 18에서 자기 값인지 가릴 때만 도구가 isOwn으로 봄). 답에 N 줄이나 다른 줄이 더 있어도 읽지 않고 매기지 않습니다. 읽힌 문항은 그 번호 자리의 개념으로 플러그인이 짠 문항입니다.",
    "2 답이 없는 자리 ⚙ (1.13.0): 빈 답(empty-reply · API 거절), 시간 한도(90초)에 끊긴 답, 읽히지 않은 자리, 플러그인의 읽기(changedRunItem)가 문항을 내지 않은 자리 — missing(C 없음) · grammar(C 머리가 '번호+글자' 꼴이 아님) · other-slot(번호가 자리와 다름) · site(목록에 없는 글자) · long(문제 글이 1200자를 넘음) — 는 (가)에서 놓침, (나)에서는 셈 밖입니다(학습자에게 보이지 않음). 상한에 닿았어도 읽힌 문항은 읽힌 그대로 매깁니다. 다시 보내는 것은 글이 하나도 없고 출력 토큰이 0인 api-error(상태 429 · 5xx)뿐이며 같은 프롬프트로 두 번까지, 모두 기록합니다. 그래도 실패하면 그 퀴즈의 자리는 모두 놓침입니다. 빈 답 · 시간 끊김 · 상한 닿음 · 읽기가 거른 자리는 다시 보내지 않습니다. 빈 답은 기록으로만 탭으로 한 번 더 보내 stop_reason과 stop_details.category를 적습니다.",
    "3 돌리기 ⚙: 문제의 코드: question의 펜스 블록(플러그인이 넣은 하나)입니다. 언어는 펜스 이름(js · python)입니다. 빈 임시 폴더에서 `unshare -n timeout 5`로, 표준 입력을 비우고 돌립니다. js: `node 파일` 두 번. py: `env -i PATH=\"$PATH\" LANG=C.UTF-8 PYTHONHASHSEED=<n> python3 -s -P -B 파일`을 n = 1..5로 다섯 번. 결과는 표준 출력의 줄들입니다(마지막 줄이 줄바꿈 없이 끝나도 한 줄). 끝 코드가 0이 아니면 그 앞까지의 출력 뒤에 마지막 예외의 이름(메시지는 뺌) 한 줄을 더합니다. 표준 오류는 결과에 넣지 않습니다. 돌린 결과가 서로 하나라도 다르거나 5초를 넘으면 그 문항은 (가) 놓침이고 A는 틀림입니다. 학습자 결과: 견본을 얼리기 전 확인 때 학습자 파일 전체(= 바꾸기 전의 보인 코드)를 같은 규칙으로 돌려 얼린 줄들입니다. (1.13.0) 플러그인이 요청에 보인 '지금 찍히는 글자'(기기의 평가기가 낸 것)는 판정에 쓰지 않습니다. 학습자 결과와 문제 코드의 결과는 늘 이 조항으로 진짜 돌린 것입니다. 도구 판(node · python · Claude Code)을 적습니다.",
    "4 채우지 않음: 블록에 없는 정의 · import · 입력 · 파일 · 준비를 덧붙이지 않습니다. 나는 오류도 결과입니다. (이 설계의 문제 코드는 학습자 파일 전체라 채울 것이 생기지 않지만 규칙은 그대로 둡니다.) \"글로 말한 바꿈\"은 쓰이지 않습니다(바꿈은 플러그인이 코드에 넣음).",
    "5 물은 것 ⚙: 문제 글은 플러그인의 고정 글(CHANGED_LEAD)이고 \"이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름\"을 묻습니다. 그래서 물은 것은 언제나 결과 전체(오류로 멈추면 그 앞 출력과 오류 이름)입니다. 매기는 쪽이 Q만 보고 물은 것을 정하는 단계는 쓰이지 않습니다. question이 이 글로 시작하지 않으면 10에서 놓침이고, (나)는 결과 전체와 견줍니다.",
    "6 표기 맞춤 ⚙: 1.10.0 조항 6을 글자 그대로 씁니다(A와 결과, 결과끼리 견줄 때 모두). 줄마다 앞뒤 공백을 지우고, 이어진 공백은 하나로, 글자 · 숫자(한글 포함)가 아닌 문자 바로 옆의 공백은 지웁니다. 따옴표 종류는 가리지 않습니다. 결과 줄이 따옴표로 시작하고 끝나지 않을 때만 A 줄 전체를 감싼 따옴표 · 백틱을 뗍니다. js에서 결과 줄에 따옴표로 감싼 객체 키가 없을 때만 A의 `\"a\":` · `'a':`를 `a:`로 봅니다(py는 그대로). 줄 끝 마침표 하나와 true · false · none · null · undefined · nan의 대소문자는 보지 않습니다. 결과 끝의 빈 줄은 견주지 않고, 가운데 빈 줄은 A의 빈 줄이나 '(빈 줄)'과 같습니다. 결과가 여러 줄이고 A가 한 줄이면 결과 줄들을 ', ' · ' ' · '과 ' · '와 ' · ' 그리고 ' · ' → ' 가운데 하나로 이어 맞춘 것이 A와 같으면 같음입니다. 그 밖의 글자 · 값 · 차례 · 줄 수 · 괄호 · 숫자 표기 · 대소문자는 그대로 견줍니다. 앞 공백만 다른 줄(padStart · ljust · rjust)은 이 규칙으로 같음입니다(1.10.0과 같음, 바꾸지 않음).",
    "7 (가) 코드 다름 · 답 다름: 아래를 모두 갖춘 자리만 넘음으로 셉니다. (ㄱ) ⚙ 읽힌 문항의 rung이 changed. (ㄴ) ⚙ 코드를 바꿨음: 3의 문제 코드가 학습자 조각(= 파일 전체)과 6의 맞춤과 줄 끝 `;` · 주석 뺌 뒤 줄 단위로 (i) 같지 않고 (ii) 찍는 줄(한 줄짜리 console.log(…) · print(…))을 뺀 나머지 줄이 학습자 줄들의 부분열이 아님. (ㄷ) ⚙ 그 개념의 코드에서 왔음: 학습자 조각의 핵심 줄(토큰 4개 이상, 괄호뿐 · else · `return 이름` · 이름 하나만 찍는 줄이 아님; 없으면 토큰 2개 이상) 가운데 하나 이상이 보인 코드의 어느 줄과 토큰이 같거나 하나만 다름(codeAsRead 토큰). (ㄹ) ⚙ 정의 빠짐이 아님: 결과가 ReferenceError/NameError로 끝나고 그 이름이 블록 안에서 한 번도 선언 · 대입 · 매개변수 · for 변수 · catch 변수로 나오지 않으면 놓침(TDZ · UnboundLocalError는 들지 않음). (ㅁ) ⚙ kind가 predict. (ㅂ) ⚙ 펜스 블록이 하나. (ㅅ) ⚙ 답이 다름(8). (ㅇ) ⚙/✎ 문제 글이 맞음(10). (ㅈ) ⚙ 3의 여러 번 돌린 결과가 모두 같고 5초 안. (1.13.0) 더하여 조항 16 · 17 · 18도 (가)의 조건입니다.",
    "8 답 다름 ⚙: 학습자 결과: 3의 얼린 학습자 결과(진짜 돌린 것). 조각 결과: 1.10.0 조항 8의 정의 그대로이고, 이 설계의 조각은 파일 전체이므로(isWholeShown) 조각 결과는 학습자 결과와 같습니다. 견줄 것은 물은 것(5: 결과 전체)입니다. 6으로 맞춘 뒤 아래 가운데 하나면 같음(놓침): (a) 결과 전체가 학습자 결과 전체와 같음. (b) 결과 줄들이 차례 그대로 학습자 결과 안에 이어진 줄들로 있음(어디서 시작해도; 한 줄이면 학습자 결과의 어느 줄과 같아도). (c) 결과 줄마다 학습자 결과의 같은 순번 줄과 같음. (d) · (e)는 물은 것이 언제나 결과 전체라 쓰이지 않습니다. 결과가 오류 이름으로 끝나면 그 줄은 학습자 결과의 어느 줄과도 다릅니다. 결과가 오류 이름 한 줄뿐이면 다름입니다.",
    "9 예측이 아닌 문항: 쓰이지 않음: 플러그인이 kind를 predict로 씁니다. 도구 결함으로 다른 kind가 저장되면 7(ㅁ) 놓침, (나)는 11로 매깁니다.",
    "10 문제 글 ⚙: lead와 hint는 플러그인이 쓴 고정 글이지만 모델 글처럼 매깁니다. (ㅇ)를 갖추려면 모두: (i) question이 CHANGED_LEAD 글 그대로로 시작하고 그 뒤에 펜스 블록 하나만 있음; (ii) 보인 코드와 학습자 코드가 정확히 한 줄에서만 다름(\"한 곳을 바꿨습니다\"가 참); (iii) hint의 \"k번째 줄\"이 그 다른 줄의 번호(보인 블록의 첫 줄을 1로, 빈 줄 포함)와 같음; (iv) hint가 줄을 따왔으면 따온 글이 그 줄의 앞뒤 공백을 뺀 것과 글자 그대로 같음(60자를 넘는 줄은 따오지 않으며 그때는 (iii)만 봄). hint는 바뀐 줄을 알려 줄 뿐 결과를 말하지 않으므로 답을 미리 말한 것으로 보지 않습니다. 하나라도 어긋나면 (가) 놓침입니다.",
    "11 (나) A 맞음: ⚙ 먼저 도구가 A 전체를 6으로 맞춰 3의 결과 전체와 같은지 봅니다. 같으면 맞음. ✎ 아니면 매기는 쪽이 봅니다: A가 결과의 줄을 모두 차례대로 말하고(6의 \"그대로 견주는 것\"으로) 다른 틀린 말이 없으면 맞음. 틀림: 결과 가운데 일부만 쓴 A, 줄여 쓴 A(… · 등 · 생략), 오류로 멈추는 결과에 출력만 쓴 A, 오류 이름을 다르게 댄 A, 둘 이상을 답으로 내놓은 A, 학습자 원래 코드의 답을 쓴 A, 줄 수가 다른 A. (1.13.0) 실행 길의 A는 플러그인이 돌린 줄들이므로 결과와 다르면 조항 16으로 틀림이고, 도구가 같다고 보지 못한 A는 매기는 쪽이 이 조항의 맞음 꼴인지 봅니다.",
    "12 ts: 쓰이지 않음: ts는 범위 밖이고(RUNG_CHANGED_EXTS = js, py) 견본에 넣지 않습니다. 도구 결함으로 ts 문항이 저장되면 (가) 놓침, (나)는 3으로 돌린 결과와 견줍니다.",
    "13 번호가 엇갈린 답 ⚙ (1.13.0): parseQuiz가 짝지은 번호대로 매깁니다. changedRunItem은 그 번호 자리 개념의 코드와 그 자리의 목록으로만 문항을 짜고, C의 번호가 자리 번호와 다르면 문항을 내지 않으므로(other-slot), 엇갈린 답은 읽히지 않은 자리(2)로만 셉니다. C를 다시 쓴 답은 플러그인처럼 마지막 글로 읽습니다(quizParts lastWins).",
    "14 매기는 차례와 갈림: 꼬리표마다 매기는 하위 에이전트 둘이 따로 매깁니다. 둘 다 설계 · 견본 쓰기 · 부르기에 끼지 않은 새 하위 에이전트이고, 이 글과 도구가 낸 파일만 봅니다(모델 이름, 토큰, 시간은 빠짐; 도구가 낸 판정 칸은 ⚙ 조항의 결과로만 보이고 ✎ 조항의 답을 미리 적지 않음). 두 판정이 갈린 문항과 이 글이 가르지 못하는 경우는 기능에 불리한 쪽((가) 놓침, (나) 틀림)으로 셉니다. 재는 세션은 판정을 바꾸지 않고, 출력을 본 뒤 조항을 더하거나 고치거나 다시 읽지 않습니다. 고칠 것은 '다시 잴 때'에 적기만 합니다. 짝 파일은 sha256만 적어 봉하고, 짝을 알리는 파일 이름이나 칸을 짝을 열기 전에 두지 않습니다.",
    "15 미리 가른 경계 사례: 아래 '경계 사례' 목록(1.10.0 · 1.12.0 기록과 1.13.0 개발 견본에서 나온 것)을 따릅니다.",
    "16 (1.13.0, 더 엄격) 플러그인이 낸 답도 똑같이 매김: 실행 길의 저장된 A가 3의 진짜 결과와 6으로 같지 않으면 (나) 틀림이고 그 자리는 (가)에서도 놓침입니다. 평가기(newRun) 결함, node · python 판 차이, '도구 결함' 어느 까닭으로도 면하지 않습니다.",
    "17 (1.13.0, 더 엄격) 고르기 길: 잴 자리마다 문항이 커밋된 트리의 rungOf(sonnet 줄에 rungChangedStep 2 · isChangedRun 켬)로 'changed'에 닿고 code.run이 있는 고르기에서 changedRunItem으로 만들어진 것이어야 합니다. 그 길 밖에서 만들어진 문항(예: 1.12.0의 C · O · N 길로 읽힌 문항)이 저장되면 (가) 놓침이고 (나)는 그대로 매깁니다. 도구가 얼린 build 기록으로 셉니다.",
    "18 (1.13.0, 더 엄격) 모델이 고른 바꿈: 저장된 문항의 바꾼 줄이 모델의 C가 말한 곳에 C가 말한 값을 넣은 것이어야 (가)를 갖춥니다. 모델 값이 값으로 읽히지 않거나(소수 · 음수 · 범위 밖 숫자 · 목록에 없는 대안 · 값 뒤의 다른 글), 바꾼 코드를 평가기가 돌리지 못했거나(오류 · 한도 · 묶음 출력), 바꾼 뒤 결과가 학습자 결과와 같거나 묻지 못할 꼴이라 플러그인이 그곳의 미리 확인한 바꿈으로 대신 냈으면(changedRunItem의 isOwn이 false), 그 자리는 (가) 놓침이고, 저장된 문항이므로 (나)에서는 매깁니다. 도구가 같은 커밋의 changedRunItem이 낸 isOwn으로 셉니다.",
    "19 (1.13.0, 더 엄격) 견본이 모자란 자리: 견본 짜임의 잴 자리(js 13 · py 7)를 커밋된 rungOf로 'changed'에 닿는 기록으로 채우지 못한 자리(미리 정한 보탬 한 번 뒤에도 모자람)는 (가) 놓침이고 (나) 밖입니다. 다른 언어의 기록으로 채우지 않습니다.",
    "20 (1.13.0, 중립) 실행 길의 답 꼴: 저장된 A는 플러그인이 돌린 줄들(1–4줄, 줄마다 160자 이하, 빈 줄 없음)을 줄바꿈으로 이은 것이고 오류 이름으로 끝나지 않습니다(오류로 멈추는 바꿈은 목록에 오르지 않고, 모델 값이 오류로 멈추면 대신 냄 → 18). CHANGED_LEAD의 '오류로 멈추면 …' 글은 이 길에서 쓰일 일이 없지만 문항 글의 일부로 10 (i)에 그대로 듭니다.",
]

BOUNDARY = [
    "1.10.0 기록(그대로): W10 부모 클래스가 블록에 없음 → 7(ㄹ)(이 범위에서는 생기지 않음). 줄인 출력 → 11 틀림. 되돌리기 · 바꿔 보기 · 왜 → 9(쓰이지 않음). Q가 지금 출력을 틀리게 말함 → 10. Object.freeze A length 1 vs TypeError → 11 틀림. 빈 답 · 상한에 잘린 끝 → 2. 그대로 보임 · 몇 줄만 떼어 보임 → 7(ㄴ). 1.8.0 ===/== 출력 그대로 → 8 같음. node `[ 1, 2, 3, [ 4 ] ]` vs A `[1, 2, 3, [4]]` → 6 같음(이 길에서는 묶음을 찍는 파일이 범위 밖). 산문 A → 11. pythonista[7:]를 ista로 → 11 틀림. 두 블록으로 보임 → 7(ㅂ). 두 번 돌린 결과가 다름 → 3. 끝에 빈 줄을 찍음 → 6 견주지 않음. `1 2`와 `12` → 6 다름. JSON.stringify의 `{\"a\":1}`을 `{a:1}`로 쓴 A → 6 다름.",
    "1.12.0 기록(1.13.0에서 읽는 법): O · N을 다시 썼거나 O가 틀리고 N이 맞은 자리 · 'subset' · 'echo' · 'value' · 'same' · 'count' · 'N-lines'로 걸러진 자리 → 이 길에는 O · N이 없어 생기지 않음(1). for-else · continue · sum · min에서 결과가 학습자 결과의 앞 줄 · 가운데 줄이 됨 → 8(b) 같음(이 길에서는 그런 바꿈이 목록에 오르지 않고, 모델 값이 그렇게 되면 대신 냄 → 18 놓침). grade()의 흐름을 잘못 따름 · 반복의 마지막 줄만 씀 · repeat(-1) 앞에 찍힌 줄을 씀 · JSON 길이를 잘못 셈(모두 1.12.0 개발의 모델 N 틀림) → 이 길의 A는 모델 글이 아니라 생기지 않음; 생기면 16 틀림.",
    "A 줄 끝 마침표(`true.`) · 대소문자(`TRUE`/`True` in js) → 6: 마침표 하나와 true/false 대소문자는 보지 않음. py `<class 'bool'>`, js typeof의 `number` → 결과 그대로; 6으로 견줌. 실수 표기(0.30000000000000004, 9240.0) → 6 그대로. 앞 공백만 다른 줄 → 6 같음. 가운데 빈 줄 → 이 길의 A에는 빈 줄이 없음(20); 결과에 빈 줄이 있으면 줄 수가 달라 11 · 16 틀림.",
    "(dev 1.13.0) 모델 값이 출력을 바꾸지 못함(맵 경계 `x < 0`을 `<=`로 — 데이터에 0이 없음; 배터리 `< 20`을 `<=`로; 과반수 `/ 2`의 2를 3으로) → 플러그인이 그곳의 미리 확인한 바꿈으로 대신 냄 → 18 (가) 놓침, 저장된 문항은 (나)로 매김.",
    "(dev 1.13.0) 숫자 자리에 소수(85.5) · 음수(-5) · numberBound를 넘는 수(401) · 원래 값(80) · 값 없음(`1e`, `1e: `) → 대신 냄(isOwn false) → 18 놓침.",
    "(dev 1.13.0) 값이 상황에 맞지 않지만 맞게 돈 답('월요일 수면 -4시간', '9시 30분 -15.0도', '빠진 번호: 6.5', 기준표 [(70,\"A\"),(80,\"B\"),(70,\"C\")]의 '예린 A') → B-10: 문제 글의 다른 흠은 기록만; 3 · 6 · 11로 매겨 결과와 같으면 맞음 · 넘음.",
    "(dev 1.13.0) 바꾼 곳이 개념 줄(blurb가 따온 줄)에서 먼 데이터 값(삼각형 넓이의 base 6 → 10, 정원 초과의 72 → 150) → 7(ㄷ)는 보인 코드가 학습자 파일 전체라 갖춤; 개념과 먼 바꿈은 B-10 기록만(개발 sonnet D 9/40 · E 14/40만 개념 줄에 닿음, haiku도 비슷함).",
    "(dev 1.13.0) console.log · print에 값 여럿(`console.log('합계:', total)` → `합계: 176`, `print(\"x\", 1.0, True, None)` → `x 1.0 True None`) → 결과 그대로; A도 플러그인이 같은 꼴로 냄; 6으로 견줌. 첫 인자가 `%`를 품은 console.log와 키워드 인자 print는 평가기가 돌리지 않아 범위 밖.",
    "(dev 1.13.0) js `-0`, py `-0.0`, 긴 실수(`3168.3168316831684`), py 정수 나눗셈의 `.0` → 결과 그대로(6은 숫자 표기를 그대로 견줌); 다르면 16 틀림.",
    "(dev 1.13.0) C 머리를 백틱으로 감쌈(`` `1d` < ``) · 이름 뒤에 쌍점 · 화살표(`1d: <`, `1d → <`) → 읽기 그대로(grammar 통과). C 머리가 글자 둘(`1dd`) · 번호 없음(`d <`) · 목록 밖 글자(`1g`) → 2 읽히지 않음(grammar). 번호가 다름 → 13(other-slot).",
    "(dev 1.13.0) 문자열 자리의 값을 따옴표 없이 · 다른 따옴표로 씀 → siteValue가 읽으면 그 값, 못 읽으면 대신 냄 → 18로 기계가 셈(isOwn).",
    "(dev 1.13.0) 한 줄에 같은 토큰이 둘(`두 번째 0`) → 목록이 순번으로 가리키고 플러그인이 그 자리만 바꿈 → 10 (ii)로 정확히 한 줄 다름을 봄.",
    "(dev 1.13.0) 답 끝에 N 줄 · 설명을 덧붙임 → 1: 읽지 않음, 저장된 문항만 매김.",
    "(1.13.0) 플러그인의 '지금 찍히는 글자'가 진짜 학습자 결과와 다름(평가기 결함) → 3: 판정은 진짜 결과로만; 8도 진짜 학습자 결과와 견줌; 저장된 A가 진짜 결과와 다르면 16 틀림; 평가기 결함은 '다시 잴 때'에 적음.",
    "(1.13.0) 바꾼 코드의 진짜 실행이 5초를 넘음 → 3: (가) 놓침 · A 틀림(평가기는 20,000걸음을 넘으면 돌리지 않으므로 생기면 16과 함께 적음).",
    "(1.13.0) 결과가 다섯 줄 이상 · 160자 넘는 줄 · 빈 줄이 되는 모델 값 → 플러그인이 대신 냄 → 18 놓침.",
    "(1.13.0) 견본 쓰기에서 한 언어가 보탬 한 번 뒤에도 모자람 → 19: 그 잴 자리는 (가) 놓침, 다른 언어로 채우지 않음.",
]

stance_text = '\n\n'.join(STANCE) + '\n\n경계 사례\n' + '\n'.join('- ' + b for b in BOUNDARY)

design = {
    'id': 'G2',
    'name': '비슷한 코드 (rungChangedStep) · sonnet 실행 길: 플러그인이 기기에서 돌려 확인한 곳만 보이고, 모델은 곳과 새 값만 고르며, 답은 플러그인이 돌린 결과 (1.13.0 G2-RUN, 파일럿 r2)',
    'recommendationInOneLine': 'sonnet: measure — one round of the r2 design after a bar commit that adds the stricter fallback clause (18), the sample-shortfall clause (19) and a pre-call differential gate, on a fresh calibration; r2 was judged only on two fresh dev sets written after its code was frozen (sets D and E: 20/20 in all four runs, 19/20 with the model\'s own value, 0 wrong in 80). Owner question 0 can stop it, because the pilot exceeded the design text\'s one-revision rule. haiku: ON (rungChangedStep 2) and untouched; it is neither re-measured nor transferred.',
    'what': {
        'whenOn': [
            'Only where MODEL_SWITCHES.sonnet holds BOTH rungChangedStep 2 and the new flag isChangedRun true (set together in one value commit after a pass), at level beginner, in a window whose alias, provider, gateway and modelOverrides reads are clean. recheckRemap runs in makeQuiz before any quiz switch is read, as in 1.12.0 (it already runs whenever rungChangedStep is finite). RUNG_CHANGED_STEP = Infinity and IS_CHANGED_RUN = false stay (D1). haiku\'s row keeps rungChangedStep 2 with isChangedRun false, so haiku stays on its 1.12.0 route byte for byte.',
            'For a concept due at review step 2 or later, met in a whole created js/py file (isWholeShown) that passes every 1.12.0 check (isChangedRunnable, isChangedShaped). In addition, the plugin\'s own evaluator (newRun with printArgs) must run the learner\'s whole file cleanly with 1–8 non-blank output lines of at most 160 characters, and at least 2 places must have a certified change (changedRunFor). Otherwise the concept is asked as 내 코드 (the 1.9.0 behaviour for that concept).',
            'Reach on the dev corpus: 119 of 250 written whole-file records (48%; js 69/155 = 44.5%, py 50/95 = 52.6%), against the haiku route\'s 224/250 (90%).',
        ],
        'learnerSees': [
            'No new learner-facing string. A sonnet item has exactly haiku\'s 1.12.0 item shape: the tag 비슷한 코드 (RUNG_LABEL), kind 예측, and stock grading.',
            f'Question (unchanged constant CHANGED_LEAD, then one js/python fence holding the changed whole file): "{CHANGED_LEAD}"',
            f'Hint (unchanged CHANGED_HINT; the quote is left out for a line over 60 characters): "{CHANGED_HINT}"',
            'Answer: the lines the plugin printed when it ran the changed file on this device (1–4 lines, never an error line), shown in the answer block exactly as haiku\'s answers are (answerShown).',
            f'If every pick of a quiz was changed and none could be read, the existing message is shown unchanged: "{ALL_UNREAD}" A concept whose slot was unread joins quizRun.changedMissed and is asked as 내 코드 for the rest of the window (unchanged 1.12.0 behaviour).',
            '/learn 진단: FEATURE_NAMES maps isChangedRun to the same 비슷한 코드 (routeOn dedupes it), so the feature line is the same as for haiku. SWITCH_NAMES \'비슷한 코드 기기 실행\' appears only in a test harness\'s switched-names list.',
            'How a sonnet item differs from haiku\'s: its answer is the plugin\'s own run, never the model\'s text; its change is the value the model named, or, when that value fails, the place\'s certified change; it never ends in an error; it occurs only for small whole files the plugin can run itself.',
        ],
        'unchanged': [
            'Every haiku request, pick and reading (shared functions untouched for haiku inputs; D26 proofs below).',
            'All OFF bytes for any other model string, level, remapped or provider window, and for sonnet until the value commit.',
            'Store shape: 0 new keys or fields; types/index.d.ts unchanged.',
            'Call settings: maxTokens 4600 (QUIZ_TRACE_TOKENS, as for any quiz holding a changed pick), timeoutMs 90000, effort low, QUIZ_SYSTEM, askModel with redactText.',
            'recheckRemap, changedMissed, numberUnsure, bankQuestion, markFor, answerShown, keptRung.',
        ],
    },
    'why': {
        'sonnetMissKinds': [
            '1.10.0 API refusals of a written-trace prompt (8 of 9 calls): no trace, no output and no reasoning is asked; the model writes one C line per slot. 0 refusals in 105 sonnet dev calls across r0–r2, and 0 in the 36 calls using the final wording.',
            '1.10.0 reply cut mid-text: the expected reply is about 28–550 tokens (median about 350, max 545), against a cap of 4600 + H. Kept as a residual risk.',
            'Wrong N from control flow, consistent across runs (1.12.0 set 3 grade()): the model writes no N, and the answer is the device\'s run. This cannot become a stored wrong answer.',
            'Wrong N from partial loop output, error position, or character/length counting: the answer comes from the run. Throwing changes are never certified, and a model value that throws falls back.',
            'Stance 8 (a)/(b)/(c) misses (N equal to a run of O): isCertified excludes them against the evaluator\'s O, both at certification and for the model\'s own value. A model value that would hit them falls back, and clause 18 counts that as a miss.',
            'Reader refusals value/echo/same/subset/N-lines/count: they cannot occur, because the reply is a label plus a value.',
            '1.10.0 haiku families (wrong kind, mis-numbering, code not from the concept, print-line-only change, same answer): the plugin still writes the question, kind, fence, hint and change. A change is never on a print line (changeSites).',
        ],
        'mechanism': 'The plugin decides the output (1.12.0 \'다시 잴 때\' direction (1)). On this device it runs the learner\'s whole file and every candidate change with a closed-subset evaluator (newRun), and lists only the places where a change runs cleanly and prints something askable. The model only names one place and a new value. The plugin applies that value and runs it, and the stored answer is that run. The model\'s arithmetic never touches the answer path, so (나) rests on evaluator fidelity. The differential gates check that before any round, and the judges still run the real code (B5, clause 16).',
        'evidence': [
            'r0 (plugin-fixed values; the model writes N; kept only on agreement): sonnet kept 13, 12, 10 and 8 of 20 with 0 wrong. Its N agreed with the device in only 43 of 80 slots.',
            'r1 (the model picks its own value; its N must agree): 13 and 14 of 20 with 0 wrong; agreement was about 75%.',
            'So at effort low, with no written trace allowed, sonnet cannot reliably predict a changed run, even for a change it picked itself. Any design that stores, or requires, the model\'s prediction is capped below (가) 16/20 if it keeps (나) at 0. Agreement checks cannot catch a consistent error such as the grade() case.',
            'r2 (C only, answer = run): 20/20 in each of 4 runs on two fresh sets, 0 wrong in 80 read items. 76 used the model\'s own value and 4 used a fallback, one per run.',
        ],
    },
    'whyNew': [
        'Versus 1.8.0, 1.9.0 and 1.10.0 (the model writes the question and a line-by-line R trace, and its answer is stored): here the model writes no question, no trace and no answer.',
        'Versus 1.12.0 G2-C rev4 (the plugin lists sites; the model writes C, O and N; the plugin applies the change and checks the form; the stored answer is the model\'s N): here the stored answer is computed on the device by an evaluator that 1.12.0 G2 did not have. The prompt shows the learner\'s true output (O), so the model writes neither O nor N. Places are listed only after the plugin has run a change at each one and certified it under stance 8. A new switch row keys the sonnet-only path.',
        'It is a different mechanism (on-device computation of the answer), not a reworded sentence. The prompt piece the model reads (CHANGED_RUN_ASK, runLines) is new, and the reader (changedRunItem) is a new function.',
    ],
    'how': {
        'switch': 'New Switches key isChangedRun ("flag"): one row in SWITCH_KINDS, SWITCHES_OFF (IS_CHANGED_RUN = false), FEATURE_NAMES (\'비슷한 코드\', deduped) and SWITCH_NAMES (\'비슷한 코드 기기 실행\'). Why a key is needed: the sonnet request and pick must differ while haiku\'s must not, so the branch must be keyed by a value haiku\'s row does not hold. The harness and pilot must also be able to turn it on. register.tsx ladderSteps() returns changedRun = build.isChangedRun && Number.isFinite(build.rungChangedStep), and only when true (the 1.12.0 object otherwise, key for key). makeQuiz passes it to withCode.',
        'evaluator': 'newParse/newRun copied from the 1.13.0 G3 final prototype (impl113/design/G3/final/enginechk/hooks/notes.ts, the block from `export type NewRunRefusal` to the end of the file). It is identical except for the header comment and the opt-in NewRunOpts { printArgs } (44 diff lines: final/g3ev.ts vs final/g2ev.ts). printArgs: console.log with 2–4 primitive values joins their texts with one space, and is refused when the first value is a string holding \'%\'. Python print with 2–4 str/number/None values joins str() of each with one space, and any keyword argument is refused. A container is still refused (print-value). The flag resets in finally, and the default reproduces G3 exactly. Limits are G3\'s: NEW_RUN_STEPS 20,000, depth 40, size 1,000, and no astral characters. Any runtime error or limit hit is a refusal.',
        'certification': 'changedRunFor(text, file, blurb) → { out, certs } | undefined. out = newRun(whole file, printArgs). It is undefined unless out has 1–8 lines, none blank, each ≤ 160 characters. Places come from changeSites(text, file, blurb, isAll = true): a new optional trailing argument returns the untrimmed nearest-first list, and its default runs the 1.12.0 body unchanged. Values per place (runValues): an integer n gives n+1, n−1, n+2, 2n, kept in 0..numberBound (a decimal is never changed); a string gives the other string tokens of the file with the same quote; a comparison gives its strict/non-strict partner first, then the rest; logic, bool and method give their listed alternatives. The first value whose changed file runs cleanly and passes isCertified(lines, out) is kept. At most 6 places (CHANGED_RUN_CERTS) are kept, nearest-first, then listed in code order. isCertified: 1–4 lines (CHANGED_RUN_LINES), none blank, each ≤ 160 characters, and, under outputSame and again under a looser key (lower case, no whitespace, no quotes, no final \'.\'), not equal to out (8a), not a run of consecutive out lines anywhere (8b; one line equal to any out line counts), and not line-for-line equal to out\'s lines at the same positions (8c).',
        'rungOf': 'When steps.changedRun is true, the 1.12.0 changed condition must also hold code.run.certs.length ≥ 2; otherwise the rung is \'mine\'. When changedRun is false, the 1.12.0 expression decides byte for byte. withCode sets transient QuizPick.code.run = changedRunFor(...) only when isChanged && isWhole && changedRun. It is never stored or sent; only out and the place lines go into the prompt.',
        'prompt': {
            'changedRunAsk': CHANGED_RUN_ASK,
            'where': 'changedQuizPrompt puts CHANGED_RUN_ASK in RUNG_ASK[\'changed\']\'s place when any changed pick has code.run. Under such a concept, runLines replaces siteLines: \'   지금 찍히는 글자:\' with out in a fenceFor fence, then \'   바꿀 수 있는 곳 (줄은 위 코드의 첫 줄을 1로 셈):\' and one line per cert, \'   {n}{a–f}: {line}번째 줄의 [두 번째 ]`{token}` ({what})\'. Here what is \'0부터 {numberBound} 사이의 다른 정수로\' for a number, or SITE_WHAT\'s text for the others (e.g. \'< <= >= == != === !== 가운데 하나로\', \'"로 감싼 다른 문자열로\').',
            'formatLine': 'C{k}: (고른 곳 이름, 한 칸 띄우고 새 값만. 예: {k}b 20)  — the only line for a run-route slot (no O, no N).',
            'shared': 'Every other line is shared and byte-identical: LEVEL_TEXT, the concept heads, the code fence, the count line, CHANGED_KINDS_LINE and the T·Q·H·A lines for other slots, the \'정확히 아래 형식만\' line, and QUIZ_SYSTEM. A test asserts that the prompt holds no \'R1\', \'한 줄씩\', \'따라\' or \'과정\'.',
        },
        'reading': 'quizItems routes a changed pick that carries code.run to changedRunItem. parseQuiz, quizParts, changedItem and every helper haiku runs are not edited, so G3\'s \'b\' marker reservation is kept. changedRunItem(parts, n, pick) → { item, isOwn } | { reason: missing | grammar | other-slot | site | long }. C is ~C{n} (lastWins) or C{n}, with fence lines and blank lines skipped. Its head must match /^\\s*`?(\\d+)([a-f])`?(?:$|[\\s:：)]\\s*(?:→|->|=>)?\\s*(.*?)\\s*$)/. The number must equal n, and the letter must name a cert. The value is read by the existing siteValue; for a number it must be a whole number in 0..numberBound. The plugin applies it and runs newRun(printArgs). If the value is invalid, the run is refused, or the lines fail isCertified, the place\'s own cert stands in (isOwn false). The item is composed as changedItem composes it (a test pins the two equal): question = CHANGED_LEAD + one js/python fence holding the changed code; hint = CHANGED_HINT(line + 1, changed line); answer = run lines joined by \\n; kind predict; rung changed; key, name and noteId. A question over 1200 characters gives \'long\'. isOwn is read only by the measuring tool (clause 18).',
        'finalTreeChangesVsPilotR2': [
            'Comments only: IS_CHANGED_RUN now describes r2 and states the rule-6 widenings. runLines and RUN_WHAT drop \'r1\'. changedRunFor says \'six places at most\'. The changedQuizPrompt comment says \'C only\'.',
            'Type: ChangedRead is restored to HEAD\'s text, so haiku\'s type is textually untouched, and the r0 reasons \'differs\' and \'run\' are gone. changedRunItem returns the new ChangedRunRead with isOwn (no reasons beyond missing, grammar, other-slot, site and long).',
            'Tests: run113 and flow113g2 now assert isOwn and drop the r0/r1 wording from 3 test names. 0 tests were removed.',
            'Proof that the pilot still covers the final tree: dev sets D and E rebuilt with tree-final give samples, layout, build-sonnet, build-haiku, lines-sonnet and lines-haiku byte-identical to the frozen pilot files (final/reD, final/reE). Re-reading the frozen sonnet answers gives 54/54 identical slots (items and reasons) in each set.',
        ],
        'caps': 'Quiz call: maxTokens 4600 (QUIZ_TRACE_TOKENS, unchanged), timeoutMs 90000, effort low; cap hit = output_tokens ≥ 4600 + H_sonnet (1.13.0 calibration). Device: CHANGED_RUN_CERTS 6, CHANGED_RUN_LINES 4, CHANGED_RUN_WIDTH 160, CHANGED_RUN_OUT 8, NEW_RUN_STEPS 20,000.',
        'perModelCells': {
            'haiku': '{ ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2 } (isChangedRun false via SWITCHES_OFF) — unchanged, ON.',
            'sonnetNow': '{ ...SWITCHES_OFF, isRuleWide: true } — G2 OFF.',
            'sonnetOnPass': '{ ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2, isChangedRun: true } in one value commit. Both values move together or neither does. rungChangedStep 2 without isChangedRun on sonnet would be the unmeasured 1.12.0 route and is never shipped.',
        },
        'files': 'hooks/notes.ts (+4,364 lines: evaluator about 4,160 copied, printArgs about 45, G2 about 185), hooks/register.tsx (+8), tests/run113.test.ts (new, 9 tests), tests/flow113g2.test.ts (new, 4), tests/route.test.ts and tests/flow110.test.ts (switch-row re-pins).',
    },
    'prototypePatch': DIFF,
    'prototypePatchSha256': sha(DIFF),
    'prototypeFiles': {
        'tree': f'{G}/proto/tree-final',
        'pilotTrees': [f'{G}/proto/tree (r0)', f'{G}/proto/tree-r1', f'{G}/proto/tree-r2'],
        'pilotDiffs': [f'{G}/proto/G2-run-113-r0.diff', f'{G}/proto/G2-run-113-r1.diff', f'{G}/proto/G2-run-113-r2.diff (sha256 936eaf78…0826)'],
        'tests': f'{G}/proto/test-final.out (1547 pass, 0 fail)',
        'proofs': [f'{G}/proofs/final (D26)', f'{G}/proofs/off-final', f'{G}/proofs/rulewide-final.log', f'{G}/proofs/mut3/result.txt', f'{G}/final/wide (differential)', f'{G}/final/enginechk/engine.out', f'{G}/final/reD', f'{G}/final/reE', f'{G}/final/own.txt'],
    },
    'samples': {
        'whoWrites': 'Fresh blind opus sub-agents (`claude -p --model opus --tools \'\'`, DISABLE_AUTOUPDATER=1, cwd an empty folder). They never see this design, the prompts, the stance, the scope or which model is measured. They use the 1.12.0 G2 measured writer prompts (impl112/b2/gen/writer-A.md, writer-B.md and the *-end.md files) word for word, except for: the record count, ids and languages per part (at most 10 records per call, the G3 STOP lesson); the mix minimums scaled to the part; and the avoid section, which holds names only. This is the dev parts.py procedure (dev/gen/parts.py), frozen with sha256 in the bar commit. Samples are not written or chosen for sonnet (M-12).',
        'layout': 'Writer parts written up front: A1–A5, js 10 each (50 js); P1–P3, py 10 each (30 py); B, the fillers as in 1.12.0 (내 코드 3 = ts, js and py fixes; 왜 2; 다시 도전 2). One pre-committed top-up per language that is short (T1 js 10, T2 py 10), then STOP. The first budget is larger than the pilot\'s (js 25, py 15) because one dev set (B) ended with 11 js members against the 13 measured js slots. From the dev reach (js 44.5%, py 52.6%), the chance that a language is still short after its top-up is below 1%.',
        'membership': 'Membership is decided only by the committed tree\'s sonnet-route rungOf (sonnet row + rungChangedStep 2 + isChangedRun true, through withCode/changedRunFor), in written order. The first js 15 and py 9 eligible records are taken (measured js 13 · py 7 plus 2 spares each, the 1.12.0 layout). A measured slot still unfilled after the top-up is a (가) miss (clause 19); no record of the other language fills it. Haiku samples and haiku\'s scope do not change.',
        'quizLayout': 'The 1.12.0 layout, unchanged: Q1–2 [c,c,c], Q3–5 [c,c,내 코드], Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; stages 2 and 3 alternating; every concept due; level beginner.',
        'freeze': 'chmod 444; sha256, author and UTC time recorded in 견본.md. D34: 9/9 requests captured from the plugin test harness with models.sonnet { rungChangedStep: 2, isChangedRun: true } must equal the tool\'s prompt files byte for byte before any call.',
        'preCallGate': 'Stated in the bar and run after freezing, before any call. Every frozen measured and spare record, at every place (changeSites isAll) and every value of the frozen final/wide/gen.mjs list (the runValues four, 0–5, 10, n/2, n+5, n+10, 10n and the bound for numbers; every other same-quote string; every listed alternative), is run by the committed evaluator and by the real runner (B5). Requirements: 0 accepted mismatches, the engine runtime equal to node on the same programs (claude plugin test fixture), and every learner run equal to out. Any mismatch stops the round before calls. The cell stays OFF, the failure is recorded, and newRun is not fixed and re-tried in 1.13.0 (an edit to newRun is a new design).',
        'avoid': 'Names only, never 견본.md prose and no model, alias or switch words: every name in impl113/NAMES-all.txt (9,066 lines, including the 285 G2-dev-113 names below, the 133 impl112 G2 dev names, the 1.12.0 G2 measured names and the G3-dev-113 names) plus the record-name fields of docs/qa/견본.md. The new measured names go into impl113/NAMES-all.txt tagged \'G2-measured-113\'.',
        'devNamesToAvoidCount': len(names),
        'devNamesToAvoid': names,
    },
    'calls': [
        'Exactly as the plugin calls (D20), through a copy of the impl111/probe mod. Per quiz: $.model.complete({ model: \'sonnet\' (the setting string as is), effort: \'low\', system: QUIZ_SYSTEM, prompt: redactText(quizPrompt(picks, \'beginner\')).text, maxTokens: 4600, timeoutMs: 90000 }). Calls run 4 at a time, are timed with $.clock, and replies go through fixEscapedTicks and are read by the committed parseQuiz. Picks are built as makeQuiz builds them (codeFor, withCode with changedRun → changedRunFor, rungOf, ladderMixed, pickForRung), from the committed tree with sonnet\'s shipped row (isRuleWide true) plus rungChangedStep 2 and isChangedRun true (M-13).',
        'One round of 9 sonnet calls. Haiku is not called (its cell is ON and proved byte-identical, rule 5 / D26). Only api-error (429/5xx, 0 tokens, no text) is re-sent, at most twice. Every empty or refused reply is tapped once through the pass-through tap for stop_reason and stop_details.category (a record only). The M-4 10% rule applies.',
        'CLI: a fresh pinned copy of the then-installed Claude Code (2.1.329 or later), DISABLE_AUTOUPDATER=1. M-5/M-10 calibration first (H_sonnet re-measured; the 1.12.0 value 2048 is not reused). `claude --version`, the system/init model and the modelUsage keys are recorded before and after. A mismatch with the calibration record voids the round, and the cell stays OFF.',
        'Usage gate (five_hour ≤ 0.60, seven_day < 0.80), detached runners, waiting on runner PIDs or status files (never `while pgrep -f`). Backup tar sha256 recorded in 견본.md.',
        'Labels: the sonnet round gets a random label. The pair file is sealed (sha256 only), and no file written before the pair is opened names the model.',
    ],
    'bar': {
        'source': 'docs/qa/견본.md \'1.12.0 비슷한 코드 (G2)\' → \'기준 · 입장 · 결정 규칙\' (bar commit 5da364c, pointing at code 3f9084c). It restates the 1.10.0 bar (d684d90; numbers from 1.8.0 and F4) without change, and is the last committed G2 bar for either model. Its decision rule 3 covers a sonnet round. It is governed by G7 M-0..M-15, B-1..B-15 and R0..R11, read as 1.13.0. Nothing is laxer.',
        'lines': [
            'B1 Numbers unchanged from the last committed bar. Nothing laxer.',
            'B2 Unit: the 20 changed slots of 9 quizzes (measured js 13 · py 7). The other items (내 코드, 왜, 다시 도전) are recorded only.',
            'B3 (가) At least 16 of the 20 slots meet every condition of stance clause 7 (ㄱ)–(ㅈ), plus clauses 16, 17 and 18.',
            'B4 (나) 0 wrong A among read items (clauses 6, 11 and 16). A stored answer that differs from the real run is wrong even though the plugin computed it.',
            'B5 Every slot is graded by running the shown code exactly as shown: unshare -n timeout 5; node twice; python with PYTHONHASHSEED 1..5, all five agreeing; nothing filled in. The learner\'s output is the real run of the whole file, never the plugin\'s \'지금 찍히는 글자\'.',
            'B6 Empty replies, timeouts, refusals and unread slots (changedRunItem: missing, grammar, other-slot, site, long) are (가) misses, outside (나), and are not re-sent. Only api-error is re-sent, at most twice. Cap hits (output_tokens ≥ 4600 + H_sonnet, from the 1.13.0 calibration) are recorded, and slots lost to them are (가) misses. Empty replies are tapped once for stop_reason.',
            'B7 Two blind judges per label, neither seeing the other label. A split, or a case the stance does not decide, goes against the feature. No clause is added, changed or re-read after any answer is opened (M-11).',
            'B8 Decision per model from that model\'s counts only: pass iff (가) ≥ 16/20 and (나) = 0. On a pass, the next commit sets MODEL_SWITCHES.sonnet.rungChangedStep = 2 and isChangedRun = true together (R6; route SHIPPED; R9 full old-build probe through the real plugin path; R10 docs). Otherwise both stay off. RUNG_CHANGED_STEP and IS_CHANGED_RUN stay off (D1). No transfer between models (R1/R2).',
            'B9 One round per (design, sonnet); no re-roll with new samples or a reworded sentence. The design\'s code stays behind the switch if it fails (rule 5). Rule 6 (sonnet): each of these is a widening and needs a new round: turning isChangedRun off while rungChangedStep stays 2; loosening isCertified; adding place kinds or values (decimals, negatives, values beyond numberBound); widening printArgs (containers, \'%\' formats, keywords, more than 4 values); widening changeSites, isChangedShaped or CHANGED_UNSETTLED; accepting a fallback as the model\'s choice in the measuring tool; or ANY edit to newRun/newParse. Narrowing needs none.',
            'B10 Measured = enabled (D33): 24 concepts written blind (20 plus 4 spares), all whole created files, js 15 · py 9 (measured js 13 · py 7), each in the sonnet run route\'s scope by the committed rungOf. Fillers: 내 코드 3 (ts, js, py fixes), 왜 2, 다시 도전 2. Quiz layout Q1–2 [c,c,c], Q3–5 [c,c,내 코드], Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; stages 2 and 3 alternating, all due; beginner; maxTokens 4600; timeoutMs 90000; effort low; QUIZ_SYSTEM; D34 9/9.',
            'B11 Stance statements committed with the bar (all neutral or stricter): 1 (C read, N neither asked nor read, the answer is the plugin\'s run), 2 (the run-route reasons are unread slots), 3 (the plugin\'s O is never used for judging), 16 (no tool-defect excuse), 17 (rung reached only through the committed sonnet route), 18 (a fallback item is a (가) miss but graded in (나)), 19 (a sample shortfall slot is a (가) miss), 20 (answer form).',
            'B12 Calibration on a fresh pinned copy of the installed CLI before the round, with version and alias recorded before and after. A difference voids the round, and the cell stays OFF (M-10, D19).',
            'B13 Deviation from 1.12.0 rule 3 (\'same frozen samples\'), stated in advance: 1.13.0 uses fresh blind samples written as above, because haiku\'s answers on the 1.12.0 set are already opened (M-3, D8) and at least 4 of its 20 files lie outside the run scope (D33). This is stricter in blindness, and haiku is not re-measured.',
            'B14 Rule 5 / D26 (extended): before every commit, re-check haiku\'s frozen requests, picks and reading byte for byte (lines-haiku.jsonl 876c8efd…, build.json 0db255b4…, read.json 05aa93f5…). Any difference in requests or picks turns haiku G2 OFF in that batch. Once sonnet is ON, the same holds for sonnet\'s frozen round (its requests, picks and re-read items), and any edit to newRun/newParse (for example when G3 lands) must re-pass the pre-call differential gate on the frozen sonnet samples and the wide corpus, or sonnet G2 turns OFF in that batch.',
            'B15 Common (G7 read as 1.13.0): M-1 the same bar for both models, counted per model; M-2 alias as is, effort low (unchanged), redactText, 4 at a time, D34 before calls; M-3 haiku is not called in this round, so sonnet alone; M-4 empty and timeout are misses, and the 10% api-error rule applies; M-5 cap = maxTokens + H_sonnet (re-measured); M-8 labels and a sealed pair; M-10 version/id before and after; M-11 undecided = miss; M-12 shared, blind samples not written for sonnet; M-13 recheck haiku\'s cell (B14); R2 no transfer; R4 another model string, an alias change or an unreadable state is always OFF; R5 a prompt change after results turns the cell OFF, and a reading-only change means re-reading the frozen answers.',
            'PRE-CALL GATE (new, stricter, stated in advance): after freezing and before any call, the differential gate of samples.preCallGate must give 0 accepted mismatches, with the engine runtime equal to node. Otherwise there are no calls, the cell stays OFF, and the failure is recorded.',
        ],
    },
    'stance': {
        'how': 'The full judging stance below (Korean, committed verbatim with the bar). It is the 1.12.0 G2 stance (5da364c) with clause numbers and meanings kept: clauses 1, 2, 3, 13 and 0 are amended for the run route, clauses 16–20 are added, and the boundary-case list is extended with every case from the r0–r2 dev answers. Every change is neutral or stricter. ⚙ clauses are counted by the frozen eval tool with real node/python; ✎ clauses (7 (ㅇ) where the tool cannot decide, and 11 when the tool finds no equality) are counted by two blind judges per label. A case the stance does not decide counts toward failing (M-11).',
        'edits': [
            '1: C is the only model line read; N and O are neither asked nor read; the answer is the plugin\'s run (neutral: what is stored is still all that is judged).',
            '2: the unread reasons are changedRunItem\'s five (neutral; follows B6).',
            '3: the plugin\'s \'지금 찍히는 글자\' is never used; the learner\'s output is the real run (stricter).',
            '13: other-slot and lastWins for C (neutral).',
            '16 (stricter), 17 (stricter), 18 (stricter), 19 (stricter), 20 (neutral): added.',
            'Boundary cases: 1.12.0 O/N cases marked as not arising, and 1.13.0 dev cases added (fallback kinds, odd but correct values, far-from-concept changes, multi-value prints, -0 and long floats, C grammar variants, evaluator-vs-real disagreement, step limit, shortfall).',
        ],
        'text': stance_text,
    },
    'decisionRule': [
        'Sonnet only, from sonnet\'s counts only (R1–R4). (가) = the number of the 20 measured changed slots whose stored item meets clause 7 (ㄱ)–(ㅈ) and clauses 16, 17 and 18, under both judges. Refused, empty, timed-out, unread, fallback (isOwn false), shortfall, split and undecided slots are misses. (나) = the number of read items whose A is wrong (clauses 6, 11 and 16; split or undecided = wrong).',
        'If the pre-call gate fails, or calibration or the before/after record mismatches: no round, and sonnet stays OFF.',
        'Pass ⇔ (가) ≥ 16 and (나) = 0. On a pass, the next commit sets MODEL_SWITCHES.sonnet to { ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2, isChangedRun: true } (R6, SHIPPED re-pinned, R9 old-build probe through the real plugin path, R10 docs, D26 re-check of haiku). Otherwise sonnet stays { ...SWITCHES_OFF, isRuleWide: true }.',
        'Haiku: no decision. Its cell stays ON (rungChangedStep 2, isChangedRun false) exactly as long as the B14 re-check shows its requests, picks and reading byte-identical; otherwise it turns OFF in that batch (rule 5 / D26). Nothing is transferred either way.',
        'One round; no re-roll; any later widening (B9) needs a new round, and narrowing does not.',
    ],
    'perModel': {
        'haiku': 'ON (1.12.0 measured 18/20, 0 wrong; rungChangedStep 2). This design does not touch haiku. The final tree keeps all three D26 proofs: the 9 frozen requests rebuilt byte-identical (D34 9/9, lines-haiku.jsonl 876c8efd…), build.json identical, and the frozen answers re-read to read.json 05aa93f5… identical (proofs/final). The 14 real plugin requests across models, levels and languages are identical between HEAD and the pilot tree (crit/bytes). Not measured, nothing transferred. The haiku dev control (records only) gave 18, 18, 20, 17 and 18 of 20 with 0 wrong in 91.',
        'sonnet': 'Measure (one round). Final dev sets D and E (records only, written after r2 was frozen): 20/20 kept in all four runs, 19/20 under clause 18 (one fallback per run), 0 wrong in 80 read items, 0 refusals, 0 empty, 0 cut, 0 timeouts, 0 cap hits, max 545 output tokens.',
    },
    'cost': {
        'perLearner': 'No new model call: one quiz call as today (cap 4600 + H). The prompt grows by about 60–250 characters per run-route concept for the O block, plus at most 6 place lines (a 3-slot quiz request was about 2,500 characters on dev). Output: sonnet median about 350 tokens (max 545); an all-changed quiz is about 28 tokens. Time: about 1.4–4 s. Device: changedRunFor median 0.67 ms, dev max 9.8 ms, about 29 ms on a stress file near the step limit; at most 3 picks × (1 + places × ≤ 4 values) evaluator runs per quiz, plus at most one run per changed slot when reading. Nothing new is stored.',
        'measurement': 'Writers: 9 opus calls (A1–A5, P1–P3, B) plus at most 2 top-ups. Calibration: about 3–6 sonnet calls (M-5). Round: 9 sonnet calls. Judges: 2 opus agents. Taps only for empty replies. Pre-call gate: CPU only (about 16k programs, about 10 minutes of real runs). Haiku: 0 calls.',
        'code': 'hooks/notes.ts 11,703 → 16,067 lines (+4,364, of which about 4,160 are the evaluator copied from G3). register.tsx +8. Two new test files (+248 lines).',
        'privacy': 'A new derived payload leaves the device inside the existing quiz request: the O block (what the learner\'s code prints, computed on the device from code that is already sent) and the place lines. It goes through askModel\'s redactText like the rest of the prompt, and isChangedShaped already requires 0 redact hits in the code. Nothing new is stored. 진단 holds counts, switch names and timestamps only.',
    },
    'compat': [
        'Stored data: the same fields as haiku\'s 1.12.0 changed item (key, name, question, hint, answer, kind \'predict\', noteId, rung \'changed\'), with 0 new store keys or fields. The answer is 1–4 lines and never an error line, the same stored shape as haiku\'s multi-line answers.',
        'Old windows: builds 1.5–1.12 (3f2b4fb, 7a7b08c, 3690021, fca5988, 3d2f251, de98243, 30adc2f) load, show and grade this item exactly as they do haiku\'s 1.12.0 changed items, which passed the 1.12.0 batch 2 R9 probe for this shape (markFor: wrong → 0, 거의 → one back, right → stays). A 1.12.0 window with the sonnet cell off stock-grades it. The R9 full probe with the sonnet ON value through the real plugin path (1.12.0 audit lesson 4) was not run in the pilot and must run at build, before the value commit. coexist19 passes in the final tree.',
        'OFF bytes: offbytes 592 same (only the 84 G2 ON-path cases differ, as in 1.12.0), offsplit 592/0, off111 949/0, off190b 553/0 (proofs/off-final). The fixtures quiz19 ×16, prompts18, quiz18, coexist19, route19, rule19 and CHANGED_QUIZ_OFF pass unchanged in the full suite. A harness with isChangedRun true and rungChangedStep Infinity gives the OFF request byte for byte (flow113g2).',
    ],
    'budget': {
        'newKeys': 0, 'newCommands': 0, 'newInputFields': 0, 'newSettings': 0, 'newStoreKeys': 0, 'newStoreFields': 0,
        'newModelCalls': 0, 'newDependencies': 0, 'newEnvReads': 0, 'newLearnerStrings': 0,
        'newSwitchRows': '1 (isChangedRun). Justified: the sonnet request and pick must differ while haiku\'s stay byte-identical, so the branch needs a value haiku\'s row does not hold. Its OFF value is false everywhere, and it moves only together with rungChangedStep 2 in sonnet\'s row. It touches the switch-table tests (route, flow110) by scripted re-pins with test names diffed: 0 removed.',
        'runTimePickFields': '1 (QuizPick.code.run), transient and never stored. Only its out lines and place lines are sent.',
        'sessionState': 'unchanged (quizRun.changedMissed).',
        'fileReads': '0 new (the run route reads no file; codeFor\'s text is enough).',
        'newExports': 'changedRunFor, changedRunItem, isCertified, runLines, CHANGED_RUN_ASK, IS_CHANGED_RUN, ChangedRun, ChangedCert, ChangedRunRead, and the evaluator (newRun, newParse, NewRunOpts, ...).',
    },
    'tests': {
        'added': [
            'tests/run113.test.ts (9): off everywhere it ships; printArgs (off by default = G3; on: 1–4 primitives, refusal of \'%\' formats, containers and keywords; no leak between runs); isCertified 8 (a)(b)(c) under both keys; changedRunFor (learner run, values in order, 6 at most in code order, a throwing change never listed, containers undefined, decimals never changed); rungOf (off = 1.12.0, on needs ≥ 2 certs); prompt (CHANGED_RUN_ASK, O block, place lines, C-only format, no trace words, 1.12.0 prompt without a run); changedRunItem (own value runs and is the answer, isOwn true; N not read; fallback for 81 / 80.5 / 85.5 / −5 / 401 / none / original value / \'=>\' with isOwn false; other-slot, grammar and missing reasons; a throwing value falls back; lastWins C); the duplicate composer equals changedItem; parseQuiz routing.',
            'tests/flow113g2.test.ts (4) through the real plugin path (harness models.sonnet): the ON request shows the O block and places, maxTokens 4600, and the item holds the plugin\'s run; an N line is never read; isChangedRun with the rung off gives the OFF request byte for byte; the OFF request for comparison.',
        ],
        'rePinned': 'route.test.ts (ON, ON_VALUES, SHIPPED, SWITCHES_OFF, keys, switchedNames) and flow110.test.ts (ON, ON_NAMED; the 1.12.0-route case pins isChangedRun false). Test names diffed against HEAD and against the pilot tree: 0 removed; 3 renamed from the pilot (r0/r1 wording).',
        'keptGuards': 'd34g2.test.ts (haiku\'s 9 measured requests through the plugin) and changed112.test.ts stay in-tree as haiku byte guards.',
        'buildMustAdd': [
            'The R9 old-build probe of a run-route item made through the real plugin path (sonnet ON value).',
            'A flow test where a fallback item is stored (isOwn false) and graded like any other item.',
            'An outside-the-repo engine-runtime fixture run of the pre-call gate programs (records only, like final/enginechk).',
        ],
        'mutationProbes': {'summary': '12 mutants on tree-final (proofs/mut3): skip-own-cert, store-model-N, no-fallback, allow-decimal-own, drop-certs-2, drop-subset, allow-container, allow-format, allow-decimal and isown-always are each caught by run113 (store-model-N also by flow113g2). run-without-flag is caught by the in-tree d34g2 (6 of 9 haiku requests fail) and by D26 (D34 2/9); flow110 does not catch it. drop-loose-key first survived; run113 gained two looser-key isCertified lines and now catches it. Every other mutant leaves haiku\'s D26 requests 9/9 identical.', 'raw': mut},
        'gates': 'tree-final: tsc 0; `claude plugin validate .` passed (with the usual warnings); `claude plugin test .` 1547 pass, 0 fail (proto/test-final.out). The two looser-key lines were added to run113 afterwards (tsc 0, run113 9/9 pass).',
    },
    'pilot': {
        'status': 'RECORDS ONLY (B-12). None of these numbers enters a decision. CLI 2.1.329 as installed (DISABLE_AUTOUPDATER=1, before/after identical in every session), provisional cap 4600 + 2048. Dev samples were written by blind opus writers with the 1.12.0 writer prompts (≤ 10 records per call); their 285 names are tagged G2-dev-113 in impl113/NAMES-all.txt. Each set was quizzed twice on sonnet (run route) and once on haiku (1.12.0 route, control), in the measured 9-quiz layout. Two blind opus judges per tag used the 1.12.0 template and stance, and real node/python runs per B5.',
        'iterations': [
            'r0, the design as first given (plugin-fixed values; the model writes N; kept only on agreement; stored answer = the evaluator\'s lines), sets A and B: sonnet kept A 13 · 12, B 10 · 8 of 20 (FAILED the pilot GO line ≥ 17). 0 wrong in 43; N disagreed in 37 of 80 slots. Set B had 16 api-errors (429, the five-hour limit), re-sent once and all answered. Haiku control: 18 and 18, 0 wrong.',
            'r1 (the model picks its own value; agreement still required), fresh set C: 13 and 14 of 20 (FAILED); 0 wrong in 27; unread: 10 differs, 2 run, 1 value. All 38 chosen changes that ran gave evaluator output equal to the real run. Haiku control: 20, 0 wrong.',
            'r2 (C only; the plugin\'s run is the answer; the place\'s certified change stands in when the model\'s value fails), fresh set D written and frozen after the r2 code (notes.ts 20:18:52, D frozen 20:28 UTC), then the held-back confirmation set E (frozen 20:54, no change since): sonnet 20 · 20 · 20 · 20 of 20, 0 wrong in 80, 0 refusals, 0 empty, 0 cut, 0 timeouts, 0 cap hits, 0 api-errors, output median about 350 (max 545). Haiku control: 17 and 18, 0 wrong.',
        ],
        'clause18Recount': f'Re-read of the frozen D/E sonnet answers with the final tree (final/own.mjs): {own}. Under the stricter clause 18 that is 19/20 in each of the four runs (bar 16).',
        'finalTreeCovered': 'tree-final rebuilds every D/E request byte-identical to the pilot\'s frozen files, and re-reads 54/54 slots identically per set (final/reD, final/reE). So the pilot numbers cover the final tree exactly, and no prompt was changed after the pilot.',
        'judging': 'Over 15 tags in sets A–E: 0 splits, 0 undecided, 0 (나) wrong. The judges used the 1.12.0 stance and saw the tool\'s verdict column, and the pair file was plaintext, so the judges add little beyond the runner. The independent evidence is the runner: all 80 stored D/E sonnet answers equal the real run (critic recount, crit/recount). The measured round uses this design\'s stance and a sealed pair (M-8).',
        'differential': f'Pilot: 0 mismatches over 6,000 generated printArgs programs, 384 corpus variants, every certified dev variant (A 98, B 98, C 125, D 128, E 119) and every model-chosen value (C 38, D/E 80). Final (wide gate, final/wide): {wide_stat["records"]} learner-shaped records (G2 dev 1.13.0 A–E, impl112 G2 dev sets 1–5 and the frozen 1.12.0 measured set, the 126-file G2 corpus, and the G3 dev pools 3–6 of trap code); {wide_stat["origAccepted"]} originals accepted; every place at every value of the wide list; {wide_stat["accepted"]} accepted changed runs ({wide_stat["certified"]} of them certifiable) plus the originals = 15,895 programs; {wide_cmp[0] if wide_cmp else "?"} against the real runner (node ×2, python ×5, node v22.23.4, Python 3.11.18). The same 15,895 programs run inside the engine runtime (`claude plugin test`, final/enginechk) give 0 differences from node.',
        'adversarial': 'The critic\'s 66 tricky programs (toFixed ties, round-half-even, -0, 1e21, float accumulation, astral characters, Date/random/input, \'%\' formats): 0 mismatches; 24 refused (crit/ev).',
        'reach': 'Sonnet route: 119/250 written whole-file records (js 44.5%, py 52.6%); haiku route: 224/250. A top-up was needed in 4 of 5 sets. Set B ended with 11 js members against 13 measured js slots (the pilot report wrongly said every top-up was enough); hence the larger first budget and clause 19.',
        'devNamesFile': f'{G}/dev/names-113.json',
    },
    'critiqueResolution': [
        '1 (the design text described r0, not r2): ACCEPTED. This file is written for r2: C read, N neither asked nor read, answer = run; the reasons are missing, grammar, other-slot, site and long; a fallback clause; and a rule-6 list of r2 widenings including any newRun edit. The stale comments, the unused \'differs\'/\'run\' reasons (ChangedRead restored to HEAD\'s text; new ChangedRunRead) and the 3 test names are fixed in tree-final. No prompt byte changed (the D/E requests rebuild identically).',
        '2 (the pre-stated stopping rule was loosened, then broken): ACCEPTED as a fact and put to the owner (question 0), recorded for 견본.md. The design text said one revision; GO.json (frozen 18:09, before any call) said three. r2 is presented as the 1.13.0 design reached after two failed pilots, not as a pass of r0. Unlike G1 and G3, r2 was judged only on sets written and frozen after its code (D) plus a held-back confirmation (E) on the unchanged tree, both 40/40. That is the held-back path the G3 critique offered as the honest alternative. Default: measure, and the owner can choose (b).',
        '3 ((나) rests on the evaluator alone, with no runtime check): ACCEPTED. The bar says (나) is model-independent and evaluator-bound (clause 16: no tool-defect excuse). A wide differential gate was run now: 15,895 programs from 686 learner-shaped records, 0 mismatches against real runs, and 0 engine-vs-node differences. A pre-call gate on the frozen samples was added to the bar. B14 extends rule 5 / D26 so that any later newRun edit (for example G3 landing) re-runs the gate and the sonnet frozen proofs, or sonnet G2 turns OFF. The version risk (learners on other node/python versions) is stated in risks.',
        '4 (the fallback lets (가) measure the plugin): ACCEPTED as stance clause 18 (stricter). A fallback slot is a (가) miss and is still graded in (나), counted mechanically by changedRunItem\'s new isOwn. The fallback stays in the product (the learner still gets a correct certified question at the place the model named). Dev recount: one fallback per run, so 19/20 each.',
        '5 (reach claim wrong; the round can come up short): ACCEPTED. The pilot report is corrected (set B: 11 js). The first writer budget is js 50 · py 30 plus one top-up each, then STOP. Clause 19 makes an unfilled slot a (가) miss with no cross-language fill (dev reach gives < 1% chance of a shortfall). The 16/20 line tolerates 4 misses of any kind.',
        '6 (most changes do not touch the concept line): ACCEPTED as a recorded teaching-quality limit, shared with haiku\'s shipped route (sonnet D 9/40, E 14/40 on the quoted line; haiku 4/17–8/18). Not changed: listing only places on the concept line would change the prompt and the scope, needing a fresh dev set, and stance 7 (ㄷ) is unchanged. Recorded as a boundary case and for 다시 잴 때.',
        '7 (odd but correct answers): ACCEPTED as a learner-facing risk. The wording is not changed (owner question 2, default no), because any new wording needs a fresh dev check against the non-deterministic refusal classifier, and the pilot covers the exact bytes. Recorded as a boundary case (B-10).',
        '8 (the mutation record understated coverage): ACCEPTED. All 10 pilot mutants plus 2 new ones (isOwn always true; dropping the loose key) were re-run on tree-final against run113, flow113g2, d34g2, changed112, route and flow110, each file on its own, plus D26 (proofs/mut3/result.txt). d34g2 is named as the in-tree haiku byte guard.',
        '9 (dev judging adds little beyond the runner): ACCEPTED. The pilot record says so. The measured round uses this r2 stance, the tool shows only ⚙ results, and the pair is sealed (sha256 only). \'0 splits\' is not cited as (나) evidence.',
        '10 (cost, privacy, learner view): ACCEPTED. cost.privacy states the O block as a new derived payload, cost.code gives the module size, and what.learnerSees states the exact strings and that answers never end in an error.',
    ],
    'risks': [
        '(나) is evaluator-bound. An evaluator bug on learner code outside the tested corpora would store a wrong 정답 with no runtime check: a learner who writes the true output is graded wrong, and the concept goes to step 0. Mitigation: a closed subset with refusals by default; 15,895 + 6,000 + 384 differential programs with 0 mismatches; engine = node; the pre-call gate; clause 16; B14 for any later newRun edit. The risk is residual and stated.',
        'Version drift: the evaluator matches Node 22 and CPython 3.11 as tested. A learner on another version could see different output for float formatting or dict and str corner cases. The subset (no set printing, no dict/list printing, primitive prints only) keeps this small. Recorded.',
        'Refusal classifier: the r2 wording ran 36 times (and 105 sonnet calls in all) with 0 refusals. The classifier is non-deterministic, so a refusal in the round would cost 2–3 slots per quiz. Tolerance is 4 slots.',
        'Reach: about 48% of whole-file records (haiku 90%). A sonnet learner sees 비슷한 코드 less often; other concepts are asked as 내 코드.',
        'Teaching quality: the changes the model picks often land on data values far from the concept line, and some values are odd but correct (\'수면 -4시간\'). Not a bar issue; recorded.',
        'Procedure: the pilot exceeded the design text\'s one-revision rule (owner question 0). The measured round itself is fresh, blind and committed in advance, so its result is not affected. The risk is only that a round is spent.',
        'Calibration: H_sonnet must be re-measured. A version or alias mismatch voids the round (the cell stays OFF).',
        'A cut reply (1.10.0) did not recur in 105 dev calls. It is kept as a residual risk (it would cost that quiz\'s changed slots).',
        'Build interplay: G5 (sonnet) and G6 (haiku) builds in 1.13.0 must keep G2\'s haiku and sonnet bytes (D26). If G3 lands later, its newRun must be this one, or B14 applies.',
    ],
    'dependsOn': [
        'G3\'s evaluator: newRun/newParse are copied from the 1.13.0 G3 final prototype (impl113/design/G3/final/enginechk/hooks/notes.ts). G3 is do-not-measure in 1.13.0 by default, so G2 sonnet brings the evaluator into the repo itself (owner question 1). If G3 is built later, there must be one shared copy, and B14 applies to any edit.',
        'G2 haiku ON (rungChangedStep 2) shares rungOf, changeSites, isChangedShaped, ladderMixed, quizParts/parseQuiz, changedQuizPrompt, recheckRemap, missedKept and QUIZ_TRACE_TOKENS. Final-tree D26: requests 9/9 identical (D34), build.json identical, read.json 05aa93f5… identical (proofs/final).',
        f'isRuleWide (haiku and sonnet, ON): impl112/d26/rulewide.mjs on tree-final: {rw_tail.replace(chr(10), " ")}',
        'G3 claims the \'b\' marker suffix in new-pick quizzes (quizParts hasSpare). This design does not touch quizParts, and its C grammar uses letters a–f inside a changed slot only.',
        'M-5 calibration on a fresh pinned copy of the installed CLI before the round (H_sonnet re-measured).',
        'No version bump is needed (no NEW_GRADER_SINCE change).',
    ],
    'whatWouldHaveToChange': {
        'haiku': 'Nothing: ON and untouched.',
        'sonnetIfOwnerSaysB': 'Under owner question 0 (b), G2 sonnet is not built or measured in 1.13.0. The tree-final prototype, the dev sets D/E and this file are kept for a later version, where r2 would be judged once on a fresh held-back set against this exact tree and then measured.',
        'sonnetIfRoundFails': 'A failure on (가) that comes from fallbacks or unread slots would need a mechanism that helps sonnet pick values that change the output (e.g. listing for each place only values the plugin has certified), shown on fresh held-back sets. A failure on (나) would mean an evaluator defect: the evaluator would have to be fixed and the whole differential gate re-run before any new design.',
    },
    'recommend': {
        'haiku': 'do-not-measure',
        'sonnet': 'measure',
        'evidence': {
            'haiku': 'Already ON (1.12.0 measured 18/20, 0 wrong). This design keeps every haiku request, pick and reading byte-identical (D26 9/9, build.json, read.json 05aa93f5…; rulewide; OFF bytes). Re-measuring would be a re-roll and is not allowed.',
            'sonnet': 'Records only. Final r2 on two fresh dev sets written after the code was frozen: 20/20 in each of 4 runs (19/20 under clause 18), 0 wrong in 80, 0 refusals, 0 empty or cut replies in 36 calls (105 in all), max 545 tokens. The final tree rebuilds the same requests and items. Wide differential: 15,895 programs with 0 mismatches. Pass chance for a fresh round is high: (가) is lost only to grammar, refusal or fallback slots (dev 1 per 20), and (나) is evaluator-bound. Default subject to owner question 0.',
        },
    },
    'ownerQuestions': [
        '0. 비슷한 코드(G2) sonnet: 파일럿이 설계 글의 \'일반 고침 하나\' 규칙을 넘었습니다(파일럿이 부르기 전에 얼린 GO 파일은 \'세 번까지\'라고 적어 서로 어긋났음). 첫 설계(r0)와 고침 1(r1)은 못 넘었고, 고침 2(r2: 모델은 곳과 새 값만 고르고 답은 플러그인이 기기에서 돌린 결과)는 그 코드를 얼린 뒤 새로 쓴 세트 D와, 고치지 않고 따로 둔 세트 E에서만 판정했습니다. 네 번 모두 20/20(모델이 고른 값만 세면 19/20)이고 틀린 답 0입니다. (a) 기본값: r2를 1.13.0 설계로 보고, 이 어긋남과 \'플러그인이 대신 낸 바꿈은 놓침\' 조항을 기준 커밋에 적은 뒤 sonnet을 한 회 잽니다(새 보정, 새 블라인드 견본, 부르기 전 평가기 대조). (b) G1 · G3처럼 1.13.0에서는 짓지도 재지도 않고 다음 판으로 넘깁니다.',
        '1. ((a)일 때만) 기기에서 코드를 돌리는 평가기(G3 시제품의 newRun, 약 4,160줄)를 G3는 재지 않는데도 G2 sonnet을 위해 저장소에 넣을까요? 기본값: 예 — G3 시제품에서 그대로 옮기고, 값 여럿을 찍는 출력만 더합니다(끈 칸에서는 쓰이지 않음). 아니오면 G2 sonnet은 1.13.0에서 짓지도 재지도 않습니다.',
        '2. ((a)일 때만) 모델에게 \'상황에서 말이 되는 값\'을 고르라는 말을 더할까요? \'수면 -4시간\'처럼 맞지만 어색한 답이 줄 수 있습니다. 기본값: 아니오 — 프롬프트가 바뀌면 파일럿 수가 그 글을 덮지 못하고, 기준 커밋 전에 새 개발 세트로 거절 · 빈 답이 없음을 다시 보여야 합니다. 예면 그 확인을 한 번 하고, 거절 · 빈 답이 하나라도 나오면 지금 글로 잽니다.',
    ],
}

json.dump(design, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('wrote', OUT, os.path.getsize(OUT), 'bytes; stance chars', len(stance_text))
