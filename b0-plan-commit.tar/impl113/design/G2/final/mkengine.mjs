// 1.13.0 G2 final (records only): the wide programs as fixtures for an engine-runtime run of newRun with printArgs.
// usage: mkengine.mjs <notes.ts> <progs.jsonl> <enginechk dir> <chunks>
import { readFileSync, writeFileSync } from 'node:fs'
const [nt, pf, dir, k] = process.argv.slice(2)
const N = await import(nt)
const rows = readFileSync(pf, 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l))
const K = Number(k)
for (let c = 0; c < K; c++) {
  const part = rows.filter((_, i) => i % K === c).map(r => [r.id, r.lang, r.code, N.newRun(r.code, r.lang, { printArgs: true })])
  writeFileSync(`${dir}/tests/fixtures/corpus${c}.ts`, `export const CORPUS: [string, 'js' | 'py', string, unknown][] = ${JSON.stringify(part)}\n`)
  writeFileSync(`${dir}/tests/engine${c}.test.ts`, `import { describe, expect, test } from 'claude-code/testing'
import { newRun } from '../hooks/notes'
import { CORPUS } from './fixtures/corpus${c}'

describe('newRun with printArgs in the engine runtime equals newRun under node, chunk ${c} (records only)', () => {
  test('the same lines or the same refusal', () => {
    const differ: string[] = []
    for (const [id, lang, code, want] of CORPUS) {
      const got = newRun(code, lang, { printArgs: true })
      if (JSON.stringify(got) !== JSON.stringify(want)) differ.push(\`\${id} \${JSON.stringify(got).slice(0, 120)} != \${JSON.stringify(want).slice(0, 120)}\`)
    }
    console.log(\`ENGINECHK chunk ${c} programs \${CORPUS.length} differ \${differ.length}\`)
    for (const d of differ.slice(0, 20)) console.log('ENGINECHK ' + d)
    expect(differ.length).toBe(0)
  }, { timeoutMs: 120000 })
})
`)
}
console.log('rows', rows.length, 'chunks', K)
