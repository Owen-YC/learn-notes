// 1.13.0 G2 final (records only): per sonnet run, slots kept with the model's own value (isOwn) vs a fallback, by tree-final's changedRunItem.
// usage: own.mjs <jtree notes.ts> <build-sonnet.json> <out.json>
import { readFileSync } from 'node:fs'
const [nt, bf, of] = process.argv.slice(2)
const N = await import(nt)
const B = JSON.parse(readFileSync(bf, 'utf8'))
const res = JSON.parse(readFileSync(of, 'utf8')).results
const per = {}
for (const r of res) {
  const [qid, run] = r.id.split('-')
  const q = B.quizzes.find(x => x.id === qid)
  const parts = r.isAnswered ? N.quizParts(r.text, true, 'QHATRCON', 'CON') : new Map()
  const t = (per[run] ??= { own: 0, fallback: 0, unread: 0, list: [] })
  q.picks.forEach((p, i) => {
    if (p.rung !== 'changed') return
    const made = N.changedRunItem(parts, i + 1, p)
    if (!('item' in made)) { t.unread++; return }
    if (made.isOwn) t.own++; else { t.fallback++; t.list.push(`${qid} ${p.name}`) }
  })
}
console.log(JSON.stringify(per))
