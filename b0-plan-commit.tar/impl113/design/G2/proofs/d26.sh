#!/bin/bash
# 1.13.0 G2-RUN prototype: haiku D26/M-13 recheck on a tree. usage: d26.sh <tree> <outdir>
T="$1"; O="$2"; S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad; B=$S/impl112/b2
mkdir -p "$O" || exit 1
# (가) the 9 frozen haiku requests from the tree with no harness row
TREE="$T" python3 "$(dirname "$0")/remake.py" "$B/frozen" "$O/remake" > "$O/ga.txt" 2>&1; echo "exit=$?" >> "$O/ga.txt"
# (나) picks + prompts from the frozen samples via the frozen build tool on this tree
mkdir -p "$O/build"; cp "$B/frozen/samples.json" "$B/frozen/layout.json" "$O/build/"
TREE="$T" node --experimental-transform-types --no-warnings "$B/tools/build.mjs" "$O/build" > "$O/na.log" 2>&1
python3 - "$B/frozen" "$O/build" > "$O/na.txt" <<'PY'
import json, sys, hashlib
a, b = sys.argv[1:3]
for f in ['build.json', 'lines-haiku.jsonl']:
    x = open(f'{a}/{f}','rb').read(); y = open(f'{b}/{f}','rb').read()
    print(f, 'identical' if x == y else 'DIFFER', hashlib.sha256(y).hexdigest()[:12])
PY
# (다) the frozen haiku answers re-read with this tree
mkdir -p "$O/jtree/hooks"; cp "$T/hooks/register.tsx" "$O/jtree/hooks/"; cp -r "$T/types" "$O/jtree/" 2>/dev/null
sed -e 's/^function shownCode(/export function shownCode(/' -e 's/^function codeTokens(/export function codeTokens(/' -e 's/^function codeAsRead(/export function codeAsRead(/' -e 's/^function quizParts(/export function quizParts(/' "$T/hooks/notes.ts" > "$O/jtree/hooks/notes.ts"
rm -f "$O/read.json"
NOTES="$T/hooks/notes.ts" JNOTES="$O/jtree/hooks/notes.ts" node --experimental-transform-types --no-warnings "$B/tools/read.mjs" "$B/stage/quiz/haiku" "$B/frozen" "$O/read.json" > "$O/da.log" 2>&1
echo "read.json $(sha256sum < "$O/read.json" | cut -c1-64) want 05aa93f5e111474233a0971316c4768d3475d1a92733181d001f7ec2b30ca2f1" > "$O/da.txt"
cat "$O/ga.txt" "$O/na.txt" "$O/da.txt"
