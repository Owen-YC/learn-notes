"""Mutation probes on the r2 prototype tree (records): each mutant must be caught by the tests (or, run-without-flag, by D26)."""
import sys, shutil
G = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G2'
MUTS = {
 'skip-own-cert': ('hooks/notes.ts', "return 'lines' in ran && isCertified(ran.lines, run.out) ? { changedLine, changed, lines: ran.lines } : undefined", "return 'lines' in ran ? { changedLine, changed, lines: ran.lines } : undefined"),
 'store-model-N': ('hooks/notes.ts', "      answer: use.lines.join('\\n'),", "      answer: (parts.get(`N${n}`) ?? use.lines).join('\\n').trim(),"),
 'no-fallback': ('hooks/notes.ts', "  const use = own ?? cert\n", "  if (!own) return { reason: 'value' }\n  const use = own\n"),
 'allow-decimal-own': ('hooks/notes.ts', "(site.kind === 'number' && (!/^\\d+$/.test(said) || Number(said) > numberBound(site.token)))", "(site.kind === 'number' && Number(said) > numberBound(site.token))"),
 'drop-certs-2': ('hooks/notes.ts', "(how.code.run?.certs.length ?? 0) >= 2", "(how.code.run?.certs.length ?? 0) >= 0"),
 'drop-subset': ('hooks/notes.ts', "    if (o.some((_, at) => at + n.length <= o.length && n.every((line, i) => line === o[at + i]))) return false\n    if (n.every((line, i) => i < o.length && line === o[i])) return false\n  }\n  return true", "  }\n  return true"),
 'allow-container': ('hooks/notes.ts', "  throw new Refuse('print-value', 'print of an object')\n}\n/** console.log of two", "  return String(v)\n}\n/** console.log of two"),
 'allow-format': ('hooks/notes.ts', "  if (typeof args[0] === 'string' && args[0].includes('%')) throw new Refuse('print-value', 'print of a format')\n", ""),
 'allow-decimal': ('hooks/notes.ts', "    if (!/^\\d+$/.test(site.token)) return []\n    const n = Number(site.token)", "    const n = Number(site.token)"),
 'isown-always': ('hooks/notes.ts', "    isOwn: own !== undefined,", "    isOwn: true,"),
 'drop-loose-key': ('hooks/notes.ts', "  for (const key of [outputSame, looseSame]) {", "  for (const key of [outputSame]) {"),
 'run-without-flag': ('hooks/register.tsx', "const run = isWhole && changedRun ? changedRunFor", "const run = isWhole ? changedRunFor"),
}
name = sys.argv[1]
f, a, b = MUTS[name]
d = f'{G}/proofs/mut3/{name}'
shutil.rmtree(d, ignore_errors=True)
shutil.copytree(f'{G}/proto/tree-final', d, ignore=shutil.ignore_patterns('.git'))
t = open(f'{d}/{f}').read(); assert t.count(a) == 1, name
open(f'{d}/{f}', 'w').write(t.replace(a, b))
print('mutated', name)
