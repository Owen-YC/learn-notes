#!/bin/bash
# 1.13.0 G2 final: each mutant of tree-final against run113, flow113g2, d34g2, changed112 and route together (failing test names show the file), flow110 for the routing mutants, plus D26 (ga).
G=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G2; M=$G/proofs/mut3
: > $M/result.txt
for m in skip-own-cert store-model-N no-fallback allow-decimal-own drop-certs-2 drop-subset allow-container allow-format allow-decimal isown-always drop-loose-key run-without-flag; do
  python3 $M/muts3.py $m > /dev/null || { echo "== $m APPLY-FAILED" >> $M/result.txt; continue; }
  echo "== $m" >> $M/result.txt
  bash $G/proto/quick.sh $M/$m $M/q-$m run113.test.ts flow113g2.test.ts d34g2.test.ts changed112.test.ts route.test.ts | grep -E "^\(fail\)| fail$" | sed 's/ \[[0-9.]*ms\]//' | cut -c1-160 >> $M/result.txt
  rm -rf "${M:?}/q-$m"
  case $m in run-without-flag|drop-certs-2|isown-always) r=$(bash $G/proto/quick.sh $M/$m $M/q-$m-f110 flow110.test.ts | grep -E "^ [0-9]+ fail$"); echo "  flow110: ${r:- (none)}" >> $M/result.txt; rm -rf "${M:?}/q-$m-f110";; esac
  bash $G/proofs/d26.sh $M/$m $M/d26-$m 2>&1 | head -1 | sed 's/^/  d26 (ga): /' >> $M/result.txt
done
echo DONE >> $M/result.txt
echo mut-done > $G/final/chain.mut
