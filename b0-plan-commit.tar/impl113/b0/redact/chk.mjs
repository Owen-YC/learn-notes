import fs from 'node:fs'
const [,, notes, promptFile, linesA, linesB] = process.argv
const m = await import(notes)
const prompt = fs.readFileSync(promptFile, 'utf8')
const r = m.redactText(prompt)
const out = { hits: r.hits, equalPrompt: r.text === prompt }
for (const f of [linesA, linesB]) {
  const ls = fs.readFileSync(f, 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l))
  out[f.split('/').pop()] = ls.map(l => l.prompt === r.text)
}
console.log(JSON.stringify(out))
