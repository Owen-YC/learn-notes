Write records. See hm.py and the haiku notes.
