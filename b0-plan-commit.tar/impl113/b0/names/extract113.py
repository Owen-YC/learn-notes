#!/usr/bin/env python3
"""Re-extract every 1.13.0 design-pilot DEV name and check it against impl113/NAMES-all.txt
(learn-notes 1.13.0, plan calibration.namesRegistry verify (2)). Model calls: none.

usage: python3 -I extract113.py <NAMES-all.txt> [--append] [--gyeonbon <docs/qa/견본.md>]

Field rules (the impl112/names/build.py rules, applied to the 1.13.0 dev sources):
  record files (JSON): in every record (a dict holding 'id' or 'name', found through lists and set dicts)
    its 'name' / 'concept' (sample/concept names), its 'file' and each 'files'[*].'path' (file paths);
    nested data inside a record (mock responses, questions) is not walked. Ids are not names (impl112 build.py took ids only from
    NAMES.txt 'ids' lines; the registry holds none for 1.13.0).
  name lists: G1 dev/NAMES.txt columns 2-3 (tab form); G5/G6 names.txt / NAMES.txt one name per line;
    G4 dev/NAMES.txt column 1 (registry form); G2 dev/names-113.json (a list of names).
  raw writer outputs (G4 X*.raw): the JSON inside the fence, as record files; if it does not parse, the
    '"name": "…"' and '"file": "…"' strings.
  avoid lists the 1.13.0 writers saw (G1 dev/gen/avoid-names.txt, G4 dev/tools/allnames.txt): checked
    for presence under any tag (they were made from the earlier registries), never re-tagged.
A record name or file is 'present' when the registry holds it (a file also when it holds its last path
part) with tag <G>-dev-113; a name-list or avoid-list entry is present under any tag (a path also by its
last part); the literal 'None' (an empty NAMES.txt column) is not a name. With --append,
each missing name is appended as '<name> TAB <G>-dev-113 TAB <source>' (source relative to the scratchpad).
With --gyeonbon, verify (3) as well: every name impl112/names/extract.py (sha256 c8ddab80…81eb, checked)
prints for that 견본.md must have a row with tag '견본'; a missing one is appended (with --append) as
'<name> TAB 견본 TAB learn-notes/docs/qa/견본.md', the impl112 build.py form.
Prints a JSON summary: per source the extracted count and the missing count; total appended.
"""
import glob, json, os, re, sys, unicodedata

SP = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad'
D = SP + '/impl113/design'


def clean(s):
    s = unicodedata.normalize('NFC', s).replace('\t', ' ').strip()
    return re.sub(r'\s+', ' ', s)


def walk(o, names, files, depth=0):
    """Record-level fields only: a record is a dict that holds 'id' (or 'name') at any nesting of lists and
    set dicts; inside a record only its own 'name'/'concept', 'file', and 'files'[*].'path' count (nested
    data such as mock responses is not a sample name)."""
    if isinstance(o, list):
        for v in o:
            walk(v, names, files, depth)
    elif isinstance(o, dict):
        if 'id' in o or 'name' in o:
            for k in ('name', 'concept'):
                if isinstance(o.get(k), str):
                    names.add(clean(o[k]))
            if isinstance(o.get('file'), str):
                files.add(clean(o['file']))
            for f in o.get('files') or []:
                if isinstance(f, dict) and isinstance(f.get('path'), str):
                    files.add(clean(f['path']))
        else:
            for v in o.values():
                walk(v, names, files, depth + 1)


def record_file(p):
    names, files = set(), set()
    text = open(p, encoding='utf-8').read()
    try:
        if p.endswith('.raw'):
            m = re.search(r'```(?:json)?\s*\n(.*?)```', text, re.S)
            text = m.group(1) if m else text
        walk(json.loads(text), names, files)
    except Exception:
        for m in re.finditer(r'"name"\s*:\s*"((?:[^"\\]|\\.)*)"', text):
            names.add(clean(json.loads('"' + m.group(1) + '"')))
        for m in re.finditer(r'"(?:file|path)"\s*:\s*"((?:[^"\\]|\\.)*)"', text):
            files.add(clean(json.loads('"' + m.group(1) + '"')))
    return {x for x in names if x}, {x for x in files if x}


def lines_of(p, cols=None):
    out = set()
    for line in open(p, encoding='utf-8').read().split('\n'):
        if not line.strip() or line.startswith('#'):
            continue
        parts = line.split('\t')
        for c in (cols if cols is not None else range(len(parts))):
            if c < len(parts) and clean(parts[c]) and clean(parts[c]) != 'None':
                out.add(clean(parts[c]))
    return out


def main():
    reg_path = sys.argv[1]
    append = '--append' in sys.argv[2:]
    rows = [l.split('\t') for l in open(reg_path, encoding='utf-8').read().split('\n') if l]
    by_name = {}
    for r in rows:
        by_name.setdefault(r[0], set()).add(r[1])

    jobs = []  # (G, source path, kind, set of (name, isFile))
    def rec(g, pattern):
        for p in sorted(glob.glob(D + '/' + pattern)):
            n, f = record_file(p)
            jobs.append((g, p, 'record', [(x, False) for x in sorted(n)] + [(x, True) for x in sorted(f)]))
    def lst(g, p, kind, cols=None):
        if os.path.exists(p):
            jobs.append((g, p, kind, [(x, False) for x in sorted(lines_of(p, cols))]))
        else:
            jobs.append((g, p, 'absent', []))

    rec('G1', 'G1/dev/set[1-4]/records.json')
    lst('G1', D + '/G1/dev/NAMES.txt', 'list', (1, 2))
    lst('G1', D + '/G1/dev/gen/avoid-names.txt', 'avoid')
    rec('G2', 'G2/dev/set[A-E]/parts/*/reply.json')
    p = D + '/G2/dev/names-113.json'
    jobs.append(('G2', p, 'list', [(clean(x), False) for x in json.load(open(p, encoding='utf-8')) if clean(x)]))
    rec('G3', 'G3/dev/set[3-6]/samples.json')
    rec('G4', 'G4/dev/set[1-2]/fixture.json')
    rec('G4', 'G4/dev/set[1-2]/X*.raw')
    lst('G4', D + '/G4/dev/NAMES.txt', 'list', (0,))
    lst('G4', D + '/G4/dev/tools/allnames.txt', 'avoid')
    rec('G5', 'G5/dev/set[1-3]/changes.json')
    for s in (1, 2, 3):
        lst('G5', D + f'/G5/dev/set{s}/NAMES.txt', 'list')
    rec('G5', 'G5/pilot/set[1-3]/texts-*.json')
    rec('G6', 'G6/dev/set[1-2]/frozen/samples.json')
    for s in (1, 2):
        lst('G6', D + f'/G6/dev/set{s}/names.txt', 'list')

    summary, new = [], []
    seen_new = set()
    for g, p, kind, items in jobs:
        tag = g + '-dev-113'
        miss = []
        for name, is_file in items:
            tags = by_name.get(name, set())
            if kind == 'record':
                ok = tag in tags or (is_file and tag in by_name.get(name.rsplit('/', 1)[-1], set()))
            else:
                ok = bool(tags) or bool(by_name.get(name.rsplit('/', 1)[-1]))
            if not ok:
                miss.append(name)
                key = (name, tag)
                if key not in seen_new:
                    seen_new.add(key)
                    new.append(f'{name}\t{tag}\t{os.path.relpath(p, SP)}')
        summary.append({'G': g, 'source': os.path.relpath(p, SP), 'kind': kind, 'extracted': len(items),
                        'missing': len(miss), 'missingNames': miss[:20]})
    gb_new = []
    if '--gyeonbon' in sys.argv:
        import hashlib, subprocess
        ex = SP + '/impl112/names/extract.py'
        assert hashlib.sha256(open(ex, 'rb').read()).hexdigest() == 'c8ddab809c9e1e9502ac6a629cdacb55094447f5206797b2c1df8582b67b81eb', 'extract.py sha256'
        src = sys.argv[sys.argv.index('--gyeonbon') + 1]
        out = subprocess.run([sys.executable, '-I', ex, src], check=True, capture_output=True).stdout.decode('utf-8')
        for w in out.split('\n'):
            w = clean(w)
            if w and '견본' not in by_name.get(w, set()):
                gb_new.append(f'{w}\t견본\tlearn-notes/docs/qa/견본.md')
        summary.append({'G': '견본', 'source': 'learn-notes/docs/qa/견본.md', 'kind': 'gyeonbon',
                        'extracted': len([w for w in out.split('\n') if w]), 'missing': len(gb_new), 'missingNames': [x.split('\t')[0] for x in gb_new[:20]]})
        new += gb_new
    if append and new:
        with open(reg_path, 'ab') as f:
            for l in new:
                f.write(l.encode('utf-8') + b'\n')
    print(json.dumps({'sources': len(jobs), 'extracted': sum(len(j[3]) for j in jobs),
                      'missingLines': len(new), 'appended': len(new) if append else 0,
                      'perSource': [s for s in summary if s['missing'] or s['kind'] == 'absent'],
                      'perSourceAll': [[s['source'], s['kind'], s['extracted'], s['missing']] for s in summary]},
                     ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()
