"""Writes the calling file of one alias: three lines, maxTokens 64 · 128 · 256, the frozen fixed prompt inline,
system '' and timeoutMs 90000 (as the 1.10.0 calibration record states)."""
import json, sys

alias, prompt_path, out = sys.argv[1], sys.argv[2], sys.argv[3]
prompt = open(prompt_path, encoding="utf-8").read()
with open(out, "w", encoding="utf-8") as f:
    for cap in (64, 128, 256):
        f.write(json.dumps({"id": f"{alias}-{cap}", "model": alias, "system": "", "prompt": prompt, "maxTokens": cap, "timeoutMs": 90000}, ensure_ascii=False) + "\n")
