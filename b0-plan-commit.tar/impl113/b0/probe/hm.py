"""G7 M-5, as written: for one alias, the three calls at maxTokens 64 · 128 · 256; d = output_tokens − maxTokens.
If every one of the three has a d (the model replied: answered or empty-reply, with its usage) and max − min ≤ 2,
H = min. Otherwise the three once more (round 2); if that round is not so either, H = 0.
usage: hm.py <alias> <round1 out.json> [<round2 out.json>]"""
import json, sys

alias, rounds = sys.argv[1], sys.argv[2:]
CAPS = (64, 128, 256)

def ds(path):
    res = json.load(open(path, encoding="utf-8"))["results"]
    by = {}
    for r in res:
        if r.get("model") != alias:
            raise SystemExit(f"line of another alias in {path}: {r.get('model')}")
        by[r["maxTokens"]] = r
    row = {}
    for cap in CAPS:
        r = by.get(cap)
        replied = r is not None and "threw" not in r and (r.get("isAnswered") is True or r.get("reason") == "empty-reply")
        out = r["usage"]["output_tokens"] if replied else None
        row[cap] = {"output_tokens": out, "d": (out - cap) if out is not None else None,
                    "how": None if r is None else ("threw" if "threw" in r else ("answered" if r.get("isAnswered") else r.get("reason")))}
    return row

verdict = None
table = []
for n, path in enumerate(rounds, 1):
    row = ds(path)
    d = [row[c]["d"] for c in CAPS]
    whole = all(x is not None for x in d)
    spread = (max(d) - min(d)) if whole else None
    ok = whole and spread <= 2
    table.append({"round": n, "row": row, "spread": spread, "settled": ok})
    if ok:
        verdict = {"H": min(d), "by": f"round {n}: three d, max - min = {spread} <= 2, H = min"}
        break
    if n == 2:
        verdict = {"H": 0, "by": "round 1 and round 2 both split (or a d missing): H = 0"}
        break
if verdict is None:
    verdict = {"H": None, "by": "round 1 split (or a d missing): call the three once more (round 2)"}
print(json.dumps({"alias": alias, "rounds": table, "verdict": verdict}, ensure_ascii=False, indent=1))
