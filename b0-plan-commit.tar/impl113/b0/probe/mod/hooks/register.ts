// learn-notes 1.11.0 calibration probe (G7 M-5, D20): calls $.model.complete exactly as the plugin's askModel does
// (the setting string as the model, effort low, system as given, prompt through notes.ts redactText, maxTokens,
// timeoutMs), 4 at a time, times each call with $.clock, passes replies through fixEscapedTicks, and writes one
// JSON file. It reads its lines from a JSONL file: { id, model, system, prompt, maxTokens, timeoutMs } per line.
import type { Register } from 'claude-code'
import { fixEscapedTicks, redactText } from './notes'

type Line = { id: string; model: string; system: string; prompt: string; maxTokens: number; timeoutMs: number }

const BATCH = 4

export const register: Register = (on) => {
  on('session.start', async ($, e, next) => {
    await $.command.register({ name: 'g7probe', description: 'learn-notes 1.11.0 calibration probe', argumentHint: '<lines.jsonl> <out.json>' })
    return next(e)
  })

  on('command.run', { command: 'g7probe' }, async ($, e) => {
    const [linesPath, outPath] = e.args.trim().split(/\s+/)
    if (!linesPath || !outPath) return { text: 'G7PROBE usage: /g7probe <lines.jsonl> <out.json>' }
    const lines = (await $.fs.read(linesPath))
      .split('\n')
      .filter(line => line.trim() !== '')
      .map(line => JSON.parse(line) as Line)
    const probeStartedAt = await $.clock.now()
    const results: unknown[] = []
    for (let i = 0; i < lines.length; i += BATCH) {
      const batch = lines.slice(i, i + BATCH)
      const done = await Promise.all(
        batch.map(async line => {
          const { text: prompt, hits } = redactText(line.prompt)
          const startedAt = await $.clock.now()
          try {
            const reply = await $.model.complete({
              model: line.model,
              effort: 'low',
              system: line.system,
              prompt,
              maxTokens: line.maxTokens,
              timeoutMs: line.timeoutMs,
            })
            const endedAt = await $.clock.now()
            const base = { id: line.id, model: line.model, maxTokens: line.maxTokens, timeoutMs: line.timeoutMs, redactHits: hits, startedAt, endedAt, ms: endedAt - startedAt, usage: reply.usage }
            if (reply.isAnswered) {
              const text = fixEscapedTicks(reply.text)
              return { ...base, isAnswered: true, chars: text.length, text }
            }
            if (reply.reason === 'api-error') return { ...base, isAnswered: false, reason: reply.reason, status: reply.status, error: reply.error }
            return { ...base, isAnswered: false, reason: reply.reason }
          } catch (err) {
            const endedAt = await $.clock.now()
            return { id: line.id, model: line.model, maxTokens: line.maxTokens, timeoutMs: line.timeoutMs, redactHits: hits, startedAt, endedAt, ms: endedAt - startedAt, threw: String(err).slice(0, 300) }
          }
        }),
      )
      results.push(...done)
    }
    const probeEndedAt = await $.clock.now()
    await $.fs.write(outPath, JSON.stringify({ linesPath, probeStartedAt, probeEndedAt, results }, null, 2) + '\n')
    const status = results.map(one => {
      const r = one as { id: string; isAnswered?: boolean; reason?: string; threw?: string; usage?: { output_tokens: number }; ms: number }
      const how = r.threw !== undefined ? 'threw' : r.isAnswered ? 'answered' : r.reason
      return `${r.id}:${how}:${r.usage?.output_tokens ?? '-'}:${r.ms}ms`
    })
    return { text: `G7PROBE done ${results.length} ${status.join(' ')}` }
  })
}
