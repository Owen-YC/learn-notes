#!/bin/bash
# usage: call.sh <round-label> <alias> <lines.jsonl>
# One probe session with the round's alias: claude --version before, then the turns 'ok' (front record),
# '/g7probe <lines> <out>' (the calls), 'ok' (back record), then claude --version after.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b0
L="$1"; A="$2"; LINES="$3"
O="${S:?}/calib/rounds/$L"; mkdir -p "$O"
[ -e "$O/out.json" ] && { echo "refuse: $O/out.json exists (one round per label)"; exit 1; }
cd "${S:?}/work" || exit 1
DISABLE_AUTOUPDATER=1 claude --version > "$O/version-before.txt" 2>&1
date -u +%FT%TZ > "$O/started.txt"
python3 -I - "$LINES" "$O/out.json" > "$O/input.jsonl" <<'PY'
import json, sys
lines, out = sys.argv[1], sys.argv[2]
for text in ("ok", f"/g7probe {lines} {out}", "ok"):
    print(json.dumps({"type": "user", "message": {"role": "user", "content": text}}, ensure_ascii=False))
PY
DISABLE_AUTOUPDATER=1 timeout 900 claude -p --model "$A" --tools '' --plugin-dir "${S:?}/probe/mod" --input-format stream-json --output-format stream-json --verbose --debug-file "$O/debug.log" < "$O/input.jsonl" > "$O/stream.jsonl" 2> "$O/err.txt"
echo "exit=$?" > "$O/exit.txt"
date -u +%FT%TZ > "$O/ended.txt"
DISABLE_AUTOUPDATER=1 claude --version > "$O/version-after.txt" 2>&1
python3 -I "${S:?}/probe/record.py" "$O"
