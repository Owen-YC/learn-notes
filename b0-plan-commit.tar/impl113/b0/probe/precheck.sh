#!/bin/bash
# usage: precheck.sh <label> <alias>
# One 'ok' session with the alias, before a round: claude --version, the stream's system/init model, the result's
# modelUsage keys and every rate_limit_event (7-day usage). No mod, no tools.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b0
L="$1"; A="$2"
O="${S:?}/calib/pre/$L"; mkdir -p "$O"
cd "${S:?}/work" || exit 1
DISABLE_AUTOUPDATER=1 claude --version > "$O/version.txt" 2>&1
date -u +%FT%TZ > "$O/started.txt"
DISABLE_AUTOUPDATER=1 timeout 180 claude -p --model "$A" --tools '' --output-format stream-json --verbose ok < /dev/null > "$O/stream.jsonl" 2> "$O/err.txt"
echo "exit=$?" > "$O/exit.txt"
date -u +%FT%TZ > "$O/ended.txt"
python3 -I "${S:?}/probe/record.py" "$O"
