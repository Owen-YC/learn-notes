# learn-notes 1.13.0 — working scope (written 2026-11-18)

Repo: /home/user/learn-notes (git main). Released: 1.11.0 (de98243), 1.12.0 (30adc2f = origin/main = HEAD at the start of 1.13.0; release published 2026-11-16).
Goal (owner, after the 1.12.0 release: "릴리스 만들었어, 이어서 해줘 멈추지마"): every (feature, model) cell still OFF gets a SUBSTANTIVELY NEW design (new versus 1.10/1.11 AND versus the 1.12.0 design in impl112/design/<id>.json), piloted on dev samples; one measured round per (design, model) where the design shows a real chance; a cell ships ON only if that round passes its committed bar.

BINDING TEXT: read /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/SCOPE.md in full (owner rules, conventions, measurement protocol, the sonnet no-written-trace fact, every dated note and batch lesson: pair never revealed before opening; avoid lists of names only, no 견본.md prose; tests deleted by scripted rewrites must be listed; backup tar sha256 in 견본.md; never `while pgrep -f`; detached runners; usage gate; container restarts keep disk but suspend when the session idles; the G3 writer STOP and its cause: one writer call of 68 records + ~2,000 avoid concepts tripped the safety classifier — split writers ≤10 records per call). Read every "1.12.0" there as "1.13.0" where it names the current version. Also read impl112/plan112.json (structure of a plan) and docs/qa/견본.md's 1.12.0 section (the outcomes below and every '다시 잴 때').

## State at the start of 1.13.0
- ON: isRuleWide (팀 규칙 표지 넓힘) haiku + sonnet; G2 비슷한 코드 rungChangedStep 2 haiku only (measured 18/20, bar 16; 0 wrong). Both beginner only, off under alias/provider/gateway env vars or modelOverrides or unreadable.
- OFF with 1.12.0 outcomes (견본.md 1.12.0 section has numbers and '다시 잴 때'):
  - G6 isRuleDrill 팀 규칙 연습: measured both; haiku failed ONE zero-tolerance line (N2: one broken answer graded correct, both runs); sonnet failed ONE zero-tolerance line (one note wrote two task lines, round A). Every other line passed (correct practice 89–96%, bar 80%).
  - G3 rungNewStep 처음 보는 코드: haiku measured on retry, Q1 26/30 (bar 29; 27–28 → second set); losses: 2 sample-name issues, 1 shown code crashed, 1 too many code lines rejected by the reader. Q2, Q3 passed. Sonnet not measured (dev 28/30 · 26/30, 1 wrong in 55).
  - G5 isThinkAsked 생각해 보기: sonnet NO-GO at the pre-bar gate (usable lines 4/8, gate 7/8: code scope dropped Math.round / round( / tuple-unpacked names; thinkKept rejected a keyword-argument call line). Haiku not measured (questions 16–17/18 in five pilots).
  - G1 풀이 보고 풀기: designed only (1.12.0 pilot set 4: haiku 15·22·23, sonnet 16·20·22 vs 22·23·23 on 24).
  - G4 바탕 개념: tied to G1's code branch on that model (R3/M-13/D9).
  - G2 sonnet: not measured (dev 5 wrong of 143; bar 0 wrong). Its design must keep every G2 haiku measured request, pick and reading byte-identical (else G2 haiku turns OFF).
- Installed Claude Code is now 2.1.327 (1.12.0 measured with a pinned 2.1.323 copy at impl112/cli/2.1.323). 1.13.0 calibrates again before its first measured round (M-5) on a fresh pinned copy of the then-installed version; that record is the before-record of every 1.13.0 round.

## Conventions (1.13.0)
- Scratch only under /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/ . Commit messages `learn-notes 1.13.0 (k/N): <짧은 한국어 요약>`, Korean bullets, blank line, then exactly:
  Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
  Claude-Session: https://claude.ai/code/session_019u8s2pttwUY2v21k1Zwy4Q
- Everything else as impl112/SCOPE.md (never push from agents; main loop backs up to backup-1.13.0-wip and backup-1.13.0-frozen; gates tsc/validate/test; no model ids outside 견본.md sample records).
- Design-time pilots allowed as records only (B-12); dev names go into impl112/NAMES-all.txt (copy to impl113/NAMES-all.txt at the start) tagged '<G>-dev-113'.
- 2026-11-18 08:0x UTC: 1.13.0 design started: wf_3083f77e-116 {ids:[G6,G3,G2]} and wf_28c9aae7-2c3 {ids:[G5,G1,G4]} (wf-113-design.js, out impl113/design/). Usage at start: 5h 0.02, 7d 0.02.
- 2026-11-20 14:55 UTC: resumed both design runs after the 5-hour limit (installed claude now 2.1.329). Done: G5 (sonnet measure), G6 (haiku measure), G1.
- 15:16 UTC container restart; both design runs resumed again.
- 2026-11-20 21:33 UTC: all six 1.13.0 designs done. recommend: G6 haiku measure / sonnet no; G5 sonnet measure (fresh GO gate first) / haiku no; G2 sonnet measure (r2: model picks place+value, the plugin's device run is the answer; pilot went past the one-refinement rule — owner question 0, default (a) measure, with that deviation and the fallback-counts-as-miss clause written in the bar commit) / haiku stays ON untouched; G1, G3, G4 both no. Owner questions are answered with their defaults (owner: "이어서 해줘 멈추지마"). Next: wf-113-plan.js → impl113/plan113.json, then wf-113-batch.js batch 0.
- 2026-11-20 22:17 UTC: plan113.json final (wf_4dcb8db1-e60). Batch 0 started: wf_0c4a80a2-efb (wf-113-batch.js {batch:0,attempt:1}). Backups: impl113/push-frozen.sh, worktree impl113/frozen-branch (backup-1.13.0-frozen); repo commits → backup-1.13.0-wip.
