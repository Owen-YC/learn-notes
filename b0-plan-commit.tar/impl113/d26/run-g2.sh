#!/bin/bash
H=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/d26
export DISABLE_AUTOUPDATER=1
cd "${H:?}"
date -u +%FT%TZ > g2-STARTED
./g2haiku.sh "$H/base-repo" "$H/out-g2-baseline" > g2-baseline.log 2>&1; echo $? > g2-baseline.exit
date -u +%FT%TZ > g2-DONE
