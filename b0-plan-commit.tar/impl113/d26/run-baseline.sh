#!/bin/bash
# batch 0 D26 tool baselines (0 model calls): rulewide113 on a 30adc2f copy, then the two-run synthetic test,
# both with --extra impl112/b1/audit/d26x/extra.json (plan d26Procedure.isRuleWide).
D=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/d26
X=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1/audit/d26x/extra.json
export DISABLE_AUTOUPDATER=1
cd "${D:?}"
date -u +%FT%TZ > rw-STARTED
node --experimental-transform-types --no-warnings rulewide113.mjs "$D/base-repo" "$D/out-baseline" --extra "$X" > rw-baseline.log 2> rw-baseline.err; echo $? > rw-baseline.exit
node --experimental-transform-types --no-warnings rulewide113.mjs "$D/syn2-repo" "$D/out-syn2" --extra "$X" > rw-syn2.log 2> rw-syn2.err; echo $? > rw-syn2.exit
date -u +%FT%TZ > rw-DONE
