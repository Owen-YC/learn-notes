#!/bin/bash
# learn-notes 1.13.0 D26 recheck of the shipped G2 rungChangedStep haiku cell (plan commonPerBatch.d26Procedure.g2Haiku).
# A copy of impl113/design/G2/proofs/d26.sh (06ec2abc…) with: impl113 paths (remake.py = impl113/d26/remake.py, the
# 1.13.0 pin); a fresh copy of the batch working tree; TREE=, NOTES= and JNOTES= all pointing at that copy and its jtree
# (the jtree copies every hooks/*.ts|tsx and applies the four export seds to notes.ts); a fresh output directory
# (build.mjs refuses an existing build.json); a refusal when TREE, NOTES or JNOTES is unset or points outside the
# output dir; and every line naming the tree path the tool imported (kit.mjs TREE, read.mjs NOTES/JNOTES). The frozen
# impl112/b2/tools/build.mjs and read.mjs are used unchanged (their impl112/b2/mtree and jtree defaults are always
# overridden). Model calls: none (the plugin test harness answers).
# usage: g2haiku.sh <batch working tree (repo dir)> <fresh out dir>
# (가) the 9 frozen requests, remade with haiku's shipped row and no harness = impl112/b2/frozen/lines-haiku.jsonl 876c8efd…
# (나) picks rebuilt from frozen samples.json + layout.json = build.json 0db255b4…
# (다) the frozen haiku answers re-read with the batch tree = impl112/b2/judge/B/read.json 05aa93f5…
R="$1"; O="$2"
SP=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad; B=$SP/impl112/b2; H=$SP/impl113/d26
export DISABLE_AUTOUPDATER=1
[ -n "$R" ] && [ -f "$R/hooks/notes.ts" ] || { echo "refuse: no batch tree ($R)"; exit 2; }
[ -n "$O" ] || { echo "refuse: no out dir"; exit 2; }
[ -e "$O" ] && { echo "refuse: $O exists (fresh out dir only)"; exit 2; }
mkdir -p "$O/tree/tests" || exit 1
O="$(cd "$O" && pwd)"
for x in hooks types .claude-plugin; do cp -r "$R/$x" "$O/tree/$x"; done
cp "$R/tsconfig.json" "$O/tree/"; cp "$R/tests/flowkit.ts" "$O/tree/tests/"; cp -r "$R/tests/fixtures" "$O/tree/tests/fixtures"
[ -e "$R/node_modules" ] && ln -s "$R/node_modules" "$O/tree/node_modules"
mkdir -p "$O/jtree/hooks"; cp "$O/tree/hooks/"*.ts "$O/tree/hooks/"*.tsx "$O/jtree/hooks/" 2>/dev/null; cp -r "$O/tree/types" "$O/jtree/" 2>/dev/null
sed -e 's/^function shownCode(/export function shownCode(/' -e 's/^function codeTokens(/export function codeTokens(/' -e 's/^function codeAsRead(/export function codeAsRead(/' -e 's/^function quizParts(/export function quizParts(/' "$O/tree/hooks/notes.ts" > "$O/jtree/hooks/notes.ts"
export TREE="$O/tree" NOTES="$O/tree/hooks/notes.ts" JNOTES="$O/jtree/hooks/notes.ts"
for v in TREE NOTES JNOTES; do
  val="${!v}"
  [ -n "$val" ] || { echo "refuse: $v unset"; exit 3; }
  case "$val" in "$O"/*) ;; *) echo "refuse: $v=$val is not under $O"; exit 3;; esac
  case "$val" in *impl112*) echo "refuse: $v=$val is an impl112 tree"; exit 3;; esac
done
KIT=$(node --experimental-transform-types --no-warnings -e "import('$B/tools/kit.mjs').then(m => console.log(m.TREE))" 2>/dev/null | tail -1)
echo "imported: kit.mjs TREE=$KIT · read.mjs NOTES=$NOTES · JNOTES=$JNOTES · remake TREE=$TREE" > "$O/imported.txt"
[ "$KIT" = "$TREE" ] || { echo "refuse: kit.mjs imported $KIT, not $TREE"; cat "$O/imported.txt"; exit 3; }
# (가)
python3 -I "$H/remake.py" "$B/frozen" "$O/remake" > "$O/ga.txt" 2>&1; echo "exit=$?" >> "$O/ga.txt"
# (나)
mkdir -p "$O/build"; cp "$B/frozen/samples.json" "$B/frozen/layout.json" "$O/build/"
node --experimental-transform-types --no-warnings "$B/tools/build.mjs" "$O/build" > "$O/na.log" 2>&1
python3 -I - "$B/frozen" "$O/build" > "$O/na.txt" <<'PY'
import json, sys, hashlib
a, b = sys.argv[1:3]
for f in ['build.json', 'lines-haiku.jsonl']:
    x = open(f'{a}/{f}','rb').read()
    try:
        y = open(f'{b}/{f}','rb').read()
    except OSError:
        print(f, 'MISSING'); continue
    print(f, 'identical' if x == y else 'DIFFER', hashlib.sha256(y).hexdigest()[:12])
PY
# (다)
node --experimental-transform-types --no-warnings "$B/tools/read.mjs" "$B/stage/quiz/haiku" "$B/frozen" "$O/read.json" > "$O/da.log" 2>&1
echo "read.json $(sha256sum < "$O/read.json" | cut -c1-64) want 05aa93f5e111474233a0971316c4768d3475d1a92733181d001f7ec2b30ca2f1" > "$O/da.txt"
cat "$O/imported.txt" "$O/ga.txt" "$O/na.txt" "$O/da.txt"
