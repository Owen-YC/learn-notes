// learn-notes 1.12.0 D26 recheck of the shipped isRuleWide cells (plan commonPerBatch.d26Procedure.isRuleWideSpecial),
// shared by every 1.12.0 batch. isRuleWide's own 1.10.0 frozen samples are lost, so this compares de98243 (1.11.0, the
// shipped and measured behaviour) with a batch tree on a rebuilt corpus, per model row (haiku, sonnet; shipped rows,
// no harness):
//   (가) request bytes: the note call each window sends (model, effort, system, prompt, maxTokens, timeoutMs), captured
//        from the plugin test harness (`claude plugin test` through the pinned CLI) in a copy of each tree;
//   (나) selection: ruleNamesOf of the team rules and which notes W2 widens (keptNoteText(reply, names) ≠ keptNoteText(reply));
//   (다) reading: the stored text (keptNoteText(reply, ruleNames)), from the harness (what writeNote saves) and by function;
//   guard: the same note with an alias variable set in the session after start (recheckRemap before a widened-marker
//        note is saved): the stored text the harness saves.
// Corpus: the repo fixtures (rule19's team file and note, its own/plain variants as tests/flow110 writes them; the
// flow1819 F2 api.js note; ruledrill110's two-rule team file), the G6 1.12.0 dev sets 1-4 (design/G6/dev, samples and
// their changes) with each model's recorded note replies (design/G6/pilot/<set>/note/<model>/out.json; byte-comparison
// inputs only, never measurement), and from batch 1 on any extra corpus file given (`--extra <json>`: [{id, model,
// team, files:[{path, tool, kind, before?, after?, content?, hunks}], request, reply}], e.g. the G6 1.12.0 frozen
// measured samples with their note replies).
// usage: node --experimental-transform-types rulewide113.mjs <batch repo dir> <out dir> [--extra <json>]...
// Writes <out>/rulewide.json (every row) and prints the summary; exit 0 when every comparison is equal, 1 otherwise.
// learn-notes 1.13.0 (impl113/d26/rulewide113.mjs, plan commonPerBatch.d26Procedure.isRuleWide): rulewide.mjs
// (c89d0800…5283) with only the PIN line changed to the 1.13.0 pin and a second run added, fixed in batch 0 before any
// G6 result. Two-run mode is on when the batch tree's MODEL_SWITCHES.haiku.isRuleDrill is true (isRuleDrill haiku ON):
// run 1 (de98243 vs the shipped batch tree) compares, for the haiku rows, only the note call (calls[0]) and the
// (나)/(다) function rows; run 2 (de98243 vs a copy of the batch tree whose haiku row holds isRuleDrill false — one
// recorded edit of that copy's MODEL_SWITCHES.haiku literal, everything else as shipped) compares the full calls list
// and the stored text. The tier-2 call and the code-made practice belong to isRuleDrill haiku's own D26
// (d26Procedure.isRuleDrillHaiku). The sonnet rows keep one run. The summary names the tree path each run imported.
import { readFileSync, writeFileSync, mkdirSync, rmSync, existsSync, cpSync, symlinkSync } from 'node:fs'
import { execFileSync, spawnSync } from 'node:child_process'
import { pathToFileURL } from 'node:url'
import { join } from 'node:path'

const I = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112'
const PIN = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/cli/pinned.sh'
const D = `${I}/design/G6`
const args = process.argv.slice(2)
const repo = args[0]
const out = args[1]
const extras = []
for (let i = 2; i < args.length; i += 1) if (args[i] === '--extra') extras.push(...JSON.parse(readFileSync(args[++i], 'utf8')))
if (!repo || !out) throw new Error('usage: rulewide.mjs <batch repo dir> <out dir> [--extra <json>]')
const J = p => JSON.parse(readFileSync(p, 'utf8'))
const PATHS = ['hooks', 'types', '.claude-plugin', 'tsconfig.json', 'tests/flowkit.ts', 'tests/fixtures']

// The two trees: de98243 from git, the batch from the working tree as it is now.
rmSync(join(out, 'trees'), { recursive: true, force: true })
const trees = { de98243: join(out, 'trees', 'de98243'), batch: join(out, 'trees', 'batch') }
mkdirSync(trees.de98243, { recursive: true })
execFileSync('bash', ['-c', 'git -C "$1" archive de98243 "${@:3}" | tar -x -C "$2"', '_', repo, trees.de98243, ...PATHS])
if (!existsSync(join(trees.de98243, 'hooks/notes.ts'))) throw new Error('de98243 tree not extracted')
for (const p of PATHS) cpSync(join(repo, p), join(trees.batch, p), { recursive: true })
const N = {
  de98243: await import(pathToFileURL(join(trees.de98243, 'hooks/notes.ts')).href),
  batch: await import(pathToFileURL(join(trees.batch, 'hooks/notes.ts')).href),
}
// Two-run mode (1.13.0): only when isRuleDrill is on in the batch tree's haiku row.
const twoRun = N.batch.MODEL_SWITCHES?.haiku?.isRuleDrill === true
let heldEdit = null
if (twoRun) {
  trees.held = join(out, 'trees', 'held')
  for (const p of PATHS) cpSync(join(repo, p), join(trees.held, p), { recursive: true })
  const f = join(trees.held, 'hooks/notes.ts')
  const lines = readFileSync(f, 'utf8').split('\n')
  const at = lines.map((l, i) => [l, i]).filter(([l]) => /^\s*haiku: Object\.freeze\(\{.*\bisRuleDrill: true\b/.test(l))
  if (at.length !== 1) throw new Error(`two-run: ${at.length} haiku MODEL_SWITCHES lines with isRuleDrill: true (want 1)`)
  const [before, i] = at[0]
  const after = before.replace(/\bisRuleDrill: true\b/, 'isRuleDrill: false')
  lines[i] = after
  writeFileSync(f, lines.join('\n'))
  heldEdit = { file: 'hooks/notes.ts', line: i + 1, before, after }
  N.held = await import(pathToFileURL(f).href)
  if (N.held.MODEL_SWITCHES.haiku.isRuleDrill !== false) throw new Error('two-run: held copy still has isRuleDrill on')
}
const imported = Object.fromEntries(Object.entries(trees).map(([k, d]) => [k, join(d, 'hooks/notes.ts')]))

// ---- corpus
const cases = []
const FX = await import(pathToFileURL(join(trees.batch, 'tests/fixtures/rule19.ts')).href)
const RD = await import(pathToFileURL(join(trees.batch, 'tests/fixtures/ruledrill110.ts')).href)
{
  const RI = FX.INPUT_RULE19
  const text = RI.note.text
  const head = text.slice(0, text.indexOf('\n### 직접 해 보기')).split('\n')
  const ruleLines = text.split('\n').slice(head.length + 1)
  const LINE = 'const res = await fetch(`/users/${id}`)'
  const user = ["import { apiRequest } from './api/apiRequest.js'", '', 'export async function loadUser(id) {', `  ${LINE}`, '  return res.json()', '}', ''].join('\n')
  const own = [...head, '### 직접 해 보기', '- 할 일: 응답을 기다리지 않고 Promise 그대로 돌려주게 바꿔 보세요', '- 고칠 줄: `return res.json()`', '- 확인: `loadUser(1)` → Promise가 나옵니다', '- 예시 답: `return res`'].join('\n')
  const plain = [...head, '### 직접 해 보기', '- 할 일: 서버 요청을 인증이 붙는 함수로 바꿔 보세요', ...ruleLines.slice(1)].join('\n')
  const said = head.find(l => l.startsWith('팀 규칙과 다를 수 있음:'))
  const files = [{ path: '/proj/src/user.js', tool: 'Write', kind: 'create', content: user, hunks: [] }]
  const variants = { rule: text, own, plain, noLine: plain.replace(`${said}\n`, ''), teamLine: plain.replace(said, '팀 규칙: 서버 요청은 apiRequest로 합니다') }
  for (const [name, reply] of Object.entries(variants)) {
    for (const model of ['haiku', 'sonnet']) {
      cases.push({ id: `fx/rule19/${name}`, model, team: RI.teamMd, files, request: RI.note.prompt, reply })
      cases.push({ id: `fx/ruledrill110/${name}`, model, team: RD.RULE_DRILL_IN.teamMd, files, request: RI.note.prompt, reply })
    }
  }
  const TEAM_FILE = ['# 팀', '', '## 규칙', '- API 호출은 `fetch`를 바로 쓰지 말고 `fetcher`를 쓴다', '- 로그는 `logger.info`로 남긴다', ''].join('\n')
  const API = ["import { fetcher } from './fetcher.js'", '', 'export async function getUser(id) {', '  const res = await fetch(`/u/${id}`)', '  return res.json()', '}', ''].join('\n')
  const RULE_SAID = 'API 호출은 `fetcher`로 하라는 규칙과 달리 `fetch`를 바로 씁니다'
  const RULE_NOTE = ['### 한 줄 요약', '사용자 정보를 가져오는 함수를 만들었습니다', '### 무엇이 바뀌었나', '- 전: 없음', '- 후: `getUser(1)`이 1번 사용자 정보를 돌려줍니다', '### 왜 이렇게 바꿨을까', '화면에서 사용자 정보를 보이려고 만들었습니다.', `팀 규칙과 다를 수 있음: ${RULE_SAID}`, '### 배울 개념', '- **async/await**: 응답을 기다렸다 씁니다 — `return res.json()`', '### 직접 해 보기', '- 할 일 (팀 규칙): API 호출을 팀 규칙대로 fetcher로 바꿔 보세요', '- 고칠 줄: `` const res = await fetch(`/u/${id}`) ``', '- 확인: `getUser(1)` → 같은 사용자 정보가 나옵니다', '- 예시 답: `` const res = await fetcher(`/u/${id}`) ``'].join('\n')
  const loose = RULE_NOTE.replace('- 할 일 (팀 규칙): ', '- 할 일: (팀 규칙) ')
  const apiFiles = [{ path: '/proj/src/api.js', tool: 'Write', kind: 'create', content: API, hunks: [] }]
  for (const [name, reply] of Object.entries({ rule: RULE_NOTE, loose, plain: RULE_NOTE.replace('- 할 일 (팀 규칙): ', '- 할 일: ') })) {
    for (const model of ['haiku', 'sonnet']) cases.push({ id: `fx/flow1819/${name}`, model, team: TEAM_FILE, files: apiFiles, request: '사용자 정보를 가져오는 함수를 만들어 줘', reply })
  }
}
const teamMd = readFileSync(`${D}/team.md`, 'utf8')
for (const set of ['set1', 'set2', 'set3', 'set4']) {
  const hunks = Object.fromEntries(J(`${D}/dev/${set}/hunks.json`).map(o => [o.id, o]))
  for (const sample of J(`${D}/dev/${set}/samples.json`)) {
    for (const model of ['haiku', 'sonnet']) {
      const got = J(`${D}/pilot/${set}/note/${model}/out.json`).results.find(r => r.id === sample.id)
      if (!got?.isAnswered) continue
      cases.push({ id: `dev/${set}/${sample.id}`, model, team: teamMd, files: hunks[sample.id].files, request: sample.request ?? '', reply: got.text })
    }
  }
}
for (const one of extras) cases.push({ ...one, id: `extra/${one.id}` })

// ---- (가) · (다) · guard through the harness: one generated test file, run in each tree.
const TEST = `import { describe, test } from 'claude-code/testing'
import { finish, routeCalls, start, turn, world } from './flowkit'
import { CASES, FROM } from './d26cases__K__'
const ALIAS = { haiku: 'ANTHROPIC_DEFAULT_HAIKU_MODEL', sonnet: 'ANTHROPIC_DEFAULT_SONNET_MODEL' } as const
type File = { path: string; tool: string; kind: string; before?: string; after?: string; content?: string; hunks: unknown[] }
describe('d26 isRuleWide capture __K__', () => {
  CASES.forEach((c: { id: string; model: 'haiku' | 'sonnet'; team: string; files: File[]; request: string; reply: string }, k: number) => {
    const n = FROM + k
    for (const turned of [false, true]) {
      test(\`\${n} \${c.id} \${c.model} \${turned}\`, { options: { model: c.model } }, async ($, on) => {
        const now: Record<string, string> = {}
        on('env.get', { name: ALIAS[c.model] }, (_$, e, next) => (now[e.name] !== undefined ? { value: now[e.name] } : next(e)))
        on('tool.call', { tool: 'Edit' }, (_$, e, next) => {
          const f = c.files.find(one => one.path === e.file_path && one.tool === 'Edit')
          if (!f) return next(e)
          return { result: { filePath: e.file_path, oldString: e.old_string, newString: e.new_string, originalFile: f.before, structuredPatch: f.hunks, userModified: false, replaceAll: false } }
        })
        on('tool.call', { tool: 'Write' }, (_$, e, next) => {
          const f = c.files.find(one => one.path === e.file_path && one.tool === 'Write')
          if (!f) return next(e)
          return { result: { type: 'create', filePath: e.file_path, content: e.content, structuredPatch: [], originalFile: null } }
        })
        const calls = routeCalls(on)
        const store = new Map<string, unknown>()
        const w = world(on, 'ok', null, true, store)
        w.files.set('/proj/.claude/learn-notes.md', c.team)
        await start($)
        if (turned) now[ALIAS[c.model]] = 'set-in-session-x'
        w.texts = [c.reply]
        await turn($, async () => {
          for (const [i, f] of c.files.entries()) {
            if (f.tool === 'Write') await $.tool.call({ tool: 'Write', tool_use_id: \`d\${i}\`, file_path: f.path, content: f.content ?? f.after ?? '' })
            else await $.tool.call({ tool: 'Edit', tool_use_id: \`d\${i}\`, file_path: f.path, old_string: f.before ?? '', new_string: f.after ?? '' })
          }
        }, 't1', c.request || '코드를 바꿔 줘')
        await finish(w)
        const notes = ((store.get('history') as Record<string, { notes: { text: string; status: string }[] }> | undefined)?.['/proj']?.notes) ?? []
        console.log('D26OUT ' + JSON.stringify({ n, id: c.id, model: c.model, turned, calls, text: notes.at(-1)?.text ?? null, status: notes.at(-1)?.status ?? null }))
      })
    }
  })
})
`
const captured = {}
for (const [label, dir] of Object.entries(trees)) {
  // The engine reads a module of 1 MiB at most: the cases in chunks of at most ~700 kB, one test file each.
  let chunk = [], from = 0, k = 0
  const flush = () => {
    if (chunk.length === 0) return
    writeFileSync(join(dir, `tests/d26cases${k}.ts`), `export const FROM = ${from}\nexport const CASES = ${JSON.stringify(chunk)} as const\n`)
    writeFileSync(join(dir, `tests/d26_${k}.test.ts`), TEST.replaceAll('__K__', String(k)))
    from += chunk.length; chunk = []; k += 1
  }
  for (const c of cases) {
    if (chunk.length > 0 && JSON.stringify([...chunk, c]).length > 700_000) flush()
    chunk.push(c)
  }
  flush()
  const r = spawnSync(PIN, ['claude', 'plugin', 'test', '.'], { cwd: dir, encoding: 'utf8', maxBuffer: 1 << 30, timeout: 1_800_000 })
  const log = `${r.stdout}\n${r.stderr}`
  writeFileSync(join(out, `harness-${label}.log`), log.split('\n').filter(l => !l.startsWith('D26OUT ')).join('\n'))
  captured[label] = Object.fromEntries(log.split('\n').filter(l => l.startsWith('D26OUT ')).map(l => JSON.parse(l.slice(7))).map(o => [`${o.n}|${o.turned}`, o]))
  const fails = (log.match(/^\(fail\)/gm) ?? []).length
  if (fails > 0 || Object.keys(captured[label]).length !== cases.length * 2) throw new Error(`${label}: ${fails} failed, ${Object.keys(captured[label]).length} of ${cases.length * 2} captured`)
}

// ---- (나) and (다) by function, and the comparison
const rows = []
const sum = {}
const add = (model, what, equal) => {
  sum[model] ??= {}
  sum[model][what] ??= { compared: 0, differ: 0 }
  sum[model][what].compared += 1
  if (!equal) sum[model][what].differ += 1
}
const teams = new Map()
cases.forEach((c, n) => {
  const old = N.de98243, neu = N.batch
  if (!teams.has(c.team)) teams.set(c.team, { o: old.parseTeamFile(c.team), b: neu.parseTeamFile(c.team) })
  const t = teams.get(c.team)
  const namesO = old.ruleNamesOf(t.o.rules), namesB = neu.ruleNamesOf(t.b.rules)
  add(c.model, 'ruleNamesOf', JSON.stringify(namesO) === JSON.stringify(namesB))
  const keptO = old.keptNoteText(c.reply, namesO), keptB = neu.keptNoteText(c.reply, namesB)
  add(c.model, 'keptNoteText(reply, names)', keptO === keptB)
  add(c.model, 'W2 widened (selection)', (keptO !== old.keptNoteText(c.reply)) === (keptB !== neu.keptNoteText(c.reply)))
  for (const turned of [false, true]) {
    const a = captured.de98243[`${n}|${turned}`], b = captured.batch[`${n}|${turned}`]
    const what = turned ? 'guard (alias set in session)' : 'harness'
    if (twoRun && c.model === 'haiku') {
      const h = captured.held[`${n}|${turned}`]
      add(c.model, `run 1 ${what}: note call (calls[0])`, JSON.stringify(a.calls[0] ?? null) === JSON.stringify(b.calls[0] ?? null))
      add(c.model, `run 2 ${what}: note request`, JSON.stringify(a.calls) === JSON.stringify(h.calls))
      add(c.model, `run 2 ${what}: stored text`, a.text === h.text && a.status === h.status)
    } else {
      add(c.model, `${what}: note request`, JSON.stringify(a.calls) === JSON.stringify(b.calls))
      add(c.model, `${what}: stored text`, a.text === b.text && a.status === b.status)
    }
    rows.push({ n, id: c.id, model: c.model, turned, calls: a.calls.length, sameCalls: JSON.stringify(a.calls) === JSON.stringify(b.calls), sameText: a.text === b.text, widened: !turned && a.text !== null && a.text !== old.keptNoteText(c.reply), ...(turned && b.text !== neu.keptNoteText(c.reply) ? { turnedNotAllOff: { status: b.status, head: (b.text ?? '').slice(0, 120), want: neu.keptNoteText(c.reply).slice(0, 120) } } : {}) })
  }
})
const widened = Object.fromEntries(['haiku', 'sonnet'].map(m => [m, rows.filter(r => r.model === m && r.widened).length]))
const guardOff = Object.fromEntries(['haiku', 'sonnet'].map(m => [m, cases.filter((c, n) => c.model === m && captured.batch[`${n}|true`].text === N.batch.keptNoteText(c.reply)).length]))
const differ = Object.values(sum).flatMap(o => Object.values(o)).reduce((x, o) => x + o.differ, 0)
const summary = { tool: 'rulewide113.mjs', twoRun, heldEdit, imported, cases: cases.length, perModel: Object.fromEntries(['haiku', 'sonnet'].map(m => [m, cases.filter(c => c.model === m).length])), widenedByW2: widened, guardKeptAsAllOff: guardOff, comparisons: sum, differ }
writeFileSync(join(out, 'rulewide.json'), JSON.stringify({ summary, rows }, null, 1) + '\n')
console.log(JSON.stringify(summary, null, 1))
process.exit(differ === 0 ? 0 : 1)
