"""learn-notes 1.12.0 G2 (batch 2): the counts of one label (bar, decision rule 1, stance 14; a split or an undecided
case counts against). (가) per changed slot: read, every ⚙ clause of 7 (eval.json ga_tool) and both judges 'pass'.
(나) per read item: the tool's 'right' or 'wrong' stands (stance 3 · 6 · 11's first step); where the tool left it to the
judges, right only when both judges say 'right'. Pass iff (가) >= 16 and (나) wrong = 0.
usage: tally.py <label>   -> judge/<L>/tally.json (chmod 444; refuses an existing one)"""
import json, os, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2"
J = os.environ.get("JUDGE", f"{S}/judge")
label = sys.argv[1]
d = f"{J}/{label}"
if os.path.exists(f"{d}/tally.json"):
    sys.exit("refuse: tally.json exists")
for p in (f"{d}/eval.json", f"{d}/verdicts-1.json", f"{d}/verdicts-2.json"):
    if os.stat(p).st_mode & 0o222:
        sys.exit(f"refuse: {p} is not frozen (chmod 444)")
rows = json.load(open(f"{d}/eval.json", encoding="utf-8"))["rows"]
v = [{x["slot"]: x for x in json.load(open(f"{d}/verdicts-{k}.json", encoding="utf-8"))["verdicts"]} for k in (1, 2)]
slots, ga, read, wrong = [], 0, 0, 0
for r in rows:
    j = [vv.get(r["slot"], {"ga": "undecided", "na": "undecided"}) for vv in v]
    g = bool(r["read"] and r.get("ga_tool") and all(x["ga"] == "pass" for x in j))
    if r["na"] == "outside":
        na = "outside"
    elif r["na"] in ("right", "wrong"):
        na = r["na"]
    else:
        na = "right" if all(x["na"] == "right" for x in j) else "wrong"
    ga += g
    read += r["read"]
    wrong += na == "wrong"
    slots.append({"slot": r["slot"], "read": r["read"], "ga_tool": r.get("ga_tool"), "ga_judges": [x["ga"] for x in j], "ga": g, "na_tool": r["na"], "na_judges": [x["na"] for x in j], "na": na})
res = {"label": label, "slots": slots, "ga": ga, "of": len(rows), "read": read, "na_wrong": wrong, "pass": ga >= 16 and wrong == 0 and len(rows) == 20}
open(f"{d}/tally.json", "w", encoding="utf-8").write(json.dumps(res, ensure_ascii=False, indent=1) + "\n")
os.chmod(f"{d}/tally.json", 0o444)
print(json.dumps({k: res[k] for k in ("label", "ga", "of", "read", "na_wrong", "pass")}))
