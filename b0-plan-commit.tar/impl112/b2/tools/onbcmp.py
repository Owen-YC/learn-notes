# Compare two onbytes.sh outputs file by file (JSON with path fields 'set' and 'notes' dropped; logs dropped).
import json, os, sys
a, b = sys.argv[1:3]
same = diff = 0
for root, _, files in os.walk(a):
    for f in sorted(files):
        if f.endswith('.log'): continue
        pa = os.path.join(root, f); pb = os.path.join(b, os.path.relpath(pa, a))
        if not os.path.exists(pb): print('missing', pb); diff += 1; continue
        ta, tb = open(pa).read(), open(pb).read()
        if f.endswith('.json'):
            ja, jb = json.loads(ta), json.loads(tb)
            for j in (ja, jb):
                if isinstance(j, dict): j.pop('set', None); j.pop('notes', None)
            ok = ja == jb
        else: ok = ta == tb
        n = len(ta.splitlines())
        if ok: same += 1
        else: diff += 1; print('DIFF', os.path.relpath(pa, a))
print(f'files same {same}, different {diff}')
