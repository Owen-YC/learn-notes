// learn-notes 1.12.0 G2 (batch 2): stance 7 (ㄷ)'s tokens, codeAsRead of the committed tree (b2/jtree: the same notes.ts
// with codeAsRead exported). usage: node --experimental-transform-types tok.mjs < [[text, file], …] JSON on stdin
import { readFileSync } from 'node:fs'
const J = await import(process.env.JNOTES ?? '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/jtree/hooks/notes.ts')
const items = JSON.parse(readFileSync(0, 'utf8'))
process.stdout.write(JSON.stringify(items.map(([text, file]) => J.codeAsRead(text, file))))
