"""learn-notes 1.12.0 G2 (batch 2): one judge of one label (stance 14: two per label, each a fresh sub-agent that never
took part in the design, the sample writing or the calls; it sees only judge/tpl-judge.md, judge/stance-G2.md (the
'판정의 입장' of this section as committed) and the label's report.md: no model name, token, time or cap).
usage: judge.py <label> <1|2>   -> judge/<L>/judge-<n>/ (prompt.md, out.json, result.txt, model.txt, pin.txt) and
       judge/<L>/verdicts-<n>.json (chmod 444; refuses an existing one)
Runs `claude -p --model opus --tools '' --output-format json` in an empty dir through cli/pinned.sh (prompt on stdin).
The reply must be a JSON array with one entry for each read slot (eval.json rows with read true): ga in pass/miss/
undecided, na in right/wrong/tool/undecided. An unreadable reply, or one missing a read slot, is asked once more of a
fresh judge with the same prompt (judge-<n>-2, recorded); a slot still missing or unreadable is 'undecided' (against)."""
import hashlib, json, os, re, subprocess, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2"
P = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh"
J = os.environ.get("JUDGE", f"{S}/judge")
CLAUDE = os.environ.get("JUDGE_CMD", "timeout 1800 claude -p --model opus --tools '' --output-format json")
label, n = sys.argv[1], sys.argv[2]
d = f"{J}/{label}"
vp = f"{d}/verdicts-{n}.json"
if os.path.exists(vp):
    sys.exit(f"refuse: {vp} exists")
rows = json.load(open(f"{d}/eval.json", encoding="utf-8"))["rows"]
want = [r["slot"] for r in rows if r["read"]]
prompt = open(f"{S}/judge/tpl-judge.md", encoding="utf-8").read() + "\n# 판정의 입장\n\n" + open(os.environ.get("STANCE", f"{S}/judge/stance-G2.md"), encoding="utf-8").read() + "\n# 보고서\n\n" + open(f"{d}/report.md", encoding="utf-8").read()


def ask(tag):
    o = f"{d}/judge-{tag}"
    if os.path.exists(o):
        sys.exit(f"refuse: {o} exists")
    os.makedirs(o)
    os.makedirs(f"{S}/work/judge-{label}-{tag}", exist_ok=True)
    open(f"{o}/prompt.md", "w", encoding="utf-8").write(prompt)
    with open(f"{o}/prompt.md", "rb") as fin, open(f"{o}/out.json", "wb") as fout:
        subprocess.run([P, "bash", "-c", CLAUDE], stdin=fin, stdout=fout, stderr=open(f"{o}/err.txt", "w"), cwd=f"{S}/work/judge-{label}-{tag}")
    subprocess.run([P, "--record"], stdout=open(f"{o}/pin.txt", "w"), stderr=subprocess.STDOUT)
    try:
        out = json.load(open(f"{o}/out.json", encoding="utf-8"))
    except Exception:
        out = {}
    text = out.get("result") or ""
    open(f"{o}/result.txt", "w", encoding="utf-8").write(text)
    open(f"{o}/model.txt", "w").write(json.dumps(sorted((out.get("modelUsage") or {}).keys())) + "\n")
    try:
        a, b = text.find("["), text.rfind("]")
        got = json.loads(text[a:b + 1])
        got = {g["slot"]: g for g in got if isinstance(g, dict) and "slot" in g}
    except Exception:
        got = None
    return got


def ok(g):
    return g.get("ga") in ("pass", "miss", "undecided") and g.get("na") in ("right", "wrong", "tool", "undecided")


got = ask(n)
tries = [n]
if got is None or any(s not in got or not ok(got[s]) for s in want):
    tries.append(f"{n}-2")
    again = ask(f"{n}-2")
    if again is not None:
        got = {**(got or {}), **{k: v for k, v in again.items() if (got is None or k not in got or not ok(got[k]))}}
verdicts = []
for s in want:
    g = (got or {}).get(s)
    verdicts.append({"slot": s, **({k: g.get(k) for k in ("ga", "ga_clause", "na", "na_clause", "why")} if g and ok(g) else {"ga": "undecided", "na": "undecided", "why": "답에 없거나 읽지 못함(도구)"})})
body = json.dumps({"label": label, "judge": n, "tries": tries, "verdicts": verdicts}, ensure_ascii=False, indent=1) + "\n"
open(vp, "w", encoding="utf-8").write(body)
os.chmod(vp, 0o444)
print(json.dumps({"label": label, "judge": n, "tries": tries, "slots": len(verdicts), "sha256": hashlib.sha256(body.encode()).hexdigest()}))
