"""learn-notes 1.12.0 G2 (batch 2): decision rule 1-2 after every verdict file and the tally are frozen: opens the pair
(label.py open) and writes judge/decision.json (chmod 444): per model its label's counts and ON (MODEL_SWITCHES[m].
rungChangedStep = 2 in the commit after the decision) or OFF (Infinity). sonnet: not measured, Infinity.
usage: decide.py"""
import json, os, subprocess, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2"
J = os.environ.get("JUDGE", f"{S}/judge")
if os.path.exists(f"{J}/decision.json"):
    sys.exit("refuse: decision.json exists")
pair = json.loads(subprocess.run(["python3", "-I", f"{S}/tools/label.py", "open"], capture_output=True, text=True, check=True, env={**os.environ, "JUDGE": J}).stdout)
label = [k for k in pair if k != "nonce"][0]
t = json.load(open(f"{J}/{label}/tally.json", encoding="utf-8"))
dec = {"haiku": {"label": label, "ga": t["ga"], "of": t["of"], "read": t["read"], "na_wrong": t["na_wrong"], "pass": t["pass"], "rungChangedStep": 2 if t["pass"] else "Infinity"},
       "sonnet": {"measured": False, "rungChangedStep": "Infinity"}}
assert pair[label] == "haiku"
open(f"{J}/decision.json", "w", encoding="utf-8").write(json.dumps(dec, ensure_ascii=False, indent=1) + "\n")
os.chmod(f"{J}/decision.json", 0o444)
print(json.dumps(dec, ensure_ascii=False))
