"""learn-notes 1.12.0 G2 (batch 2): extract, check and freeze the blind writers' records (plan batches[2].samples, design
samples.design 'Static check before freezing'). No model call; the plugin facts come from tools/facts.mjs (committed tree).
usage: check.py <out dir>      reads gen/out/A1[,A2]/result.txt and gen/out/B1[,B2]/result.txt as they exist
  -> <out>/raw.json (every record as written, with its source), facts-in.json · facts.json (facts.mjs), check-report.json,
     and when every slot is
     filled: samples.json (the 20 measured eligible records in slot order and the 7 fillers), layout.json (the 9
     quizzes), learner.json (stance 3 learner results); each written once and chmod 444 (refuses an existing <out>/samples.json).
Rules (a failing record is never edited; it is replaced):
  eligible (gm01-gm24; js gm01-gm15, py gm16-gm24; measured js gm01-gm13 · py gm16-gm22, spares js gm14 gm15 · py gm23 gm24):
   fields id name blurb file code output kind; file ext by id; 6-16 lines, <= 650 chars; the blurb's backtick quote on
   a line within lines 1-6; 1-4 print lines (console.log( / print( starting the line), no other console. or print( call;
   no import/require/export line, no while/do, no counted for (for (…;…)), no list grown inside the loop over it, no
   empty print call, no backslash, no Python set (set( or a {…} literal with no ':' once strings are blanked), no
   input/file/network/clock/random/timer/locale/process/environment/id()/hash() (UNSET below for js and py and the
   committed isChangedRunnable), every string literal under 20 characters; the run (stance 3, runlib.run) exit 0, all runs the
   same, no timeout, its lines exactly the declared output's lines, 1-4 lines; the committed rungOf alone at step 2 with
   haiku's G2 cell gives 'changed' (so isWholeShown, isChangedRunnable and isChangedShaped hold), changeSites >= 3 with
   one not a string; name and blurb read back by conceptsOf exactly as written; redactText hits 0.
  fillers gf1-gf7: gf1 ts · gf2 js · gf5 py edits (before/after, after 20-34 lines, one hunk changing 1-4 consecutive
   lines, the blurb's quote in after, rung 'mine' at step 0); gf3 · gf6 no code (rung none, asked why); gf4 js · gf7 py
   whole files of 6-14 lines with slip {question, mine, what} (rung none at step 1 with the slip asked again).
  names (every record): no '*', no backtick, no '--' in the name, no '--' in the blurb; the name (lower case, spaces
   out) and the file path not in impl112/NAMES-all.txt (any entry, compared the same way) and not twice in one
   writer's reply; the chosen 27 records hold no name or file twice (else STOP).
  mix (design samples, each a minimum across the 24): the writer's own 'mix' letters of A1's 24 records are counted
   (a >= 8, b c d >= 4, e >= 3 js only, f g h >= 2, i j k >= 3); when one falls short the report says 'WRITE A 2: mix'
   and, once gen/out/A2 exists, A2 is the eligible source and A1 the second source (A2 counted the same way and
   recorded; a short A2 is recorded and used). The letters are the writer's word: no tool checks them.
  replacement: a failing measured eligible slot takes the first passing unused spare of its language in id order; when
   none is left, the report says 'WRITE A 2' and the slot takes the first passing unused record of its language from
   gen/out/A2 in id order; a failing filler says 'WRITE B 2' and takes the same id from gen/out/B2. Still short: STOP.
  layout (fixed): the 20 measured in slot order c1..c20, py at c2 c5 c8 c11 c14 c17 c20 (py in id order, js in id order),
   steps 2 / 3 alternating from c1 = 2; Q1 [c1 c2 c3] · Q2 [c4 c5 c6] · Q3 [c7 c8 gf1] · Q4 [gf2 c9 c10] · Q5 [c11 gf5
   c12] · Q6 [c13 gf3 c14] · Q7 [c15 gf6 c16] · Q8 [gf4 c17 c18] · Q9 [gf7 c19 c20]; 내 코드 at step 0, 왜 at 2, 다시 도전
   at 1 with its slip asked again (times 1)."""
import hashlib, json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import runlib  # noqa: E402

S = os.path.dirname(HERE)
GEN = os.environ.get("GENOUT", f"{S}/gen/out")
NAMES = os.environ.get("NAMESALL", "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/NAMES-all.txt")
NODE = ["node", "--experimental-transform-types", "--no-warnings"]
ELIG = [f"gm{i:02d}" for i in range(1, 25)]
MEASURED = {"js": ELIG[0:13], "py": ELIG[15:22]}
SPARES = {"js": ELIG[13:15], "py": ELIG[22:24]}
FILL = {"gf1": ("mine", "ts"), "gf2": ("mine", "js"), "gf3": ("why", None), "gf4": ("again", "js"), "gf5": ("mine", "py"), "gf6": ("why", None), "gf7": ("again", "py")}
MIX = {"a": 8, "b": 4, "c": 4, "d": 4, "e": 3, "f": 2, "g": 2, "h": 2, "i": 3, "j": 3, "k": 3}
PRINT = {"js": re.compile(r"^\s*console\.log\("), "py": re.compile(r"^\s*print\(")}
UNSET = {"js": re.compile(r"(?<![\w$.])(require|fetch|setTimeout|setInterval|Date|Intl|navigator|crypto|XMLHttpRequest)\b|\bprocess\.|\bMath\.random\b|\.toLocale\w*\s*\(|\.localeCompare\s*\("),
         "py": re.compile(r"(?<![\w$.])(input|open|id|hash|exec|eval|__import__)\s*\(")}
STR = re.compile(r"""(['"`])((?:(?!\1).)*)\1""")


def norm(x):
    return re.sub(r"\s+", "", x).lower()


def lang_of(path):
    return {"js": "js", "py": "py", "ts": "ts"}.get(path.rsplit(".", 1)[-1]) if path and "." in path else None


def parse(path):
    text = open(path, encoding="utf-8").read().strip()
    text = re.sub(r"^```\w*\n|\n```$", "", text)
    a, b = text.find("["), text.rfind("]")
    return json.loads(text[a:b + 1])


def grows_in_loop(code, lang):
    lines = code.split("\n")
    for i, line in enumerate(lines):
        m = re.match(r"^(\s*)for\s*\(\s*(?:const|let|var)\s+.+?\s+of\s+([A-Za-z_$][\w$.]*)\s*\)", line) if lang == "js" else re.match(r"^(\s*)for\s+.+?\s+in\s+([A-Za-z_][\w.]*)\s*:", line)
        if not m:
            continue
        ind, name = len(m.group(1)), m.group(2)
        grow = re.compile(re.escape(name) + r"\s*\.\s*(push|unshift|splice|append|extend|insert)\s*\(")
        if grow.search(line):
            return True
        for nxt in lines[i + 1:]:
            if nxt.strip() == "" or nxt.strip() == "}":
                if nxt.strip() == "}" and len(nxt) - len(nxt.lstrip()) <= ind:
                    break
                continue
            if len(nxt) - len(nxt.lstrip()) <= ind:
                break
            if grow.search(nxt):
                return True
    return False


def static_eligible(r):
    bad = []
    for k in ("id", "name", "blurb", "file", "code", "output", "kind"):
        if not isinstance(r.get(k), str) or not r.get(k):
            bad.append(f"field {k}")
    if bad:
        return bad
    lang = lang_of(r["file"])
    want = "js" if r["id"] in ELIG[:15] else "py"
    if lang != want:
        bad.append(f"ext {lang} not {want}")
        return bad
    code = r["code"].rstrip("\n")
    lines = code.split("\n")
    if not 6 <= len(lines) <= 16:
        bad.append(f"lines {len(lines)}")
    if len(code) > 650:
        bad.append(f"chars {len(code)}")
    prints = [l for l in lines if PRINT[lang].match(l)]
    calls = len(re.findall(r"\bconsole\s*\.", code)) if lang == "js" else len(re.findall(r"(?<![\w$.])print\s*\(", code))
    if not 1 <= len(prints) <= 4 or calls != len(prints):
        bad.append(f"print lines {len(prints)} calls {calls}")
    if re.search(r"^\s*(import|export)\b|\brequire\s*\(|(?<![\w$.])import\s*\(", code, re.M) or (lang == "py" and re.search(r"^\s*from\s+\S+\s+import\b", code, re.M)):
        bad.append("import/require/export")
    if re.search(r"\bwhile\b", code) or (lang == "js" and re.search(r"\bdo\b", code)):
        bad.append("while/do")
    if lang == "js" and re.search(r"\bfor\s*\([^)]*;", code):
        bad.append("counted for")
    if grows_in_loop(code, lang):
        bad.append("grows the list it loops over")
    if re.search(r"console\.log\(\s*\)" if lang == "js" else r"(?<![\w$.])print\(\s*\)", code):
        bad.append("empty print")
    if "\\" in code:
        bad.append("backslash")
    if lang == "py":
        blank = STR.sub('""', code)
        if re.search(r"(?<![\w.])set\s*\(", blank) or re.search(r"\{[^{}:]*[^{}:\s][^{}:]*\}", blank):
            bad.append("python set")
    if UNSET[lang].search(STR.sub('""', code)):
        bad.append("input/file/network/clock/random/locale/process/id/hash")
    long = [m.group(2) for m in STR.finditer(code) if len(m.group(2)) >= 20]
    if long:
        bad.append(f"string literal >= 20 chars: {long[0][:24]}")
    return bad


def name_rules(r, taken_names, taken_files, seen_n, seen_f):
    bad = []
    n, b, f = r.get("name") or "", r.get("blurb") or "", r.get("file")
    if "*" in n or "`" in n or "--" in n:
        bad.append("name has * ` or --")
    if "--" in b:
        bad.append("blurb has --")
    if norm(n) in taken_names:
        bad.append("name in NAMES-all")
    if norm(n) in seen_n:
        bad.append("name twice in the set")
    if f is not None and (f in taken_files or norm(f) in taken_names):
        bad.append("file in NAMES-all")
    if f is not None and f in seen_f:
        bad.append("file twice in the set")
    return bad


def static_filler(r):
    role, lang = FILL[r["id"]]
    bad = []
    for k in ("id", "name", "blurb", "kind"):
        if not isinstance(r.get(k), str) or not r.get(k):
            bad.append(f"field {k}")
    if role == "why":
        if any(k in r for k in ("code", "before", "after", "file")):
            bad.append("why record has code or file")
        return bad
    if lang_of(r.get("file")) != lang:
        bad.append(f"ext not {lang}")
    if role == "mine":
        if not isinstance(r.get("before"), str) or not isinstance(r.get("after"), str):
            return bad + ["before/after"]
        a, b = r["before"].rstrip("\n").split("\n"), r["after"].rstrip("\n").split("\n")
        if not 20 <= len(b) <= 34:
            bad.append(f"after lines {len(b)}")
        s = 0
        while s < min(len(a), len(b)) and a[s] == b[s]:
            s += 1
        ea, eb = len(a) - 1, len(b) - 1
        while ea >= s and eb >= s and a[ea] == b[eb]:
            ea -= 1
            eb -= 1
        if not (1 <= max(ea - s + 1, eb - s + 1) <= 4):
            bad.append(f"changed lines {ea - s + 1}/{eb - s + 1}")
    else:
        code = r.get("code")
        if not isinstance(code, str):
            return bad + ["code"]
        if not 6 <= len(code.rstrip("\n").split("\n")) <= 14:
            bad.append("code lines")
        slip = r.get("slip")
        if not isinstance(slip, dict) or not all(isinstance(slip.get(k), str) and slip.get(k) for k in ("question", "mine", "what")):
            bad.append("slip")
    return bad


def main():
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    if os.path.exists(f"{out}/samples.json"):
        sys.exit(f"refuse: {out}/samples.json exists")
    taken = [l.split("\t", 1)[0] for l in open(NAMES, encoding="utf-8") if l.strip()]
    taken_names, taken_files = {norm(x) for x in taken}, set(taken)
    raw = []
    for src in ("A1", "A2", "B1", "B2"):
        p = f"{GEN}/{src}/result.txt"
        if os.path.exists(p):
            try:
                recs = parse(p)
            except Exception as e:  # recorded; the writer's whole reply is unreadable
                raw.append({"source": src, "unreadable": str(e)[:200]})
                continue
            for r in recs:
                raw.append({"source": src, **r})
    recs = [r for r in raw if "unreadable" not in r]
    roles = []
    for r in recs:
        rid = r.get("id")
        role = "eligible" if rid in ELIG else FILL[rid][0] if rid in FILL else None
        roles.append(dict(r, role=role))
    known = [r for r in roles if r["role"]]
    fin = f"{out}/facts-in.json"
    json.dump(known, open(fin, "w", encoding="utf-8"), ensure_ascii=False)
    subprocess.run(NODE + [f"{HERE}/facts.mjs", fin, f"{out}/facts.json"], check=True, capture_output=True)
    facts = json.load(open(f"{out}/facts.json", encoding="utf-8"))
    report = []
    seen = {}
    ok = {}
    for r, f in zip(known, facts):
        seen_n, seen_f = seen.setdefault(r["source"], (set(), set()))
        bad = static_eligible(r) if r["role"] == "eligible" else static_filler(r)
        bad += name_rules(r, taken_names, taken_files, seen_n, seen_f)
        if not f["readSame"]:
            bad.append("name/blurb not read back as written")
        if f["redactHits"]:
            bad.append("redactText hits")
        if r["role"] == "eligible" and not bad:
            run = runlib.run(r["code"].rstrip("\n"), lang_of(r["file"]))
            want = r["output"].split("\n")
            while want and want[-1] == "":
                want.pop()
            if run["rc"] != 0 or not run["agree"] or run["timeout"]:
                bad.append(f"run rc {run['rc']} agree {run['agree']} timeout {run['timeout']}")
            elif run["lines"] != want:
                bad.append("output not as declared")
            elif not 1 <= len(run["lines"]) <= 4:
                bad.append(f"prints {len(run['lines'])} lines")
            if f["rung"] != "changed":
                bad.append(f"rung {f['rung']}")
            sites = f.get("sites") or []
            if len(sites) < 3 or all(s["kind"] == "string" for s in sites):
                bad.append(f"sites {len(sites)}")
            if not 1 <= f["quoteLine"] <= 6:
                bad.append(f"quote line {f['quoteLine']}")
        elif r["role"] in ("mine",) and f["rung"] != "mine":
            bad.append(f"rung {f['rung']}")
        elif r["role"] in ("why", "again") and f["rung"] is not None:
            bad.append(f"rung {f['rung']}")
        if r["role"] == "mine" and not bad and not (f.get("text") and f["quoteLine"] > 0):
            bad.append("quote not in after")
        seen_n.add(norm(r.get("name") or ""))
        if r.get("file"):
            seen_f.add(r["file"])
        report.append({"source": r["source"], "id": r["id"], "role": r["role"], "name": r.get("name"), "file": r.get("file"), "mix": r.get("mix"), "pass": not bad, "why": bad})
        if not bad:
            ok[(r["source"], r["id"])] = r
    # mix (writer's letters, counted over a try's 24 records)
    def mix_of(src):
        recs_ = [r for r in recs if r["source"] == src and r.get("id") in ELIG]
        cnt = {k: 0 for k in MIX}
        for r in recs_:
            for k in set(r.get("mix") or []) if isinstance(r.get("mix"), list) else set():
                if k in cnt and (k != "e" or lang_of(r.get("file")) == "js"):
                    cnt[k] += 1
        return {"counts": cnt, "short": [k for k, n in MIX.items() if cnt[k] < n]}
    mix = {src: mix_of(src) for src in ("A1", "A2") if any(r["source"] == src for r in recs)}
    has_a2 = "A2" in mix
    first, other = ("A2", "A1") if mix.get("A1", {}).get("short") and has_a2 else ("A1", "A2")
    # slots
    slots, notes = {}, []
    if mix.get("A1", {}).get("short") and not has_a2:
        notes.append(f"WRITE A 2: mix short {mix['A1']['short']}")
    for lang in ("js", "py"):
        free = [i for i in SPARES[lang] if (first, i) in ok]
        second = [i for i in (ELIG[:15] if lang == "js" else ELIG[15:]) if (other, i) in ok]
        for i in MEASURED[lang]:
            if (first, i) in ok:
                slots[i] = ok[(first, i)]
            elif free:
                j = free.pop(0)
                slots[i] = ok[(first, j)]
                notes.append(f"{i} <- {first} {j} (spare)")
            elif second:
                j = second.pop(0)
                slots[i] = ok[(other, j)]
                notes.append(f"{i} <- {other} {j}")
            else:
                notes.append(f"WRITE A 2: {i} ({lang}) has no passing record" if not has_a2 else f"STOP: {i} ({lang}) has no passing record in A1 or A2")
    for i in FILL:
        if ("B1", i) in ok:
            slots[i] = ok[("B1", i)]
        elif ("B2", i) in ok:
            slots[i] = ok[("B2", i)]
            notes.append(f"{i} <- B2 {i}")
        else:
            notes.append(f"WRITE B 2: {i} fails" if not any(r["source"] == "B2" for r in recs) else f"STOP: {i} fails in B1 and B2")
    chosen = list(slots.values())
    for key in ("name", "file"):
        vals = [norm(r.get(key) or "") if key == "name" else r.get(key) for r in chosen if r.get(key)]
        if len(vals) != len(set(vals)):
            notes.append(f"STOP: the same {key} twice among the chosen records (two tries)")
    meta = {"report": report, "replaced": notes, "mix": mix, "eligibleSource": first, "unreadable": [r for r in raw if "unreadable" in r]}
    if any(n.startswith(("WRITE", "STOP")) for n in notes) or len(slots) < 27:
        json.dump(meta, open(f"{out}/check-report.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(json.dumps({"filled": len(slots), "notes": notes}, ensure_ascii=False))
        sys.exit(3)
    js = [slots[i] for i in MEASURED["js"]]
    py = [slots[i] for i in MEASURED["py"]]
    order = []
    for k in range(1, 21):
        order.append(py.pop(0) if k % 3 == 2 else js.pop(0))
    c = [dict(r, slot=f"c{k}", step=2 if k % 2 == 1 else 3) for k, r in enumerate(order, 1)]
    F = {i: slots[i] for i in FILL}
    def fs(i, step, slip=False):
        return {"id": i, "source": F[i]["source"], "step": step, **({"slip": True} if slip else {})}
    def cs(k):
        return {"id": c[k - 1]["id"], "source": c[k - 1]["source"], "slot": f"c{k}", "step": c[k - 1]["step"]}
    layout = {"quizzes": [
        {"id": "Q1", "slots": [cs(1), cs(2), cs(3)]}, {"id": "Q2", "slots": [cs(4), cs(5), cs(6)]},
        {"id": "Q3", "slots": [cs(7), cs(8), fs("gf1", 0)]}, {"id": "Q4", "slots": [fs("gf2", 0), cs(9), cs(10)]},
        {"id": "Q5", "slots": [cs(11), fs("gf5", 0), cs(12)]}, {"id": "Q6", "slots": [cs(13), fs("gf3", 2), cs(14)]},
        {"id": "Q7", "slots": [cs(15), fs("gf6", 2), cs(16)]}, {"id": "Q8", "slots": [fs("gf4", 1, True), cs(17), cs(18)]},
        {"id": "Q9", "slots": [fs("gf7", 1, True), cs(19), cs(20)]}]}
    samples = {"eligible": [{k: v for k, v in r.items() if k not in ("role",)} for r in c], "fillers": [{k: v for k, v in F[i].items() if k != "role"} for i in FILL]}
    learner = {}
    for r in c:
        code = r["code"].rstrip("\n")
        run = runlib.run(code, lang_of(r["file"]))
        learner[r["slot"]] = {"id": r["id"], "source": r["source"], "lang": lang_of(r["file"]), "code": code, "lines": run["lines"], "agree": run["agree"], "timeout": run["timeout"]}
    for name, obj in (("raw.json", raw), ("samples.json", samples), ("layout.json", layout), ("learner.json", learner), ("check-report.json", meta)):
        p = f"{out}/{name}"
        open(p, "w", encoding="utf-8").write(json.dumps(obj, ensure_ascii=False, indent=1) + "\n")
        os.chmod(p, 0o444)
    for name in ("facts-in.json", "facts.json"):
        os.chmod(f"{out}/{name}", 0o444)
    print(json.dumps({"filled": len(slots), "replaced": notes, "sha256": {n: hashlib.sha256(open(f"{out}/{n}", "rb").read()).hexdigest() for n in ("raw.json", "samples.json", "layout.json", "learner.json", "check-report.json")}}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
