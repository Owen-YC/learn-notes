#!/bin/bash
# learn-notes 1.12.0 G2 (batch 2): the one model-stage of the round, quiz haiku, run DETACHED (plan runnerRules), e.g.
#   ONLY_WORKFLOW=1 setsid nohup bash tools/stage.sh quiz haiku > stage/quiz-haiku.log 2>&1 < /dev/null &
# The 9 frozen quiz lines (frozen/lines-haiku.jsonl, D34 9/9 first). sonnet is not measured in 1.12.0 (refused).
# Refuses a stage whose STARTED exists (cut-stage rule: the main loop decides). Before: an 'ok' session
# (probe/precheck.sh) = the before record and the usage gate (tools/gate.py pre): record differs -> exit 3 (STOP, not
# called); gate fails -> exit 7 (WAIT, its resetsAt printed; no STARTED written, may run again later). Then STARTED
# (UTC, request file sha256), attempt 1 (probe session call-1: each call's status line in call-1/status.jsonl), then
# the G's api-error rule (design stance 2 / bar): a call whose reply is an api-error with status 429 or 5xx, no text
# and 0 output tokens (the engine gives usage on every arm) is sent again, its frozen line as it is, up to twice (call-2, call-3; nothing else is ever
# sent again: an empty reply, a timeout, a cap hit, another api-error status stay as they are); the after record (exit 4
# VOID when it differs). A call that threw (the engine refused before sending) -> exit 5 (M-4 line 4). Then M-4's 10%
# rule on the final status of each quiz: api-errors above 10% of the 9 -> exit 6 (void, nothing opened).
# Only status is printed; never an answer's text. Every claude process goes through cli/pinned.sh.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2
P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh
ST="$1"; M="$2"
[ "$ST" = quiz ] || { echo "usage: stage.sh quiz haiku"; exit 2; }
[ "$M" = haiku ] || { echo "refuse: only haiku is measured for G2 in 1.12.0"; exit 2; }
D="${S:?}/stage/$ST/$M"
[ -e "$D/STARTED" ] && { echo "refuse: $D/STARTED exists (cut-stage rule: report to the main loop)"; exit 1; }
LINES="${S:?}/frozen/lines-$M.jsonl"
[ -s "$LINES" ] || { echo "no frozen lines: $LINES"; exit 2; }
grep -q '"same": 9' "${S:?}/frozen/d34/compare.json" 2>/dev/null || { echo "refuse: no D34 9/9 (frozen/d34/compare.json)"; exit 2; }
mkdir -p "$D"
N=$(ls -d "$D"/pre-*/ 2>/dev/null | wc -l); PRE="$D/pre-$((N + 1))"
"$P" --record > "$PRE.pin.txt" 2>&1
"$P" bash "${S:?}/probe/precheck.sh" "$PRE" "$M" || { echo "precheck failed to run"; exit 3; }
python3 -I "${S:?}/tools/gate.py" pre "$PRE" "$M" "$ST" "$PRE.pin.txt"; rc=$?
[ $rc -eq 3 ] && { echo "STOP: the before record differs from the 1.12.0 calibration: not called"; exit 3; }
[ $rc -eq 7 ] && { echo "WAIT: usage gate failed: not started"; exit 7; }
[ $rc -eq 9 ] && { echo "not started: no statement that no other workflow runs (ONLY_WORKFLOW=1)"; exit 2; }
[ $rc -ne 0 ] && { echo "gate error $rc"; exit 3; }
{ date -u +%FT%TZ; sha256sum "$LINES"; echo "gate $PRE/gate.json"; } > "$D/STARTED"
"$P" --record > "$D/pin-before.txt" 2>&1
threw() { grep -q '"reason": *"threw"' "$1/status.jsonl" 2>/dev/null; }
CUR="$LINES"
for A in 1 2 3; do
  "$P" bash "${S:?}/probe/call.sh" "$D/call-$A" "$M" "$CUR"
  [ -f "$D/call-$A/out.json" ] || { echo "CUT: no call-$A out.json"; "$P" --record > "$D/pin-after.txt" 2>&1; exit 9; }
  threw "$D/call-$A" && { echo "THREW: the engine refused before sending (M-4 line 4)"; exit 5; }
  chmod 444 "$D/call-$A/out.json"
  [ $A -eq 3 ] && break
  python3 -I - "$D/call-$A/out.json" "$LINES" "$D/again-$((A + 1)).jsonl" <<'PY'
import json, sys
out, lines_p, nxt = sys.argv[1:4]
lines = {json.loads(x)["id"]: x for x in open(lines_p, encoding="utf-8") if x.strip()}
again = []
for r in json.load(open(out, encoding="utf-8"))["results"]:
    st = r.get("status")
    toks = (r.get("usage") or {}).get("output_tokens")
    if not r.get("isAnswered") and r.get("reason") == "api-error" and isinstance(st, int) and (st == 429 or st >= 500) and toks == 0 and not r.get("text"):
        again.append(lines[r["id"]].rstrip("\n"))
if again:
    open(nxt, "w", encoding="utf-8").write("\n".join(again) + "\n")
print(f"api-errors to send again: {len(again)}")
PY
  [ -s "$D/again-$((A + 1)).jsonl" ] || break
  CUR="$D/again-$((A + 1)).jsonl"
done
"$P" --record > "$D/pin-after.txt" 2>&1
python3 -I "${S:?}/tools/gate.py" after "$D" "$M" "$D/pin-after.txt"; after=$?
python3 -I - "$D" <<'PY'
import hashlib, json, os, sys
d = sys.argv[1]
final, summ = {}, {"attempts": [], "sha256": {}}
for a in (1, 2, 3):
    p = f"{d}/call-{a}/out.json"
    if not os.path.exists(p):
        continue
    summ["sha256"][f"call-{a}"] = hashlib.sha256(open(p, "rb").read()).hexdigest()
    rs = json.load(open(p, encoding="utf-8"))["results"]
    summ["attempts"].append({"attempt": a, "calls": len(rs)})
    for r in rs:
        how = "answered" if r.get("isAnswered") else r.get("reason")
        if how == "api-error":
            how += f"/{r.get('status')}"
        final[r["id"]] = {"attempt": a, "how": how}
counts = {}
for v in final.values():
    counts[v["how"]] = counts.get(v["how"], 0) + 1
api = sum(n for k, n in counts.items() if k.startswith("api-error"))
summ.update({"quizzes": len(final), "final": final, "counts": counts, "apiErrors": api, "void10": api * 10 > len(final)})
open(f"{d}/summary.json", "w").write(json.dumps(summ, indent=1) + "\n")
print(json.dumps({k: summ[k] for k in ("quizzes", "counts", "apiErrors", "void10", "sha256")}))
PY
[ $after -ne 0 ] && { echo "VOID: the after record differs (D19): this model's cell is off"; exit 4; }
grep -q '"void10": true' "$D/summary.json" && { echo "VOID: api-errors above 10% (M-4)"; exit 6; }
date -u +%FT%TZ > "$D/DONE"
echo "DONE $ST $M"
