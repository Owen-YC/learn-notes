// learn-notes 1.12.0 G2 (batch 2): the plugin facts check.py needs of each written record, from the committed tree
// (kit.mjs). No model call.
// usage: node --experimental-transform-types facts.mjs <records.json> <out.json>
//   eligible (role 'eligible'): read name/blurb (conceptsOf), codeFor's lines, isWholeShown, rung alone at step 2 with
//   haiku's G2 cell (rungOf: 'changed' needs isChangedRunnable and isChangedShaped), changeSites (count, kinds), the
//   1-based line of the blurb's quote; fillers: the rung alone at their layout step (내 코드 edits at 0, 다시 도전 at 1
//   with a slip asked again, 왜 at 2 with no code); redactText hits of name, blurb and code.
import { readFileSync, writeFileSync } from 'node:fs'
import { N, readConcept, pickOf, rungAlone, changeFor } from './kit.mjs'

const [inp, out] = process.argv.slice(2)
const recs = JSON.parse(readFileSync(inp, 'utf8'))
const STEP = { eligible: 2, mine: 0, why: 2, again: 1 }
const res = recs.map(r => {
  const role = r.role
  const read = readConcept(r)
  const slot = role === 'again' ? { slip: true } : {}
  const one = pickOf(r, STEP[role], role === 'again' ? { slip: r.slip } : {})
  const rung = rungAlone(one, slot) ?? null
  const quote = /`([^`]+)`\s*$/.exec(r.blurb ?? '')?.[1]
  const code = r.code ?? r.after
  const quoteLine = quote && code ? code.split('\n').findIndex(l => l.includes(quote)) + 1 : 0
  const hits = [r.name, r.blurb, code ?? ''].reduce((n, t) => n + N.redactText(t ?? '').hits, 0)
  const f = { id: r.id, role, read: read ?? null, readSame: !!read && read.name === r.name && read.blurb === r.blurb, rung, quoteLine, redactHits: hits }
  if (one.code) {
    const change = changeFor(r)
    f.text = one.code.text
    f.file = one.code.file
    f.isWhole = one.code.isWhole === true
    f.textIsFile = one.code.text === (code ?? '').replace(/\n+$/, '')
    f.changeRedacted = change.redacted ?? 0
    f.isChangedRunnable = N.isChangedRunnable(one.code)
    f.isChangedShaped = N.isChangedShaped(one.code, one.blurb)
    const sites = N.changeSites(one.code.text, one.code.file, one.blurb)
    f.sites = sites.map(s => ({ kind: s.kind, token: s.token, line: s.line + 1 }))
  }
  return f
})
writeFileSync(out, JSON.stringify(res, null, 1) + '\n')
console.log(res.map(f => `${f.id} ${f.role} ${f.rung} sites ${f.sites?.length ?? '-'}`).join('\n'))
