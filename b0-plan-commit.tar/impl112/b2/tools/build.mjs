// learn-notes 1.12.0 G2 (batch 2): the 9 quiz requests of the measured round, made as makeQuiz makes them, from the
// committed tree (kit.mjs: b2/mtree = 3f9084c) with haiku's G2 cell on (rungChangedStep 2) on top of batch 1's haiku row.
// usage: node --experimental-transform-types build.mjs <frozen dir>
//   reads <frozen>/samples.json and layout.json (check.py); writes <frozen>/build.json (each quiz's picks, rungs alone,
//   rungs after ladderMixed, prompt, redact hits, maxTokens) and <frozen>/lines-haiku.jsonl ({ id, model 'haiku',
//   system QUIZ_SYSTEM, prompt, maxTokens, timeoutMs 90000 } per quiz), both chmod 444; refuses existing files.
//   Exit 3 (nothing written) when a measured slot is not 'changed' after ladderMixed, a filler not at its rung (내 코드
//   'mine', 왜 and 다시 도전 none), a prompt's redactText hits are not 0, or a quiz's maxTokens is not 4600.
import { readFileSync, writeFileSync, existsSync, chmodSync } from 'node:fs'
import { join } from 'node:path'
import { N, quizOf, QUIZ_TRACE_TOKENS } from './kit.mjs'

const dir = process.argv[2]
for (const f of ['build.json', 'lines-haiku.jsonl']) if (existsSync(join(dir, f))) { console.log(`refuse: ${f} exists`); process.exit(1) }
const S = JSON.parse(readFileSync(join(dir, 'samples.json'), 'utf8'))
const L = JSON.parse(readFileSync(join(dir, 'layout.json'), 'utf8'))
const bySlot = Object.fromEntries(S.eligible.map(r => [r.slot, r]))
const fill = Object.fromEntries(S.fillers.map(r => [r.id, r]))
const out = { quizzes: [] }
const bad = []
for (const q of L.quizzes) {
  const recs = {}
  const slots = q.slots.map(s => {
    const rec = s.slot ? bySlot[s.slot] : fill[s.id]
    const key = s.slot ?? s.id
    recs[key] = rec
    return { id: key, step: s.step, ...(s.slip ? { slip: true } : {}) }
  })
  const made = quizOf(slots, recs)
  q.slots.forEach((s, i) => {
    const want = s.slot ? 'changed' : s.slip ? undefined : fill[s.id].before !== undefined ? 'mine' : undefined
    if (made.rungs[i] !== want) bad.push(`${q.id} ${s.slot ?? s.id} rung ${made.rungs[i]} not ${want}`)
  })
  if (made.redactHits !== 0) bad.push(`${q.id} redact hits ${made.redactHits}`)
  if (made.maxTokens !== QUIZ_TRACE_TOKENS) bad.push(`${q.id} maxTokens ${made.maxTokens}`)
  out.quizzes.push({ id: q.id, slots: q.slots, ...made })
}
if (bad.length) { console.log(bad.join('\n')); process.exit(3) }
writeFileSync(join(dir, 'build.json'), JSON.stringify(out, null, 1) + '\n')
writeFileSync(join(dir, 'lines-haiku.jsonl'), out.quizzes.map(q => JSON.stringify({ id: q.id, model: 'haiku', system: N.QUIZ_SYSTEM, prompt: q.prompt, maxTokens: q.maxTokens, timeoutMs: 90000 })).join('\n') + '\n')
for (const f of ['build.json', 'lines-haiku.jsonl']) chmodSync(join(dir, f), 0o444)
for (const q of out.quizzes) console.log(q.id, q.rungs.map(r => r ?? '-').join(','), 'chars', q.prompt.length, 'redact', q.redactHits, 'max', q.maxTokens)
