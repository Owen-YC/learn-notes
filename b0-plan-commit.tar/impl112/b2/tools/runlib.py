"""learn-notes 1.12.0 G2 (batch 2): running code and comparing outputs as the committed stance says ('판정의 입장' in
docs/qa/견본.md, 1.12.0 G2 section). Rebuilt from the design pilot's runner.py and judge.py (n6, same8).
- run(code, lang): stance 3. An empty new temp dir under b2/work/run, stdin empty, `unshare -n timeout 5`; js `node
  case.js` twice; py `env -i PATH=… LANG=C.UTF-8 PYTHONHASHSEED=n python3 -s -P -B case.py` for n = 1..5; ts (stance
  12, only a tool defect could store one) `node --experimental-transform-types --no-warnings case.ts` twice, as SCOPE's
  protocol runs ts. The result is the stdout lines (a last line with no newline is a line) and, when the exit code is
  not 0, the last exception's name (message left out) as one more line. stderr never enters the result. `agree` is every run's (exit code, stdout,
  name) the same; `timeout` is exit code 124 in any run (no name is added for it).
- the exception's name: py the last non-blank stderr line's leading name (a dotted name's last part); node the last
  stderr line that starts with a name ending in Error or Exception (after an optional 'Uncaught '), else 'Error'.
- the missing name (stance 7 (ㄹ)): node 'X is not defined', py "name 'X' is not defined", from stderr.
- n6(line): stance 6 for any line: ends trimmed, runs of white space one space, no space beside a character that is not a
  letter or digit (Korean included), the quotes ' " ` one kind, one period at the end left out, true · false · none ·
  null · undefined · nan in any case read as lower case.
- a_lines_same(A, result, lang): stance 6 + 11's first step (the tool's): A's lines set against the result's, with the
  A-only rules of stance 6 (a wrapping quote or backtick of a whole A line taken off only where the result line of the
  same place does not start and end with a quote; in js, A's "a": / 'a': read as a: only when no result line holds a
  quoted object key; '(빈 줄)' is an empty line; the result's empty lines at the end are not compared; a middle empty
  line of the result is A's empty line); a result of several lines against an A of one line is the same when the result
  lines joined by ', ' · ' ' · '과 ' · '와 ' · ' 그리고 ' · ' → ' give A.
- same8(result, learner): stance 8 (a) (b) (c) on n6 lines; an error-name line of the result equals no learner line; a
  result that is one error-name line alone differs.
usage as a script: runlib.py <js|py> <file>   (prints the run as JSON)"""
import hashlib, json, os, re, subprocess, sys, tempfile

ROOT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "work", "run")
_cache = {}
NODE_ERR = re.compile(r"^\s*(?:Uncaught\s+)?([A-Za-z_$][\w$]*(?:Error|Exception))\b")
PY_ERR = re.compile(r"^([A-Za-z_][\w.]*)\s*(?::|$)")
MISS_JS = re.compile(r"\b([A-Za-z_$][\w$]*) is not defined\b")
MISS_PY = re.compile(r"name '([A-Za-z_]\w*)' is not defined")


def _name(stderr, lang):
    lines = [l for l in stderr.splitlines() if l.strip()]
    if lang == "py":
        if not lines:
            return "Error"
        m = PY_ERR.match(lines[-1].strip())
        return m.group(1).split(".")[-1] if m else "Error"
    for line in reversed(lines):
        m = NODE_ERR.match(line)
        if m:
            return m.group(1)
    return "Error"


def _missing(stderr, lang):
    m = (MISS_PY if lang == "py" else MISS_JS).search(stderr)
    return m.group(1) if m else None


def run(code, lang):
    key = hashlib.sha256((lang + "\0" + code).encode()).hexdigest()
    if key in _cache:
        return _cache[key]
    os.makedirs(ROOT, exist_ok=True)
    runs = []
    with tempfile.TemporaryDirectory(dir=ROOT) as d:
        f = os.path.join(d, {"js": "case.js", "ts": "case.ts"}.get(lang, "case.py"))
        with open(f, "w", encoding="utf-8") as fh:
            fh.write(code if code.endswith("\n") else code + "\n")
        if lang == "js":
            cmds = [["unshare", "-n", "timeout", "5", "node", f]] * 2
        elif lang == "ts":
            cmds = [["unshare", "-n", "timeout", "5", "node", "--experimental-transform-types", "--no-warnings", f]] * 2
        else:
            cmds = [["unshare", "-n", "timeout", "5", "env", "-i", f"PATH={os.environ['PATH']}", "LANG=C.UTF-8", f"PYTHONHASHSEED={n}", "python3", "-s", "-P", "-B", f] for n in range(1, 6)]
        for cmd in cmds:
            p = subprocess.run(cmd, cwd=d, stdin=subprocess.DEVNULL, capture_output=True, text=True)
            name = None if p.returncode in (0, 124) else _name(p.stderr, lang)
            runs.append((p.returncode, p.stdout, name, _missing(p.stderr, lang) if p.returncode not in (0, 124) else None))
    rc, out, name, missing = runs[0]
    lines = out.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    res = {"rc": rc, "stdout": out, "err": name, "missing": missing, "agree": len({r[:3] for r in runs}) == 1, "timeout": any(r[0] == 124 for r in runs), "runs": len(runs)}
    res["lines"] = lines + ([name] if name else [])
    _cache[key] = res
    return res


def n6(line):
    x = re.sub(r"\s+", " ", line.strip())
    x = re.sub(r"\s*([^\w\s]|_)\s*", r"\1", x)
    x = re.sub(r"['\"`]", '"', x)
    x = re.sub(r"\.$", "", x)
    return re.sub(r"\b(true|false|none|null|undefined|nan)\b", lambda m: m.group(1).lower(), x, flags=re.I)


def _strip_end_blank(lines):
    out = list(lines)
    while out and out[-1].strip() == "":
        out.pop()
    return out


QUOTED_KEY = re.compile(r"""(['"])[^'"]*\1\s*:""")
A_KEY = re.compile(r"""(['"])([A-Za-z_$][\w$]*)\1\s*:""")
JOINS = [", ", " ", "과 ", "와 ", " 그리고 ", " → "]


def a_lines_same(answer, result_lines, lang):
    res = _strip_end_blank(result_lines)
    a = [("" if l.strip() == "(빈 줄)" else l) for l in answer.split("\n")]
    a = _strip_end_blank(a) if len(a) > 1 else a
    is_key = lang == "js" and not any(QUOTED_KEY.search(r) for r in res)

    def a_norm(line, ref):
        x = line.strip()
        r = (ref or "").strip()
        is_ref_quoted = len(r) >= 2 and r[0] in "'\"`" and r[-1] in "'\"`"
        if not is_ref_quoted and len(x) >= 2 and x[0] == x[-1] and x[0] in "'\"`":
            x = x[1:-1]
        if is_key:
            x = A_KEY.sub(r"\2:", x)
        return n6(x)

    if len(a) == len(res) and all(a_norm(x, r) == n6(r) for x, r in zip(a, res)):
        return True
    if len(res) > 1 and len(a) == 1:
        for j in JOINS:
            joined = j.join(res)
            if a_norm(a[0], joined) == n6(joined):
                return True
    return False


def same8(result_lines, learner_lines, has_err):
    """Stance 8: 'a' / 'b' / 'c' when the result is the same as the learner's (a miss), None when it differs."""
    res = _strip_end_blank(result_lines)
    lrn = [n6(x) for x in _strip_end_blank(learner_lines)]
    n = [None if (has_err and i == len(res) - 1) else n6(x) for i, x in enumerate(res)]
    if has_err and len(n) == 1:
        return None
    if n == lrn:
        return "a"
    if any(lrn[i:i + len(n)] == n for i in range(len(lrn) - len(n) + 1)):
        return "b"
    if len(n) <= len(lrn) and all(n[i] == lrn[i] for i in range(len(n))):
        return "c"
    return None


DECL_JS = [r"\b(?:const|let|var|function|class)\s+{n}\b", r"(?<![=!<>.\w$]){n}\s*(?:=(?!=)|\+=|-=|\*=|/=|%=|\+\+|--)",
           r"\bfunction\b[^(]*\(([^)]*\b{n}\b[^)]*)\)", r"\(([^()]*\b{n}\b[^()]*)\)\s*=>", r"(?<![\w$.]){n}\s*=>",
           r"\bfor\s*\(\s*(?:const|let|var)?\s*[\[{{]?[^;)]*\b{n}\b[^;)]*\s(?:of|in)\s", r"\bcatch\s*\(\s*{n}\b",
           r"\b(?:const|let|var)\s*[\[{{][^=]*\b{n}\b[^=]*[\]}}]\s*="]
DECL_PY = [r"^\s*{n}\s*(?:=(?!=)|\+=|-=|\*=|/=|//=|%=|:)", r"^\s*(?:[\w.]+\s*,\s*)*{n}\s*(?:,\s*[\w.]+\s*)*=(?!=)",
           r"\bdef\s+{n}\b", r"\bclass\s+{n}\b", r"\bdef\s+\w+\s*\(([^)]*\b{n}\b[^)]*)\)", r"\bfor\s+[^:]*\b{n}\b[^:]*\s+in\s",
           r"\bexcept\b[^:]*\bas\s+{n}\b", r"\blambda\s+[^:]*\b{n}\b[^:]*:", r"\bwith\b[^:]*\bas\s+{n}\b", r"\bimport\b.*\b{n}\b", r"\(\s*{n}\s*:="]


def declared(name, code, lang):
    """Stance 7 (ㄹ): the name is declared, assigned, a parameter, a for variable or a catch variable in the block."""
    pats = DECL_PY if lang == "py" else DECL_JS
    n = re.escape(name)
    return any(re.search(p.format(n=n), code, flags=re.M) for p in pats)


if __name__ == "__main__":
    print(json.dumps(run(open(sys.argv[2], encoding="utf-8").read(), sys.argv[1]), ensure_ascii=False, indent=1))
