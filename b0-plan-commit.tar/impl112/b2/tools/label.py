"""learn-notes 1.12.0 G2 (batch 2): blind label (M-8; plan commonPerBatch step 5). One measured model, one label.
  seal          after stage/quiz/haiku/DONE: draws the label at random from A and B (secrets), writes judge/pair.json
                {label: model, nonce} chmod 444 and prints its sha256 alone (sealed until every verdict file is frozen);
                writes judge/label.txt (the label alone).
  read          judge/<L>/read.json from the stage's final replies (tools/read.mjs); named by the label, no model field.
  open          after judge/<L>/verdicts-1.json, verdicts-2.json and tally.json exist (chmod 444): prints the pair.
No file written before 'open' names the model next to the label (batch 1 audit lesson 1)."""
import hashlib, json, os, secrets, subprocess, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2"
J = os.environ.get("JUDGE", f"{S}/judge")
STAGE = os.environ.get("STAGE", f"{S}/stage/quiz/haiku")
FROZEN = os.environ.get("FROZEN", f"{S}/frozen")
mode = sys.argv[1]
if mode == "seal":
    if not os.path.exists(f"{STAGE}/DONE"):
        sys.exit("refuse: the stage is not DONE")
    if os.path.exists(f"{J}/pair.json"):
        sys.exit("refuse: judge/pair.json exists")
    os.makedirs(J, exist_ok=True)
    label = secrets.choice(["A", "B"])
    body = json.dumps({label: "haiku", "nonce": secrets.token_hex(16)}) + "\n"
    open(f"{J}/pair.json", "w").write(body)
    os.chmod(f"{J}/pair.json", 0o444)
    open(f"{J}/label.txt", "w").write(label + "\n")
    os.chmod(f"{J}/label.txt", 0o444)
    print("pair.json sha256", hashlib.sha256(body.encode()).hexdigest())
elif mode == "read":
    label = open(f"{J}/label.txt").read().strip()
    os.makedirs(f"{J}/{label}", exist_ok=True)
    subprocess.run(["node", "--experimental-transform-types", "--no-warnings", f"{S}/tools/read.mjs", STAGE, FROZEN, f"{J}/{label}/read.json"], check=True)
elif mode == "open":
    label = open(f"{J}/label.txt").read().strip()
    need = [f"{J}/{label}/verdicts-1.json", f"{J}/{label}/verdicts-2.json", f"{J}/{label}/tally.json"]
    if not all(os.path.exists(p) and os.stat(p).st_mode & 0o222 == 0 for p in need):
        sys.exit("refuse: the verdict files and the tally are not all frozen")
    print(open(f"{J}/pair.json").read().strip())
else:
    sys.exit("usage: label.py seal|read|open")
