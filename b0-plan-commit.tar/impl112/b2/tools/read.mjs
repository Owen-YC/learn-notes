// learn-notes 1.12.0 G2 (batch 2): stance 1 · 2 · 13, the plugin's own reading of the round's final replies. Each quiz's
// final reply is its last attempt's (stage.sh: only a 429/5xx api-error is sent again); the probe already passed it
// through fixEscapedTicks; parseQuiz(text, picks) of the committed tree (b2/mtree, the picks from frozen/build.json)
// gives the items a learner would get. Per changed slot: kept (an item with that pick's key) and, for the record only,
// changedItem's reason over the same parts parseQuiz reads (b2/jtree: mtree's notes.ts with codeAsRead · codeTokens ·
// quizParts · shownCode exported, nothing else changed; markers QHATR + CON, lastWins CON, fence-aware first).
// No output_tokens, time or cap in the output (blinding, M-8); the file is named by the label alone.
// usage: node --experimental-transform-types read.mjs <stage dir> <frozen dir> <out.json>   (refuses an existing out)
import { readFileSync, writeFileSync, existsSync, chmodSync } from 'node:fs'
import { join } from 'node:path'

const [stage, frozen, out] = process.argv.slice(2)
if (existsSync(out)) { console.log(`refuse: ${out} exists`); process.exit(1) }
const M = await import(process.env.NOTES ?? '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/mtree/hooks/notes.ts')
const J = await import(process.env.JNOTES ?? '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/jtree/hooks/notes.ts')
const B = JSON.parse(readFileSync(join(frozen, 'build.json'), 'utf8'))
const final = new Map()
for (const a of [1, 2, 3]) {
  const p = join(stage, `call-${a}`, 'out.json')
  if (!existsSync(p)) continue
  for (const r of JSON.parse(readFileSync(p, 'utf8')).results) final.set(r.id, r)
}
const quizzes = B.quizzes.map(q => {
  const r = final.get(q.id)
  const how = !r ? 'missing' : r.threw !== undefined ? 'threw' : r.isAnswered ? 'answered' : r.reason === 'api-error' ? `api-error/${r.status}` : r.reason
  const text = r && r.isAnswered ? r.text : ''
  const items = text ? M.parseQuiz(text, q.picks) : []
  const aware = text ? J.quizParts(text, true, 'QHATRCON', 'CON') : new Map()
  const slots = q.picks.map((pick, i) => {
    const item = items.find(it => it.key === pick.key) ?? null
    const slot = { place: i + 1, slot: q.slots[i].slot ?? null, id: q.slots[i].id, rung: pick.rung ?? null, kept: !!item, item }
    if (pick.rung === 'changed') {
      const made = text ? J.changedItem(aware, i + 1, pick) : { reason: how }
      slot.reason = 'item' in made ? 'ok' : made.reason
    }
    return slot
  })
  return { id: q.id, how, slots }
})
const body = JSON.stringify({ quizzes }, null, 1) + '\n'
writeFileSync(out, body)
chmodSync(out, 0o444)
for (const q of quizzes) console.log(q.id, q.how, q.slots.map(s => `${s.rung ?? '-'}:${s.rung === 'changed' ? s.reason : s.kept ? 'kept' : 'none'}`).join(' '))
