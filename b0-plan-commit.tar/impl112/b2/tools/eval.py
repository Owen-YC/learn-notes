"""learn-notes 1.12.0 G2 (batch 2): the eval tool, the stance's ⚙ clauses ('판정의 입장' of the 1.12.0 G2 section of
docs/qa/견본.md) for one label, and the judges' report. No model name, token, time or cap anywhere (M-8).
usage: eval.py <label>     reads judge/<L>/read.json, frozen/build.json, frozen/learner.json, frozen/samples.json
                           -> judge/<L>/eval.json and judge/<L>/report.md (chmod 444; refuses existing files)
Per changed slot (the 20, stance 0):
  unread (stance 2 · 13: no stored item for the slot; empty, cut, refused, api-error, changedItem gave none): (가) miss,
  outside (나).
  read: the item stored (stance 1). Its question's code (stance 3) is the content of its one fenced block (a line that
  is only ``` or ~~~ and a name opens, the same or longer closes); the language is the fence's name (js / python);
  a block with another or no name takes the learner file's language and says so in the report.
  (ㄱ) rung 'changed'. (ㅁ) kind 'predict'. (ㅂ) exactly one fenced block. (ㅈ) every run the same and none over 5 s.
  (ㄴ) both codes line by line, each line: a comment cut (js // , py #, outside strings), clause 6's n6, one ';' at
      the end cut, empty lines dropped: (i) not equal and (ii) the shown lines that are not a one-line console.log(…) /
      print(…) not a subsequence of the learner lines.
  (ㄷ) codeAsRead tokens (committed tree, tok.mjs): a learner key line (>= 4 tokens; not brackets and commas only, not
      else alone once brackets and ':' are left out, not `return name`, not console.log(name) / print(name)); with none,
      a line of >= 2 tokens) equal to a shown line or one token off it (same length and one place different, or one
      token more or less).
  (ㄹ) a result ending in ReferenceError / NameError whose missing name (runlib) is never declared, assigned, a
      parameter, a for or catch variable in the block (runlib.declared) is a miss.
  (ㅅ) clause 8 by runlib.same8 against the frozen learner result: (a)/(b)/(c) = the same = a miss.
  (ㅇ) clause 10 by tool: (i) the question starts with CHANGED_LEAD as it is and only one fenced block follows (white
      space aside); (ii) the shown code and the learner code differ in exactly one line (same number of lines);
      (iii) the hint's 'k번째 줄' is that line (the block's first line 1, empty lines counted); (iv) the hint's quoted
      text, where it quotes, equals that line with its ends trimmed. ✎: the judges confirm or not (judge.py).
  12: a ts block or file: a (가) miss; (나) against the run (runlib: node --experimental-transform-types, twice).
  (나) (stance 11): runs not the same or over 5 s -> wrong (stance 3); else runlib.a_lines_same(A, result) -> right;
  else the judges decide (✎)."""
import json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import runlib  # noqa: E402

S = os.path.dirname(HERE)
J = os.environ.get("JUDGE", f"{S}/judge")
FROZEN = os.environ.get("FROZEN", f"{S}/frozen")
FENCE = re.compile(r"^\s*(`{3,}|~{3,})([\w+.-]*)\s*$")
LANGS = {"js": "js", "javascript": "js", "python": "py", "py": "py", "ts": "ts", "typescript": "ts"}
PRINTLINE = {"js": re.compile(r"^\s*console\.log\(.*\)\s*;?\s*$"), "py": re.compile(r"^\s*print\(.*\)\s*$")}


def lead():
    src = open(os.environ.get("NOTES", f"{S}/mtree/hooks/notes.ts"), encoding="utf-8").read()
    m = re.search(r"export const CHANGED_LEAD =\s*\n\s*'([^']*)'", src)
    return m.group(1)


def blocks(q):
    out, cur, fence, name = [], None, None, None
    for line in q.split("\n"):
        m = FENCE.match(line)
        if fence is None and m:
            fence, name, cur = m.group(1), m.group(2), []
        elif fence is not None and m and m.group(1)[0] == fence[0] and len(m.group(1)) >= len(fence) and m.group(2) == "":
            out.append((name, "\n".join(cur)))
            fence, cur = None, None
        elif cur is not None:
            cur.append(line)
    return out


def uncomment(line, lang):
    q = None
    i = 0
    while i < len(line):
        ch = line[i]
        if ch == "\\":
            i += 2
            continue
        if q:
            q = None if ch == q else q
        elif ch in "'\"`":
            q = ch
        elif lang == "py" and ch == "#":
            return line[:i]
        elif lang != "py" and line.startswith("//", i):
            return line[:i]
        i += 1
    return line


def nlines(code, lang):
    out = []
    for l in code.split("\n"):
        x = runlib.n6(uncomment(l, lang))
        x = x[:-1] if x.endswith(";") else x
        if x:
            out.append(x)
    return out


def subseq(small, big):
    it = iter(big)
    return all(any(x == y for y in it) for x in small)


def toks(pairs):
    p = subprocess.run(["node", "--experimental-transform-types", "--no-warnings", f"{HERE}/tok.mjs"], input=json.dumps(pairs), capture_output=True, text=True, check=True)
    return json.loads(p.stdout)


def is_key(t):
    if all(x in "()[]{}," for x in t):
        return False
    if [x for x in t if x not in "()[]{}:"] == ["else"]:
        return False
    if len(t) == 2 and t[0] == "return" and re.match(r"^[A-Za-z_$][\w$]*$", t[1]):
        return False
    if t[:4] == ["console", ".", "log", "("] and len(t) == 6 and t[-1] == ")" or (t[:2] == ["print", "("] and len(t) == 4 and t[-1] == ")"):
        return False
    return True


def near(a, b):
    if a == b:
        return True
    if len(a) == len(b):
        return sum(x != y for x, y in zip(a, b)) == 1
    if abs(len(a) - len(b)) == 1:
        s, l = (a, b) if len(a) < len(b) else (b, a)
        return any(l[:i] + l[i + 1:] == s for i in range(len(l)))
    return False


HINT = re.compile(r"바뀐 곳은 (\d+)번째 줄(?: (`+) ?(.*?) ?\2)?입니다\.")


def main():
    label = sys.argv[1]
    d = f"{J}/{label}"
    for f in ("eval.json", "report.md"):
        if os.path.exists(f"{d}/{f}"):
            sys.exit(f"refuse: {d}/{f} exists")
    read = json.load(open(f"{d}/read.json", encoding="utf-8"))
    learner = json.load(open(f"{FROZEN}/learner.json", encoding="utf-8"))
    LEAD = lead()
    rows = []
    for q in read["quizzes"]:
        for s in q["slots"]:
            if s["rung"] != "changed":
                continue
            L = learner[s["slot"]]
            row = {"slot": s["slot"], "quiz": q["id"], "place": s["place"], "how": q["how"], "read": s["kept"], "reason": s.get("reason")}
            if not s["kept"]:
                row.update({"ga_tool": False, "ga_miss": ["2"], "na": "outside"})
                rows.append(row)
                continue
            it = s["item"]
            qtext, hint, ans = it["question"], it.get("hint") or "", it["answer"]
            bl = blocks(qtext)
            name, shown = (bl[0] if bl else (None, ""))
            lang = LANGS.get((name or "").lower()) or L["lang"]
            row.update({"question": qtext, "hint": hint, "answer": ans, "kind": it.get("kind"), "rung": it.get("rung"), "fence": name, "lang": lang, "learner_code": L["code"], "learner_result": L["lines"], "shown": shown})
            cl = {}
            cl["ㄱ"] = it.get("rung") == "changed"
            cl["ㅁ"] = it.get("kind") == "predict"
            cl["ㅂ"] = len(bl) == 1
            if lang == "ts":
                row.update({"ga_tool": False, "ga_miss": ["12"], "clauses": cl})
            run = runlib.run(shown, lang if lang in ("py", "ts") else "js")
            row["run"] = {"lines": run["lines"], "agree": run["agree"], "timeout": run["timeout"]}
            cl["ㅈ"] = run["agree"] and not run["timeout"]
            ln, sn = nlines(L["code"], lang), nlines(shown, lang)
            nonprint = [n for raw in shown.split("\n") for n in nlines(raw, lang) if not PRINTLINE[lang if lang in PRINTLINE else "js"].match(raw)]
            cl["ㄴ"] = ln != sn and not subseq(nonprint, ln)
            tl, ts = toks([[L["code"], f"a.{lang}"], [shown, f"a.{lang}"]])
            keys = [t for t in tl if len(t) >= 4 and is_key(t)] or [t for t in tl if len(t) >= 2]
            cl["ㄷ"] = any(near(k, t) for k in keys for t in ts)
            cl["ㄹ"] = not (run["err"] in ("ReferenceError", "NameError") and run["missing"] and not runlib.declared(run["missing"], shown, lang))
            cl["ㅅ"] = runlib.same8(run["lines"], L["lines"], bool(run["err"])) is None if cl["ㅈ"] else False
            ol, sl = L["code"].split("\n"), shown.split("\n")
            diff = [i for i, (a, b) in enumerate(zip(ol, sl)) if a != b] if len(ol) == len(sl) else None
            m = HINT.search(hint)
            after = qtext[len(LEAD):] if qtext.startswith(LEAD) else None
            ten = {"i": qtext.startswith(LEAD) and len(bl) == 1 and bool(re.fullmatch(r"\s*(`{3,}|~{3,})[\w+.-]*\n[\s\S]*\n\s*\1\s*", after or "")),
                   "ii": diff is not None and len(diff) == 1,
                   "iii": bool(m) and diff is not None and len(diff) == 1 and int(m.group(1)) == diff[0] + 1,
                   "iv": bool(m) and diff is not None and len(diff) == 1 and (m.group(3) is None or m.group(3) == sl[diff[0]].strip())}
            row["ten"] = ten
            cl["ㅇ"] = all(ten.values())
            row["clauses"] = cl
            if lang != "ts":
                row["ga_tool"] = all(cl.values())
                row["ga_miss"] = [k for k, v in cl.items() if not v]
            if not cl["ㅈ"]:
                row["na"] = "wrong"
                row["na_by"] = "3"
            elif runlib.a_lines_same(ans, run["lines"], "py" if lang == "py" else "js"):
                row["na"] = "right"
                row["na_by"] = "6 · 11 (tool)"
            else:
                row["na"] = "judge"
            rows.append(row)
    os.makedirs(d, exist_ok=True)
    open(f"{d}/eval.json", "w", encoding="utf-8").write(json.dumps({"label": label, "rows": rows}, ensure_ascii=False, indent=1) + "\n")
    os.chmod(f"{d}/eval.json", 0o444)
    md = [f"# 꼬리표 {label}: 비슷한 코드 자리 {len(rows)}개 (도구 결과)", "", "도구(⚙)가 센 것과 판정자(✎)가 볼 것을 자리마다 적었습니다. 모델 이름 · 토큰 · 시간은 없습니다.", ""]
    for r in rows:
        md.append(f"## {r['slot']} ({r['quiz']}의 {r['place']}번째 자리)")
        if not r["read"]:
            md += ["", f"- 읽힌 문항 없음(조항 2 · 13). (가) 놓침, (나) 셈 밖. 판정자는 이 자리를 적지 않습니다.", ""]
            continue
        md += ["", "### 학습자 코드(학습자 조각 = 파일 전체)", "```", r["learner_code"], "```", "학습자 결과(조항 3, 얼린 것):", "```", "\n".join(r["learner_result"]), "```",
               "### 저장된 문항", "question:", "````", r["question"], "````", "hint:", "````", r["hint"], "````", "answer(A):", "````", r["answer"], "````",
               f"kind {r['kind']} · rung {r['rung']} · 펜스 이름 {r['fence']!r} → 언어 {r['lang']}",
               "### 보인 코드를 돌린 결과(조항 3)", "```", "\n".join(r["run"]["lines"]), "```", f"여러 번 돌린 결과가 모두 같음: {r['run']['agree']} · 5초 넘음: {r['run']['timeout']}",
               "### 도구(⚙)", "- 조항 7: " + " · ".join(f"({k}) {'예' if v else '아니오'}" for k, v in r["clauses"].items()),
               "- 조항 10: " + " · ".join(f"({k}) {'예' if v else '아니오'}" for k, v in r["ten"].items()),
               f"- (가) 도구 결과: {'⚙ 모두 갖춤' if r['ga_tool'] else '놓침(' + ', '.join(r['ga_miss']) + ')'}",
               f"- (나) 도구 결과: " + ({"right": f"맞음({r.get('na_by')})", "wrong": f"틀림({r.get('na_by')})", "judge": "도구가 같다고 하지 못함 → 판정자가 조항 11로 매김"}[r["na"]]), ""]
    open(f"{d}/report.md", "w", encoding="utf-8").write("\n".join(md) + "\n")
    os.chmod(f"{d}/report.md", 0o444)
    print(json.dumps({"slots": len(rows), "read": sum(r["read"] for r in rows), "ga_tool": sum(1 for r in rows if r.get("ga_tool")), "na": {k: sum(1 for r in rows if r["na"] == k) for k in ("right", "wrong", "judge", "outside")}}, ensure_ascii=False))


if __name__ == "__main__":
    main()
