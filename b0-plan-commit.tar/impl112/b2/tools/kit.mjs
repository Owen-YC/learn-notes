// learn-notes 1.12.0 G2 (batch 2): the plugin side of a record, made with the committed tree's notes.ts (b2/mtree, the
// build commit 3f9084c; NOTES env to point elsewhere, for a tool test only). Rebuilt from the design pilot's build.mjs.
// - readConcept(rec): the record's name and blurb as the plugin reads them from a note (conceptsOf over the note answer the
//   D34 test gives: '### 배울 개념' then '- **name**: blurb'); check.py refuses a record whose read form differs.
// - changeFor(rec): changeOf of a Write create (creationHunk of the code) for a whole file, of an Edit (one -U3 hunk
//   around the changed run) for a filler edit, at /proj/<file>.
// - pickOf(rec, step, extra): a quiz pick as makeQuiz's withCode makes it (codeFor's lines; isWhole by isWholeShown,
//   isLibrary · isImporting where code changed could ask, at step `step`).
// - quizOf(slots, recs): rungOf with haiku's G2 cell on top of batch 1's haiku row (changedStep 2; newStep, workedAfter,
//   workedPlainAfter Infinity: their cells are off in that row), ladderMixed, pickForRung, quizPrompt(picks,
//   'beginner') through redactText, maxTokens QUIZ_TRACE_TOKENS when a pick is changed/new/worked else QUIZ_TOKENS as
//   register.tsx picks it (the expression and both constants read from the tree's register.tsx text, not written here),
//   system QUIZ_SYSTEM.
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'

export const TREE = process.env.TREE ?? '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/mtree'
export const N = await import(process.env.NOTES ?? join(TREE, 'hooks/notes.ts'))
const REG = readFileSync(join(dirname(process.env.NOTES ?? join(TREE, 'hooks/notes.ts')), 'register.tsx'), 'utf8')
if (!REG.includes('maxTokens: isLong ? QUIZ_TRACE_TOKENS : QUIZ_TOKENS')) throw new Error('register.tsx: the quiz cap expression is not as read')
const num = name => Number(new RegExp(`\\nconst ${name} = ([\\d_]+)\\n`).exec(REG)[1].replace(/_/g, ''))
export const QUIZ_TRACE_TOKENS = num('QUIZ_TRACE_TOKENS')
export const QUIZ_TOKENS = num('QUIZ_TOKENS')
export const NOW = Date.UTC(2026, 9, 3, 1)
const DAY = 86_400_000

export const noteAnswer = rec => ['### 한 줄 요약', '만들었습니다', '### 배울 개념', `- **${rec.name}**: ${rec.blurb}`, '### 직접 확인해 볼 것', '- 실행해 보기'].join('\n')
export function readConcept(rec) {
  const got = N.conceptsOf(noteAnswer(rec))
  return got.length === 1 ? { name: got[0].name, blurb: got[0].blurb, key: got[0].key } : undefined
}

export function hunkOf(before, after) {
  const a = before.replace(/\n$/, '').split('\n'), b = after.replace(/\n$/, '').split('\n')
  let s = 0
  while (s < a.length && s < b.length && a[s] === b[s]) s++
  let ea = a.length - 1, eb = b.length - 1
  while (ea >= s && eb >= s && a[ea] === b[eb]) { ea--; eb-- }
  const from = Math.max(0, s - 3), toA = Math.min(a.length - 1, ea + 3), toB = Math.min(b.length - 1, eb + 3)
  const lines = [...a.slice(from, s).map(l => ' ' + l), ...a.slice(s, ea + 1).map(l => '-' + l), ...b.slice(s, eb + 1).map(l => '+' + l), ...a.slice(ea + 1, toA + 1).map(l => ' ' + l)]
  return { oldStart: from + 1, oldLines: toA - from + 1, newStart: from + 1, newLines: toB - from + 1, lines }
}

export function changeFor(rec) {
  const path = `/proj/${rec.file}`
  if (rec.before !== undefined) return N.changeOf({ path, root: '/proj', tool: 'Edit', kind: 'update', hunks: [hunkOf(rec.before, rec.after)] })
  return N.changeOf({ path, root: '/proj', tool: 'Write', kind: 'create', hunks: [N.creationHunk(rec.code)] })
}

export function pickOf(rec, step, extra = {}) {
  const read = readConcept(rec) ?? { name: rec.name, blurb: rec.blurb, key: N.conceptKey(rec.name) }
  const base = { key: read.key, name: read.name, count: 3, firstAt: NOW - 60 * DAY, lastAt: NOW - 60 * DAY, blurb: read.blurb, files: [], step, reviewedAt: NOW - 30 * DAY, noteId: `note-${rec.id}` }
  if (rec.code === undefined && rec.after === undefined) return { ...base, ...extra }
  const change = changeFor(rec)
  const text = N.codeFor(change, read.blurb)
  if (!text) return { ...base, ...extra }
  const isChanged = change.kind === 'create' && N.isChangedAskable({ ...base }, change.file, 2)
  const isWhole = isChanged && N.isWholeShown(change, text)
  const isLibrary = isChanged && N.isUnrunnableChange(change, undefined)
  const isImporting = isChanged && N.isImportingChange(change, undefined)
  const code = { file: N.baseName(change.file), text, ...(isLibrary ? { isLibrary: true } : {}), ...(isImporting ? { isImporting: true } : {}), ...(isWhole ? { isWhole: true } : {}) }
  return { ...base, code, ...extra }
}

export const STEPS = { changedStep: 2, workedAfter: Infinity, workedPlainAfter: Infinity }
export function rungAlone(one, slot = {}) {
  return N.rungOf(one, { ...(one.code ? { code: one.code } : {}), ...(slot.slip ? { slip: { times: 1 } } : {}), isAsking: slot.slip === true, isTeam: false, isDue: true }, Infinity, STEPS)
}

export function quizOf(slots, recs) {
  const laid = slots.map(s => pickOf(recs[s.id], s.step, s.slip ? { slip: recs[s.id].slip } : {}))
  const rungs = laid.map((one, i) => rungAlone(one, slots[i]))
  const asIs = N.ladderMixed(rungs, laid)
  const picks = laid.map((one, i) => N.pickForRung(one, asIs[i]))
  const isLong = picks.some(one => one.rung === 'changed' || one.rung === 'new' || one.rung === 'worked')
  const red = N.redactText(N.quizPrompt(picks, 'beginner'))
  return { picks, rungsAlone: rungs, rungs: asIs, prompt: red.text, redactHits: red.hits, maxTokens: isLong ? QUIZ_TRACE_TOKENS : QUIZ_TOKENS }
}
