#!/bin/bash
# b2 ON-byte check (record only): runs the G2 and G3 design pilot tools (build, read, grade) on every recorded dev set
# with the notes.ts given, into $S/onb/<name>. Compare two names with onbcmp.py.
# usage: onbytes.sh <name> <g2-side notes.ts> <g3-side notes.ts>
set -u
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2
D=$S/../design
name=$1; N2=$2; N3=$3
O="${S:?}/onb/$name"; rm -rf "${O:?}"; mkdir -p "$O"
NODE="node --experimental-transform-types --no-warnings"
for n in 1 2 3 4 5; do
  d=$O/g2set$n; mkdir -p $d; cp $D/G2/dev/set$n/samples.json $D/G2/dev/set$n/layout.json $d/
  $NODE $D/G2/pilot/build.mjs $d $N2 > $d/build.log 2>&1
  for m in haiku sonnet; do [ -f $D/G2/pilot/set$n/$m/out.json ] && NOTES=$N2 $NODE $D/G2/pilot/read.mjs $d $m $D/G2/pilot/set$n/$m/out.json > $d/read-$m.log 2>&1; done
done
for n in 1 2; do
  d=$O/g3set$n; mkdir -p $d/calls; cp $D/G3/dev/set$n/A.json $D/G3/dev/set$n/B.json $D/G3/dev/set$n/layout.json $d/; [ -f $D/G3/dev/set$n/pair.txt ] && cp $D/G3/dev/set$n/pair.txt $d/
  day=$(python3 -c "import json;print(json.load(open('$D/G3/dev/set$n/build.json'))['day'])")
  $NODE $D/G3/pilot/build.mjs $d $day $N3 > $d/build.log 2>&1
  for l in X Y; do ln -s $D/G3/dev/set$n/calls/$l $d/calls/$l; $NODE $D/G3/pilot/read.mjs $d $l $N3 > $d/read-$l.log 2>&1; done
done
$NODE $S/tools/g3grade.mjs $N3 $O/g3grade.json > $O/g3grade.log 2>&1
echo done $name
