// b2 ON-byte check (record only): G3 exact-grade requests and readings, from the recorded design grade plans, with the notes.ts given.
// usage: node --experimental-transform-types g3grade.mjs <notes.ts> <out.json>
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'
const [notes, outFile] = process.argv.slice(2)
const P = await import(notes)
const G = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/design/G3'
const rows = []
for (const dir of [join(G, 'final/set2'), join(G, 'final/probe')]) for (const label of ['X', 'Y']) for (const stage of ['1', '2']) {
  const pf = join(dir, `grade-${label}-f-${stage}.plan.json`), itf = join(dir, `items-${label}.json`)
  if (!existsSync(pf) || !existsSync(itf)) continue
  const W = JSON.parse(readFileSync(itf, 'utf8')), plan = JSON.parse(readFileSync(pf, 'utf8'))
  const outF = join(dir, 'calls', `grade-${label}-f-${stage}`, 'out.json')
  const res = existsSync(outF) ? Object.fromEntries(JSON.parse(readFileSync(outF, 'utf8')).results.map(r => [r.id, r])) : {}
  for (const p of plan) {
    const item = W.find(w => w.key === p.key).item
    const local = P.localRight(p.mine, item.answer)
    const prompt = local ? null : P.checkPrompt(item, p.mine, 'beginner', p.first, undefined, { exact: true })
    const stock = P.checkPrompt(item, p.mine, 'beginner', p.first, undefined, {})
    const r = res[p.id]
    const read = r && r.isAnswered ? [P.parseCheck(r.text, { exact: item.answer, mine: p.mine }), P.parseCheck(r.text, { exact: item.answer }), P.parseCheck(r.text, {})] : null
    rows.push({ id: `${dir.split('/').pop()}/${label}/${stage}/${p.id}`, local, prompt, stock, read, shown: P.answerShown(item) })
  }
}
writeFileSync(outFile, JSON.stringify(rows, null, 1) + '\n')
console.log('g3grade rows', rows.length)
