"""learn-notes 1.12.0 G2 (batch 2): machine counts of the quiz stage by label (M-8: the judges never get this file).
Per attempt: calls and how each ended; final per quiz (its last attempt); api-errors sent again; cap hits
(output_tokens >= maxTokens + H_haiku, 4600 + 2048 = 6648, '보정 기록 (1.12.0)'); output_tokens largest and median;
time (ms) largest and median; the tap's refusals (record only, own column).
usage: count.py <label>   -> judge/count-<L>.json (chmod 444; refuses an existing one)"""
import json, os, statistics, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2"
J = os.environ.get("JUDGE", f"{S}/judge")
STAGE = os.environ.get("STAGE", f"{S}/stage/quiz/haiku")
H = 2048
label = sys.argv[1]
out = f"{J}/count-{label}.json"
if os.path.exists(out):
    sys.exit(f"refuse: {out} exists")
attempts, final = [], {}
for a in (1, 2, 3):
    p = f"{STAGE}/call-{a}/out.json"
    if not os.path.exists(p):
        continue
    rs = json.load(open(p, encoding="utf-8"))["results"]
    hows = {}
    for r in rs:
        how = "threw" if "threw" in r else "answered" if r.get("isAnswered") else r.get("reason")
        if how == "api-error":
            how += f"/{r.get('status')}"
        hows[how] = hows.get(how, 0) + 1
        final[r["id"]] = r
    attempts.append({"attempt": a, "calls": len(rs), "how": hows})
toks = [(r.get("usage") or {}).get("output_tokens") for r in final.values()]
toks = [t for t in toks if isinstance(t, int)]
ms = [r.get("ms") for r in final.values() if isinstance(r.get("ms"), int)]
caps = sorted(r["id"] for r in final.values() if isinstance((r.get("usage") or {}).get("output_tokens"), int) and r["usage"]["output_tokens"] >= r["maxTokens"] + H)
tap = json.load(open(f"{STAGE}/tap-quiz.json", encoding="utf-8")) if os.path.exists(f"{STAGE}/tap-quiz.json") else {"empty": [], "sent": {}}
fh = {}
for r in final.values():
    how = "answered" if r.get("isAnswered") else r.get("reason")
    fh[how] = fh.get(how, 0) + 1
res = {"label": label, "attempts": attempts, "final": fh, "resent": sum(x["calls"] for x in attempts[1:]), "capHits": caps, "capAt": 4600 + H,
       "outputTokens": {"max": max(toks) if toks else None, "median": statistics.median(toks) if toks else None},
       "ms": {"max": max(ms) if ms else None, "median": statistics.median(ms) if ms else None},
       "empty": len(tap["empty"]), "refusals": sum(1 for v in tap["sent"].values() if v.get("stop_reason") == "refusal")}
open(out, "w", encoding="utf-8").write(json.dumps(res, indent=1) + "\n")
os.chmod(out, 0o444)
print(json.dumps(res))
