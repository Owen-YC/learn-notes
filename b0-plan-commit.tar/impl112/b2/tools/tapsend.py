"""learn-notes 1.12.0 G2 (batch 2; from batch 1's tapsend.py; record only, B-12, SCOPE's batch-3 fact): after the quiz
stage, each empty reply (reason empty-reply) of any attempt is sent once more, its frozen line as it is, through the
local pass-through tap (tap/call.sh through cli/pinned.sh), to record whether the API refused it (stop_reason,
stop_details). It never enters a count or a decision and no answer text is read or kept (the tap keeps lengths and
sha256 alone); refusals are their own column (count.py).
usage: tapsend.py quiz haiku   -> stage/quiz/haiku/tap-quiz.json (chmod 444)"""
import hashlib, json, os, subprocess, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2"
P = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh"
sha = lambda text: hashlib.sha256(text.encode("utf-8")).hexdigest()
st, m = sys.argv[1:3]
if (st, m) != ("quiz", "haiku"):
    sys.exit("usage: tapsend.py quiz haiku")
d = f"{S}/stage/{st}/{m}"
out_path = f"{d}/tap-quiz.json"
if os.path.exists(out_path):
    sys.exit(f"refuse: {out_path} exists")
lines = {json.loads(x)["id"]: json.loads(x) for x in open(f"{S}/frozen/lines-{m}.jsonl", encoding="utf-8") if x.strip()}
empty = []
for a in (1, 2, 3):
    p = f"{d}/call-{a}/out.json"
    if os.path.exists(p):
        empty += [r["id"] for r in json.load(open(p, encoding="utf-8"))["results"] if r.get("reason") == "empty-reply"]
rec = {"stage": st, "empty": empty, "sent": {}}
if empty:
    t = f"{d}/tap-quiz"
    os.makedirs(t, exist_ok=True)
    tl = f"{t}/tap-lines.jsonl"
    with open(tl, "w", encoding="utf-8") as f:
        for i in empty:
            f.write(json.dumps(lines[i], ensure_ascii=False) + "\n")
    subprocess.run([P, "bash", f"{S}/tap/call.sh", t, m, tl], check=False)
    seen = [json.loads(x) for x in open(f"{t}/tap.jsonl", encoding="utf-8")] if os.path.exists(f"{t}/tap.jsonl") else []
    for i in empty:
        want = sha(lines[i]["prompt"])
        hits = [s for s in seen if any(u.get("sha256") == want for u in (s.get("request") or {}).get("user_texts", []))]
        last = hits[-1] if hits else None
        rec["sent"][i] = {"matched": len(hits), **({k: last.get(k) for k in ("status", "stop_reason", "stop_details", "output_tokens", "error_type", "tap_error")} if last else {})}
body = json.dumps(rec, ensure_ascii=False, indent=1) + "\n"
open(out_path, "w", encoding="utf-8").write(body)
os.chmod(out_path, 0o444)
print(json.dumps({"stage": st, "empty": len(empty), "refusals": sum(1 for v in rec["sent"].values() if v.get("stop_reason") == "refusal"), "sha256": sha(body)}))
