#!/usr/bin/env python3
"""Build impl112/NAMES-all.txt (learn-notes 1.12.0, plan calibration.namesRegistry).

usage: python3 -I build.py <repo>/docs/qa/견본.md <out>
Line form: <name> TAB <tag> TAB <source>, tag in {G<n>-dev, G<n>-measured, 견본}; source = the file the name came
from (relative to the scratchpad dir). Sorted in byte order, duplicate lines dropped. Model calls: none.
"""
import glob, json, os, re, subprocess, sys, unicodedata

SP = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad'
I = SP + '/impl112'
D = I + '/design'
rows = set()

def clean(s):
    s = unicodedata.normalize('NFC', s).replace('\t', ' ').strip()
    return re.sub(r'\s+', ' ', s)

def add(name, tag, src):
    name = clean(name)
    if name:
        rows.add((name, tag, os.path.relpath(src, SP)))

def tsv(path, tag, cols):
    for line in open(path, encoding='utf-8').read().split('\n'):
        if not line.strip() or line.startswith('#'):
            continue
        parts = line.split('\t')
        for c in cols:
            if c < len(parts):
                add(parts[c], tag, path)

def expand(a, b):
    m1, m2 = re.fullmatch(r'([A-Z]+)(\d+)', a), re.fullmatch(r'([A-Z]+)(\d+)', b)
    assert m1 and m2 and m1.group(1) == m2.group(1), (a, b)
    w = len(m1.group(2))
    return [m1.group(1) + str(k).zfill(w) for k in range(int(m1.group(2)), int(m2.group(2)) + 1)]

# G1
tsv(D + '/G1/dev/NAMES.txt', 'G1-dev', (0, 1, 2))
p = D + '/G1/proto/gen/names.ts.txt'
for m in re.finditer(r"wordSet\('([^']*)'\)", open(p, encoding='utf-8').read()):
    for w in m.group(1).split():
        add(w, 'G1-dev', p)
# G2
tsv(D + '/G2/dev/NAMES.txt', 'G2-dev', (0, 1, 2))
for p in sorted(glob.glob(D + '/G2/dev/req/*.txt')):
    m = re.search(r'Do not use these concepts[^:\n]*:([^\n]*)', open(p, encoding='utf-8').read())
    lst = m.group(1).strip()
    lst = lst[:-1] if lst.endswith('.') else lst
    for w in lst.split(', '):
        add(w, 'G2-dev', p)
# G3
tsv(D + '/G3/dev/NAMES.txt', 'G3-dev', (0, 1, 2))
p = D + '/G3/final/probe/items-X.json'
for it in json.load(open(p, encoding='utf-8')):
    add(it['key'], 'G3-dev', p)
    add(it['item']['name'], 'G3-dev', p)
# G4
p = D + '/G4/dev/NAMES.txt'
for line in open(p, encoding='utf-8').read().split('\n'):
    if line.strip() and not line.startswith('#'):
        add(line, 'G4-dev', p)
# G5
p = D + '/G5/dev/NAMES.txt'
for line in open(p, encoding='utf-8').read().split('\n'):
    if not line.strip() or line.startswith('#'):
        continue
    m = re.fullmatch(r'ids (\w+)-(\w+)', line.strip())
    if m:
        for x in expand(m.group(1), m.group(2)):
            add(x, 'G5-dev', p)
        continue
    head, sep, rest = line.partition(': ')
    assert sep, line
    for w in rest.split():
        add(w, 'G5-dev', p)
p = D + '/G5/dev/cov/changes.json'
for c in json.load(open(p, encoding='utf-8')):
    add(c['id'], 'G5-dev', p)
    for f in c.get('files') or []:
        add(f['path'], 'G5-dev', p)
p = SP + '/impl111/b7/gen/names.json'
k = json.load(open(p, encoding='utf-8'))
for x in expand('K01', 'K37'):
    add(x, 'G5-measured', p)
for w in k['files'] + k['functions']:
    add(w, 'G5-measured', p)
# G6
for s in (1, 2, 3, 4):
    p = D + f'/G6/dev/set{s}/names.txt'
    for line in open(p, encoding='utf-8').read().split('\n'):
        if line.strip() and not line.startswith('#'):
            add(line, 'G6-dev', p)
p = D + '/G6/dev/gen/set4-part-A.md'
m = re.search(r'아래 이름도 피한다\([^)]*\): ([^\n]*)', open(p, encoding='utf-8').read())
lst = m.group(1).strip()
lst = lst[:-1] if lst.endswith('.') else lst
g6avoid = [w for w in lst.split(', ') if w.strip()]
for w in g6avoid:
    add(w, 'G6-dev', p)
# 견본.md
src = sys.argv[1]
ex = subprocess.run([sys.executable, '-I', I + '/names/extract.py', src], check=True, capture_output=True).stdout.decode('utf-8')
for w in ex.split('\n'):
    if w:
        rows.add((clean(w), '견본', 'learn-notes/docs/qa/견본.md'))

lines = sorted({f'{a}\t{b}\t{c}' for a, b, c in rows}, key=lambda s: s.encode('utf-8'))
with open(sys.argv[2], 'wb') as f:
    for l in lines:
        f.write(l.encode('utf-8') + b'\n')
by = {}
for a, b, c in rows:
    by[b] = by.get(b, 0) + 1
print(json.dumps({'lines': len(lines), 'distinctNames': len({a for a, _, _ in rows}), 'byTag': dict(sorted(by.items())), 'g6AvoidList': len(g6avoid)}, ensure_ascii=False))
