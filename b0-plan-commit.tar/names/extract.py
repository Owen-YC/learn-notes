#!/usr/bin/env python3
"""Extract every sample name / id / file path from docs/qa/견본.md (learn-notes 1.12.0, calibration.namesRegistry).

usage: python3 -I extract.py <견본.md>   -> prints one name per line (sorted, unique, LC_ALL=C byte order)

Rules (deterministic; over-inclusion is the safe side for an avoid list):
  P  file names and paths: a token ending in a code/data extension, with any leading directories
  N  'ID name (' : an id (1-3 capitals, 1-3 digits, optional lower letter) followed by a name and an opening paren
  Q  'ID(name)'  : an id immediately followed by a parenthesised name
  I  ids: every id captured by N or Q, and every id range 'X01–X24' / 'X1~X6' expanded (same prefix)
  T  sample tables whose header's first cell is '개념' or '변경': the first cell of each row split on ' · '
     (a leading '흐름 있음: ' style label and backticks dropped)
  A captured N/Q name that ends with '.' (a sentence, not a name) is dropped.
"""
import re, sys, unicodedata

EXT = r'(?:js|mjs|cjs|jsx|ts|tsx|py|sh|json|css|html|md|go|rb|vue|txt|yml|yaml|toml|env)'
P = re.compile(r'(?<![\w./-])((?:[\w.-]+/)*[\w.-]*\w\.' + EXT + r')(?![\w])')
ID = r'[A-Z]{1,3}\d{1,3}[a-z]?'
N = re.compile(r'(?<![\w-])(' + ID + r')\s+([^()|·,;:`*\n]{2,40}?)\s*\(')
Q = re.compile(r'(?<![\w-])(' + ID + r')\(([^()|`*\n]{2,40})\)')
R = re.compile(r'(?<![\w-])([A-Z]{1,3})(\d{1,3})\s*[–~]\s*\1(\d{1,3})(?![\w])')

def clean(s):
    s = unicodedata.normalize('NFC', s).replace('\t', ' ').strip()
    return re.sub(r'\s+', ' ', s)

def main(path):
    text = open(path, encoding='utf-8').read()
    out = set()
    for m in P.finditer(text):
        out.add(clean(m.group(1)))
    for rx in (N, Q):
        for m in rx.finditer(text):
            out.add(clean(m.group(1)))
            name = clean(m.group(2))
            if len(name) >= 2 and not name.endswith('.'):
                out.add(name)
    for m in R.finditer(text):
        pre, a, b = m.group(1), m.group(2), m.group(3)
        lo, hi = int(a), int(b)
        if lo <= hi and hi - lo <= 200:
            width = len(a) if a.startswith('0') else 0
            for k in range(lo, hi + 1):
                out.add(pre + (str(k).zfill(width) if width else str(k)))
    head = None
    for line in text.split('\n'):
        if not line.startswith('|'):
            head = None
            continue
        cells = [c.strip() for c in re.split(r'(?<!\\)\|', line)[1:-1]]
        if not cells:
            continue
        if head is None:
            head = cells[0]
            continue
        if head not in ('개념', '변경') or set(cells[0]) <= set('-: '):
            continue
        first = re.sub(r'^[^:`]{1,12}:\s*', '', cells[0]).replace('\\|', '|')
        for part in first.split(' · '):
            name = clean(part.replace('`', ''))
            if len(name) >= 2:
                out.add(name)
    for s in sorted(x for x in out if x):
        sys.stdout.buffer.write(s.encode('utf-8') + b'\n')

if __name__ == '__main__':
    main(sys.argv[1])
