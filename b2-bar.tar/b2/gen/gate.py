"""learn-notes 1.13.0 G2 sonnet (batch 2; from impl112/b3r/gen/gate.py): the record, usage gate and ending class of a
writer / judge / checker stage (plan commonPerBatch.writerRunner; no haiku/sonnet call here).
  pre <precheck dir> <projection>   exit 0 pass, 3 RECORD-STOP (pinned version or sha256 differs from the 1.13.0
       calibration record, or the session failed), 7 WAIT (five_hour > 0.60 or seven_day + projection >= 0.80;
       resetsAt in gate.json as ISO UTC: five_hour's when five_hour fails, else seven_day's)
  after <precheck dir> <pre dir>    exit 0 same, 4 VOID (version, pinned sha256, init model or modelUsage keys differ
       from the pre record)
  part <part dir> <pre dir>         exit 0 the call's modelUsage keys are the pre record's init model alone, else 4
  ending <part dir>                 prints OK | REFUSAL | WAIT for one call: WAIT = no readable out.json, an error
       result (api error 429/5xx, a limit-reached result, no result) or a killed/suspended process (exit != 0 with no
       result); REFUSAL = stop_reason 'refusal' or safety_stops > 0 (the reply-shape check that counts printed tool-call
       text in place of the asked output is parts.py read, run by run.sh after OK)
The record must equal the 1.13.0 calibration's pin (pinned `claude --version` 2.1.329 (Claude Code), the pinned
binaries' sha256 re-hashed now). The writers' model (alias opus) has no calibration record: its init id is taken from
this stage's pre session and must stay the same in every call and in the after session (ids are kept only in the
stage files and in 견본.md sample records)."""
import datetime, json, subprocess, sys

PINNED = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/cli/pinned.sh"
VERSION = "2.1.329 (Claude Code)"
PIN = {"claude": "30e2724e2aecb1bf5dc9f3130901afb71c5fa229051c190a6d7ad9aff6378d6d",
       "claude.hot": "c3484833d40fc1e1b87aee30b2b46edbe7115170b5bbe3308dba0e6d3e918e74"}
FIVE_MAX, SEVEN_BELOW = 0.60, 0.80


def pin_bad():
    t = subprocess.run([PINNED, "--record"], capture_output=True, text=True).stdout
    got = {l.split()[1]: l.split()[0] for l in t.splitlines() if len(l.split()) == 2 and l.split()[1] in PIN}
    return ([] if f"version: {VERSION}" in t else ["pinned version"]) + [f"pinned {k} sha256" for k in PIN if got.get(k) != PIN[k]]


def rec_bad(d, want=None):
    rec = json.load(open(f"{d}/record.json", encoding="utf-8"))
    bad = []
    if list(rec["versions"].values()) != [VERSION]:
        bad.append("version")
    w = want if want is not None else (rec["inits"][:1] if rec["inits"] else None)
    if not w or not rec["inits"] or any([x] != w for x in rec["inits"]):
        bad.append("init model")
    if not rec["results"] or any(r["modelUsage"] != w for r in rec["results"]):
        bad.append("modelUsage keys")
    if rec.get("exit") != "exit=0":
        bad.append(rec.get("exit") or "no exit")
    return rec, bad


def iso(ts):
    return datetime.datetime.fromtimestamp(ts, datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ") if ts else None


def pre_id(pre):
    return json.load(open(f"{pre}/record.json", encoding="utf-8"))["inits"][:1]


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "pre":
        d, proj = sys.argv[2], float(sys.argv[3])
        rec, bad = rec_bad(d)
        bad += pin_bad()
        win = {}
        for ev in rec["rate_limit_events"]:
            for k, v in (ev.get("unifiedWindows") or {}).items():
                win[k] = v
        five, seven = win.get("five_hour", {}), win.get("seven_day", {})
        fu, su = five.get("utilization"), seven.get("utilization")
        ok = fu is not None and su is not None and fu <= FIVE_MAX and su + proj < SEVEN_BELOW
        wait = five.get("resetsAt") if (fu is None or fu > FIVE_MAX) else seven.get("resetsAt")
        out = {"recordSame": not bad, "differs": bad, "five_hour": {"utilization": fu, "resetsAt": iso(five.get("resetsAt"))},
               "seven_day": {"utilization": su, "resetsAt": iso(seven.get("resetsAt"))}, "projection": proj,
               "rule": "five_hour <= 0.60 AND seven_day + projection < 0.80", "pass": bool(ok) and not bad, "waitUntil": None if ok else iso(wait)}
        json.dump(out, open(f"{d}/gate.json", "w"), indent=1)
        print(json.dumps(out))
        if bad:
            sys.exit(3)
        if not ok:
            sys.exit(7)
    elif mode == "after":
        d, pre = sys.argv[2], sys.argv[3]
        rec, bad = rec_bad(d, pre_id(pre))
        bad += pin_bad()
        json.dump({"same": not bad, "differs": bad}, open(f"{d}/after.json", "w"), indent=1)
        print(json.dumps({"same": not bad, "differs": bad}))
        sys.exit(4 if bad else 0)
    elif mode == "part":
        d, pre = sys.argv[2], sys.argv[3]
        got = json.loads(open(f"{d}/model.txt").read())
        sys.exit(0 if got == pre_id(pre) else 4)
    elif mode == "ending":
        d = sys.argv[2]
        try:
            o = json.load(open(f"{d}/out.json", encoding="utf-8"))
        except Exception:
            print("WAIT")
            sys.exit(0)
        if o.get("stop_reason") == "refusal" or (o.get("safety_stops") or 0) > 0:
            print("REFUSAL")
        elif o.get("is_error") or o.get("subtype") != "success" or not (o.get("result") or "").strip():
            print("WAIT")
        else:
            print("OK")
    else:
        sys.exit(2)
