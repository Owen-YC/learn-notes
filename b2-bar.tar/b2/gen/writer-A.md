You are writing realistic test data for a Korean learning-notes app used by beginner "vibe coders" (people who build small programs by asking an AI coding assistant, and learn programming concepts along the way). For each concept the learner met in a file the assistant created for them, the app keeps a record. You only write records; you do not know or need to know how the app uses them.

Write in Korean wherever a person reads text (names, explanations), formal polite style (합니다체) for explanations. Code is a small, plausible, complete practice script or utility file a beginner's AI assistant would have created (a tip calculator, a grade report, a todo list printer, a stock checker, a text cleaner, a game score tally, etc.), never a toy one-liner.

Write 24 records, ids "gm01".."gm24". gm01–gm15 are JavaScript (".js"), gm16–gm24 are Python (".py").

Record fields:
- "id"
- "name": the concept's title as a learning-notes app would show it: short (2–20 characters), Korean, and when the concept is a specific keyword, operator, function or method, that word written in code spelling inside the title. Never use the characters * or ` in a name, and never two hyphens in a row.
- "blurb": ONE Korean sentence (합니다체) explaining the concept as the learner met it, then " — " and one backtick-quoted piece of code (at least 4 characters) copied EXACTLY from one line of "code" where the concept is used. Never two hyphens in a row anywhere in the blurb.
- "file": a project-relative path, e.g. "src/shop/tip.js" or "scripts/grades.py".
- "code": the WHOLE file the assistant created, as one string with \n line breaks. 6 to 16 lines, at most 650 characters in total. The line the blurb quotes must be one of the first 6 lines of the file.
- "output": exactly what running the file prints (standard output), as one string with \n between lines.
- "kind": a short English tag of the concept kind (e.g. "builtin-call", "operator", "method", "keyword", "statement").
- "mix": the letters of the mix items below that this record meets (a list, possibly empty).

Rules for "code":
- It runs alone as it is with node (JavaScript, CommonJS script) or python3, with no input, and prints 1 to 4 lines.
- It prints only with console.log(...) (JavaScript) or print(...) (Python), each such call starting its own line; 1 to 4 such print lines in the file. No other console method.
- No import, require or export line. No while or do loop, and no counting for loop with semicolons (use for...of / for...in in JavaScript, for ... in in Python). Never add to a list while looping over it. No files, network, user input, dates or clocks, random numbers, timers, locale functions (toLocaleString and the like), process, environment, id() or hash().
- Keep string literals short (under 20 characters) and without backslashes. No empty print call (no print() or console.log() with nothing to print). No sets in Python. Nothing that looks like a secret (keys, tokens, passwords, emails).
- Realistic data: numbers, short Korean or English strings, small arrays/lists, objects/dicts.

Mix across the 24 records:
- (a) at least 8 where a print line is inside a loop or a function body (printed several times or from a function);
- (b) at least 4 where a number in the code is a count or a bound: how many times a loop runs (range, a slice end, repeat, a list of a given length) or a limit a value is compared with;
- (c) at least 4 that index a list/array by position or read a property/key of a looked-up item, or divide by a value that comes from the data;
- (d) at least 4 that compare strings (==, ===, a string in a condition) or compare numbers in an if;
- (e) at least 3 JavaScript records that print a whole array or object with console.log (for example console.log(list) or console.log(result)), with at most 6 entries;
- (f) at least 2 that print a value built by joining or slicing a list or string (so it could be short or empty for other data);
- (g) at least 2 where two lines of the file look almost the same (for example two if checks with different numbers, or two similar assignments);
- (h) at least 2 that print the type of a value (typeof in JavaScript, type() in Python) or a boolean result directly;
- (i) at least 3 that use a method of a dict/object or array/list;
- (j) at least 3 that print 3 or 4 lines;
- (k) at least 3 that use a boolean, an && / || / and / or, or a comparison inside a condition.
Every concept must be different from every other, and every file path too.
