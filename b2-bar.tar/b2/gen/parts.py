"""learn-notes 1.13.0 G2 sonnet (batch 2; from impl113/design/G2/dev/gen/parts.py, the dev writer procedure, and
impl113/b1/gen/parts.py's make/read/assemble interface): the sample writers' parts (gen/parts.json is the layout).
The prompts are the 1.12.0 G2 measured writer prompts (gen/writer-A.md, writer-A-end.md, writer-B.md, writer-B-end.md =
impl112/b2/gen, byte copies) word for word, except (as the dev procedure): the record count, ids and languages of the
part (at most 10 records per call), the mix minimums scaled to the part (round(min24 * n / 24), at least 1; (e) only
in a part with JavaScript), and the avoid section. The avoid section is the frozen builder's (gen/avoid113.py on
impl113/NAMES-all.txt as it is when the part's prompt is made, written beside the prompt: names only; it replaces the
dev procedure's avoid.py section, declared in the bar commit), plus, as the dev procedure does, the concept names of
the earlier parts of the same set already read (chain M in layout order; a top-up: every main part).
  make <root> <part> <out prompt.md>   one part's prompt. Refuses to overwrite.
  read <part dir> <part>               result.txt: one ```json block, else the whole reply from its first '[' to its
       last ']', as a JSON array of objects whose ids are exactly the part's ids. Exit 0 readable (reply.json), 5 not.
       Never edits a reply.
  assemble <root>                      every main part read -> <root>/raw.json (records in layout order, each with
       its 'part'; exit 6 when a main part has no reply.json). A top-up part runs in its own root (run.sh topup with
       CHAIN_ROOT = the samples root) and is read by tools/check.py from there (TOPUPS).
A writer sees only the record form, the writing rules, the earlier parts' concept names and the avoid section: never a
prompt of the app, the code, the stance, the design or which model is measured."""
import json, os, re, subprocess, sys

G = os.path.dirname(os.path.abspath(__file__))
L = json.load(open(f"{G}/parts.json", encoding="utf-8"))
LAYOUT = L["parts"]
TOPUPS = L["topups"]
BY = {p["part"]: p for p in LAYOUT + TOPUPS}
MIX24 = {"a": 8, "b": 4, "c": 4, "d": 4, "e": 3, "f": 2, "g": 2, "h": 2, "i": 3, "j": 3, "k": 3}
OLD_A = 'Write 24 records, ids "gm01".."gm24". gm01–gm15 are JavaScript (".js"), gm16–gm24 are Python (".py").'
SIB = "\n\nThese concept names are already used by other parts of this same set; do not use them or write about the same concepts:\n"


def scaled(n, has_js):
    return {k: max(1, round(v * n / 24)) for k, v in MIX24.items() if k != "e" or has_js}


def latest(root, part):
    for t in range(9, 0, -1):
        d = f"{root}/parts/{part}-{t}"
        if os.path.exists(f"{d}/reply.json") and not os.path.exists(f"{d}/VOIDED"):
            return d
    return None


def siblings(root, p):
    if p.get("topup"):
        root = os.environ["CHAIN_ROOT"]
        before = [q for q in LAYOUT if q["chain"] == "M"]
    elif p["chain"] == "M":
        before = []
        for q in LAYOUT:
            if q["part"] == p["part"]:
                break
            if q["chain"] == "M":
                before.append(q)
    else:
        before = []
    names = []
    for q in before:
        d = latest(root, q["part"])
        if d:
            names += [r.get("name", "") for r in json.load(open(f"{d}/reply.json", encoding="utf-8")) if isinstance(r, dict)]
    return sorted(set(n for n in names if isinstance(n, str) and n))


def make(root, part, out):
    if os.path.exists(out):
        sys.exit(f"refuse: {out} exists")
    p = BY[part]
    d = os.path.dirname(out)
    av, keep, tools = f"{d}/avoid.md", f"{d}/avoid-names.txt", f"{d}/avoid-toolnames.txt"
    r = subprocess.run(["python3", "-I", f"{G}/avoid113.py", av, keep, tools], capture_output=True, text=True)
    if r.returncode:
        sys.exit("avoid113.py: " + r.stderr)
    open(f"{d}/avoid-build.json", "w").write(r.stdout)
    section = open(av, encoding="utf-8").read()
    sib = siblings(root, p)
    if sib:
        section = section.rstrip("\n") + SIB + " · ".join(sib) + "\n"
    if p["kind"] == "B":
        body = open(f"{G}/writer-B.md", encoding="utf-8").read()
        for k in range(1, 8):
            body = body.replace(f"gf{k}", p["ids"][k - 1])
        end = open(f"{G}/writer-B-end.md", encoding="utf-8").read()
        open(out, "w", encoding="utf-8").write(body + section + end)
        return
    A = open(f"{G}/writer-A.md", encoding="utf-8").read()
    n, ids = len(p["ids"]), p["ids"]
    langs = 'All are JavaScript (".js").' if p["lang"] == "js" else 'All are Python (".py").'
    assert OLD_A in A
    A = A.replace(OLD_A, f'Write {n} records, ids "{ids[0]}".."{ids[-1]}". {langs} This is one part of a larger set that is written in several parts.')
    A = A.replace("Mix across the 24 records:", f"Mix across the {n} records:")
    mix = scaled(n, p["lang"] == "js")
    for k, v in MIX24.items():
        m = re.search(rf"^- \({k}\) at least {v} ", A, re.M)
        assert m, k
        if k not in mix:
            A = re.sub(rf"^- \({k}\) at least {v} .*\n", "", A, flags=re.M)
        else:
            A = A[:m.start()] + f"- ({k}) at least {mix[k]} " + A[m.end():]
    end = open(f"{G}/writer-A-end.md", encoding="utf-8").read().replace("the 24 records", f"the {n} records")
    open(out, "w", encoding="utf-8").write(A + section + end)


def read(d, part):
    p = BY[part]
    text = open(f"{d}/result.txt", encoding="utf-8").read() if os.path.exists(f"{d}/result.txt") else ""
    blocks = re.findall(r"```json[ \t]*\n(.*?)\n```", text, re.S)
    if len(blocks) == 1:
        body = blocks[0]
    elif not blocks and "[" in text and "]" in text:
        body = text[text.index("["): text.rindex("]") + 1]
    else:
        body = None
    v = None
    if body is not None:
        try:
            v = json.loads(body)
        except Exception:
            v = None
    ok = isinstance(v, list) and all(isinstance(x, dict) for x in v) and sorted(str(x.get("id")) for x in v) == sorted(p["ids"])
    json.dump({"part": part, "readable": ok, "blocks": len(blocks), "records": len(v) if isinstance(v, list) else 0},
              open(f"{d}/readable.json", "w"), indent=1)
    if not ok:
        sys.exit(5)
    json.dump(v, open(f"{d}/reply.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def assemble(root):
    out = f"{root}/raw.json"
    if os.path.exists(out):
        sys.exit(f"refuse: {out} exists")
    rows = []
    for p in LAYOUT:
        d = latest(root, p["part"])
        if not d:
            print(f"no reply for {p['part']}")
            sys.exit(6)
        rows += [{"part": p["part"], **r} for r in json.load(open(f"{d}/reply.json", encoding="utf-8"))]
    open(out, "w", encoding="utf-8").write(json.dumps(rows, ensure_ascii=False, indent=1) + "\n")
    print(len(rows))


if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "make":
        make(sys.argv[2], sys.argv[3], sys.argv[4])
    elif cmd == "read":
        read(sys.argv[2], sys.argv[3])
    elif cmd == "assemble":
        assemble(sys.argv[2])
    else:
        sys.exit(2)
