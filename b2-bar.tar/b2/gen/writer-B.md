You are writing realistic test data for a Korean learning-notes app used by beginner "vibe coders" (people who build small programs by asking an AI coding assistant, and learn programming concepts along the way). For each concept the learner met in their project, the app keeps a record. You only write records; you do not know or need to know how the app uses them.

Write in Korean wherever a person reads text (names, explanations, questions, answers), formal polite style (합니다체) for explanations. Code is plausible project code a beginner's AI assistant would have written.

Common fields:
- "id" (given below), "kind" (short English tag of the concept kind)
- "name": the concept's title: short (2–20 characters), Korean, with a keyword/function/method written in code spelling inside the title when the concept is one. Never use the characters * or ` in a name, and never two hyphens in a row.
- "blurb": ONE Korean sentence (합니다체) explaining the concept as the learner met it; for records with code, then " — " and one backtick-quoted piece of code (at least 4 characters) copied EXACTLY from one line of the code where the concept is used. Never two hyphens in a row anywhere in the blurb.
- "file": a project-relative path with the extension asked.

Write these 7 records, in this order:

1. id "gf1": an EDIT of a TypeScript file (".ts"). Fields "before" (the file before the edit) and "after" (the file after), each 20–30 lines, as strings with \n. The edit changes 1–4 consecutive lines; the blurb quotes a changed line of "after". "after" passes tsc --strict, runs alone with node and prints 1–4 lines with console.log. No import/require/export lines.
2. id "gf2": an EDIT of a JavaScript file (".js"), same fields; "after" 22–34 lines; the edit changes 1–4 consecutive lines; the blurb quotes a changed line. Runs alone with node, prints 1–4 lines. No import/require/export lines.
3. id "gf3": a concept met with NO code (a tool, workflow or idea, e.g. a git or terminal concept): only "name" and "blurb" (no backtick quote needed), no file, no code.
4. id "gf4": a concept the learner got wrong once in a review quiz. A whole JavaScript file the assistant created: "code" 6–14 lines (prints 1–3 lines with console.log, no import/require/export), "file" (".js"), and "slip": { "question": the review question the learner got wrong (one or two Korean sentences, short code in backticks allowed), "mine": the learner's wrong answer as typed (short, informal), "what": one Korean phrase saying what the learner misunderstood, ending in "봄" or "생각함" }.
5. id "gf5": an EDIT of a Python file (".py"), same fields as gf1; "after" 20-30 lines; the edit changes 1-4 consecutive lines; prints 1-4 lines with print. No import lines.
6. id "gf6": another concept met with NO code (a tool, workflow or idea): only "name" and "blurb".
7. id "gf7": another concept the learner got wrong once, a whole Python file (".py") the assistant created: "code" 6-14 lines (prints 1-3 lines with print, no import), "file", and "slip" as in gf4.

For every record with code: no files, network, user input, dates, random numbers, timers, locale functions or process; string literals short and without backslashes; nothing that looks like a secret. Every concept must be different from every other, and every file path too.
