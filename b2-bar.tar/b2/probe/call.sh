#!/bin/bash
# learn-notes 1.12.0 G2 (batch 2; from batch 1's): one probe session (the calibration's form, impl112/b0/probe/call.sh).
# usage: call.sh <out dir> <alias> <lines.jsonl>      (run through cli/pinned.sh: the pinned claude first on PATH)
# claude --version before; stream-json turns 'ok' (front record) · '/g2probe <lines> <dir>/out.json <dir>/status.jsonl'
# (the calls) · 'ok' (back record); claude --version after; record.py.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2
O="$1"; A="$2"; LINES="$3"
case "$A" in haiku|sonnet) ;; *) echo "refuse: alias must be haiku or sonnet"; exit 2;; esac
[ -s "$LINES" ] || { echo "no lines: $LINES"; exit 2; }
mkdir -p "$O" "${S:?}/work/empty"
[ -e "$O/out.json" ] && { echo "refuse: $O/out.json exists (one round)"; exit 1; }
cd "${S:?}/work/empty" || exit 1
export DISABLE_AUTOUPDATER=1
claude --version > "$O/version-before.txt" 2>&1
date -u +%FT%TZ > "$O/started.txt"
python3 -I - "$LINES" "$O/out.json" "$O/status.jsonl" > "$O/input.jsonl" <<'PY'
import json, sys
lines, out, status = sys.argv[1:4]
for text in ("ok", f"/g2probe {lines} {out} {status}", "ok"):
    print(json.dumps({"type": "user", "message": {"role": "user", "content": text}}, ensure_ascii=False))
PY
timeout 2400 claude -p --model "$A" --tools '' --plugin-dir "${S:?}/probe/mod" --input-format stream-json --output-format stream-json --verbose --debug-file "$O/debug.log" < "$O/input.jsonl" > "$O/stream.jsonl" 2> "$O/err.txt"
echo "exit=$?" > "$O/exit.txt"
date -u +%FT%TZ > "$O/ended.txt"
claude --version > "$O/version-after.txt" 2>&1
python3 -I "${S:?}/probe/record.py" "$O" > /dev/null
