// learn-notes 1.13.0 G2 sonnet measurement probe (batch 2; copy of impl113/b1/probe/mod = a copy of the 1.12.0 calibration probe impl112/b0/probe/mod, D20):
// calls $.model.complete exactly as the plugin's askModel does (the setting string as the model, effort low, system as
// given, prompt through notes.ts redactText, maxTokens, timeoutMs), 4 at a time, times each call with $.clock, passes
// replies through fixEscapedTicks (notes.ts = the build commit's hooks/notes.ts, byte for byte), and writes one JSON
// file. Lines come from a JSONL file: { id, model, system, prompt, maxTokens, timeoutMs } per line.
// Runner rules: after each call its status line { id, answered, reason, status, output_tokens, ms } (no text) is added
// to the status file; the engine has no append, so the whole file is written again each time with every earlier line
// as it was (it only grows).
import type { Register } from 'claude-code'
import { fixEscapedTicks, redactText } from './notes'

type Line = { id: string; model: string; system: string; prompt: string; maxTokens: number; timeoutMs: number }

const BATCH = 4

export const register: Register = (on) => {
  on('session.start', async ($, e, next) => {
    await $.command.register({ name: 'g2probe', description: 'learn-notes 1.13.0 G2 measurement probe', argumentHint: '<lines.jsonl> <out.json> <status.jsonl>' })
    return next(e)
  })

  on('command.run', { command: 'g2probe' }, async ($, e) => {
    const [linesPath, outPath, statusPath] = e.args.trim().split(/\s+/)
    if (!linesPath || !outPath || !statusPath) return { text: 'G2PROBE usage: /g2probe <lines.jsonl> <out.json> <status.jsonl>' }
    if (await $.fs.exists(outPath)) return { text: `G2PROBE refuse: ${outPath} exists` }
    const lines = (await $.fs.read(linesPath))
      .split('\n')
      .filter(line => line.trim() !== '')
      .map(line => JSON.parse(line) as Line)
    const probeStartedAt = await $.clock.now()
    const results: unknown[] = []
    const status: string[] = []
    let writing = Promise.resolve()
    const said = (one: Record<string, unknown>) => {
      status.push(JSON.stringify(one))
      const text = status.join('\n') + '\n'
      writing = writing.then(() => $.fs.write(statusPath, text))
      return writing
    }
    for (let i = 0; i < lines.length; i += BATCH) {
      const batch = lines.slice(i, i + BATCH)
      const done = await Promise.all(
        batch.map(async line => {
          const { text: prompt, hits } = redactText(line.prompt)
          const startedAt = await $.clock.now()
          let row: Record<string, unknown>
          try {
            const reply = await $.model.complete({
              model: line.model,
              effort: 'low',
              system: line.system,
              prompt,
              maxTokens: line.maxTokens,
              timeoutMs: line.timeoutMs,
            })
            const endedAt = await $.clock.now()
            const base = { id: line.id, model: line.model, maxTokens: line.maxTokens, timeoutMs: line.timeoutMs, redactHits: hits, startedAt, endedAt, ms: endedAt - startedAt, usage: reply.usage }
            if (reply.isAnswered) {
              const text = fixEscapedTicks(reply.text)
              row = { ...base, isAnswered: true, chars: text.length, text }
            } else if (reply.reason === 'api-error') row = { ...base, isAnswered: false, reason: reply.reason, status: reply.status, error: reply.error }
            else row = { ...base, isAnswered: false, reason: reply.reason }
          } catch (err) {
            const endedAt = await $.clock.now()
            row = { id: line.id, model: line.model, maxTokens: line.maxTokens, timeoutMs: line.timeoutMs, redactHits: hits, startedAt, endedAt, ms: endedAt - startedAt, threw: String(err).slice(0, 300) }
          }
          const usage = row.usage as { output_tokens?: number } | undefined
          await said({ id: row.id, answered: row.isAnswered === true, reason: row.threw !== undefined ? 'threw' : (row.reason ?? null), status: row.status ?? null, output_tokens: usage?.output_tokens ?? null, ms: row.ms })
          return row
        }),
      )
      results.push(...done)
    }
    await writing
    const probeEndedAt = await $.clock.now()
    await $.fs.write(outPath, JSON.stringify({ linesPath, probeStartedAt, probeEndedAt, results }, null, 2) + '\n')
    const counts: Record<string, number> = {}
    for (const one of results) {
      const r = one as { isAnswered?: boolean; reason?: string; threw?: string }
      const how = r.threw !== undefined ? 'threw' : r.isAnswered ? 'answered' : (r.reason ?? '?')
      counts[how] = (counts[how] ?? 0) + 1
    }
    return { text: `G2PROBE done ${results.length} ${JSON.stringify(counts)}` }
  })
}
