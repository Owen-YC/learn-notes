"""(learn-notes 1.13.0 G2 sonnet batch 2: copy of impl113/b1/probe/record.py = impl112/b1/probe/record.py = impl112/b0/probe/record.py with G7PROBE -> G2PROBE.) Reads one session's stream: every system/init model, each result's modelUsage keys and subtype, every
rate_limit_event (as it came), the /g7probe command's status line, the version files. Writes record.json there."""
import json, os, sys

o = sys.argv[1]
inits, results, limits, probe = [], [], [], []
for raw in open(os.path.join(o, "stream.jsonl"), encoding="utf-8", errors="replace"):
    try:
        d = json.loads(raw)
    except Exception:
        continue
    if d.get("type") == "system" and d.get("subtype") == "init":
        inits.append(d.get("model"))
    if d.get("type") == "result":
        results.append({"subtype": d.get("subtype"), "is_error": d.get("is_error"), "modelUsage": sorted((d.get("modelUsage") or {}).keys()), "result": (d.get("result") or "")[:600] if "G2PROBE" in (d.get("result") or "") else None})
    if d.get("type") == "rate_limit_event":
        limits.append(d.get("rate_limit_info", d))
def read(name):
    p = os.path.join(o, name)
    return open(p, encoding="utf-8").read().strip() if os.path.exists(p) else None
rec = {"versions": {n: read(n) for n in ("version.txt", "version-before.txt", "version-after.txt") if read(n) is not None},
       "exit": read("exit.txt"), "started": read("started.txt"), "ended": read("ended.txt"),
       "inits": inits, "results": results, "rate_limit_events": limits}
json.dump(rec, open(os.path.join(o, "record.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print(json.dumps(rec, ensure_ascii=False, indent=1))
