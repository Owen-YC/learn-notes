// learn-notes 1.12.0 G2 tap sender (batch 2; copy of impl111/b7/tap/mod, command renamed; record only, B-12): sends each frozen line once more through
// $.model.complete as the probe does (model, effort low, system, prompt, maxTokens, timeoutMs), but its prompt exactly
// as frozen (the lines were masked when built), one at a time. The session runs with ANTHROPIC_BASE_URL on the local
// tap (tap.py), which records each request's shape and the answer's stop_reason and stop_details. Writes one JSON file
// of each call's status (answered or its reason, output_tokens), never its text.
import type { Register } from 'claude-code'

type Line = { id: string; model: string; system: string; prompt: string; maxTokens: number; timeoutMs: number }

export const register: Register = (on) => {
  on('session.start', async ($, e, next) => {
    await $.command.register({ name: 'g2tap', description: 'learn-notes 1.12.0 G2 tap sender (record only)', argumentHint: '<lines.jsonl> <out.json>' })
    return next(e)
  })

  on('command.run', { command: 'g2tap' }, async ($, e) => {
    const [linesPath, outPath] = e.args.trim().split(/\s+/)
    if (!linesPath || !outPath) return { text: 'G2TAP usage: /g2tap <lines.jsonl> <out.json>' }
    if (await $.fs.exists(outPath)) return { text: `G2TAP refuse: ${outPath} exists` }
    const lines = String(await $.fs.read(linesPath))
      .split('\n')
      .filter(line => line.trim() !== '')
      .map(line => JSON.parse(line) as Line)
    const results: unknown[] = []
    for (const line of lines) {
      const startedAt = await $.clock.now()
      try {
        const reply = await $.model.complete({ model: line.model, effort: 'low', system: line.system, prompt: line.prompt, maxTokens: line.maxTokens, timeoutMs: line.timeoutMs })
        const endedAt = await $.clock.now()
        results.push({ id: line.id, ms: endedAt - startedAt, usage: reply.usage, ...(reply.isAnswered ? { isAnswered: true, chars: reply.text.length } : { isAnswered: false, reason: reply.reason, ...(reply.reason === 'api-error' ? { status: reply.status, error: reply.error } : {}) }) })
      } catch (err) {
        results.push({ id: line.id, threw: String(err).slice(0, 300) })
      }
    }
    await $.fs.write(outPath, JSON.stringify({ linesPath, results }, null, 2) + '\n')
    return { text: `G2TAP done ${results.length}` }
  })
}
