You are a fresh checker. Below are (1) SOURCE fields, mostly English, from a measurement design file and a plan, and (2) a Korean SECTION meant to quote them. Check the translation only.

For every source field and every sentence/bullet/number in it, check that the Korean section states it with the same meaning: no number changed, no clause added, dropped, weakened, strengthened or reinterpreted, no condition changed, no list item lost. The design's 'stance' field is already Korean and must appear in the section letter for letter. Also flag places where the section's own added text (marked as this batch's notes, '읽는 법', '도구가 글을 읽는 방식', '이 묶음이 정한 것', '(이 묶음의 기록, 원문 밖)') contradicts a source field or changes its meaning. Ignore style.

Answer in Korean. List each problem as: 번호, 출처 필드와 원문 조각, 절의 해당 글, 무엇이 다른지, 고칠 글 제안. If there is no problem in a field, say so for that field. End with a line '문제 수: N'.

=== SOURCE (JSON) ===
{
 "design.bar": [
  "Unchanged from the last committed bar (docs/qa/견본.md '1.10.0 비슷한 코드 (G2)' → '기준 · 입장 · 결정 규칙', d684d90; the numbers are 1.8.0's and F4's). Nothing laxer.",
  "Unit: the 20 slots picked as 비슷한 코드 in 9 quizzes; other items (내 코드, 왜, 다시 도전) recorded only.",
  "(가) at least 16 of 20 slots meet ALL of stance clause 7 (ㄱ)–(ㅈ).",
  "(나) 0 wrong A among read items (stance 6, 11).",
  "Every slot graded by running the shown code as shown (unshare -n timeout 5; nothing filled in).",
  "Empty reply, timeout, refused or unread slot (including a slot the plugin's reader refuses, which stores no item): a (가) miss, outside (나), never re-sent. Only an api-error (429/5xx, 0 tokens, no text) is re-sent, up to twice. A cap hit (output_tokens >= 4600 + H_haiku) is recorded; a slot lost to it is a (가) miss.",
  "Two judges per label (blind label), neither sees another label; a split, or a case the stance does not decide, counts against ((가) miss, (나) wrong). No clause added, changed or re-read after answers are opened.",
  "Decision rule 3: per model, pass iff (가) >= 16/20 AND (나) 0 wrong. Pass → MODEL_SWITCHES[model].rungChangedStep = 2 in the commit after the decision (R6), else Infinity. RUNG_CHANGED_STEP stays Infinity (D1). Never transferred between models (R1/R2).",
  "Rule 2: one round per design per model; no re-measure with mended sentence, scope or stance. Rule 5: the design's code stays behind the switch. Rule 6: once ON, widening the scope (adding an extension, edits, ts, removing any isChangedShaped / CHANGED_UNSETTLED condition, loosening a changedItem check) needs a new round; narrowing does not.",
  "Measured layout restated only because the scope narrowed (D33: measured = enabled): 24 concepts written blind (20 + 4 spare), all whole-file creates js 15 · py 9 (measured js 13 · py 7) in the enabled shape (samples above); fillers 3 내 코드 · 2 왜 · 2 다시 도전; 9 quizzes Q1–2 [c,c,c], Q3–5 [c,c,내 코드], Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; steps 2/3 alternating, all due; beginner; maxTokens 4600; timeoutMs 90000; effort low; QUIZ_SYSTEM; the same prompt file for any model measured; D34 9/9 byte match.",
  "Stance clarifications committed with the bar (each neutral or stricter, see stance): 2 (a reader-refused slot is unread), 8 (조각 결과 = 학습자 결과 for a whole file, read word for word), 10 (the plugin's lead and hint judged like model text; the hint's line number and quoted line must be right — stricter), 12 (no ts in scope), 1 (C, O and the echo are never judged: never stored).",
  "Before the round: 1.12.0 calibration on the installed CLI; version and alias before/after; a mismatch voids the round (cell OFF)."
 ],
 "design.stance": {
  "머리": "판정의 입장 (G2, 1.12.0 G2-C). 기준 · 결정 규칙 · 짜임 · 견본 쓰기 프롬프트와 함께, 견본을 쓰거나 부르기 전에 docs/qa/견본.md 새 절로 한 커밋에 넣습니다(UTC 시각, 가리키는 코드 커밋 해시). 매기는 쪽은 이 글의 조항만 따르고 판정마다 조항 번호를 적습니다. ⚙ 조항은 eval 도구(부르기 전에 sha256으로 얼림)가 세고, ✎ 조항만 매기는 하위 에이전트가 매깁니다. 1.10.0의 조항 번호와 뜻을 그대로 두고, 이 설계에서 쓰이지 않는 갈래는 \"쓰이지 않음\"으로 적었습니다.",
  "0 셈의 단위": "비슷한 코드로 고른 20자리(퀴즈 9개). 같은 퀴즈의 내 코드 · 왜 · 다시 도전 문항은 셈 밖이고 기록만 합니다.",
  "1 읽기 ⚙": "플러그인처럼 fixEscapedTicks → 그 커밋의 parseQuiz로 읽어 저장될 문항(question · hint · answer · kind · rung)만 매깁니다. 모델의 C · O · N 줄, 되풀이 줄(R), 바꿀 수 있는 곳 목록과 날글은 저장되지 않으므로 판정 대상이 아니며, O가 틀리고 N이 맞은 자리도 저장된 문항(N)만으로 매깁니다. 읽힌 문항은 그 번호 자리의 개념으로 플러그인이 짠 문항입니다.",
  "2 답이 없는 자리 ⚙": "빈 답(empty-reply · API 거절), 시간 한도(90초)에 끊긴 답, 읽히지 않은 자리, 플러그인의 읽기(changedItem)가 문항을 내지 않은 자리는 (가)에서 놓침, (나)에서는 셈 밖입니다(학습자에게 보이지 않음). 상한에 닿았어도 읽힌 문항은 읽힌 그대로 매깁니다. 다시 보내는 것은 글이 하나도 없고 출력 토큰이 0인 api-error(상태 429 · 5xx)뿐이며 같은 프롬프트로 두 번까지, 모두 기록합니다. 그래도 실패하면 그 퀴즈의 자리는 모두 놓침입니다. 빈 답 · 시간 끊김 · 상한 닿음 · 읽기가 거른 자리는 다시 보내지 않습니다. 빈 답은 기록으로만 탭으로 한 번 더 보내 stop_reason을 적습니다.",
  "3 돌리기 ⚙": "문제의 코드: question의 펜스 블록(플러그인이 넣은 하나)입니다. 언어는 펜스 이름(js · python)입니다. 빈 임시 폴더에서 `unshare -n timeout 5`로, 표준 입력을 비우고 돌립니다. js: `node 파일` 두 번. py: `env -i PATH=\"$PATH\" LANG=C.UTF-8 PYTHONHASHSEED=<n> python3 -s -P -B 파일`을 n = 1..5로 다섯 번. 결과는 표준 출력의 줄들입니다(마지막 줄이 줄바꿈 없이 끝나도 한 줄). 끝 코드가 0이 아니면 그 앞까지의 출력 뒤에 마지막 예외의 이름(메시지는 뺌) 한 줄을 더합니다. 표준 오류는 결과에 넣지 않습니다. 돌린 결과가 서로 하나라도 다르거나 5초를 넘으면 그 문항은 (가) 놓침이고 A는 틀림입니다. 학습자 결과: 견본을 얼리기 전 확인 때 학습자 파일 전체(= 바꾸기 전의 보인 코드)를 같은 규칙으로 돌려 얼린 줄들입니다. 도구 판(node · python · Claude Code)을 적습니다.",
  "4 채우지 않음": "블록에 없는 정의 · import · 입력 · 파일 · 준비를 덧붙이지 않습니다. 나는 오류도 결과입니다. (이 설계의 문제 코드는 학습자 파일 전체라 채울 것이 생기지 않지만 규칙은 그대로 둡니다.) 4의 \"글로 말한 바꿈\"은 쓰이지 않습니다(바꿈은 플러그인이 코드에 넣음).",
  "5 물은 것 ⚙": "문제 글은 플러그인의 고정 글(CHANGED_LEAD)이고 \"이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름\"을 묻습니다. 그래서 물은 것은 언제나 결과 전체(오류로 멈추면 그 앞 출력과 오류 이름)입니다. 매기는 쪽이 Q만 보고 물은 것을 정하는 단계는 쓰이지 않습니다. question이 이 글로 시작하지 않으면 10에서 놓침이고, (나)는 결과 전체와 견줍니다.",
  "6 표기 맞춤 ⚙": "1.10.0 조항 6을 글자 그대로 씁니다(A와 결과, 결과끼리 견줄 때 모두). 줄마다 앞뒤 공백을 지우고, 이어진 공백은 하나로, 글자 · 숫자(한글 포함)가 아닌 문자 바로 옆의 공백은 지웁니다. 따옴표 종류는 가리지 않습니다. 결과 줄이 따옴표로 시작하고 끝나지 않을 때만 A 줄 전체를 감싼 따옴표 · 백틱을 뗍니다. js에서 결과 줄에 따옴표로 감싼 객체 키가 없을 때만 A의 `\"a\":` · `'a':`를 `a:`로 봅니다(py는 그대로). 줄 끝 마침표 하나와 true · false · none · null · undefined · nan의 대소문자는 보지 않습니다. 결과 끝의 빈 줄은 견주지 않고, 가운데 빈 줄은 A의 빈 줄이나 '(빈 줄)'과 같습니다. 결과가 여러 줄이고 A가 한 줄이면 결과 줄들을 ', ' · ' ' · '과 ' · '와 ' · ' 그리고 ' · ' → ' 가운데 하나로 이어 맞춘 것이 A와 같으면 같음입니다(학습자가 쉼표로 이어 쓴 답과 같은 규칙). 그 밖의 글자 · 값 · 차례 · 줄 수 · 괄호 · 숫자 표기 · 대소문자는 그대로 견줍니다. 앞 공백만 다른 줄(padStart · ljust · rjust가 찍은 `   5`와 `5`)은 이 규칙으로 같음입니다(1.10.0과 같음, 바꾸지 않음).",
  "7 (가) 코드 다름 · 답 다름": "아래를 모두 갖춘 자리만 넘음으로 셉니다. (ㄱ) ⚙ 읽힌 문항의 rung이 changed. (ㄴ) ⚙ 코드를 바꿨음: 3의 문제 코드가 학습자 조각(= 파일 전체)과 6의 맞춤과 줄 끝 `;` · 주석 뺌 뒤 줄 단위로 (i) 같지 않고 (ii) 찍는 줄(한 줄짜리 console.log(…) · print(…))을 뺀 나머지 줄이 학습자 줄들의 부분열이 아님. (ㄷ) ⚙ 그 개념의 코드에서 왔음: 학습자 조각의 핵심 줄(토큰 4개 이상, 괄호뿐 · else · `return 이름` · 이름 하나만 찍는 줄이 아님; 없으면 토큰 2개 이상) 가운데 하나 이상이 보인 코드의 어느 줄과 토큰이 같거나 하나만 다름(codeAsRead 토큰). (ㄹ) ⚙ 정의 빠짐이 아님: 결과가 ReferenceError/NameError로 끝나고 그 이름이 블록 안에서 한 번도 선언 · 대입 · 매개변수 · for 변수 · catch 변수로 나오지 않으면 놓침(TDZ · UnboundLocalError는 들지 않음). (ㅁ) ⚙ kind가 predict. (ㅂ) ⚙ 펜스 블록이 하나. (ㅅ) ⚙ 답이 다름(8). (ㅇ) ⚙/✎ 문제 글이 맞음(10). (ㅈ) ⚙ 3의 여러 번 돌린 결과가 모두 같고 5초 안(ts 갈래는 쓰이지 않음: 12).",
  "8 답 다름 ⚙": "학습자 결과: 3의 얼린 학습자 결과. 조각 결과: 1.10.0 조항 8의 정의를 그대로 씁니다 — 학습자 결과 가운데, 보낸 codeFor 조각이 파일에서 차지하는 줄 범위 안의 print 호출이 찍은 줄들. 이 설계의 조각은 파일 전체이므로(isWholeShown) 모든 호출이 범위 안에 있고, 조각 결과는 학습자 결과와 같습니다(새 해석이 아니라 정의를 그대로 적용한 것). 견줄 것은 물은 것(5: 결과 전체)입니다. 6으로 맞춘 뒤 아래 가운데 하나면 같음(놓침): (a) 결과 전체가 학습자 결과 전체와 같음. (b) 결과 줄들이 차례 그대로 학습자 결과 안에 이어진 줄들로 있음(어디서 시작해도; 한 줄이면 학습자 결과의 어느 줄과 같아도). (c) 결과 줄마다 학습자 결과의 같은 순번 줄과 같음. (d) · (e)(찍지 않는 이름, 줄 수 · 횟수를 물음)는 물은 것이 언제나 결과 전체라 쓰이지 않습니다. 결과가 오류 이름으로 끝나면 그 줄은 학습자 결과의 어느 줄과도 다릅니다. 결과가 오류 이름 한 줄뿐이면 다름입니다.",
  "9 예측이 아닌 문항": "쓰이지 않음: 플러그인이 kind를 predict로 씁니다. 도구 결함으로 다른 kind가 저장되면 7(ㅁ) 놓침, (나)는 11로 매깁니다.",
  "10 문제 글 ⚙": "lead와 hint는 플러그인이 쓴 고정 글이지만 모델 글처럼 매깁니다(1.10.0보다 엄격: 그때 H는 기록만). (ㅇ)를 갖추려면 모두: (i) question이 CHANGED_LEAD 글 그대로로 시작하고 그 뒤에 펜스 블록 하나만 있음; (ii) 보인 코드와 학습자 코드가 정확히 한 줄에서만 다름(\"한 곳을 바꿨습니다\"가 참); (iii) hint의 \"k번째 줄\"이 그 다른 줄의 번호(보인 블록의 첫 줄을 1로, 빈 줄 포함)와 같음; (iv) hint가 줄을 따왔으면 따온 글이 그 줄의 앞뒤 공백을 뺀 것과 글자 그대로 같음. hint는 바뀐 줄을 알려 줄 뿐 결과나 따라간 과정을 말하지 않으므로 답을 미리 말한 것으로 보지 않습니다. 하나라도 어긋나면 (가) 놓침입니다.",
  "11 (나) A 맞음": "⚙ 먼저 도구가 A 전체를 6으로 맞춰 결과 전체와 같은지 봅니다. 같으면 맞음. ✎ 아니면 매기는 쪽이 봅니다: A가 결과의 줄을 모두 차례대로 말하고(6의 \"그대로 견주는 것\"으로) 다른 틀린 말이 없으면 맞음. 틀림: 결과 전체 가운데 일부만 쓴 A(반복이 찍는 여러 줄 중 마지막 줄만 등), 줄여 쓴 A(… · 등 · 생략), 오류로 멈추는 결과에 출력만 쓴 A, 오류가 첫 출력 전에 나는데 그 앞에 찍힌 줄을 쓴 A, 오류 이름을 다르게 댄 A, 둘 이상을 답으로 내놓은 A, 학습자 원래 코드의 답을 쓴 A, node가 여러 줄로 펼쳐 찍는 값을 한 줄로 쓴 A(결과가 여러 줄이고 A도 여러 줄이면 줄 수가 달라 틀림; A 전체가 한 줄일 때만 6의 잇기 규칙). 맞음: 오류 메시지 글은 견주지 않음(이름만). 저장된 A에는 언제나 오류 이름이 있습니다(읽기가 이름 없는 오류 줄을 받지 않음).",
  "12 ts": "쓰이지 않음: ts는 범위 밖이고(RUNG_CHANGED_EXTS = js, py) 견본에 넣지 않습니다. 도구 결함으로 ts 문항이 저장되면 (가) 놓침, (나)는 3으로 돌린 결과와 견줍니다.",
  "13 번호가 엇갈린 답 ⚙": "parseQuiz가 짝지은 번호대로 매깁니다. changedItem은 그 번호 자리 개념의 코드로만 문항을 짜고 C의 번호가 자리 번호와 다르면 문항을 내지 않으므로, 엇갈린 답은 읽히지 않은 자리(2)로만 셉니다. C · O · N을 다시 쓴 답은 플러그인처럼 마지막 글로 읽습니다(1).",
  "14 매기는 차례와 갈림": "꼬리표마다 매기는 하위 에이전트 둘이 따로 매깁니다. 둘 다 설계 · 견본 쓰기 · 부르기에 끼지 않은 새 하위 에이전트이고, 이 글과 도구가 낸 파일만 봅니다(모델 이름, 토큰, 시간은 빠짐). 두 판정이 갈린 문항과 이 글이 가르지 못하는 경우는 기능에 불리한 쪽((가) 놓침, (나) 틀림)으로 셉니다. 재는 세션은 판정을 바꾸지 않고, 출력을 본 뒤 조항을 더하거나 고치거나 다시 읽지 않습니다. 고칠 것은 '다시 잴 때'에 적기만 합니다.",
  "15 미리 가른 경계 사례": [
   "1.10.0 기록: W10 부모 클래스가 블록에 없음 → 7(ㄹ) (이 범위에서는 생기지 않음). 줄인 출력 → 11 틀림. 되돌리기 · 바꿔 보기 · 왜 → 9(쓰이지 않음). Q가 지금 출력을 틀리게 말함 → 10. Object.freeze A length 1 vs TypeError → 11 틀림. 빈 답 · 상한에 잘린 끝 → 2. 그대로 보임 · 몇 줄만 떼어 보임 → 7(ㄴ). 1.8.0 ===/== 출력 그대로 → 8 같음. node `[ 1, 2, 3, [ 4 ] ]` vs A `[1, 2, 3, [4]]` → 6 같음. 산문 A → 11. pythonista[7:]를 ista로 → 11 틀림. 두 블록으로 보임 → 7(ㅂ). 두 번 돌린 결과가 다름 → 3. node가 깊은 배열을 `[Array]`로 줄여 찍음 → 3 · 6 · 11(통째로 쓴 A는 틀림). 끝에 빈 줄을 찍음 → 6 견주지 않음. `1 2`와 `12` → 6 다름. JSON.stringify의 `{\"a\":1}`을 `{a:1}`로 쓴 A → 6 다름. T 줄만 있고 유형이 빔 → 쓰이지 않음(9).",
   "(dev) for-else: 바꾼 뒤 'hana 없음' 줄이 빠지고 결과가 학습자 결과의 둘째 줄 하나만 남음 → 8(b) 같음, (가) 놓침(지금 읽기는 이런 N을 'subset'으로 거르므로 읽히지 않은 자리, 2와 같은 결과).",
   "(dev) continue · sum · min: 결과가 학습자 결과의 앞 줄들 또는 가운데 한 줄 → 8(b) 같음.",
   "(dev) 반복이 네 줄을 찍는데 A가 마지막 줄만 씀 → 11 틀림.",
   "(dev) repeat(-1)이 첫 출력 전에 RangeError를 내는데 A가 그 앞에 찍힌 줄을 씀 → 11 틀림. 결과가 오류 이름 한 줄이면 A도 그 이름 한 줄이어야 맞음.",
   "(dev) 기준 점수를 바꾼 grade()의 흐름을 잘못 따라 '서아 B'라고 씀(결과 '서아 A') → 11 틀림.",
   "(dev) JSON.stringify 문자열의 길이 비교(text.length > 30)를 잘못 셈 → 11 틀림.",
   "(dev) A 줄 끝 마침표(`true.`)·대소문자(`TRUE`/`True` in js) → 6: 마침표 하나와 true/false 대소문자는 보지 않음.",
   "(dev) py `<class 'bool'>`, js typeof의 `number` → 결과 그대로; 6으로 견줌.",
   "앞 공백(padStart · rjust)만 다른 줄 → 6 같음(1.10.0 그대로).",
   "가운데 빈 줄: 저장된 A의 빈 줄('(빈 줄)'을 읽기가 빈 줄로 바꿈)은 결과의 가운데 빈 줄과 같음; 결과에 가운데 빈 줄이 있는데 A에 없으면 줄 수가 달라 11 틀림.",
   "py 집합 · 사전 차례: 다섯 번의 결과 가운데 하나라도 다르면 3 → (가) 놓침 · A 틀림(범위에서 집합은 빠짐; 사전은 넣은 차례로 같음).",
   "node가 클래스 인스턴스를 `Point { x: 1 }`로 찍는데 A가 `{ x: 1 }` → 6 그대로 견주는 것이라 다름 → 11 틀림.",
   "실수 표기(0.30000000000000004, 9240.0) → 6 그대로; 다르게 쓴 A는 틀림.",
   "A가 여러 줄 결과를 쉼표로 이어 한 줄로 씀(lead가 허용) → 6의 잇기 규칙으로 같으면 맞음.",
   "보인 코드가 학습자 코드와 두 줄 이상에서 다름(도구 결함) → 10(ii) 놓침.",
   "hint의 줄 번호나 따온 줄이 바뀐 줄과 다름(도구 결함) → 10(iii)/(iv) 놓침.",
   "O가 틀리고 N이 맞음 / O가 맞고 N이 틀림 → 1: 저장된 N만 매김(N이 틀리면 11 틀림).",
   "모델이 C · O · N을 다시 써서 읽기가 마지막 글을 씀 → 1 · 13: 저장된 문항만 매김.",
   "바꾼 코드가 5초 안에 끝나지 않음 → 3: (가) 놓침 · A 틀림(범위 규칙으로 dev 951 + 330 변형에서 0번).",
   "바꾼 결과가 node에서 여러 줄로 펼쳐짐(배열 7개 이상 등) → 3의 결과 그대로; 읽기가 그런 줄을 거르므로 저장된 문항이 있으면 11로 매김."
  ]
 },
 "design.decisionRule": [
  "Per model m, from m's counts only (R1–R4): (가) = number of the 20 changed slots meeting every sub-clause of 7 under the two judges (a split or an undecided case = miss); (나) = number of read items with a wrong A (split = wrong). Pass iff (가) >= 16 AND (나) = 0.",
  "Pass → MODEL_SWITCHES[m].rungChangedStep = 2 in the commit after the decision, with tests/route.test.ts SHIPPED equal to the decision table, the old-build probe re-run with the ON value (R9), and README/CHANGELOG naming the model (R10, docs phase). Fail → Infinity. RUNG_CHANGED_STEP stays Infinity.",
  "haiku is measured; sonnet is not measured in 1.12.0 (its cell stays Infinity) unless the owner says otherwise (ownerQuestions); if measured, the same rule on the same frozen samples, after haiku.",
  "Void round (version/alias mismatch before or after, H_M stale) → that model's cell OFF, not re-measured in 1.12.0. Infrastructure failure: G7 M-4 10% stage rule, judged on status counts only before any answer is opened.",
  "Any later change to the request or selection of this cell (prompt bytes, isChangedShaped, changeSites, changedItem checks that widen) turns the cell OFF in that batch (D26); answer-reading-only changes mean re-reading the same frozen answers (a fail never turns ON)."
 ],
 "design.perModel": {
  "haiku": "measure. Dev (records only): final prompt (rev4) on fresh set 5 in the measured layout, each quiz twice: (가)-equivalent 19/20 and 20/20 (every kept item met all clauses by tool, stance 8 included), (나) 0 wrong of 39 read (all tool-matched to the run), O right 40/40 and N right 40/40 vs runs, 1 refusal (echo of the wrong line), 18/18 answered, 0 empty/refused/cut, max 3,718 output tokens. All five dev sets, corrected for stance 8: kept-and-passing 18/28 · 25/28 · 25/28 · 36/40 · 39/40, wrong A 0 in 149 read.",
  "sonnet": "do-not-measure. Dev set 5 (rev4): 18/20 and 18/20 kept and passing, but 1 wrong A of 36 read (JSON.stringify length compared with 30: said false, the run prints true); all sets: 5 wrong A in 143 read (≈1 in 29), i.e. about a 50% chance of 0 wrong in ~18 read items; set 4 (rev3) corrected for stance 8 was 16/20 and 15/20 on (가). The refusal problem is solved (0 refusals, 0 empty, 0 cut in 72 calls); the accuracy limit (no thinking share at effort low, no written trace allowed) is not. Cell stays Infinity."
 },
 "design.samples": {
  "design": [
   "One frozen set for the measured round (haiku), written blind by a fresh sub-agent (`claude -p --model opus --tools ''`, DISABLE_AUTOUPDATER=1) that never sees the rule wording, prompts, stance, design, code or which model is measured; frozen (chmod 444, sha256, author, UTC) before any call; recorded in docs/qa/견본.md.",
   "24 eligible concepts (20 measured + 4 spare), ALL whole-file creates: js 15 · py 9 (measured: js 13 · py 7). Each: 6–16 lines, <= 650 chars (codeFor budget 700), the blurb's quoted line within lines 1–6, 1–4 print-call lines each starting its line, prints 1–4 lines; no import/require/export; no while/do; no counted for loop (for…of/for…in/for … in only); never grows a list inside its own loop; no empty print call; no backslash; no Python set; no input/file/network/clock/random/locale/process/id/hash; nothing in CHANGED_UNSETTLED; string literals < 20 chars.",
   "Mix (each a minimum across the 24): >= 8 print inside a loop or function; >= 4 a count/bound number (range, slice end, repeat, list length) or a compared limit; >= 4 index/key/property of a looked-up item or divide by data; >= 4 string or number comparison in an if; >= 3 js printing a whole array/object (<= 6 entries); >= 2 printing a joined/sliced value; >= 2 with two near-identical lines; >= 2 printing typeof/type() or a boolean directly; >= 3 dict/object or list method; >= 3 printing 3–4 lines; >= 3 boolean / && || and or / comparison inside a condition. These are the shapes the review found missing from dev sets 1–4.",
   "Fillers written separately (another blind request): 3 내 코드 (a ts edit, a js edit, a py edit of 20–34 lines, 1–4 changed lines), 2 왜 (no code), 2 다시 도전 (a js and a py whole file with a slip { question, mine, what }).",
   "Static check before freezing (a failing record is replaced by the writer, never edited by hand): every eligible record reaches rung changed through the committed rungOf + ladderMixed + isChangedShaped with >= 3 sites (one not a string); it runs to its declared output (node twice; py PYTHONHASHSEED 1..5, all agree; unshare -n timeout 5); every filler reaches its rung; the build tool reads every blurb through the plugin's own note reading (D34 in dev set 5 found that note reading turns a blurb's \"--\" into \"-\"; build from what the plugin reads, or forbid \"--\" in blurbs).",
   "Names: no `*`, no backticks, no \"--\"; disjoint from the 205-name avoid list, the 28 G2 1.10.0 names (C01–C24, F1, F2, W1, W2), every other 1.12.0 round, and all G2 dev names in /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/design/G2/dev/NAMES.txt (sets 1–5, 133 names incl. fillers and negatives).",
   "Layout (unchanged from the committed bar): 9 quizzes — Q1–2 [c,c,c], Q3–5 [c,c,내 코드] (내 코드 at places 3, 1, 2), Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; changed concepts at steps 2/3 alternating, all due; level beginner; 20 changed slots."
  ],
  "devNamesNotToOverlap": "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/design/G2/dev/NAMES.txt — set 1 e01–e18, m1 m2 w1 s1, n1–n5; set 2 f01–f18, m3 m4 w2 s2; set 3 g01–g18, m5 m6 w3 s3; set 4 h01–h24, m7 m8 m9 w4 w5 s4 s5; set 5 k01–k24 (toLowerCase 메서드, Math.trunc 소수 버리기, padEnd 메서드, Array.from 배열 생성, Object.fromEntries, JSON.stringify 변환, fill 메서드, flat 메서드, reverse 메서드, lastIndexOf 메서드, toString 진법 변환, -- 감소 연산자, shift 메서드, substring 메서드, charAt 메서드, str.title, list.extend, dict.update, isinstance 함수, all 함수, [::-1] 역순 슬라이스, 가변 위치 인자, sorted reverse 정렬, str.find), p1 유니온 리터럴 타입, p2 JSON.stringify 문자열 변환, p3 isinstance 타입 검사, v1 git diff 변경 확인, v2 ls 파일 목록 보기, r1 sort 기본 정렬, r2 / 나눗셈 실수 결과."
 },
 "design.calls": "Exactly as the plugin calls (D20), through a copy of the probe mod: $.model.complete({ model: 'haiku' (the setting string as is), effort: 'low', system: QUIZ_SYSTEM, prompt: redactText(quizPrompt(picks, 'beginner')).text, maxTokens: 4600 (QUIZ_TRACE_TOKENS; every measured quiz has a changed pick), timeoutMs: 90000 }), 4 at a time, timing with $.clock, replies through fixEscapedTicks, read with the committed parseQuiz. Prompts built by importing the committed tree's notes.ts with only haiku's rungChangedStep = 2. Before the first call, one real request per quiz (9/9) captured from the plugin test harness at the committed tree must equal the tool's prompt file and maxTokens to the byte (D34). claude --version and the resolved alias recorded before and after (DISABLE_AUTOUPDATER=1); they must equal the 1.12.0 calibration record (installed 2.1.323; the dev pilot used H_haiku 2048 / H_sonnet 0 from the G1 pilot's 2.1.323 calibration, to be measured again). Every empty reply re-sent once through the pass-through tap as a record (stop_reason/stop_details), never as an answer. If the owner asks for a sonnet round anyway: the same frozen set and prompt file, called after haiku is complete and frozen.",
 "design.risks": [
  "A single wrong stored answer fails the round. Haiku had 0 wrong in 149 dev items; with ~19 read items and a true rate near 1% the chance of a clean round is ~80–85%.",
  "Calibration: if the 1.12.0 calibration changes haiku's thinking share from H 2048, its accuracy (which relies on it: median ~2,400 output tokens) may change. The round must use the measured H and the same CLI version.",
  "Reach is narrow: only small js/py files the assistant created whole in one Write (<= 16 lines, <= 700 chars), no ts/tsx, no edits, no imports, 1–4 prints at line start, no while/counted for. App builders (tsx, imports, edited files) will rarely meet it; practice-script learners often. Estimated, not measured.",
  "Places nearest the quoted line are often data literals rather than the concept's own token, so the question tests reading the changed program more than the concept itself. Fine for the bar; a learning-quality limit.",
  "The prompt grows ~1k characters per quiz; a model may still mislabel (refused, unread) — 1/40 on haiku set 5.",
  "D34 sample artifact: the plugin's note reading rewrites \"--\" in blurbs; the measured build tool must read blurbs as the plugin does or the writer must avoid \"--\".",
  "Sonnet: if the owner asks for a sonnet round anyway, (나) is about a coin toss (5/143 wrong in dev).",
  "Old windows: grading by the stock grade is unchanged, but the full old-build probe with the ON value is still to be run in the build phase (R9)."
 ],
 "plan.batch2": {
  "barSource": {
   "fields": "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/design/G2.json: bar, stance (0–15, incl. the clarifications 1, 2, 8, 10, 12 committed with the bar), decisionRule, samples, calls.",
   "summary": "20 changed slots in 9 quizzes: (가) ≥ 16/20 slots meet ALL of stance 7 (ㄱ)–(ㅈ) under two judges; (나) 0 wrong A among read items; every slot graded by running the shown code; empty/timeout/refused/unread = (가) miss; api-error resent up to twice; cap hit recorded, a lost slot a miss.",
   "decision": "Pass iff (가) ≥ 16 ∧ (나) = 0 → MODEL_SWITCHES.haiku.rungChangedStep = 2 in the commit after the decision; else Infinity. RUNG_CHANGED_STEP stays Infinity. Rule 6: widening needs a new round, narrowing does not.",
   "quotedFrom": "docs/qa/견본.md '1.10.0 비슷한 코드 (G2)' > '기준 · 입장 · 결정 규칙' (d684d90) plus the design's measured layout restatement (D33)."
  },
  "samples": {
   "layout": "24 eligible concepts (20 measured + 4 spare), all whole-file creates js 15 · py 9 (measured js 13 · py 7) in the enabled shape; fillers 3 내 코드 (ts, js, py edits) · 2 왜 · 2 다시 도전; 9 quizzes Q1–2 [c,c,c], Q3–5 [c,c,내 코드] (place 3, 1, 2), Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; steps 2/3 alternating, all due; beginner.",
   "writers": "2 fresh blind writers (eligible; fillers) with the mix minimums from the design; no \"--\" in blurbs or the build tool reads blurbs through the plugin's own note reading (set-5 D34 artifact).",
   "freezeChecks": "Each eligible record reaches rung changed through committed rungOf + ladderMixed + isChangedShaped with ≥ 3 sites (one not a string); runs to its declared output (node twice; py five seeds; unshare -n timeout 5); fillers reach their rung.",
   "avoid": "design/G2/dev/NAMES.txt (133 names, sets 1–5) + 205-name avoid list + 1.10.0 G2 names + impl112/NAMES-all.txt."
  },
  "calls": {
   "haiku": "9 quiz calls (QUIZ_SYSTEM, quizPrompt(picks, beginner), 4600, 90000), api-error retries only (≤ 2). Prompts from the committed tree with only haiku's rungChangedStep = 2 on top of batch 1's haiku row.",
   "D34": "9/9 quizzes captured from the test harness = the tool's prompt files and maxTokens to the byte."
  },
  "judges": "Two blind judges for the haiku label (each sees only that label); a split or undecided case counts against.",
  "stop": [
   "Merged tree cannot reproduce G2-rev4's ON request bytes (G3 off) or G3-final's (G2 off) to the byte, or 1.9.0 OFF bytes → no bar commit for that G; report to the owner. Owner default: the G whose bytes cannot be reproduced is recorded under '설계만 하고 재지 않음' (reason: build ≠ design bytes) and the next batch goes on; if the OFF bytes cannot be reproduced, the joint build is not committed and batches 2 and 3 are skipped (recorded).",
   "D26 recheck of a batch-1 ON cell (isRuleDrill notes/tier-2/N2 checkPrompt request bytes or selection, notePrompt, writeNote path) differs → fix before the build commit; a (다) reading difference (parseCheck {rule}, ruleFixReply) → fix, or else after the commit the R5 re-read of the frozen answers (a pass stands only if it still passes).",
   "A single wrong A among read items fails the round (no stop; recorded)."
  ],
  "switchCommit": "If pass: MODEL_SWITCHES.haiku.rungChangedStep = 2; route SHIPPED; full old-build probe with the ON value (R9); recheckRemap per ON quiz; measured prompts re-made byte-identical.",
  "usage": "haiku 9 calls (+ retries): ≈ 40k input, ≈ 25k output tokens. Opus: 2 writers, 2 judges, translation check, audit, 2 reviewers ≈ 8 runs. The joint build (G2 + G3, ~1,500 changed lines in notes.ts, ~100 in register.tsx, ~120 test changes) is the main cost of this batch."
 }
}

=== SECTION (Korean) ===

## 1.12.0 비슷한 코드 (G2): 플러그인이 한 곳을 바꾸고, 모델은 바꿀 곳을 고르고 바뀌기 전후의 출력만 씀 (rungChangedStep) · haiku

### 짓기 (두 모델 모두 끔, 3/5 첫 커밋 3f9084c)

설계 G2(1.12.0 G2-C rev4)의 코드는 G3(1.12.0 처음 보는 코드)의 코드와 한 메커니즘으로 3f9084c에 끈 스위치 뒤로 들어갔습니다(위 'G2+G3 함께 짓기'). 무엇을 바꿨고 무엇을 확인했는지(켠 바이트 52/52 · 끈 바이트 · 옛 창 여섯 · 돌연변이 탐침 12 · isRuleWide D26 재확인 · 관문)는 그 커밋 본문에 있습니다. hooks/notes.ts sha256 `aca7544f47733164a3a11d984242232d688360de4a9b164b14d82ea2f783a684` · hooks/register.tsx `3f5855ca8dca4d4e00a830c2befbda48c908669e26d37e4942bd80c29144c3f1`. RUNG_CHANGED_STEP · RUNG_NEW_STEP은 Infinity 그대로이고, MODEL_SWITCHES 두 줄은 `{ ...SWITCHES_OFF, isRuleWide: true }` 그대로입니다. 짓기 때의 얼린 입력 백업은 `impl112/backup/b2-build.tar` sha256 `46c848ecbf5787af2204e2be63f2eab06439d91d863675be055cd29b45c94865`(묶음 1 감사 교훈 3: 백업 tar의 sha256은 견본.md에 적음)입니다.

### 기준 · 입장 · 결정 규칙 (재기 전에 정함: __BARTIME__ UTC, 견본을 쓰거나 모델을 부르기 전)

이 절은 공통 입장 절('1.10.0 모델별 갈래 (G7): 두 모델을 재는 공통 입장'의 M-0 ~ M-15, B-1 ~ B-15, R0 ~ R11)을 따릅니다. 그 글의 '1.10.0'은 '1.12.0'으로, '묶음 1 보정 기록'은 위 '### 보정 기록 (1.12.0)'으로 읽습니다(위 '1.12.0 미뤄 둔 기능 다시 설계' 절의 첫 항목). 같은 절의 '셈을 지키는 규칙'(CLI 고정 · 사용량 관문 · 끊긴 스테이지 규칙 · 러너 규칙 · 백업 규칙)과 '이름 목록'도 이 절을 다스립니다.

- 잰 설계: 설계 파일 `impl112/design/G2.json`(sha256 `494596455c0cec7a55882430fb82acdcc4f660152c00ad3d05d208c968011c9c`), 시제품 패치 `impl112/design/G2/proto/G2-rev4-proto.diff`(`f6ee8f3d7d4c6338cac953983709974948d5b331b977fb2ade703a30f2998c83`). 코드는 짓기 커밋 3f9084c(위)입니다. 계획 `impl112/plan112.json`의 묶음 2(3/5)입니다. 이 커밋이 가리키는 코드 커밋은 3f9084c(2026-11-14 06:04 UTC 커밋)입니다(입장 머리말의 '가리키는 코드 커밋 해시').
- 이 절의 기준 · 결정 규칙 · 모델마다 · 견본 · 부르기 · 위험 글은 설계의 bar · decisionRule · perModel · samples · calls · risks 필드와 계획 묶음 2의 barSource · samples · calls · judges · stop 글을 한국어로 옮긴 것입니다. 수와 조항은 하나도 바꾸지 않았습니다. 설계의 입장(stance)은 처음부터 한국어라 글자 그대로 옮겼습니다.
- M-0 대응: G2의 상한 닿음(기준에 들지 않고 기록; 그것 때문에 잃은 자리는 (가) 놓침) → M-5의 `output_tokens ≥ maxTokens + H_M`, 1.12.0 보정 기록의 H_haiku 2048. 이 퀴즈 9개는 모두 maxTokens 4600(QUIZ_TRACE_TOKENS)이라 haiku의 상한 닿음은 `output_tokens ≥ 6648`입니다. M-6: G2의 기준에는 토큰 절댓값 줄이 없어(수와 비율뿐) 바꿀 것이 없습니다. 판정자는 꼬리표마다 둘(입장 14, M-8, D7)이고, 다시 보내기는 입장 2의 api-error 줄과 M-4 셋째 줄(10%)입니다(아래 '읽는 법' 1).
- 수준: 견본은 beginner로 잽니다(켠 값도 beginner에서만 닿음, 1.10.0 계획 고침 D17).
- 잴 모델: haiku 하나. sonnet 칸은 Infinity 그대로이고 재지 않습니다(위 '1.12.0 설계만 하고 재지 않음'의 'G2 비슷한 코드 · sonnet', 주인 물음 5의 기본값).
- 앞선 칸 재확인(D26): 묶음 2가 다시 확인할 칸은 isRuleWide haiku · isRuleWide sonnet입니다(isRuleDrill은 묶음 1에서 두 모델 모두 끔이라 해당 없음). 짓기 커밋 전 작업 트리에서 `impl112/d26/rulewide.mjs`로 639경우(haiku 319 · sonnet 320) 다름 0이었고, G6 N2 채점 바이트(checkPrompt {rule})와 parseCheck 읽기도 다름 0이었습니다(3f9084c 본문). 이 기준 커밋은 견본.md만 바꿉니다.
- 주인 물음(위 '주인 물음 (기본값)' 5 · 6 · 7 · 18, 다른 답이 오지 않아 기본값): 5 — sonnet은 재지 않음. 6 — 좁힌 범위(도우미가 통째로 만든 js/py 파일만, ≤ 16줄, ts/tsx 없음, 고침 없음, import 없음)를 받아들이고 그대로 잼. 7 — quizRun.changedMissed(저장하지 않는 세션 상태)를 둠. 18 — 함께 짓기가 G2-rev4의 켠 요청 바이트를 다시 냈으므로(52/52, 3f9084c 본문) G2 haiku는 잽니다.

#### 기준

출처: 설계 bar(아래 옮김)와 계획 묶음 2의 barSource. 설계 bar는 이 파일의 '1.10.0 비슷한 코드 (G2)' > '기준 · 입장 · 결정 규칙'(d684d90)의 기준에서 수를 바꾸지 않습니다: 비슷한 코드로 고른 20자리에서 (가) 입장 7을 모두 갖춘 자리 16개 이상, (나) 읽힌 문항의 틀린 A 0개, 20자리 모두 돌려서 매김(1.8.0 · F4의 수).

설계 bar(옮김)
- 마지막으로 커밋된 기준(이 파일의 '1.10.0 비슷한 코드 (G2)' → '기준 · 입장 · 결정 규칙', d684d90; 수는 1.8.0과 F4의 것)에서 바꾸지 않습니다. 더 너그러운 것은 없습니다.
- 단위: 퀴즈 9개에서 비슷한 코드로 고른 20자리. 다른 문항(내 코드, 왜, 다시 도전)은 기록만 합니다.
- (가) 20자리 가운데 16자리 이상이 입장 조항 7의 (ㄱ)–(ㅈ)을 모두 갖춤.
- (나) 읽힌 문항 가운데 틀린 A 0개(입장 6, 11).
- 모든 자리는 보인 코드를 보인 그대로 돌려 매깁니다(unshare -n timeout 5; 채워 넣는 것 없음).
- 빈 답, 시간 한도, 거절되었거나 읽히지 않은 자리(플러그인의 읽기가 거절해 문항을 저장하지 않은 자리 포함): (가) 놓침, (나) 밖, 다시 보내지 않음. 다시 보내는 것은 api-error(429/5xx, 토큰 0, 글 없음)뿐이고 두 번까지입니다. 상한 닿음(output_tokens ≥ 4600 + H_haiku)은 기록합니다. 그것 때문에 잃은 자리는 (가) 놓침입니다. (1.12.0 보정 기록: H_haiku = 2048 → output_tokens ≥ 6648.)
- 꼬리표(가린 꼬리표)마다 판정자 둘, 어느 쪽도 다른 꼬리표를 보지 않습니다. 갈림이나 입장이 가르지 못하는 경우는 불리한 쪽으로 셉니다((가) 놓침, (나) 틀림). 답을 연 뒤에는 조항을 더하거나 바꾸거나 다시 읽지 않습니다.
- 결정 규칙 3: 모델마다, (가) ≥ 16/20 그리고 (나) 틀림 0일 때만 넘음. 넘으면 → 결정 다음 커밋에서 MODEL_SWITCHES[모델].rungChangedStep = 2(R6), 아니면 Infinity. RUNG_CHANGED_STEP은 Infinity 그대로(D1). 모델 사이에 옮기지 않음(R1/R2).
- 규칙 2: 설계마다 모델마다 한 회; 고친 문장 · 범위 · 입장으로 다시 재지 않음. 규칙 5: 설계의 코드는 스위치 뒤에 남음. 규칙 6: 켠 뒤 범위를 넓히는 것(확장자 · 고침 · ts를 더하거나, isChangedShaped / CHANGED_UNSETTLED 조건 하나라도 빼거나, changedItem 확인을 느슨하게 함)은 새 회차가 필요하고, 좁히는 것은 필요 없음.
- 잰 짜임은 범위가 좁아졌기 때문에만 다시 적습니다(D33: 잰 것 = 켠 것). 가린 채 쓴 개념 24개(20 + 예비 4), 모두 통째로 만든 파일: js 15 · py 9(잴 것: js 13 · py 7), 켠 꼴로(아래 견본); 채우는 것은 내 코드 3 · 왜 2 · 다시 도전 2; 퀴즈 9개 Q1–2 [c,c,c], Q3–5 [c,c,내 코드], Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; 단계 2/3을 번갈아, 모두 때 됨; beginner; maxTokens 4600; timeoutMs 90000; effort low; QUIZ_SYSTEM; 어느 모델을 재든 같은 프롬프트 파일; D34 9/9 바이트 맞춤.
- 기준과 함께 커밋하는 입장의 밝힘(모두 중립이거나 더 엄격함, 입장 참고): 2(읽기가 거절한 자리는 읽히지 않은 자리), 8(파일 전체에서는 조각 결과 = 학습자 결과, 글자 그대로 읽음), 10(플러그인의 lead와 hint를 모델 글처럼 매김; hint의 줄 번호와 따온 줄이 맞아야 함 — 더 엄격함), 12(범위에 ts 없음), 1(C, O와 되풀이 줄은 매기지 않음: 저장되지 않음).
- 회차 전: 설치된 CLI로 1.12.0 보정; 판과 별칭을 앞뒤로; 다르면 회차는 무효(칸 끔).

계획 묶음 2의 글(같은 기준): 퀴즈 9개의 비슷한 코드 20자리. (가) 두 판정자 아래에서 입장 7 (ㄱ)–(ㅈ)을 모두 갖춘 자리 ≥ 16/20; (나) 읽힌 문항의 틀린 A 0; 모든 자리는 보인 코드를 돌려 매김; 빈 답 · 시간 한도 · 거절 · 읽히지 않음 = (가) 놓침; api-error는 두 번까지 다시 보냄; 상한 닿음은 기록, 잃은 자리는 놓침.

1.10.0 기준과 다른 점(재기 전에 적는 까닭)
- 수(16/20, 틀림 0)와 단위(20자리, 9퀴즈)는 같습니다.
- 잰 짜임: 1.10.0은 create와 edit, js · ts · py 개념 20개를 썼습니다. 1.12.0은 범위가 '도우미가 통째로 만든 js/py 파일'로 좁아져(주인 물음 6), 잰 것 = 켠 것(D33)이 되도록 짜임을 그 범위로 다시 적었습니다(설계 bar 열째 줄). 퀴즈 꼴(세 칸, 내 코드 · 왜 · 다시 도전 자리)은 1.10.0과 같습니다.
- 입장의 밝힘 다섯(2 · 8 · 10 · 12 · 1)은 중립이거나 더 엄격합니다. 특히 10은 1.10.0에서 기록만 하던 hint를 (가)에 넣습니다.
- 상한 닿음의 H_M은 1.12.0 보정 기록의 값(H_haiku 2048)입니다. 1.10.0의 haiku도 2048이었습니다(묶음 1 보정). 그래서 haiku의 줄 6648은 1.10.0과 같습니다.
- 1.10.0의 sonnet 칸 측정은 이 판에 없습니다(재지 않음).

#### 판정의 입장

설계의 입장(stance) 글입니다. 머리말과 조항 0–15, 조항 15의 미리 가른 경계 사례를 설계 글자 그대로 옮겼습니다. 판정은 이 글자대로만 셉니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 '다시 잴 때'에 적습니다(M-11).

판정의 입장 (G2, 1.12.0 G2-C). 기준 · 결정 규칙 · 짜임 · 견본 쓰기 프롬프트와 함께, 견본을 쓰거나 부르기 전에 docs/qa/견본.md 새 절로 한 커밋에 넣습니다(UTC 시각, 가리키는 코드 커밋 해시). 매기는 쪽은 이 글의 조항만 따르고 판정마다 조항 번호를 적습니다. ⚙ 조항은 eval 도구(부르기 전에 sha256으로 얼림)가 세고, ✎ 조항만 매기는 하위 에이전트가 매깁니다. 1.10.0의 조항 번호와 뜻을 그대로 두고, 이 설계에서 쓰이지 않는 갈래는 "쓰이지 않음"으로 적었습니다.

0 셈의 단위: 비슷한 코드로 고른 20자리(퀴즈 9개). 같은 퀴즈의 내 코드 · 왜 · 다시 도전 문항은 셈 밖이고 기록만 합니다.

1 읽기 ⚙: 플러그인처럼 fixEscapedTicks → 그 커밋의 parseQuiz로 읽어 저장될 문항(question · hint · answer · kind · rung)만 매깁니다. 모델의 C · O · N 줄, 되풀이 줄(R), 바꿀 수 있는 곳 목록과 날글은 저장되지 않으므로 판정 대상이 아니며, O가 틀리고 N이 맞은 자리도 저장된 문항(N)만으로 매깁니다. 읽힌 문항은 그 번호 자리의 개념으로 플러그인이 짠 문항입니다.

2 답이 없는 자리 ⚙: 빈 답(empty-reply · API 거절), 시간 한도(90초)에 끊긴 답, 읽히지 않은 자리, 플러그인의 읽기(changedItem)가 문항을 내지 않은 자리는 (가)에서 놓침, (나)에서는 셈 밖입니다(학습자에게 보이지 않음). 상한에 닿았어도 읽힌 문항은 읽힌 그대로 매깁니다. 다시 보내는 것은 글이 하나도 없고 출력 토큰이 0인 api-error(상태 429 · 5xx)뿐이며 같은 프롬프트로 두 번까지, 모두 기록합니다. 그래도 실패하면 그 퀴즈의 자리는 모두 놓침입니다. 빈 답 · 시간 끊김 · 상한 닿음 · 읽기가 거른 자리는 다시 보내지 않습니다. 빈 답은 기록으로만 탭으로 한 번 더 보내 stop_reason을 적습니다.

3 돌리기 ⚙: 문제의 코드: question의 펜스 블록(플러그인이 넣은 하나)입니다. 언어는 펜스 이름(js · python)입니다. 빈 임시 폴더에서 `unshare -n timeout 5`로, 표준 입력을 비우고 돌립니다. js: `node 파일` 두 번. py: `env -i PATH="$PATH" LANG=C.UTF-8 PYTHONHASHSEED=<n> python3 -s -P -B 파일`을 n = 1..5로 다섯 번. 결과는 표준 출력의 줄들입니다(마지막 줄이 줄바꿈 없이 끝나도 한 줄). 끝 코드가 0이 아니면 그 앞까지의 출력 뒤에 마지막 예외의 이름(메시지는 뺌) 한 줄을 더합니다. 표준 오류는 결과에 넣지 않습니다. 돌린 결과가 서로 하나라도 다르거나 5초를 넘으면 그 문항은 (가) 놓침이고 A는 틀림입니다. 학습자 결과: 견본을 얼리기 전 확인 때 학습자 파일 전체(= 바꾸기 전의 보인 코드)를 같은 규칙으로 돌려 얼린 줄들입니다. 도구 판(node · python · Claude Code)을 적습니다.

4 채우지 않음: 블록에 없는 정의 · import · 입력 · 파일 · 준비를 덧붙이지 않습니다. 나는 오류도 결과입니다. (이 설계의 문제 코드는 학습자 파일 전체라 채울 것이 생기지 않지만 규칙은 그대로 둡니다.) 4의 "글로 말한 바꿈"은 쓰이지 않습니다(바꿈은 플러그인이 코드에 넣음).

5 물은 것 ⚙: 문제 글은 플러그인의 고정 글(CHANGED_LEAD)이고 "이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름"을 묻습니다. 그래서 물은 것은 언제나 결과 전체(오류로 멈추면 그 앞 출력과 오류 이름)입니다. 매기는 쪽이 Q만 보고 물은 것을 정하는 단계는 쓰이지 않습니다. question이 이 글로 시작하지 않으면 10에서 놓침이고, (나)는 결과 전체와 견줍니다.

6 표기 맞춤 ⚙: 1.10.0 조항 6을 글자 그대로 씁니다(A와 결과, 결과끼리 견줄 때 모두). 줄마다 앞뒤 공백을 지우고, 이어진 공백은 하나로, 글자 · 숫자(한글 포함)가 아닌 문자 바로 옆의 공백은 지웁니다. 따옴표 종류는 가리지 않습니다. 결과 줄이 따옴표로 시작하고 끝나지 않을 때만 A 줄 전체를 감싼 따옴표 · 백틱을 뗍니다. js에서 결과 줄에 따옴표로 감싼 객체 키가 없을 때만 A의 `"a":` · `'a':`를 `a:`로 봅니다(py는 그대로). 줄 끝 마침표 하나와 true · false · none · null · undefined · nan의 대소문자는 보지 않습니다. 결과 끝의 빈 줄은 견주지 않고, 가운데 빈 줄은 A의 빈 줄이나 '(빈 줄)'과 같습니다. 결과가 여러 줄이고 A가 한 줄이면 결과 줄들을 ', ' · ' ' · '과 ' · '와 ' · ' 그리고 ' · ' → ' 가운데 하나로 이어 맞춘 것이 A와 같으면 같음입니다(학습자가 쉼표로 이어 쓴 답과 같은 규칙). 그 밖의 글자 · 값 · 차례 · 줄 수 · 괄호 · 숫자 표기 · 대소문자는 그대로 견줍니다. 앞 공백만 다른 줄(padStart · ljust · rjust가 찍은 `   5`와 `5`)은 이 규칙으로 같음입니다(1.10.0과 같음, 바꾸지 않음).

7 (가) 코드 다름 · 답 다름: 아래를 모두 갖춘 자리만 넘음으로 셉니다. (ㄱ) ⚙ 읽힌 문항의 rung이 changed. (ㄴ) ⚙ 코드를 바꿨음: 3의 문제 코드가 학습자 조각(= 파일 전체)과 6의 맞춤과 줄 끝 `;` · 주석 뺌 뒤 줄 단위로 (i) 같지 않고 (ii) 찍는 줄(한 줄짜리 console.log(…) · print(…))을 뺀 나머지 줄이 학습자 줄들의 부분열이 아님. (ㄷ) ⚙ 그 개념의 코드에서 왔음: 학습자 조각의 핵심 줄(토큰 4개 이상, 괄호뿐 · else · `return 이름` · 이름 하나만 찍는 줄이 아님; 없으면 토큰 2개 이상) 가운데 하나 이상이 보인 코드의 어느 줄과 토큰이 같거나 하나만 다름(codeAsRead 토큰). (ㄹ) ⚙ 정의 빠짐이 아님: 결과가 ReferenceError/NameError로 끝나고 그 이름이 블록 안에서 한 번도 선언 · 대입 · 매개변수 · for 변수 · catch 변수로 나오지 않으면 놓침(TDZ · UnboundLocalError는 들지 않음). (ㅁ) ⚙ kind가 predict. (ㅂ) ⚙ 펜스 블록이 하나. (ㅅ) ⚙ 답이 다름(8). (ㅇ) ⚙/✎ 문제 글이 맞음(10). (ㅈ) ⚙ 3의 여러 번 돌린 결과가 모두 같고 5초 안(ts 갈래는 쓰이지 않음: 12).

8 답 다름 ⚙: 학습자 결과: 3의 얼린 학습자 결과. 조각 결과: 1.10.0 조항 8의 정의를 그대로 씁니다 — 학습자 결과 가운데, 보낸 codeFor 조각이 파일에서 차지하는 줄 범위 안의 print 호출이 찍은 줄들. 이 설계의 조각은 파일 전체이므로(isWholeShown) 모든 호출이 범위 안에 있고, 조각 결과는 학습자 결과와 같습니다(새 해석이 아니라 정의를 그대로 적용한 것). 견줄 것은 물은 것(5: 결과 전체)입니다. 6으로 맞춘 뒤 아래 가운데 하나면 같음(놓침): (a) 결과 전체가 학습자 결과 전체와 같음. (b) 결과 줄들이 차례 그대로 학습자 결과 안에 이어진 줄들로 있음(어디서 시작해도; 한 줄이면 학습자 결과의 어느 줄과 같아도). (c) 결과 줄마다 학습자 결과의 같은 순번 줄과 같음. (d) · (e)(찍지 않는 이름, 줄 수 · 횟수를 물음)는 물은 것이 언제나 결과 전체라 쓰이지 않습니다. 결과가 오류 이름으로 끝나면 그 줄은 학습자 결과의 어느 줄과도 다릅니다. 결과가 오류 이름 한 줄뿐이면 다름입니다.

9 예측이 아닌 문항: 쓰이지 않음: 플러그인이 kind를 predict로 씁니다. 도구 결함으로 다른 kind가 저장되면 7(ㅁ) 놓침, (나)는 11로 매깁니다.

10 문제 글 ⚙: lead와 hint는 플러그인이 쓴 고정 글이지만 모델 글처럼 매깁니다(1.10.0보다 엄격: 그때 H는 기록만). (ㅇ)를 갖추려면 모두: (i) question이 CHANGED_LEAD 글 그대로로 시작하고 그 뒤에 펜스 블록 하나만 있음; (ii) 보인 코드와 학습자 코드가 정확히 한 줄에서만 다름("한 곳을 바꿨습니다"가 참); (iii) hint의 "k번째 줄"이 그 다른 줄의 번호(보인 블록의 첫 줄을 1로, 빈 줄 포함)와 같음; (iv) hint가 줄을 따왔으면 따온 글이 그 줄의 앞뒤 공백을 뺀 것과 글자 그대로 같음. hint는 바뀐 줄을 알려 줄 뿐 결과나 따라간 과정을 말하지 않으므로 답을 미리 말한 것으로 보지 않습니다. 하나라도 어긋나면 (가) 놓침입니다.

11 (나) A 맞음: ⚙ 먼저 도구가 A 전체를 6으로 맞춰 결과 전체와 같은지 봅니다. 같으면 맞음. ✎ 아니면 매기는 쪽이 봅니다: A가 결과의 줄을 모두 차례대로 말하고(6의 "그대로 견주는 것"으로) 다른 틀린 말이 없으면 맞음. 틀림: 결과 전체 가운데 일부만 쓴 A(반복이 찍는 여러 줄 중 마지막 줄만 등), 줄여 쓴 A(… · 등 · 생략), 오류로 멈추는 결과에 출력만 쓴 A, 오류가 첫 출력 전에 나는데 그 앞에 찍힌 줄을 쓴 A, 오류 이름을 다르게 댄 A, 둘 이상을 답으로 내놓은 A, 학습자 원래 코드의 답을 쓴 A, node가 여러 줄로 펼쳐 찍는 값을 한 줄로 쓴 A(결과가 여러 줄이고 A도 여러 줄이면 줄 수가 달라 틀림; A 전체가 한 줄일 때만 6의 잇기 규칙). 맞음: 오류 메시지 글은 견주지 않음(이름만). 저장된 A에는 언제나 오류 이름이 있습니다(읽기가 이름 없는 오류 줄을 받지 않음).

12 ts: 쓰이지 않음: ts는 범위 밖이고(RUNG_CHANGED_EXTS = js, py) 견본에 넣지 않습니다. 도구 결함으로 ts 문항이 저장되면 (가) 놓침, (나)는 3으로 돌린 결과와 견줍니다.

13 번호가 엇갈린 답 ⚙: parseQuiz가 짝지은 번호대로 매깁니다. changedItem은 그 번호 자리 개념의 코드로만 문항을 짜고 C의 번호가 자리 번호와 다르면 문항을 내지 않으므로, 엇갈린 답은 읽히지 않은 자리(2)로만 셉니다. C · O · N을 다시 쓴 답은 플러그인처럼 마지막 글로 읽습니다(1).

14 매기는 차례와 갈림: 꼬리표마다 매기는 하위 에이전트 둘이 따로 매깁니다. 둘 다 설계 · 견본 쓰기 · 부르기에 끼지 않은 새 하위 에이전트이고, 이 글과 도구가 낸 파일만 봅니다(모델 이름, 토큰, 시간은 빠짐). 두 판정이 갈린 문항과 이 글이 가르지 못하는 경우는 기능에 불리한 쪽((가) 놓침, (나) 틀림)으로 셉니다. 재는 세션은 판정을 바꾸지 않고, 출력을 본 뒤 조항을 더하거나 고치거나 다시 읽지 않습니다. 고칠 것은 '다시 잴 때'에 적기만 합니다.

15 미리 가른 경계 사례
- 1.10.0 기록: W10 부모 클래스가 블록에 없음 → 7(ㄹ) (이 범위에서는 생기지 않음). 줄인 출력 → 11 틀림. 되돌리기 · 바꿔 보기 · 왜 → 9(쓰이지 않음). Q가 지금 출력을 틀리게 말함 → 10. Object.freeze A length 1 vs TypeError → 11 틀림. 빈 답 · 상한에 잘린 끝 → 2. 그대로 보임 · 몇 줄만 떼어 보임 → 7(ㄴ). 1.8.0 ===/== 출력 그대로 → 8 같음. node `[ 1, 2, 3, [ 4 ] ]` vs A `[1, 2, 3, [4]]` → 6 같음. 산문 A → 11. pythonista[7:]를 ista로 → 11 틀림. 두 블록으로 보임 → 7(ㅂ). 두 번 돌린 결과가 다름 → 3. node가 깊은 배열을 `[Array]`로 줄여 찍음 → 3 · 6 · 11(통째로 쓴 A는 틀림). 끝에 빈 줄을 찍음 → 6 견주지 않음. `1 2`와 `12` → 6 다름. JSON.stringify의 `{"a":1}`을 `{a:1}`로 쓴 A → 6 다름. T 줄만 있고 유형이 빔 → 쓰이지 않음(9).
- (dev) for-else: 바꾼 뒤 'hana 없음' 줄이 빠지고 결과가 학습자 결과의 둘째 줄 하나만 남음 → 8(b) 같음, (가) 놓침(지금 읽기는 이런 N을 'subset'으로 거르므로 읽히지 않은 자리, 2와 같은 결과).
- (dev) continue · sum · min: 결과가 학습자 결과의 앞 줄들 또는 가운데 한 줄 → 8(b) 같음.
- (dev) 반복이 네 줄을 찍는데 A가 마지막 줄만 씀 → 11 틀림.
- (dev) repeat(-1)이 첫 출력 전에 RangeError를 내는데 A가 그 앞에 찍힌 줄을 씀 → 11 틀림. 결과가 오류 이름 한 줄이면 A도 그 이름 한 줄이어야 맞음.
- (dev) 기준 점수를 바꾼 grade()의 흐름을 잘못 따라 '서아 B'라고 씀(결과 '서아 A') → 11 틀림.
- (dev) JSON.stringify 문자열의 길이 비교(text.length > 30)를 잘못 셈 → 11 틀림.
- (dev) A 줄 끝 마침표(`true.`)·대소문자(`TRUE`/`True` in js) → 6: 마침표 하나와 true/false 대소문자는 보지 않음.
- (dev) py `<class 'bool'>`, js typeof의 `number` → 결과 그대로; 6으로 견줌.
- 앞 공백(padStart · rjust)만 다른 줄 → 6 같음(1.10.0 그대로).
- 가운데 빈 줄: 저장된 A의 빈 줄('(빈 줄)'을 읽기가 빈 줄로 바꿈)은 결과의 가운데 빈 줄과 같음; 결과에 가운데 빈 줄이 있는데 A에 없으면 줄 수가 달라 11 틀림.
- py 집합 · 사전 차례: 다섯 번의 결과 가운데 하나라도 다르면 3 → (가) 놓침 · A 틀림(범위에서 집합은 빠짐; 사전은 넣은 차례로 같음).
- node가 클래스 인스턴스를 `Point { x: 1 }`로 찍는데 A가 `{ x: 1 }` → 6 그대로 견주는 것이라 다름 → 11 틀림.
- 실수 표기(0.30000000000000004, 9240.0) → 6 그대로; 다르게 쓴 A는 틀림.
- A가 여러 줄 결과를 쉼표로 이어 한 줄로 씀(lead가 허용) → 6의 잇기 규칙으로 같으면 맞음.
- 보인 코드가 학습자 코드와 두 줄 이상에서 다름(도구 결함) → 10(ii) 놓침.
- hint의 줄 번호나 따온 줄이 바뀐 줄과 다름(도구 결함) → 10(iii)/(iv) 놓침.
- O가 틀리고 N이 맞음 / O가 맞고 N이 틀림 → 1: 저장된 N만 매김(N이 틀리면 11 틀림).
- 모델이 C · O · N을 다시 써서 읽기가 마지막 글을 씀 → 1 · 13: 저장된 문항만 매김.
- 바꾼 코드가 5초 안에 끝나지 않음 → 3: (가) 놓침 · A 틀림(범위 규칙으로 dev 951 + 330 변형에서 0번).
- 바꾼 결과가 node에서 여러 줄로 펼쳐짐(배열 7개 이상 등) → 3의 결과 그대로; 읽기가 그런 줄을 거르므로 저장된 문항이 있으면 11로 매김.

#### 결정 규칙

설계 decisionRule(옮김)
1. 모델 m마다, m의 수로만(R1–R4): (가) = 20개의 비슷한 코드 자리 가운데 두 판정자 아래에서 조항 7의 모든 갈래를 갖춘 자리의 수(갈림이나 가르지 못한 경우 = 놓침); (나) = 읽힌 문항 가운데 A가 틀린 문항의 수(갈림 = 틀림). (가) ≥ 16 그리고 (나) = 0일 때만 넘음.
2. 넘음 → 결정 다음 커밋에서 MODEL_SWITCHES[m].rungChangedStep = 2. 그때 tests/route.test.ts의 SHIPPED는 결정 표와 같고, 옛 빌드 확인을 켠 값으로 다시 돌리며(R9), README/CHANGELOG가 그 모델을 적습니다(R10, 문서 단계). 못 넘음 → Infinity. RUNG_CHANGED_STEP은 Infinity 그대로.
3. haiku를 잽니다. sonnet은 주인이 달리 말하지 않으면(주인 물음) 1.12.0에서 재지 않습니다(그 칸은 Infinity 그대로). 잰다면 같은 얼린 견본으로, haiku 뒤에, 같은 규칙으로 잽니다.
4. 무효인 회(앞이나 뒤의 판/별칭이 다름, H_M이 낡음) → 그 모델의 칸은 끔, 1.12.0에서 다시 재지 않음. 기반 실패: G7 M-4의 10% 스테이지 규칙, 어느 답도 열기 전에 상태 수로만 판정.
5. 이 칸의 요청이나 고르기를 뒤에 바꾸는 것(프롬프트 바이트, isChangedShaped, changeSites, 넓히는 changedItem 확인)은 그 묶음에서 이 칸을 끕니다(D26). 답 읽기만 바꾸면 같은 얼린 답을 다시 읽습니다(못 넘음이 켬으로 바뀌지 않음).

계획 묶음 2의 글(같은 규칙): (가) ≥ 16 ∧ (나) = 0일 때만 넘음 → 결정 다음 커밋에서 MODEL_SWITCHES.haiku.rungChangedStep = 2; 아니면 Infinity. RUNG_CHANGED_STEP은 Infinity 그대로. 규칙 6: 넓히는 것은 새 회차가 필요하고, 좁히는 것은 필요 없음. 넘으면(switchCommit): MODEL_SWITCHES.haiku.rungChangedStep = 2; route SHIPPED; 켠 값으로 옛 빌드 확인 전체(R9); 켠 퀴즈마다 recheckRemap; 잰 프롬프트를 다시 만들어 바이트까지 같음.
- 판정자(계획 judges): haiku 꼬리표에 가린 판정자 둘(각자 그 꼬리표만 봄); 갈림이나 가르지 못한 경우는 불리한 쪽으로 셈.
- 멈춤(계획 stop)
  - 합친 트리가 G2-rev4의 켠 요청 바이트(G3 끔)나 G3-final의 것(G2 끔)이나 1.9.0 끈 바이트를 바이트까지 다시 내지 못함 → 그 G에는 기준 커밋이 없고 주인에게 알림. 주인 기본값: 바이트를 다시 내지 못한 G는 '설계만 하고 재지 않음'(까닭: 짓기 ≠ 설계 바이트)에 적고 다음 묶음으로 감; 끈 바이트를 다시 내지 못하면 함께 짓기를 커밋하지 않고 묶음 2와 3을 건너뜀. (짓기에서 모두 다시 냈습니다: 3f9084c 본문.)
  - 묶음 1의 켠 칸의 D26 재확인(isRuleDrill 노트/2단/N2 checkPrompt 요청 바이트나 고르기, notePrompt, writeNote 길)이 다름 → 짓기 커밋 전에 고침; (다) 읽기의 다름(parseCheck {rule}, ruleFixReply) → 고치거나, 아니면 커밋 뒤 얼린 답의 R5 다시 읽기(넘음은 다시 읽어도 넘을 때만). (묶음 1이 isRuleDrill을 켜지 않아 해당 없음; isRuleWide는 다름 0.)
  - 읽힌 문항 가운데 틀린 A가 하나라도 있으면 회차는 못 넘음(멈추지 않음; 적음).

#### 모델마다 (설계 perModel, 기록만 · B-12, 결정에 들지 않음)

- haiku: 잼. 개발 기록(기록만): 마지막 프롬프트(rev4)를 새 세트 5에서 잰 짜임으로, 퀴즈마다 두 번: (가)에 해당하는 수 19/20과 20/20(남은 문항은 모두 도구로 모든 조항을 갖춤, 입장 8 포함), (나) 읽힌 39개에서 틀림 0(모두 도구로 돌린 결과와 맞음), O 맞음 40/40 · N 맞음 40/40(돌린 결과와 견줌), 거절 1(틀린 줄의 되풀이), 18/18 답함, 빈 답 · 거절 · 끊김 0, 가장 큰 출력 3,718토큰. 다섯 개발 세트 모두를 입장 8로 고쳐 세면 남아서 넘은 것 18/28 · 25/28 · 25/28 · 36/40 · 39/40, 읽힌 149개에서 틀린 A 0.
- sonnet: 재지 않음. 개발 세트 5(rev4): 남아서 넘은 것 18/20과 18/20이지만 읽힌 36개에 틀린 A 1(JSON.stringify의 길이를 30과 비교: false라 썼으나 돌리면 true); 모든 세트에서 읽힌 143개에 틀린 A 5(≈ 29개에 1), 곧 읽힌 문항 ~18개에서 틀림 0일 확률이 약 50%; 세트 4(rev3)를 입장 8로 고쳐 세면 (가)에서 16/20과 15/20. 거절 문제는 풀렸습니다(72호출에서 거절 0, 빈 답 0, 끊김 0). 정확도의 한계(effort low에서 생각 몫 없음, 적어 내는 따라가기 허락 안 됨)는 풀리지 않았습니다. 칸은 Infinity 그대로.

#### 견본의 짜임

설계 samples 글(옮김)
- 잰 회차(haiku)를 위한 얼린 세트 하나. 규칙 글 · 프롬프트 · 입장 · 설계 · 코드나 어느 모델을 재는지를 보지 않는 새 하위 에이전트(`claude -p --model opus --tools ''`, DISABLE_AUTOUPDATER=1)가 가린 채 씁니다. 어느 부르기보다 먼저 얼리고(chmod 444, sha256, 쓴 쪽, UTC) docs/qa/견본.md에 적습니다.
- 조건에 드는 개념 24개(잴 것 20 + 예비 4), 모두 통째로 만든 파일: js 15 · py 9(잴 것: js 13 · py 7). 하나마다: 6–16줄, ≤ 650자(codeFor 몫 700), 설명이 따온 줄이 1–6번째 줄 안, 찍는 호출 줄 1–4개가 각각 줄 머리에서 시작, 1–4줄을 찍음; import/require/export 없음; while/do 없음; 세는 for 없음(for…of/for…in/for … in만); 자기 반복 안에서 목록을 늘리지 않음; 빈 찍기 호출 없음; 백슬래시 없음; Python 집합 없음; 입력/파일/네트워크/시계/난수/지역 설정/process/id/hash 없음; CHANGED_UNSETTLED에 드는 것 없음; 문자열 글자는 20자 미만.
- 섞임(24개 전체에서 각각 최소): ≥ 8 반복이나 함수 안에서 찍음; ≥ 4 셈/경계 수(range, 자르기 끝, repeat, 목록 길이)나 비교하는 한계; ≥ 4 찾은 항목의 인덱스/키/속성, 또는 데이터로 나눔; ≥ 4 if 안의 문자열이나 수 비교; ≥ 3 배열/객체 통째를 찍는 js(≤ 6항목); ≥ 2 잇거나 자른 값을 찍음; ≥ 2 거의 같은 두 줄; ≥ 2 typeof/type()이나 불리언을 바로 찍음; ≥ 3 dict/객체나 목록 메서드; ≥ 3 3–4줄을 찍음; ≥ 3 조건 안의 불리언 / && || and or / 비교. 검토가 개발 세트 1–4에 없다고 찾은 꼴입니다.
- 채우는 것은 따로 씀(가린 다른 요청): 내 코드 3(ts 고침, js 고침, py 고침, 20–34줄, 바뀐 줄 1–4), 왜 2(코드 없음), 다시 도전 2(js와 py 통째 파일, slip { question, mine, what }).
- 얼리기 전 정적 확인(못 넘은 기록은 쓴 쪽이 바꾸고, 손으로 고치지 않음): 조건에 드는 기록마다 커밋된 rungOf + ladderMixed + isChangedShaped로 칸 changed에 닿고, 바꿀 곳 ≥ 3(하나는 문자열이 아님); 적힌 출력대로 돎(node 두 번; py PYTHONHASHSEED 1..5, 모두 같음; unshare -n timeout 5); 채우는 것마다 자기 칸에 닿음; 짓는 도구는 모든 설명을 플러그인 자신의 노트 읽기로 읽음(개발 세트 5의 D34가, 노트 읽기가 설명의 "--"를 "-"로 바꾼다는 것을 찾음; 플러그인이 읽은 것으로 짓거나, 설명에 "--"를 금함).
- 이름: `*` 없음, 백틱 없음, "--" 없음; 205개 피할 이름 목록, G2 1.10.0 이름 28개(C01–C24, F1, F2, W1, W2), 다른 모든 1.12.0 회차, `impl112/design/G2/dev/NAMES.txt`의 모든 G2 개발 이름(세트 1–5, 채우는 것과 부정 예 포함 133개)과 겹치지 않음.
- 짜임(커밋된 기준에서 바꾸지 않음): 퀴즈 9개 — Q1–2 [c,c,c], Q3–5 [c,c,내 코드](내 코드는 3, 1, 2번째 자리), Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; 비슷한 코드 개념은 단계 2/3을 번갈아, 모두 때 됨; 수준 beginner; 비슷한 코드 자리 20.
- 겹치지 않을 개발 이름(설계 devNamesNotToOverlap): `impl112/design/G2/dev/NAMES.txt` — 세트 1 e01–e18, m1 m2 w1 s1, n1–n5; 세트 2 f01–f18, m3 m4 w2 s2; 세트 3 g01–g18, m5 m6 w3 s3; 세트 4 h01–h24, m7 m8 m9 w4 w5 s4 s5; 세트 5 k01–k24(toLowerCase 메서드, Math.trunc 소수 버리기, padEnd 메서드, Array.from 배열 생성, Object.fromEntries, JSON.stringify 변환, fill 메서드, flat 메서드, reverse 메서드, lastIndexOf 메서드, toString 진법 변환, -- 감소 연산자, shift 메서드, substring 메서드, charAt 메서드, str.title, list.extend, dict.update, isinstance 함수, all 함수, [::-1] 역순 슬라이스, 가변 위치 인자, sorted reverse 정렬, str.find), p1 유니온 리터럴 타입, p2 JSON.stringify 문자열 변환, p3 isinstance 타입 검사, v1 git diff 변경 확인, v2 ls 파일 목록 보기, r1 sort 기본 정렬, r2 / 나눗셈 실수 결과.

계획 묶음 2의 글(같은 짜임)
- 짜임: 조건에 드는 개념 24개(잴 것 20 + 예비 4), 모두 통째로 만든 js 15 · py 9(잴 것 js 13 · py 7), 켠 꼴; 채우는 것 내 코드 3(ts, js, py 고침) · 왜 2 · 다시 도전 2; 퀴즈 9개 Q1–2 [c,c,c], Q3–5 [c,c,내 코드](자리 3, 1, 2), Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; 단계 2/3 번갈아, 모두 때 됨; beginner.
- 쓰는 쪽: 새로 가린 쓰는 쪽 둘(조건에 드는 것; 채우는 것), 설계의 섞임 최소와 함께; 설명에 "--"가 없거나, 짓는 도구가 플러그인 자신의 노트 읽기로 설명을 읽음(세트 5 D34의 흔적).
- 얼릴 때 확인: 조건에 드는 기록마다 커밋된 rungOf + ladderMixed + isChangedShaped로 칸 changed에 닿고 바꿀 곳 ≥ 3(하나는 문자열이 아님); 적힌 출력대로 돎(node 두 번; py 씨앗 다섯; unshare -n timeout 5); 채우는 것은 자기 칸에 닿음.
- 피할 것: design/G2/dev/NAMES.txt(133개, 세트 1–5) + 205개 피할 목록 + 1.10.0 G2 이름 + impl112/NAMES-all.txt.

#### 부르기

설계 calls 글(옮김)
- 플러그인이 부르는 그대로(D20), 프로브 mod의 사본으로: $.model.complete({ model: 'haiku'(설정 글자 그대로), effort: 'low', system: QUIZ_SYSTEM, prompt: redactText(quizPrompt(picks, 'beginner')).text, maxTokens: 4600(QUIZ_TRACE_TOKENS; 잴 퀴즈마다 비슷한 코드 고르기가 있음), timeoutMs: 90000 }), 4개씩, $.clock으로 시간을 재고, 답은 fixEscapedTicks를 거쳐 커밋된 parseQuiz로 읽음.
- 프롬프트는 커밋된 트리의 notes.ts를 불러와 haiku의 rungChangedStep = 2만 켜고 짓습니다.
- 첫 호출 전에, 커밋된 트리의 플러그인 시험 하네스에서 잡은 퀴즈마다의 실제 요청 하나(9/9)가 도구의 프롬프트 파일과 maxTokens에 바이트까지 같아야 합니다(D34).
- claude --version과 풀린 별칭을 앞뒤로 적습니다(DISABLE_AUTOUPDATER=1). 1.12.0 보정 기록과 같아야 합니다(설치된 2.1.323; 개발 파일럿은 G1 파일럿의 2.1.323 보정에서 온 H_haiku 2048 / H_sonnet 0을 썼고, 다시 잴 것).
- 빈 답마다 지나가는 탭으로 한 번 다시 보내 기록(stop_reason/stop_details)으로만 두고, 답으로 쓰지 않습니다.
- 주인이 그래도 sonnet 회차를 바라면: 같은 얼린 세트와 프롬프트 파일로, haiku가 끝나고 얼린 뒤에 부름.

계획 묶음 2의 글
- haiku: 퀴즈 호출 9번(QUIZ_SYSTEM, quizPrompt(picks, beginner), 4600, 90000), api-error 다시 보내기만(≤ 2). 프롬프트는 커밋된 트리에서, 묶음 1의 haiku 줄 위에 haiku의 rungChangedStep = 2만 켜고.
- D34: 시험 하네스에서 잡은 퀴즈 9/9가 도구의 프롬프트 파일과 maxTokens에 바이트까지 같음.
- 쓰는 몫(기록): haiku 9번(+ 다시 보낸 것): 입력 ≈ 40k, 출력 ≈ 25k 토큰. opus: 쓰는 쪽 2, 판정자 2, 번역 확인, 감사, 검토자 2 ≈ 8번.

이 묶음이 정한 것(위 글을 도구로 옮긴 자리, 기록)
- 모델-스테이지: `quiz` haiku 하나(계획 사용량 관문 자리 'G2 quiz haiku'). sonnet 스테이지는 없습니다.
- 떼어 낸 러너(러너 규칙): `tools/stage.sh quiz haiku`를 setsid nohup으로 띄우고, 에이전트는 STARTED · 시도마다의 status.jsonl · DONE · 러너 로그만 봅니다. 러너는 (1) STARTED가 없고 `frozen/d34/compare.json`이 9/9인지 보고, (2) 고정한 길로 앞 'ok' 세션(`probe/precheck.sh`)과 `tools/gate.py pre`(앞 기록이 1.12.0 보정과 같음 · five_hour ≤ 0.60 · seven_day < 0.80 · 다른 워크플로 없음을 에이전트가 ONLY_WORKFLOW=1로 밝힘)를 거친 뒤에만 STARTED를 쓰고, (3) 시도 1(`call-1`), 그리고 입장 2의 api-error 줄(상태 429 또는 5xx, 글 없음, 출력 토큰 0이거나 없음)인 퀴즈만 같은 얼린 줄 그대로 시도 2 · 3(`call-2` · `call-3`)으로 다시 보냅니다. 그 밖의 것(빈 답, 시간 한도, 상한 닿음, 다른 상태의 api-error)은 다시 보내지 않습니다. (4) 뒤 기록(`tools/gate.py after`), 퀴즈마다 마지막 시도의 상태 수, M-4의 10% 판정을 `summary.json`에 적고 DONE을 씁니다.
- 주간 예측: 계획 usageGate의 주간 예측은 묶음 1과 묶음 4에만 있습니다. 이 묶음은 0으로 둡니다(`tools/gate.py`의 WEEKLY_PROJECTION).
- 모델 기록(M-10, D19): 앞 기록은 앞 'ok' 세션과 고정한 길의 --record, 뒤 기록은 시도마다의 프로브 세션(세션마다 앞뒤 claude --version, 턴마다 init model, result의 modelUsage 키)과 끝의 --record입니다. 모두 1.12.0 보정 기록(2.1.323, 고정 사본 sha256 `604d29a6…348e` · `d2bc14da…a9e`, haiku 별칭의 풀린 id)과 같아야 합니다.
- 빈 답의 탭(기록만): `tools/tapsend.py quiz haiku`.

#### 위험 (재기 전에 적음)

설계 risks(옮김)
- R1 저장된 답 하나만 틀려도 회차는 못 넘습니다. haiku는 개발 149문항에서 틀림 0이었습니다. 읽힌 문항 ~19개와 참 틀림 비율 ~1%면 깨끗한 회차의 확률은 ~80–85%입니다.
- R2 보정: 1.12.0 보정이 haiku의 생각 몫을 H 2048에서 바꾸면, 그것에 기대는 정확도(가운데 ~2,400 출력 토큰)가 바뀔 수 있습니다. 회차는 잰 H와 같은 CLI 판을 써야 합니다. (이 묶음의 기록: 1.12.0 보정이 H_haiku 2048을 냈고, 모든 부르기는 고정한 2.1.323 사본으로 합니다.)
- R3 닿는 범위가 좁습니다: 도우미가 Write 한 번으로 통째로 만든 작은 js/py 파일(≤ 16줄, ≤ 700자)만, ts/tsx 없음, 고침 없음, import 없음, 줄 머리에서 찍는 것 1–4개, while/세는 for 없음. 앱을 짓는 사람(tsx, import, 고친 파일)은 드물게 닿고, 연습 스크립트를 쓰는 학습자는 자주 닿습니다. 짐작이고 재지 않았습니다.
- R4 따온 줄에 가장 가까운 바꿀 곳은 흔히 그 개념 자신의 토큰이 아니라 데이터 글자여서, 문제는 개념 자체보다 바뀐 프로그램 읽기를 더 시험합니다. 기준에는 괜찮고, 배움 질의 한계입니다.
- R5 퀴즈마다 프롬프트가 ~1k자 늡니다. 모델이 여전히 잘못 적을 수 있습니다(거절됨, 읽히지 않음) — haiku 세트 5에서 1/40.
- R6 D34 견본 흔적: 플러그인의 노트 읽기가 설명의 "--"를 바꿉니다. 잴 짓는 도구는 플러그인처럼 설명을 읽어야 하고, 아니면 쓰는 쪽이 "--"를 피해야 합니다.
- R7 sonnet: 주인이 그래도 sonnet 회차를 바라면, (나)는 동전 던지기쯤입니다(개발에서 143개에 5 틀림).
- R8 옛 창: 기본 채점으로 매기는 것은 그대로이지만, 켠 값으로 하는 옛 빌드 확인 전체는 짓기 단계에서 아직 돌려야 합니다(R9). (이 묶음의 기록: 짓기 커밋 3f9084c가 옛 창 여섯(3f2b4fb · 7a7b08c · 3690021 · fca5988 · 3d2f251 · de98243)과 coexist19를 돌렸고 결과는 그 본문에 있습니다. 켠 값으로 하는 확인 전체는 넘을 때 값 커밋 전에 돌립니다(R9).)
- (이 묶음의 기록, 원문 밖) sonnet의 따라가기 거절(SCOPE 묶음 3의 사실): 이 설계의 퀴즈 요청은 코드를 한 줄씩 따라간 과정을 적으라고 하지 않습니다. 모델이 쓰는 것은 바꿀 곳 이름과 새 값(C), 그 값으로 바꾼 줄 하나, 원래 코드와 바꾼 코드가 찍는 줄(O · N)뿐입니다(1.10.0 G2가 거절당한 R 줄 지시는 없음). 설계 파일럿에서 sonnet 72호출 거절 0, haiku 거절 0(위 perModel). 잴 모델은 haiku입니다. 빈 답과 거절은 입장 2대로 그 퀴즈의 자리를 (가) 놓침으로 셉니다. 탭 결과는 기록만 합니다(B-12).

#### 읽는 법 (재기 전에 정함)

1. 다시 보내기와 M-4의 10%: 두 커밋된 규칙이 겹치는 곳이라 그대로 적습니다(묶음 1 감사 교훈 2). 계획의 끊긴 스테이지 규칙이 정한 차례대로, 먼저 이 G의 api-error 줄(입장 2: 상태 429 · 5xx, 글 없음, 출력 토큰 0인 것만 같은 프롬프트로 두 번까지)을 쓰고, 그다음 퀴즈마다 마지막 상태로 M-4 셋째 줄(10%)을 어느 답도 열기 전에 상태 수로만 봅니다. 퀴즈는 9개라, 마지막까지 api-error로 남은 퀴즈가 하나라도 있으면 1/9 > 10%이고 그 스테이지는 무효(답을 열지 않음)입니다. 다른 날 같은 바이트로 한 번 더 보내고, 또 넘으면 칸은 끔입니다(M-4). 그래서 입장 2의 '그래도 실패하면 그 퀴즈의 자리는 모두 놓침'은 api-error가 남지 않을 때에만 매기는 단계로 가므로 쓰일 일이 없습니다. 이 글은 어느 조항도 바꾸지 않고, 두 규칙을 계획이 정한 차례로 읽은 것입니다.
2. 입장 7 (ㅇ)의 ⚙/✎과 입장 14: 도구가 조항 10의 (i)–(iv)를 세고, 두 판정자가 각자 (ㅇ)을 매기며 다른 조항으로 (가) 놓침을 볼 수도 있습니다(조항 번호를 적음). (가)는 읽힌 자리에서 조항 7의 ⚙가 모두 참이고 두 판정자가 모두 넘음이라 할 때만 넘음입니다. (나)는 도구가 조항 3으로 틀림(여러 번 돌린 결과가 다르거나 5초 넘음)이거나 조항 6 · 11 첫 단계로 같음이면 그대로이고, 그 밖에는 두 판정자가 모두 맞음이라 할 때만 맞음입니다. 판정자의 '가르지 못함'이나 빠진 자리는 불리한 쪽입니다.
3. 입장 머리말의 '견본 쓰기 프롬프트와 함께 한 커밋': 쓰는 쪽 프롬프트(`gen/writer-A.md` · `gen/writer-A-end.md` · `gen/writer-B.md` · `gen/writer-B-end.md`)와 피할 이름 절을 짓는 `gen/avoid.py`를 아래 표로 이 커밋에 얼립니다. 피할 이름 절 자체는 쓰는 쪽이 돌 때의 NAMES-all.txt에서 지어지므로(계획 samples.avoid) 그 sha256과 다 지은 프롬프트의 sha256은 견본 커밋에 적습니다.
4. 쓰는 쪽의 수: 설계 samples 첫 줄은 '새 하위 에이전트'라 하고, 넷째 줄('채우는 것은 따로 씀')과 계획 samples.writers는 조건에 드는 것과 채우는 것을 따로 쓰는 쓰는 쪽 둘을 말합니다. 둘 다 새로 가린 쓰는 쪽이므로 계획 글대로 둘입니다(엇갈림이 아니라 더 자세한 글).
5. 205개 피할 이름 목록과 G2 1.10.0 이름 28개: 1.10.0 도구 폴더(`impl110/b3/gen/avoid.json`)는 1.10.0 컨테이너 회수로 사라졌습니다(1.11.0 기록). 그 이름들은 이 파일의 1.8.0 ~ 1.10.0 절에 적혀 있어, 묶음 0이 이 파일에서 뽑은 `impl112/NAMES-all.txt`(꼬리표 '견본')에 들어 있고, G2 개발 이름 133개도 꼬리표 'G2-dev'로 들어 있습니다. 그래서 쓰는 쪽에게 주는 피할 이름과 얼릴 때 확인은 NAMES-all.txt 하나로 네 목록을 모두 덮습니다.
6. 섞임 최소: 설계는 쓰는 쪽에게 주는 글로 두고, 얼리기 전 정적 확인 목록에는 넣지 않았습니다. 그래서 쓰는 쪽이 기록마다 적은 섞임 꼬리표('mix', (a)–(k))를 얼릴 때 세어 기록만 하고, 모자라도 견본을 바꾸지 않습니다.
7. 입장 3의 '도구 판(node · python · Claude Code)을 적습니다': 견본을 얼리는 커밋에 적습니다. 이 커밋 때: node v22.23.4 · Python 3.11.18(`/usr/local/bin/python3`) · git 2.43.0 · Claude Code 2.1.323(고정한 길).
8. 설계 calls의 '개발 파일럿은 … H_haiku 2048 / H_sonnet 0을 썼고, 다시 잴 것': 1.12.0 보정 기록이 H_haiku 2048 · H_sonnet 2048을 냈습니다. 이 회차가 쓰는 것은 H_haiku 2048(상한 닿음 6648)뿐입니다.
9. 입장 15의 '(dev)' 사례들은 설계 때 개발 세트에서 본 꼴을 미리 가른 것이고, 개발 결과는 어느 결정에도 들지 않습니다(B-12).

#### 도구가 글을 읽는 방식 (재기 전에 정함)

도구는 설계 파일럿 도구(`impl112/design/G2/pilot/`: build.mjs · check.mjs · read.mjs · judge.py · runner.py · gen-d34.mjs · probe/ · tap/)를 짓기 커밋의 트리에 맞춰 `impl112/b2/` 아래에 다시 지었습니다. 계획이 '새로'라고 한 것(꼬리표 · 봉인 · 짝, 기계 셈, 커밋된 입장 글에서 지은 판정자 프롬프트)도 여기서 지었습니다. 파일럿의 study.py는 기록 전용이라 쓰지 않습니다. 글과 도구가 다르면 글이 이깁니다(M-15).

1. 트리: `mtree/`는 짓기 커밋 3f9084c의 `git archive`(docs · README · CHANGELOG 뺌)이고, `mtree/hooks/notes.ts` · `register.tsx`는 위 sha256과 같습니다. 판정의 읽기 트리 `jtree/hooks/notes.ts`는 mtree의 notes.ts에서 `codeAsRead` · `codeTokens` · `quizParts` · `shownCode` 앞에 `export `만 더한 것입니다(다른 바이트 같음). 요청을 짓는 모든 도구는 mtree를, 읽기의 기록(changedItem의 까닭)과 조항 7 (ㄷ)의 토큰만 jtree를 씁니다.
2. 견본 쓰기(`gen/writer-A.md` · `gen/writer-A-end.md` · `gen/writer-B.md` · `gen/writer-B-end.md` · `gen/avoid.py` · `gen/run.sh`): 쓰는 쪽 A는 조건에 드는 기록 24개(gm01–gm15 js, gm16–gm24 py), 쓰는 쪽 B는 채우는 것 7개(gf1 ts 고침 · gf2 js 고침 · gf3 왜 · gf4 다시 도전 js · gf5 py 고침 · gf6 왜 · gf7 다시 도전 py)를 씁니다. 프롬프트는 설계 개발 세트 5의 쓰는 쪽 프롬프트(`design/G2/dev/req/A5.txt` · `B5.txt`)에서 id를 바꾸고, 이름과 설명에 하이픈 둘을 금하고, A에 섞임 꼬리표 (a)–(k)와 'mix' 칸을 더한 것입니다. 피할 이름 절은 `gen/avoid.py`가 그때의 NAMES-all.txt에서 개념 이름(아이디 · 경로 · 파일 이름이 아닌 2–30자 항목)과 파일 경로(빗금이나 코드 파일 확장자가 있는 항목)로 나눠 짓습니다. 쓰는 쪽마다 새 `claude -p --model opus --tools '' --output-format json`(고정한 길, 빈 폴더, 프롬프트는 stdin)이고, 답 · 시각 · 쓴 쪽(result의 modelUsage 키)을 `gen/out/<쓰는 쪽><회>/`에 둡니다. 답은 고치지 않습니다. 둘째 회(`run.sh A 2` · `run.sh B 2`)는 check.py가 'WRITE A 2' · 'WRITE B 2'를 말할 때만입니다.
3. 얼리기(`tools/check.py` · `tools/facts.mjs` · `tools/kit.mjs` · `tools/runlib.py`): 쓴 그대로를 `frozen/raw.json`으로 묶고, 위 '얼리기 전 정적 확인'을 기록마다 봅니다. 조건에 드는 기록: 칸(gm01–gm15 .js, gm16–gm24 .py), 6–16줄 · ≤ 650자, 설명의 백틱 인용이 1–6번째 줄 안, 줄 머리에서 시작하는 찍기 줄 1–4개이고 다른 `console.` · `print(` 호출 없음, import/require/export 줄 없음, while/do 없음, `for (…;…)` 없음, 도는 목록을 그 반복 안에서 늘리지 않음, 빈 찍기 호출 없음, 백슬래시 없음, Python 집합 없음(`set(` 또는 문자열을 지운 뒤 ':'이 없는 `{…}`), js의 require · fetch · setTimeout · setInterval · Date · Intl · navigator · crypto · XMLHttpRequest · process. · Math.random · toLocale… · localeCompare와 py의 input · open · id · hash · exec · eval · __import__ 호출 없음, 문자열 글자 < 20자; 입장 3대로 돌린 결과가 끝 코드 0 · 모두 같음 · 5초 안이고 적힌 출력의 줄과 글자 그대로 같으며 1–4줄; 커밋된 rungOf가 단계 2에서 haiku의 G2 칸으로 'changed'(isWholeShown · isChangedRunnable · isChangedShaped를 거침); changeSites ≥ 3이고 모두 문자열은 아님; 이름과 설명을 conceptsOf로 다시 읽어 쓴 그대로; redactText 걸림 0. 채우는 것: 고침 셋은 before/after가 있고 after 20–34줄, 바뀐 줄 묶음 하나가 1–4줄, 설명의 인용이 after에 있고 단계 0에서 'mine'; 왜 둘은 코드 · 파일 없음, 칸 없음; 다시 도전 둘은 6–14줄 통째 파일과 slip { question, mine, what }, 단계 1에서 slip을 다시 묻는 칸(없음). 모든 기록의 이름: `*` · 백틱 · "--" 없음, 설명에 "--" 없음, 이름(소문자, 공백 뺌)과 파일 경로가 NAMES-all.txt의 어느 항목과도(같은 식으로 견줌) 같지 않고 세트 안에서 두 번 나오지 않음. 바꿈: 못 넘은 잴 자리는 같은 언어의 넘은 예비(id 차례), 없으면 'WRITE A 2'로 둘째 회의 같은 언어 넘은 기록(id 차례); 채우는 것은 'WRITE B 2'로 둘째 회의 같은 id; 그래도 모자라면 STOP. 짜임(고정): 잴 20개를 c1–c20으로, py는 c2 · c5 · c8 · c11 · c14 · c17 · c20(py는 id 차례, js도 id 차례), 단계는 c1 = 2부터 2/3 번갈아; Q1 [c1 c2 c3] · Q2 [c4 c5 c6] · Q3 [c7 c8 gf1] · Q4 [gf2 c9 c10] · Q5 [c11 gf5 c12] · Q6 [c13 gf3 c14] · Q7 [c15 gf6 c16] · Q8 [gf4 c17 c18] · Q9 [gf7 c19 c20]; 내 코드는 단계 0, 왜는 2, 다시 도전은 1(slip times 1을 다시 물음). 학습자 결과(입장 3 · 8)는 잴 자리마다 파일 전체(= 보인 코드, 바꾸기 전)를 runlib.run으로 돌린 줄을 `frozen/learner.json`에 얼립니다. 결과는 `frozen/`의 raw.json · facts-in.json · facts.json · samples.json · layout.json · learner.json · check-report.json(모두 chmod 444)입니다.
4. 짜기(`tools/build.mjs` · `tools/kit.mjs`): 퀴즈마다 makeQuiz처럼 개념마다의 고르기(withCode: codeFor의 줄, 비슷한 코드가 물을 수 있는 create에서만 isWholeShown · isUnrunnableChange · isImportingChange), rungOf(단계, haiku 줄의 칸: changedStep 2, newStep · workedAfter · workedPlainAfter Infinity, 다시 도전은 slip times 1과 isAsking), ladderMixed, pickForRung, `redactText(quizPrompt(picks, 'beginner')).text`, maxTokens는 register.tsx의 식(`isLong ? QUIZ_TRACE_TOKENS : QUIZ_TOKENS`, 둘 다 register.tsx 글에서 읽음), system QUIZ_SYSTEM, timeoutMs 90000. 개념 이름과 설명은 노트 줄('- **이름**: 설명')을 conceptsOf로 읽은 것입니다(D34 흔적, 위험 R6). 잴 자리 20개가 모두 'changed', 채우는 것이 자기 칸, redact 걸림 0, maxTokens 4600이 아니면 아무것도 쓰지 않고 멈춥니다. `frozen/build.json` · `frozen/lines-haiku.jsonl`(chmod 444).
5. D34(`d34/make.py`, 셈에 들지 않음): mtree 사본에서 시험 파일을 모두 빼고(flowkit.ts · fixtures는 둠) 퀴즈마다 시험 하나를 만듭니다: model 'haiku', level beginner, 하네스 `models: { haiku: { rungChangedStep: 2 } }`(묶음 1의 haiku 줄 위에 G2 칸), 그 퀴즈의 개념을 단계대로 저장소에 두고 퀴즈 차례로 때 되게(reviewedAt = NOW − 단계의 날 − (10 − 자리)시간), 다시 도전은 저장소 slip(times 1), 통째 파일은 Write 턴, 고친 파일은 Edit 턴(그 -U3 hunk 하나를 structuredPatch로), 턴마다 그 개념을 이름 짓는 노트, 그다음 `/learn 퀴즈 새로`. 노트 뒤 잡힌 요청(routeCalls: model · effort · system · prompt · maxTokens · timeoutMs)이 하나뿐이고 lines-haiku.jsonl의 그 줄과 바이트까지 같아야 합니다. 고정한 길의 `claude plugin test .`(하네스가 답함, 모델 호출 0). 9/9가 아니면 부르지 않습니다(stage.sh가 `frozen/d34/compare.json`을 봄).
6. 부르기(`tools/stage.sh` · `tools/gate.py` · `probe/precheck.sh` · `probe/call.sh` · `probe/record.py` · `probe/mod/`): 위 '부르기'의 러너. 프로브 mod(명령 `/g2probe <줄> <답 파일> <상태 파일>`)는 묶음 1 프로브의 사본이고(명령 이름만 바꿈) `probe/mod/hooks/notes.ts`는 mtree의 notes.ts와 바이트까지 같습니다. 4개씩 부르고, 호출마다 상태 줄(id, answered, reason, status, output_tokens, ms; 글 없음)을 더합니다. 다시 보낸 요청은 얼린 줄 그대로입니다(`again-2.jsonl` · `again-3.jsonl`).
7. 탭(`tools/tapsend.py` · `tap/`): 묶음 1 탭의 사본(명령 `/g2tap`, `tap/tap.py`는 1.11.0 · 묶음 1 것과 바이트까지 같음). 어느 시도의 빈 답이든 그 얼린 줄을 한 번 탭으로 보내 stop_reason · stop_details만 적습니다. 기록만.
8. 꼬리표와 읽기(`tools/label.py` · `tools/read.mjs`): seal은 스테이지가 DONE일 때 꼬리표를 A · B 가운데 난수로 하나 뽑아 `judge/pair.json`({꼬리표: 모델, nonce}, chmod 444, sha256만 찍음)과 `judge/label.txt`를 씁니다. read는 퀴즈마다 마지막 시도의 답(프로브가 이미 fixEscapedTicks를 거침)을 mtree의 parseQuiz(text, build.json의 picks)로 읽어 `judge/<꼬리표>/read.json`(chmod 444)에 둡니다. 비슷한 코드 자리마다 저장된 문항과, 기록으로 jtree의 quizParts(펜스 앎, 표지 QHATRCON, CON은 마지막 글)와 changedItem의 까닭을 적습니다. 모델 이름 · 토큰 · 시간은 없습니다.
9. eval(`tools/eval.py` · `tools/tok.mjs` · `tools/runlib.py`): 입장의 ⚙ 조항. 읽히지 않은 자리는 (가) 놓침(조항 2 · 13), (나) 밖. 읽힌 자리: 문제의 코드는 question의 펜스 블록(줄 전체가 ``` 또는 ~~~와 이름인 줄로 열고, 같은 글자로 같거나 긴 이름 없는 줄로 닫음)의 내용, 언어는 펜스 이름(js · javascript → js, python · py → py, ts · typescript → ts; 이름이 없거나 다르면 학습자 파일의 언어로 하고 보고서에 적음). 돌리기(조항 3, runlib.run): 빈 새 임시 폴더, 표준 입력 비움, `unshare -n timeout 5`, js `node case.js` 두 번, py `env -i PATH=… LANG=C.UTF-8 PYTHONHASHSEED=n python3 -s -P -B case.py` n = 1..5, ts(조항 12, 도구 결함으로만 생김) `node --experimental-transform-types --no-warnings case.ts` 두 번. 결과는 표준 출력 줄(끝 줄바꿈 없는 마지막 줄도 한 줄)이고, 끝 코드가 0도 124도 아니면 예외 이름 한 줄을 더합니다: py는 표준 오류의 마지막 빈 줄 아닌 줄 머리의 이름(점이 있으면 마지막 마디), node는 `…Error` · `…Exception`으로 시작하는(앞에 'Uncaught ' 허용) 표준 오류의 마지막 줄의 이름, 없으면 `Error`. 모든 번의 (끝 코드, 표준 출력, 이름)이 같아야 '같음', 어느 번이든 124면 '5초 넘음'. 조항 6의 맞춤 n6: 줄 앞뒤 공백 지움 → 이어진 공백 하나로 → 글자 · 숫자(Python \w, 한글 포함; '_'는 글자 아님)가 아닌 문자 옆 공백 지움 → ' " `를 한 가지로 → 줄 끝 마침표 하나 뗌 → true · false · none · null · undefined · nan을 소문자로. A 쪽만 더(조항 6): '(빈 줄)'은 빈 줄, 같은 자리의 결과 줄이 따옴표로 시작하고 끝나지 않을 때만 A 줄을 감싼 같은 따옴표/백틱 한 겹을 뗌, js에서 결과 줄에 따옴표 키가 없을 때만 A의 `"a":` · `'a':`를 `a:`로; 결과 끝의 빈 줄은 견주지 않음; 결과가 여러 줄이고 A가 한 줄이면 ', ' · ' ' · '과 ' · '와 ' · ' 그리고 ' · ' → '로 이은 결과와 견줌. 조항 7: (ㄱ) rung 'changed', (ㅁ) kind 'predict', (ㅂ) 펜스 블록 하나, (ㅈ) 같음이고 5초 안, (ㄴ) 두 코드를 줄마다 주석(js `//`, py `#`, 문자열 밖)을 떼고 n6, 줄 끝 `;` 하나 뗌, 빈 줄 뺀 목록이 (i) 다르고 (ii) 보인 코드의 한 줄짜리 `console.log(…)` · `print(…)`가 아닌 줄들이 학습자 줄들의 부분열이 아님, (ㄷ) jtree codeAsRead 토큰으로 학습자의 핵심 줄(토큰 ≥ 4이고 괄호 · 쉼표뿐이 아님, 괄호 · ':'를 뺀 것이 else 하나가 아님, `return 이름`이 아님, `console.log(이름)` · `print(이름)`이 아님; 없으면 토큰 ≥ 2인 줄) 하나 이상이 보인 코드의 어느 줄과 같거나 토큰 하나 다름(같은 길이에서 한 자리 다름, 또는 하나 더하거나 뺌), (ㄹ) 결과가 ReferenceError/NameError이고 표준 오류의 'X is not defined' · "name 'X' is not defined"의 X가 블록 안에서 선언 · 대입 · 매개변수 · for · catch · except … as · with … as · lambda · import로 나오지 않으면(runlib.declared의 정규식) 놓침, (ㅅ) 조항 8을 runlib.same8로(오류 이름 줄은 학습자 결과의 어느 줄과도 다름, 오류 이름 한 줄뿐이면 다름; (a) · (b) · (c)면 같음 = 놓침; 같음이 아닌 때만 넘음, (ㅈ)를 못 넘으면 놓침), (ㅇ) 조항 10을 도구로: (i) question이 notes.ts의 CHANGED_LEAD 글 그대로로 시작하고 그 뒤에 공백을 빼면 펜스 블록 하나만, (ii) 보인 코드와 학습자 코드의 줄 수가 같고 정확히 한 줄만 다름, (iii) hint의 'k번째 줄'의 k가 그 줄 번호(블록 첫 줄 1, 빈 줄 포함), (iv) hint가 따왔으면 따온 글이 그 줄의 앞뒤 공백을 뺀 것과 같음. 조항 12: ts면 (가) 놓침. (나): (ㅈ)를 못 넘으면 틀림(조항 3), 아니면 A와 결과가 위 맞춤으로 같으면 맞음(조항 6 · 11 첫 단계), 그 밖은 판정자. 결과는 `judge/<꼬리표>/eval.json`과 판정자에게 주는 `report.md`(chmod 444; 자리마다 학습자 코드 · 학습자 결과 · 저장된 문항 · 돌린 결과 · ⚙ 결과; 모델 이름 · 토큰 · 시간 · 상한 없음; 모델의 C · O · N 줄과 날글 없음, 조항 1).
10. 판정(`tools/judge.py` · `judge/tpl-judge.md` · `judge/stance-G2.md`): 꼬리표마다 판정자 둘, 각자 새 `claude -p --model opus --tools '' --output-format json`(고정한 길, 빈 폴더, 프롬프트는 stdin). 받는 것은 틀 · 입장(stance-G2.md는 이 절의 '판정의 입장'에서 '결정 규칙' 앞까지를 그대로 자른 것) · 그 꼬리표의 report.md뿐입니다. 답은 읽힌 자리마다 {slot, ga: pass/miss/undecided, ga_clause, na: right/wrong/tool/undecided, na_clause, why}인 JSON 배열입니다. 읽지 못한 답이나 읽힌 자리가 빠진 답은 같은 프롬프트로 새 판정자에게 한 번 더 묻고(기록), 그래도 빠진 자리는 undecided(불리한 쪽)입니다. `judge/<꼬리표>/verdicts-<n>.json`(chmod 444).
11. 셈과 결정(`tools/tally.py` · `tools/decide.py`): tally는 eval.json과 두 verdicts가 모두 chmod 444일 때만, 위 '읽는 법' 2대로 (가)와 (나)를 세고 넘음(가 ≥ 16, 나 틀림 0, 자리 20)을 `judge/<꼬리표>/tally.json`(chmod 444)에 씁니다. decide는 판정 파일 둘과 tally가 얼린 뒤에만 짝을 열고(label.py open), 모델마다의 수와 칸 값(haiku 2 또는 Infinity, sonnet은 재지 않음 Infinity)을 `judge/decision.json`(chmod 444)에 씁니다.
12. 기계 셈(`tools/count.py`): 꼬리표마다 시도별 호출 · 끝난 꼴, 퀴즈마다 마지막 상태, 다시 보낸 수, 상한 닿음(output_tokens ≥ 4600 + 2048 = 6648), output_tokens 가장 큰 것과 가운데, 시간, 탭의 빈 답 · 거절 열을 `judge/count-<꼬리표>.json`(chmod 444)에. 판정자는 이 파일을 받지 않습니다.
13. 짓기 때 쓴 도구(기록, 이 커밋으로 함께 얼림): `tools/onbytes.sh` · `tools/onbcmp.py` · `tools/g3grade.mjs`(켠 바이트), `off/offbytes.mts` · `off/offsplit.mts` · `off/run.sh`(끈 바이트), `probeoff/probe_off_repo.mjs`(G6 끈 바이트), `oldprobe/probe.mts`(옛 창 여섯), `mut/run.py`(돌연변이 탐침), `impl112/d26/rulewide.mjs`(isRuleWide D26). 값 커밋(R9)과 뒤 묶음의 재확인이 다시 씁니다.
14. 도구 시험(견본 · 모델 호출 0, 저장소 밖 `impl112/b2/test/`): 설계 개발 세트 5(측정에 쓰지 않음)의 견본과 적어 둔 개발 답을 입력으로만 썼습니다.
    - check.py: 세트 5를 gm/gf id로 바꿔 넣으면(시험용 NAMES 파일) 개발 짜임에서 빠졌던 셋(k01: 찍는 호출이 줄 머리에 없음, k16 · k17: 칸 mine)과 "--"가 든 k12, 시험 NAMES에 넣은 이름 하나를 거절하고 예비로 바꾸며, 예비가 모자라면 'WRITE A 2'를 말하고, 둘째 회 기록으로 채운 뒤 얼림. 손으로 망가뜨린 기록 12개(세는 for · require · 백슬래시 · 빈 찍기 · 적힌 출력 다름 · 앞에 줄 7개를 더해 인용이 9번째 줄이 됨(돌리면 오류, 칸 mine) · 긴 문자열 · 도는 목록 늘림 · py 집합 · input · 같은 파일 경로 · while)를 모두 거절.
    - build.mjs: 세트 5를 개발 짜임으로 넣으면 퀴즈 9개 프롬프트 가운데 8개가 파일럿 프롬프트와 바이트까지 같고, 다른 하나(q7)는 "--" 든 설명을 conceptsOf로 읽은 차이뿐(위험 R6).
    - D34(실제 `claude plugin test`, 고정한 CLI, 모델 호출 0): 시험 얼림의 퀴즈 9개가 9/9 바이트까지 같음; 줄 한 글자를 바꾼 사본은 8/9(종료 4)로 잡힘.
    - read.mjs → eval.py: 세트 5의 haiku 개발 답(1회째)을 넣으면 설계 기록과 같은 수(읽힘 19/20, 거절 1은 echo, ⚙ 모두 넘음 19, (나) 틀림 0). 손 사례 11개(코드 그대로 · hint 줄 번호 틀림 · 틀린 A · kind why · 블록 둘 · 정의 안 된 이름 · 끝나지 않는 코드 · 쉼표로 이은 A · ts 펜스 · lead 바뀜 · hint 인용 틀림)가 모두 맞는 조항으로 갈림.
    - judge.py → tally.py → decide.py(가짜 판정자 명령): 읽지 못한 첫 답의 다시 묻기, 빠진 자리 → undecided, 판정자 갈림 → 불리한 쪽, 짝은 판정 파일 둘과 tally가 얼린 뒤에만 열림, decision.json 한 번만.
    - stage.sh · gate.py · tapsend.py(가짜 `claude`와 가짜 고정 길): ONLY_WORKFLOW 없음 → 시작 안 함(2), five_hour 0.70 → WAIT(7, STARTED 없음), 판 다름 → STOP(3), 모두 넘음 → DONE, 다시 → STARTED로 거절, 429 두 번 뒤 답함 · 429 한 번 뒤 답함 · 빈 답 · 400(다시 보내지 않음) → 시도 1 · 2 · 3이 9 · 2 · 1번, 남은 api-error 1 → 10% 넘음으로 무효(6), 던짐 → 5, sonnet → 거절, 빈 답 하나 → 탭 기록 하나.

#### 틀과 도구 (sha256, 이 커밋으로 얼림, 저장소 밖 `impl112/b2/` 아래, chmod 444)

목록 파일 `impl112/b2/bar/tools.sha256`(chmod 444) sha256 `3950ae6db4e90746e5dd4b86eedacba7673efa1feef7c8c53ffd09297d445ed2`. `../cli/pinned.sh`는 실행돼야 하므로 555이고 sha256은 묶음 0과 같습니다. `mtree/` · `jtree/`는 트리 통째로 쓰기를 막았습니다.

| 파일 | 하는 일 | sha256 |
| --- | --- | --- |
| `gen/writer-A.md` | 쓰는 쪽 A 프롬프트 앞(조건에 드는 기록 24) | `80f1a7d59073f987d5aaa92c0240a879881c596235cc2b37fc6453c2635948ea` |
| `gen/writer-A-end.md` | 쓰는 쪽 A 프롬프트 끝 | `dbe1f05d70a9451da75d1548b859ea42201abba08ff41d4b31d766fb8853a72c` |
| `gen/writer-B.md` | 쓰는 쪽 B 프롬프트 앞(채우는 것 7) | `5db99cef937717d3dad4473a0fb7ec33ac47d51c6595909499b5d4dc99f331b0` |
| `gen/writer-B-end.md` | 쓰는 쪽 B 프롬프트 끝 | `8babf61b1e1a19f85047a4979ceff965f84147d770dec03f0282501c633a5c9d` |
| `gen/avoid.py` | 피할 이름 절(NAMES-all.txt에서) | `d45e01825e89518e12d2ebb335acc823b506973c6e8cf9ecc02f0c44441718ff` |
| `gen/run.sh` | 견본 쓰는 쪽 실행 | `9c4087ef69813bbc75afa98a42e1856e40ed1e57838bac885ef89449f5f63f96` |
| `tools/runlib.py` | 돌리기(입장 3 · 12) · 맞춤(입장 6) · 조항 8 · (ㄹ) | `47445b907494f7d07de6494fa2ee0fe06cd5dad5c71b0430388dceaf8b5a8bae` |
| `tools/kit.mjs` | 플러그인 쪽 고르기 · 칸 · 프롬프트(mtree) | `b904a7cb97f06e5a687e4b136c5665daa232193759c011e0c513e648c8748aa7` |
| `tools/facts.mjs` | 얼릴 때 플러그인 사실 | `fbd99ff0471b5ffc6efb7df921d69ee4865bdbd199d7f64c346d9c581db7f1aa` |
| `tools/check.py` | 얼릴 때 확인 · 바꿈 · 짜임 · 학습자 결과 | `70eca216ddca6dd5bc1034f7ede654d8fb30199772a62819b7fe08da153599ca` |
| `tools/build.mjs` | 퀴즈 9개 요청(lines-haiku.jsonl) | `74c64ba9a5a97a5ee1f6017a5df0195b55e6213c5e6de32290077929fe6da8e3` |
| `tools/stage.sh` | 떼어 낸 러너(quiz haiku, api-error 다시 보내기) | `7058f0873b905d317b3236ad98f868779865ce35260eea7596b81f1198339c2f` |
| `tools/gate.py` | 앞뒤 기록 · 사용량 관문 | `f56c83fdba58c9fafb414814e9767d04deb89374da645566c152ee2589747e36` |
| `tools/tapsend.py` | 빈 답의 탭(기록) | `6f298167b2994a3b14ffc7197b6632f565f508c8ddf4cff1ca78692accdef101` |
| `tools/read.mjs` | 읽기(입장 1 · 2 · 13) | `b5ef7df2309bfdc7821a00724332ebbad167015263a47270ff1a82fba762b9bf` |
| `tools/label.py` | 꼬리표 봉인 · 읽기 · 짝 열기 | `ce6357903723e4770300a022b34f3dc302f859ec3dda4d2082d4a85d961bdda4` |
| `tools/eval.py` | eval 도구(⚙ 조항) · 판정자 보고서 | `02f53441a26ce1f63188a96ec4a9a4b5b1d8ba31449c68bc32c5f146ba4452b9` |
| `tools/tok.mjs` | 조항 7 (ㄷ)의 토큰(jtree codeAsRead) | `dac821ff7060c6d4881aed6a1376d79283013ab61226a664cd73da44a4a95f06` |
| `tools/judge.py` | 판정자(꼬리표마다 둘) | `9c2ded1c21c7feb59f524f9d338c5137f49e5eb4c3c5789fd5193ed7eb71fa8f` |
| `tools/tally.py` | 셈(갈림은 불리한 쪽) | `703991d811f4b4fe8a8697c383fe0597a7e716a8250d43dadf5a3ebbd0aef533` |
| `tools/decide.py` | 결정 규칙 | `bc0fb5b682b48e83cb61b0ed4fa303b80728b494373e190a1c3ca0b3aedca329` |
| `tools/count.py` | 기계 셈(꼬리표마다) | `1e4732ae634c65e925a222bd84e1cfe3c48ca296ba0d778b458ca5197ae6ff41` |
| `judge/tpl-judge.md` | 판정자 틀 | `dc948a3fbde3c6975890eb29dd460650b37b3eac080d4154c754f3f9c5b24dcb` |
| `judge/stance-G2.md` | 판정자에게 주는 입장(이 절에서 자름) | `814f834cb3d874534f213552826b5e1894990e87ae0f75a517f7fc372362998d` |
| `d34/make.py` | D34 하네스 잡기 · 견줌 | `3800ebc63ea554424135d2bd6e7b7f75d1d65f5625b1ace4394bd09fceb4f93a` |
| `probe/call.sh` | 프로브 세션 | `3cf26d5976ed33c4495e6026fe5a819f75489bb181452a477a78325f5b1405d0` |
| `probe/precheck.sh` | 앞 'ok' 세션 | `8d79a5777c98c52428a82dad5eff026220f71ce4af8e8cf927d35f21670f9f39` |
| `probe/record.py` | 세션 기록 읽기 | `126e35df8537202d7ed23a0b3158149d857a8139b06c610651959eb60abc1737` |
| `probe/mod/hooks/register.ts` | 프로브 mod(/g2probe) | `5c066914e05581d10570a1b436a181d0823d49aae01e739bb26d482d859e5568` |
| `probe/mod/hooks/notes.ts` | 프로브 notes.ts(= mtree) | `aca7544f47733164a3a11d984242232d688360de4a9b164b14d82ea2f783a684` |
| `probe/mod/hooks/hooks.json` | 프로브 mod | `c835c92d8e1159d20a40ca78ad654da7433942c3694ffeda0b376b0c4dfd52cf` |
| `probe/mod/.claude-plugin/plugin.json` | 프로브 mod | `3112aa91340717e297bec81c623698de178ea06e067cdf6cd7a5ea59a8fafd40` |
| `tap/call.sh` | 탭 세션 | `12ad1160206c18d1f88c61a553b04483158d5b5c70be9fd7288432d34726213d` |
| `tap/tap.py` | 탭(1.11.0 · 묶음 1과 같음) | `e8d8174b09e11c74e6d744e4c44bc62033436d2ab35be6daa95d27026d17db9b` |
| `tap/mod/hooks/register.ts` | 탭 mod(/g2tap) | `a9702fca0511efc3463a5fd09f31df78baad2073360bc52eb9fba5fb8e0da14c` |
| `tap/mod/hooks/hooks.json` | 탭 mod | `c835c92d8e1159d20a40ca78ad654da7433942c3694ffeda0b376b0c4dfd52cf` |
| `tap/mod/.claude-plugin/plugin.json` | 탭 mod | `c721dc87568b3103c611c264bb911ea5d414a450b95f8212ebdd813f50e9b2e3` |
| `tap/mod/tsconfig.json` | 탭 mod | `88437ec880f7008b5df208a95a7d47330f0e3a8204d78d6c5cc272e5941c3511` |
| `mtree/hooks/notes.ts` | 짓기 트리(3f9084c) | `aca7544f47733164a3a11d984242232d688360de4a9b164b14d82ea2f783a684` |
| `mtree/hooks/register.tsx` | 짓기 트리(3f9084c) | `3f5855ca8dca4d4e00a830c2befbda48c908669e26d37e4942bd80c29144c3f1` |
| `jtree/hooks/notes.ts` | 읽기 트리(export 넷만 더함) | `00de7ba22b7454182c4b36cb1757831133f301266f1f00594d8cadee243a087c` |
| `tools/onbytes.sh` | 켠 바이트(짓기 때) | `065eb1791ccaeebb4d6c08d12dcda925ec47db0b608cd90b7b23389bd1a47162` |
| `tools/onbcmp.py` | 켠 바이트 견줌(짓기 때) | `7dfb936458daa0e83d63889397527f8bf042e53773563586ea9ae2b90bc3fe2f` |
| `tools/g3grade.mjs` | G3 채점 바이트(짓기 때) | `71919288035f10dd837320183b6786520e4f2ac601ce49874f1bab6828981a63` |
| `off/offbytes.mts` | 끈 바이트(짓기 때) | `4d475a69b05f33e21b7eaffff09b72ee93ed8efbafff430be110c2f3b573345b` |
| `off/offsplit.mts` | 끈 바이트 나눠 셈(짓기 때) | `0d67cf09010f075f6940d6916e50771f37728539d0ec0a788dc3db809f1d0be8` |
| `off/run.sh` | 끈 바이트 실행(짓기 때) | `8dc1fb3b371bd3c3f191ac1f8b5c47d30931dfd6ab089b86f2e7eaf8f540fd3d` |
| `probeoff/probe_off_repo.mjs` | G6 끈 바이트(짓기 때) | `0eb891d13d49a37521add2866ed4e60c1e777711179acda9059c4ddb931bca76` |
| `oldprobe/probe.mts` | 옛 창 여섯(짓기 때) | `e5fa56ba0a353dc4c8e3d35b594261692ac99937d120572cff26afb90054cacc` |
| `mut/run.py` | 돌연변이 탐침(짓기 때) | `65d6ecf0443ced8f9867530cc7b2d95ca8b2225965b06a113ee47b1406a541db` |
| `../d26/rulewide.mjs` | isRuleWide D26 재확인(짓기 때) | `c89d0800f3ca4bb0e3aaf5913b359d3273e6ad888ecab31751159d77fc7a5283` |
| `../cli/pinned.sh` | 고정한 길(묶음 0, chmod 555) | `e80f767481780e27fd6915d8f603bb5c07d18d08192efb0639d9629e811e3473` |

