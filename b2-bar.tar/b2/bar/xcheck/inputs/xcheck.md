너는 번역 확인자다. 아래 '원문'(설계 파일 G2의 name · bar · stance · decisionRule · samples · calls · risks · perModel · ownerQuestions 필드, 계획 묶음 2의 notMeasured · barSource · samples · calls · judges · stop · preCallGate · switchCommit · usage 필드; 영어와 한국어)과 '옮긴 글'(docs/qa/견본.md에 넣을 한국어 절)을 견준다. 코드를 돌릴 수 없고 다른 파일도 없다. 도구도 쓰지 마라.

확인할 것:
1. 원문의 모든 수(개수, 비율, 토큰, 밀리초, 문턱, 커밋, sha256 앞자리, 백분율 등)가 옮긴 글에 같은 값으로 있는가.
2. 원문의 모든 조항 · 조건 · 예외 · 미리 정한 경계 사례가 빠짐없이, 뜻을 바꾸지 않고(더 너그럽게도, 더 엄하게도 아니게) 옮겨졌는가. 특히 bar.lines의 줄마다(B1–B15와 PRE-CALL GATE), decisionRule의 줄마다, samples · calls · risks · perModel의 줄마다. stance.text와 ownerQuestions는 한국어 원문이므로 글자까지 같아야 한다.
3. 옮긴 글이 원문에 없는 조건을 기준이나 결정에 더했는가. 단, 옮긴 글이 '이 묶음이 정한 것', '읽는 법', '(이 묶음의 기록, 원문 밖)', '도구가 글을 읽는 방식', '도구 시험', '1.12.0 기준과 다른 점', '밝혀 둔 벗어남', '사용량 관문', '피할 목록 짓기', '틀과 도구'로 따로 표시한 곳은 원문 밖의 기록으로 보고, 그것이 원문과 어긋나는지, 그리고 원문보다 너그러운지만 본다.
4. 원문끼리(설계와 계획, 또는 계획 안의 두 글) 어긋나는 곳이 있으면 적고, 옮긴 글이 더 엄한 쪽을 따랐는지 본다.

출력: JSON 하나만 ```json 블록으로. 문제가 없으면 빈 배열.
[{"where": "<옮긴 글의 자리>", "source": "<원문 필드와 줄>", "kind": "number|clause-missing|clause-changed|added|conflict|other", "detail": "<무엇이 어떻게 다른지, 한두 문장>", "fix": "<고칠 글 제안>"}]

## 원문 (JSON)

```json
{
 "design": {
  "name": "비슷한 코드 (rungChangedStep) · sonnet 실행 길: 플러그인이 기기에서 돌려 확인한 곳만 보이고, 모델은 곳과 새 값만 고르며, 답은 플러그인이 돌린 결과 (1.13.0 G2-RUN, 파일럿 r2)",
  "bar": {
   "source": "docs/qa/견본.md '1.12.0 비슷한 코드 (G2)' → '기준 · 입장 · 결정 규칙' (bar commit 5da364c, pointing at code 3f9084c). It restates the 1.10.0 bar (d684d90; numbers from 1.8.0 and F4) without change, and is the last committed G2 bar for either model. Its decision rule 3 covers a sonnet round. It is governed by G7 M-0..M-15, B-1..B-15 and R0..R11, read as 1.13.0. Nothing is laxer.",
   "lines": [
    "B1 Numbers unchanged from the last committed bar. Nothing laxer.",
    "B2 Unit: the 20 changed slots of 9 quizzes (measured js 13 · py 7). The other items (내 코드, 왜, 다시 도전) are recorded only.",
    "B3 (가) At least 16 of the 20 slots meet every condition of stance clause 7 (ㄱ)–(ㅈ), plus clauses 16, 17 and 18.",
    "B4 (나) 0 wrong A among read items (clauses 6, 11 and 16). A stored answer that differs from the real run is wrong even though the plugin computed it.",
    "B5 Every slot is graded by running the shown code exactly as shown: unshare -n timeout 5; node twice; python with PYTHONHASHSEED 1..5, all five agreeing; nothing filled in. The learner's output is the real run of the whole file, never the plugin's '지금 찍히는 글자'.",
    "B6 Empty replies, timeouts, refusals and unread slots (changedRunItem: missing, grammar, other-slot, site, long) are (가) misses, outside (나), and are not re-sent. Only api-error is re-sent, at most twice. Cap hits (output_tokens ≥ 4600 + H_sonnet, from the 1.13.0 calibration) are recorded, and slots lost to them are (가) misses. Empty replies are tapped once for stop_reason.",
    "B7 Two blind judges per label, neither seeing the other label. A split, or a case the stance does not decide, goes against the feature. No clause is added, changed or re-read after any answer is opened (M-11).",
    "B8 Decision per model from that model's counts only: pass iff (가) ≥ 16/20 and (나) = 0. On a pass, the next commit sets MODEL_SWITCHES.sonnet.rungChangedStep = 2 and isChangedRun = true together (R6; route SHIPPED; R9 full old-build probe through the real plugin path; R10 docs). Otherwise both stay off. RUNG_CHANGED_STEP and IS_CHANGED_RUN stay off (D1). No transfer between models (R1/R2).",
    "B9 One round per (design, sonnet); no re-roll with new samples or a reworded sentence. The design's code stays behind the switch if it fails (rule 5). Rule 6 (sonnet): each of these is a widening and needs a new round: turning isChangedRun off while rungChangedStep stays 2; loosening isCertified; adding place kinds or values (decimals, negatives, values beyond numberBound); widening printArgs (containers, '%' formats, keywords, more than 4 values); widening changeSites, isChangedShaped or CHANGED_UNSETTLED; accepting a fallback as the model's choice in the measuring tool; or ANY edit to newRun/newParse. Narrowing needs none.",
    "B10 Measured = enabled (D33): 24 concepts written blind (20 plus 4 spares), all whole created files, js 15 · py 9 (measured js 13 · py 7), each in the sonnet run route's scope by the committed rungOf. Fillers: 내 코드 3 (ts, js, py fixes), 왜 2, 다시 도전 2. Quiz layout Q1–2 [c,c,c], Q3–5 [c,c,내 코드], Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; stages 2 and 3 alternating, all due; beginner; maxTokens 4600; timeoutMs 90000; effort low; QUIZ_SYSTEM; D34 9/9.",
    "B11 Stance statements committed with the bar (all neutral or stricter): 1 (C read, N neither asked nor read, the answer is the plugin's run), 2 (the run-route reasons are unread slots), 3 (the plugin's O is never used for judging), 16 (no tool-defect excuse), 17 (rung reached only through the committed sonnet route), 18 (a fallback item is a (가) miss but graded in (나)), 19 (a sample shortfall slot is a (가) miss), 20 (answer form).",
    "B12 Calibration on a fresh pinned copy of the installed CLI before the round, with version and alias recorded before and after. A difference voids the round, and the cell stays OFF (M-10, D19).",
    "B13 Deviation from 1.12.0 rule 3 ('same frozen samples'), stated in advance: 1.13.0 uses fresh blind samples written as above, because haiku's answers on the 1.12.0 set are already opened (M-3, D8) and at least 4 of its 20 files lie outside the run scope (D33). This is stricter in blindness, and haiku is not re-measured.",
    "B14 Rule 5 / D26 (extended): before every commit, re-check haiku's frozen requests, picks and reading byte for byte (lines-haiku.jsonl 876c8efd…, build.json 0db255b4…, read.json 05aa93f5…). Any difference in requests or picks turns haiku G2 OFF in that batch. Once sonnet is ON, the same holds for sonnet's frozen round (its requests, picks and re-read items), and any edit to newRun/newParse (for example when G3 lands) must re-pass the pre-call differential gate on the frozen sonnet samples and the wide corpus, or sonnet G2 turns OFF in that batch.",
    "B15 Common (G7 read as 1.13.0): M-1 the same bar for both models, counted per model; M-2 alias as is, effort low (unchanged), redactText, 4 at a time, D34 before calls; M-3 haiku is not called in this round, so sonnet alone; M-4 empty and timeout are misses, and the 10% api-error rule applies; M-5 cap = maxTokens + H_sonnet (re-measured); M-8 labels and a sealed pair; M-10 version/id before and after; M-11 undecided = miss; M-12 shared, blind samples not written for sonnet; M-13 recheck haiku's cell (B14); R2 no transfer; R4 another model string, an alias change or an unreadable state is always OFF; R5 a prompt change after results turns the cell OFF, and a reading-only change means re-reading the frozen answers.",
    "PRE-CALL GATE (new, stricter, stated in advance): after freezing and before any call, the differential gate of samples.preCallGate must give 0 accepted mismatches, with the engine runtime equal to node. Otherwise there are no calls, the cell stays OFF, and the failure is recorded."
   ]
  },
  "stance": {
   "how": "The full judging stance below (Korean, committed verbatim with the bar). It is the 1.12.0 G2 stance (5da364c) with clause numbers and meanings kept: clauses 1, 2, 3, 13 and 0 are amended for the run route, clauses 16–20 are added, and the boundary-case list is extended with every case from the r0–r2 dev answers. Every change is neutral or stricter. ⚙ clauses are counted by the frozen eval tool with real node/python; ✎ clauses (7 (ㅇ) where the tool cannot decide, and 11 when the tool finds no equality) are counted by two blind judges per label. A case the stance does not decide counts toward failing (M-11).",
   "edits": [
    "1: C is the only model line read; N and O are neither asked nor read; the answer is the plugin's run (neutral: what is stored is still all that is judged).",
    "2: the unread reasons are changedRunItem's five (neutral; follows B6).",
    "3: the plugin's '지금 찍히는 글자' is never used; the learner's output is the real run (stricter).",
    "13: other-slot and lastWins for C (neutral).",
    "16 (stricter), 17 (stricter), 18 (stricter), 19 (stricter), 20 (neutral): added.",
    "Boundary cases: 1.12.0 O/N cases marked as not arising, and 1.13.0 dev cases added (fallback kinds, odd but correct values, far-from-concept changes, multi-value prints, -0 and long floats, C grammar variants, evaluator-vs-real disagreement, step limit, shortfall)."
   ],
   "text": "판정의 입장 (G2 sonnet, 1.13.0 G2-RUN 실행 길). 기준 · 결정 규칙 · 짜임 · 견본 쓰기 프롬프트와 함께, 견본을 쓰거나 부르기 전에 docs/qa/견본.md 새 절로 한 커밋에 넣습니다(UTC 시각, 가리키는 코드 커밋 해시). 매기는 쪽은 이 글의 조항만 따르고 판정마다 조항 번호를 적습니다. ⚙ 조항은 eval 도구(부르기 전에 sha256으로 얼림)가 세고, ✎ 조항만 매기는 하위 에이전트가 매깁니다. 1.12.0 G2 입장(5da364c)의 조항 0–15 번호와 뜻을 그대로 두고, 실행 길에서 달라지는 것은 그 조항 안에 '(1.13.0)'으로 적고 조항 16–20을 더했습니다. 바뀐 것은 모두 중립이거나 더 엄격합니다. 이 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 '다시 잴 때'에 적습니다(M-11).\n\n0 셈의 단위: 비슷한 코드로 고른 20자리(퀴즈 9개, 견본 짜임의 잴 자리 js 13 · py 7). 같은 퀴즈의 내 코드 · 왜 · 다시 도전 문항은 셈 밖이고 기록만 합니다. (1.13.0) 짜임에서 채우지 못한 잴 자리(조항 19)도 20자리에 듭니다.\n\n1 읽기 ⚙ (1.13.0): 플러그인처럼 fixEscapedTicks → 그 커밋의 parseQuiz로 읽어 저장될 문항(question · hint · answer · kind · rung)만 매깁니다. 실행 길의 자리(build 기록에서 그 고르기에 code.run이 있음)는 parseQuiz 안에서 changedRunItem이 읽습니다. 모델이 쓰는 것은 C 줄(고른 곳의 이름과 새 값)뿐이고, O · N은 묻지도 읽지도 않습니다. 저장된 답(answer)은 모델 글이 아니라 플러그인이 기기에서 바꾼 코드를 돌린 줄들입니다. C 줄, '지금 찍히는 글자', '바꿀 수 있는 곳' 목록과 날글은 저장되지 않으므로 판정 대상이 아닙니다(조항 18에서 자기 값인지 가릴 때만 도구가 isOwn으로 봄). 답에 N 줄이나 다른 줄이 더 있어도 읽지 않고 매기지 않습니다. 읽힌 문항은 그 번호 자리의 개념으로 플러그인이 짠 문항입니다.\n\n2 답이 없는 자리 ⚙ (1.13.0): 빈 답(empty-reply · API 거절), 시간 한도(90초)에 끊긴 답, 읽히지 않은 자리, 플러그인의 읽기(changedRunItem)가 문항을 내지 않은 자리 — missing(C 없음) · grammar(C 머리가 '번호+글자' 꼴이 아님) · other-slot(번호가 자리와 다름) · site(목록에 없는 글자) · long(문제 글이 1200자를 넘음) — 는 (가)에서 놓침, (나)에서는 셈 밖입니다(학습자에게 보이지 않음). 상한에 닿았어도 읽힌 문항은 읽힌 그대로 매깁니다. 다시 보내는 것은 글이 하나도 없고 출력 토큰이 0인 api-error(상태 429 · 5xx)뿐이며 같은 프롬프트로 두 번까지, 모두 기록합니다. 그래도 실패하면 그 퀴즈의 자리는 모두 놓침입니다. 빈 답 · 시간 끊김 · 상한 닿음 · 읽기가 거른 자리는 다시 보내지 않습니다. 빈 답은 기록으로만 탭으로 한 번 더 보내 stop_reason과 stop_details.category를 적습니다.\n\n3 돌리기 ⚙: 문제의 코드: question의 펜스 블록(플러그인이 넣은 하나)입니다. 언어는 펜스 이름(js · python)입니다. 빈 임시 폴더에서 `unshare -n timeout 5`로, 표준 입력을 비우고 돌립니다. js: `node 파일` 두 번. py: `env -i PATH=\"$PATH\" LANG=C.UTF-8 PYTHONHASHSEED=<n> python3 -s -P -B 파일`을 n = 1..5로 다섯 번. 결과는 표준 출력의 줄들입니다(마지막 줄이 줄바꿈 없이 끝나도 한 줄). 끝 코드가 0이 아니면 그 앞까지의 출력 뒤에 마지막 예외의 이름(메시지는 뺌) 한 줄을 더합니다. 표준 오류는 결과에 넣지 않습니다. 돌린 결과가 서로 하나라도 다르거나 5초를 넘으면 그 문항은 (가) 놓침이고 A는 틀림입니다. 학습자 결과: 견본을 얼리기 전 확인 때 학습자 파일 전체(= 바꾸기 전의 보인 코드)를 같은 규칙으로 돌려 얼린 줄들입니다. (1.13.0) 플러그인이 요청에 보인 '지금 찍히는 글자'(기기의 평가기가 낸 것)는 판정에 쓰지 않습니다. 학습자 결과와 문제 코드의 결과는 늘 이 조항으로 진짜 돌린 것입니다. 도구 판(node · python · Claude Code)을 적습니다.\n\n4 채우지 않음: 블록에 없는 정의 · import · 입력 · 파일 · 준비를 덧붙이지 않습니다. 나는 오류도 결과입니다. (이 설계의 문제 코드는 학습자 파일 전체라 채울 것이 생기지 않지만 규칙은 그대로 둡니다.) \"글로 말한 바꿈\"은 쓰이지 않습니다(바꿈은 플러그인이 코드에 넣음).\n\n5 물은 것 ⚙: 문제 글은 플러그인의 고정 글(CHANGED_LEAD)이고 \"이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름\"을 묻습니다. 그래서 물은 것은 언제나 결과 전체(오류로 멈추면 그 앞 출력과 오류 이름)입니다. 매기는 쪽이 Q만 보고 물은 것을 정하는 단계는 쓰이지 않습니다. question이 이 글로 시작하지 않으면 10에서 놓침이고, (나)는 결과 전체와 견줍니다.\n\n6 표기 맞춤 ⚙: 1.10.0 조항 6을 글자 그대로 씁니다(A와 결과, 결과끼리 견줄 때 모두). 줄마다 앞뒤 공백을 지우고, 이어진 공백은 하나로, 글자 · 숫자(한글 포함)가 아닌 문자 바로 옆의 공백은 지웁니다. 따옴표 종류는 가리지 않습니다. 결과 줄이 따옴표로 시작하고 끝나지 않을 때만 A 줄 전체를 감싼 따옴표 · 백틱을 뗍니다. js에서 결과 줄에 따옴표로 감싼 객체 키가 없을 때만 A의 `\"a\":` · `'a':`를 `a:`로 봅니다(py는 그대로). 줄 끝 마침표 하나와 true · false · none · null · undefined · nan의 대소문자는 보지 않습니다. 결과 끝의 빈 줄은 견주지 않고, 가운데 빈 줄은 A의 빈 줄이나 '(빈 줄)'과 같습니다. 결과가 여러 줄이고 A가 한 줄이면 결과 줄들을 ', ' · ' ' · '과 ' · '와 ' · ' 그리고 ' · ' → ' 가운데 하나로 이어 맞춘 것이 A와 같으면 같음입니다. 그 밖의 글자 · 값 · 차례 · 줄 수 · 괄호 · 숫자 표기 · 대소문자는 그대로 견줍니다. 앞 공백만 다른 줄(padStart · ljust · rjust)은 이 규칙으로 같음입니다(1.10.0과 같음, 바꾸지 않음).\n\n7 (가) 코드 다름 · 답 다름: 아래를 모두 갖춘 자리만 넘음으로 셉니다. (ㄱ) ⚙ 읽힌 문항의 rung이 changed. (ㄴ) ⚙ 코드를 바꿨음: 3의 문제 코드가 학습자 조각(= 파일 전체)과 6의 맞춤과 줄 끝 `;` · 주석 뺌 뒤 줄 단위로 (i) 같지 않고 (ii) 찍는 줄(한 줄짜리 console.log(…) · print(…))을 뺀 나머지 줄이 학습자 줄들의 부분열이 아님. (ㄷ) ⚙ 그 개념의 코드에서 왔음: 학습자 조각의 핵심 줄(토큰 4개 이상, 괄호뿐 · else · `return 이름` · 이름 하나만 찍는 줄이 아님; 없으면 토큰 2개 이상) 가운데 하나 이상이 보인 코드의 어느 줄과 토큰이 같거나 하나만 다름(codeAsRead 토큰). (ㄹ) ⚙ 정의 빠짐이 아님: 결과가 ReferenceError/NameError로 끝나고 그 이름이 블록 안에서 한 번도 선언 · 대입 · 매개변수 · for 변수 · catch 변수로 나오지 않으면 놓침(TDZ · UnboundLocalError는 들지 않음). (ㅁ) ⚙ kind가 predict. (ㅂ) ⚙ 펜스 블록이 하나. (ㅅ) ⚙ 답이 다름(8). (ㅇ) ⚙/✎ 문제 글이 맞음(10). (ㅈ) ⚙ 3의 여러 번 돌린 결과가 모두 같고 5초 안. (1.13.0) 더하여 조항 16 · 17 · 18도 (가)의 조건입니다.\n\n8 답 다름 ⚙: 학습자 결과: 3의 얼린 학습자 결과(진짜 돌린 것). 조각 결과: 1.10.0 조항 8의 정의 그대로이고, 이 설계의 조각은 파일 전체이므로(isWholeShown) 조각 결과는 학습자 결과와 같습니다. 견줄 것은 물은 것(5: 결과 전체)입니다. 6으로 맞춘 뒤 아래 가운데 하나면 같음(놓침): (a) 결과 전체가 학습자 결과 전체와 같음. (b) 결과 줄들이 차례 그대로 학습자 결과 안에 이어진 줄들로 있음(어디서 시작해도; 한 줄이면 학습자 결과의 어느 줄과 같아도). (c) 결과 줄마다 학습자 결과의 같은 순번 줄과 같음. (d) · (e)는 물은 것이 언제나 결과 전체라 쓰이지 않습니다. 결과가 오류 이름으로 끝나면 그 줄은 학습자 결과의 어느 줄과도 다릅니다. 결과가 오류 이름 한 줄뿐이면 다름입니다.\n\n9 예측이 아닌 문항: 쓰이지 않음: 플러그인이 kind를 predict로 씁니다. 도구 결함으로 다른 kind가 저장되면 7(ㅁ) 놓침, (나)는 11로 매깁니다.\n\n10 문제 글 ⚙: lead와 hint는 플러그인이 쓴 고정 글이지만 모델 글처럼 매깁니다. (ㅇ)를 갖추려면 모두: (i) question이 CHANGED_LEAD 글 그대로로 시작하고 그 뒤에 펜스 블록 하나만 있음; (ii) 보인 코드와 학습자 코드가 정확히 한 줄에서만 다름(\"한 곳을 바꿨습니다\"가 참); (iii) hint의 \"k번째 줄\"이 그 다른 줄의 번호(보인 블록의 첫 줄을 1로, 빈 줄 포함)와 같음; (iv) hint가 줄을 따왔으면 따온 글이 그 줄의 앞뒤 공백을 뺀 것과 글자 그대로 같음(60자를 넘는 줄은 따오지 않으며 그때는 (iii)만 봄). hint는 바뀐 줄을 알려 줄 뿐 결과를 말하지 않으므로 답을 미리 말한 것으로 보지 않습니다. 하나라도 어긋나면 (가) 놓침입니다.\n\n11 (나) A 맞음: ⚙ 먼저 도구가 A 전체를 6으로 맞춰 3의 결과 전체와 같은지 봅니다. 같으면 맞음. ✎ 아니면 매기는 쪽이 봅니다: A가 결과의 줄을 모두 차례대로 말하고(6의 \"그대로 견주는 것\"으로) 다른 틀린 말이 없으면 맞음. 틀림: 결과 가운데 일부만 쓴 A, 줄여 쓴 A(… · 등 · 생략), 오류로 멈추는 결과에 출력만 쓴 A, 오류 이름을 다르게 댄 A, 둘 이상을 답으로 내놓은 A, 학습자 원래 코드의 답을 쓴 A, 줄 수가 다른 A. (1.13.0) 실행 길의 A는 플러그인이 돌린 줄들이므로 결과와 다르면 조항 16으로 틀림이고, 도구가 같다고 보지 못한 A는 매기는 쪽이 이 조항의 맞음 꼴인지 봅니다.\n\n12 ts: 쓰이지 않음: ts는 범위 밖이고(RUNG_CHANGED_EXTS = js, py) 견본에 넣지 않습니다. 도구 결함으로 ts 문항이 저장되면 (가) 놓침, (나)는 3으로 돌린 결과와 견줍니다.\n\n13 번호가 엇갈린 답 ⚙ (1.13.0): parseQuiz가 짝지은 번호대로 매깁니다. changedRunItem은 그 번호 자리 개념의 코드와 그 자리의 목록으로만 문항을 짜고, C의 번호가 자리 번호와 다르면 문항을 내지 않으므로(other-slot), 엇갈린 답은 읽히지 않은 자리(2)로만 셉니다. C를 다시 쓴 답은 플러그인처럼 마지막 글로 읽습니다(quizParts lastWins).\n\n14 매기는 차례와 갈림: 꼬리표마다 매기는 하위 에이전트 둘이 따로 매깁니다. 둘 다 설계 · 견본 쓰기 · 부르기에 끼지 않은 새 하위 에이전트이고, 이 글과 도구가 낸 파일만 봅니다(모델 이름, 토큰, 시간은 빠짐; 도구가 낸 판정 칸은 ⚙ 조항의 결과로만 보이고 ✎ 조항의 답을 미리 적지 않음). 두 판정이 갈린 문항과 이 글이 가르지 못하는 경우는 기능에 불리한 쪽((가) 놓침, (나) 틀림)으로 셉니다. 재는 세션은 판정을 바꾸지 않고, 출력을 본 뒤 조항을 더하거나 고치거나 다시 읽지 않습니다. 고칠 것은 '다시 잴 때'에 적기만 합니다. 짝 파일은 sha256만 적어 봉하고, 짝을 알리는 파일 이름이나 칸을 짝을 열기 전에 두지 않습니다.\n\n15 미리 가른 경계 사례: 아래 '경계 사례' 목록(1.10.0 · 1.12.0 기록과 1.13.0 개발 견본에서 나온 것)을 따릅니다.\n\n16 (1.13.0, 더 엄격) 플러그인이 낸 답도 똑같이 매김: 실행 길의 저장된 A가 3의 진짜 결과와 6으로 같지 않으면 (나) 틀림이고 그 자리는 (가)에서도 놓침입니다. 평가기(newRun) 결함, node · python 판 차이, '도구 결함' 어느 까닭으로도 면하지 않습니다.\n\n17 (1.13.0, 더 엄격) 고르기 길: 잴 자리마다 문항이 커밋된 트리의 rungOf(sonnet 줄에 rungChangedStep 2 · isChangedRun 켬)로 'changed'에 닿고 code.run이 있는 고르기에서 changedRunItem으로 만들어진 것이어야 합니다. 그 길 밖에서 만들어진 문항(예: 1.12.0의 C · O · N 길로 읽힌 문항)이 저장되면 (가) 놓침이고 (나)는 그대로 매깁니다. 도구가 얼린 build 기록으로 셉니다.\n\n18 (1.13.0, 더 엄격) 모델이 고른 바꿈: 저장된 문항의 바꾼 줄이 모델의 C가 말한 곳에 C가 말한 값을 넣은 것이어야 (가)를 갖춥니다. 모델 값이 값으로 읽히지 않거나(소수 · 음수 · 범위 밖 숫자 · 목록에 없는 대안 · 값 뒤의 다른 글), 바꾼 코드를 평가기가 돌리지 못했거나(오류 · 한도 · 묶음 출력), 바꾼 뒤 결과가 학습자 결과와 같거나 묻지 못할 꼴이라 플러그인이 그곳의 미리 확인한 바꿈으로 대신 냈으면(changedRunItem의 isOwn이 false), 그 자리는 (가) 놓침이고, 저장된 문항이므로 (나)에서는 매깁니다. 도구가 같은 커밋의 changedRunItem이 낸 isOwn으로 셉니다.\n\n19 (1.13.0, 더 엄격) 견본이 모자란 자리: 견본 짜임의 잴 자리(js 13 · py 7)를 커밋된 rungOf로 'changed'에 닿는 기록으로 채우지 못한 자리(미리 정한 보탬 한 번 뒤에도 모자람)는 (가) 놓침이고 (나) 밖입니다. 다른 언어의 기록으로 채우지 않습니다.\n\n20 (1.13.0, 중립) 실행 길의 답 꼴: 저장된 A는 플러그인이 돌린 줄들(1–4줄, 줄마다 160자 이하, 빈 줄 없음)을 줄바꿈으로 이은 것이고 오류 이름으로 끝나지 않습니다(오류로 멈추는 바꿈은 목록에 오르지 않고, 모델 값이 오류로 멈추면 대신 냄 → 18). CHANGED_LEAD의 '오류로 멈추면 …' 글은 이 길에서 쓰일 일이 없지만 문항 글의 일부로 10 (i)에 그대로 듭니다.\n\n경계 사례\n- 1.10.0 기록(그대로): W10 부모 클래스가 블록에 없음 → 7(ㄹ)(이 범위에서는 생기지 않음). 줄인 출력 → 11 틀림. 되돌리기 · 바꿔 보기 · 왜 → 9(쓰이지 않음). Q가 지금 출력을 틀리게 말함 → 10. Object.freeze A length 1 vs TypeError → 11 틀림. 빈 답 · 상한에 잘린 끝 → 2. 그대로 보임 · 몇 줄만 떼어 보임 → 7(ㄴ). 1.8.0 ===/== 출력 그대로 → 8 같음. node `[ 1, 2, 3, [ 4 ] ]` vs A `[1, 2, 3, [4]]` → 6 같음(이 길에서는 묶음을 찍는 파일이 범위 밖). 산문 A → 11. pythonista[7:]를 ista로 → 11 틀림. 두 블록으로 보임 → 7(ㅂ). 두 번 돌린 결과가 다름 → 3. 끝에 빈 줄을 찍음 → 6 견주지 않음. `1 2`와 `12` → 6 다름. JSON.stringify의 `{\"a\":1}`을 `{a:1}`로 쓴 A → 6 다름.\n- 1.12.0 기록(1.13.0에서 읽는 법): O · N을 다시 썼거나 O가 틀리고 N이 맞은 자리 · 'subset' · 'echo' · 'value' · 'same' · 'count' · 'N-lines'로 걸러진 자리 → 이 길에는 O · N이 없어 생기지 않음(1). for-else · continue · sum · min에서 결과가 학습자 결과의 앞 줄 · 가운데 줄이 됨 → 8(b) 같음(이 길에서는 그런 바꿈이 목록에 오르지 않고, 모델 값이 그렇게 되면 대신 냄 → 18 놓침). grade()의 흐름을 잘못 따름 · 반복의 마지막 줄만 씀 · repeat(-1) 앞에 찍힌 줄을 씀 · JSON 길이를 잘못 셈(모두 1.12.0 개발의 모델 N 틀림) → 이 길의 A는 모델 글이 아니라 생기지 않음; 생기면 16 틀림.\n- A 줄 끝 마침표(`true.`) · 대소문자(`TRUE`/`True` in js) → 6: 마침표 하나와 true/false 대소문자는 보지 않음. py `<class 'bool'>`, js typeof의 `number` → 결과 그대로; 6으로 견줌. 실수 표기(0.30000000000000004, 9240.0) → 6 그대로. 앞 공백만 다른 줄 → 6 같음. 가운데 빈 줄 → 이 길의 A에는 빈 줄이 없음(20); 결과에 빈 줄이 있으면 줄 수가 달라 11 · 16 틀림.\n- (dev 1.13.0) 모델 값이 출력을 바꾸지 못함(맵 경계 `x < 0`을 `<=`로 — 데이터에 0이 없음; 배터리 `< 20`을 `<=`로; 과반수 `/ 2`의 2를 3으로) → 플러그인이 그곳의 미리 확인한 바꿈으로 대신 냄 → 18 (가) 놓침, 저장된 문항은 (나)로 매김.\n- (dev 1.13.0) 숫자 자리에 소수(85.5) · 음수(-5) · numberBound를 넘는 수(401) · 원래 값(80) · 값 없음(`1e`, `1e: `) → 대신 냄(isOwn false) → 18 놓침.\n- (dev 1.13.0) 값이 상황에 맞지 않지만 맞게 돈 답('월요일 수면 -4시간', '9시 30분 -15.0도', '빠진 번호: 6.5', 기준표 [(70,\"A\"),(80,\"B\"),(70,\"C\")]의 '예린 A') → B-10: 문제 글의 다른 흠은 기록만; 3 · 6 · 11로 매겨 결과와 같으면 맞음 · 넘음.\n- (dev 1.13.0) 바꾼 곳이 개념 줄(blurb가 따온 줄)에서 먼 데이터 값(삼각형 넓이의 base 6 → 10, 정원 초과의 72 → 150) → 7(ㄷ)는 보인 코드가 학습자 파일 전체라 갖춤; 개념과 먼 바꿈은 B-10 기록만(개발 sonnet D 9/40 · E 14/40만 개념 줄에 닿음, haiku도 비슷함).\n- (dev 1.13.0) console.log · print에 값 여럿(`console.log('합계:', total)` → `합계: 176`, `print(\"x\", 1.0, True, None)` → `x 1.0 True None`) → 결과 그대로; A도 플러그인이 같은 꼴로 냄; 6으로 견줌. 첫 인자가 `%`를 품은 console.log와 키워드 인자 print는 평가기가 돌리지 않아 범위 밖.\n- (dev 1.13.0) js `-0`, py `-0.0`, 긴 실수(`3168.3168316831684`), py 정수 나눗셈의 `.0` → 결과 그대로(6은 숫자 표기를 그대로 견줌); 다르면 16 틀림.\n- (dev 1.13.0) C 머리를 백틱으로 감쌈(`` `1d` < ``) · 이름 뒤에 쌍점 · 화살표(`1d: <`, `1d → <`) → 읽기 그대로(grammar 통과). C 머리가 글자 둘(`1dd`) · 번호 없음(`d <`) · 목록 밖 글자(`1g`) → 2 읽히지 않음(grammar). 번호가 다름 → 13(other-slot).\n- (dev 1.13.0) 문자열 자리의 값을 따옴표 없이 · 다른 따옴표로 씀 → siteValue가 읽으면 그 값, 못 읽으면 대신 냄 → 18로 기계가 셈(isOwn).\n- (dev 1.13.0) 한 줄에 같은 토큰이 둘(`두 번째 0`) → 목록이 순번으로 가리키고 플러그인이 그 자리만 바꿈 → 10 (ii)로 정확히 한 줄 다름을 봄.\n- (dev 1.13.0) 답 끝에 N 줄 · 설명을 덧붙임 → 1: 읽지 않음, 저장된 문항만 매김.\n- (1.13.0) 플러그인의 '지금 찍히는 글자'가 진짜 학습자 결과와 다름(평가기 결함) → 3: 판정은 진짜 결과로만; 8도 진짜 학습자 결과와 견줌; 저장된 A가 진짜 결과와 다르면 16 틀림; 평가기 결함은 '다시 잴 때'에 적음.\n- (1.13.0) 바꾼 코드의 진짜 실행이 5초를 넘음 → 3: (가) 놓침 · A 틀림(평가기는 20,000걸음을 넘으면 돌리지 않으므로 생기면 16과 함께 적음).\n- (1.13.0) 결과가 다섯 줄 이상 · 160자 넘는 줄 · 빈 줄이 되는 모델 값 → 플러그인이 대신 냄 → 18 놓침.\n- (1.13.0) 견본 쓰기에서 한 언어가 보탬 한 번 뒤에도 모자람 → 19: 그 잴 자리는 (가) 놓침, 다른 언어로 채우지 않음."
  },
  "decisionRule": [
   "Sonnet only, from sonnet's counts only (R1–R4). (가) = the number of the 20 measured changed slots whose stored item meets clause 7 (ㄱ)–(ㅈ) and clauses 16, 17 and 18, under both judges. Refused, empty, timed-out, unread, fallback (isOwn false), shortfall, split and undecided slots are misses. (나) = the number of read items whose A is wrong (clauses 6, 11 and 16; split or undecided = wrong).",
   "If the pre-call gate fails, or calibration or the before/after record mismatches: no round, and sonnet stays OFF.",
   "Pass ⇔ (가) ≥ 16 and (나) = 0. On a pass, the next commit sets MODEL_SWITCHES.sonnet to { ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2, isChangedRun: true } (R6, SHIPPED re-pinned, R9 old-build probe through the real plugin path, R10 docs, D26 re-check of haiku). Otherwise sonnet stays { ...SWITCHES_OFF, isRuleWide: true }.",
   "Haiku: no decision. Its cell stays ON (rungChangedStep 2, isChangedRun false) exactly as long as the B14 re-check shows its requests, picks and reading byte-identical; otherwise it turns OFF in that batch (rule 5 / D26). Nothing is transferred either way.",
   "One round; no re-roll; any later widening (B9) needs a new round, and narrowing does not."
  ],
  "samples": {
   "whoWrites": "Fresh blind opus sub-agents (`claude -p --model opus --tools ''`, DISABLE_AUTOUPDATER=1, cwd an empty folder). They never see this design, the prompts, the stance, the scope or which model is measured. They use the 1.12.0 G2 measured writer prompts (impl112/b2/gen/writer-A.md, writer-B.md and the *-end.md files) word for word, except for: the record count, ids and languages per part (at most 10 records per call, the G3 STOP lesson); the mix minimums scaled to the part; and the avoid section, which holds names only. This is the dev parts.py procedure (dev/gen/parts.py), frozen with sha256 in the bar commit. Samples are not written or chosen for sonnet (M-12).",
   "layout": "Writer parts written up front: A1–A5, js 10 each (50 js); P1–P3, py 10 each (30 py); B, the fillers as in 1.12.0 (내 코드 3 = ts, js and py fixes; 왜 2; 다시 도전 2). One pre-committed top-up per language that is short (T1 js 10, T2 py 10), then STOP. The first budget is larger than the pilot's (js 25, py 15) because one dev set (B) ended with 11 js members against the 13 measured js slots. From the dev reach (js 44.5%, py 52.6%), the chance that a language is still short after its top-up is below 1%.",
   "membership": "Membership is decided only by the committed tree's sonnet-route rungOf (sonnet row + rungChangedStep 2 + isChangedRun true, through withCode/changedRunFor), in written order. The first js 15 and py 9 eligible records are taken (measured js 13 · py 7 plus 2 spares each, the 1.12.0 layout). A measured slot still unfilled after the top-up is a (가) miss (clause 19); no record of the other language fills it. Haiku samples and haiku's scope do not change.",
   "quizLayout": "The 1.12.0 layout, unchanged: Q1–2 [c,c,c], Q3–5 [c,c,내 코드], Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; stages 2 and 3 alternating; every concept due; level beginner.",
   "freeze": "chmod 444; sha256, author and UTC time recorded in 견본.md. D34: 9/9 requests captured from the plugin test harness with models.sonnet { rungChangedStep: 2, isChangedRun: true } must equal the tool's prompt files byte for byte before any call.",
   "preCallGate": "Stated in the bar and run after freezing, before any call. Every frozen measured and spare record, at every place (changeSites isAll) and every value of the frozen final/wide/gen.mjs list (the runValues four, 0–5, 10, n/2, n+5, n+10, 10n and the bound for numbers; every other same-quote string; every listed alternative), is run by the committed evaluator and by the real runner (B5). Requirements: 0 accepted mismatches, the engine runtime equal to node on the same programs (claude plugin test fixture), and every learner run equal to out. Any mismatch stops the round before calls. The cell stays OFF, the failure is recorded, and newRun is not fixed and re-tried in 1.13.0 (an edit to newRun is a new design).",
   "avoid": "Names only, never 견본.md prose and no model, alias or switch words: every name in impl113/NAMES-all.txt (9,066 lines, including the 285 G2-dev-113 names below, the 133 impl112 G2 dev names, the 1.12.0 G2 measured names and the G3-dev-113 names) plus the record-name fields of docs/qa/견본.md. The new measured names go into impl113/NAMES-all.txt tagged 'G2-measured-113'.",
   "devNamesToAvoidCount": 285
  },
  "calls": [
   "Exactly as the plugin calls (D20), through a copy of the impl111/probe mod. Per quiz: $.model.complete({ model: 'sonnet' (the setting string as is), effort: 'low', system: QUIZ_SYSTEM, prompt: redactText(quizPrompt(picks, 'beginner')).text, maxTokens: 4600, timeoutMs: 90000 }). Calls run 4 at a time, are timed with $.clock, and replies go through fixEscapedTicks and are read by the committed parseQuiz. Picks are built as makeQuiz builds them (codeFor, withCode with changedRun → changedRunFor, rungOf, ladderMixed, pickForRung), from the committed tree with sonnet's shipped row (isRuleWide true) plus rungChangedStep 2 and isChangedRun true (M-13).",
   "One round of 9 sonnet calls. Haiku is not called (its cell is ON and proved byte-identical, rule 5 / D26). Only api-error (429/5xx, 0 tokens, no text) is re-sent, at most twice. Every empty or refused reply is tapped once through the pass-through tap for stop_reason and stop_details.category (a record only). The M-4 10% rule applies.",
   "CLI: a fresh pinned copy of the then-installed Claude Code (2.1.329 or later), DISABLE_AUTOUPDATER=1. M-5/M-10 calibration first (H_sonnet re-measured; the 1.12.0 value 2048 is not reused). `claude --version`, the system/init model and the modelUsage keys are recorded before and after. A mismatch with the calibration record voids the round, and the cell stays OFF.",
   "Usage gate (five_hour ≤ 0.60, seven_day < 0.80), detached runners, waiting on runner PIDs or status files (never `while pgrep -f`). Backup tar sha256 recorded in 견본.md.",
   "Labels: the sonnet round gets a random label. The pair file is sealed (sha256 only), and no file written before the pair is opened names the model."
  ],
  "risks": [
   "(나) is evaluator-bound. An evaluator bug on learner code outside the tested corpora would store a wrong 정답 with no runtime check: a learner who writes the true output is graded wrong, and the concept goes to step 0. Mitigation: a closed subset with refusals by default; 15,895 + 6,000 + 384 differential programs with 0 mismatches; engine = node; the pre-call gate; clause 16; B14 for any later newRun edit. The risk is residual and stated.",
   "Version drift: the evaluator matches Node 22 and CPython 3.11 as tested. A learner on another version could see different output for float formatting or dict and str corner cases. The subset (no set printing, no dict/list printing, primitive prints only) keeps this small. Recorded.",
   "Refusal classifier: the r2 wording ran 36 times (and 105 sonnet calls in all) with 0 refusals. The classifier is non-deterministic, so a refusal in the round would cost 2–3 slots per quiz. Tolerance is 4 slots.",
   "Reach: about 48% of whole-file records (haiku 90%). A sonnet learner sees 비슷한 코드 less often; other concepts are asked as 내 코드.",
   "Teaching quality: the changes the model picks often land on data values far from the concept line, and some values are odd but correct ('수면 -4시간'). Not a bar issue; recorded.",
   "Procedure: the pilot exceeded the design text's one-revision rule (owner question 0). The measured round itself is fresh, blind and committed in advance, so its result is not affected. The risk is only that a round is spent.",
   "Calibration: H_sonnet must be re-measured. A version or alias mismatch voids the round (the cell stays OFF).",
   "A cut reply (1.10.0) did not recur in 105 dev calls. It is kept as a residual risk (it would cost that quiz's changed slots).",
   "Build interplay: G5 (sonnet) and G6 (haiku) builds in 1.13.0 must keep G2's haiku and sonnet bytes (D26). If G3 lands later, its newRun must be this one, or B14 applies."
  ],
  "perModel": {
   "haiku": "ON (1.12.0 measured 18/20, 0 wrong; rungChangedStep 2). This design does not touch haiku. The final tree keeps all three D26 proofs: the 9 frozen requests rebuilt byte-identical (D34 9/9, lines-haiku.jsonl 876c8efd…), build.json identical, and the frozen answers re-read to read.json 05aa93f5… identical (proofs/final). The 14 real plugin requests across models, levels and languages are identical between HEAD and the pilot tree (crit/bytes). Not measured, nothing transferred. The haiku dev control (records only) gave 18, 18, 20, 17 and 18 of 20 with 0 wrong in 91.",
   "sonnet": "Measure (one round). Final dev sets D and E (records only, written after r2 was frozen): 20/20 kept in all four runs, 19/20 under clause 18 (one fallback per run), 0 wrong in 80 read items, 0 refusals, 0 empty, 0 cut, 0 timeouts, 0 cap hits, max 545 output tokens."
  },
  "ownerQuestions": [
   "0. 비슷한 코드(G2) sonnet: 파일럿이 설계 글의 '일반 고침 하나' 규칙을 넘었습니다(파일럿이 부르기 전에 얼린 GO 파일은 '세 번까지'라고 적어 서로 어긋났음). 첫 설계(r0)와 고침 1(r1)은 못 넘었고, 고침 2(r2: 모델은 곳과 새 값만 고르고 답은 플러그인이 기기에서 돌린 결과)는 그 코드를 얼린 뒤 새로 쓴 세트 D와, 고치지 않고 따로 둔 세트 E에서만 판정했습니다. 네 번 모두 20/20(모델이 고른 값만 세면 19/20)이고 틀린 답 0입니다. (a) 기본값: r2를 1.13.0 설계로 보고, 이 어긋남과 '플러그인이 대신 낸 바꿈은 놓침' 조항을 기준 커밋에 적은 뒤 sonnet을 한 회 잽니다(새 보정, 새 블라인드 견본, 부르기 전 평가기 대조). (b) G1 · G3처럼 1.13.0에서는 짓지도 재지도 않고 다음 판으로 넘깁니다.",
   "1. ((a)일 때만) 기기에서 코드를 돌리는 평가기(G3 시제품의 newRun, 약 4,160줄)를 G3는 재지 않는데도 G2 sonnet을 위해 저장소에 넣을까요? 기본값: 예 — G3 시제품에서 그대로 옮기고, 값 여럿을 찍는 출력만 더합니다(끈 칸에서는 쓰이지 않음). 아니오면 G2 sonnet은 1.13.0에서 짓지도 재지도 않습니다.",
   "2. ((a)일 때만) 모델에게 '상황에서 말이 되는 값'을 고르라는 말을 더할까요? '수면 -4시간'처럼 맞지만 어색한 답이 줄 수 있습니다. 기본값: 아니오 — 프롬프트가 바뀌면 파일럿 수가 그 글을 덮지 못하고, 기준 커밋 전에 새 개발 세트로 거절 · 빈 답이 없음을 다시 보여야 합니다. 예면 그 확인을 한 번 하고, 거절 · 빈 답이 하나라도 나오면 지금 글로 잽니다."
  ]
 },
 "plan_batch2": {
  "notMeasured": [
   "haiku: ON since 1.12.0, kept byte-identical, not re-measured (notMeasured.onNotReMeasured)"
  ],
  "barSource": {
   "fields": "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G2.json: bar.source and bar.lines B1–B15 plus PRE-CALL GATE, stance (text, how, edits: clauses 1–20 with 16–20 new), decisionRule, samples (whoWrites, layout, membership, quizLayout, freeze, preCallGate, avoid), calls.",
   "summary": "sonnet only: pass ⇔ (가) ≥ 16 of the 20 changed slots meet clause 7 (ㄱ)–(ㅈ) plus 16, 17, 18 under both judges, and (나) = 0 wrong A among read items (clauses 6, 11, 16). Refused, empty, timed-out, unread, fallback (isOwn false; clause 18 — graded in (나) but a (가) miss), shortfall (clause 19), split and undecided slots are (가) misses. Every slot graded by running the shown code exactly as shown. Only api-error re-sent, at most twice; cap hit = output_tokens ≥ 4600 + H_sonnet (a lost slot is a (가) miss).",
   "declaredDeviations": "Stated in the bar commit before any sample: (1) the pilot exceeded the design text's one-revision rule (its GO file said 'up to three'); r2 was judged only on sets D and E written after its code was frozen (G2 ownerQuestions 0 default (a)); (2) B13: fresh blind samples instead of 1.12.0 rule 3's 'same frozen samples' (stricter in blindness); (3) clause 18 (fallback = (가) miss) and clause 19 (shortfall = (가) miss), stricter; (4) the pre-call gate, stricter.",
   "decision": "MODEL_SWITCHES.sonnet = { ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2, isChangedRun: true } iff pass; else { ...SWITCHES_OFF, isRuleWide: true }. Haiku: no decision (B14 only). RUNG_CHANGED_STEP and IS_CHANGED_RUN stay off (D1). One round; B9 widening needs a new round.",
   "capNumbers": "quiz cap hit = output_tokens ≥ 4600 + H_sonnet, as a number from the 보정 기록.",
   "quotedFrom": "docs/qa/견본.md '## 1.12.0 비슷한 코드 (G2)' > '기준 · 입장 · 결정 규칙' (5da364c) restated; the bar commit writes '## 1.13.0 비슷한 코드 (G2): 실행 길 · sonnet'."
  },
  "samples": {
   "layout": "Writer parts A1–A5 js 10 each (50 js), P1–P3 py 10 each (30 py), B fillers as in 1.12.0 (내 코드 3 = ts, js, py fixes; 왜 2; 다시 도전 2) in one call of 7 records of three filler kinds. That call is the declared exception to 'one set kind per call' (1.12.0 writer-B.md word for word; it ran without refusal in 1.12.0; 7 ≤ 10), named with its count in the bar commit. 9 writer calls, each ≤ 10 records; one pre-committed top-up per short language (T1 js 10, T2 py 10), then STOP. Writer prompts = /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/gen/writer-A.md, writer-B.md and *-end.md word for word except record count/ids/languages per part, scaled mix minimums and the names-only avoid section (dev/gen/parts.py procedure, frozen with sha256 in the bar commit).",
   "membership": "Decided only by the committed tree's sonnet-route rungOf (sonnet row + rungChangedStep 2 + isChangedRun true, through withCode/changedRunFor), in written order: first js 15 and py 9 eligible records (measured js 13 · py 7 + 2 spares each). An unfilled measured slot after the top-up is a (가) miss (clause 19); no cross-language fill.",
   "quizLayout": "Q1–2 [c,c,c], Q3–5 [c,c,내 코드], Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; stages 2 and 3 alternating; every concept due; beginner.",
   "freeze": "chmod 444; sha256, author, UTC in 견본.md; names appended to NAMES-all.txt tagged 'G2-measured-113'; then the pre-call gate; then D34 9/9 (harness models.sonnet { rungChangedStep: 2, isChangedRun: true }) before any call.",
   "avoid": "avoid113.py output (calibration.avoidBuilder) from NAMES-all.txt (incl. G2-dev-113 285, G2-dev, G2-measured, G3-dev-113, G3-dev-retry): names only, filtered as the builder states. It replaces the avoid section that design/G2/dev/gen/parts.py made, and the bar commit declares that change. check.py (NAMESALL = impl113/NAMES-all.txt) rejects records against the complete registry and the extended corpora (commonPerBatch.freezeCheckInputs)."
  },
  "calls": {
   "sonnet": "9 quiz calls: $.model.complete({ model: 'sonnet', effort: 'low', system: QUIZ_SYSTEM, prompt: redactText(quizPrompt(picks, 'beginner')).text, maxTokens: 4600, timeoutMs: 90000 }), 4 at a time, fixEscapedTicks, committed parseQuiz; picks built as makeQuiz builds them from the committed tree with sonnet's row (isRuleWide true) + rungChangedStep 2 + isChangedRun true (M-13).",
   "haiku": "0 calls.",
   "retries": "Only api-error (429/5xx, 0 tokens, no text) re-sent, at most twice; empty/refused replies tapped once for stop_reason and stop_details.category (record); M-4 10% rule.",
   "stages": "One stage: quiz sonnet."
  },
  "judges": "Two blind opus judges for the sonnet label, neither seeing another label; a split or an undecided case goes against the feature (B7). Machine: the real runner grades every slot (B5) and the frozen count script.",
  "stop": [
   "G2 haiku request or pick difference on the build tree that cannot be removed → no build commit; stop and report.",
   "Pre-call gate fails → no calls, sonnet OFF (recorded).",
   "Round void (M-10) or M-4 → sonnet OFF, not re-measured.",
   "Writer refused twice on one call (refusal as commonPerBatch.writerRunner defines it; a usage-limit ending is WAIT) → STOP, not measured (recorded).",
   "A single wrong A among read items fails the round (no stop; recorded)."
  ],
  "preCallGate": {
   "what": "G2 bar 'PRE-CALL GATE' (new, stricter, stated in advance): after the samples freeze and before any call, every frozen measured and spare record, at every place (changeSites isAll) and every value of the frozen /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G2/final/wide/gen.mjs list, is run by the committed evaluator and by the real runner (B5: unshare -n timeout 5; node twice; python PYTHONHASHSEED 1..5 all agreeing).",
   "pass": "0 accepted mismatches; the engine runtime equal to node on the same programs (claude plugin test fixture); every learner run equal to out.",
   "ifFails": "No calls; the cell stays OFF; the failure is recorded in the G2 section; newRun is not fixed and re-tried in 1.13.0 (an edit to newRun is a new design). The code stays behind the OFF switch (G2 rule 5).",
   "cost": "CPU only (about 16k programs, about 10 minutes)."
  },
  "switchCommit": "If pass: MODEL_SWITCHES.sonnet = { ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2, isChangedRun: true }; route SHIPPED; R9 old-build probe (seven builds) through the real plugin path with the ON value; recheckRemap per ON quiz; ≥ 2 mutation probes at the ON value; measured prompts re-made byte-identical; D26 of G2 haiku (9/9, build.json, read.json), isRuleWide, isRuleDrill haiku if ON; the evaluator block sha256 recorded for B14.",
  "usage": "9 sonnet calls (~2,500-char requests, ≤ ~550 output tokens each); ≤ 11 writer calls, 2 judges and 1 translation check (≈ 14 × c_sub); agent steps ≈ 11; pre-call gate CPU ~10 min. Batch projection 0.16 (formula in commonPerBatch.usageGate[2]); round R = 0.01."
 }
}
```

## 옮긴 글

````markdown
## 1.13.0 비슷한 코드 (G2): 실행 길 · sonnet

### 짓기 (sonnet 실행 길, 끔; 3/4 짓기 커밋 5c27746)

설계 G2(1.13.0 G2-RUN, 파일럿 r2: "플러그인이 기기에서 돌려 확인한 곳만 보이고, 모델은 곳과 새 값만 고르며, 답은 플러그인이 돌린 결과")의 코드는 5c27746(2026-11-21 03:34 UTC 커밋)에 끈 스위치 뒤로 들어갔습니다. 무엇을 바꿨고 무엇을 확인했는지(모듈 시험 · 끈 바이트 · 진짜 플러그인 요청 14개 · 옛 창 일곱과 coexist19 · 엔진 실행 기록 · 돌연변이 탐침 13 · D26 재확인 · 모듈 크기 · 관문)는 그 커밋 본문에 있습니다. hooks/notes.ts sha256 `4b36cf9d1d7d0bd1aea179b9f865a1354b72d666c11789a890beb26ba7f54b99` · hooks/newrun.ts `393ed29b414cb784e3e70e1e06a79637e6a5f0bbd7a053c2a765a3cf51b21943` · hooks/register.tsx `dd8a5def01596e19221a8de0718acb23684b239bba0a12315bc9d540c43a2182`. RUNG_CHANGED_STEP과 IS_CHANGED_RUN은 끈 값 그대로이고, MODEL_SWITCHES 두 줄은 짓기 전 그대로입니다(haiku `{ ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2 }`, sonnet `{ ...SWITCHES_OFF, isRuleWide: true }`). 짓기 때의 얼린 입력 백업은 `impl113/backup/b2-build.tar` sha256 `23e2f53d2a7c5d8ee23f99b983e20ca80af80cc6990727830f041db750b7d722`입니다.

### 기준 · 입장 · 결정 규칙 (재기 전에 정함: (커밋 때 적음) UTC, 견본을 쓰거나 모델을 부르기 전)

이 절을 따른다: 이 절은 공통 입장 절('1.10.0 모델별 갈래 (G7): 두 모델을 재는 공통 입장'의 M-0 ~ M-15, B-1 ~ B-15, R0 ~ R11)을 따릅니다. 그 글의 '1.10.0'은 '1.13.0'으로, '묶음 1 보정 기록'은 위 '### 보정 기록 (1.13.0)'으로 읽습니다. 위 '1.13.0 꺼진 칸 다시 설계' 절의 '셈을 지키는 규칙'(CLI 고정 · 사용량 관문 · 끊긴 스테이지 규칙 · 러너 규칙 · 쓰는 쪽 · 판정자 · 확인자 러너 · 얼릴 때 확인 입력 · 백업 규칙 · 피할 목록 짓기 · D26 도구 사본 · 모듈 나눔), '이름 목록', '주인 물음 (기본값)', '묶음마다 앞선 칸 재확인'도 이 절을 다스립니다.

- 잰 설계: 설계 파일 `impl113/design/G2.json`(sha256 `453ae101a498368f587fca6a20077817cc71be470a694481e492add2dd890e4d`), 시제품 패치 `impl113/design/G2/proto/G2-run-113-final.diff`(`38e10ad001db8ca9685466b6fc1e5d99e4218622e8c779e0be110f0b1671c92c`, 설계 파일의 prototypePatchSha256과 같음). 코드는 짓기 커밋 5c27746(위)입니다. 계획 `impl113/plan113.json`(`21b5421c401a1c3235dac21d1d238fd6690dacfd4e94266fb0512aca81e64912`)의 묶음 2(3/4)입니다. 이 커밋이 가리키는 코드 커밋은 5c27746입니다(입장 머리말의 '가리키는 코드 커밋 해시').
- 이 절의 기준 · 결정 규칙 · 모델마다 · 견본 · 부르기 · 위험 글은 설계의 bar · decisionRule · perModel · samples · calls · risks 필드와 계획 묶음 2(batches[1])의 barSource · samples · calls · judges · stop · preCallGate · switchCommit · usage 글을 한국어로 옮긴 것입니다. 수와 조항은 하나도 바꾸지 않았습니다. 설계의 입장(stance.text)은 처음부터 한국어라 글자 그대로 옮겼고, 설계 stance.how · stance.edits와 ownerQuestions도 아래에 옮기거나 원문으로 붙였습니다. 옮긴 글은 새 하위 에이전트가 설계 필드와 계획 글에 견주어 확인했습니다(아래 '옮김 확인').
- M-0 대응: G2의 상한 몫(기준에 들지 않고 기록; 그것 때문에 잃은 자리는 (가) 놓침) → M-5의 `output_tokens ≥ maxTokens + H_M`, '보정 기록 (1.13.0)'의 H_sonnet 2048. 이 퀴즈 9개는 모두 maxTokens 4600(QUIZ_TRACE_TOKENS)이라 sonnet의 상한 닿음은 `output_tokens ≥ 6648`입니다(그 기록의 '상한 닿음 줄' 표, 묶음 2 줄; 조건 (c): G2 sonnet은 H_sonnet과 상관없이 잼). 판정자는 꼬리표마다 둘(입장 14, M-8, D7)이고, 다시 보내기는 입장 2의 api-error 줄과 M-4 셋째 줄(10%)입니다(아래 '읽는 법' 1).
- M-6: G2의 기준에는 토큰 절댓값 줄이 없어(수와 비율뿐) 바꿀 것이 없습니다('보정 기록 (1.13.0)'의 M-6 표: G2 · G6 바꿀 것 없음).
- 수준: 견본은 beginner로 잽니다(켠 값도 beginner에서만 닿음, 1.10.0 계획 고침 D17).
- 잴 모델: sonnet 하나입니다. haiku는 1.12.0부터 켬(rungChangedStep 2)이고 바이트까지 그대로 두며 다시 재지 않습니다(계획 notMeasured.onNotReMeasured; 위 '1.13.0 설계만 하고 재지 않음'의 G2 haiku 칸). 그래서 이 절의 결정은 sonnet에만 쓰고, haiku에는 결정이 없습니다(B14 재확인만).
- 앞선 칸 재확인(D26): 묶음 2가 다시 확인할 칸은 isRuleWide haiku · isRuleWide sonnet · G2 rungChangedStep haiku입니다(isRuleDrill haiku는 묶음 1에서 끔으로 남아 해당 없음, 6a32a29). 짓기 커밋 전 작업 트리에서 돌렸고 다름 0이었습니다(5c27746 본문: `impl113/d26/rulewide113.mjs` 639경우 모든 견줌 다름 0; `impl113/d26/g2haiku.sh` (가) 9/9 · (나) build.json `0db255b4…` 같음 · (다) read.json `05aa93f5…a2f1` 같음, 진짜 플러그인 요청 14개 HEAD와 같음). 이 기준 커밋은 견본.md만 바꿉니다.
- 주인 물음(위 '주인 물음 (기본값)' 표의 8 · 9 · 10, 다른 답이 오지 않아 기본값): 8 — (a) r2를 1.13.0 설계로 보고 sonnet을 한 회 잽니다. 그 벗어남과 '플러그인이 대신 낸 바꿈은 놓침' 조항(18)을 이 커밋에 적습니다(아래 '밝혀 둔 벗어남' 1 · 3). 9 — 예: 평가기(newRun · newParse)를 G2 코드로 저장소에 넣었습니다(5c27746, `hooks/newrun.ts`). 10 — 아니오: 프롬프트는 그대로입니다.
  - 설계 ownerQuestions 원문(글자 그대로; 위 표의 8 · 9 · 10은 이 셋을 옮긴 것): 0. 비슷한 코드(G2) sonnet: 파일럿이 설계 글의 '일반 고침 하나' 규칙을 넘었습니다(파일럿이 부르기 전에 얼린 GO 파일은 '세 번까지'라고 적어 서로 어긋났음). 첫 설계(r0)와 고침 1(r1)은 못 넘었고, 고침 2(r2: 모델은 곳과 새 값만 고르고 답은 플러그인이 기기에서 돌린 결과)는 그 코드를 얼린 뒤 새로 쓴 세트 D와, 고치지 않고 따로 둔 세트 E에서만 판정했습니다. 네 번 모두 20/20(모델이 고른 값만 세면 19/20)이고 틀린 답 0입니다. (a) 기본값: r2를 1.13.0 설계로 보고, 이 어긋남과 '플러그인이 대신 낸 바꿈은 놓침' 조항을 기준 커밋에 적은 뒤 sonnet을 한 회 잽니다(새 보정, 새 블라인드 견본, 부르기 전 평가기 대조). (b) G1 · G3처럼 1.13.0에서는 짓지도 재지도 않고 다음 판으로 넘깁니다. / 1. ((a)일 때만) 기기에서 코드를 돌리는 평가기(G3 시제품의 newRun, 약 4,160줄)를 G3는 재지 않는데도 G2 sonnet을 위해 저장소에 넣을까요? 기본값: 예 — G3 시제품에서 그대로 옮기고, 값 여럿을 찍는 출력만 더합니다(끈 칸에서는 쓰이지 않음). 아니오면 G2 sonnet은 1.13.0에서 짓지도 재지도 않습니다. / 2. ((a)일 때만) 모델에게 '상황에서 말이 되는 값'을 고르라는 말을 더할까요? '수면 -4시간'처럼 맞지만 어색한 답이 줄 수 있습니다. 기본값: 아니오 — 프롬프트가 바뀌면 파일럿 수가 그 글을 덮지 못하고, 기준 커밋 전에 새 개발 세트로 거절 · 빈 답이 없음을 다시 보여야 합니다. 예면 그 확인을 한 번 하고, 거절 · 빈 답이 하나라도 나오면 지금 글로 잽니다.
- 계획과 SCOPE.md가 다른 곳: 없습니다. 계획 안의 두 글이 어긋나는 곳(견본이 모자란 언어의 처리)은 더 엄한 쪽을 따릅니다(아래 '읽는 법' 3). 계획이 SCOPE.md보다 엄한 곳(쓰는 쪽 짜임, 피할 목록, 부르기 전 관문, 회 수준 관문)은 계획을 따릅니다.
- 계획 기록과 다른 수 하나(기록): 계획 batches[1].prototypePatch.sha256 `5404650d…9a50`은 디스크의 어느 파일과도 맞지 않습니다. 디스크의 패치와 설계 파일의 값 `38e10ad0…c92c`를 썼고, 이것은 짓기 커밋 5c27746 본문과 1/4 첫 커밋 표에 적힌 값과 같습니다.

밝혀 둔 벗어남 (계획 barSource.declaredDeviations와 설계가 밝힌 것, 견본을 쓰기 전에 적음)
1. 파일럿이 설계 글의 '일반 고침 하나' 규칙을 넘었습니다(파일럿이 부르기 전에 얼린 GO 파일은 '세 번까지'라고 적어 서로 어긋났음). r2는 그 코드를 얼린 뒤 쓴 세트 D와 E에서만 판정했습니다(G2 주인 물음 0 = 위 표의 8, 기본값 (a)). 잴 회차 자체는 새롭고, 가리고, 미리 커밋한 것이라 그 결과는 이 벗어남에 기대지 않습니다(설계 risks의 '절차' 줄).
2. B13: 1.12.0 규칙 3의 '같은 얼린 견본' 대신 새로 가린 견본을 씁니다(가림에서 더 엄격함).
3. 조항 18(대신 낸 바꿈 = (가) 놓침)과 조항 19(견본이 모자란 자리 = (가) 놓침)는 더 엄격합니다.
4. 부르기 전 관문(PRE-CALL GATE)은 더 엄격합니다.
5. (계획 samples.layout이 이름과 수를 붙여 밝히라고 한 것) 쓰는 쪽 B는 채우는 것 세 종류(내 코드 · 왜 · 다시 도전)의 기록 7개를 한 번에 씁니다. 이것은 '부르기마다 견본 종류 하나'의 밝힌 예외 하나입니다(1.12.0 writer-B.md 글자 그대로; 1.12.0에서 거절 없이 돌았음; 7 ≤ 10).
6. (계획 samples.avoid가 밝히라고 한 것) 쓰는 쪽의 피할 절은 얼린 짓는 도구 `gen/avoid113.py`(calibration.avoidBuilder)의 출력입니다. 설계 개발 절차(design/G2/dev/gen/parts.py)가 쓴 avoid.py 절을 이것으로 바꿨습니다.

사용량 관문 (계획 usageGate; R과 그 이끌어 냄은 이 커밋 본문에도 적음)
- 묶음 예측 0.16 = 호출 1 × c_stage 0.01(퀴즈 sonnet 9번) + 하위 ≈ 14 × c_sub 0.04(쓰는 쪽 9 + 보탬 ≤ 2, 판정자 2, 번역 확인 1) + 에이전트 ≈ 11 × c_agent 0.11.
- 회 R(퀴즈 스테이지에서) = 0.01: G2 회차의 모델-스테이지는 퀴즈 sonnet 하나뿐입니다(계획 usageGate 둘째 항목: 'G2: the quiz stage alone'). 퀴즈 sonnet은 seven_day + 0.01 < 0.80일 때만 시작하고, 아니면 seven_day.resetsAt 바로 뒤에 시작합니다.
- 스테이지 관문: 퀴즈 sonnet은 five_hour ≤ 0.60 그리고 seven_day + 0.01 < 0.80 그리고 다른 워크플로가 돌지 않음(`tools/gate.py`, ONLY_WORKFLOW=1은 에이전트의 밝힘).
- 쓰는 쪽 · 판정자 · 확인자 러너(`gen/run.sh`)는 자기 관문(five_hour ≤ 0.60 그리고 seven_day + 그 스테이지 예측 < 0.80)을 가집니다: 견본 쓰는 쪽 9번 = 0.03, 보탬 하나 = 0.01, 판정자 둘 = 0.01, 번역 확인 하나 = 0.01. 쓰는 쪽 러너가 스테이지 앞뒤로 적은 seven_day의 잰 차이가 c_sub보다 크면 그 뒤 예측은 잰 값을 씁니다.

#### 기준

출처(설계 bar.source, 옮김): docs/qa/견본.md '1.12.0 비슷한 코드 (G2)' → '기준 · 입장 · 결정 규칙'(기준 커밋 5da364c, 코드 3f9084c를 가리킴). 그것은 1.10.0 기준(d684d90; 수는 1.8.0과 F4의 것)을 바꾸지 않고 다시 말하며, 두 모델 어느 쪽에도 마지막으로 커밋된 G2 기준입니다. 그 결정 규칙 3이 sonnet 회차를 덮습니다. G7의 M-0..M-15, B-1..B-15, R0..R11을 1.13.0으로 읽어 다스립니다. 더 너그러운 것은 없습니다.

설계 bar.lines(옮김, 번호는 설계의 것)
- B1 수는 마지막으로 커밋된 기준에서 바꾸지 않습니다. 더 너그러운 것은 없습니다.
- B2 단위: 퀴즈 9개의 비슷한 코드 20자리(잴 것 js 13 · py 7). 다른 문항(내 코드, 왜, 다시 도전)은 기록만 합니다.
- B3 (가) 20자리 가운데 16자리 이상이 입장 조항 7의 (ㄱ)–(ㅈ)을 모두 갖추고, 조항 16 · 17 · 18도 갖춤.
- B4 (나) 읽힌 문항 가운데 틀린 A 0개(조항 6 · 11 · 16). 저장된 답이 진짜 실행과 다르면 플러그인이 계산한 것이라도 틀림입니다.
- B5 모든 자리는 보인 코드를 보인 그대로 돌려 매깁니다: unshare -n timeout 5; node 두 번; python은 PYTHONHASHSEED 1..5로, 다섯 번이 모두 같아야 함; 채워 넣는 것 없음. 학습자의 출력은 파일 전체를 진짜로 돌린 것이고, 플러그인의 '지금 찍히는 글자'가 아닙니다.
- B6 빈 답, 시간 한도, 거절, 읽히지 않은 자리(changedRunItem: missing, grammar, other-slot, site, long)는 (가) 놓침이고, (나) 밖이며, 다시 보내지 않습니다. 다시 보내는 것은 api-error뿐이고 두 번까지입니다. 상한 닿음(output_tokens ≥ 4600 + H_sonnet, 1.13.0 보정에서)은 기록하고, 그것 때문에 잃은 자리는 (가) 놓침입니다. 빈 답은 한 번 탭으로 보내 stop_reason을 적습니다. (이 묶음의 기록, 원문 밖: '보정 기록 (1.13.0)'의 H_sonnet = 2048 → output_tokens ≥ 6648.)
- B7 꼬리표마다 판정자 둘, 어느 쪽도 다른 꼬리표를 보지 않습니다. 갈림이나 입장이 정하지 않은 경우는 기능에 불리하게 셉니다. 어느 답이든 연 뒤에는 조항을 더하거나 바꾸거나 다시 읽지 않습니다(M-11).
- B8 결정은 모델마다 그 모델의 수로만 합니다: (가) ≥ 16/20 그리고 (나) = 0일 때만 넘음. 넘으면 다음 커밋이 MODEL_SWITCHES.sonnet.rungChangedStep = 2와 isChangedRun = true를 함께 둡니다(R6; route SHIPPED; 진짜 플러그인 길로 R9 옛 빌드 확인 전체; R10 문서). 아니면 둘 다 끔 그대로입니다. RUNG_CHANGED_STEP과 IS_CHANGED_RUN은 끔 그대로입니다(D1). 모델 사이에 옮기지 않습니다(R1/R2).
- B9 (설계, sonnet)마다 한 회; 새 견본이나 고친 문장으로 다시 굴리지 않습니다. 못 넘으면 설계의 코드는 스위치 뒤에 남습니다(규칙 5). 규칙 6(sonnet): 다음은 모두 넓히기이고 새 회차가 필요합니다: rungChangedStep이 2인 채로 isChangedRun을 끔; isCertified를 느슨하게 함; 곳의 종류나 값을 더함(소수, 음수, numberBound를 넘는 값); printArgs를 넓힘(컨테이너, '%' 서식, 키워드, 값 4개 넘게); changeSites, isChangedShaped, CHANGED_UNSETTLED를 넓힘; 재는 도구에서 대신 낸 바꿈을 모델의 선택으로 받음; newRun/newParse를 어떻게든 고침. 좁히기는 새 회차가 필요 없습니다.
- B10 잰 것 = 켠 것(D33): 가린 채 쓴 개념 24개(20 + 예비 4), 모두 통째로 만든 파일, js 15 · py 9(잴 것 js 13 · py 7), 하나하나가 커밋된 rungOf로 sonnet 실행 길의 범위 안. 채우는 것: 내 코드 3(ts, js, py 고침), 왜 2, 다시 도전 2. 퀴즈 짜임 Q1–2 [c,c,c], Q3–5 [c,c,내 코드], Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; 단계 2와 3을 번갈아, 모두 때 됨; beginner; maxTokens 4600; timeoutMs 90000; effort low; QUIZ_SYSTEM; D34 9/9.
- B11 기준과 함께 커밋하는 입장 문장(모두 중립이거나 더 엄격함): 1(C를 읽고, N은 묻지도 읽지도 않으며, 답은 플러그인의 실행), 2(실행 길의 까닭들은 읽히지 않은 자리), 3(플러그인의 O는 판정에 쓰지 않음), 16(도구 결함이라는 핑계 없음), 17(커밋된 sonnet 길로만 닿은 rung), 18(대신 낸 문항은 (가) 놓침이지만 (나)에서는 매김), 19(견본이 모자란 자리는 (가) 놓침), 20(답 꼴).
- B12 회차 전에 설치된 CLI의 새 고정 사본으로 보정하고, 판과 별칭을 앞뒤로 적습니다. 다르면 회차는 무효이고 칸은 끔입니다(M-10, D19).
- B13 1.12.0 규칙 3('같은 얼린 견본')에서 벗어남, 미리 밝힘: 1.13.0은 위처럼 쓴 새로 가린 견본을 씁니다. haiku의 1.12.0 세트 답은 이미 열렸고(M-3, D8), 그 20개 파일 가운데 적어도 4개는 실행 범위 밖이기 때문입니다(D33). 가림에서 더 엄격하며, haiku는 다시 재지 않습니다.
- B14 규칙 5 / D26(넓힘): 모든 커밋 전에 haiku의 얼린 요청 · 고르기 · 읽기를 바이트까지 다시 확인합니다(lines-haiku.jsonl 876c8efd…, build.json 0db255b4…, read.json 05aa93f5…). 요청이나 고르기가 하나라도 다르면 그 묶음에서 haiku G2를 끕니다. sonnet이 켜지면 sonnet의 얼린 회차(그 요청, 고르기, 다시 읽은 문항)에도 같은 것이 걸리고, newRun/newParse를 어떻게든 고치면(예를 들어 G3가 들어올 때) 얼린 sonnet 견본과 넓은 코퍼스에서 부르기 전 대조 관문을 다시 넘어야 하며, 아니면 그 묶음에서 sonnet G2를 끕니다.
- B15 공통(G7을 1.13.0으로 읽음): M-1 두 모델에 같은 기준, 모델마다 셈; M-2 별칭 그대로, effort low(그대로), redactText, 4개씩, 부르기 전 D34; M-3 이 회차에서 haiku는 부르지 않으므로 sonnet만; M-4 빈 답과 시간 한도는 놓침이고 10% api-error 규칙이 걸림; M-5 상한 = maxTokens + H_sonnet(다시 잼); M-8 꼬리표와 봉인한 짝; M-10 판/id 앞뒤; M-11 정하지 못함 = 놓침; M-12 함께 쓰는 가린 견본, sonnet을 위해 쓰지 않음; M-13 haiku의 칸을 다시 확인(B14); R2 옮기지 않음; R4 다른 모델 글자, 별칭 바꿈, 읽을 수 없는 상태는 늘 끔; R5 결과 뒤 프롬프트 바꿈은 칸을 끄고, 읽기만 바꾸면 얼린 답을 다시 읽음.
- PRE-CALL GATE(부르기 전 관문; 새로, 더 엄격, 미리 밝힘): 얼린 뒤 어느 호출보다 먼저, samples.preCallGate의 대조 관문이 받아들인 다름 0을 내고, 엔진 런타임이 node와 같아야 합니다. 아니면 호출이 없고, 칸은 끔이며, 실패를 적습니다.

계획 묶음 2의 글(barSource.summary, 같은 기준): sonnet만: 넘음 ⇔ (가) 20 changed 자리 가운데 16자리 이상이 두 판정자 아래에서 조항 7 (ㄱ)–(ㅈ)과 16 · 17 · 18을 갖춤, 그리고 (나) 읽힌 문항의 틀린 A = 0(조항 6 · 11 · 16). 거절, 빈 답, 시간 끊김, 읽히지 않음, 대신 냄(isOwn false; 조항 18 — (나)에서는 매기지만 (가) 놓침), 모자람(조항 19), 갈림, 정하지 못한 자리는 (가) 놓침. 모든 자리는 보인 코드를 보인 그대로 돌려 매김. api-error만 두 번까지 다시 보냄; 상한 닿음 = output_tokens ≥ 4600 + H_sonnet(잃은 자리는 (가) 놓침). 계획 capNumbers: 퀴즈 상한 닿음 = output_tokens ≥ 4600 + H_sonnet, 보정 기록의 수로 → 6648.

1.12.0 기준과 다른 점(재기 전에 적는 까닭)
- 수(16/20, 틀림 0)와 단위(20자리, 9퀴즈)는 같습니다.
- 입장의 조항 1 · 2 · 3 · 13은 실행 길에 맞춰 고쳤고(중립이거나 더 엄격), 조항 16 · 17 · 18 · 19 · 20을 더했습니다(16 · 17 · 18 · 19 더 엄격, 20 중립). 경계 사례 목록을 r0–r2 개발 답의 모든 꼴로 넓혔습니다(설계 stance.edits, 아래 '판정의 입장').
- 견본은 1.12.0 규칙 3의 '같은 얼린 견본'이 아니라 새로 가린 견본입니다(B13, 더 엄격).
- 부르기 전 관문을 더했습니다(PRE-CALL GATE, 더 엄격).
- 상한 닿음의 H_M은 1.13.0 보정 기록의 값입니다(H_sonnet 2048, 1.12.0과 같은 수 6648). 이것은 설계가 바꾼 것이 아니라 커밋된 공통 입장(M-5: 판마다 다시 잼, M-10)이 주는 수입니다.
- 1.12.0의 sonnet 칸은 '재지 않음'이었습니다. 이 판에서 처음 잽니다(결정 규칙 3이 덮는 회차).

#### 판정의 입장

설계의 입장(stance.text) 글입니다. 머리말, 조항 0–20, 그리고 조항 15가 가리키는 '경계 사례' 목록을 설계 글자 그대로 옮겼습니다. 판정은 이 글자대로만 셉니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 '다시 잴 때'에 적습니다(M-11).

설계 stance.how(옮김): 아래가 판단의 입장 전체입니다(한국어, 기준과 함께 글자 그대로 커밋). 1.12.0 G2 입장(5da364c)의 조항 번호와 뜻을 그대로 두고: 조항 1 · 2 · 3 · 13 · 0은 실행 길에 맞춰 고쳤고, 조항 16–20을 더했으며, 경계 사례 목록을 r0–r2 개발 답의 모든 꼴로 넓혔습니다. 바뀐 것은 모두 중립이거나 더 엄격합니다. ⚙ 조항은 얼린 eval 도구가 진짜 node/python으로 세고, ✎ 조항(도구가 가르지 못하는 7 (ㅇ), 그리고 도구가 같음을 찾지 못할 때의 11)은 꼬리표마다 가린 판정자 둘이 셉니다. 입장이 정하지 않은 경우는 못 넘는 쪽으로 셉니다(M-11).

설계 stance.edits(옮김)
- 1: C가 읽는 모델 줄의 전부이고, N과 O는 묻지도 읽지도 않습니다; 답은 플러그인의 실행입니다(중립: 저장되는 것이 여전히 판정의 전부).
- 2: 읽히지 않은 까닭은 changedRunItem의 다섯입니다(중립; B6을 따름).
- 3: 플러그인의 '지금 찍히는 글자'는 쓰지 않습니다; 학습자의 출력은 진짜 실행입니다(더 엄격).
- 13: C의 other-slot과 lastWins(중립).
- 16(더 엄격), 17(더 엄격), 18(더 엄격), 19(더 엄격), 20(중립): 더함.
- 경계 사례: 1.12.0의 O/N 사례는 생기지 않는다고 적고, 1.13.0 개발 사례를 더했습니다(대신 낸 꼴들, 이상하지만 맞는 값, 개념에서 먼 바꿈, 값 여럿 찍기, -0과 긴 실수, C 문법의 변형들, 평가기와 진짜 실행의 어긋남, 걸음 한도, 모자람).

판정의 입장 (G2 sonnet, 1.13.0 G2-RUN 실행 길). 기준 · 결정 규칙 · 짜임 · 견본 쓰기 프롬프트와 함께, 견본을 쓰거나 부르기 전에 docs/qa/견본.md 새 절로 한 커밋에 넣습니다(UTC 시각, 가리키는 코드 커밋 해시). 매기는 쪽은 이 글의 조항만 따르고 판정마다 조항 번호를 적습니다. ⚙ 조항은 eval 도구(부르기 전에 sha256으로 얼림)가 세고, ✎ 조항만 매기는 하위 에이전트가 매깁니다. 1.12.0 G2 입장(5da364c)의 조항 0–15 번호와 뜻을 그대로 두고, 실행 길에서 달라지는 것은 그 조항 안에 '(1.13.0)'으로 적고 조항 16–20을 더했습니다. 바뀐 것은 모두 중립이거나 더 엄격합니다. 이 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 '다시 잴 때'에 적습니다(M-11).

0 셈의 단위: 비슷한 코드로 고른 20자리(퀴즈 9개, 견본 짜임의 잴 자리 js 13 · py 7). 같은 퀴즈의 내 코드 · 왜 · 다시 도전 문항은 셈 밖이고 기록만 합니다. (1.13.0) 짜임에서 채우지 못한 잴 자리(조항 19)도 20자리에 듭니다.

1 읽기 ⚙ (1.13.0): 플러그인처럼 fixEscapedTicks → 그 커밋의 parseQuiz로 읽어 저장될 문항(question · hint · answer · kind · rung)만 매깁니다. 실행 길의 자리(build 기록에서 그 고르기에 code.run이 있음)는 parseQuiz 안에서 changedRunItem이 읽습니다. 모델이 쓰는 것은 C 줄(고른 곳의 이름과 새 값)뿐이고, O · N은 묻지도 읽지도 않습니다. 저장된 답(answer)은 모델 글이 아니라 플러그인이 기기에서 바꾼 코드를 돌린 줄들입니다. C 줄, '지금 찍히는 글자', '바꿀 수 있는 곳' 목록과 날글은 저장되지 않으므로 판정 대상이 아닙니다(조항 18에서 자기 값인지 가릴 때만 도구가 isOwn으로 봄). 답에 N 줄이나 다른 줄이 더 있어도 읽지 않고 매기지 않습니다. 읽힌 문항은 그 번호 자리의 개념으로 플러그인이 짠 문항입니다.

2 답이 없는 자리 ⚙ (1.13.0): 빈 답(empty-reply · API 거절), 시간 한도(90초)에 끊긴 답, 읽히지 않은 자리, 플러그인의 읽기(changedRunItem)가 문항을 내지 않은 자리 — missing(C 없음) · grammar(C 머리가 '번호+글자' 꼴이 아님) · other-slot(번호가 자리와 다름) · site(목록에 없는 글자) · long(문제 글이 1200자를 넘음) — 는 (가)에서 놓침, (나)에서는 셈 밖입니다(학습자에게 보이지 않음). 상한에 닿았어도 읽힌 문항은 읽힌 그대로 매깁니다. 다시 보내는 것은 글이 하나도 없고 출력 토큰이 0인 api-error(상태 429 · 5xx)뿐이며 같은 프롬프트로 두 번까지, 모두 기록합니다. 그래도 실패하면 그 퀴즈의 자리는 모두 놓침입니다. 빈 답 · 시간 끊김 · 상한 닿음 · 읽기가 거른 자리는 다시 보내지 않습니다. 빈 답은 기록으로만 탭으로 한 번 더 보내 stop_reason과 stop_details.category를 적습니다.

3 돌리기 ⚙: 문제의 코드: question의 펜스 블록(플러그인이 넣은 하나)입니다. 언어는 펜스 이름(js · python)입니다. 빈 임시 폴더에서 `unshare -n timeout 5`로, 표준 입력을 비우고 돌립니다. js: `node 파일` 두 번. py: `env -i PATH="$PATH" LANG=C.UTF-8 PYTHONHASHSEED=<n> python3 -s -P -B 파일`을 n = 1..5로 다섯 번. 결과는 표준 출력의 줄들입니다(마지막 줄이 줄바꿈 없이 끝나도 한 줄). 끝 코드가 0이 아니면 그 앞까지의 출력 뒤에 마지막 예외의 이름(메시지는 뺌) 한 줄을 더합니다. 표준 오류는 결과에 넣지 않습니다. 돌린 결과가 서로 하나라도 다르거나 5초를 넘으면 그 문항은 (가) 놓침이고 A는 틀림입니다. 학습자 결과: 견본을 얼리기 전 확인 때 학습자 파일 전체(= 바꾸기 전의 보인 코드)를 같은 규칙으로 돌려 얼린 줄들입니다. (1.13.0) 플러그인이 요청에 보인 '지금 찍히는 글자'(기기의 평가기가 낸 것)는 판정에 쓰지 않습니다. 학습자 결과와 문제 코드의 결과는 늘 이 조항으로 진짜 돌린 것입니다. 도구 판(node · python · Claude Code)을 적습니다.

4 채우지 않음: 블록에 없는 정의 · import · 입력 · 파일 · 준비를 덧붙이지 않습니다. 나는 오류도 결과입니다. (이 설계의 문제 코드는 학습자 파일 전체라 채울 것이 생기지 않지만 규칙은 그대로 둡니다.) "글로 말한 바꿈"은 쓰이지 않습니다(바꿈은 플러그인이 코드에 넣음).

5 물은 것 ⚙: 문제 글은 플러그인의 고정 글(CHANGED_LEAD)이고 "이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름"을 묻습니다. 그래서 물은 것은 언제나 결과 전체(오류로 멈추면 그 앞 출력과 오류 이름)입니다. 매기는 쪽이 Q만 보고 물은 것을 정하는 단계는 쓰이지 않습니다. question이 이 글로 시작하지 않으면 10에서 놓침이고, (나)는 결과 전체와 견줍니다.

6 표기 맞춤 ⚙: 1.10.0 조항 6을 글자 그대로 씁니다(A와 결과, 결과끼리 견줄 때 모두). 줄마다 앞뒤 공백을 지우고, 이어진 공백은 하나로, 글자 · 숫자(한글 포함)가 아닌 문자 바로 옆의 공백은 지웁니다. 따옴표 종류는 가리지 않습니다. 결과 줄이 따옴표로 시작하고 끝나지 않을 때만 A 줄 전체를 감싼 따옴표 · 백틱을 뗍니다. js에서 결과 줄에 따옴표로 감싼 객체 키가 없을 때만 A의 `"a":` · `'a':`를 `a:`로 봅니다(py는 그대로). 줄 끝 마침표 하나와 true · false · none · null · undefined · nan의 대소문자는 보지 않습니다. 결과 끝의 빈 줄은 견주지 않고, 가운데 빈 줄은 A의 빈 줄이나 '(빈 줄)'과 같습니다. 결과가 여러 줄이고 A가 한 줄이면 결과 줄들을 ', ' · ' ' · '과 ' · '와 ' · ' 그리고 ' · ' → ' 가운데 하나로 이어 맞춘 것이 A와 같으면 같음입니다. 그 밖의 글자 · 값 · 차례 · 줄 수 · 괄호 · 숫자 표기 · 대소문자는 그대로 견줍니다. 앞 공백만 다른 줄(padStart · ljust · rjust)은 이 규칙으로 같음입니다(1.10.0과 같음, 바꾸지 않음).

7 (가) 코드 다름 · 답 다름: 아래를 모두 갖춘 자리만 넘음으로 셉니다. (ㄱ) ⚙ 읽힌 문항의 rung이 changed. (ㄴ) ⚙ 코드를 바꿨음: 3의 문제 코드가 학습자 조각(= 파일 전체)과 6의 맞춤과 줄 끝 `;` · 주석 뺌 뒤 줄 단위로 (i) 같지 않고 (ii) 찍는 줄(한 줄짜리 console.log(…) · print(…))을 뺀 나머지 줄이 학습자 줄들의 부분열이 아님. (ㄷ) ⚙ 그 개념의 코드에서 왔음: 학습자 조각의 핵심 줄(토큰 4개 이상, 괄호뿐 · else · `return 이름` · 이름 하나만 찍는 줄이 아님; 없으면 토큰 2개 이상) 가운데 하나 이상이 보인 코드의 어느 줄과 토큰이 같거나 하나만 다름(codeAsRead 토큰). (ㄹ) ⚙ 정의 빠짐이 아님: 결과가 ReferenceError/NameError로 끝나고 그 이름이 블록 안에서 한 번도 선언 · 대입 · 매개변수 · for 변수 · catch 변수로 나오지 않으면 놓침(TDZ · UnboundLocalError는 들지 않음). (ㅁ) ⚙ kind가 predict. (ㅂ) ⚙ 펜스 블록이 하나. (ㅅ) ⚙ 답이 다름(8). (ㅇ) ⚙/✎ 문제 글이 맞음(10). (ㅈ) ⚙ 3의 여러 번 돌린 결과가 모두 같고 5초 안. (1.13.0) 더하여 조항 16 · 17 · 18도 (가)의 조건입니다.

8 답 다름 ⚙: 학습자 결과: 3의 얼린 학습자 결과(진짜 돌린 것). 조각 결과: 1.10.0 조항 8의 정의 그대로이고, 이 설계의 조각은 파일 전체이므로(isWholeShown) 조각 결과는 학습자 결과와 같습니다. 견줄 것은 물은 것(5: 결과 전체)입니다. 6으로 맞춘 뒤 아래 가운데 하나면 같음(놓침): (a) 결과 전체가 학습자 결과 전체와 같음. (b) 결과 줄들이 차례 그대로 학습자 결과 안에 이어진 줄들로 있음(어디서 시작해도; 한 줄이면 학습자 결과의 어느 줄과 같아도). (c) 결과 줄마다 학습자 결과의 같은 순번 줄과 같음. (d) · (e)는 물은 것이 언제나 결과 전체라 쓰이지 않습니다. 결과가 오류 이름으로 끝나면 그 줄은 학습자 결과의 어느 줄과도 다릅니다. 결과가 오류 이름 한 줄뿐이면 다름입니다.

9 예측이 아닌 문항: 쓰이지 않음: 플러그인이 kind를 predict로 씁니다. 도구 결함으로 다른 kind가 저장되면 7(ㅁ) 놓침, (나)는 11로 매깁니다.

10 문제 글 ⚙: lead와 hint는 플러그인이 쓴 고정 글이지만 모델 글처럼 매깁니다. (ㅇ)를 갖추려면 모두: (i) question이 CHANGED_LEAD 글 그대로로 시작하고 그 뒤에 펜스 블록 하나만 있음; (ii) 보인 코드와 학습자 코드가 정확히 한 줄에서만 다름("한 곳을 바꿨습니다"가 참); (iii) hint의 "k번째 줄"이 그 다른 줄의 번호(보인 블록의 첫 줄을 1로, 빈 줄 포함)와 같음; (iv) hint가 줄을 따왔으면 따온 글이 그 줄의 앞뒤 공백을 뺀 것과 글자 그대로 같음(60자를 넘는 줄은 따오지 않으며 그때는 (iii)만 봄). hint는 바뀐 줄을 알려 줄 뿐 결과를 말하지 않으므로 답을 미리 말한 것으로 보지 않습니다. 하나라도 어긋나면 (가) 놓침입니다.

11 (나) A 맞음: ⚙ 먼저 도구가 A 전체를 6으로 맞춰 3의 결과 전체와 같은지 봅니다. 같으면 맞음. ✎ 아니면 매기는 쪽이 봅니다: A가 결과의 줄을 모두 차례대로 말하고(6의 "그대로 견주는 것"으로) 다른 틀린 말이 없으면 맞음. 틀림: 결과 가운데 일부만 쓴 A, 줄여 쓴 A(… · 등 · 생략), 오류로 멈추는 결과에 출력만 쓴 A, 오류 이름을 다르게 댄 A, 둘 이상을 답으로 내놓은 A, 학습자 원래 코드의 답을 쓴 A, 줄 수가 다른 A. (1.13.0) 실행 길의 A는 플러그인이 돌린 줄들이므로 결과와 다르면 조항 16으로 틀림이고, 도구가 같다고 보지 못한 A는 매기는 쪽이 이 조항의 맞음 꼴인지 봅니다.

12 ts: 쓰이지 않음: ts는 범위 밖이고(RUNG_CHANGED_EXTS = js, py) 견본에 넣지 않습니다. 도구 결함으로 ts 문항이 저장되면 (가) 놓침, (나)는 3으로 돌린 결과와 견줍니다.

13 번호가 엇갈린 답 ⚙ (1.13.0): parseQuiz가 짝지은 번호대로 매깁니다. changedRunItem은 그 번호 자리 개념의 코드와 그 자리의 목록으로만 문항을 짜고, C의 번호가 자리 번호와 다르면 문항을 내지 않으므로(other-slot), 엇갈린 답은 읽히지 않은 자리(2)로만 셉니다. C를 다시 쓴 답은 플러그인처럼 마지막 글로 읽습니다(quizParts lastWins).

14 매기는 차례와 갈림: 꼬리표마다 매기는 하위 에이전트 둘이 따로 매깁니다. 둘 다 설계 · 견본 쓰기 · 부르기에 끼지 않은 새 하위 에이전트이고, 이 글과 도구가 낸 파일만 봅니다(모델 이름, 토큰, 시간은 빠짐; 도구가 낸 판정 칸은 ⚙ 조항의 결과로만 보이고 ✎ 조항의 답을 미리 적지 않음). 두 판정이 갈린 문항과 이 글이 가르지 못하는 경우는 기능에 불리한 쪽((가) 놓침, (나) 틀림)으로 셉니다. 재는 세션은 판정을 바꾸지 않고, 출력을 본 뒤 조항을 더하거나 고치거나 다시 읽지 않습니다. 고칠 것은 '다시 잴 때'에 적기만 합니다. 짝 파일은 sha256만 적어 봉하고, 짝을 알리는 파일 이름이나 칸을 짝을 열기 전에 두지 않습니다.

15 미리 가른 경계 사례: 아래 '경계 사례' 목록(1.10.0 · 1.12.0 기록과 1.13.0 개발 견본에서 나온 것)을 따릅니다.

16 (1.13.0, 더 엄격) 플러그인이 낸 답도 똑같이 매김: 실행 길의 저장된 A가 3의 진짜 결과와 6으로 같지 않으면 (나) 틀림이고 그 자리는 (가)에서도 놓침입니다. 평가기(newRun) 결함, node · python 판 차이, '도구 결함' 어느 까닭으로도 면하지 않습니다.

17 (1.13.0, 더 엄격) 고르기 길: 잴 자리마다 문항이 커밋된 트리의 rungOf(sonnet 줄에 rungChangedStep 2 · isChangedRun 켬)로 'changed'에 닿고 code.run이 있는 고르기에서 changedRunItem으로 만들어진 것이어야 합니다. 그 길 밖에서 만들어진 문항(예: 1.12.0의 C · O · N 길로 읽힌 문항)이 저장되면 (가) 놓침이고 (나)는 그대로 매깁니다. 도구가 얼린 build 기록으로 셉니다.

18 (1.13.0, 더 엄격) 모델이 고른 바꿈: 저장된 문항의 바꾼 줄이 모델의 C가 말한 곳에 C가 말한 값을 넣은 것이어야 (가)를 갖춥니다. 모델 값이 값으로 읽히지 않거나(소수 · 음수 · 범위 밖 숫자 · 목록에 없는 대안 · 값 뒤의 다른 글), 바꾼 코드를 평가기가 돌리지 못했거나(오류 · 한도 · 묶음 출력), 바꾼 뒤 결과가 학습자 결과와 같거나 묻지 못할 꼴이라 플러그인이 그곳의 미리 확인한 바꿈으로 대신 냈으면(changedRunItem의 isOwn이 false), 그 자리는 (가) 놓침이고, 저장된 문항이므로 (나)에서는 매깁니다. 도구가 같은 커밋의 changedRunItem이 낸 isOwn으로 셉니다.

19 (1.13.0, 더 엄격) 견본이 모자란 자리: 견본 짜임의 잴 자리(js 13 · py 7)를 커밋된 rungOf로 'changed'에 닿는 기록으로 채우지 못한 자리(미리 정한 보탬 한 번 뒤에도 모자람)는 (가) 놓침이고 (나) 밖입니다. 다른 언어의 기록으로 채우지 않습니다.

20 (1.13.0, 중립) 실행 길의 답 꼴: 저장된 A는 플러그인이 돌린 줄들(1–4줄, 줄마다 160자 이하, 빈 줄 없음)을 줄바꿈으로 이은 것이고 오류 이름으로 끝나지 않습니다(오류로 멈추는 바꿈은 목록에 오르지 않고, 모델 값이 오류로 멈추면 대신 냄 → 18). CHANGED_LEAD의 '오류로 멈추면 …' 글은 이 길에서 쓰일 일이 없지만 문항 글의 일부로 10 (i)에 그대로 듭니다.

경계 사례
- 1.10.0 기록(그대로): W10 부모 클래스가 블록에 없음 → 7(ㄹ)(이 범위에서는 생기지 않음). 줄인 출력 → 11 틀림. 되돌리기 · 바꿔 보기 · 왜 → 9(쓰이지 않음). Q가 지금 출력을 틀리게 말함 → 10. Object.freeze A length 1 vs TypeError → 11 틀림. 빈 답 · 상한에 잘린 끝 → 2. 그대로 보임 · 몇 줄만 떼어 보임 → 7(ㄴ). 1.8.0 ===/== 출력 그대로 → 8 같음. node `[ 1, 2, 3, [ 4 ] ]` vs A `[1, 2, 3, [4]]` → 6 같음(이 길에서는 묶음을 찍는 파일이 범위 밖). 산문 A → 11. pythonista[7:]를 ista로 → 11 틀림. 두 블록으로 보임 → 7(ㅂ). 두 번 돌린 결과가 다름 → 3. 끝에 빈 줄을 찍음 → 6 견주지 않음. `1 2`와 `12` → 6 다름. JSON.stringify의 `{"a":1}`을 `{a:1}`로 쓴 A → 6 다름.
- 1.12.0 기록(1.13.0에서 읽는 법): O · N을 다시 썼거나 O가 틀리고 N이 맞은 자리 · 'subset' · 'echo' · 'value' · 'same' · 'count' · 'N-lines'로 걸러진 자리 → 이 길에는 O · N이 없어 생기지 않음(1). for-else · continue · sum · min에서 결과가 학습자 결과의 앞 줄 · 가운데 줄이 됨 → 8(b) 같음(이 길에서는 그런 바꿈이 목록에 오르지 않고, 모델 값이 그렇게 되면 대신 냄 → 18 놓침). grade()의 흐름을 잘못 따름 · 반복의 마지막 줄만 씀 · repeat(-1) 앞에 찍힌 줄을 씀 · JSON 길이를 잘못 셈(모두 1.12.0 개발의 모델 N 틀림) → 이 길의 A는 모델 글이 아니라 생기지 않음; 생기면 16 틀림.
- A 줄 끝 마침표(`true.`) · 대소문자(`TRUE`/`True` in js) → 6: 마침표 하나와 true/false 대소문자는 보지 않음. py `<class 'bool'>`, js typeof의 `number` → 결과 그대로; 6으로 견줌. 실수 표기(0.30000000000000004, 9240.0) → 6 그대로. 앞 공백만 다른 줄 → 6 같음. 가운데 빈 줄 → 이 길의 A에는 빈 줄이 없음(20); 결과에 빈 줄이 있으면 줄 수가 달라 11 · 16 틀림.
- (dev 1.13.0) 모델 값이 출력을 바꾸지 못함(맵 경계 `x < 0`을 `<=`로 — 데이터에 0이 없음; 배터리 `< 20`을 `<=`로; 과반수 `/ 2`의 2를 3으로) → 플러그인이 그곳의 미리 확인한 바꿈으로 대신 냄 → 18 (가) 놓침, 저장된 문항은 (나)로 매김.
- (dev 1.13.0) 숫자 자리에 소수(85.5) · 음수(-5) · numberBound를 넘는 수(401) · 원래 값(80) · 값 없음(`1e`, `1e: `) → 대신 냄(isOwn false) → 18 놓침.
- (dev 1.13.0) 값이 상황에 맞지 않지만 맞게 돈 답('월요일 수면 -4시간', '9시 30분 -15.0도', '빠진 번호: 6.5', 기준표 [(70,"A"),(80,"B"),(70,"C")]의 '예린 A') → B-10: 문제 글의 다른 흠은 기록만; 3 · 6 · 11로 매겨 결과와 같으면 맞음 · 넘음.
- (dev 1.13.0) 바꾼 곳이 개념 줄(blurb가 따온 줄)에서 먼 데이터 값(삼각형 넓이의 base 6 → 10, 정원 초과의 72 → 150) → 7(ㄷ)는 보인 코드가 학습자 파일 전체라 갖춤; 개념과 먼 바꿈은 B-10 기록만(개발 sonnet D 9/40 · E 14/40만 개념 줄에 닿음, haiku도 비슷함).
- (dev 1.13.0) console.log · print에 값 여럿(`console.log('합계:', total)` → `합계: 176`, `print("x", 1.0, True, None)` → `x 1.0 True None`) → 결과 그대로; A도 플러그인이 같은 꼴로 냄; 6으로 견줌. 첫 인자가 `%`를 품은 console.log와 키워드 인자 print는 평가기가 돌리지 않아 범위 밖.
- (dev 1.13.0) js `-0`, py `-0.0`, 긴 실수(`3168.3168316831684`), py 정수 나눗셈의 `.0` → 결과 그대로(6은 숫자 표기를 그대로 견줌); 다르면 16 틀림.
- (dev 1.13.0) C 머리를 백틱으로 감쌈(`` `1d` < ``) · 이름 뒤에 쌍점 · 화살표(`1d: <`, `1d → <`) → 읽기 그대로(grammar 통과). C 머리가 글자 둘(`1dd`) · 번호 없음(`d <`) · 목록 밖 글자(`1g`) → 2 읽히지 않음(grammar). 번호가 다름 → 13(other-slot).
- (dev 1.13.0) 문자열 자리의 값을 따옴표 없이 · 다른 따옴표로 씀 → siteValue가 읽으면 그 값, 못 읽으면 대신 냄 → 18로 기계가 셈(isOwn).
- (dev 1.13.0) 한 줄에 같은 토큰이 둘(`두 번째 0`) → 목록이 순번으로 가리키고 플러그인이 그 자리만 바꿈 → 10 (ii)로 정확히 한 줄 다름을 봄.
- (dev 1.13.0) 답 끝에 N 줄 · 설명을 덧붙임 → 1: 읽지 않음, 저장된 문항만 매김.
- (1.13.0) 플러그인의 '지금 찍히는 글자'가 진짜 학습자 결과와 다름(평가기 결함) → 3: 판정은 진짜 결과로만; 8도 진짜 학습자 결과와 견줌; 저장된 A가 진짜 결과와 다르면 16 틀림; 평가기 결함은 '다시 잴 때'에 적음.
- (1.13.0) 바꾼 코드의 진짜 실행이 5초를 넘음 → 3: (가) 놓침 · A 틀림(평가기는 20,000걸음을 넘으면 돌리지 않으므로 생기면 16과 함께 적음).
- (1.13.0) 결과가 다섯 줄 이상 · 160자 넘는 줄 · 빈 줄이 되는 모델 값 → 플러그인이 대신 냄 → 18 놓침.
- (1.13.0) 견본 쓰기에서 한 언어가 보탬 한 번 뒤에도 모자람 → 19: 그 잴 자리는 (가) 놓침, 다른 언어로 채우지 않음.

#### 결정 규칙

설계 decisionRule(옮김)
1. sonnet만, sonnet의 수로만(R1–R4). (가) = 잰 비슷한 코드 20자리 가운데 저장된 문항이 두 판정자 아래에서 조항 7 (ㄱ)–(ㅈ)과 조항 16 · 17 · 18을 갖춘 자리의 수. 거절, 빈 답, 시간 끊김, 읽히지 않음, 대신 냄(isOwn false), 모자람, 갈림, 정하지 못한 자리는 놓침. (나) = 읽힌 문항 가운데 A가 틀린 문항의 수(조항 6 · 11 · 16; 갈림이나 정하지 못함 = 틀림).
2. 부르기 전 관문이 실패하거나, 보정이나 앞뒤 기록이 맞지 않으면: 회차 없음, sonnet은 끔 그대로.
3. 넘음 ⇔ (가) ≥ 16 그리고 (나) = 0. 넘으면 다음 커밋이 MODEL_SWITCHES.sonnet을 `{ ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2, isChangedRun: true }`로 둡니다(R6, SHIPPED 다시 고정, 진짜 플러그인 길로 R9 옛 빌드 확인, R10 문서, haiku의 D26 다시 확인). 아니면 sonnet은 `{ ...SWITCHES_OFF, isRuleWide: true }` 그대로입니다.
4. haiku: 결정 없음. 그 칸은 B14 다시 확인이 요청 · 고르기 · 읽기가 바이트까지 같다고 보이는 동안만 켬(rungChangedStep 2, isChangedRun false) 그대로이고, 아니면 그 묶음에서 끔입니다(규칙 5 / D26). 어느 쪽으로도 옮기지 않습니다.
5. 한 회; 다시 굴리지 않음; 뒤의 넓히기(B9)는 새 회차가 필요하고, 좁히기는 필요 없습니다.

계획 묶음 2의 글(barSource.decision, 같은 규칙): MODEL_SWITCHES.sonnet = `{ ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2, isChangedRun: true }` ⇔ 넘음; 아니면 `{ ...SWITCHES_OFF, isRuleWide: true }`. haiku: 결정 없음(B14만). RUNG_CHANGED_STEP과 IS_CHANGED_RUN은 끔 그대로(D1). 한 회; B9 넓히기는 새 회차가 필요함.
- 판정자(계획 judges): sonnet 꼬리표에 가린 opus 판정자 둘, 어느 쪽도 다른 꼬리표를 보지 않음; 갈림이나 정하지 못한 경우는 기능에 불리하게 셈(B7). 기계: 진짜 돌리는 쪽이 모든 자리를 매기고(B5), 얼린 셈 스크립트가 셈.
- 값 커밋(계획 switchCommit, 넘을 때만): MODEL_SWITCHES.sonnet = `{ ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2, isChangedRun: true }`; route SHIPPED; 켠 값으로 진짜 플러그인 길을 거친 R9 옛 빌드 확인(일곱 빌드); 켠 퀴즈마다 recheckRemap; 켠 값에서 돌연변이 탐침 2개 이상; 잰 프롬프트를 다시 만들어 바이트까지 같음; G2 haiku의 D26(9/9, build.json, read.json), isRuleWide, 켰다면 isRuleDrill haiku; B14를 위해 평가기 블록의 sha256을 적음.
- 멈춤(계획 stop)
  - 짓기 트리에서 G2 haiku의 요청이나 고르기 다름을 없앨 수 없음 → 짓기 커밋 없음; 멈추고 알림. (이 묶음의 기록, 원문 밖: 짓기에서 다름 0, 5c27746 본문.)
  - 부르기 전 관문 실패 → 호출 없음, sonnet 끔(적음).
  - 회차 무효(M-10) 또는 M-4 → sonnet 끔, 다시 재지 않음.
  - 쓰는 쪽이 한 부르기에서 두 번 거절함(commonPerBatch.writerRunner가 정한 거절; 사용량 한도로 끝난 것은 WAIT) → STOP, 재지 않음(적음).
  - 읽힌 문항 가운데 틀린 A가 하나라도 있으면 회차는 못 넘음(멈추지 않음; 적음).

#### 모델마다 (설계 perModel; 개발 수는 기록만 · B-12, 결정에 들지 않음)

- haiku: 켬(1.12.0 잼 18/20, 틀림 0; rungChangedStep 2). 이 설계는 haiku를 건드리지 않습니다. 마지막 트리는 D26 증명 셋을 모두 지킵니다: 얼린 요청 9개를 바이트까지 다시 냄(D34 9/9, lines-haiku.jsonl 876c8efd…), build.json 같음, 얼린 답을 다시 읽은 read.json 05aa93f5… 같음(proofs/final). 모델 · 수준 · 언어에 걸친 진짜 플러그인 요청 14개가 HEAD와 파일럿 트리에서 같습니다(crit/bytes). 재지 않고, 아무것도 옮기지 않습니다. haiku 개발 대조군(기록만)은 20 가운데 18, 18, 20, 17, 18이고 91개에서 틀림 0이었습니다.
- sonnet: 잼(한 회). 마지막 개발 세트 D와 E(기록만, r2를 얼린 뒤 씀): 네 번 모두 20/20 남음, 조항 18로는 19/20(번마다 대신 냄 하나), 읽힌 문항 80개에서 틀림 0, 거절 0, 빈 답 0, 잘림 0, 시간 한도 0, 상한 닿음 0, 가장 큰 출력 545 토큰.
- 계획 notMeasured(옮김): haiku: 1.12.0부터 켬, 바이트까지 그대로 두고 다시 재지 않음(notMeasured.onNotReMeasured).

#### 견본

설계 samples 글(옮김)
- 쓰는 쪽(whoWrites): 새로 가린 opus 하위 에이전트(`claude -p --model opus --tools ''`, DISABLE_AUTOUPDATER=1, cwd는 빈 폴더). 이 설계, 프롬프트, 입장, 범위, 어느 모델을 재는지를 보지 않습니다. 1.12.0 G2의 잰 쓰는 쪽 프롬프트(impl112/b2/gen/writer-A.md, writer-B.md와 *-end.md 파일)를 글자 그대로 쓰되, 다음만 다릅니다: 부분마다의 기록 수, id, 언어(부르기마다 기록 10개 이하, G3 STOP 교훈); 그 부분에 맞춰 줄인 섞임 최소; 그리고 이름만 든 피할 절. 이것이 개발 parts.py 절차(dev/gen/parts.py)이고, 기준 커밋에 sha256으로 얼립니다. 견본은 sonnet을 위해 쓰거나 고르지 않습니다(M-12).
- 짜임(layout): 먼저 쓰는 쓰는 쪽 부분: A1–A5, 각 js 10(js 50); P1–P3, 각 py 10(py 30); B, 1.12.0과 같은 채우는 것(내 코드 3 = ts, js, py 고침; 왜 2; 다시 도전 2). 모자란 언어마다 미리 정한 보탬 한 번(T1 js 10, T2 py 10), 그다음 STOP. 첫 몫이 파일럿(js 25, py 15)보다 큰 것은 개발 세트 하나(B)가 잴 js 자리 13에 js 구성원 11로 끝났기 때문입니다. 개발 닿음(js 44.5%, py 52.6%)으로 보면, 한 언어가 보탬 뒤에도 모자랄 확률은 1% 아래입니다.
- 구성원(membership): 구성원은 커밋된 트리의 sonnet 길 rungOf(sonnet 줄 + rungChangedStep 2 + isChangedRun true, withCode/changedRunFor를 거침)로만, 쓴 차례대로 정합니다. 처음 드는 js 15와 py 9를 가집니다(잴 js 13 · py 7과 언어마다 예비 2, 1.12.0 짜임). 보탬 뒤에도 채우지 못한 잴 자리는 (가) 놓침(조항 19)이고, 다른 언어의 기록으로 채우지 않습니다. haiku 견본과 haiku의 범위는 바뀌지 않습니다.
- 퀴즈 짜임(quizLayout): 1.12.0 짜임 그대로: Q1–2 [c,c,c], Q3–5 [c,c,내 코드], Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; 단계 2와 3을 번갈아; 모든 개념 때 됨; 수준 beginner.
- 얼림(freeze): chmod 444; sha256, 쓴 쪽, UTC 시각을 견본.md에 적음. D34: 시험 하네스에서 models.sonnet { rungChangedStep: 2, isChangedRun: true }로 잡은 요청 9/9가 어느 호출보다 먼저 도구의 프롬프트 파일과 바이트까지 같아야 함.
- 부르기 전 관문(preCallGate): 기준에 적고, 얼린 뒤 어느 호출보다 먼저 돌립니다. 얼린 잴 기록과 예비 기록 하나하나를, 모든 곳(changeSites isAll)과 얼린 final/wide/gen.mjs 목록의 모든 값(숫자는 runValues의 넷, 0–5, 10, n/2, n+5, n+10, 10n과 상한; 따옴표가 같은 다른 모든 문자열; 목록에 든 모든 대안)으로, 커밋된 평가기와 진짜 돌리는 쪽(B5)이 돌립니다. 요구: 받아들인 다름 0, 같은 프로그램에서 엔진 런타임이 node와 같음(claude plugin test 고정물), 학습자 실행이 모두 out과 같음. 다름이 하나라도 있으면 호출 전에 회차를 멈춥니다. 칸은 끔이고, 실패를 적으며, newRun을 고쳐 1.13.0에서 다시 시도하지 않습니다(newRun을 고치면 새 설계).
- 피할 것(avoid): 이름만, 견본.md 산문은 넣지 않고 모델 · 별칭 · 스위치 낱말도 넣지 않음: impl113/NAMES-all.txt의 모든 이름(9,066줄; 아래 G2-dev-113 이름 285개, impl112 G2 개발 이름 133개, 1.12.0 G2 잰 이름, G3-dev-113 이름 포함)과 docs/qa/견본.md의 기록 이름 칸. 새 잰 이름은 impl113/NAMES-all.txt에 'G2-measured-113' 꼬리표로 들어갑니다. (이 묶음의 기록, 원문 밖: 설계 때 9,066줄이던 NAMES-all.txt는 묶음 1의 덧붙임 뒤 지금 10,674줄, sha256 `aca62354e1ff48b4dc03fef16cfe7a07fe1788939bda094be6800ac2dfc0fdb3`입니다. 설계 samples.devNamesToAvoid의 285개는 그 안에 꼬리표 'G2-dev-113'으로 들어 있습니다.)

계획 묶음 2의 글(samples, 같은 짜임)
- 짜임: 쓰는 쪽 부분 A1–A5 각 js 10(js 50), P1–P3 각 py 10(py 30), B는 1.12.0과 같은 채우는 것(내 코드 3 = ts, js, py 고침; 왜 2; 다시 도전 2)을 세 가지 채우는 것 종류의 기록 7개로 한 번에. 그 부르기는 '부르기마다 견본 종류 하나'의 밝힌 예외입니다(1.12.0 writer-B.md 글자 그대로; 1.12.0에서 거절 없이 돌았음; 7 ≤ 10)이고, 기준 커밋에 그 수와 함께 이름을 적습니다(위 '밝혀 둔 벗어남' 5). 쓰는 쪽 부르기 9번, 각 기록 10개 이하; 모자란 언어마다 미리 정한 보탬 한 번(T1 js 10, T2 py 10), 그다음 STOP. 쓰는 쪽 프롬프트 = impl112/b2/gen/writer-A.md, writer-B.md, *-end.md를 글자 그대로, 부분마다의 기록 수 · id · 언어, 줄인 섞임 최소, 이름만 든 피할 절만 다름(dev/gen/parts.py 절차, 기준 커밋에 sha256으로 얼림).
- 구성원: 커밋된 트리의 sonnet 길 rungOf(sonnet 줄 + rungChangedStep 2 + isChangedRun true, withCode/changedRunFor를 거침)로만, 쓴 차례대로: 처음 드는 js 15와 py 9(잴 js 13 · py 7 + 언어마다 예비 2). 보탬 뒤에도 채우지 못한 잴 자리는 (가) 놓침(조항 19); 다른 언어로 채우지 않음.
- 퀴즈 짜임: Q1–2 [c,c,c], Q3–5 [c,c,내 코드], Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; 단계 2와 3을 번갈아; 모든 개념 때 됨; beginner.
- 얼림: chmod 444; sha256, 쓴 쪽, UTC를 견본.md에; 이름을 NAMES-all.txt에 'G2-measured-113' 꼬리표로 덧붙임; 그다음 부르기 전 관문; 그다음 어느 호출보다 먼저 D34 9/9(하네스 models.sonnet { rungChangedStep: 2, isChangedRun: true }).
- 피할 것: NAMES-all.txt(G2-dev-113 285개, G2-dev, G2-measured, G3-dev-113, G3-dev-retry 포함)에서 짓는 avoid113.py 출력(calibration.avoidBuilder): 이름만, 짓는 도구가 밝힌 대로 거름. 이것은 design/G2/dev/gen/parts.py가 만든 피할 절을 바꾸며, 기준 커밋이 그 바꿈을 밝힙니다(위 '밝혀 둔 벗어남' 6). check.py(NAMESALL = impl113/NAMES-all.txt)는 온전한 이름 목록과 넓힌 코퍼스(commonPerBatch.freezeCheckInputs)에 견주어 기록을 거절합니다.

피할 목록 짓기(calibration.avoidBuilder의 거름, 짓는 도구가 하는 그대로 옮김; `gen/avoid113.py`는 `impl113/gen/avoid113.py`와 바이트까지 같은 사본)
- (a) 개념 이름은 꼬리표가 '견본'이 아닌 줄(기록 파일)에서만 옵니다: 개발 이름의 ': ' 앞 주제, 2–30글자, 한글, 파일 이름이 아님, 따옴표로 시작하지 않음. '견본' 꼬리표 줄은 개념 이름을 주지 않습니다.
- (b) haiku|sonnet|opus|fable|claude|anthropic|model|isRule|rung|isThink|isBase|isChanged|worked|stance|judge|verdict|calib|impl11|alias|gateway|bedrock|vertex|override|provider|모델|채점|견본|판정|프롬프트 에 대소문자 없이 걸리는 항목(개념 · 파일 · 코드 이름, 어느 줄에서 왔든)은 뺍니다.
- (c) 파일 이름과 코드 이름은 기록 파일 줄(꼬리표 ≠ '견본')과 names.json(impl111/b7/gen, 1.8.0 · 1.9.0의 파일 · 함수 이름)에서 옵니다(파일 이름은 코드 · 문서 확장자를 가진 항목의 경로 마지막 부분, 코드 이름은 세 글자 이상인 식별자이고 K01 · pT01 같은 id가 아님). '견본' 꼬리표 줄은 공백이 없고, 경로의 어느 부분도 judge, tools, calib, gen, stage, frozen, pilot, audit, review, fix, sw, cli, probe, d26, oldprobe, proofs, design, b<숫자>, b<숫자>r, impl11<숫자>가 아니며, 마지막 부분이 impl111 · impl112 · impl113 아래 어느 tools.sha256 / SHA256SUMS 표에 적힌 파일 이름도 아닐 때만 파일이나 코드 이름을 줍니다(그 표 이름 목록은 짓는 도구가 돌 때 지어 함께 sha256을 냄). 공백이 든 '견본' 항목(산문 조각)은 쓰지 않습니다. (c′) 어느 줄에서 왔든 그 표 이름 목록에 있는 파일 이름은 파일 목록에서 뺍니다(이름 목록에는 남아 얼릴 때 확인이 계속 거절함).
- 쓰는 쪽에게 주는 것은 이 셋(개념 이름 · 파일 이름 · 코드 이름)을 정렬해 ' · '로 이은 절뿐이고, 손으로 고치지 않습니다. 더하여 개발 절차대로, 같은 세트의 앞 부분이 이미 쓴 개념 이름을 한 줄로 붙입니다(아래 '도구가 글을 읽는 방식' 2).

#### 부르기

설계 calls 글(옮김)
- 플러그인이 부르는 그대로(D20), impl111/probe mod의 사본으로. 퀴즈마다: $.model.complete({ model: 'sonnet'(설정 글자 그대로), effort: 'low', system: QUIZ_SYSTEM, prompt: redactText(quizPrompt(picks, 'beginner')).text, maxTokens: 4600, timeoutMs: 90000 }). 4개씩 부르고, $.clock으로 시간을 재며, 답은 fixEscapedTicks를 거쳐 커밋된 parseQuiz로 읽습니다. 고르기는 makeQuiz가 짓는 그대로(codeFor, changedRun → changedRunFor인 withCode, rungOf, ladderMixed, pickForRung), 커밋된 트리에서 sonnet의 낸 줄(isRuleWide true)에 rungChangedStep 2와 isChangedRun true를 더해 짓습니다(M-13).
- sonnet 호출 9번의 한 회. haiku는 부르지 않습니다(그 칸은 켬이고 바이트까지 같다고 증명됨, 규칙 5 / D26). api-error(429/5xx, 토큰 0, 글 없음)만 두 번까지 다시 보냅니다. 빈 답이나 거절된 답은 모두 지나가는 탭으로 한 번 보내 stop_reason과 stop_details.category를 적습니다(기록만). M-4의 10% 규칙이 걸립니다.
- CLI: 그때 설치된 Claude Code의 새 고정 사본(2.1.329 이상), DISABLE_AUTOUPDATER=1. 먼저 M-5/M-10 보정(H_sonnet을 다시 잼; 1.12.0 값 2048을 다시 쓰지 않음). `claude --version`, system/init 모델, modelUsage 키를 앞뒤로 적습니다. 보정 기록과 어긋나면 회차는 무효이고 칸은 끔입니다.
- 사용량 관문(five_hour ≤ 0.60, seven_day < 0.80), 떼어 낸 러너, 러너 PID나 상태 파일을 기다림(`while pgrep -f`는 절대 안 씀). 백업 tar의 sha256은 견본.md에 적음.
- 꼬리표: sonnet 회차는 난수 꼬리표를 받습니다. 짝 파일은 봉하고(sha256만), 짝을 열기 전에 쓴 어느 파일도 모델 이름을 적지 않습니다.

계획 묶음 2의 글(calls)
- sonnet: 퀴즈 호출 9번: $.model.complete({ model: 'sonnet', effort: 'low', system: QUIZ_SYSTEM, prompt: redactText(quizPrompt(picks, 'beginner')).text, maxTokens: 4600, timeoutMs: 90000 }), 4개씩, fixEscapedTicks, 커밋된 parseQuiz; 고르기는 커밋된 트리에서 sonnet의 줄(isRuleWide true) + rungChangedStep 2 + isChangedRun true로 makeQuiz가 짓는 그대로(M-13).
- haiku: 호출 0.
- 다시 보내기: api-error(429/5xx, 토큰 0, 글 없음)만, 두 번까지; 빈 답/거절된 답은 stop_reason과 stop_details.category를 보러 한 번 탭(기록); M-4 10% 규칙.
- 스테이지: 하나, 퀴즈 sonnet.
- 쓰는 몫(계획 usage, 기록): sonnet 호출 9번(요청 약 2,500자, 출력 각 ≤ 약 550 토큰); 쓰는 쪽 호출 ≤ 11번, 판정자 2, 번역 확인 1(≈ 14 × c_sub); 에이전트 단계 ≈ 11; 부르기 전 관문 CPU 약 10분. 묶음 예측 0.16(commonPerBatch.usageGate[2]의 식); 회 R = 0.01.

이 묶음이 정한 것(위 글을 도구로 옮긴 자리, 기록)
- 모델-스테이지: `quiz` sonnet 하나(계획 사용량 관문 자리 'G2 quiz'). haiku 스테이지는 없습니다(`tools/stage.sh`가 거절).
- 떼어 낸 러너(러너 규칙): `tools/stage.sh quiz sonnet`을 setsid nohup으로 띄우고, 에이전트는 STARTED · 시도마다의 status.jsonl · DONE · summary.json · 러너 로그만 봅니다. 러너는 (1) STARTED가 없고, `frozen/d34/compare.json`이 9/9이며, `frozen/precall/result.json`이 pass true인지 보고, (2) 고정한 길로 앞 'ok' 세션(`probe/precheck.sh`)과 `tools/gate.py pre`(앞 기록이 1.13.0 보정과 같음 · five_hour ≤ 0.60 · seven_day + 0.01 < 0.80 · 회 R 0.01 · 다른 워크플로 없음을 에이전트가 ONLY_WORKFLOW=1로 밝힘)를 거친 뒤에만 STARTED를 쓰고, (3) 시도 1(`call-1`), 그리고 입장 2의 api-error 줄(상태 429 · 5xx, 글 없음, 출력 토큰 0)인 퀴즈만 얼린 줄 그대로 시도 2 · 3으로 다시 보내고, (4) 뒤 기록(`tools/gate.py after`)과 M-4 10%를 상태 수로만 봅니다. 엔진이 던지면 끝(M-4 넷째 줄). 끊긴 스테이지(한 시도가 out.json을 남기지 못함)는 계획 cutStageRule대로 상태 수로만 summary.json을 쓰고 끝(9)이며, 10%를 넘으면 무효이고 'quiz-r2'를 같은 요청 파일(sha256 확인)로 다른 날 한 번만 돌릴 수 있습니다.
- 모델 기록(M-10, D19): 앞 기록은 앞 'ok' 세션과 고정한 길의 --record, 뒤 기록은 시도마다의 프로브 세션(세션마다 앞뒤 claude --version, 턴마다 init model, result의 modelUsage 키)과 끝의 --record입니다. 모두 '보정 기록 (1.13.0)'(2.1.329, 고정 사본 sha256 `30e2724e…6d6d` · `c3484833…8e74`, sonnet 별칭의 풀린 id)과 같아야 합니다.
- 빈 답 · 거절의 탭(기록만): `tools/tapsend.py`.
- 판정자와 번역 확인: 계획 commonPerBatch.writerRunner대로 `gen/run.sh files json`(떼어 낸 러너, 고정한 길, 앞뒤 'ok' 세션 기록, 자기 관문)으로 부릅니다.

#### 위험 (재기 전에 적음)

설계 risks(옮김)
- (나)는 평가기에 묶여 있습니다. 시험한 코퍼스 밖의 학습자 코드에서 평가기 결함이 나면, 실행 중 확인 없이 틀린 정답이 저장됩니다: 진짜 출력을 쓴 학습자가 틀림으로 매겨지고, 그 개념은 단계 0으로 갑니다. 줄이는 것: 기본이 거절인 닫힌 부분 집합; 15,895 + 6,000 + 384 대조 프로그램에서 다름 0; 엔진 = node; 부르기 전 관문; 조항 16; 뒤의 어느 newRun 고침에도 B14. 남는 위험이고 밝혀 둡니다.
- 판 차이: 평가기는 시험한 대로 Node 22와 CPython 3.11에 맞습니다. 다른 판의 학습자는 실수 표기나 dict와 str의 모서리 사례에서 다른 출력을 볼 수 있습니다. 부분 집합(집합 찍기 없음, dict/list 찍기 없음, 기본 값 찍기만)이 이것을 작게 합니다. 적어 둡니다.
- 거절 분류기: r2 문구는 36번(sonnet 호출은 모두 105번) 돌았고 거절 0이었습니다. 분류기는 결정적이지 않아, 회차에서 거절이 나면 퀴즈마다 2–3자리를 잃습니다. 허용은 4자리입니다.
- 닿음: 통째 파일 기록의 약 48%(haiku 90%). sonnet 학습자는 비슷한 코드를 덜 자주 봅니다; 다른 개념은 내 코드로 묻습니다.
- 가르침의 질: 모델이 고르는 바꿈은 흔히 개념 줄에서 먼 데이터 값에 떨어지고, 어떤 값은 이상하지만 맞습니다('수면 -4시간'). 기준 문제가 아니고, 적어 둡니다.
- 절차: 파일럿이 설계 글의 '고침 하나' 규칙을 넘었습니다(주인 물음 0). 잰 회차 자체는 새롭고, 가리고, 미리 커밋한 것이라 그 결과는 영향을 받지 않습니다. 위험은 회차 하나를 쓴다는 것뿐입니다.
- 보정: H_sonnet은 다시 재야 합니다. 판이나 별칭이 어긋나면 회차는 무효입니다(칸은 끔).
- 잘린 답(1.10.0)은 개발 호출 105번에서 다시 나오지 않았습니다. 남는 위험으로 둡니다(그 퀴즈의 changed 자리를 잃음).
- 짓기 얽힘: 1.13.0의 G5(sonnet)와 G6(haiku) 짓기는 G2의 haiku와 sonnet 바이트를 지켜야 합니다(D26). G3가 뒤에 들어오면 그 newRun은 이것이어야 하고, 아니면 B14가 걸립니다.
- (이 묶음의 기록, 원문 밖) sonnet의 따라가기 거절(1.12.0 SCOPE 묶음 3의 사실: sonnet은 한 줄씩 따라간 과정을 글로 쓰라는 요청을 거절할 수 있음): 이 설계의 퀴즈 요청은 따라간 과정도, 출력도 쓰라고 하지 않습니다. 실행 길 자리에서 모델이 쓰는 것은 C 줄(고른 곳의 이름과 새 값) 하나뿐이고 T · Q · H · A를 쓰지 말라고 합니다(CHANGED_RUN_ASK). 설계 파일럿의 r2 문구는 36번(sonnet 105번) 돌아 거절 · 빈 답 0이었습니다(위 '거절 분류기' 줄). 거절된 답은 빈 답으로 남고 그 퀴즈의 자리는 (가) 놓침이며, 탭으로 stop_reason · stop_details.category만 기록합니다.

#### 읽는 법 (재기 전에 정함)

1. 다시 보내기와 M-4의 10%: 두 커밋된 규칙이 겹치는 곳이라 그대로 적습니다(1.12.0 묶음 1 감사 교훈 2). 먼저 이 G의 api-error 줄(입장 2: 상태 429 · 5xx, 글 없음, 출력 토큰 0인 것만 같은 프롬프트로 두 번까지)을 쓰고, 그다음 퀴즈마다 마지막 상태로 M-4 셋째 줄(10%)을 어느 답도 열기 전에 상태 수로만 봅니다. 퀴즈는 9개라, 마지막까지 api-error로 남은 퀴즈가 하나라도 있으면 1/9 > 10%이고 그 스테이지는 무효(답을 열지 않음)입니다. 끊긴 스테이지는 계획 cutStageRule대로 같은 셈을 상태 수로만 하고, 무효면 'quiz-r2'를 다른 날 같은 바이트로 한 번 돌리며, 다시 10%를 넘으면 칸은 끔입니다.
2. 입장 7 (ㅇ)과 11의 ⚙/✎, 조항 16과 14: 도구가 조항 10의 (i)–(iv), 조항 17(그 자리의 얼린 고르기에 code.run이 있고 저장된 문항이 changedRunItem의 것) · 18(changedRunItem의 isOwn이 true)을 세고, 두 판정자가 각자 (ㅇ)을 매기며 다른 조항으로 (가) 놓침을 볼 수도 있습니다(조항 번호를 적음). (나)는 도구가 조항 3으로 틀림(여러 번 돌린 결과가 다르거나 5초 넘음)이거나 조항 6 · 11 첫 단계로 같음이면 그대로이고, 그 밖에는 두 판정자가 모두 맞음이라 할 때만 맞음입니다(조항 11 · 16). (가)는 읽힌 자리에서 조항 7의 ⚙과 17 · 18이 모두 참이고, 두 판정자가 모두 넘음이라 하며, 그 자리의 (나)가 맞음일 때만 넘음입니다(조항 16: 저장된 A가 진짜 결과와 다르면 (가)에서도 놓침). 판정자에게 주는 보고서의 도구 칸은 ⚙ 조항의 결과만 보이고 ✎ 조항의 답을 미리 적지 않습니다(입장 14).
3. 견본이 모자란 언어: 계획 batches[1]의 두 글이 어긋납니다. samples.membership(과 설계 조항 19)은 '보탬 뒤에도 채우지 못한 잴 자리는 (가) 놓침'이라 하고, samples.layout과 commonPerBatch 셋째 단계는 '보탬 한 번, 그다음 STOP(재지 않음)'이라 합니다. 더 엄한 쪽을 따릅니다: 보탬 한 번 뒤에도 한 언어의 구성원이 잴 자리(js 13 · py 7)보다 적으면 견본을 얼리지 않고 STOP, 재지 않음(적음; sonnet은 끔 그대로)입니다. 예비만 모자라면(js 13–14 · py 7–8) 그대로 갑니다. 그래서 조항 19는 커밋된 글로 남지만 이 회차에서 쓰일 일이 없습니다. 까닭(기록): 모자란 자리를 빼고 퀴즈를 지으면 그 퀴즈의 고르기가 셋보다 적어 ladderMixed가 남은 비슷한 코드 자리까지 'mine'으로 바꿈을 도구 시험에서 보았습니다(아래 '도구 시험'). 그런 짜임은 커밋된 짜임이 아닙니다. 다른 언어의 기록으로 채우지 않습니다.
4. 채우는 것: 계획에 채우는 것의 보탬은 없습니다(보탬은 T1 · T2뿐이고, 쓰는 쪽 부르기는 11번 이하). 채우는 것 7개 가운데 하나라도 기록 확인을 넘지 못하면 commonPerBatch 셋째 단계의 '그 종류의 보탬 한 번, 그다음 STOP'에서 보탬이 없으므로 STOP, 재지 않음입니다(적음).
5. 구성원과 기록 확인: '구성원은 rungOf로만 정함'은 쓰는 쪽 규칙을 지킨 기록 가운데서의 차례입니다. 쓰는 쪽 프롬프트의 규칙을 어긴 기록(아래 '도구가 글을 읽는 방식' 3의 기록 확인)은 1.12.0처럼 고치지 않고 빼며, 그 뒤 남은 기록을 쓴 차례(id 차례)대로 커밋된 sonnet 길 rungOf에 넣습니다. 자리의 단계는 2 또는 3이라, 두 단계 모두에서 'changed'인 기록만 구성원입니다(설계 개발 도구와 같음; 한 단계만 따지는 것보다 엄함).
6. 판정자의 다시 묻기: 1.12.0 judge.py는 읽지 못한 답이나 읽힌 자리가 빠진 답을 새 판정자에게 한 번 더 물었습니다. 1.13.0은 계획 commonPerBatch.writerRunner대로 판정자를 `gen/run.sh files json`으로 부르고, 그 러너가 읽지 못한 답과 거절을 같은 프롬프트로 한 번 더 보내며, 두 번째에도 그러면 그 판정자는 STOP입니다. 읽힌 답에서 빠졌거나 꼴이 틀린 자리, 그리고 STOP인 판정자의 모든 자리는 'undecided'(불리한 쪽)입니다. 사용량 한도나 기반 실패로 끝난 판정자 호출은 판정 파일이 없으므로 같은 바이트로 다시 부릅니다(다시 매김이 아님). 판정 파일이 있는 판정자는 다시 부르지 않습니다.
7. 입장 머리말의 '견본 쓰기 프롬프트와 함께 한 커밋': 쓰는 쪽 틀(`gen/writer-A.md` · `gen/writer-A-end.md` · `gen/writer-B.md` · `gen/writer-B-end.md`, impl112/b2/gen의 바이트 사본), 부분 짜임(`gen/parts.json`), 프롬프트를 짓는 `gen/parts.py`, 피할 절을 짓는 `gen/avoid113.py`를 아래 표로 이 커밋에 얼립니다. 피할 절 자체는 쓰는 쪽이 돌 때의 NAMES-all.txt에서 지어지므로(계획 avoidBuilder) 그 sha256과 다 지은 프롬프트의 sha256은 견본 커밋에 적습니다.
8. 입장 3의 '도구 판(node · python · Claude Code)을 적습니다': 견본을 얼리는 커밋에 적습니다. 이 커밋 때: node v22.23.4 · Python 3.11.18 · git 2.43.0 · Claude Code 2.1.329(고정한 길).
9. 입장 15가 가리키는 '경계 사례'의 '(dev 1.13.0)' 사례들은 설계 때 개발 세트에서 본 꼴을 미리 가른 것이고, 개발 결과는 어느 결정에도 들지 않습니다(B-12).
10. 부르기 전 관문의 코퍼스: 설계 samples.preCallGate는 '얼린 잴 기록과 예비 기록'을 돌린다고 하고, 계획 preCallGate.cost는 '약 16k 프로그램, 약 10분'이라 합니다(설계의 넓은 코퍼스 15,895 프로그램의 크기). 더 엄하게 둘 다 돌립니다: 얼린 잴 · 예비 기록(24개)과 설계의 넓은 코퍼스(`final/wide/records.jsonl` 686개, 바이트 사본 `tools/precall/wide-records.jsonl`)를 같은 목록 · 같은 평가기 · 같은 진짜 돌리는 쪽으로 돌리고, 어느 쪽 다름도 관문 실패입니다. 엔진 런타임은 모든 프로그램을 여섯 조각으로 `claude plugin test`(고정한 길)에서 돌립니다.
11. 조항 18의 isOwn: parseQuiz는 펜스를 아는 읽기가 모자라면 펜스를 모르는 읽기로 물러섭니다. 도구는 저장된 문항과 바이트까지 같은 문항을 낸 읽기(먼저 펜스를 아는 쪽)의 isOwn을 씁니다. 어느 읽기의 문항도 저장된 문항과 같지 않으면 isOwn을 정하지 못한 것으로 보고 (가) 놓침입니다(입장 14).
12. 계획 batches[1].build의 'run113 시험 10개'와 짓기 커밋의 9개, 계획 prototypePatch.sha256과 디스크의 값이 다른 것은 짓기 커밋 5c27746 본문에 적었고, 이 기준의 수에 들지 않습니다.

#### 도구가 글을 읽는 방식 (재기 전에 정함)

도구는 설계 개발 도구(`impl113/design/G2/dev/gen/parts.py` · `dev/tools/build.mjs` · `read.mjs`, `final/wide/gen.mjs` · `realpar.py` · `cmpwant.py` · `mkengine.mjs`, `final/own.mjs`), 1.12.0 G2 잰 도구(`impl112/b2/tools`, `gen`, `d34`, `judge`)와 묶음 1의 1.13.0 기반 도구(`impl113/b1/gen/run.sh` · `gate.py` · `precheck.sh` · `record.py`, `tools/gate.py` · `stage.sh` · `tapsend.py`, `probe/`, `tap/`)를 짓기 커밋의 트리에 맞춰 `impl113/b2/` 아래에 다시 지었습니다. 계획이 '새로'라고 한 것(부르기 전 관문 러너, sonnet 길의 고르기 짓기, 꼬리표 · 봉인 · 짝과 기계 셈)도 여기서 지었습니다. 글과 도구가 다르면 글이 이깁니다(M-15).

1. 트리: `mtree/`는 짓기 커밋 5c27746의 `git archive`(docs · README · CHANGELOG 뺌)이고, `mtree/hooks/notes.ts` · `newrun.ts` · `register.tsx`는 위 sha256과 같습니다. 판정의 읽기 트리 `jtree/hooks/notes.ts`는 mtree의 notes.ts에서 `codeAsRead` · `codeTokens` · `quizParts` · `shownCode` 앞에 `export `만 더한 것이고(다른 바이트 같음), `jtree/hooks/`의 다른 파일은 mtree의 바이트 사본입니다. 요청을 짓는 모든 도구는 mtree를, 읽기의 기록(changedRunItem의 까닭과 isOwn)과 조항 7 (ㄷ)의 토큰만 jtree를 씁니다.
2. 견본 쓰기(`gen/parts.json` · `gen/parts.py` · `gen/avoid113.py` · 쓰는 쪽 틀 넷 · `gen/run.sh` · `gen/gate.py` · `gen/precheck.sh` · `gen/record.py`): 부분은 A1(rm01–rm10) · P1(rm51–rm60) · A2(rm11–rm20) · P2(rm61–rm70) · A3(rm21–rm30) · P3(rm71–rm80) · A4(rm31–rm40) · A5(rm41–rm50)를 이 차례로 하나씩(사슬 M), 그리고 그 곁에서 B(rf1–rf7; rf1 ts 고침 · rf2 js 고침 · rf3 왜 · rf4 다시 도전 js · rf5 py 고침 · rf6 왜 · rf7 다시 도전 py)입니다. 보탬은 TU-T1(js rm81–rm90) · TU-T2(py rm91–rm100)이고 자기 뿌리에서 돕니다. 프롬프트는 개발 절차 그대로입니다: writer-A.md에서 '24 records …' 한 줄을 그 부분의 수 · id · 언어 한 줄('This is one part of a larger set that is written in several parts.'를 붙임)로, 섞임 최소를 round(최소24 × n / 24)(1 이상; (e)는 js 부분에만)로, writer-A-end.md의 'the 24 records'를 'the 10 records'로 바꾸고; writer-B.md에서는 id만 rf로 바꿉니다. 그 뒤에 피할 절(`avoid113.py`, 이름만)과, 사슬 M에서 앞 부분들이 이미 쓴 개념 이름 한 줄(개발 절차의 'These concept names are already used by other parts of this same set; …')을 붙입니다. 다 지은 틀이 개발 세트 D의 프롬프트와 id 말고 같음을 확인했습니다(아래 '도구 시험'). 러너는 묶음 1 러너의 사본입니다(경로와 사슬 이름만 바꿈): 부르기마다 STARTED와 상태 줄, 거절(stop_reason refusal 또는 safety_stops > 0) · 읽지 못함(도구 호출 글 포함)은 같은 프롬프트로 한 번 더, 두 번째면 STOP, 사용량 한도 · api 오류 · 끊긴 프로세스는 WAIT(거절로 세지 않음), 앞뒤 'ok' 세션 기록이 다르면 VOID.
3. 얼리기(`tools/check.py` · `tools/facts.mjs` · `tools/kit.mjs` · `tools/runlib.py`): `gen/parts.py assemble`이 쓴 그대로를 `frozen/raw.json`으로 묶고(보탬은 그 뿌리에서 읽음), 기록마다 1.12.0의 기록 확인(필드; id에 맞는 확장자; 6–16줄 · ≤ 650자; 설명의 백틱 인용이 1–6번째 줄 안; 줄 머리에서 시작하는 찍기 줄 1–4개이고 다른 `console.` · `print(` 호출 없음; import/require/export 줄 없음; while/do 없음; 세는 for 없음; 도는 목록을 그 반복 안에서 늘리지 않음; 빈 찍기 호출 없음; 백슬래시 없음; Python 집합 없음; 입력 · 파일 · 네트워크 · 시계 · 난수 · 타이머 · 지역 설정 · process · 환경 · id() · hash() 없음; 문자열 글자는 20자 미만; 입장 3으로 돌린 결과가 끝 코드 0 · 모두 같음 · 5초 안이고 적힌 output과 줄까지 같으며 1–4줄; conceptsOf가 이름과 설명을 쓴 그대로 읽음; redactText 0곳)과 이름 확인(이름에 `*` · 백틱 · '--' 없음, 설명에 '--' 없음; 이름(소문자, 공백 뺌)과 파일 경로가 NAMES-all.txt의 어느 항목도 아님; 세트 전체에서 이름이나 파일 경로가 두 번 나오면 뒤의 것이 못 넘음)을 봅니다. 더하여(1.13.0, 더 엄격; 계획 freezeCheckInputs) 겹침 확인: 파일 경로가 겹침 코퍼스(impl113/design/*/dev · pilot, impl113/b*/frozen, impl112/design/*/dev, impl112/b1 · b2 · b3r · b4의 frozen과 b3r/dev 아래 JSON 기록의 'path' · 'file' 값; 얼리는 폴더 자신은 뺌)의 경로가 아니고, 그 마지막 부분이 NAMES-all.txt 기록 파일 줄(꼬리표 ≠ '견본')의 파일 이름이나 코퍼스 경로의 마지막 부분이 아니며, 설명의 백틱 인용(공백을 하나로)이 코퍼스 기록 설명의 인용이 아니고, 코드(공백을 뺌)가 코퍼스 기록의 코드가 아니어야 합니다. 채우는 것은 1.12.0의 확인(고침 셋은 before/after, after 20–34줄, 이어진 1–4줄을 바꾼 hunk 하나, 설명의 인용이 after 안, 단계 0에서 rung 'mine'; 왜 둘은 코드 · 파일 없음, rung 없음; 다시 도전 둘은 6–14줄 통째 파일과 slip {question, mine, what}, 단계 1에서 slip을 다시 물을 때 rung 없음). 구성원은 위 '읽는 법' 5, 모자람은 '읽는 법' 3 · 4. 짜임은 1.12.0 짜임 그대로입니다: 잴 20개를 자리 c1..c20에, py는 c2 c5 c8 c11 c14 c17 c20(py는 id 차례, js는 id 차례), 단계는 c1 = 2부터 2 / 3 번갈아; Q1 [c1 c2 c3] · Q2 [c4 c5 c6] · Q3 [c7 c8 rf1] · Q4 [rf2 c9 c10] · Q5 [c11 rf5 c12] · Q6 [c13 rf3 c14] · Q7 [c15 rf6 c16] · Q8 [rf4 c17 c18] · Q9 [rf7 c19 c20]; 내 코드는 단계 0, 왜는 2, 다시 도전은 1에서 slip을 다시 물음(times 1). `frozen/samples.json`(잴 것 · 예비 · 채우는 것), `layout.json`, `learner.json`(입장 3의 학습자 결과), `members.json`, `check-report.json`(NAMES-all.txt와 코퍼스의 sha256 포함)을 한 번만 쓰고 chmod 444. 이름 목록 덧붙임은 `names/append113.py`(묶음 1 도구의 사본; 기록마다 id · 개념 이름 · 파일 경로 · 코드가 정의한 이름을 'G2-measured-113'으로, 덧붙이기만)입니다.
4. 짜기(`tools/build.mjs` · `tools/kit.mjs`): 퀴즈마다 makeQuiz처럼 개념마다의 고르기(withCode: codeFor의 줄, isChangedAskable(단계 2), isWholeShown · isUnrunnableChange · isImportingChange, 그리고 통째 파일이면 code.run = changedRunFor(text, file, blurb)), rungOf(sonnet 측정 줄: changedStep 2, changedRun true, newStep · workedAfter · workedPlainAfter Infinity; 다시 도전은 slip times 1과 isAsking), ladderMixed, pickForRung, `redactText(quizPrompt(picks, 'beginner')).text`, maxTokens는 register.tsx의 식(`isLong ? QUIZ_TRACE_TOKENS : QUIZ_TOKENS`, 둘 다 register.tsx 글에서 읽음), system QUIZ_SYSTEM, timeoutMs 90000. 잴 자리가 'changed'가 아니거나 code.run이 없거나(조항 17), 채우는 것이 제 rung이 아니거나, redactText가 0곳이 아니거나, maxTokens가 4600이 아니면 아무것도 쓰지 않고 끝(3). `frozen/build.json`과 `frozen/lines-sonnet.jsonl`(퀴즈마다 { id, model 'sonnet', system, prompt, maxTokens, timeoutMs })을 chmod 444로 씁니다.
5. D34(`d34/make.py`, 셈에 들지 않음): mtree 사본에서 시험 파일을 모두 빼고(flowkit.ts · fixtures는 둠) 퀴즈마다 시험 하나를 만듭니다: model 'sonnet', level beginner, 하네스 `models: { sonnet: { rungChangedStep: 2, isChangedRun: true } }`(sonnet의 낸 줄 위에 G2 칸), 그 퀴즈의 개념을 단계대로 저장소에 두고 퀴즈 차례로 때 되게, 다시 도전은 저장소 slip(times 1), 통째 파일은 Write 턴, 고친 파일은 Edit 턴(그 -U3 hunk 하나를 structuredPatch로), 턴마다 그 개념을 적은 노트, 그다음 `/learn 퀴즈 새로`. 잡힌 요청(model, effort, system, prompt, maxTokens, timeoutMs)이 `lines-sonnet.jsonl`의 그 줄과 바이트까지 같고 노트 뒤의 유일한 요청이어야 하며, 9/9일 때만 끝 코드 0입니다. `claude plugin test`는 고정한 길로 돌고 하네스가 답하므로 모델 호출은 없습니다.
6. 부르기 전 관문(`tools/precall/precall.py` · `gen.mjs` · `realpar.py` · `cmpwant.py` · `learner.mjs` · `mkengine.mjs` · `wide-records.jsonl`): 위 '읽는 법' 10. gen.mjs는 설계 `final/wide/gen.mjs`(`eb7dd0ad…9fe4`)의 사본이고 newRun을 notes.ts 곁의 `hooks/newrun.ts`에서 읽는 것만 다릅니다(값 목록 그대로). realpar.py는 임시 파일을 결과 곁의 work 폴더에 두는 것만, cmpwant.py는 머리말만 다릅니다. mkengine.mjs는 짓기 때의 `tools/mkengine113.mjs` 사본(시험이 `hooks/newrun`을 가져옴, 2.1.329 키트의 test(이름, 옵션, 본문) 꼴)입니다. learner.mjs는 얼린 기록마다 kit.mjs의 고르기로 changedRunFor의 out을 내고, precall.py가 그것을 진짜 실행(runlib)과 견줍니다. 결과 `frozen/precall/result.json`(chmod 444)의 pass가 true일 때만 스테이지 러너가 시작합니다.
7. 부르기(`tools/stage.sh` · `tools/gate.py` · `probe/precheck.sh` · `probe/call.sh` · `probe/record.py` · `probe/mod/`): 위 '부르기'의 러너. 프로브 mod(명령 `/g2probe <줄> <답 파일> <상태 파일>`)는 묶음 1 프로브의 사본이고(명령 이름만 바꿈) `probe/mod/hooks/notes.ts` · `newrun.ts`는 mtree의 것과 바이트까지 같으며, notes.ts가 `./newrun.ts`를 가져오므로 mod에 `tsconfig.json`(allowImportingTsExtensions)을 두었습니다. 4개씩 부르고, 호출마다 상태 줄(id, answered, reason, status, output_tokens, ms; 글 없음)을 더합니다. 다시 보낸 요청은 얼린 줄 그대로입니다(`again-2.jsonl` · `again-3.jsonl`).
8. 탭(`tools/tapsend.py` · `tap/`): 묶음 1 탭의 사본(명령 `/g2tap`, `tap/tap.py`는 묶음 1 것과 바이트까지 같음). 퀴즈마다 마지막 시도의 빈 답이나 거절된 답을 그 얼린 줄로 한 번 탭으로 보내 stop_reason · stop_details만 적습니다. 기록만.
9. 꼬리표와 읽기(`tools/label.py` · `tools/read.mjs`): seal은 스테이지가 DONE일 때 꼬리표를 A · B 가운데 난수로 하나 뽑아 `judge/pair.json`({꼬리표: 모델, nonce}, chmod 444, sha256만 찍음)과 `judge/label.txt`를 씁니다. read는 퀴즈마다 마지막 시도의 답(프로브가 이미 fixEscapedTicks를 거침)을 mtree의 parseQuiz(text, build.json의 picks)로 읽어 `judge/<꼬리표>/read.json`(chmod 444)에 둡니다. 비슷한 코드 자리마다 저장된 문항, 길(조항 17: 고르기에 code.run), jtree의 changedRunItem이 낸 까닭과 isOwn(위 '읽는 법' 11)을 적습니다. 토큰 · 시간 · 상한 · 모델 이름은 적지 않습니다.
10. eval(`tools/eval.py` · `tools/tok.mjs` · `tools/runlib.py`): 입장의 ⚙ 조항. 1.12.0 eval.py에 조항 17 · 18 칸, 조항 16의 도구 결과, 조항 20의 답 꼴(기록만), 그리고 조항 19의 자리(쓰일 일이 없음, '읽는 법' 3)를 더했습니다. 읽히지 않은 자리는 (가) 놓침(조항 2 · 13), (나) 밖. 읽힌 자리: 문제의 코드는 question의 펜스 블록 내용, 언어는 펜스 이름. 돌리기는 runlib.run(조항 3), (ㄴ) · (ㄷ) · (ㄹ) · (ㅁ) · (ㅂ) · (ㅅ) · (ㅈ)과 조항 10 (i)–(iv)는 1.12.0 도구 그대로입니다. 판정자 보고서 `report.md`에는 학습자 코드 · 얼린 학습자 결과 · 저장된 문항 · 보인 코드를 돌린 결과 · 도구 칸이 들어갑니다(모델 이름 · 토큰 · 시간 없음).
11. 판정(`tools/judge.py` · `judge/tpl-judge.md` · `judge/stance-G2.md`): 꼬리표마다 판정자 둘, `judge.py prep`이 같은 프롬프트 둘(틀 · 입장 · 그 꼬리표의 report.md)을 `judge/<꼬리표>/run/inputs/`에 쓰고, `gen/run.sh judge/<꼬리표>/run files json`(PROJ 0.01)이 각자 새 `claude -p --model opus --tools '' --output-format json`(고정한 길, 빈 폴더, 프롬프트는 stdin)으로 부르며, `judge.py collect`가 `verdicts-1.json` · `verdicts-2.json`(chmod 444)을 씁니다(위 '읽는 법' 6). stance-G2.md는 이 절의 '판정의 입장'에서 '결정 규칙' 앞까지를 그대로 자른 것입니다. 틀은 1.12.0 tpl-judge.md에서 (나) 판정 줄의 '조항 11'을 '조항 11 · 16'으로만 바꿨습니다.
12. 셈과 결정(`tools/tally.py` · `tools/decide.py`): tally는 eval.json과 두 verdicts가 모두 chmod 444일 때만 위 '읽는 법' 2대로 (가)와 (나)를 세고 넘음((가) ≥ 16, (나) 틀림 0, 자리 20)을 `judge/<꼬리표>/tally.json`(chmod 444)에 씁니다. decide는 스테이지가 DONE이고 판정 파일 둘과 tally가 얼린 뒤에만 짝을 열고(label.py open), sonnet의 수와 줄(넘음이면 `{ ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2, isChangedRun: true }`, 아니면 `{ ...SWITCHES_OFF, isRuleWide: true }`; haiku는 결정 없음)을 `judge/decision.json`(chmod 444)에 씁니다.
13. 기계 셈(`tools/count.py`): 꼬리표마다 시도별 호출 · 끝난 꼴, 퀴즈마다 마지막 상태, 다시 보낸 수, 상한 닿음(output_tokens ≥ 4600 + 2048 = 6648), output_tokens 가장 큰 것과 가운데, 시간, 탭의 빈 답 · 거절 · 거절 갈래 열을 `judge/count-<꼬리표>.json`(chmod 444)에. 판정자는 이 파일을 받지 않습니다.
14. 짓기 때 쓴 도구(기록, 이 커밋으로 함께 얼림): `tools/mkengine113.mjs` · `tools/mkengine113.diff`(엔진 실행 기록), `tools/nodecmp.mts`(node 견줌), `tools/probe_off.mjs` · `tools/probe_off.diff`(끈 바이트), `tools/mut.py` · `tools/mutrun.sh`(돌연변이 탐침). D26 도구(`impl113/d26/rulewide113.mjs` · `g2haiku.sh` · `remake.py`)는 묶음 0의 표 그대로입니다. 값 커밋(R9)과 뒤 묶음의 재확인이 다시 씁니다.

#### 도구 시험 (견본 · 모델 호출 0, 저장소 밖 `impl113/b2/test/`)

입력은 설계 개발 세트 D와 E의 기록(측정에 쓰지 않는 개발 기록)을 잴 꼴의 id로 바꾼 합성 세트, 손으로 쓴 합성 기록, 가짜 `claude`(`test/bin/claude`)와 가짜 고정 길(`test/pinned-fake.sh`)뿐입니다. 잴 견본은 아직 하나도 쓰지 않았습니다.
- 쓰는 쪽 러너(`test/wrtest.sh`): 모두 넘음 → DONE, 기록 87개, 부분 9개; A1 프롬프트에는 앞 부분 줄이 없고 A5 프롬프트에는 앞 일곱 부분의 개념 이름이 있음; P1이 두 번 거절 → STOP P1; A2 거절 한 번 · B 도구 호출 글 한 번 → 같은 바이트로 다시 보내 DONE; 한도에 닿음 → WAIT, 다시 돌리면 같은 바이트로 DONE; 끊긴 프로세스 → WAIT; five_hour 0.70 → WAIT(호출 0); seven_day 0.75 + 0.06 → WAIT; 판 다름 · 고정 sha 다름 → RECORD-STOP; 쓰는 쪽 id 다름 → VOID, 다시 돌리면 아홉 부분 모두 새로 DONE; DONE인 뿌리를 다시 → 거절; CHAIN_ROOT 없는 보탬 → 2, 보탬 T1 → DONE(id rm81–rm90, 본 부분 여덟의 개념 이름); 없는 보탬 이름 → 2; files json → DONE, 읽지 못한 답 두 번 → STOP.
- 프롬프트 틀: 다 지은 A1 · B 프롬프트에서 피할 절을 빼면 설계 개발 세트 D의 A1 · B 프롬프트와 id 말고 바이트까지 같음(개발 절차 그대로).
- 얼리기(`tools/check.py`): 합성 세트(잴 꼴 87개, 빈 시험 이름 목록, 코퍼스 없음) → js 구성원 19 · py 17, 기록 확인에서 빠진 것 12(문자열 20자 이상 9 · 이름 두 번 2 · 파일 두 번 1), 확인을 넘었지만 sonnet 길에서 'changed'가 아닌 것 33. 진짜 NAMES-all.txt와 진짜 코퍼스(파일 1,357개, 경로 2,600, 인용 1,523, 코드 3,486)로 손 기록 11개: design/G6/dev/set1/names.txt의 파일 이름을 쓴 기록, 'G2-dev-113' 개념 이름을 쓴 기록, 1.13.0 개발 기록의 인용 줄을 쓴 기록, 개발 기록의 코드를 그대로 쓴 기록이 각각 그 까닭 하나로 거절됨(계획 freezeCheckInputs의 세 거절과 코드 겹침); while · 적힌 출력 다름 · 긴 문자열 · 이름 두 번 · 확장자도 거절. 한 언어가 모자람 → 'TOPUP T2'(끝 3, 얼림 없음); 보탬 뒤에도 py 6 < 7 → STOP(끝 6, 얼림 없음); 채우는 것이 못 넘음 → STOP. (모자란 자리를 빼고 지은 짜임에서는 Q9의 고르기가 둘이 되어 ladderMixed가 남은 자리를 'mine'으로 바꿨고 build.mjs가 끝 3으로 거절함 → '읽는 법' 3.)
- 짜기와 D34: 합성 얼림에서 build.mjs가 9퀴즈 모두 잴 자리 'changed' · 채우는 것 제 rung · redactText 0 · maxTokens 4600; `d34/make.py`(진짜 `claude plugin test`, 고정한 길, 모델 호출 0) 9/9 바이트까지 같음; 한 퀴즈 프롬프트의 한 글자를 바꾼 사본은 8/9(끝 4)로 잡힘.
- 부르기 전 관문(`tools/precall/precall.py`, 합성 얼림): 프로그램 17,406개(넓은 코퍼스 15,895 = 설계 기록과 같은 수, 합성 기록 1,511), 다름 0, 학습자 실행 다름 0, 엔진 여섯 조각 모두 다름 0 · 시험 끝 0 → pass. 진짜 실행 기록 두 줄을 바꾼 사본은 cmpwant가 다름 2로 잡음.
- 스테이지 러너(`test/stagetest.sh`, 가짜 claude): DONE(관문 자리 'G2 quiz sonnet', R 0.01); STARTED가 있으면 거절; haiku 거절; DONE 뒤 quiz-r2 거절; 부르기 전 관문 pass 없음 · D34 없음 → 거절; ONLY_WORKFLOW 없음 → 시작 안 함; five_hour 0.70 · seven_day 0.795 → WAIT(STARTED 없음), seven_day 0.785 → DONE; 판 · 고정 sha 다름 → STOP; 프로브 세션 id 다름 → VOID(4); 429/5xx 두 번 뒤 답함 · 한 번 뒤 답함 → 시도 9 · 2 · 1, DONE; 세 번 모두 api-error → 10% 넘음 VOID(6); 400은 다시 보내지 않음 → VOID(6); 빈 답 · 시간 한도는 다시 보내지 않음 → DONE; 던짐 → 5; 상태 넷 뒤 끊김 → CUT(9), 상태 수로 api-error 5 → void10, 그 뒤 quiz-r2 → DONE, quiz-r2 다시 → 거절.
- 읽기 → eval → 판정 → 셈 → 결정(`test/pipe.sh`, 가짜 답): 자리마다 자기 값 · 값 아님('abc', 숫자 자리에서 대신 냄) · C 머리 문법 틀림 · 다른 번호를 넣은 합성 답에서 read.mjs가 ok/own · ok/fallback · grammar · other-slot을 냄(문자열 자리의 'abc'는 값으로 읽혀 own); eval이 읽힘 18 · own 15 · ⚙ 넘음 15 · (나) 도구 맞음 18; 판정자 둘은 가짜 고정 길의 `gen/run.sh files json`으로 돌고 collect · tally((가) 15, 못 넘음) · count(상한 6648) · decide(sonnet 줄 그대로)가 이어짐; 짝은 판정 파일 둘과 tally가 얼기 전에는 열리지 않고, decision.json은 한 번만. 빈 답 하나 · 시간 한도 하나인 스테이지에서는 그 퀴즈 자리가 까닭과 함께 읽히지 않은 자리로 가고, tapsend가 빈 답 하나를 탭으로 보냄(가짜 길).
- 프로브 · 탭 mod: 고정한 길의 `claude plugin validate`가 둘 다 넘음(끝 0, 경고 있음).
- 이름 덧붙임: NAMES-all.txt의 사본에 합성 세트로 301줄을 덧붙이고(앞 줄 그대로), 두 번째는 거절.
- 피할 목록(`impl113/gen/avoidtest113.py`, 얼린 뒤 다시 돌림): 얼린 뒤(2026-11-21 04:06:51 UTC 얼림 다음) 이 묶음의 표(`bar/tools.sha256`)가 든 채로 다시 지었습니다(`test/avoid-1795234024/`). 짓는 도구 출력: 개념 이름 1,848 · 파일 이름 2,319 · 코드 이름 1,727, NAMES-all.txt `aca62354…fdb3`, 표 이름 목록 213개 `5d3b0f93…d217`(이 묶음의 표 포함). 다 지은 쓰는 쪽 프롬프트 넷(A1 js · P1 py · B · 보탬 TU-T2)에서 (1) (b) 무늬 0곳 · 표 파일 이름 0곳; (2) namesRegistry.verify (4)의 일곱 줄 0 · '견본' 줄의 공백 든 항목은 기록 개념 이름으로 든 20개 말고 0; (3) 'G2-dev-113'의 개념 이름 · 파일 이름 있음(코드 이름은 그 꼬리표에 해당 항목 없음 n/a). 끝 코드 0, 결과 `avoidtest.json` sha256 `9bb0a48b23e0ba1868b755d8648c1e4bc79aa2c350ddf7379dca9203d49bbb4c`.

#### 옮김 확인

(확인 뒤에 적음)

#### 틀과 도구 (sha256, 이 커밋으로 얼림, 저장소 밖 `impl113/b2/` 아래, chmod 444)

목록 파일 `impl113/b2/bar/tools.sha256`(chmod 444) sha256 `acac75d9aae6ec864c4dd09c2c0eca45d7c8dd484b07cd8126a1a96377c7c5b9`, 파일 64개. 표의 경로는 `impl113/b2/` 기준입니다. `mtree/` · `jtree/`는 트리 통째로 쓰기를 막았습니다. 쓰는 쪽과 판정자가 돌 때 각 스테이지는 `../NAMES-all.txt`의 그때 sha256을 자기 폴더에 적습니다. 얼릴 때 확인의 환경 값: `NAMESALL` = `impl113/NAMES-all.txt`(지금 `aca62354e1ff48b4dc03fef16cfe7a07fe1788939bda094be6800ac2dfc0fdb3`, 덧붙인 뒤의 값은 견본 커밋에 적음), `CORPUS_GLOBS` = check.py의 기본 목록(계획 freezeCheckInputs의 코퍼스), `RAW` = `frozen/raw.json`, `TOPUPS` = 보탬을 돌렸을 때 그 뿌리 목록.

| 파일 | 하는 일 | sha256 |
| --- | --- | --- |
| `gen/writer-A.md` | 쓰는 쪽 A 틀 앞(impl112/b2/gen 바이트 사본) | `80f1a7d59073f987d5aaa92c0240a879881c596235cc2b37fc6453c2635948ea` |
| `gen/writer-A-end.md` | 쓰는 쪽 A 틀 끝(바이트 사본) | `dbe1f05d70a9451da75d1548b859ea42201abba08ff41d4b31d766fb8853a72c` |
| `gen/writer-B.md` | 쓰는 쪽 B 틀 앞(채우는 것 7, 바이트 사본) | `5db99cef937717d3dad4473a0fb7ec33ac47d51c6595909499b5d4dc99f331b0` |
| `gen/writer-B-end.md` | 쓰는 쪽 B 틀 끝(바이트 사본) | `8babf61b1e1a19f85047a4979ceff965f84147d770dec03f0282501c633a5c9d` |
| `gen/parts.json` | 쓰는 쪽 부분 짜임(A1–A5, P1–P3, B, TU-T1 · TU-T2) | `b8b7e911b991563dc1ae6d6d1ba0251c421153ce38d788a7fc4ce68ac96a41e6` |
| `gen/parts.py` | 부분 프롬프트 짓기 · 읽기 · 묶기(개발 parts.py 절차) | `dab985e0c68e30dc057b1e87d5102155018eca2ca8ce6a6e79072549c3c7a485` |
| `gen/avoid113.py` | 피할 절 짓는 도구(impl113/gen/avoid113.py와 같음) | `66b0528bae2375f59ce4d3363503d0317b9a37dbd19da1a2c80240edefb395de` |
| `gen/run.sh` | 쓰는 쪽 · 판정자 · 확인자의 떼어 낸 러너 | `9beb848320630fcdc943133210e3678818e9a02b84ec162587c3855aa51ec0c9` |
| `gen/gate.py` | 러너의 앞뒤 기록 · 사용량 관문 · 끝난 꼴 | `a5346beb61e8d4e1c4c769913052ea37cc5dab03a85f51b3a9305d923ad1cea0` |
| `gen/precheck.sh` | 러너의 앞뒤 opus 'ok' 세션 | `6f3f35dae0a77fa141236f63425b3e253b17e099cc8332a94dc04e2a294bc60e` |
| `gen/record.py` | 세션 기록 읽기(러너) | `a50da824e3ccfa74f5514e7edd8f1098089083efe59f0d36c31e2265312dcc38` |
| `tools/runlib.py` | 돌리기(입장 3 · 12) · 맞춤(입장 6) · 조항 8 · (ㄹ)(1.12.0 사본) | `9aba9148a2b2f2afe0cffcc19c494efcf422dfb139668a4613fb4823839c37a2` |
| `tools/kit.mjs` | 플러그인 쪽 고르기 · sonnet 실행 길 · 칸 · 프롬프트(mtree) | `888e8963958eb9ca97469c876e81b8925b991f55c3d461ccab9099d58f8956bf` |
| `tools/facts.mjs` | 얼릴 때 플러그인 사실 | `2dc743d3c34da22a0c34182edd870d4dacd789a2808cfe69c764bd4a139db903` |
| `tools/check.py` | 얼릴 때 확인 · 겹침 · 구성원 · 짜임 · 학습자 결과 | `aba858bd7636277e9a9f0fac1fdaa1b433ee5001fa4f3910b8fc46e5d815cf89` |
| `tools/build.mjs` | 퀴즈 9개 요청(lines-sonnet.jsonl) | `14f5f45d3dfa28746f5b892e26997e8fefb6143c9e43c103c72eba6b2b24bc27` |
| `tools/stage.sh` | 떼어 낸 러너(quiz sonnet, api-error 다시 보내기, 끊긴 스테이지) | `f61650c5a73320391dc7633ea19b01d178fcb4f963d3ac8e370a0a5f693b6299` |
| `tools/gate.py` | 스테이지 앞뒤 기록 · 사용량 관문(0.01, R 0.01) | `16f23b29f9bbdb5ac86a372700f88408abc5832431dc746a44c9109ad612ee4d` |
| `tools/tapsend.py` | 빈 답 · 거절의 탭(기록) | `d4304031a9c6242bdb18e9b313d0a191760950ca8df8803cc97aae0ce0b7ec94` |
| `tools/read.mjs` | 읽기(입장 1 · 2 · 13 · 17 · 18) | `adeb0d353cd3445180801e9d9632dd4b374b596df7f8b4658988756554e633a8` |
| `tools/label.py` | 꼬리표 봉인 · 읽기 · 짝 열기 | `8bfd136e042c7f3ab27e9f8e4cc3e0e174e179a77f865ebd02d246ade87022bf` |
| `tools/eval.py` | eval 도구(⚙ 조항) · 판정자 보고서 | `ffffd35dd82d1231e6a9b9014d34c8875ded7d75fa5d1f23a3fcb59659b151ef` |
| `tools/tok.mjs` | 조항 7 (ㄷ)의 토큰(jtree codeAsRead) | `c04aa262a32481e46262f7f8c2b4a108050bfaccc3fb69e639d1744a8bd09c60` |
| `tools/judge.py` | 판정자 프롬프트 짓기 · 판정 모으기 | `11a7f2af0b2824167877597027c9fd360e1771f59bec37807939e3e224187984` |
| `tools/tally.py` | 셈(갈림은 불리한 쪽) | `eb20c4cfba2eb6df30203ea08b70b6644e53fa3c0e367b3f67b0514a8d9f1f60` |
| `tools/decide.py` | 결정 규칙 | `464b82d07b20d1d640c101c7c01a3eb31ae57d0e46e7c5ff936e362411c05d5a` |
| `tools/count.py` | 기계 셈(꼬리표마다) | `10f62077d5a7c6842f1a699733fcc23175349987b9019a6d97958de30be96ebd` |
| `tools/precall/precall.py` | 부르기 전 관문 | `0612362d86bc3330cc5f016cce47313593cb64501a94646f6bd6777ace46d27c` |
| `tools/precall/gen.mjs` | 부르기 전 관문 프로그램(설계 final/wide/gen.mjs 사본) | `ab77227dd000e3b2cf67c5841acdc64819cc8324e5871870c7218cb0397fd22a` |
| `tools/precall/realpar.py` | 진짜 돌리는 쪽(B5, 설계 사본) | `8db18fad021c0284747e80aac5dd8eb3f5edefd897d0802173395c774bd3106e` |
| `tools/precall/cmpwant.py` | 평가기와 진짜 실행 견줌(설계 사본) | `3ab4b61c2db076bbcbfc31b85c22e842e37e5d07a4554a70cc7a035525228561` |
| `tools/precall/learner.mjs` | 학습자 실행(changedRunFor의 out) | `4bba0dda837f8acf1243175b4ac38e012dd295c34712fbbf9310c9395097110b` |
| `tools/precall/mkengine.mjs` | 엔진 런타임 고정물 | `80d3f6996ce04f0103d8cba089280c66334084db65db9ec9e9db3983192d19fc` |
| `tools/precall/wide-records.jsonl` | 넓은 코퍼스(설계 final/wide/records.jsonl 바이트 사본) | `f852c740ae1408a4401b364737a58a1b57bcb38afc5e95b749c18bc4b519ef8a` |
| `names/append113.py` | 이름 목록 덧붙임(G2-measured-113) | `bf5c23e217096be0a95bc8cd7baa1a9e7b40c0a2f9da4ea19ffd0348d35bb406` |
| `d34/make.py` | D34 하네스 잡기 · 견줌(sonnet 실행 길) | `bbb34934f7af36d27ea59503d3df42d3fbb4fed1fa01fd535f90d7fcc50905ed` |
| `judge/tpl-judge.md` | 판정자 틀 | `cf3cf5e7f962a1eb09a4061aee24ed95e800286d204bedba80b177faab05cb8d` |
| `judge/stance-G2.md` | 판정자에게 주는 입장(이 절에서 자름) | `caafd7eefdb57299ac8aeb4ec9bc9c79e311438c565ea64175896b4b723a1296` |
| `probe/call.sh` | 프로브 세션 | `b6f1af4940d1d8ece0560b1d54d431d01d851d15af573279584055d06c8339dd` |
| `probe/precheck.sh` | 앞 'ok' 세션 | `723d1aef9346ee8d1da82fc5df727d9065b7f5127edb06f634bafdf0b188f498` |
| `probe/record.py` | 세션 기록 읽기 | `9c18195b8c0925ac5160217d279e4c5ec8cab3b79e47b36cda5448df1ba340ee` |
| `probe/mod/hooks/register.ts` | 프로브 mod(/g2probe) | `d8b9da9b6a7b4e0d5a4893b155fb132cd82a2de40278da044d97da3f8f5969b0` |
| `probe/mod/hooks/notes.ts` | 프로브 notes.ts(= mtree) | `4b36cf9d1d7d0bd1aea179b9f865a1354b72d666c11789a890beb26ba7f54b99` |
| `probe/mod/hooks/newrun.ts` | 프로브 newrun.ts(= mtree) | `393ed29b414cb784e3e70e1e06a79637e6a5f0bbd7a053c2a765a3cf51b21943` |
| `probe/mod/hooks/hooks.json` | 프로브 mod | `c835c92d8e1159d20a40ca78ad654da7433942c3694ffeda0b376b0c4dfd52cf` |
| `probe/mod/tsconfig.json` | 프로브 mod(allowImportingTsExtensions) | `022c66e39a26a7f12145aa1e0c045e3494087eb27074d530d02096de2b8e6cbf` |
| `probe/mod/.claude-plugin/plugin.json` | 프로브 mod | `85ebbae392b04d3e45b4615b6fe674cd7544906c12c4feb527826b304de73815` |
| `tap/call.sh` | 탭 세션 | `fdd843566b03db1714fbc9f51e9ccbd4575ee9bf5b1114a3daeb91f4249881dd` |
| `tap/tap.py` | 탭(묶음 1과 같음) | `e8d8174b09e11c74e6d744e4c44bc62033436d2ab35be6daa95d27026d17db9b` |
| `tap/mod/hooks/register.ts` | 탭 mod(/g2tap) | `eae56ed057cf37bb2ba32235dcbf0cf70546b3bb6bda526076851dea8f21b114` |
| `tap/mod/hooks/hooks.json` | 탭 mod | `c835c92d8e1159d20a40ca78ad654da7433942c3694ffeda0b376b0c4dfd52cf` |
| `tap/mod/tsconfig.json` | 탭 mod | `88437ec880f7008b5df208a95a7d47330f0e3a8204d78d6c5cc272e5941c3511` |
| `tap/mod/.claude-plugin/plugin.json` | 탭 mod | `8067d6ffee4f8b1bc7dcdade37a452ef647e9315e1f5f4e619a67690dd143cfd` |
| `mtree/hooks/notes.ts` | 짓기 트리(5c27746) | `4b36cf9d1d7d0bd1aea179b9f865a1354b72d666c11789a890beb26ba7f54b99` |
| `mtree/hooks/newrun.ts` | 짓기 트리(5c27746) | `393ed29b414cb784e3e70e1e06a79637e6a5f0bbd7a053c2a765a3cf51b21943` |
| `mtree/hooks/register.tsx` | 짓기 트리(5c27746) | `dd8a5def01596e19221a8de0718acb23684b239bba0a12315bc9d540c43a2182` |
| `jtree/hooks/notes.ts` | 읽기 트리(export 넷만 더함) | `beb5f20913a81438931f90586ec2bf6cd587065053b0eae1693e1fd6fbca236a` |
| `tools/mkengine113.mjs` | 엔진 실행 기록(짓기 때) | `d01028c4ab4bbc0ccc5312414ea98e0ce8559cfa0c828855c2762f31ae6c8c9f` |
| `tools/mkengine113.diff` | 엔진 실행 기록 도구의 바꿈(짓기 때) | `a24c3f3e2795e91306677051100ea388b387307c98c992f87a5e4b355e1f1cc7` |
| `tools/nodecmp.mts` | node 견줌(짓기 때) | `475dd2f7e9ccff05575cfb87bfedeeb62766ba30fba37e833ed0fc0d10d3c22f` |
| `tools/probe_off.mjs` | 끈 바이트(짓기 때) | `e7f9969b339031c78e6a910fc24e657b06c9dc4e05f53efde22ec318e5a09673` |
| `tools/probe_off.diff` | 끈 바이트 도구의 바꿈(짓기 때) | `72851ad0026f5960b568210ea08c46ae8107f93ce2ffac26a1876123f34b327f` |
| `tools/mut.py` | 돌연변이 탐침(짓기 때) | `859b39f4822294548cb0ff9464e63d3754f835f40c81b1d9874cc21a3f20dba8` |
| `tools/mutrun.sh` | 돌연변이 탐침 실행(짓기 때) | `d8e22bef380ed86a6d41d728c165c20ee9d68a03997120c36eb9b2ae07c063e3` |
| `../cli/pinned.sh` | 고정한 길(묶음 0, chmod 555) | `bbe2dc0a6212d1865c4d253bdc451645174c3d5cceef3a0feb662d5c791aba5f` |
| `../d26/rulewide113.mjs` · `g2haiku.sh` · `remake.py` | D26 재확인 도구(묶음 0의 표 그대로, 짓기 때 씀) | 1/4 첫 커밋 표 |

````
