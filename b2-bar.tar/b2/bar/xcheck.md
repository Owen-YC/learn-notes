- 새 하위 에이전트 하나가 설계 G2의 name · bar · stance · decisionRule · samples(devNamesToAvoid 목록은 뺌) · calls · risks · perModel · ownerQuestions 필드와 계획 묶음 2의 notMeasured · barSource · samples · calls · judges · stop · preCallGate · switchCommit · usage 필드를 이 절의 첫 판(고치기 전)에 견주었습니다. 고정한 CLI 2.1.329의 `claude -p --model opus --tools '' --output-format json`, 빈 폴더, 떼어 낸 러너 `gen/run.sh bar/xcheck files json`(PROJ 0.01)으로 한 번 불렀습니다(2026-11-21 04:07:52 ~ 04:09:05 UTC; 러너 관문 five_hour 0.44 · seven_day 0.64 + 0.01 → 넘음; 앞뒤 기록 같음; 거절 0, safety_stops 0).
  - 프롬프트 `impl113/b2/bar/xcheck/parts/xcheck-1/prompt.md` sha256 `ff03c42d377e2753a6c325ae00daab5e54a6943e8b4c69e56986812ee5be326a`, 답 글(result.txt) sha256 `b8eae2917c89df6419b66db04c61271fff23a6b3fb265ea5ee64e356df7450dd`.
- 지적 7개를 모두 고쳤습니다(수 · 조항은 바꾸지 않음).
  1. (clause-missing) B7에서 'blind'(가린)가 빠졌던 것을 '꼬리표마다 가린 판정자 둘'로 고쳤습니다.
  2. (number) '사용량 관문'의 식이 'c_sub 0.04'처럼 단위 값과 곱의 결과를 붙여 적어 14 × 0.04로 읽혔습니다. 단위(c_stage 0.01, c_sub 0.003, c_agent 0.01; 계획 usageGate 셋째 항목)를 괄호로 적고 곱의 결과를 '='로 나눠 적었습니다(0.01 + 0.04 + 0.11 = 0.16, 쓰는 쪽 9 × 0.003 ≈ 0.03 등). 수는 그대로입니다.
  3. (conflict) 끊긴 · 무효 퀴즈 스테이지의 'quiz-r2': 계획 commonPerBatch(M-4 줄 · cutStageRule)는 다른 날 한 번 더를 허락하고, 계획 batches[1].stop은 'M-4 → sonnet 끔, 다시 재지 않음'이라 합니다. 첫 판은 너그러운 쪽(quiz-r2)을 따랐습니다. 더 엄한 쪽으로 고쳤습니다: G2 퀴즈 스테이지가 M-4로(끊김 포함) 무효면 sonnet은 끔이고 다시 재지 않습니다('읽는 법' 1, '이 묶음이 정한 것'). 아무것도 재기 전이므로 `tools/stage.sh`가 quiz-r2를 늘 거절하도록 고쳐 다시 얼렸고(2026-11-21 04:10:45 UTC, chmod 444; 바꾸기 전 sha256 `f61650c5a73320391dc7633ea19b01d178fcb4f963d3ac8e370a0a5f693b6299`), 스테이지 러너 시험을 다시 돌려 같은 끝을 얻었습니다(quiz-r2는 거절). 다른 63개 파일의 sha256은 첫 얼림(04:06:51 UTC)과 같습니다.
  4. (conflict) 설계 samples.avoid(NAMES-all.txt의 모든 이름 + 견본.md 기록 이름)와 계획의 짓는 도구(거름 (a)–(c))가 다릅니다. 계획 쪽을 따르고 '밝혀 둔 벗어남' 6으로 밝혔던 것에, 피할 절이 설계보다 좁다는 것과 거절은 check.py가 NAMES-all.txt 전체와 넓힌 코퍼스로 한다는 것을 덧붙였습니다.
  5. (clause-changed) '1.12.0 기준과 다른 점'에서 고친 조항 목록에 빠졌던 조항 0을 넣었습니다(0 · 1 · 2 · 3 · 13).
  6. (other) H_sonnet 2048이 1.12.0 값을 다시 쓴 것이 아니라 1.13.0 보정에서 새로 잰 값(보정 기록의 sonnet 2회 줄)이라는 것을 두 곳에 밝혔습니다.
  7. (other) 설계 필드 이름을 'samples.devNamesToAvoidCount의 285개(이름은 samples.devNamesToAvoid)'로 바로잡았습니다.
- 고친 곳에 입장 글은 없어서 판정자에게 주는 `judge/stance-G2.md`는 그대로입니다(다시 지은 자른 글이 얼린 파일과 바이트까지 같음을 스크립트로 확인). 설계 stance.text와 ownerQuestions가 이 절에 글자 그대로 든 것도 스크립트로 확인했습니다.
- 다시 확인을 부르지는 않았습니다(묶음 1과 같이 한 번 확인하고 고침).
