"""learn-notes 1.13.0 G2 sonnet (batch 2): composes the bar section of docs/qa/견본.md from bar/part1-4.md, the design's
stance text and ownerQuestions (verbatim), and the frozen tool table; writes bar/section.md and, with 'stance', cuts
judge/stance-G2.md (the section's '#### 판정의 입장' up to '#### 결정 규칙', as 1.12.0 did).
usage: compose.py stance            -> judge/stance-G2.md (refuses an existing one unless REFREEZE=1)
       compose.py section <BAR_UTC> -> bar/section.md (reads bar/tools.sha256, bar/avoidtest.md, bar/xcheck.md)"""
import hashlib, json, os, sys
S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2"
DES = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G2.json"
d = json.load(open(DES, encoding="utf-8"))
rd = lambda p: open(f"{S}/bar/{p}", encoding="utf-8").read()
oq = " / ".join(d["ownerQuestions"])
text = (rd("part1.md").replace("{{OWNERQ}}", oq) + "\n" + rd("part2.md").replace("{{STANCE}}", d["stance"]["text"]) + "\n" + rd("part3.md") + "\n" + rd("part4.md"))
a, b = text.index("#### 판정의 입장"), text.index("#### 결정 규칙")
stance_cut = text[a:b].rstrip("\n") + "\n"
if sys.argv[1] == "stance":
    p = f"{S}/judge/stance-G2.md"
    if os.path.exists(p) and os.environ.get("REFREEZE") != "1":
        sys.exit("refuse: judge/stance-G2.md exists")
    if os.path.exists(p):
        os.chmod(p, 0o644)
    open(p, "w", encoding="utf-8").write(stance_cut)
    print(hashlib.sha256(stance_cut.encode("utf-8")).hexdigest())
    sys.exit(0)
utc = sys.argv[2]
desc = dict(json.load(open(f"{S}/bar/tools-desc.json", encoding="utf-8")))
shas = [l.split("  ", 1) for l in open(f"{S}/bar/tools.sha256", encoding="utf-8").read().splitlines() if l.strip()]
tsha = hashlib.sha256(open(f"{S}/bar/tools.sha256", "rb").read()).hexdigest()
rows = ["| 파일 | 하는 일 | sha256 |", "| --- | --- | --- |"] + [f"| `{p}` | {desc.get(p, '')} | `{h}` |" for h, p in shas]
rows += ["| `../cli/pinned.sh` | 고정한 길(묶음 0, chmod 555) | `bbe2dc0a6212d1865c4d253bdc451645174c3d5cceef3a0feb662d5c791aba5f` |",
         "| `../d26/rulewide113.mjs` · `g2haiku.sh` · `remake.py` | D26 재확인 도구(묶음 0의 표 그대로, 짓기 때 씀) | 1/4 첫 커밋 표 |"]
head = (f"목록 파일 `impl113/b2/bar/tools.sha256`(chmod 444) sha256 `{tsha}`, 파일 {len(shas)}개. 표의 경로는 `impl113/b2/` 기준입니다. "
        "`mtree/` · `jtree/`는 트리 통째로 쓰기를 막았습니다. 쓰는 쪽과 판정자가 돌 때 각 스테이지는 `../NAMES-all.txt`의 그때 sha256을 자기 폴더에 적습니다. "
        "얼릴 때 확인의 환경 값: `NAMESALL` = `impl113/NAMES-all.txt`(지금 `aca62354e1ff48b4dc03fef16cfe7a07fe1788939bda094be6800ac2dfc0fdb3`, 덧붙인 뒤의 값은 견본 커밋에 적음), `CORPUS_GLOBS` = check.py의 기본 목록(계획 freezeCheckInputs의 코퍼스), `RAW` = `frozen/raw.json`, `TOPUPS` = 보탬을 돌렸을 때 그 뿌리 목록.\n\n")
text = text.replace("{{TOOLTABLE}}", head + "\n".join(rows)).replace("{{BAR_UTC}}", utc)
text = text.replace("{{AVOIDTEST}}", rd("avoidtest.md").strip()).replace("{{XCHECK}}", rd("xcheck.md").strip())
assert "{{" not in text, text[text.index("{{"):][:80]
open(f"{S}/bar/section.md", "w", encoding="utf-8").write(text)
print(len(text), hashlib.sha256(text.encode("utf-8")).hexdigest())
