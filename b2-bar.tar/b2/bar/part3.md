#### 결정 규칙

설계 decisionRule(옮김)
1. sonnet만, sonnet의 수로만(R1–R4). (가) = 잰 비슷한 코드 20자리 가운데 저장된 문항이 두 판정자 아래에서 조항 7 (ㄱ)–(ㅈ)과 조항 16 · 17 · 18을 갖춘 자리의 수. 거절, 빈 답, 시간 끊김, 읽히지 않음, 대신 냄(isOwn false), 모자람, 갈림, 정하지 못한 자리는 놓침. (나) = 읽힌 문항 가운데 A가 틀린 문항의 수(조항 6 · 11 · 16; 갈림이나 정하지 못함 = 틀림).
2. 부르기 전 관문이 실패하거나, 보정이나 앞뒤 기록이 맞지 않으면: 회차 없음, sonnet은 끔 그대로.
3. 넘음 ⇔ (가) ≥ 16 그리고 (나) = 0. 넘으면 다음 커밋이 MODEL_SWITCHES.sonnet을 `{ ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2, isChangedRun: true }`로 둡니다(R6, SHIPPED 다시 고정, 진짜 플러그인 길로 R9 옛 빌드 확인, R10 문서, haiku의 D26 다시 확인). 아니면 sonnet은 `{ ...SWITCHES_OFF, isRuleWide: true }` 그대로입니다.
4. haiku: 결정 없음. 그 칸은 B14 다시 확인이 요청 · 고르기 · 읽기가 바이트까지 같다고 보이는 동안만 켬(rungChangedStep 2, isChangedRun false) 그대로이고, 아니면 그 묶음에서 끔입니다(규칙 5 / D26). 어느 쪽으로도 옮기지 않습니다.
5. 한 회; 다시 굴리지 않음; 뒤의 넓히기(B9)는 새 회차가 필요하고, 좁히기는 필요 없습니다.

계획 묶음 2의 글(barSource.decision, 같은 규칙): MODEL_SWITCHES.sonnet = `{ ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2, isChangedRun: true }` ⇔ 넘음; 아니면 `{ ...SWITCHES_OFF, isRuleWide: true }`. haiku: 결정 없음(B14만). RUNG_CHANGED_STEP과 IS_CHANGED_RUN은 끔 그대로(D1). 한 회; B9 넓히기는 새 회차가 필요함.
- 판정자(계획 judges): sonnet 꼬리표에 가린 opus 판정자 둘, 어느 쪽도 다른 꼬리표를 보지 않음; 갈림이나 정하지 못한 경우는 기능에 불리하게 셈(B7). 기계: 진짜 돌리는 쪽이 모든 자리를 매기고(B5), 얼린 셈 스크립트가 셈.
- 값 커밋(계획 switchCommit, 넘을 때만): MODEL_SWITCHES.sonnet = `{ ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2, isChangedRun: true }`; route SHIPPED; 켠 값으로 진짜 플러그인 길을 거친 R9 옛 빌드 확인(일곱 빌드); 켠 퀴즈마다 recheckRemap; 켠 값에서 돌연변이 탐침 2개 이상; 잰 프롬프트를 다시 만들어 바이트까지 같음; G2 haiku의 D26(9/9, build.json, read.json), isRuleWide, 켰다면 isRuleDrill haiku; B14를 위해 평가기 블록의 sha256을 적음.
- 멈춤(계획 stop)
  - 짓기 트리에서 G2 haiku의 요청이나 고르기 다름을 없앨 수 없음 → 짓기 커밋 없음; 멈추고 알림. (이 묶음의 기록, 원문 밖: 짓기에서 다름 0, 5c27746 본문.)
  - 부르기 전 관문 실패 → 호출 없음, sonnet 끔(적음).
  - 회차 무효(M-10) 또는 M-4 → sonnet 끔, 다시 재지 않음.
  - 쓰는 쪽이 한 부르기에서 두 번 거절함(commonPerBatch.writerRunner가 정한 거절; 사용량 한도로 끝난 것은 WAIT) → STOP, 재지 않음(적음).
  - 읽힌 문항 가운데 틀린 A가 하나라도 있으면 회차는 못 넘음(멈추지 않음; 적음).

#### 모델마다 (설계 perModel; 개발 수는 기록만 · B-12, 결정에 들지 않음)

- haiku: 켬(1.12.0 잼 18/20, 틀림 0; rungChangedStep 2). 이 설계는 haiku를 건드리지 않습니다. 마지막 트리는 D26 증명 셋을 모두 지킵니다: 얼린 요청 9개를 바이트까지 다시 냄(D34 9/9, lines-haiku.jsonl 876c8efd…), build.json 같음, 얼린 답을 다시 읽은 read.json 05aa93f5… 같음(proofs/final). 모델 · 수준 · 언어에 걸친 진짜 플러그인 요청 14개가 HEAD와 파일럿 트리에서 같습니다(crit/bytes). 재지 않고, 아무것도 옮기지 않습니다. haiku 개발 대조군(기록만)은 20 가운데 18, 18, 20, 17, 18이고 91개에서 틀림 0이었습니다.
- sonnet: 잼(한 회). 마지막 개발 세트 D와 E(기록만, r2를 얼린 뒤 씀): 네 번 모두 20/20 남음, 조항 18로는 19/20(번마다 대신 냄 하나), 읽힌 문항 80개에서 틀림 0, 거절 0, 빈 답 0, 잘림 0, 시간 한도 0, 상한 닿음 0, 가장 큰 출력 545 토큰.
- 계획 notMeasured(옮김): haiku: 1.12.0부터 켬, 바이트까지 그대로 두고 다시 재지 않음(notMeasured.onNotReMeasured).

#### 견본

설계 samples 글(옮김)
- 쓰는 쪽(whoWrites): 새로 가린 opus 하위 에이전트(`claude -p --model opus --tools ''`, DISABLE_AUTOUPDATER=1, cwd는 빈 폴더). 이 설계, 프롬프트, 입장, 범위, 어느 모델을 재는지를 보지 않습니다. 1.12.0 G2의 잰 쓰는 쪽 프롬프트(impl112/b2/gen/writer-A.md, writer-B.md와 *-end.md 파일)를 글자 그대로 쓰되, 다음만 다릅니다: 부분마다의 기록 수, id, 언어(부르기마다 기록 10개 이하, G3 STOP 교훈); 그 부분에 맞춰 줄인 섞임 최소; 그리고 이름만 든 피할 절. 이것이 개발 parts.py 절차(dev/gen/parts.py)이고, 기준 커밋에 sha256으로 얼립니다. 견본은 sonnet을 위해 쓰거나 고르지 않습니다(M-12).
- 짜임(layout): 먼저 쓰는 쓰는 쪽 부분: A1–A5, 각 js 10(js 50); P1–P3, 각 py 10(py 30); B, 1.12.0과 같은 채우는 것(내 코드 3 = ts, js, py 고침; 왜 2; 다시 도전 2). 모자란 언어마다 미리 정한 보탬 한 번(T1 js 10, T2 py 10), 그다음 STOP. 첫 몫이 파일럿(js 25, py 15)보다 큰 것은 개발 세트 하나(B)가 잴 js 자리 13에 js 구성원 11로 끝났기 때문입니다. 개발 닿음(js 44.5%, py 52.6%)으로 보면, 한 언어가 보탬 뒤에도 모자랄 확률은 1% 아래입니다.
- 구성원(membership): 구성원은 커밋된 트리의 sonnet 길 rungOf(sonnet 줄 + rungChangedStep 2 + isChangedRun true, withCode/changedRunFor를 거침)로만, 쓴 차례대로 정합니다. 처음 드는 js 15와 py 9를 가집니다(잴 js 13 · py 7과 언어마다 예비 2, 1.12.0 짜임). 보탬 뒤에도 채우지 못한 잴 자리는 (가) 놓침(조항 19)이고, 다른 언어의 기록으로 채우지 않습니다. haiku 견본과 haiku의 범위는 바뀌지 않습니다.
- 퀴즈 짜임(quizLayout): 1.12.0 짜임 그대로: Q1–2 [c,c,c], Q3–5 [c,c,내 코드], Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; 단계 2와 3을 번갈아; 모든 개념 때 됨; 수준 beginner.
- 얼림(freeze): chmod 444; sha256, 쓴 쪽, UTC 시각을 견본.md에 적음. D34: 시험 하네스에서 models.sonnet { rungChangedStep: 2, isChangedRun: true }로 잡은 요청 9/9가 어느 호출보다 먼저 도구의 프롬프트 파일과 바이트까지 같아야 함.
- 부르기 전 관문(preCallGate): 기준에 적고, 얼린 뒤 어느 호출보다 먼저 돌립니다. 얼린 잴 기록과 예비 기록 하나하나를, 모든 곳(changeSites isAll)과 얼린 final/wide/gen.mjs 목록의 모든 값(숫자는 runValues의 넷, 0–5, 10, n/2, n+5, n+10, 10n과 상한; 따옴표가 같은 다른 모든 문자열; 목록에 든 모든 대안)으로, 커밋된 평가기와 진짜 돌리는 쪽(B5)이 돌립니다. 요구: 받아들인 다름 0, 같은 프로그램에서 엔진 런타임이 node와 같음(claude plugin test 고정물), 학습자 실행이 모두 out과 같음. 다름이 하나라도 있으면 호출 전에 회차를 멈춥니다. 칸은 끔이고, 실패를 적으며, newRun을 고쳐 1.13.0에서 다시 시도하지 않습니다(newRun을 고치면 새 설계).
- 피할 것(avoid): 이름만, 견본.md 산문은 넣지 않고 모델 · 별칭 · 스위치 낱말도 넣지 않음: impl113/NAMES-all.txt의 모든 이름(9,066줄; 아래 G2-dev-113 이름 285개, impl112 G2 개발 이름 133개, 1.12.0 G2 잰 이름, G3-dev-113 이름 포함)과 docs/qa/견본.md의 기록 이름 칸. 새 잰 이름은 impl113/NAMES-all.txt에 'G2-measured-113' 꼬리표로 들어갑니다. (이 묶음의 기록, 원문 밖: 설계 때 9,066줄이던 NAMES-all.txt는 묶음 1의 덧붙임 뒤 지금 10,674줄, sha256 `aca62354e1ff48b4dc03fef16cfe7a07fe1788939bda094be6800ac2dfc0fdb3`입니다. 설계 samples.devNamesToAvoidCount의 285개(이름은 samples.devNamesToAvoid)는 그 안에 꼬리표 'G2-dev-113'으로 들어 있습니다.)

계획 묶음 2의 글(samples, 같은 짜임)
- 짜임: 쓰는 쪽 부분 A1–A5 각 js 10(js 50), P1–P3 각 py 10(py 30), B는 1.12.0과 같은 채우는 것(내 코드 3 = ts, js, py 고침; 왜 2; 다시 도전 2)을 세 가지 채우는 것 종류의 기록 7개로 한 번에. 그 부르기는 '부르기마다 견본 종류 하나'의 밝힌 예외입니다(1.12.0 writer-B.md 글자 그대로; 1.12.0에서 거절 없이 돌았음; 7 ≤ 10)이고, 기준 커밋에 그 수와 함께 이름을 적습니다(위 '밝혀 둔 벗어남' 5). 쓰는 쪽 부르기 9번, 각 기록 10개 이하; 모자란 언어마다 미리 정한 보탬 한 번(T1 js 10, T2 py 10), 그다음 STOP. 쓰는 쪽 프롬프트 = impl112/b2/gen/writer-A.md, writer-B.md, *-end.md를 글자 그대로, 부분마다의 기록 수 · id · 언어, 줄인 섞임 최소, 이름만 든 피할 절만 다름(dev/gen/parts.py 절차, 기준 커밋에 sha256으로 얼림).
- 구성원: 커밋된 트리의 sonnet 길 rungOf(sonnet 줄 + rungChangedStep 2 + isChangedRun true, withCode/changedRunFor를 거침)로만, 쓴 차례대로: 처음 드는 js 15와 py 9(잴 js 13 · py 7 + 언어마다 예비 2). 보탬 뒤에도 채우지 못한 잴 자리는 (가) 놓침(조항 19); 다른 언어로 채우지 않음.
- 퀴즈 짜임: Q1–2 [c,c,c], Q3–5 [c,c,내 코드], Q6–7 [c,왜,c], Q8–9 [다시 도전,c,c]; 단계 2와 3을 번갈아; 모든 개념 때 됨; beginner.
- 얼림: chmod 444; sha256, 쓴 쪽, UTC를 견본.md에; 이름을 NAMES-all.txt에 'G2-measured-113' 꼬리표로 덧붙임; 그다음 부르기 전 관문; 그다음 어느 호출보다 먼저 D34 9/9(하네스 models.sonnet { rungChangedStep: 2, isChangedRun: true }).
- 피할 것: NAMES-all.txt(G2-dev-113 285개, G2-dev, G2-measured, G3-dev-113, G3-dev-retry 포함)에서 짓는 avoid113.py 출력(calibration.avoidBuilder): 이름만, 짓는 도구가 밝힌 대로 거름. 이것은 design/G2/dev/gen/parts.py가 만든 피할 절을 바꾸며, 기준 커밋이 그 바꿈을 밝힙니다(위 '밝혀 둔 벗어남' 6). check.py(NAMESALL = impl113/NAMES-all.txt)는 온전한 이름 목록과 넓힌 코퍼스(commonPerBatch.freezeCheckInputs)에 견주어 기록을 거절합니다.

피할 목록 짓기(calibration.avoidBuilder의 거름, 짓는 도구가 하는 그대로 옮김; `gen/avoid113.py`는 `impl113/gen/avoid113.py`와 바이트까지 같은 사본)
- (a) 개념 이름은 꼬리표가 '견본'이 아닌 줄(기록 파일)에서만 옵니다: 개발 이름의 ': ' 앞 주제, 2–30글자, 한글, 파일 이름이 아님, 따옴표로 시작하지 않음. '견본' 꼬리표 줄은 개념 이름을 주지 않습니다.
- (b) haiku|sonnet|opus|fable|claude|anthropic|model|isRule|rung|isThink|isBase|isChanged|worked|stance|judge|verdict|calib|impl11|alias|gateway|bedrock|vertex|override|provider|모델|채점|견본|판정|프롬프트 에 대소문자 없이 걸리는 항목(개념 · 파일 · 코드 이름, 어느 줄에서 왔든)은 뺍니다.
- (c) 파일 이름과 코드 이름은 기록 파일 줄(꼬리표 ≠ '견본')과 names.json(impl111/b7/gen, 1.8.0 · 1.9.0의 파일 · 함수 이름)에서 옵니다(파일 이름은 코드 · 문서 확장자를 가진 항목의 경로 마지막 부분, 코드 이름은 세 글자 이상인 식별자이고 K01 · pT01 같은 id가 아님). '견본' 꼬리표 줄은 공백이 없고, 경로의 어느 부분도 judge, tools, calib, gen, stage, frozen, pilot, audit, review, fix, sw, cli, probe, d26, oldprobe, proofs, design, b<숫자>, b<숫자>r, impl11<숫자>가 아니며, 마지막 부분이 impl111 · impl112 · impl113 아래 어느 tools.sha256 / SHA256SUMS 표에 적힌 파일 이름도 아닐 때만 파일이나 코드 이름을 줍니다(그 표 이름 목록은 짓는 도구가 돌 때 지어 함께 sha256을 냄). 공백이 든 '견본' 항목(산문 조각)은 쓰지 않습니다. (c′) 어느 줄에서 왔든 그 표 이름 목록에 있는 파일 이름은 파일 목록에서 뺍니다(이름 목록에는 남아 얼릴 때 확인이 계속 거절함).
- 쓰는 쪽에게 주는 것은 이 셋(개념 이름 · 파일 이름 · 코드 이름)을 정렬해 ' · '로 이은 절뿐이고, 손으로 고치지 않습니다. 더하여 개발 절차대로, 같은 세트의 앞 부분이 이미 쓴 개념 이름을 한 줄로 붙입니다(아래 '도구가 글을 읽는 방식' 2).

#### 부르기

설계 calls 글(옮김)
- 플러그인이 부르는 그대로(D20), impl111/probe mod의 사본으로. 퀴즈마다: $.model.complete({ model: 'sonnet'(설정 글자 그대로), effort: 'low', system: QUIZ_SYSTEM, prompt: redactText(quizPrompt(picks, 'beginner')).text, maxTokens: 4600, timeoutMs: 90000 }). 4개씩 부르고, $.clock으로 시간을 재며, 답은 fixEscapedTicks를 거쳐 커밋된 parseQuiz로 읽습니다. 고르기는 makeQuiz가 짓는 그대로(codeFor, changedRun → changedRunFor인 withCode, rungOf, ladderMixed, pickForRung), 커밋된 트리에서 sonnet의 낸 줄(isRuleWide true)에 rungChangedStep 2와 isChangedRun true를 더해 짓습니다(M-13).
- sonnet 호출 9번의 한 회. haiku는 부르지 않습니다(그 칸은 켬이고 바이트까지 같다고 증명됨, 규칙 5 / D26). api-error(429/5xx, 토큰 0, 글 없음)만 두 번까지 다시 보냅니다. 빈 답이나 거절된 답은 모두 지나가는 탭으로 한 번 보내 stop_reason과 stop_details.category를 적습니다(기록만). M-4의 10% 규칙이 걸립니다.
- CLI: 그때 설치된 Claude Code의 새 고정 사본(2.1.329 이상), DISABLE_AUTOUPDATER=1. 먼저 M-5/M-10 보정(H_sonnet을 다시 잼; 1.12.0 값 2048을 다시 쓰지 않음). `claude --version`, system/init 모델, modelUsage 키를 앞뒤로 적습니다. 보정 기록과 어긋나면 회차는 무효이고 칸은 끔입니다.
- 사용량 관문(five_hour ≤ 0.60, seven_day < 0.80), 떼어 낸 러너, 러너 PID나 상태 파일을 기다림(`while pgrep -f`는 절대 안 씀). 백업 tar의 sha256은 견본.md에 적음.
- 꼬리표: sonnet 회차는 난수 꼬리표를 받습니다. 짝 파일은 봉하고(sha256만), 짝을 열기 전에 쓴 어느 파일도 모델 이름을 적지 않습니다.

계획 묶음 2의 글(calls)
- sonnet: 퀴즈 호출 9번: $.model.complete({ model: 'sonnet', effort: 'low', system: QUIZ_SYSTEM, prompt: redactText(quizPrompt(picks, 'beginner')).text, maxTokens: 4600, timeoutMs: 90000 }), 4개씩, fixEscapedTicks, 커밋된 parseQuiz; 고르기는 커밋된 트리에서 sonnet의 줄(isRuleWide true) + rungChangedStep 2 + isChangedRun true로 makeQuiz가 짓는 그대로(M-13).
- haiku: 호출 0.
- 다시 보내기: api-error(429/5xx, 토큰 0, 글 없음)만, 두 번까지; 빈 답/거절된 답은 stop_reason과 stop_details.category를 보러 한 번 탭(기록); M-4 10% 규칙.
- 스테이지: 하나, 퀴즈 sonnet.
- 쓰는 몫(계획 usage, 기록): sonnet 호출 9번(요청 약 2,500자, 출력 각 ≤ 약 550 토큰); 쓰는 쪽 호출 ≤ 11번, 판정자 2, 번역 확인 1(≈ 14 × c_sub); 에이전트 단계 ≈ 11; 부르기 전 관문 CPU 약 10분. 묶음 예측 0.16(commonPerBatch.usageGate[2]의 식); 회 R = 0.01.

이 묶음이 정한 것(위 글을 도구로 옮긴 자리, 기록)
- 모델-스테이지: `quiz` sonnet 하나(계획 사용량 관문 자리 'G2 quiz'). haiku 스테이지는 없습니다(`tools/stage.sh`가 거절).
- 떼어 낸 러너(러너 규칙): `tools/stage.sh quiz sonnet`을 setsid nohup으로 띄우고, 에이전트는 STARTED · 시도마다의 status.jsonl · DONE · summary.json · 러너 로그만 봅니다. 러너는 (1) STARTED가 없고, `frozen/d34/compare.json`이 9/9이며, `frozen/precall/result.json`이 pass true인지 보고, (2) 고정한 길로 앞 'ok' 세션(`probe/precheck.sh`)과 `tools/gate.py pre`(앞 기록이 1.13.0 보정과 같음 · five_hour ≤ 0.60 · seven_day + 0.01 < 0.80 · 회 R 0.01 · 다른 워크플로 없음을 에이전트가 ONLY_WORKFLOW=1로 밝힘)를 거친 뒤에만 STARTED를 쓰고, (3) 시도 1(`call-1`), 그리고 입장 2의 api-error 줄(상태 429 · 5xx, 글 없음, 출력 토큰 0)인 퀴즈만 얼린 줄 그대로 시도 2 · 3으로 다시 보내고, (4) 뒤 기록(`tools/gate.py after`)과 M-4 10%를 상태 수로만 봅니다. 엔진이 던지면 끝(M-4 넷째 줄). 끊긴 스테이지(한 시도가 out.json을 남기지 못함)는 계획 cutStageRule대로 상태 수로만 summary.json을 쓰고 끝(9)입니다. 10%를 넘으면 무효이고 sonnet은 끔, 다시 재지 않습니다(계획 batches[1].stop; 'quiz-r2'는 이 묶음에서 쓰지 않으며 러너가 거절; 아래 '읽는 법' 1).
- 모델 기록(M-10, D19): 앞 기록은 앞 'ok' 세션과 고정한 길의 --record, 뒤 기록은 시도마다의 프로브 세션(세션마다 앞뒤 claude --version, 턴마다 init model, result의 modelUsage 키)과 끝의 --record입니다. 모두 '보정 기록 (1.13.0)'(2.1.329, 고정 사본 sha256 `30e2724e…6d6d` · `c3484833…8e74`, sonnet 별칭의 풀린 id)과 같아야 합니다.
- 빈 답 · 거절의 탭(기록만): `tools/tapsend.py`.
- 판정자와 번역 확인: 계획 commonPerBatch.writerRunner대로 `gen/run.sh files json`(떼어 낸 러너, 고정한 길, 앞뒤 'ok' 세션 기록, 자기 관문)으로 부릅니다.

#### 위험 (재기 전에 적음)

설계 risks(옮김)
- (나)는 평가기에 묶여 있습니다. 시험한 코퍼스 밖의 학습자 코드에서 평가기 결함이 나면, 실행 중 확인 없이 틀린 정답이 저장됩니다: 진짜 출력을 쓴 학습자가 틀림으로 매겨지고, 그 개념은 단계 0으로 갑니다. 줄이는 것: 기본이 거절인 닫힌 부분 집합; 15,895 + 6,000 + 384 대조 프로그램에서 다름 0; 엔진 = node; 부르기 전 관문; 조항 16; 뒤의 어느 newRun 고침에도 B14. 남는 위험이고 밝혀 둡니다.
- 판 차이: 평가기는 시험한 대로 Node 22와 CPython 3.11에 맞습니다. 다른 판의 학습자는 실수 표기나 dict와 str의 모서리 사례에서 다른 출력을 볼 수 있습니다. 부분 집합(집합 찍기 없음, dict/list 찍기 없음, 기본 값 찍기만)이 이것을 작게 합니다. 적어 둡니다.
- 거절 분류기: r2 문구는 36번(sonnet 호출은 모두 105번) 돌았고 거절 0이었습니다. 분류기는 결정적이지 않아, 회차에서 거절이 나면 퀴즈마다 2–3자리를 잃습니다. 허용은 4자리입니다.
- 닿음: 통째 파일 기록의 약 48%(haiku 90%). sonnet 학습자는 비슷한 코드를 덜 자주 봅니다; 다른 개념은 내 코드로 묻습니다.
- 가르침의 질: 모델이 고르는 바꿈은 흔히 개념 줄에서 먼 데이터 값에 떨어지고, 어떤 값은 이상하지만 맞습니다('수면 -4시간'). 기준 문제가 아니고, 적어 둡니다.
- 절차: 파일럿이 설계 글의 '고침 하나' 규칙을 넘었습니다(주인 물음 0). 잰 회차 자체는 새롭고, 가리고, 미리 커밋한 것이라 그 결과는 영향을 받지 않습니다. 위험은 회차 하나를 쓴다는 것뿐입니다.
- 보정: H_sonnet은 다시 재야 합니다. 판이나 별칭이 어긋나면 회차는 무효입니다(칸은 끔).
- 잘린 답(1.10.0)은 개발 호출 105번에서 다시 나오지 않았습니다. 남는 위험으로 둡니다(그 퀴즈의 changed 자리를 잃음).
- 짓기 얽힘: 1.13.0의 G5(sonnet)와 G6(haiku) 짓기는 G2의 haiku와 sonnet 바이트를 지켜야 합니다(D26). G3가 뒤에 들어오면 그 newRun은 이것이어야 하고, 아니면 B14가 걸립니다.
- (이 묶음의 기록, 원문 밖) sonnet의 따라가기 거절(1.12.0 SCOPE 묶음 3의 사실: sonnet은 한 줄씩 따라간 과정을 글로 쓰라는 요청을 거절할 수 있음): 이 설계의 퀴즈 요청은 따라간 과정도, 출력도 쓰라고 하지 않습니다. 실행 길 자리에서 모델이 쓰는 것은 C 줄(고른 곳의 이름과 새 값) 하나뿐이고 T · Q · H · A를 쓰지 말라고 합니다(CHANGED_RUN_ASK). 설계 파일럿의 r2 문구는 36번(sonnet 105번) 돌아 거절 · 빈 답 0이었습니다(위 '거절 분류기' 줄). 거절된 답은 빈 답으로 남고 그 퀴즈의 자리는 (가) 놓침이며, 탭으로 stop_reason · stop_details.category만 기록합니다.
