import { describe, expect, test } from 'claude-code/testing'
import { newRun } from '../hooks/newrun'
import { CORPUS } from './fixtures/corpus2'

describe('newRun with printArgs in the engine runtime equals newRun under node, chunk 2 (records only)', () => {
  // Options before the body: the 2.1.329 kit takes test(name, options, body) only.
  test('the same lines or the same refusal', { timeoutMs: 120000 }, () => {
    const differ: string[] = []
    for (const [id, lang, code, want] of CORPUS) {
      const got = newRun(code, lang, { printArgs: true })
      if (JSON.stringify(got) !== JSON.stringify(want)) differ.push(`${id} ${JSON.stringify(got).slice(0, 120)} != ${JSON.stringify(want).slice(0, 120)}`)
    }
    console.log(`ENGINECHK chunk 2 programs ${CORPUS.length} differ ${differ.length}`)
    for (const d of differ.slice(0, 20)) console.log('ENGINECHK ' + d)
    expect(differ.length).toBe(0)
  })
})
