#!/bin/bash
# tool test only: a fake-claude quiz stage with one empty reply and one timeout (test/st/empty), for pipe.sh.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2
source <(sed -n '/^F=/,/^mkdir -p "\$S\/test\/st"/p' "$S/test/stagetest.sh")
mk empty
FAKE_SPEC='{"Q3":"empty","Q6":"timeout"}' ONLY_WORKFLOW=1 "$R/stage.sh" quiz sonnet > "$R.log" 2>&1; echo "empty stage exit $?"
