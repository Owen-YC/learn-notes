#!/bin/bash
# learn-notes 1.13.0 G2 sonnet (batch 2; from impl112/b2/tools/stage.sh, the 1.12.0 G2 quiz runner, with batch 1's
# 1.13.0 gate and cut-stage handling, impl113/b1/tools/stage.sh): the one model-stage of the round, quiz sonnet, run
# DETACHED (plan runnerRules), e.g.
#   ONLY_WORKFLOW=1 setsid nohup bash tools/stage.sh quiz sonnet > stage/quiz-sonnet.log 2>&1 < /dev/null &
# The 9 frozen quiz lines (frozen/lines-sonnet.jsonl). Refused unless frozen/d34/compare.json is 9/9 and the pre-call
# gate passed (frozen/precall/result.json "pass": true). haiku is not called in this round (refused).
# Refuses a stage whose STARTED exists (cut-stage rule: the main loop decides). Before: an 'ok' session
# (probe/precheck.sh) = the before record and the usage gate (tools/gate.py pre: five_hour <= 0.60, seven_day + 0.01
# < 0.80, and the round R 0.01): record differs -> exit 3 (STOP, not called); gate fails -> exit 7 (WAIT, its
# resetsAt printed; no STARTED written, may run again later). Then STARTED (UTC, request file sha256), attempt 1 (probe
# session call-1: each call's status line in call-1/status.jsonl), then the G's api-error rule (stance 2 / bar B6): a
# call whose reply is an api-error with status 429 or 5xx, no text and 0 output tokens is sent again, its frozen line as
# it is, up to twice (call-2, call-3; nothing else is ever sent again: an empty reply, a timeout, a cap hit, another
# api-error status stay as they are); the after record (exit 4 VOID when it differs). A call that threw (the engine
# refused before sending) -> exit 5 (M-4 line 4). Then M-4's 10% rule on the final status of each quiz: api-errors
# above 10% of the 9 -> exit 6 (void, nothing opened). Cut-stage rule (plan cutStageRule): an attempt that leaves no
# out.json (a usage limit, a suspend or restart, a killed process) ends with exit 9 CUT and a summary.json judged on
# status counts only (each quiz's last status line; a frozen request with none = an api-error); above 10% it is VOID
# and, by plan batches[1].stop (the stricter of the plan's two texts, the bar's '읽는 법' 1), sonnet is OFF and not
# re-measured in 1.13.0: no 'quiz-r2' (refused). Only status is printed; never an answer's text. Every claude process
# goes through cli/pinned.sh. (Re-frozen before the bar commit after the translation check: quiz-r2 refused.)
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2/test/st/cut
P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2/test/pinned-fake.sh
ST="$1"; M="$2"
case "$ST" in quiz) ;; quiz-r2) echo "refuse: no quiz-r2 for G2 sonnet in 1.13.0 (plan batches[1].stop: a void round turns sonnet OFF, not re-measured)"; exit 1;; *) echo "usage: stage.sh quiz sonnet"; exit 2;; esac
[ "$M" = sonnet ] || { echo "refuse: only sonnet is measured for G2 in 1.13.0 (haiku: ON, not re-measured)"; exit 2; }
D="${S:?}/stage/$ST/$M"
BASE=quiz
[ -e "$D/STARTED" ] && { echo "refuse: $D/STARTED exists (cut-stage rule: report to the main loop)"; exit 1; }
LINES="${S:?}/frozen/lines-$M.jsonl"
[ -s "$LINES" ] || { echo "no frozen lines: $LINES"; exit 2; }
grep -q '"same": 9' "${S:?}/frozen/d34/compare.json" 2>/dev/null || { echo "refuse: no D34 9/9 (frozen/d34/compare.json)"; exit 2; }
python3 -I -c 'import json,sys; sys.exit(0 if json.load(open(sys.argv[1])).get("pass") is True else 1)' "${S:?}/frozen/precall/result.json" 2>/dev/null \
  || { echo "refuse: the pre-call gate has not passed (frozen/precall/result.json)"; exit 2; }
if [ "$ST" != "$BASE" ]; then
  python3 -I -c 'import json,sys; s=json.load(open(sys.argv[1])); sys.exit(0 if s.get("void10") and s.get("cut") else 1)' "${S:?}/stage/$BASE/$M/summary.json" 2>/dev/null \
    || { echo "refuse: $ST runs only after $BASE holds a VOID (cut) summary judged on status counts"; exit 1; }
  [ "$(sha256sum < "$LINES")" = "$(sed -n 2p "${S:?}/stage/$BASE/$M/STARTED" | sed 's#  .*#  -#')" ] || { echo "refuse: the request file differs from $BASE's"; exit 1; }
fi
mkdir -p "$D"
N=$(ls -d "$D"/pre-*/ 2>/dev/null | wc -l); PRE="$D/pre-$((N + 1))"
"$P" --record > "$PRE.pin.txt" 2>&1
"$P" bash "${S:?}/probe/precheck.sh" "$PRE" "$M" || { echo "precheck failed to run"; exit 3; }
python3 -I "${S:?}/tools/gate.py" pre "$PRE" "$M" "$BASE" "$PRE.pin.txt"; rc=$?
[ $rc -eq 3 ] && { echo "STOP: the before record differs from the 1.13.0 calibration: not called"; exit 3; }
[ $rc -eq 7 ] && { echo "WAIT: usage gate failed: not started"; exit 7; }
[ $rc -eq 9 ] && { echo "not started: no statement that no other workflow runs (ONLY_WORKFLOW=1)"; exit 2; }
[ $rc -ne 0 ] && { echo "gate error $rc"; exit 3; }
{ date -u +%FT%TZ; sha256sum "$LINES"; echo "gate $PRE/gate.json"; } > "$D/STARTED"
"$P" --record > "$D/pin-before.txt" 2>&1
cut_out() { # a cut model-stage: summary.json judged on status counts only (no answer opened), then exit 9
  "$P" --record > "$D/pin-after.txt" 2>&1
  python3 -I - "$D" "$LINES" <<'PY'
import json, os, sys
d, lines = sys.argv[1], sys.argv[2]
ids = [json.loads(l)["id"] for l in open(lines, encoding="utf-8") if l.strip()]
last = {}
for a in (1, 2, 3):
    p = f"{d}/call-{a}/status.jsonl"
    if os.path.exists(p):
        for l in open(p, encoding="utf-8"):
            if l.strip():
                r = json.loads(l)
                last[r["id"]] = r
counts = {}
for i in ids:
    r = last.get(i)
    how = "api-error/no-status" if r is None else "answered" if r.get("answered") else (r.get("reason") or "unknown") + (f"/{r.get('status')}" if r.get("reason") == "api-error" else "")
    counts[how] = counts.get(how, 0) + 1
api = sum(v for k, v in counts.items() if k.startswith("api-error"))
summ = {"cut": True, "quizzes": len(ids), "counts": counts, "apiErrors": api, "void10": api * 10 > len(ids)}
open(f"{d}/summary.json", "w").write(json.dumps(summ, indent=1) + "\n")
print(json.dumps(summ))
PY
  echo "CUT: $1 (judged on status counts; VOID when void10 is true: sonnet OFF, not re-measured)"; exit 9
}
threw() { grep -q '"reason": *"threw"' "$1/status.jsonl" 2>/dev/null; }
CUR="$LINES"
for A in 1 2 3; do
  "$P" bash "${S:?}/probe/call.sh" "$D/call-$A" "$M" "$CUR"
  [ -f "$D/call-$A/out.json" ] || cut_out "no call-$A out.json"
  threw "$D/call-$A" && { echo "THREW: the engine refused before sending (M-4 line 4)"; exit 5; }
  chmod 444 "$D/call-$A/out.json"
  [ $A -eq 3 ] && break
  python3 -I - "$D/call-$A/out.json" "$LINES" "$D/again-$((A + 1)).jsonl" <<'PY'
import json, sys
out, lines_p, nxt = sys.argv[1:4]
lines = {json.loads(x)["id"]: x for x in open(lines_p, encoding="utf-8") if x.strip()}
again = []
for r in json.load(open(out, encoding="utf-8"))["results"]:
    st = r.get("status")
    toks = (r.get("usage") or {}).get("output_tokens")
    if not r.get("isAnswered") and r.get("reason") == "api-error" and isinstance(st, int) and (st == 429 or st >= 500) and toks == 0 and not r.get("text"):
        again.append(lines[r["id"]].rstrip("\n"))
if again:
    open(nxt, "w", encoding="utf-8").write("\n".join(again) + "\n")
print(f"api-errors to send again: {len(again)}")
PY
  [ -s "$D/again-$((A + 1)).jsonl" ] || break
  CUR="$D/again-$((A + 1)).jsonl"
done
"$P" --record > "$D/pin-after.txt" 2>&1
python3 -I "${S:?}/tools/gate.py" after "$D" "$M" "$D/pin-after.txt"; after=$?
python3 -I - "$D" <<'PY'
import hashlib, json, os, sys
d = sys.argv[1]
final, summ = {}, {"attempts": [], "sha256": {}}
for a in (1, 2, 3):
    p = f"{d}/call-{a}/out.json"
    if not os.path.exists(p):
        continue
    summ["sha256"][f"call-{a}"] = hashlib.sha256(open(p, "rb").read()).hexdigest()
    rs = json.load(open(p, encoding="utf-8"))["results"]
    summ["attempts"].append({"attempt": a, "calls": len(rs)})
    for r in rs:
        how = "answered" if r.get("isAnswered") else r.get("reason")
        if how == "api-error":
            how += f"/{r.get('status')}"
        final[r["id"]] = {"attempt": a, "how": how}
counts = {}
for v in final.values():
    counts[v["how"]] = counts.get(v["how"], 0) + 1
api = sum(n for k, n in counts.items() if k.startswith("api-error"))
summ.update({"quizzes": len(final), "final": final, "counts": counts, "apiErrors": api, "void10": api * 10 > len(final)})
open(f"{d}/summary.json", "w").write(json.dumps(summ, indent=1) + "\n")
print(json.dumps({k: summ[k] for k in ("quizzes", "counts", "apiErrors", "void10", "sha256")}))
PY
[ $after -ne 0 ] && { echo "VOID: the after record differs (D19): this model's cell is off"; exit 4; }
grep -q '"void10": true' "$D/summary.json" && { echo "VOID: api-errors above 10% (M-4)"; exit 6; }
date -u +%FT%TZ > "$D/DONE"
echo "DONE $ST $M"
