#!/bin/bash
# learn-notes 1.13.0 G2 sonnet (batch 2; copy of impl112/b3r/gen/precheck.sh, R= moved): the opus 'ok' session before/after a writer,
# the writers' alias). It is the before/after record (pinned claude --version, init model, modelUsage keys) and holds the
# usage gate's numbers (rate_limit_event). usage: pinned.sh bash gen/precheck.sh <out dir>   (no haiku/sonnet call)
R=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2/test/wr/again
O="$1"
[ -n "$O" ] || { echo "usage: precheck.sh <out dir>"; exit 2; }
[ -e "$O" ] && { echo "refuse: $O exists"; exit 1; }
mkdir -p "$O" "${R:?}/work/empty"
cd "${R:?}/work/empty" || exit 1
export DISABLE_AUTOUPDATER=1
claude --version > "$O/version.txt" 2>&1
date -u +%FT%TZ > "$O/started.txt"
timeout 180 claude -p --model opus --tools '' --output-format stream-json --verbose ok < /dev/null > "$O/stream.jsonl" 2> "$O/err.txt"
echo "exit=$?" > "$O/exit.txt"
date -u +%FT%TZ > "$O/ended.txt"
python3 -I "${R:?}/gen/record.py" "$O" > /dev/null
python3 -I - "$O" <<'PY'
import json, sys, datetime
o = sys.argv[1]
rec = json.load(open(o + "/record.json", encoding="utf-8"))
win = {}
for ev in rec["rate_limit_events"]:
    for k, v in (ev.get("unifiedWindows") or {}).items():
        win[k] = v
iso = lambda t: datetime.datetime.fromtimestamp(t, datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ") if t else None
f, s = win.get("five_hour", {}), win.get("seven_day", {})
print(json.dumps({"version": list(rec["versions"].values()), "inits": rec["inits"], "modelUsage": [r["modelUsage"] for r in rec["results"]],
  "exit": rec["exit"], "five_hour": f.get("utilization"), "five_reset": iso(f.get("resetsAt")), "seven_day": s.get("utilization"), "seven_reset": iso(s.get("resetsAt"))}))
PY
