#!/bin/bash
# learn-notes 1.13.0 G2 sonnet (batch 2; copy of impl113/b1/gen/run.sh = impl112/b3r/gen/run.sh's form, plan
# commonPerBatch.writerRunner): the detached runner of every opus call of this batch: the sample writers, the two judges
# and the translation checker. Each call is a fresh `claude -p --model opus --tools '' --output-format json` with the
# prompt on stdin in an empty dir of its own, through the pinned CLI cli/pinned.sh (DISABLE_AUTOUPDATER=1).
# usage: run.sh <root> samples            every main part of gen/parts.json (chain M one after another, chain B beside)
#        CHAIN_ROOT=<samples root> run.sh <root> topup <T1|T2>   the one pre-committed top-up part TU-<K> (own root; the
#                                         samples run DONE)
#        run.sh <root> files <json|text>  every <root>/inputs/<name>.md as one call (prompts made beforehand by the
#                                         batch tools); json: the reply must hold exactly one ```json block (or be JSON);
#                                         text: any non-empty reply
# PROJ = the stage's own projection for the usage gate (default 0.06).
# Before: an opus 'ok' session (gen/precheck.sh) = the before record and the usage gate (gen/gate.py pre): pinned
# version/sha256 differ -> RECORD-STOP; five_hour > 0.60 or seven_day + PROJ >= 0.80 -> WAIT <resetsAt>, nothing called.
# Per call: STARTED marker, status line appended to <root>/status.jsonl (part, try, ending, readable; no text).
#   ending (gen/gate.py ending): WAIT (api error, limit reached, no result, killed) -> the run stops with WAIT and the
#   same frozen prompt (byte copy of the part's first prompt.md) is sent again after the reset; it is not a refusal.
#   REFUSAL (stop_reason refusal or safety_stops > 0) or an unreadable reply (incl. printed tool-call text in place of
#   the asked output) -> sent once more with the same prompt; a second such ending of the same part -> STOP <part>.
#   A call whose modelUsage is not the pre session's init model alone -> VOID.
# After: an opus 'ok' session = the after record (gen/gate.py after): differs -> VOID. On VOID the run's replies are
# marked VOIDED (kept, never used) and the same frozen prompts run again once the record matches.
# STATUS: RUNNING <pid> -> DONE | WAIT <resetsAt> | STOP <part> | RECORD-STOP | VOID. A root whose STATUS is DONE, STOP,
# RECORD-STOP or RUNNING is refused; WAIT and VOID resume (parts with a reply that is not VOIDED are kept).
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2/test/wr/again
P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2/test/pinned-fake.sh
ROOT="$1"; MODE="$2"; ARG="$3"
case "$ROOT" in "${S:?}/"[A-Za-z0-9]*) ;; *) echo "usage: run.sh <root under b2> samples|topup <T1|T2>|files <json|text>"; exit 2;; esac
case "$ROOT" in *..*|*[!A-Za-z0-9/_.-]*) echo "refuse: root path"; exit 2;; esac
case "$MODE" in samples) ;; topup) case "$ARG" in T1|T2) ;; *) echo "topup <T1|T2>"; exit 2;; esac;; files) case "$ARG" in json|text) ;; *) echo "files <json|text>"; exit 2;; esac;; *) echo "mode?"; exit 2;; esac
if [ -e "$ROOT/STATUS" ]; then
  case "$(cat "$ROOT/STATUS")" in WAIT*|VOID*) ;; *) echo "refuse: $ROOT/STATUS is $(cat "$ROOT/STATUS")"; exit 1;; esac
fi
if [ "$MODE" = files ]; then
  [ -d "$ROOT/inputs" ] || { echo "no $ROOT/inputs"; exit 2; }
  ALL=$(cd "$ROOT/inputs" && ls *.md | sed 's/\.md$//' | tr '\n' ' ')
elif [ "$MODE" = topup ]; then
  case "${CHAIN_ROOT:-}" in "${S:?}/"*) [ "$(cat "$CHAIN_ROOT/STATUS" 2>/dev/null)" = DONE ] || { echo "CHAIN_ROOT: the samples run must be DONE"; exit 2; };; *) echo "topup needs CHAIN_ROOT=<samples root>"; exit 2;; esac
  [ "$ROOT" != "$CHAIN_ROOT" ] || { echo "a top-up runs in its own root"; exit 2; }
  ALL="TU-$ARG"
else
  ALL=$(python3 -I -c 'import json,sys; print(" ".join(p["part"] for p in json.load(open(sys.argv[1]))["parts"]))' "${S:?}/gen/parts.json")
fi
[ -n "$ALL" ] || { echo "nothing to run"; exit 2; }
mkdir -p "$ROOT/parts"
N=$(ls -d "$ROOT"/run-*/ 2>/dev/null | wc -l); RUN="run-$((N + 1))"; mkdir -p "$ROOT/$RUN"
echo "RUNNING $$" > "$ROOT/STATUS"
[ -e "$ROOT/STARTED" ] || { date -u +%FT%TZ; echo "mode $MODE $ARG"; } > "$ROOT/STARTED"
echo "$(date -u +%FT%TZ) $RUN $MODE $ARG" >> "$ROOT/runs.txt"
"$P" --record > "$ROOT/$RUN/pin-before.txt" 2>&1
sha256sum /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/NAMES-all.txt > "$ROOT/$RUN/names.sha256"

"$P" bash "${S:?}/gen/precheck.sh" "$ROOT/$RUN/pre" > "$ROOT/$RUN/pre.log" 2>&1
python3 -I "${S:?}/gen/gate.py" pre "$ROOT/$RUN/pre" "${PROJ:-0.06}" >> "$ROOT/$RUN/pre.log" 2>&1
g=$?
if [ $g = 3 ]; then echo "RECORD-STOP" > "$ROOT/STATUS"; exit 3; fi
if [ $g = 7 ]; then echo "WAIT $(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["waitUntil"])' "$ROOT/$RUN/pre/gate.json")" > "$ROOT/STATUS"; exit 7; fi
[ $g = 0 ] || { echo "RECORD-STOP gate exit $g" > "$ROOT/STATUS"; exit 3; }

has_reply() { # <part>: a reply that is not VOIDED
  local d
  for d in "$ROOT"/parts/"$1"-*; do [ -f "$d/reply.json" ] && [ ! -e "$d/VOIDED" ] && return 0; done
  return 1
}
bad_tries() { # <part>: tries that ended REFUSAL or unreadable, not VOIDED
  local d n=0
  for d in "$ROOT"/parts/"$1"-*; do [ -f "$d/ending.txt" ] && [ ! -e "$d/VOIDED" ] && grep -qE '^(REFUSAL|UNREADABLE)' "$d/ending.txt" && n=$((n + 1)); done
  echo $n
}

call() { # <part dir>
  local d="$1" w="${S:?}/work/gen-$(basename "$ROOT")-$(basename "$1")"
  sha256sum "$d/prompt.md" > "$d/prompt.sha256"
  mkdir -p "$w"
  echo "$RUN" > "$d/run.txt"
  date -u +%FT%TZ > "$d/started.txt"
  ( cd "$w" && "$P" bash -c 'timeout 3000 claude -p --model opus --tools "" --output-format json' < "$d/prompt.md" > "$d/out.json" 2> "$d/err.txt" )
  echo "exit=$?" > "$d/exit.txt"
  date -u +%FT%TZ > "$d/ended.txt"
  python3 -I - "$d" <<'PY'
import json, sys
d = sys.argv[1]
try:
    o = json.load(open(d + "/out.json", encoding="utf-8"))
except Exception as e:
    o = {"result": "", "is_error": f"unreadable out.json: {e}"}
open(d + "/result.txt", "w", encoding="utf-8").write(o.get("result") or "")
open(d + "/model.txt", "w").write(json.dumps(sorted((o.get("modelUsage") or {}).keys())) + "\n")
u = o.get("usage") or {}
json.dump({"is_error": o.get("is_error"), "subtype": o.get("subtype"), "stop_reason": o.get("stop_reason"), "safety_stops": o.get("safety_stops"),
           "num_turns": o.get("num_turns"), "output_tokens": u.get("output_tokens"), "duration_ms": o.get("duration_ms")}, open(d + "/stats.json", "w"))
PY
}

readable() { # <part dir> <part>
  if [ "$MODE" = files ]; then
    python3 -I - "$1" "$ARG" <<'PY'
import json, re, sys
d, how = sys.argv[1], sys.argv[2]
t = open(d + "/result.txt", encoding="utf-8").read()
if how == "text":
    ok = bool(t.strip())
else:
    b = re.findall(r"```json[ \t]*\n(.*?)\n```", t, re.S)
    body = b[0] if len(b) == 1 else (t if not b else None)
    try:
        v = json.loads(body) if body is not None else None
        ok = v is not None
    except Exception:
        ok = False
if ok:
    open(d + "/reply.json", "w", encoding="utf-8").write(json.dumps({"text": t}, ensure_ascii=False))
sys.exit(0 if ok else 5)
PY
  else
    python3 -I "${S:?}/gen/parts.py" read "$1" "$2"
  fi
}

part() { # <part>
  local x="$1" t d e
  has_reply "$x" && return 0
  while :; do
    [ "$(bad_tries "$x")" -ge 2 ] && { echo "second refusal or unreadable reply" > "$ROOT/STOP-$x"; return 6; }
    t=$(( $(ls -d "$ROOT"/parts/"$x"-*/ 2>/dev/null | wc -l) + 1 ))
    d="$ROOT/parts/$x-$t"
    mkdir -p "$d"
    if [ -f "$ROOT/parts/$x-1/prompt.md" ]; then
      cp "$ROOT/parts/$x-1/prompt.md" "$d/prompt.md"
    elif [ "$MODE" = files ]; then
      cp "$ROOT/inputs/$x.md" "$d/prompt.md"
    else
      python3 -I "${S:?}/gen/parts.py" make "$ROOT" "$x" "$d/prompt.md" || { echo "make failed" > "$ROOT/STOP-$x"; return 6; }
    fi
    call "$d"
    e=$(python3 -I "${S:?}/gen/gate.py" ending "$d")
    if [ "$e" = WAIT ]; then
      echo WAIT > "$d/ending.txt"; echo "{\"part\":\"$x\",\"try\":$t,\"ending\":\"WAIT\"}" >> "$ROOT/status.jsonl"
      echo "wait" > "$ROOT/WAIT-$x"; return 7
    fi
    python3 -I "${S:?}/gen/gate.py" part "$d" "$ROOT/$RUN/pre" || echo "model differs: $d" >> "$ROOT/$RUN/VOID"
    if [ "$e" = REFUSAL ]; then
      echo REFUSAL > "$d/ending.txt"; echo "{\"part\":\"$x\",\"try\":$t,\"ending\":\"REFUSAL\"}" >> "$ROOT/status.jsonl"
      continue
    fi
    if readable "$d" "$x"; then
      echo OK > "$d/ending.txt"; echo "{\"part\":\"$x\",\"try\":$t,\"ending\":\"OK\",\"readable\":true}" >> "$ROOT/status.jsonl"
      return 0
    fi
    echo UNREADABLE > "$d/ending.txt"; echo "{\"part\":\"$x\",\"try\":$t,\"ending\":\"UNREADABLE\",\"readable\":false}" >> "$ROOT/status.jsonl"
  done
}

chain() { # <chain letter, or '-' for every part in order>
  local x c
  for x in $ALL; do
    if [ "$MODE" = samples ]; then
      c=$(python3 -I -c 'import json,sys; print({p["part"]: p["chain"] for p in json.load(open(sys.argv[1]))["parts"]}[sys.argv[2]])' "${S:?}/gen/parts.json" "$x")
      [ "$c" = "$1" ] || continue
    fi
    ls "$ROOT"/STOP-* "$ROOT"/WAIT-* > /dev/null 2>&1 && return 6
    part "$x" || return 6
  done
}

rm -f "$ROOT"/WAIT-*
if [ "$MODE" = samples ]; then
  chain M & cm=$!; chain B & cb=$!
  wait $cm; wait $cb
else
  chain -
fi

"$P" bash "${S:?}/gen/precheck.sh" "$ROOT/$RUN/after" > "$ROOT/$RUN/after.log" 2>&1
python3 -I "${S:?}/gen/gate.py" after "$ROOT/$RUN/after" "$ROOT/$RUN/pre" >> "$ROOT/$RUN/after.log" 2>&1
a=$?
"$P" --record > "$ROOT/$RUN/pin-after.txt" 2>&1
if [ $a != 0 ] || [ -e "$ROOT/$RUN/VOID" ]; then
  for d in "$ROOT"/parts/*/; do [ "$(cat "$d/run.txt" 2>/dev/null)" = "$RUN" ] && touch "$d/VOIDED"; done
  echo "VOID" > "$ROOT/STATUS"; exit 4
fi
if ls "$ROOT"/STOP-* > /dev/null 2>&1; then echo "STOP $(ls "$ROOT"/STOP-* | xargs -n1 basename | sed 's/^STOP-//' | tr '\n' ' ')" > "$ROOT/STATUS"; exit 6; fi
if ls "$ROOT"/WAIT-* > /dev/null 2>&1; then echo "WAIT $(python3 -I -c 'import json,sys; g=json.load(open(sys.argv[1])); print(g["five_hour"]["resetsAt"])' "$ROOT/$RUN/pre/gate.json")" > "$ROOT/STATUS"; exit 7; fi
if [ "$MODE" = samples ]; then
  python3 -I "${S:?}/gen/parts.py" assemble "$ROOT" > "$ROOT/assemble.log" 2>&1 || { echo "STOP assemble" > "$ROOT/STATUS"; exit 6; }
fi
echo "DONE" > "$ROOT/STATUS"
