#!/bin/bash
# tool test only: tools/stage.sh with the fake claude (test/bin/claude) through the fake pin in test roots; no model call.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2
F="${S:?}/test/chk/out1"
mk() { # mk <name> [precall pass true|false]: a fresh test root
  R="${S:?}/test/st/$1"; rm -rf "${R:?}"; mkdir -p "$R/frozen/d34" "$R/frozen/precall" "$R/stage"
  cp "$F/lines-sonnet.jsonl" "$F/build.json" "$F/samples.json" "$F/layout.json" "$F/learner.json" "$R/frozen/"
  cp "$S/test/d34-syn/compare.json" "$R/frozen/d34/compare.json"
  echo "{\"pass\": ${2:-true}}" > "$R/frozen/precall/result.json"
  ln -s "$S/tools" "$R/tools"; ln -s "$S/probe" "$R/probe"
  sed "s#^S=.*#S=$R#; s#^P=.*#P=$S/test/pinned-fake.sh#" "$S/tools/stage.sh" > "$R/stage.sh"; chmod +x "$R/stage.sh"
  export FAKE_STATE="$R/fake-state"
}
export FAKE_ID_SONNET="$(python3 -c "import json;print(json.load(open('/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b0/calib/pre/sonnet-1/record.json'))['inits'][0])")"
export FAKE_TEXTS="$S/test/st-texts.json"
mkdir -p "$S/test/st"
t() { echo "== $1: expect $2"; shift 2; "$@" > "$R.log" 2>&1; echo "exit $?"; grep -E "^(STOP|WAIT|VOID|THREW|DONE|refuse|not started|CUT|usage|api-errors)" "$R.log" | head -4; }
mk ok
ONLY_WORKFLOW=1 t "quiz sonnet" "DONE (seven 0.2 + 0.01, R 0.01)" "$R/stage.sh" quiz sonnet
head -c 400 "$R/stage/quiz/sonnet/summary.json"; echo; ls "$R/stage/quiz/sonnet" | tr '\n' ' '; echo; python3 -c "import json;print(json.load(open('$R/stage/quiz/sonnet/pre-1/gate.json'))['checkPoint'], json.load(open('$R/stage/quiz/sonnet/pre-1/gate.json'))['roundProjection'])"
ONLY_WORKFLOW=1 t "quiz sonnet again" "refuse STARTED" "$R/stage.sh" quiz sonnet
ONLY_WORKFLOW=1 t "quiz haiku" "refuse (haiku not measured)" "$R/stage.sh" quiz haiku
ONLY_WORKFLOW=1 t "quiz-r2 after a DONE quiz" "refuse (no quiz-r2 in 1.13.0)" "$R/stage.sh" quiz-r2 sonnet
mk nogate false; ONLY_WORKFLOW=1 t "pre-call gate not passed" "refuse exit 2" "$R/stage.sh" quiz sonnet
mk nod34; rm "$R/frozen/d34/compare.json"; ONLY_WORKFLOW=1 t "no D34" "refuse exit 2" "$R/stage.sh" quiz sonnet
mk att; t "no attestation" "exit 2 not started" "$R/stage.sh" quiz sonnet; ls "$R/stage/quiz/sonnet" | grep -c STARTED
mk five; FAKE_FIVE=0.7 ONLY_WORKFLOW=1 t "five 0.70" "WAIT exit 7" "$R/stage.sh" quiz sonnet; ls "$R/stage/quiz/sonnet" | grep -c STARTED
mk seven; FAKE_SEVEN=0.795 ONLY_WORKFLOW=1 t "seven 0.795 + 0.01" "WAIT exit 7" "$R/stage.sh" quiz sonnet
mk seven2; FAKE_SEVEN=0.785 ONLY_WORKFLOW=1 t "seven 0.785 + 0.01" "DONE" "$R/stage.sh" quiz sonnet
mk ver; FAKE_VERSION="2.1.330 (Claude Code)" ONLY_WORKFLOW=1 t "version drift" "STOP exit 3" "$R/stage.sh" quiz sonnet
mk pin; FAKE_PIN_BAD=0000 ONLY_WORKFLOW=1 t "pinned sha differs" "STOP exit 3" "$R/stage.sh" quiz sonnet
mk drift; FAKE_DRIFT=1 ONLY_WORKFLOW=1 t "id drift in probe session" "VOID exit 4" "$R/stage.sh" quiz sonnet
mk api2; FAKE_SPEC='{"Q2":"api,api,answered","Q5":"api,answered"}' ONLY_WORKFLOW=1 t "429/5xx twice then answered; once then answered" "DONE, attempts 9/2/1" "$R/stage.sh" quiz sonnet; python3 -c "import json;s=json.load(open('$R/stage/quiz/sonnet/summary.json'));print(s['attempts'],s['counts'])"
mk api3; FAKE_SPEC='{"Q4":"api,api,api"}' ONLY_WORKFLOW=1 t "api-error after two resends (1/9 > 10%)" "VOID exit 6" "$R/stage.sh" quiz sonnet
mk api400; FAKE_SPEC='{"Q4":"api400"}' ONLY_WORKFLOW=1 t "api-error 400 not resent (1/9 > 10%)" "VOID exit 6, attempts 9" "$R/stage.sh" quiz sonnet; python3 -c "import json;s=json.load(open('$R/stage/quiz/sonnet/summary.json'));print(s['attempts'])"
mk empty; FAKE_SPEC='{"Q3":"empty","Q6":"timeout"}' ONLY_WORKFLOW=1 t "empty and timeout not resent" "DONE, attempts 9" "$R/stage.sh" quiz sonnet; python3 -c "import json;s=json.load(open('$R/stage/quiz/sonnet/summary.json'));print(s['attempts'],s['counts'])"
mk threw; FAKE_SPEC='{"Q3":"threw"}' ONLY_WORKFLOW=1 t "threw" "THREW exit 5" "$R/stage.sh" quiz sonnet
mk cut; FAKE_CUT=4 ONLY_WORKFLOW=1 t "cut after 4 status lines" "CUT exit 9, void10" "$R/stage.sh" quiz sonnet; tr -d '\n ' < "$R/stage/quiz/sonnet/summary.json" | head -c 300; echo
unset FAKE_CUT; ONLY_WORKFLOW=1 t "quiz-r2 after the VOID cut" "refuse (no quiz-r2: sonnet OFF)" "$R/stage.sh" quiz-r2 sonnet
ONLY_WORKFLOW=1 t "quiz-r2 again" "refuse" "$R/stage.sh" quiz-r2 sonnet
