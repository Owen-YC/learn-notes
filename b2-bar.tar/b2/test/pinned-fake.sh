#!/bin/bash
# tool test only: cli/pinned.sh with the fake claude first on PATH; --record prints the pinned record (FAKE_PIN_BAD changes one sha).
export DISABLE_AUTOUPDATER=1
export PATH="/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2/test/bin:$PATH"
if [ "$1" = "--record" ]; then
  echo "version: $(claude --version)"
  echo "${FAKE_PIN_BAD:-30e2724e2aecb1bf5dc9f3130901afb71c5fa229051c190a6d7ad9aff6378d6d}  claude"
  echo "c3484833d40fc1e1b87aee30b2b46edbe7115170b5bbe3308dba0e6d3e918e74  claude.hot"
  exit 0
fi
exec "$@"
