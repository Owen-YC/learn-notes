#!/bin/bash
# tool test only: the whole read -> eval -> judges -> tally -> count -> decide pipe on fake-claude stages (test/st/ok,
# test/st/empty); no model call (the judges run through gen/run.sh with the fake pin and a fixed fake reply).
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2
N="$(date +%s)"; export STANCE="$S/test/stance-test.md"
for case in ok empty; do
R="${S:?}/test/st/$case"; export JUDGE="$R/judge-$N" STAGE="$R/stage/quiz/sonnet" FROZEN="$R/frozen"
echo "=== $case"
python3 -I $S/tools/label.py seal; L=$(cat "$JUDGE/label.txt"); echo "label $L"; ls "$JUDGE" | tr '\n' ' '; echo
python3 -I $S/tools/label.py open 2>&1 | tail -1
python3 -I $S/tools/label.py read | tail -9
NOTES=$S/mtree/hooks/notes.ts python3 -I $S/tools/eval.py "$L"
python3 -I $S/tools/judge.py prep "$L"
python3 - "$JUDGE/$L/eval.json" > "$R/fake-judge-$N.json" <<'PY'
import json, sys
rows = json.load(open(sys.argv[1]))["rows"]
print(json.dumps([{"slot": r["slot"], "ga": "pass", "na": "right" if r["na"] == "judge" else "tool", "why": "t"} for r in rows if r["read"]]))
PY
mkdir -p "$R/gen"; for f in parts.json parts.py avoid113.py record.py; do cp "$S/gen/$f" "$R/gen/"; done
sed "s#^S=.*#S=$R#; s#^P=.*#P=$S/test/pinned-fake.sh#" "$S/gen/run.sh" > "$R/gen/run.sh"; sed "s#^R=.*#R=$R#" "$S/gen/precheck.sh" > "$R/gen/precheck.sh"
sed "s#^PINNED = .*#PINNED = \"$S/test/pinned-fake.sh\"#" "$S/gen/gate.py" > "$R/gen/gate.py"
export FAKE_ID_OPUS=fake-opus-id FAKE_STATE="$R/fake-state-j-$N"
FAKE_FILE_REPLY="$(cat "$R/fake-judge-$N.json")" PROJ=0.01 bash "$R/gen/run.sh" "$JUDGE/$L/run" files json > "$R/judges-$N.log" 2>&1; echo "judges runner exit $? $(cat "$JUDGE/$L/run/STATUS")"
python3 -I $S/tools/label.py open 2>&1 | tail -1
python3 -I $S/tools/judge.py collect "$L"
python3 -I $S/tools/tally.py "$L"
PIN_TEST=$S/test/pinned-fake.sh python3 -I $S/tools/tapsend.py "$STAGE" 2>&1 | tail -1
python3 -I $S/tools/count.py "$L"
python3 -I $S/tools/decide.py
python3 -I $S/tools/decide.py 2>&1 | tail -1
done
