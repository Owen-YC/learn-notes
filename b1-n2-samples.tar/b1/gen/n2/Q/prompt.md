너는 코딩 연습의 학습자 답 견본을 쓰는 사람이다. 아래 팀 파일과 연습마다, 학습자가 '고칠 줄' 자리에 적었을 법한 한 줄 답을 갈래마다 정한 수만큼 쓴다. 답은 들여쓰기 없이 그 줄 하나다. 답은 실제로 그 파일의 그 줄 자리에 넣어 돌려 본다.

## 팀 파일

```markdown
# 우리 팀의 학습 노트 규칙

## 규칙
- 서버 요청은 `fetch`(파이썬은 `requests`)를 바로 쓰지 말고 `apiRequest`(파이썬은 `api_request`)를 쓴다. 같은 인자를 받고 같은 응답을 돌려주며, 인증 헤더와 재시도를 더한다
- 기록은 `console.log`(파이썬은 `print`) 대신 `log.info`로 남긴다
- 날짜를 글자로 보일 때는 직접 만들지 말고 `toDateText`(파이썬은 `to_date_text`)를 쓴다. 결과는 `2026-10-22` 꼴(UTC)이다
- 설정 값은 `process.env`(파이썬은 `os.environ`)를 바로 읽지 말고 `config`에서 같은 이름으로 읽는다 (`config.API_URL`)

## 용어
- **주문서**: 결제 직전에 굳힌 장바구니. 금액과 배송지가 더는 바뀌지 않는다
- **회원 등급**: 지난 1년 구매 금액으로 정하는 등급(일반 · 실버 · 골드). 할인율이 등급마다 다르다
```

## 갈래 (연습마다 열 개: 본 답 여섯 + 갈래마다 예비 하나)

- keep 3개(본 2 + 예비 1): 팀 규칙을 지키고 그대로 동작하지만, 예시 답과 글자가 다른 줄(변수 이름 · 인자 · 따옴표 · 꼴을 바꿈. 같은 결과를 냄)
- break 3개(본 2 + 예비 1): 팀 규칙을 어긴 채로(규칙이 쓰지 말라는 이름이나 방식을 남기거나 쓰라는 이름을 안 씀) 동작은 하는 줄. 고칠 줄과 글자가 달라야 한다
- broken 2개(본 1 + 예비 1): 규칙이 쓰라는 이름은 들어 있지만 깨진 줄(구문 오류, 없는 변수, 결과가 달라짐)
- off 2개(본 1 + 예비 1): 규칙과 상관없는 엉뚱한 고침(쓰라는 이름 없음, 결과도 달라짐)
- 답은 영문 상태에서 친 코드 줄이다. 빈 줄, 예시 답이나 고칠 줄과 같은 줄은 쓰지 않는다.

## 연습

### 연습 GA01
- 파일: `src/wishlist/wishCount.js` (16행)
- 할 일: 바뀐 한 줄을 규칙대로 고쳐 보세요.
- 확인: 고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다
- 고칠 줄: `const res = await fetch(saleUrl);`
- 예시 답: `const res = await apiRequest(saleUrl);`
- 노트가 짚은 팀 규칙: 서버 요청은 `fetch`를 바로 쓰지 않고 `apiRequest`를 쓰기로 했는데, 이 코드는 `fetch(saleUrl)`을 바로 호출합니다.
- 돌려 보는 호출(첫 파일 끝에서): `countSaleWishes('u7')`
- 파일 전체(바뀐 뒤):
```
import { apiRequest } from '../api/apiRequest.js';
import { log } from '../log.js';

const BASE_URL = 'https://api.example.test';

export async function getWishItems(userId) {
  const res = await apiRequest(BASE_URL + '/wishlist/' + userId);
  const data = await res.json();
  log.info('wish items:', data.items.length);
  return data.items;
}

export async function countSaleWishes(userId) {
  const items = await getWishItems(userId);
  const saleUrl = BASE_URL + '/sales';
  const res = await fetch(saleUrl);
  const sale = await res.json();
  const onSale = items.filter((id) => sale.ids.includes(id));
  log.info('sale wishes:', onSale.length);
  return onSale.length;
}

```

### 연습 GA02
- 파일: `src/pages/reviewLike.js` (17행)
- 할 일: 바뀐 한 줄을 규칙대로 고쳐 보세요.
- 확인: 고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다
- 고칠 줄: `const res = await fetch(url, opts);`
- 예시 답: `const res = await apiRequest(url, opts);`
- 노트가 짚은 팀 규칙: 서버 요청은 `fetch`를 바로 쓰지 않고 `apiRequest`를 쓰기로 했는데, 이 코드는 `fetch(url, opts)`를 직접 부릅니다. 인증 헤더와 재시도가 빠질 수 있습니다.
- 돌려 보는 호출(첫 파일 끝에서): `likeReview(31, 'u2')`
- 파일 전체(바뀐 뒤):
```
import { apiRequest } from '../api/apiRequest.js';
import { log } from '../log.js';

const REVIEW_API = 'https://api.example.test/reviews';

export async function readReview(reviewId) {
  const res = await apiRequest(REVIEW_API + '/' + reviewId);
  const data = await res.json();
  log.info('review', reviewId, 'loaded');
  return data;
}

export async function likeReview(reviewId, userId) {
  const url = REVIEW_API + '/' + reviewId + '/like';
  const body = JSON.stringify({ userId });
  const opts = { method: 'POST', body };
  const res = await fetch(url, opts);
  const data = await res.json();
  if (!data.ok) return 0;
  log.info('likes now', data.likes);
  return data.likes;
}

```

### 연습 GA06
- 파일: `src/points/rewardPoints.js` (13행)
- 할 일: 바뀐 한 줄을 규칙대로 고쳐 보세요.
- 확인: 고친 줄이 돌 때 `log.info` 쪽을 거칩니다
- 고칠 줄: `console.log('capped', order.id);`
- 예시 답: `log.info('capped', order.id);`
- 노트가 짚은 팀 규칙: 새로 넣은 기록 줄이 `console.log('capped', order.id)`인데, 팀은 `console.log` 대신 `log.info`를 쓰도록 정했습니다. 같은 파일 위쪽에는 이미 `log.info`가 쓰이고 있습니다.
- 돌려 보는 호출(첫 파일 끝에서): `calcRewardPoints({ id: 'A-9', grade: '실버', amount: 300000 })`
- 파일 전체(바뀐 뒤):
```
// 회원 등급별 적립 포인트
import { log } from '../log.js';

const RATE_BY_GRADE = { 일반: 1, 실버: 2, 골드: 3 };
const MAX_POINTS = 5000;

export function calcRewardPoints(order) {
  const rate = RATE_BY_GRADE[order.grade] ?? 1;
  const points = Math.floor((order.amount * rate) / 100);
  log.info('points for', order.id, points);
  const capped = Math.min(points, MAX_POINTS);
  if (capped < points) {
    console.log('capped', order.id);
  }
  return capped;
}

```

### 연습 GA12
- 파일: `src/blog/postStamp.ts` (8행)
- 할 일: 바뀐 한 줄을 규칙대로 고쳐 보세요.
- 확인: 고친 줄이 돌 때 `toDateText` 쪽을 거칩니다
- 고칠 줄: `return when.toISOString().slice(0, 10);`
- 예시 답: `return toDateText(value);`
- 노트가 짚은 팀 규칙: 날짜를 글자로 보일 때는 직접 만들지 말고 `toDateText`를 쓰라고 했는데, `changedOn`이 `toISOString().slice(0, 10)`으로 직접 만들고 있습니다.
- 돌려 보는 호출(첫 파일 끝에서): `postStampLine({ title: '가을 세일', publishedAt: '2026-10-01T03:00:00Z', updatedAt: '2026-10-22T23:30:00Z' })`
- 파일 전체(바뀐 뒤):
```
import { toDateText } from '../dateText.js';
import { log } from '../log.js';

type Post = { title: string; publishedAt: string; updatedAt?: string };

function changedOn(value: string): string {
  const when = new Date(value);
  return when.toISOString().slice(0, 10);
}

export function postStampLine(post: Post): string {
  const published = toDateText(post.publishedAt);
  let line = post.title + ' · ' + published;
  if (post.updatedAt) {
    line += ' (수정 ' + changedOn(post.updatedAt) + ')';
  }
  log.info(line);
  return line;
}

```

### 연습 GA19
- 파일: `app/cart/free_ship.py` (10행)
- 할 일: 바뀐 한 줄을 규칙대로 고쳐 보세요.
- 확인: 고친 줄이 돌 때 `config` 쪽을 거칩니다
- 고칠 줄: `goal = int(os.environ["FREE_SHIP_AT"])`
- 예시 답: `goal = int(config.FREE_SHIP_AT)`
- 노트가 짚은 팀 규칙: 설정 값은 `os.environ`을 바로 읽지 않고 `config`에서 같은 이름으로 읽는 것이 규칙인데, 이 코드는 `os.environ["FREE_SHIP_AT"]`를 바로 읽습니다. 파일 위쪽에 `config`를 이미 가져오고 있으니 `config.FREE_SHIP_AT`로 바꾸는 편이 규칙에 맞습니다.
- 돌려 보는 호출(첫 파일 끝에서): `free_ship_gap(32000)`
- 파일 전체(바뀐 뒤):
```
import os

from app.config import config
from app.log import log

SHIP_FEE = 3000


def free_ship_gap(cart_total):
    goal = int(os.environ["FREE_SHIP_AT"])
    gap = max(goal - cart_total, 0)
    log.info("until free shipping:", gap)
    return gap


def ship_fee_for(cart_total):
    fee = SHIP_FEE if cart_total < 50000 else 0
    if config.get("SHOP_REGION") == "island":
        fee += 3000
    log.info("ship fee:", fee)
    return fee

```

## 출력

JSON 하나만 ```json 블록으로 쓴다. 갈래마다 본 답을 먼저, 예비를 마지막에 둔다(`"reserve": true`):
{"<연습 id>": [{"kind": "keep|break|broken|off", "line": "…", "reserve": false}, … 10개], …}
