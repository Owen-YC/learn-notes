#!/bin/bash
# usage: one.sh <tree> <test file name...>  run only those test files of <tree> (a copy under $S/iter)
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4
R=$1; shift
rm -rf "${S:?}/iter"
mkdir -p "$S/iter/tests"
cd "$R" && cp -r .claude-plugin hooks types tsconfig.json "$S/iter/" 2>/dev/null
ln -s /home/user/learn-notes/node_modules "$S/iter/node_modules"
cp -r tests/fixtures tests/flowkit.ts "$S/iter/tests/"
for f in "$@"; do cp "tests/$f" "$S/iter/tests/"; done
cd "$S/iter" && /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh claude plugin test . 2>&1
