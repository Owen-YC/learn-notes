
## 1.12.0 생각해 보기 (G5): 코드가 범위(돌려주는 짧은 js·ts·py 함수, 보인 그대로 전체)를 정하고, 모델이 고른 리터럴 호출 하나를 코드가 확인해 플러그인이 물음 문장을 쓰며, 줄이 열려 있는 동안 적은 글은 모두 한 번의 확인 호출이 종류를 갈라 읽고 플러그인이 머리를 붙임 (isThinkAsked) · sonnet

### 짓기 (두 모델 모두 끔, 5/5 짓기 커밋)

- 설계 G5c '호출 하나'(`impl112/design/G5.json` `247b2d67…c2ea2c0`)의 시제품 패치(`design/G5/proto/G5c-final.diff` `07bb555e…69f56a0`, de98243 위에서 지음)를 지금 HEAD(cbad928) 위로 옮겼습니다. 그대로 덮어쓰지 않고, de98243을 밑으로 HEAD와 시제품 트리를 세 갈래로 합쳤습니다(`git merge-file`, 맞부딪침 0). 시제품이 쓰는 도움 함수(diffBlocks · withoutDrill · thinkOf · clean · askPrompt 등)가 de98243과 HEAD 사이에 바뀌지 않았는지도 확인했습니다(바뀐 것 0).
- 무엇: hooks/notes.ts(thinkCallees 범위, traceCallQuestion, thinkCallKept, 코드가 쓰는 한 문장 thinkCallLine, openThink · isThinkFollow의 isCalled, THINK_SLOT_SYSTEM · thinkSlotCheckPrompt, 얼린 THINK_VARIANT { haiku: 'trace', sonnet: 'basis' } · thinkVariantOf, thinkSlotReply · slotFallback · SLOT_UNREAD), hooks/register.tsx(askNote, 패널의 noteTools, 도움말 줄). 1.10.0 · 1.11.0의 G5 켠 길(기준을 못 넘음)을 갈음합니다. 켠 길에서 쓰지 않게 된 가져오기 여섯(isThinkCode · isThinkQuestion · THINK_SYSTEM · thinkCheckPrompt · thinkReply · withoutTrace)은 register.tsx에서 뺐습니다(notes.ts의 그 함수들은 바이트까지 그대로, think19 통과).
- 끈 쪽: IS_THINK_ASKED false 그대로, MODEL_SWITCHES는 haiku `{ ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2 }` · sonnet `{ ...SWITCHES_OFF, isRuleWide: true }` 그대로(isThinkAsked는 두 줄 모두 false). 끈 동안(그리고 haiku · sonnet 말고 다른 모델 글자, beginner 말고 다른 수준, 별칭을 바꾼 · 제공자 · modelOverrides · 읽지 못한 창) r의 질문은 traceQuestion(false), ASK_SYSTEM · 900, 확인 호출 없음, 저장은 받은 그대로: 1.9.0과 바이트까지 같습니다.
- 몫: 새 키 · 명령 · 입력 칸 · 설정 · 저장 키 · 저장 필드 · 환경 변수 · 파일 읽기 · 모델 호출 · maxTokens · Switches 키 0. 새 상수는 THINK_VARIANT 하나(얼린 모델별 표, 켠 길에서 recheckRemap 뒤에만 읽음; 설계의 isThinkTraced Switches 키를 갈음해 /learn 진단 · FEATURE_NAMES · G7 키 시험은 그대로). 학습자에게 보이는 글은 켰을 때만 바뀝니다(코드가 쓰는 한 문장, 바른 결과가 붙은 머리, SLOT_UNREAD, 도움말 줄).
- hooks/notes.ts sha256 `d899d0c160beabe0375d5fb59fd65d122f0403a87ffd1aaeeacd779124e680f0` · hooks/register.tsx `fe7c80dff6ee38d835fc15eda11fd6df3029b0c059ce015e768db59e47c4ef74`. 무엇을 확인했는지(시험, 끈 바이트, 옛 창 여섯과 coexist19, 돌연변이 탐침, 켠 칸의 D26 재확인, 관문)는 짓기 커밋 본문에 있습니다.
- 짓기 때의 얼린 입력 백업: `impl112/backup/b4-build.tar` sha256 `__TARSHA__`(__TARINFO__; 묶음 1 감사 교훈 3).

### 기준 전 GO 관문 (짓기 커밋으로 정함: 관문 견본을 쓰거나 관문 호출을 하기 전)

계획(`impl112/plan112.json` batches[4].preBarGate, 옮긴 원문 `impl112/b4/go/preBarGate-plan.json` sha256 `2de6efddb78cca6693082ae92e0ac054fbb497ff86baa88b2c5fd8858a763dbe`)의 GO 규칙을 숫자와 조항을 바꾸지 않고 옮깁니다. 관문 결과는 기록만 하고(B-12) 잰 결정에 들지 않습니다.

- 조건 0: 묶음 0이 H_sonnet = 2048을 냈습니다(위 '보정 기록 (1.12.0)'). 그래서 관문을 돌립니다. 아니었다면 GO 파일럿 · 기준 커밋 · 회차 없이 G5 sonnet은 '1.12.0 설계만 하고 재지 않음'에 바뀐 (가)-5 줄(⌊2500 × (900 + H_sonnet)/2948⌋)을 까닭으로 들어갔습니다.
- 관문: 이 짓기 커밋 뒤, 기준 커밋 전, sonnet만.
  - 새 개발 세트 PG01–PG12: 범위 안 8(잰 쓰는 쪽의 제품 수준 말씨로) · 열면 안 되는 4(범위 밖 가까운 꼴). 새 눈가림 쓰는 쪽이 쓰고, 이름은 `design/G5/dev/NAMES.txt`와 NAMES-all.txt에 덧붙입니다(잰 견본으로는 결코 쓰지 않음).
  - 기준 커밋이 실을 바로 그 코드와 프롬프트(= 이 짓기 커밋의 트리; G5.json: '기준 커밋의 바로 그 코드와 프롬프트'), D34로 확인.
  - 노트 12 + r 12 호출. 그다음 새 쓰는 쪽이 쓴 글 50개(짐작 24, 그 가운데 '?' 붙은 것 4; 빈 답 4; 질문 22, 그 가운데 예/아니요로 성질을 묻는 것 4와 '?' 없는 것 4)로 확인 호출 한 회. 판정자 둘.
- GO는 다음을 모두 넘을 때만입니다.
  - (가) 쓸 수 있는 줄 8개 가운데 7 이상, 열면 안 되는 4개 가운데 연 것 0, 드러남 0, 상한 닿음 0, r의 가장 큰 output_tokens ≤ 2,300(M-6을 H 2048에서 = 2,300).
  - (나) 짐작 24개 가운데 23 이상, 질문 22개 가운데 21 이상, 빈 답 4개 가운데 3 이상, 확인 호출 상한 닿음 0, 거절 0.
  - 이 커밋이 미리 정하는 수(보정 기록 (c)의 식, H_sonnet = 2048): 상한 닿음은 r · 확인 output_tokens ≥ 2948, 노트 ≥ 5548. (가)의 '상한 닿음 0'은 (가) 스테이지의 노트와 r 호출을 모두 셉니다(두 읽기 가운데 엄한 쪽을 미리 고름).
- 기록: 이 GO 규칙은 관문 견본이 생기기 전에 이 짓기 커밋으로 이 절에 적습니다. 관문 결과는 기록만 하고(B-12) 잰 결정에 들지 않습니다.
- 넘지 못하면(NO-GO): 1.12.0에서 sonnet의 기준 커밋도 잰 회차도 없고, 더 다듬지 않습니다. 칸은 false 그대로입니다. 관문의 수를 '1.12.0 설계만 하고 재지 않음'(G5 sonnet)에 설계의 '다시 잴 때 바꿔야 할 것'(whatWouldHaveToChange)과 함께 적습니다.
- 호출: sonnet 약 74번 + opus 쓰는 쪽 2 + 판정자 2.
- 얼림
  - 관문 호출 전에 설계의 판정 입장 글(G5.json의 stance)을 얼립니다: `impl112/b4/go/stance-G5.json` sha256 `ef1b377a4f16455a0380c2604420f89c80836d974f29bf7561228c653a2c631e`(chmod 444, 이 짓기 커밋 본문에도 적음). 관문의 판정자 둘은 이 글만 씁니다.
  - 관문과 기준 커밋 사이에는 G5 요청을 짓거나 읽는 것(hooks/, 시험, 프롬프트를 짓는 도구)을 하나도 바꾸지 않습니다. 바꾸면(D26 고침, 검토 고침도) GO는 무효이고 NO-GO로 셉니다(적음).
  - 기준 커밋은 설계의 판정 입장을 바꾸지 않고 옮겨 적습니다. 그 옮김 확인은 sha로 얼린 관문 글과 견줍니다. 관문 뒤에 다듬지 않습니다(G5.json).
- 모델 기록: GO 파일럿 앞뒤로 회차와 같은 앞 'ok' 세션 + 프로브 세션 기록을 고정한 길로 적습니다. 둘 가운데 하나라도 묶음 0과 다르면(판, 고정 sha256, 별칭 id) GO 판정은 없습니다. 적고 M-10 멈춤을 씁니다(기준 커밋 없음, 회차 없음).
- 사용량: GO 스테이지(노트, r, 확인)마다 앞에 사용량 관문, 관문 전에 주간 예상(아래)을 봅니다(위 '셈을 지키는 규칙').
- 주간 예상(셈을 지키는 규칙의 주간 예상 규칙, 묶음 4는 이 짓기 커밋에 적음): 묶음 4 전체의 주간 사용을 0.10으로 잡습니다. 근거는 설계 파일럿과 앞 묶음의 rate_limit_event 기록입니다: G5 파일럿은 개발 세트 하나(두 모델 약 250번 + 파일럿 에이전트)마다 seven_day 약 0.01(0.17 → 0.18 → 0.19); G6 파일럿 set4는 0.45 → 0.52(파일럿 에이전트 포함, 가장 큰 예); 1.12.0 묶음 0 → 묶음 2 잰 스테이지 앞(00:42 → 06:48 UTC, 묶음 1 · 2의 호출과 에이전트 모두) 0.28 → 0.37. 묶음 4는 GO 관문(sonnet 약 74번 + opus 4) + 회차(sonnet 200번 + opus 약 10) + 감사 · 검토 에이전트라 묶음 1과 비슷한 크기로 보고 0.10으로 잡습니다. 그래서 관문의 첫 앞 세션에서 seven_day.utilization + 0.10 < 0.80일 때만(곧 seven_day < 0.70) 시작하고, 아니면 주간 초기화 뒤에 시작합니다. 마지막으로 적힌 값은 2026-11-14 06:48 UTC의 0.37(초기화 2026-11-17 07:00 UTC)입니다.
