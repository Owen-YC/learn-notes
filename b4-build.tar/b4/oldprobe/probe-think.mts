// learn-notes 1.12.0 batch 4 old-window probe (R9; record): the asks a 1.12.0 window stores while 생각해 보기 is on
// (G5c: r's answer ending on code's own line, then the check's reply as shown) read by six real builds' functions
// (git archive of 3f2b4fb 1.7.0 · 7a7b08c 1.7.1 · 3690021 1.8.0 · fca5988 1.9.0 · 3d2f251 1.10.0 · de98243 1.11.0) and
// the tree: whether r's line opens (thinkOf / openThink, each build's default; 1.10/1.11 also with their closed form on),
// whether the text after it follows it (isThinkFollow), the prompt a guess typed after it builds there (askPrompt with
// the open line: its section and the line), screenNote over the asks, and the export's cut answer (1.7.0 kept 1500).
// usage: node --experimental-transform-types probe-think.mts <tree dir> <isOn: 1 builds the asks with the tree's ON path>
const TREES = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/trees'
const TREE = process.argv[2] ?? '/home/user/learn-notes'
const T = await import(`${TREE}/hooks/notes.ts`)
const change = { file: 'src/odd.js', path: '/p/src/odd.js', tool: 'Edit', kind: 'update', added: 1, removed: 1, diff: '@@ -1,5 +1,5 @@\n function sumOdd(xs) {\n   let t = 0\n-  for (const x of xs) t += x\n+  for (const x of xs) if (x % 2) t += x\n   return t\n }', isCut: false }
const callees = T.thinkCallees([change])
const reply = '예시 호출: `sumOdd([1, 2, 3])`\n\n1. `t`는 0에서 시작합니다.\n2. 홀수 1과 3만 더해 `t`는 4가 됩니다.\n3. `4`를 돌려줍니다.\n\n**생각해 보기:** `sumOdd([5, 7])`'
// The tree's ON path: r's answer kept with code's line (thinkCallKept), and a guess's check reply as shown (thinkSlotReply).
const kept = T.thinkCallKept(reply, callees, '### 한 줄 요약\n홀수만 더함', [change.diff])
const shown = T.thinkSlotReply('종류: 짐작\n근거: `5 + 7`\n바른 결과: `12`를 돌려준다\n판정: 맞음\n까닭: 5와 7이 모두 홀수입니다.\n답: 없음', '12요')
const NOW = 10_000_000
const asks = [
  { question: '예시로 따라가기', answer: kept, at: NOW - 5 * 60_000 },
  { question: '12요', answer: shown, at: NOW - 4 * 60_000 },
]
const note = { id: 'n1', turnId: 't1', at: NOW - 600_000, prompt: 'sumOdd가 홀수만 더하게 해줘', answer: '', changes: [change], moreFiles: 0, status: 'ready', text: '### 한 줄 요약\n홀수만 더함', savedAs: 'ready', withheld: [], asks }
const out: Record<string, unknown> = { tree: { callees: callees.map((one: { name: string }) => one.name), kept, shown } }
for (const c of ['3f2b4fb', '7a7b08c', '3690021', 'fca5988', '3d2f251', 'de98243', 'TREE']) {
  const N = c === 'TREE' ? T : await import(`${TREES}/${c}/hooks/notes.ts`)
  const row: Record<string, unknown> = {}
  row.traceLabel = N.TRACE_LABEL === '예시로 따라가기'
  if (N.openThink) {
    const opened = N.openThink(asks.slice(0, 1), NOW)
    row.opensOff = opened?.question ?? null
    if (N.isThinkShape) row.opensClosedForm = N.openThink(asks.slice(0, 1), NOW, true)?.question ?? null
    if (c === 'TREE') row.opensOn = N.openThink(asks.slice(0, 1), NOW, true, true)?.question ?? null
    row.follows = N.isThinkFollow(asks, 1)
    if (opened) {
      const p = N.askPrompt({ ...note, asks: asks.slice(0, 1) }, '12요', 'beginner', undefined, opened)
      row.guessPrompt = { section: p.includes("## 바로 앞 '예시로 따라가기'의 답과, 그 끝에 학습자에게 던진 생각해 보기"), line: p.includes(`생각해 보기: ${opened.question}`), trace: p.includes(kept) }
    }
  } else {
    // 1.7.x: no 생각해 보기; the line is a part of r's answer, the asks a question and an answer each.
    const p = N.askPrompt({ ...note }, '더 알려 줘', 'beginner')
    row.askPrompt = { earlierAsks: p.includes('12요') && p.includes(shown) }
  }
  const screened = N.screenNote ? N.screenNote(note) : undefined
  row.screened = screened ? JSON.stringify(screened.asks) === JSON.stringify(asks) : 'none'
  out[c] = row
}
console.log(JSON.stringify(out, null, 1))
