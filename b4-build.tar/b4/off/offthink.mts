// b4 OFF bytes for G5c: the working tree (B) against 1.9.0 (fca5988, A9) and 1.11.0 (de98243, A11), every think/ask
// path the off build runs: r's question, askPrompt (isThinkAsked false), thinkCheckPrompt, thinkReply, thinkOf, openThink,
// isThinkFollow (default args), thinkKept (1.11.0 only), ASK_SYSTEM, THINK_SYSTEM.
import * as A9 from '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/trees/fca5988/hooks/notes.ts'
import * as A11 from '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/trees/de98243/hooks/notes.ts'
import * as B from '/home/user/learn-notes/hooks/notes.ts'
const n = { s9: 0, d9: 0, s11: 0, d11: 0 }
const diffs: string[] = []
const cmp = (what: string, a9: unknown, a11: unknown, b: unknown) => {
  const [x9, x11, y] = [JSON.stringify(a9), JSON.stringify(a11), JSON.stringify(b)]
  if (a9 !== SKIP) x9 === y ? n.s9++ : (n.d9++, diffs.push(`1.9.0 ${what}`))
  x11 === y ? n.s11++ : (n.d11++, diffs.push(`1.11.0 ${what}`))
}
const SKIP = Symbol('skip')
cmp('TRACE_QUESTION', A9.TRACE_QUESTION, A11.traceQuestion(false), B.traceQuestion(false))
cmp('TRACE_QUESTION const', A9.TRACE_QUESTION, A11.TRACE_QUESTION, B.TRACE_QUESTION)
cmp('ASK_SYSTEM', A9.ASK_SYSTEM, A11.ASK_SYSTEM, B.ASK_SYSTEM)
cmp('THINK_SYSTEM', A9.THINK_SYSTEM, A11.THINK_SYSTEM, B.THINK_SYSTEM)
const CALL_LINE = '**생각해 보기:** `sumOdd([5, 7])`를 실행하면 최종 결과는 무엇이 될까요?'
const WALK = '예시 호출: `sumOdd([1, 2, 3])`\n\n1. `t`는 0입니다.\n2. 4를 돌려줍니다.'
const answers = [
  `${WALK}\n\n${CALL_LINE}`,
  `${WALK}\n\n**생각해 보기:** \`xs\`를 \`[5]\`로 바꾸면 최종 결과는 무엇이 될까요?`,
  `${WALK}\n\n**생각해 보기:** 홀수만 더하면 어떻게 될까요?`,
  `${WALK}\n\n**생각해 보기:** \`sumOdd([5, 7])\``,
  `${WALK}\n\n생각해 보기: 결과는?`,
  WALK,
  '',
]
const changes = [
  { file: 'src/odd.js', path: '/p/src/odd.js', tool: 'Edit', kind: 'update', added: 1, removed: 1, diff: '@@ -1,5 +1,5 @@\n function sumOdd(xs) {\n   let t = 0\n-  for (const x of xs) t += x\n+  for (const x of xs) if (x % 2) t += x\n   return t\n }', isCut: false },
  { file: 'src/a.css', path: '/p/src/a.css', tool: 'Edit', kind: 'update', added: 1, removed: 1, diff: '@@ -1 +1 @@\n-a{}\n+b{}', isCut: false },
  { file: 'main.go', path: '/p/main.go', tool: 'Write', kind: 'create', added: 3, removed: 0, diff: '@@ -0,0 +1,3 @@\n+package main\n+func f(n int) int {\n+\treturn n }', isCut: false },
]
const notes = [
  { prompt: 'sumOdd 고쳐 줘', text: '### 한 줄 요약\n홀수만 더함', status: 'ready', changes: [changes[0]], moreFiles: 0, withheld: [] },
  { prompt: '', text: '', status: 'writing', changes: [changes[0], changes[1]], moreFiles: 2, withheld: [{ file: '.env', why: 'secret' }] },
  { prompt: '색 바꿔 줘', text: '노트', status: 'ready', changes: [changes[1], changes[2]], moreFiles: 0, withheld: [] },
]
const team = A9.parseTeamFile('## 규칙\n- 변수 이름은 camelCase로 씁니다\n\n## 용어\n- **합계**: 더한 값')
const teamB = B.parseTeamFile('## 규칙\n- 변수 이름은 camelCase로 씁니다\n\n## 용어\n- **합계**: 더한 값')
const team11 = A11.parseTeamFile('## 규칙\n- 변수 이름은 camelCase로 씁니다\n\n## 용어\n- **합계**: 더한 값')
const NOW = 10_000_000
for (const level of ['beginner', 'intermediate', 'advanced'] as const)
  for (const [k, note] of notes.entries())
    for (const answer of answers)
      for (const askAt of [NOW - 60_000, NOW - 31 * 60_000, NOW + 5_000]) {
        const asks = [{ question: '왜요?', answer: '그래서요.', at: askAt - 1000 }, { question: '예시로 따라가기', answer, at: askAt }]
        const withAsks = { ...note, asks }
        const t9 = A9.openThink(asks as never, NOW)
        const t11 = A11.openThink(asks as never, NOW)
        const tB = B.openThink(asks as never, NOW)
        cmp(`openThink ${level} ${k}`, t9, t11, tB)
        cmp(`openThink shaped-false`, SKIP, A11.openThink(asks as never, NOW, false), B.openThink(asks as never, NOW, false))
        const follow = [...asks, { question: '12요', answer: '네', at: NOW }]
        cmp('isThinkFollow', A9.isThinkFollow(follow as never, 2), A11.isThinkFollow(follow as never, 2), B.isThinkFollow(follow as never, 2))
        cmp('thinkOf', A9.thinkOf(answer), A11.thinkOf(answer), B.thinkOf(answer))
        cmp('thinkKept off', SKIP, A11.thinkKept(answer, false), B.thinkKept(answer, false))
        cmp('thinkKept code', SKIP, A11.thinkKept(answer, true), B.thinkKept(answer, true))
        for (const question of [A9.TRACE_QUESTION, '12요', '', '모르겠어요', '왜 2는 안 더해요?', 'x'.repeat(1200)]) {
          for (const think of [undefined, t9 ?? { question: '홀수만 더하면 어떻게 될까요?', trace: answer }]) {
            for (const [ta, t1, tb] of [[undefined, undefined, undefined], [team, team11, teamB]] as const) {
              cmp(
                `askPrompt ${level} ${k} ${question.slice(0, 8)} ${think ? 'think' : '-'} ${ta ? 'team' : '-'}`,
                A9.askPrompt(withAsks as never, question, level, ta as never, think, false, false),
                A11.askPrompt(withAsks as never, question, level, t1 as never, think, false),
                B.askPrompt(withAsks as never, question, level, tb as never, think, false),
              )
            }
            if (think) cmp(`thinkCheckPrompt ${level} ${k}`, A9.thinkCheckPrompt(withAsks as never, think, question, level), A11.thinkCheckPrompt(withAsks as never, think, question, level), B.thinkCheckPrompt(withAsks as never, think, question, level))
          }
        }
      }
for (const text of ['바른 결과: 3\n판정: 맞음\n피드백: 좋아요.', '바른 결과: 3\n판정: 틀림\n피드백: 아닙니다.', '판정: 질문\n피드백: 답입니다.', '따라가기: x\n바른 결과: 3\n판정: 거의\n피드백: f', '그냥 글', ''])
  for (const isBlank of [false, true]) cmp('thinkReply', A9.thinkReply(text, isBlank), A11.thinkReply(text, isBlank), B.thinkReply(text, isBlank))
const tc = diffs.filter(d => d.startsWith('1.9.0 thinkCheckPrompt')).length
console.log(`vs 1.9.0 OFF: ${n.s9} same, ${n.d9 - tc} different (thinkCheckPrompt apart: 1.9.0 sends it only on, 1.10.0 G5 changed it; ${tc} different from 1.9.0, 0 from 1.11.0)`)
console.log(`all vs 1.9.0: ${n.s9} same, ${n.d9} different; vs 1.11.0 OFF: ${n.s11} same, ${n.d11} different`)
for (const d of [...new Set(diffs)].slice(0, 20)) console.log('DIFF', d)
