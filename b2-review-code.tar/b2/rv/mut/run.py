# b2 robustness review mutations: copy HEAD (probe-robust), apply one mutation, run selected tests, record failures.
import json, os, shutil, subprocess, sys, concurrent.futures as cf, time
S='/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/rv/mut'
R='/home/user/learn-notes'
NM='/home/user/learn-notes/node_modules'
PIN='/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh'
TESTS=sys.argv[2].split(',')
def one(m):
    name, f, old, new = m
    d=os.path.join(S,'w-'+name)
    if os.path.isdir(d): shutil.rmtree(d)
    os.makedirs(d+'/tests')
    for x in ['hooks','types','.claude-plugin']:
        src=os.path.join(R,x)
        if os.path.isdir(src): shutil.copytree(src, os.path.join(d,x))
    shutil.copy(os.path.join(R,'tsconfig.json'), d)
    os.symlink(NM, os.path.join(d,'node_modules'))
    shutil.copytree(os.path.join(R,'tests/fixtures'), os.path.join(d,'tests/fixtures')); shutil.copy(os.path.join(R,'tests/flowkit.ts'), d+'/tests/')
    for t in TESTS: shutil.copy(os.path.join(R,'tests',t), d+'/tests/')
    if f:
        p=os.path.join(d,f); s=open(p).read()
        if s.count(old)!=1: return f'{name}: NOT APPLIED (count {s.count(old)})'
        open(p,'w').write(s.replace(old,new))
    t0=time.time()
    out=subprocess.run([PIN,'claude','plugin','test','.'],cwd=d,capture_output=True,text=True,timeout=3000)
    o=out.stdout+out.stderr
    open(os.path.join(S,name+'.out'),'w').write(o)
    cur=''; per={}; fails=[]
    for l in o.splitlines():
        if l.startswith('tests/') and l.endswith(':'): cur=l[6:-1]
        if l.startswith('(fail)'): per[cur]=per.get(cur,0)+1; fails.append(l)
    shutil.rmtree(d)
    tail=[l for l in o.splitlines() if ' pass' in l or ' fail' in l][-3:]
    return f"{name}: {len(fails)} fail {json.dumps(per)} [{int(time.time()-t0)}s] {tail} :: " + ' | '.join(x.split(' > ')[-1][:100] for x in fails[:3])
muts=json.load(open(sys.argv[1]))
with cf.ThreadPoolExecutor(int(os.environ.get('J','3'))) as ex:
    for r in ex.map(one, muts): print(r, flush=True)
