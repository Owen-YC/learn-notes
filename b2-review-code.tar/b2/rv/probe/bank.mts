import { readFileSync } from 'node:fs'
const N = await import(process.argv[2] + '/hooks/notes.ts')
const d = JSON.parse(readFileSync(process.argv[3], 'utf8'))
for (const q of d.quizzes) for (const s of q.slots) {
  const it = s.item
  if (it?.rung !== 'changed') continue
  const asked = N.bankQuestion(it)
  let front = ''
  if (asked !== undefined) {
    const bank = N.addToBank([], [{ key: it.key, name: it.name, question: asked, answer: it.answer }], 0)
    front = N.ankiText(bank, {}).text.split('\n').at(-2).split('\t')[0]
  }
  const lastCode = it.question.split('\n').at(-2)
  const whole = asked === undefined ? 'left-out' : (front.includes(N.ankiHtml('```\n' + lastCode + '\n```').replace(/^<pre><code>|<\/code><\/pre>$/g, '')) && !front.includes('…')) ? 'whole' : 'CUT'
  console.log(s.slot, it.question.length, whole)
}
