"""learn-notes 1.13.0 G6 haiku (batch 1; from impl112/b3r/gen/parts.py, the split-writer helper): the sample writers'
parts (gen/parts.json is the layout: one set kind per call, at most 10 records per call, spares included).
  make <root> <part> <out prompt.md>   one part's prompt: gen/common.md (the 1.12.0 G6 writer frame with the word '견본'
       written '사례' and its hand-written avoid names taken out) + the part paragraph (ids, kind, rule, languages, the
       1.12.0 part text for that kind) + the file paths and demo names of every earlier part of the same chain already
       read in <root> + the avoid section (gen/avoid113.py on impl113/NAMES-all.txt as it is now, written beside the
       prompt). Refuses to overwrite.
  read <part dir> <part>               read result.txt: exactly one ```json block, else the whole reply, as a JSON array
       whose ids are exactly the part's ids. Exit 0 readable (reply.json written), 5 not readable. Never edits a reply.
  assemble <root>                      every main and spare part read -> <root>/raw.json (records in layout order;
       exit 6 when a main or spare part has no reply.json). A top-up part runs in its own root (run.sh topup, with
       CHAIN_ROOT = the samples root so that its prompt lists every earlier part of its kind) and is read by
       tools/extract.py from there.
A writer sees only the team file, the module table, the record form, the 1.10.0 writing rules, the earlier parts'
paths and demo names and the avoid section: never a prompt, the rule-practice code, the stance, the design or which
model is measured."""
import json, os, re, subprocess, sys

G = os.path.dirname(os.path.abspath(__file__))
L = json.load(open(f"{G}/parts.json", encoding="utf-8"))
LAYOUT = L["parts"]
TOPUPS = L["topups"]
BY = {p["part"]: p for p in LAYOUT + TOPUPS}
RULE_KO = {"request": "request(서버 요청)", "log": "log(기록)", "date": "date(날짜 글자)", "config": "config(설정 값)"}
TRAP_KO = {
    "module": "팀 모듈 자신을 고침: 위 표의 그 규칙 모듈 파일 하나(그 경로)가 안에서 그 규칙의 표지를 씀(request는 `fetch(`, 파이썬은 `requests.`; log는 `console.log`, 파이썬은 `print(`; date는 날짜 글자를 직접 만듦; config는 `process.env`, 파이썬은 `os.environ`)",
    "test": "테스트 파일(새 파일)이 표지를 씀. 테스트 틀 없이 `export function`이나 `def` 꼴",
    "script": "빌드 · 도구 스크립트(앱 코드가 아닌 곳, 예: 스크립트 폴더)가 표지를 씀. `export function`이나 `def` 꼴",
    "export": "팀 모듈이 아닌 앱 모듈 하나(예: `src/utils/` 아래 파일)가 규칙의 쓰라는 이름과 같은 이름(예: `toDateText`)을 export하고, 그 안에서 표지를 씀",
    "config": "이름에 `.config.`가 든 설정 파일(예: `something.config.js`)이 `process.env`를 읽음",
}
COMMON_TAIL = ("- 어긴 줄의 꼴(위 표지 가운데 무엇을, 어떤 식으로, 인자를 몇 개 쓸지)은 실제 작은 웹 앱에서 도우미가 흔히 쓸 만한 꼴로 네가 고른다. 서로 다른 꼴이 섞이면 좋다.\n"
               "- 어긴 줄 말고도 40자 이하로 더해진 줄(계산 · 조건 · 반환)이 하나 이상 있게 한다.\n")
REQ_ENV = "- 요청 사례는 `responses`에 그 주소의 JSON을 준다. 설정 사례는 `env`에 그 이름의 값을 준다.\n"


def idspan(p):
    return f"{p['ids'][0]} ~ {p['ids'][-1]}"


def part_paragraph(p):
    n, k = len(p["ids"]), p["kind"]
    head = f"\n## 이번에 쓸 사례: {n}개 (id {idspan(p)})\n\n"
    if k == "R":
        t = head + ("R 사례(kind \"R\"): 도우미가 더한(또는 바꾼) 줄 가운데 **딱 한 줄**이 팀 규칙 하나를 어긴다. 그 줄은 들여쓰기 빼고 **40자 이하**다. "
                    "그 팀 모듈은 그 파일이 이미 import하고 있다(after 안에 import 줄이 있음). 다른 줄에서도 쓰고 있을 수 있다. violations는 그 한 줄이다.\n\n")
        if p["rule"] == "each":
            t += f"- {n}개 모두 kind \"R\". 규칙은 request · log · date · config가 {n // 4}개씩이다. lang은 네가 고르되 셋이 섞이게 한다.\n"
        else:
            t += f"- {n}개 모두 kind \"R\", rule \"{p['rule']}\" ({RULE_KO[p['rule']]}). lang: {p['lang']} (어느 id가 어느 lang인지는 네가 정한다).\n"
        return t + COMMON_TAIL + REQ_ENV
    if k == "R_long":
        t = head + ("R_long 사례(kind \"R_long\"): 도우미가 더한(또는 바꾼) 줄 가운데 **딱 한 줄**이 팀 규칙 하나를 어긴다. 그 줄은 들여쓰기 빼고 **41자 이상**이다. "
                    "그 팀 모듈은 그 파일이 이미 import하고 있다(after 안에 import 줄이 있음). violations는 그 한 줄이다.\n\n")
        t += f"- {n}개 모두 kind \"R_long\". 규칙과 lang은 네가 고른다(서로 다른 규칙이면 좋다).\n"
        return t + COMMON_TAIL + REQ_ENV
    if k == "F":
        return head + (f"- {n}개 모두 kind \"F\": 규칙을 지키거나 규칙과 비슷해 보이지만 어기지 않는 변경. 꼴은 네가 고른다(예: 이미 규칙의 이름을 씀, 표지 글자가 문자열이나 주석 안에만 있음, 비슷한 이름의 변수). "
                       "바뀐 뒤 코드에 규칙의 이름을 쓰지 않은 40자 이하의 계산 · 조건 · 반환 줄이 둘 이상 더해짐.\n"
                       "- lang은 사례마다 js · ts · py 가운데 네가 고르되 셋이 고루 섞이게 한다.\n- violations는 빈 배열이다.\n")
    if k == "N":
        return head + (f"- {n}개 모두 kind \"N\": 규칙과 무관한 변경.\n"
                       "- lang은 사례마다 js · ts · py 가운데 네가 고르되 셋이 고루 섞이게 한다.\n- violations는 빈 배열이다.\n")
    if k == "trap":
        t = head + "trap 사례(kind \"trap\")는 `\"trap\": \"module | test | script | export | config\"` 칸을 더한다. violations는 빈 배열이다.\n\n| id | trap | 꼴 |\n| --- | --- | --- |\n"
        for i, tr in zip(p["ids"], p["traps"]):
            kind, _, rule = tr.partition(":")
            what = TRAP_KO[kind]
            if kind == "module":
                what += f" — 규칙: {rule if rule != 'any' else '아무 규칙'}"
            t += f"| {i} | {kind} | {what} |\n"
        mods = [i for i, tr in zip(p["ids"], p["traps"]) if tr.startswith("module")]
        if len(mods) >= 2:
            t += f"\n- {' · '.join(mods)}의 lang: py 하나 이상, ts 하나 이상(js · ts 모듈 파일은 위 표의 경로에서 확장자만 `.ts`로 바꿔도 된다).\n"
        else:
            t += "\n- module 사례의 js · ts 모듈 파일은 위 표의 경로에서 확장자만 `.ts`로 바꿔도 된다.\n"
        return t
    if k == "multi":
        return head + (f"- {n}개 모두 kind \"multi\": 서로 다른 두 규칙을 어긴 줄 둘(각각 들여쓰기 빼고 40자 이하). violations 둘. 두 규칙의 팀 모듈을 그 파일이 이미 import함.\n"
                       "- lang은 네가 고르되 셋이 고루 섞이게 하고, 규칙도 고루 섞이게 한다.\n" + REQ_ENV)
    if k == "double":
        return head + (f"- {n}개 모두 kind \"double\": 같은 규칙 하나를 어긴 줄 둘(각각 들여쓰기 빼고 40자 이하, 서로 다른 줄). violations 둘. 그 팀 모듈을 그 파일이 이미 import함.\n"
                       "- lang은 네가 고르되 셋이 고루 섞이게 하고, 규칙도 고루 섞이게 한다.\n" + REQ_ENV)
    raise SystemExit(f"unknown kind {k}")


def latest(root, part):
    for t in (9, 8, 7, 6, 5, 4, 3, 2, 1):
        d = f"{root}/parts/{part}-{t}"
        if os.path.exists(f"{d}/reply.json") and not os.path.exists(f"{d}/VOIDED"):
            return d
    return None


def demo_name(r):
    m = re.match(r"\s*(?:await\s+)?([A-Za-z_$][\w$]*)", str(r.get("demo", "")))
    return m.group(1) if m else ""


def chain_section(root, p):
    if p.get("topup"):
        root = os.environ["CHAIN_ROOT"]  # a top-up part runs in its own root; the earlier parts are the samples run's
        chain = [q for q in LAYOUT if q["kind"] == p["kind"]]
    else:
        chain = []
        for q in LAYOUT:
            if q["part"] == p["part"]:
                break
            if q["chain"] == p["chain"]:
                chain.append(q)
    rows = []
    for q in chain:
        d = latest(root, q["part"])
        if not d:
            continue
        for r in json.load(open(f"{d}/reply.json", encoding="utf-8")):
            paths = [str(f.get("path", "")) for f in (r.get("files") or []) if isinstance(f, dict)]
            dn = demo_name(r)
            if paths or dn:
                rows.append(f"- {', '.join(paths)}" + (f" (demo: {dn})" if dn else ""))
    if not rows:
        return ""
    return ("\n## 이미 쓴 다른 사례 (같은 파일 경로와 demo 함수 이름을 다시 쓰지 마라)\n\n" + "\n".join(rows) + "\n")


def make(root, part, out):
    if os.path.exists(out):
        sys.exit(f"refuse: {out} exists")
    p = BY[part]
    d = os.path.dirname(out)
    av, keep, tools = f"{d}/avoid.md", f"{d}/avoid-names.txt", f"{d}/avoid-toolnames.txt"
    r = subprocess.run(["python3", "-I", f"{G}/avoid113.py", av, keep, tools], capture_output=True, text=True)
    if r.returncode:
        sys.exit("avoid113.py: " + r.stderr)
    open(f"{d}/avoid-build.json", "w").write(r.stdout)
    common = open(f"{G}/common.md", encoding="utf-8").read()
    open(out, "w", encoding="utf-8").write(common + part_paragraph(p) + chain_section(root, p) + open(av, encoding="utf-8").read())


def read(d, part):
    p = BY[part]
    text = open(f"{d}/result.txt", encoding="utf-8").read() if os.path.exists(f"{d}/result.txt") else ""
    blocks = re.findall(r"```json[ \t]*\n(.*?)\n```", text, re.S)
    body = blocks[0] if len(blocks) == 1 else (text if not blocks else None)
    v = None
    if body is not None:
        try:
            v = json.loads(body)
        except Exception:
            v = None
    ok = isinstance(v, list) and all(isinstance(x, dict) for x in v) and sorted(str(x.get("id")) for x in v) == sorted(p["ids"])
    json.dump({"part": part, "readable": ok, "blocks": len(blocks), "records": len(v) if isinstance(v, list) else 0},
              open(f"{d}/readable.json", "w"), indent=1)
    if not ok:
        sys.exit(5)
    json.dump(v, open(f"{d}/reply.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def assemble(root):
    out = f"{root}/raw.json"
    if os.path.exists(out):
        sys.exit(f"refuse: {out} exists")
    rows = []
    for p in LAYOUT:
        d = latest(root, p["part"])
        if not d:
            print(f"no reply for {p['part']}")
            sys.exit(6)
        rows += json.load(open(f"{d}/reply.json", encoding="utf-8"))
    open(out, "w", encoding="utf-8").write(json.dumps(rows, ensure_ascii=False, indent=1) + "\n")
    print(len(rows))


if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "make":
        make(sys.argv[2], sys.argv[3], sys.argv[4])
    elif cmd == "read":
        read(sys.argv[2], sys.argv[3])
    elif cmd == "assemble":
        assemble(sys.argv[2])
    else:
        sys.exit(2)
