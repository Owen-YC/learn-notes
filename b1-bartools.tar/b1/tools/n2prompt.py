"""learn-notes 1.13.0 G6 haiku (batch 1; from impl112/b1/tools/n2prompt.py) the N2 answer writers' prompts for one
label (1.10.0 N2 (2), plan secondStage): ONE PROMPT PER PICKED PRACTICE (the declared exception to 'one set kind per
call': four answer kinds of one practice, 10 records), each the frame gen/n2-frame.md with the team file and that one
practice as gradeDrill shows it (file and row,
the code-written task and check, the line, the example, the note's rule line) plus the sample's demo and its changed
file whole. Nothing else: no grading prompt, no RULE_CHECK, no stance, no model name.
usage: n2prompt.py <label>  -> gen/n2/<label>/inputs/<practice id>.md, one per pick (gen/run.sh <root> files json runs
them; refuses to overwrite)"""
import json, os, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1"
J = os.environ.get("JUDGE", f"{S}/judge")
FROZEN = os.environ.get("FROZEN", f"{S}/frozen")
label = sys.argv[1]
GEN = os.environ.get("GEN_N2", f"{S}/gen/n2")
out_d = f"{GEN}/{label}/inputs"
if os.path.exists(out_d):
    sys.exit(f"refuse: {out_d} exists")
picks = json.load(open(f"{J}/{label}/picks.json", encoding="utf-8"))
if picks["fails"]:
    sys.exit(f"{label}: fewer than 5 correct practices: N2 fails, no writer")
samples = {s["id"]: s for s in json.load(open(f"{FROZEN}/samples.json", encoding="utf-8"))}
parts = {}
for p in picks["picks"]:
    s, d = samples[p["id"]], p["drill"]
    f = next(x for x in s["files"] if x["path"] == d["file"])
    parts[p["id"]] = (f"""### 연습 {p['id']}
- 파일: `{d['file']}` ({d['n']}행)
- 할 일: {d['task']}
- 확인: {d['check']}
- 고칠 줄: `{d['line']}`
- 예시 답: `{d['example']}`
- 노트가 짚은 팀 규칙: {p['said']}
- 돌려 보는 호출(첫 파일 끝에서): `{s['demo']}`
- 파일 전체(바뀐 뒤):
```
{f['after']}
```
""")
frame = open(f"{S}/gen/n2-frame.md", encoding="utf-8").read()
team = open(f"{S}/team.md", encoding="utf-8").read()
os.makedirs(out_d)
for pid, part in parts.items():
    text = frame.replace("{TEAM}", "```markdown\n" + team + "```").replace("{PRACTICES}", part)
    open(f"{out_d}/{pid}.md", "w", encoding="utf-8").write(text)
    print(label, pid, len(text))
