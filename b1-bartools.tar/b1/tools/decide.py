"""learn-notes 1.13.0 G6 haiku (batch 1; from impl112/b1/tools/decide.py) the committed decision rule, by machine (after every verdict file is frozen; it
opens the pair at its end). Per label, from that label's files only:
  W        both rounds: 0 §11 false positives (OFF reading) and keptNoteText idempotent on every reply
  N1' per round A and B (all must pass in both):
    (a) O >= 20 and rule practices on O notes 0
    (b) den >= 20; correct >= 80% of den; harmful 0 (all answered notes, both readings); two task lines 0 (both readings)
    (c) O notes: final text the same ON/OFF, no practice call on an O note; and D34 (pre and real) all the same
    traps 0 rule practices; R_long and notes with no <= 40 violating line 0 rule practices; unlabelled 0 (both readings)
    old windows 0 bad
  no-answer: count.py's rule-drill line (both rounds: <= max(1, floor(n/60)))
  N2: picks >= 5 correct (else fails); both runs pass (n2build.mjs judge: correct >= 27 · break→맞음 <= 1 · broken→맞음 0 ·
      missing 규칙 <= 1 · keep caps 0 (NEW) · pre-cap (break + broken)→맞음 <= 2 (NEW), counted on the 1.13.0 gradeDrill
      verdict); D34 of the N2 requests all the same
  void: a model-stage summary with void10, an after record that differs, or a stage not DONE -> that model OFF
  row check: every row the label's checker listed counts the way unfavourable to passing (M-9)
  tool sanity: offW0 equal to the tree's keptNoteText(reply, []) and the OFF text the kept text on every row; else
  the rule cannot be applied as written -> fails (§15)
isRuleDrill_m = MODEL_SWITCHES[m].isRuleWide at the bar commit (mtree) ∧ W ∧ N1' A ∧ N1' B ∧ no-answer ∧ N2 ∧ not void.
A model with no label in pair.json (sonnet in 1.13.0: not measured) stays false: no transfer.
usage: decide.py -> judge/decision.json (chmod 444)"""
import json, os, re, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1"
J = os.environ.get("JUDGE", f"{S}/judge")
STAGE = os.environ.get("STAGE", f"{S}/stage")
D34 = os.environ.get("D34", f"{S}/d34")
out_p = f"{J}/decision.json"
if os.path.exists(out_p):
    sys.exit("refuse: decision exists")
rj = lambda p: json.load(open(p, encoding="utf-8"))

def SD(st, m):
    """The stage dir that counts: '<st>-r2' when the cut-stage rule ran it (its DONE there), else '<st>'."""
    r2 = f"{STAGE}/{st}-r2/{m}"
    return r2 if os.path.exists(f"{r2}/DONE") else f"{STAGE}/{st}/{m}"

ok_file = lambda p: os.path.exists(p) and rj(p).get("bad") == 0 and rj(p).get("testExit") == 0


def rule_wide_on():
    t = open(f"{S}/mtree/hooks/notes.ts", encoding="utf-8").read()
    m = re.search(r"export const MODEL_SWITCHES[^=]*= Object\.freeze\(\{(.*?)\n\}\)", t, re.S)
    rows = dict(re.findall(r"(haiku|sonnet): Object\.freeze\(\{([^}]*)\}\)", m.group(1)))
    return {k: "isRuleWide: true" in v for k, v in rows.items()}


def per_label(label, model):
    lines, info = {}, {}
    rc = rj(f"{J}/rowcheck-{label}.json")["rows"] if os.path.exists(f"{J}/rowcheck-{label}.json") else None
    for r in ("A", "B"):
        c = rj(f"{J}/verdicts-{label}-{r}.json")["c"]
        flagged = [x for x in (rc or []) if x.get("round") == r]
        down = sum(1 for x in flagged if x.get("field") == "correct")
        extra = {f: sum(1 for x in flagged if x.get("field") == f) for f in ("harm", "unlabelled", "O_rule", "trap_rule", "noShort_rule", "twoTask", "w_fp", "old_bad", "c_bad", "other")}
        correct = max(0, c["correct"] - down)
        lines[f"{r}:a"] = c["O"] >= 20 and not c["O_rule"] and extra["O_rule"] == 0
        lines[f"{r}:b"] = c["den"] >= 20 and correct * 10 >= 8 * c["den"] and not c["harmful"] and extra["harm"] == 0 and not c["twoTask"] and extra["twoTask"] == 0
        lines[f"{r}:c"] = not c["c_bad"] and extra["c_bad"] == 0
        lines[f"{r}:traps"] = not c["trap_rule"] and extra["trap_rule"] == 0
        lines[f"{r}:noShort"] = not c["noShort_rule"] and extra["noShort_rule"] == 0
        lines[f"{r}:unlabelled"] = not c["unlabelled"] and extra["unlabelled"] == 0
        lines[f"{r}:oldWindows"] = not c["old_bad"] and extra["old_bad"] == 0
        lines[f"{r}:W"] = not c["w_fp"] and extra["w_fp"] == 0 and not c["idem_bad"]
        lines[f"{r}:sane"] = not c["offW0_differs_tree"] and not c["off_not_kept"] and not c["undecided"] and extra["other"] == 0
        info[r] = {"O": c["O"], "L": c["L"], "den": c["den"], "correct": c["correct"], "correctAfterRowCheck": correct, "harmful": len(c["harmful"]),
                   "twoTask": len(c["twoTask"]), "O_rule": len(c["O_rule"]), "trap_rule": len(c["trap_rule"]), "noShort_rule": len(c["noShort_rule"]),
                   "unlabelled": len(c["unlabelled"]), "old_bad": len(c["old_bad"]), "w_fp": len(c["w_fp"]), "w_changed": c["w_changed"],
                   "idem_bad": len(c["idem_bad"]), "undecided": len(c["undecided"]), "unanswered": len(c["unanswered"]), "tiers": c["tiers"], "rowCheckFlagged": len(flagged)}
    lines["rowCheckDone"] = rc is not None
    cnt = rj(f"{J}/count-{label}.json")
    lines["noAnswer"] = cnt["ruleDrillNoAnswer"]["pass"]
    lines["D34"] = ok_file(f"{D34}/pre/result.json") and all(ok_file(f"{SD(r, model)}/d34/result.json") or not os.path.exists(f"{SD(r, model)}/drill-lines.jsonl") or os.path.getsize(f"{SD(r, model)}/drill-lines.jsonl") == 0 for r in ("A", "B"))
    picks = rj(f"{J}/{label}/picks.json") if os.path.exists(f"{J}/{label}/picks.json") else {"fails": True, "correct": 0}
    n2 = [rj(f"{J}/n2-{label}-{k}.json") for k in (1, 2) if os.path.exists(f"{J}/n2-{label}-{k}.json")]
    # N2 checker (plan judges, M-9): every row it lists counts the way unfavourable to passing, in its run.
    nc = rj(f"{J}/n2check-{label}.json")["rows"] if os.path.exists(f"{J}/n2check-{label}.json") else None
    lines["n2CheckDone"] = nc is not None or picks["fails"]
    n2pass = []
    for k, x in enumerate(n2, 1):
        fl = [r for r in (nc or []) if str(r.get("run")) == str(k)]
        f = lambda name: sum(1 for r in fl if r.get("field") == name)
        y = {"correct": x["correct"] - f("correct"), "breakRight": x["breakRight"] + f("breakRight"), "brokenRight": x["brokenRight"] + f("brokenRight"),
             "noRuleLine": x["noRuleLine"] + f("noRuleLine"), "keepCapped": x["keepCapped"] + f("keepCapped"),
             "preCapWrongRight": x["preCapWrongRight"] + f("preCapWrongRight"), "other": f("other")}
        n2pass.append(x["pass"] and y["correct"] >= 27 and y["breakRight"] <= 1 and y["brokenRight"] == 0 and y["noRuleLine"] <= 1
                      and y["keepCapped"] == 0 and y["preCapWrongRight"] <= 2 and y["other"] == 0)
    lines["N2"] = not picks["fails"] and len(n2) == 2 and all(n2pass) and ok_file(f"{D34}/n2-{model}/result.json")
    info["N2"] = {"checkerFlagged": len(nc or []), "passAfterChecker": n2pass, "correctPractices": picks["correct"], "dropped": picks.get("dropped"), "runs": [{k: x[k] for k in ("n", "correct", "breakRight", "brokenRight", "noRuleLine", "keepCapped", "preCapWrongRight", "capped", "afterMissing", "pass")} for x in n2]}
    info["noAnswer"] = cnt["ruleDrillNoAnswer"]
    void = []
    for st in ("A", "B", "N2-1", "N2-2"):
        d = SD(st, model)
        if not os.path.exists(f"{d}/DONE"):
            void.append(f"{st}: not done")
        elif rj(f"{d}/summary.json").get("void10") or not rj(f"{d}/after.json").get("same"):
            void.append(f"{st}: void")
    lines["notVoid"] = not void
    info["void"] = void
    return lines, info


if __name__ == "__main__":
    labels = rj(f"{J}/pair.json")["labels"]
    wide = rule_wide_on()
    res = {"isRuleWideAtBar": wide, "labels": {}, "models": {}}
    for model, label in labels.items():
        lines, info = per_label(label, model)
        res["labels"][label] = {"lines": lines, "info": info, "pass": all(lines.values())}
    for model, label in labels.items():
        res["models"][model] = {"label": label, "isRuleDrill": bool(wide.get(model)) and res["labels"][label]["pass"], "isRuleWide": "unchanged (not re-decided)"}
    for model in ("haiku", "sonnet"):
        if model not in labels:
            res["models"][model] = {"label": None, "isRuleDrill": False, "why": "not measured in 1.13.0 (no transfer)", "isRuleWide": "unchanged (not re-decided)"}
    body = json.dumps(res, ensure_ascii=False, indent=1) + "\n"
    open(out_p, "w", encoding="utf-8").write(body)
    os.chmod(out_p, 0o444)
    print(body)
