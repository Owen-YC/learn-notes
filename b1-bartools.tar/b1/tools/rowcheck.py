"""learn-notes 1.13.0 G6 haiku (batch 1; from impl112/b1/tools/rowcheck.py; the call itself now runs through the
detached runner gen/run.sh, plan writerRunner) row check (1.10.0 detail 21; plan judges): per label one fresh sub-agent
(`claude -p --model opus --tools ''`, empty dir, pinned CLI) that gets only that label's verdict files (rounds A and
B, the row evidence) and the stance with its details (judge/stance-G6.md, the bar commit's text), never the other
label, a model name, tokens, time or caps. It lists rows the script did not count as the text says.
  prompt <label>  -> judge/rowcheck/<label>/inputs/rowcheck.md
  (run)           -> `bash gen/run.sh judge/rowcheck/<label> files json`, detached (STATUS DONE when answered)
  parse <label>   -> judge/rowcheck-<label>.json (chmod 444): the rows listed; decide.py counts each listed row the
                     way unfavourable to passing (M-9: a judge/checker split counts against), and M-15 applies to a
                     tool defect it shows (the text wins; both labels counted again; a fail never turns into ON)."""
import hashlib, json, os, re, subprocess, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1"
P = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/cli/pinned.sh"
J = os.environ.get("JUDGE", f"{S}/judge")
mode, label = sys.argv[1], sys.argv[2]
if label not in ("P", "Q"):
    sys.exit("label P or Q")
d = f"{J}/rowcheck/{label}"
if mode == "prompt":
    os.makedirs(d, exist_ok=True)
    if os.path.exists(f"{d}/inputs/rowcheck.md"):
        sys.exit("refuse: prompt exists")
    os.makedirs(f"{d}/inputs")
    stance = open(f"{S}/judge/stance-G6.md", encoding="utf-8").read()
    ver = "\n\n".join(open(f"{J}/verdicts-{label}-{r}.md", encoding="utf-8").read() for r in ("A", "B"))
    tpl = open(f"{S}/judge/tpl-rowcheck.md", encoding="utf-8").read()
    open(f"{d}/inputs/rowcheck.md", "w", encoding="utf-8").write(tpl.replace("{LABEL}", label).replace("{STANCE}", stance).replace("{VERDICTS}", ver))
    print(label, os.path.getsize(f"{d}/inputs/rowcheck.md"))
elif mode == "parse":
    out_p = f"{J}/rowcheck-{label}.json"
    if os.path.exists(out_p):
        sys.exit("refuse: exists")
    if open(f"{d}/STATUS").read().strip() != "DONE":
        sys.exit("refuse: the row check run is not DONE")
    tries = [x for x in sorted(os.listdir(f"{d}/parts"), key=lambda x: int(x.rsplit("-", 1)[1])) if os.path.exists(f"{d}/parts/{x}/reply.json") and not os.path.exists(f"{d}/parts/{x}/VOIDED")]
    t = json.load(open(f"{d}/parts/{tries[-1]}/reply.json", encoding="utf-8"))["text"]
    m = re.search(r"```json\s*\n(.*?)\n```", t, re.S)
    rows = json.loads(m.group(1) if m else t)
    body = json.dumps({"label": label, "rows": rows, "promptSha256": hashlib.sha256(open(f"{d}/inputs/rowcheck.md", "rb").read()).hexdigest()}, ensure_ascii=False, indent=1) + "\n"
    open(out_p, "w", encoding="utf-8").write(body)
    os.chmod(out_p, 0o444)
    print(label, len(rows))
else:
    sys.exit("usage: rowcheck.py prompt|parse <label>")
