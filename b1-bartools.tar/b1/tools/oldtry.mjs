// learn-notes 1.13.0 batch 1 build (old-window probe, the stored-first-try half; plan commonPerBatch.oldWindowProbe G6:
// "a 1.13.0 first try with code feedback shows as any first try"). 0 model calls. A first try the ON grade cap keeps
// is the 1.7.0 shape { mine, verdict: 'partial', feedback, nudge, at } with code's words in feedback/nudge. For every
// cap text (ruleCapText of each reason, long names cut) and both nudges (RULE_CAP_NUDGE, drillRuleHint), the seven
// real builds' functions read it as any first try: isDrillOver false; the try again's grading prompt
// (checkPrompt(item, line, 'beginner', firstTry, undefined, { rule })) holds the feedback and nudge as written and equals
// that build's prompt for a model-written first try with the strings swapped back; and the batch tree's prompt
// equals 30adc2f's to the byte.
// usage: node --experimental-transform-types oldtry.mjs <tree notes.ts> <tree tests/fixtures/rule19.ts> → JSON summary
import { pathToFileURL } from 'node:url'
const S = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1'
const N = await import(pathToFileURL(process.argv[2]).href)
const FX = await import(pathToFileURL(process.argv[3]).href)
const OLD = ['3f2b4fb', '7a7b08c', '3690021', 'fca5988', '3d2f251', 'de98243', '30adc2f']
const O = Object.fromEntries(await Promise.all(OLD.map(async c => [c, await import(pathToFileURL(`${S}/oldprobe/${c}/hooks/notes.ts`).href)])))
const I = FX.INPUT_RULE19
const rule = FX.OUTPUT_RULE19.drill.rule
const caps = [
  { why: 'rule-use', name: 'apiRequest' },
  { why: 'rule-old', name: 'fetch' },
  { why: 'name', name: 'options' },
  { why: 'name', name: 'aVeryLongNameOfSomething' },
  { why: 'brackets' },
  { why: 'swap', from: '`/users/${id}`', to: 'id' },
]
const nudges = [N.RULE_CAP_NUDGE, `팀 규칙과 다를 수 있음: ${rule} · 이 줄에서 바꿀 곳 한 군데를 찾아보세요`]
const line = '  const res = await apiRequest(`/users/${id}`)'
const bad = []
let reads = 0, firstTries = 0
for (const cap of caps) for (const nudge of nudges) {
  const feedback = N.ruleCapText(cap)
  const ft = { mine: 'const res = await apiRequest(url, options)', verdict: 'partial', feedback, nudge, at: 1790989200000 }
  const plain = { ...ft, feedback: '모델이 쓴 피드백입니다.', nudge: '모델이 쓴 되묻기입니다.' }
  firstTries += 1
  const ref = O['30adc2f'].checkPrompt(I.item, line, 'beginner', ft, undefined, { rule })
  if (N.checkPrompt(I.item, line, 'beginner', ft, undefined, { rule }) !== ref) bad.push(`${cap.why} batch tree ≠ 30adc2f`)
  for (const c of OLD) {
    reads += 1
    const M = O[c]
    if (M.isDrillOver({ firstTry: ft }) !== false) bad.push(`${c} ${cap.why}: isDrillOver`)
    const p = M.checkPrompt(I.item, line, 'beginner', ft, undefined, { rule })
    const q = M.checkPrompt(I.item, line, 'beginner', plain, undefined, { rule })
    if (!p.includes(feedback) || !p.includes(nudge)) bad.push(`${c} ${cap.why}: feedback/nudge not shown as written`)
    if (q.split(plain.feedback).join(feedback).split(plain.nudge).join(nudge) !== p) bad.push(`${c} ${cap.why}: read otherwise than a model's first try`)
  }
}
console.log(JSON.stringify({ builds: OLD, firstTries, reads, bad: bad.length, first: bad.slice(0, 10) }, null, 1))
