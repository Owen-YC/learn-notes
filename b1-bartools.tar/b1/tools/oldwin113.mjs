// learn-notes 1.12.0 batch 1 (G6 build): the old-window probe (plan commonPerBatch.oldWindowProbe, R9) re-run on the
// batch tree. Inputs are byte-comparison inputs only (never measurement): the G6 design's dev sets 1-4 (samples,
// hunks) and their recorded note replies and tier-2 replies (design/G6/pilot/<set>/note|drill/<model>/out.json), plus
// the design pilot's recorded ON/OFF/variant texts of sets 1-3 (read-<model>.json, the prototype task swapped for
// RULE_FIX_TASK). From each recorded note reply the batch tree makes the texts a window keeps:
//   OFF  keptNoteText(reply, ruleNames) (the shipped rows, isRuleWide on) and keptNoteText(reply, []) (every switch off);
//   ON   the OFF text with the practice code makes (ruleFixPlan: tier 1 ruleFixMade, tier 2 the recorded reply through
//        ruleFixReply; none made: the OFF text).
// Every distinct text is read by the six real builds' notes.ts (git show <c>:hooks/notes.ts, oldprobe/<c>):
//   a text holding a marked task line (`- 할 일 (팀 규칙):`): no practice (drillOf) and no 고칠 줄 / 예시 답 shown
//   (hideDrillAnswer) in any of them; an unmarked text: each one's practice the same as 3d2f251's (task, line, example,
//   file, n). The batch tree reads each ON text with the switch on (a made practice → that rule's practice; any other
//   marked one → none) and each text with it off (no rule practice).
// usage: node --experimental-transform-types oldwin.mjs <tree notes.ts> → JSON summary on stdout
import { readFileSync, existsSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
const I = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112'
const D = `${I}/design/G6`
const N = await import(pathToFileURL(process.argv[2]).href)
const K = await import(pathToFileURL(`${D}/tools/notekit.mjs`).href)
const OLD = ['3f2b4fb', '7a7b08c', '3690021', 'fca5988', '3d2f251', 'de98243', '30adc2f']  // 1.13.0: 30adc2f (1.12.0) added
const O = Object.fromEntries(await Promise.all(OLD.map(async c => [c, await import(pathToFileURL(`/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1/oldprobe/${c}/hooks/notes.ts`).href)])))  // 1.13.0 batch 1: all seven from impl113/b1/oldprobe (git archive)
const PROTO_TASK = '바뀐 코드에서 팀 규칙과 다른 한 줄을 규칙대로 고쳐 보세요.'
const J = p => JSON.parse(readFileSync(p, 'utf8'))
const team = N.parseTeamFile(readFileSync(`${D}/team.md`, 'utf8'))
const rules = team.rules
const names = N.ruleNamesOf(rules)
const pick = d => (d === undefined ? null : JSON.stringify([d.task, d.line, d.example, d.file, d.n]))
const SHOWS = /^\s*(?:[-*+•]\s+)?(?:\*\*)?\s*(?:고칠\s*줄|예시\s*답)\s*(?:\*\*)?\s*[:：]/
const bad = []
const counts = { texts: 0, reads: 0, marked: 0, unmarked: 0, made: { tier1: 0, tier2: 0 }, newOn: 0, newOff: 0 }
const seen = new Set()
function check(where, text, changes, kind) {
  const key = JSON.stringify([text, changes])
  if (seen.has(key)) return
  seen.add(key)
  counts.texts += 1
  const marked = text.split('\n').some(l => l.startsWith('- 할 일 (팀 규칙):'))
  counts[marked ? 'marked' : 'unmarked'] += 1
  const ref = pick(O['3d2f251'].drillOf(text, changes, kind === 'on'))
  for (const c of OLD) {
    counts.reads += 1
    const d = O[c].drillOf(text, changes)
    const shows = O[c].hideDrillAnswer(text).split('\n').some(l => SHOWS.test(l))
    if (marked && (d !== undefined || shows)) bad.push(`${where} ${c}: marked text read as practice=${d !== undefined} shows=${shows}`)
    if (!marked && pick(d) !== ref) bad.push(`${where} ${c}: unmarked practice differs from 3d2f251`)
  }
  // The batch tree: off, no rule practice anywhere; on, only a practice code made.
  counts.newOff += 1
  const off = N.drillOf(text, changes, false)
  if (off?.rule !== undefined) bad.push(`${where} new off: a rule practice read`)
  if (kind === 'on') {
    counts.newOn += 1
    const on = N.drillOf(text, changes, true)
    if (on?.rule !== undefined && on.task.trim() !== N.RULE_FIX_TASK) bad.push(`${where} new on: a rule practice code did not make read`)
  }
}
for (const set of ['set1', 'set2', 'set3', 'set4']) {
  const hunks = Object.fromEntries(J(`${D}/dev/${set}/hunks.json`).map(o => [o.id, o]))
  const samples = J(`${D}/dev/${set}/samples.json`)
  for (const model of ['haiku', 'sonnet']) {
    const notes = Object.fromEntries(J(`${D}/pilot/${set}/note/${model}/out.json`).results.map(r => [r.id, r]))
    const drillPath = `${D}/pilot/${set}/drill/${model}/out.json`
    const drills = existsSync(drillPath) ? Object.fromEntries(J(drillPath).results.map(r => [r.id, r])) : {}
    for (const sample of samples) {
      const got = notes[sample.id]
      if (!got?.isAnswered) continue
      const note = K.noteOf(N, hunks[sample.id], sample)
      const shown = N.screenNote(note, team.excludes ?? [], () => false)
      const offWide = N.keptNoteText(got.text, names)
      const offAll = N.keptNoteText(got.text, [])
      const where = `${set}/${model}/${sample.id}`
      check(`${where} off-wide`, offWide, note.changes, 'off')
      check(`${where} off-all`, offAll, note.changes, 'off')
      const said = N.noteRuleOf(offWide)
      let on = offWide
      if (said !== undefined) {
        const plan = N.ruleFixPlan(shown, rules, said)
        if ('fix' in plan) {
          const made = N.ruleFixMade(offWide, plan.fix, note.changes)
          if (made !== undefined) { on = made; counts.made.tier1 += 1 }
        } else if ('cands' in plan && drills[sample.id]?.isAnswered) {
          const r = N.ruleFixReply(offWide, drills[sample.id].text, plan, rules, said, note.changes)
          if ('text' in r) { on = r.text; counts.made.tier2 += 1 }
        }
      }
      check(`${where} on`, on, note.changes, 'on')
    }
  }
  // The design pilot's recorded texts (sets 1-3), read again.
  if (set === 'set4') continue
  for (const model of ['haiku', 'sonnet']) {
    const rows = J(`${D}/pilot/${set}/read${set === 'set1' ? '-r1' : ''}-${model}.json`)
    for (const [id, r] of Object.entries(rows)) {
      if (!r?.answered) continue
      for (const [kind, t] of [['on', r.on], ['off', r.off], ['off', r.offW0], ['on', r.variant]]) {
        if (typeof t !== 'string') continue
        check(`${set}/${model}/${id} pilot-${kind}`, t, r.changes, kind)
        check(`${set}/${model}/${id} pilot-${kind}-task`, t.split(PROTO_TASK).join(N.RULE_FIX_TASK), r.changes, kind)
      }
    }
  }
}
console.log(JSON.stringify({ builds: OLD, ...counts, bad: bad.length, first: bad.slice(0, 20) }, null, 1))
