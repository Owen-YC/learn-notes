"""learn-notes 1.13.0 G6 haiku (batch 1; from impl112/b1/tools/extract.py): the writer parts' answers as one array
(frozen/raw.json, chmod 444) and who wrote what (frozen/raw.meta.json: part, try, count, UTC start/end, the writer's
modelUsage keys, the prompt's and the answer's sha256). Reads gen/out (the samples run of gen/run.sh, STATUS DONE) part by
part in layout order, then any top-up root gen/out-topup-<K> whose STATUS is DONE. An answer is the part's reply.json
(parts.py read: exactly one ```json block, else the whole reply; ids exactly the part's); nothing in it is changed. A try
marked VOIDED is never used. Refuses to overwrite, and refuses when an id is outside its part's ids or appears twice.
usage: extract.py"""
import glob, hashlib, json, os, sys
S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1"
GEN = os.environ.get("GENOUT", f"{S}/gen/out")
FROZEN = os.environ.get("FROZEN", f"{S}/frozen")
dst, meta_dst = f"{FROZEN}/raw.json", f"{FROZEN}/raw.meta.json"
if os.path.exists(dst):
    sys.exit(f"refuse: {dst} exists")
L = json.load(open(f"{S}/gen/parts.json", encoding="utf-8"))
if open(f"{GEN}/STATUS").read().strip() != "DONE":
    sys.exit("refuse: the samples run is not DONE")


def latest(root, part):
    best = None
    for d in glob.glob(f"{root}/parts/{part}-*"):
        if os.path.exists(f"{d}/reply.json") and not os.path.exists(f"{d}/VOIDED"):
            best = d
    return best


rows, meta = [], []
todo = [(GEN, p) for p in L["parts"]]
for p in L["topups"]:
    root = f"{GEN}-topup-{p['part'][3:]}"
    if os.path.exists(f"{root}/STATUS") and open(f"{root}/STATUS").read().strip() == "DONE":
        todo.append((root, p))
for root, p in todo:
    d = latest(root, p["part"])
    if d is None:
        sys.exit(f"refuse: no reply for {p['part']} in {root}")
    arr = json.load(open(f"{d}/reply.json", encoding="utf-8"))
    bad = [s.get("id") for s in arr if s.get("id") not in p["ids"]]
    if bad or len(arr) != len(p["ids"]):
        sys.exit(f"refuse: part {p['part']} ids {bad}")
    rows += arr
    meta.append({"part": p["part"], "kind": p["kind"], "spare": p["spare"], "topup": bool(p.get("topup")), "try": os.path.basename(d), "n": len(arr),
                 "started": open(f"{d}/started.txt").read().strip(), "ended": open(f"{d}/ended.txt").read().strip(),
                 "writer": json.load(open(f"{d}/model.txt")), "promptSha256": open(f"{d}/prompt.sha256").read().split()[0],
                 "resultSha256": hashlib.sha256(open(f"{d}/result.txt", "rb").read()).hexdigest()})
ids = [s["id"] for s in rows]
if len(ids) != len(set(ids)):
    sys.exit("refuse: an id twice")
os.makedirs(FROZEN, exist_ok=True)
txt = json.dumps(rows, ensure_ascii=False, indent=1) + "\n"
open(dst, "w", encoding="utf-8").write(txt)
os.chmod(dst, 0o444)
json.dump({"rawSha256": hashlib.sha256(txt.encode("utf-8")).hexdigest(), "parts": meta,
           "author": "claude -p --model opus --tools '' (fresh, blind; pinned CLI; one set kind and at most 10 records per call)"},
          open(meta_dst, "w"), ensure_ascii=False, indent=1)
os.chmod(meta_dst, 0o444)
print(len(rows), hashlib.sha256(txt.encode("utf-8")).hexdigest())
