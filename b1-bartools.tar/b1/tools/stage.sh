#!/bin/bash
# learn-notes 1.13.0 G6 haiku (batch 1; from impl112/b1/tools/stage.sh): one model-stage, run DETACHED (plan runnerRules), e.g.
#   ONLY_WORKFLOW=1 setsid nohup bash tools/stage.sh A haiku > stage/A-haiku.log 2>&1 < /dev/null &
# stage A | B: round A or B, the note calls (frozen/note-lines-<model>.jsonl) then that model's tier-2 calls (built by
#   tools/build.mjs drill from its own note answers; D34 of those requests against the plugin test harness first);
# stage N2-1 | N2-2: the N2 grading calls of that model (frozen/n2-lines-<model>.jsonl).
# 1.13.0: haiku only (sonnet is not measured; refused). Order: B after A; N2-1 after the N2 lines are frozen; N2-2 after
# N2-1. Refuses a stage whose STARTED exists (cut-stage rule: the main loop decides). Cut-stage rule (plan cutStageRule):
# a stage cut by a usage limit, a suspend/restart or a killed process ends with exit 9 CUT and a summary.json judged on
# status counts only (every frozen request with no status line = an api-error; tier-2 requests not yet built cannot be
# counted and are left out); above 10% it is VOID (cut) and '<stage>-r2' may run once, whole, on another day with the
# same request file (sha256 checked); '<stage>-r2' is allowed only when '<stage>' holds such a VOID summary. Gates (plan
# usageGate): every stage five_hour <= 0.60 and seven_day + 0.01 < 0.80; round A (A or A-r2) also seven_day + 0.08 < 0.80. Before: an 'ok' session
# (probe/precheck.sh) = the before record and the usage gate (tools/gate.py pre): record differs -> exit 3 (STOP, not
# called); gate fails -> exit 7 (WAIT, its resetsAt printed; no STARTED written, may run again later). Then STARTED
# (UTC, request file sha256), the probe sessions (each call's status line in <session>/status.jsonl), the after
# record (exit 4 VOID when it differs). A call that threw (the engine refused before sending) -> exit 5 (M-4 line 4).
# API errors above 10% of the model-stage's calls -> exit 6 (M-4: void, nothing opened). No call is ever sent again.
# Only status is printed; never an answer's text. Every claude process goes through cli/pinned.sh.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1
P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/cli/pinned.sh
ST="$1"; M="$2"
case "$ST" in A|B|N2-1|N2-2|A-r2|B-r2|N2-1-r2|N2-2-r2) ;; *) echo "usage: stage.sh <A|B|N2-1|N2-2>[-r2] haiku"; exit 2;; esac
case "$M" in haiku) ;; *) echo "refuse: only haiku is measured in 1.13.0 (G6 sonnet: not measured)"; exit 2;; esac
D="${S:?}/stage/$ST/$M"
BASE="${ST%-r2}"
done_of() { [ -e "${S:?}/stage/$1/$2/DONE" ] || [ -e "${S:?}/stage/$1-r2/$2/DONE" ]; }
[ -e "$D/STARTED" ] && { echo "refuse: $D/STARTED exists (cut-stage rule: report to the main loop)"; exit 1; }
if [ "$ST" != "$BASE" ]; then
  python3 -I -c 'import json,sys; s=json.load(open(sys.argv[1])); sys.exit(0 if s.get("void10") and s.get("cut") else 1)' "${S:?}/stage/$BASE/$M/summary.json" 2>/dev/null \
    || { echo "refuse: $ST runs only after $BASE holds a VOID (cut) summary judged on status counts"; exit 1; }
fi
[ "$BASE" = B ] && ! done_of A "$M" && { echo "refuse: round A is not done"; exit 1; }
[ "$BASE" = N2-2 ] && ! done_of N2-1 "$M" && { echo "refuse: N2-1 is not done"; exit 1; }
case "$BASE" in A|B) LINES="${S:?}/frozen/note-lines-$M.jsonl";; *) LINES="${S:?}/frozen/n2-lines-$M.jsonl";; esac
[ -s "$LINES" ] || { echo "no frozen lines: $LINES"; exit 2; }
if [ "$ST" != "$BASE" ]; then
  [ "$(sha256sum < "$LINES")" = "$(sed -n 2p "${S:?}/stage/$BASE/$M/STARTED" | sed 's#  .*#  -#')" ] || { echo "refuse: the request file differs from $BASE's"; exit 1; }
fi
mkdir -p "$D"
N=$(ls -d "$D"/pre-*/ 2>/dev/null | wc -l); PRE="$D/pre-$((N + 1))"
"$P" --record > "$PRE.pin.txt" 2>&1
"$P" bash "${S:?}/probe/precheck.sh" "$PRE" "$M" || { echo "precheck failed to run"; exit 3; }
python3 -I "${S:?}/tools/gate.py" pre "$PRE" "$M" "$BASE" "$PRE.pin.txt"; rc=$?
[ $rc -eq 3 ] && { echo "STOP: the before record differs from the 1.13.0 calibration: not called"; exit 3; }
[ $rc -eq 7 ] && { echo "WAIT: usage gate failed: not started"; exit 7; }
[ $rc -eq 9 ] && { echo "not started: no statement that no other workflow runs (ONLY_WORKFLOW=1)"; exit 2; }
[ $rc -ne 0 ] && { echo "gate error $rc"; exit 3; }
{ date -u +%FT%TZ; sha256sum "$LINES"; echo "gate $PRE/gate.json"; } > "$D/STARTED"
"$P" --record > "$D/pin-before.txt" 2>&1
cut_out() { # a cut model-stage: summary.json judged on status counts only (no answer opened), then exit 9
  "$P" --record > "$D/pin-after.txt" 2>&1
  python3 -I - "$D" "$LINES" <<'PY'
import json, os, sys
d, lines = sys.argv[1], sys.argv[2]
summ = {"cut": True, "calls": 0, "counts": {}, "sha256": {}}
def nlines(p):
    return sum(1 for l in open(p, encoding="utf-8") if l.strip()) if os.path.exists(p) else 0
for sub, src in (("note", lines), ("n2", lines), ("drill", f"{d}/drill-lines.jsonl")):
    if not os.path.isdir(f"{d}/{sub}") and sub != "drill":
        continue
    if sub == "drill" and not os.path.exists(src):
        continue
    want = nlines(src)
    got = [json.loads(l) for l in open(f"{d}/{sub}/status.jsonl", encoding="utf-8") if l.strip()] if os.path.exists(f"{d}/{sub}/status.jsonl") else []
    for r in got:
        how = "answered" if r.get("answered") else (r.get("reason") or "unknown")
        summ["counts"][f"{sub}:{how}"] = summ["counts"].get(f"{sub}:{how}", 0) + 1
    if want > len(got):
        summ["counts"][f"{sub}:api-error/no-status"] = want - len(got)
    summ["calls"] += max(want, len(got))
api = sum(v for k, v in summ["counts"].items() if ":api-error" in k)
summ["apiErrors"] = api
summ["void10"] = api * 10 > summ["calls"]
open(f"{d}/summary.json", "w").write(json.dumps(summ, indent=1) + "\n")
print(json.dumps(summ))
PY
  echo "CUT: $1 (judged on status counts; VOID when void10 is true: then '${BASE}-r2' on another day)"; exit 9
}
threw() { grep -q '"reason": "threw"' "$1/status.jsonl" 2>/dev/null || grep -q '"reason":"threw"' "$1/status.jsonl" 2>/dev/null; }
case "$BASE" in
  A|B)
    "$P" bash "${S:?}/probe/call.sh" "$D/note" "$M" "$LINES"
    [ -f "$D/note/out.json" ] || cut_out "no note out.json"
    threw "$D/note" && { echo "THREW: the engine refused before sending (M-4 line 4)"; exit 5; }
    chmod 444 "$D/note/out.json"
    node --experimental-transform-types --no-warnings "${S:?}/tools/build.mjs" drill "$D" "$M" || { echo "drill build failed"; exit 9; }
    if [ -s "$D/drill-lines.jsonl" ]; then
      "$P" python3 -I "${S:?}/d34/make.py" real "$D" "$M" > "$D/d34-real.log" 2>&1 || { echo "STOP: D34 of the tier-2 requests differs: no tier-2 call made"; cat "$D/d34-real.log" | tail -5; exit 8; }
      tail -1 "$D/d34-real.log"
      "$P" bash "${S:?}/probe/call.sh" "$D/drill" "$M" "$D/drill-lines.jsonl"
      [ -f "$D/drill/out.json" ] || cut_out "no drill out.json"
      threw "$D/drill" && { echo "THREW: the engine refused before sending (M-4 line 4)"; exit 5; }
      chmod 444 "$D/drill/out.json"
    fi
    ;;
  N2-1|N2-2)
    "$P" bash "${S:?}/probe/call.sh" "$D/n2" "$M" "$LINES"
    [ -f "$D/n2/out.json" ] || cut_out "no n2 out.json"
    threw "$D/n2" && { echo "THREW: the engine refused before sending (M-4 line 4)"; exit 5; }
    chmod 444 "$D/n2/out.json"
    ;;
esac
"$P" --record > "$D/pin-after.txt" 2>&1
python3 -I "${S:?}/tools/gate.py" after "$D" "$M" "$D/pin-after.txt"; after=$?
python3 -I - "$D" <<'PY'
import hashlib, json, os, sys
d = sys.argv[1]
summ = {"calls": 0, "counts": {}, "sha256": {}}
for sub in ("note", "drill", "n2"):
    p = f"{d}/{sub}/out.json"
    if not os.path.exists(p):
        continue
    summ["sha256"][sub] = hashlib.sha256(open(p, "rb").read()).hexdigest()
    for r in json.load(open(p, encoding="utf-8"))["results"]:
        how = "threw" if "threw" in r else "answered" if r.get("isAnswered") else r.get("reason")
        if how == "api-error":
            how += f"/{r.get('status')}"
        summ["calls"] += 1
        summ["counts"][f"{sub}:{how}"] = summ["counts"].get(f"{sub}:{how}", 0) + 1
api = sum(v for k, v in summ["counts"].items() if ":api-error" in k)
summ["apiErrors"] = api
summ["void10"] = api * 10 > summ["calls"]
for sub in ("drill-lines.jsonl", "plan.json"):
    if os.path.exists(f"{d}/{sub}"):
        summ["sha256"][sub] = hashlib.sha256(open(f"{d}/{sub}", "rb").read()).hexdigest()
open(f"{d}/summary.json", "w").write(json.dumps(summ, indent=1) + "\n")
print(json.dumps(summ))
PY
[ $after -ne 0 ] && { echo "VOID: the after record differs (D19): this model's cell is off"; exit 4; }
grep -q '"void10": true' "$D/summary.json" && { echo "VOID: api-errors above 10% (M-4)"; exit 6; }
date -u +%FT%TZ > "$D/DONE"
echo "DONE $ST $M"
