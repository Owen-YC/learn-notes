"""learn-notes 1.13.0 G6 haiku (batch 1; from impl112/b1/tools/count.py) machine counts by label (M-8: judges never see these): per label and stage, from the
probe's own answer files, the calls, answered, each reason, api-errors, threw, cap hits (output_tokens >= maxTokens +
H_M; H_haiku = H_sonnet = 2048 from '### 보정 기록 (1.13.0)', never measured again; caps 5548 note and tier 2, 2528 N2), output_tokens max and median and
time; refusals from the tap records (tapsend.py) where there are any. And the rule-drill no-answer line (stance §2,
detail 18 changed): over that model's tier-2 calls of rounds A and B (n), those with a cap hit (answered or not), an
empty reply (an API refusal included) or a timeout (aborted); it passes when <= max(1, floor(n / 60)). API errors are
counted apart, never sent again; the M-4 10% line is the stage summaries'.
usage: count.py  -> judge/count-<label>.json (chmod 444) for each label; prints by label only"""
import json, os, statistics, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1"
J = os.environ.get("JUDGE", f"{S}/judge")
STAGE = os.environ.get("STAGE", f"{S}/stage")
H_M = {"haiku": 2048, "sonnet": 2048}

def SD(st, m):
    """The stage dir that counts: '<st>-r2' when the cut-stage rule ran it (its DONE there), else '<st>'."""
    r2 = f"{STAGE}/{st}-r2/{m}"
    return r2 if os.path.exists(f"{r2}/DONE") else f"{STAGE}/{st}/{m}"



def how(r):
    return "threw" if "threw" in r else "answered" if r.get("isAnswered") else r.get("reason")


def stage_counts(path, h):
    rs = json.load(open(path, encoding="utf-8"))["results"]
    toks = [(r.get("usage") or {}).get("output_tokens") for r in rs if (r.get("usage") or {}).get("output_tokens") is not None]
    c = {"calls": len(rs), "by": {}, "capHits": [], "outputTokensMax": max(toks) if toks else None,
         "outputTokensMedian": statistics.median(toks) if toks else None, "msMax": max((r.get("ms") or 0) for r in rs) if rs else None}
    for r in rs:
        k = how(r) + (f"/{r.get('status')}" if how(r) == "api-error" else "")
        c["by"][k] = c["by"].get(k, 0) + 1
        if (r.get("usage") or {}).get("output_tokens", 0) >= r["maxTokens"] + h:
            c["capHits"].append(r["id"])
    return c, rs


if __name__ == "__main__":
    labels = json.load(open(f"{J}/pair.json", encoding="utf-8"))["labels"]
    for m, label in labels.items():
        out_p = f"{J}/count-{label}.json"
        if os.path.exists(out_p):
            sys.exit(f"refuse: {out_p} exists")
        out = {"label": label, "H_M": H_M[m], "stages": {}}
        tier2 = []
        for st, sub in (("A", "note"), ("A", "drill"), ("B", "note"), ("B", "drill"), ("N2-1", "n2"), ("N2-2", "n2")):
            p = f"{SD(st, m)}/{sub}/out.json"
            if not os.path.exists(p):
                continue
            c, rs = stage_counts(p, H_M[m])
            tp = f"{SD(st, m)}/tap-{sub}.json"
            if os.path.exists(tp):
                t = json.load(open(tp, encoding="utf-8"))
                c["empty"] = len(t["empty"])
                c["refusals"] = sum(1 for v in t["sent"].values() if v.get("stop_reason") == "refusal")
            out["stages"][f"{st}:{sub}"] = c
            if sub == "drill":
                tier2 += rs
        n = len(tier2)
        bad = [f"{r['id']}:{'cap' if (r.get('usage') or {}).get('output_tokens', 0) >= r['maxTokens'] + H_M[m] else how(r)}" for r in tier2
               if (r.get("usage") or {}).get("output_tokens", 0) >= r["maxTokens"] + H_M[m] or how(r) in ("empty-reply", "aborted")]
        out["ruleDrillNoAnswer"] = {"n": n, "noAnswer": bad, "max": max(1, n // 60), "pass": len(bad) <= max(1, n // 60),
                                    "apiErrors": sum(1 for r in tier2 if how(r) == "api-error"), "threw": sum(1 for r in tier2 if how(r) == "threw")}
        body = json.dumps(out, ensure_ascii=False, indent=1) + "\n"
        open(out_p, "w", encoding="utf-8").write(body)
        os.chmod(out_p, 0o444)
        print(label, json.dumps(out["ruleDrillNoAnswer"]))
