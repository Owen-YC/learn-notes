"""learn-notes 1.13.0 G6 haiku (batch 1; from impl112/b1/tools/n2verify.py; reads the one-practice writer replies) N2 stub check (1.10.0 detail 22, n2verify): the label's writer answers, each run in
place of its practice's line (js/ts twice, py five times; runlib): kept only if gradeDrill would send it (not blank,
not sameLine with the example or the line, not typed in a Korean input mode: n2build.mjs skips) and it is what its kind
says: keep = all runs the same · exit 0 · r's use name · no r marker · output as the example's; break = all the same ·
exit 0 · (an r marker or no use name); broken = a use name · (runs differ or exit != 0 or output not the example's);
off = no use name · (exit != 0 or output not the example's). A main answer that fails is replaced by its practice's
reserve of the same kind if that passes, else dropped and counted (never rewritten). Expected verdicts: keep 맞음,
break 거의 · 틀림, broken 틀림 · 거의, off 틀림.
usage: n2verify.py <label>  -> judge/<label>/n2-answers.json (chmod 444)"""
import json, os, re, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import runlib as R
from key import KEY, holds_use, markers_in

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1"
J = os.environ.get("JUDGE", f"{S}/judge")
FROZEN = os.environ.get("FROZEN", f"{S}/frozen")
WANT = {"keep": 2, "break": 2, "broken": 1, "off": 1}
label = sys.argv[1]
out_p = f"{J}/{label}/n2-answers.json"
if os.path.exists(out_p):
    sys.exit(f"refuse: {out_p} exists")
picks = {p["id"]: p for p in json.load(open(f"{J}/{label}/picks.json", encoding="utf-8"))["picks"]}
samples = {s["id"]: s for s in json.load(open(f"{FROZEN}/samples.json", encoding="utf-8"))}
GEN = os.environ.get("GEN_N2", f"{S}/gen/n2")
# One writer call per picked practice (gen/run.sh <GEN>/<label> files json): each practice's latest reply that is not
# VOIDED, read as the first ```json block, else the whole reply; the objects are merged (one practice id each).
if open(f"{GEN}/{label}/STATUS").read().strip() != "DONE":
    sys.exit("refuse: the N2 writer run is not DONE")
raw = {}
for pid in sorted(picks):
    tries = sorted((d for d in os.listdir(f"{GEN}/{label}/parts") if d.rsplit("-", 1)[0] == pid), key=lambda d: int(d.rsplit("-", 1)[1]))
    tries = [d for d in tries if os.path.exists(f"{GEN}/{label}/parts/{d}/reply.json") and not os.path.exists(f"{GEN}/{label}/parts/{d}/VOIDED")]
    if not tries:
        sys.exit(f"refuse: no reply for {pid}")
    t = json.load(open(f"{GEN}/{label}/parts/{tries[-1]}/reply.json", encoding="utf-8"))["text"]
    m = re.search(r"```json\s*\n(.*?)\n```", t, re.S)
    raw.update(json.loads(m.group(1) if m else t))
tmp = f"{J}/{label}/n2-raw.json"
if not os.path.exists(tmp):
    open(tmp, "w", encoding="utf-8").write(json.dumps(raw, ensure_ascii=False, indent=1) + "\n")
    os.chmod(tmp, 0o444)
p = subprocess.run(["node", "--experimental-transform-types", "--no-warnings", f"{S}/tools/n2build.mjs", "skips", label, tmp], capture_output=True, text=True)
if p.returncode != 0:
    sys.exit("skips failed: " + p.stderr[-800:])
skips = json.loads(p.stdout)
answers, dropped, replaced, bad = [], [], [], []
for sid in sorted(picks):
    pk, s = picks[sid], samples[sid]
    d, r = pk["drill"], pk["rule"]
    files = R.files_of(s)
    first = s["files"][0]["path"]

    def run_with(line):
        text = files[d["file"]].split("\n")
        ind = text[d["n"] - 1][: len(text[d["n"] - 1]) - len(text[d["n"] - 1].lstrip())]
        text[d["n"] - 1] = ind + line.strip()
        return R.run(s, {**files, d["file"]: "\n".join(text)}, first, s["demo"])
    ex = run_with(d["example"])
    rows = raw.get(sid) or []
    for i, a in enumerate(rows):
        line = (a.get("line") or "").strip()
        o = run_with(line)
        use = any(holds_use(line, u) for u in KEY[r]["use"])
        mark = bool(markers_in(r, line))
        same = o["exit"] == 0 and o["same"] and R.out_lines(o["stdout"]) == R.out_lines(ex["stdout"])
        k = a.get("kind")
        fits = {"keep": same and use and not mark, "break": o["exit"] == 0 and o["same"] and (mark or not use),
                "broken": use and (not o["same"] or o["exit"] != 0 or not same), "off": (not use) and (o["exit"] != 0 or not same)}.get(k, False)
        a["_ok"] = fits and not skips[sid][i]
        a["_why"] = None if a["_ok"] else ("not sent by gradeDrill" if skips[sid][i] else f"not {k}")
    for k, n in WANT.items():
        mains = [a for a in rows if a.get("kind") == k and not a.get("reserve")][:n]
        res = [a for a in rows if a.get("kind") == k and a.get("reserve")]
        if len(mains) < n:
            bad.append(f"{sid}: {k} has {len(mains)} main answers, {n} asked")
        for a in mains:
            if a["_ok"]:
                answers.append({"id": sid, "kind": k, "line": a["line"].strip()})
                continue
            sub = next((x for x in res if x["_ok"] and not x.get("_used")), None)
            if sub:
                sub["_used"] = True
                answers.append({"id": sid, "kind": k, "line": sub["line"].strip()})
                replaced.append({"id": sid, "kind": k, "failed": a["line"], "why": a["_why"], "by": sub["line"]})
            else:
                dropped.append({"id": sid, "kind": k, "line": a["line"], "why": a["_why"]})
out = {"label": label, "answers": answers, "replaced": replaced, "dropped": dropped, "short": bad, "n": len(answers)}
open(out_p, "w", encoding="utf-8").write(json.dumps(out, ensure_ascii=False, indent=1) + "\n")
os.chmod(out_p, 0o444)
print(label, json.dumps({"n": len(answers), "replaced": len(replaced), "dropped": len(dropped), "short": bad}))
