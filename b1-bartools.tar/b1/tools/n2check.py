"""learn-notes 1.13.0 G6 haiku (batch 1; new, the form of tools/rowcheck.py) N2 check (plan judges: 'N2: machine count
incl. the pre-cap verdict and the cap reason per item, plus one fresh opus checker'): per label one fresh sub-agent
(`claude -p --model opus --tools ''`, empty dir, pinned CLI, through gen/run.sh) that gets only that label's two N2
count files (judge/n2-<label>-1.md and -2.md: per answer its kind, the pre-cap verdict, the cap reason, the verdict
shown, the 규칙 line and whether it counted as correct) and the stance with its details (judge/stance-G6.md), never the
other label, a model name, tokens, time or caps. It lists rows the count did not count as the text says.
  prompt <label>  -> judge/n2check/<label>/inputs/n2check.md
  (run)           -> `bash gen/run.sh judge/n2check/<label> files json`, detached (STATUS DONE when answered)
  parse <label>   -> judge/n2check-<label>.json (chmod 444): the rows listed; decide.py counts each listed row the way
                     unfavourable to passing (M-9), and M-15 applies to a tool defect it shows."""
import hashlib, json, os, re, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1"
J = os.environ.get("JUDGE", f"{S}/judge")
mode, label = sys.argv[1], sys.argv[2]
if label not in ("P", "Q"):
    sys.exit("label P or Q")
d = f"{J}/n2check/{label}"
if mode == "prompt":
    if os.path.exists(f"{d}/inputs/n2check.md"):
        sys.exit("refuse: prompt exists")
    os.makedirs(f"{d}/inputs")
    stance = open(f"{S}/judge/stance-G6.md", encoding="utf-8").read()
    cnt = "\n\n".join(open(f"{J}/n2-{label}-{k}.md", encoding="utf-8").read() for k in (1, 2))
    tpl = open(f"{S}/judge/tpl-n2check.md", encoding="utf-8").read()
    open(f"{d}/inputs/n2check.md", "w", encoding="utf-8").write(tpl.replace("{LABEL}", label).replace("{STANCE}", stance).replace("{COUNTS}", cnt))
    print(label, os.path.getsize(f"{d}/inputs/n2check.md"))
elif mode == "parse":
    out_p = f"{J}/n2check-{label}.json"
    if os.path.exists(out_p):
        sys.exit("refuse: exists")
    if open(f"{d}/STATUS").read().strip() != "DONE":
        sys.exit("refuse: the N2 check run is not DONE")
    tries = [x for x in sorted(os.listdir(f"{d}/parts"), key=lambda x: int(x.rsplit("-", 1)[1])) if os.path.exists(f"{d}/parts/{x}/reply.json") and not os.path.exists(f"{d}/parts/{x}/VOIDED")]
    t = json.load(open(f"{d}/parts/{tries[-1]}/reply.json", encoding="utf-8"))["text"]
    m = re.search(r"```json\s*\n(.*?)\n```", t, re.S)
    rows = json.loads(m.group(1) if m else t)
    body = json.dumps({"label": label, "rows": rows, "promptSha256": hashlib.sha256(open(f"{d}/inputs/n2check.md", "rb").read()).hexdigest()}, ensure_ascii=False, indent=1) + "\n"
    open(out_p, "w", encoding="utf-8").write(body)
    os.chmod(out_p, 0o444)
    print(label, len(rows))
else:
    sys.exit("usage: n2check.py prompt|parse <label>")
