// learn-notes 1.13.0 G6 haiku (batch 1; from impl112/b1/tools/n2build.mjs) N2 (grading bytes unchanged at 1.9.0, rule19;
// 1.10.0 N2 (3), details 22 · 23; the 1.13.0 STANCE: the verdict the learner is shown, E24–E30, E32):
//   skips <label> <answers.json>  -> per answer whether gradeDrill sends it at all: not when isBlankAnswer, when
//                                    sameLine with the example or with the line, or isKoreanTyped (detail 22)
//   lines <label>                 -> frozen/n2-lines-<model of label>.jsonl (+ n2-meta-<model>.json for D34): gradeDrill's
//                                    first try, CHECK_SYSTEM · redactText(checkPrompt({ name: '팀 규칙', question:
//                                    drillQuestion(sent), answer: sent.example, kind: 'modify' }, `${sent.indent}${mine}`,
//                                    'beginner', undefined, undefined, { rule: sent.rule })).text · 480 · 60000, where
//                                    sent = drillOf(on, changes, true) of the label's round-A ON text
//   judge <label> <run 1|2>       -> judge/n2-<label>-<run>.json/.md: the 1.13.0 build tree's gradeDrill verdict:
//                                    parseCheck(text, { rule: true }) (its 안 지킴 + 맞음 → 거의 inside), THEN, on a 맞음,
//                                    ruleGradeCap(sent, ruleFixUse(sent.check), mine, capKnownNames(the note's screened
//                                    change diffs, the sample file's after text), pairLangOf(sent.file), after text,
//                                    ruleAvoidsOf(the frozen team file's rules, use)) — anything it gives → 거의 (with
//                                    ruleCapText as feedback), exactly as register.tsx gradeDrill (never raised, never
//                                    on 거의/틀림, E27). The after text is the frozen sample's file whose path equals
//                                    sent.file (or ends with '/' + sent.file); not found → names from the diffs only,
//                                    counted as afterMissing (E28). correct: keep 맞음 · break 거의|틀림 · broken
//                                    틀림|거의 · off 틀림 (E25: off capped to 거의 is not correct; E26: break/broken
//                                    capped to 거의 is correct); an unanswered or unread grade is not correct and counts
//                                    as a missing 규칙 line (B-8). Recorded per row: the pre-cap verdict (parseCheck's)
//                                    and the cap reason. NEW lines: keepCapped = keep answers ruleGradeCap lowered
//                                    (E24, E32; must be 0); preCapWrongRight = break + broken answers whose pre-cap
//                                    verdict is 맞음 (E26; must be <= 2).
//                                    pass: correct >= 27 · break→맞음 <= 1 · broken→맞음 0 · missing 규칙 <= 1 ·
//                                    keepCapped 0 · preCapWrongRight <= 2 (each run)
import { existsSync, readFileSync, writeFileSync, chmodSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
const S = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1'
const N = await import(pathToFileURL(`${S}/mtree/hooks/notes.ts`).href)
const J = process.env.JUDGE ?? `${S}/judge`
const FROZEN = process.env.FROZEN ?? `${S}/frozen`
const STAGE = process.env.STAGE ?? `${S}/stage`
const rj = p => JSON.parse(readFileSync(p, 'utf8'))
// The stage dir that counts: '<st>-r2' when the cut-stage rule ran it (its DONE there), else '<st>'.
const SD = (st, m) => existsSync(`${STAGE}/${st}-r2/${m}/DONE`) ? `${STAGE}/${st}-r2/${m}` : `${STAGE}/${st}/${m}`
const once = (p, t) => { if (existsSync(p)) throw new Error(`refuse: ${p} exists`); writeFileSync(p, t); chmodSync(p, 0o444) }
const [mode, label, arg] = process.argv.slice(2)
const modelOf = l => Object.entries(rj(`${J}/pair.json`).labels).find(([, x]) => x === l)[0]
const sentOf = (rows, sid) => N.drillOf(rows[sid].on, rows[sid].changes, true)
if (mode === 'skips') {
  const rows = rj(`${J}/${label}/read2-A.json`)
  const ans = rj(arg)
  const out = {}
  for (const [sid, list] of Object.entries(ans)) {
    const d = sentOf(rows, sid)
    out[sid] = list.map(a => N.isBlankAnswer(a.line) || N.sameLine(d, a.line, d.example) || N.sameLine(d, a.line, d.line) || N.isKoreanTyped(a.line, `${d.indent}${d.line}`))
  }
  console.log(JSON.stringify(out))
} else if (mode === 'lines') {
  const m = modelOf(label)
  const rows = rj(`${J}/${label}/read2-A.json`)
  const answers = rj(`${J}/${label}/n2-answers.json`).answers
  const notes = Object.fromEntries(rj(`${SD('A', m)}/note/out.json`).results.map(r => [r.id, r]))
  const drills = existsSync(`${SD('A', m)}/drill/out.json`) ? Object.fromEntries(rj(`${SD('A', m)}/drill/out.json`).results.map(r => [r.id, r])) : {}
  const lines = []
  const meta = { label, answers: {} }
  answers.forEach((a, i) => {
    const sent = sentOf(rows, a.id)
    if (!sent || sent.rule === undefined) throw new Error(`no rule practice for ${a.id}`)
    const prompt = N.checkPrompt({ name: '팀 규칙', question: N.drillQuestion(sent), answer: sent.example, kind: 'modify' }, `${sent.indent}${a.line}`, 'beginner', undefined, undefined, { rule: sent.rule })
    const id = `${a.id}-${String(i).padStart(2, '0')}-${a.kind}`
    lines.push({ id, model: m, system: N.CHECK_SYSTEM, prompt: N.redactText(prompt).text, maxTokens: 480, timeoutMs: 60000 })
    meta.answers[id] = { sid: a.id, kind: a.kind, mine: a.line, noteReply: notes[a.id].text, drillReply: drills[a.id]?.isAnswered ? drills[a.id].text : null }
  })
  once(`${FROZEN}/n2-lines-${m}.jsonl`, lines.map(l => JSON.stringify(l)).join('\n') + '\n')
  once(`${FROZEN}/n2-meta-${m}.json`, JSON.stringify(meta, null, 1) + '\n')
  console.log(label, lines.length)
} else if (mode === 'judge') {
  const m = modelOf(label)
  const base = `${J}/n2-${label}-${arg}`
  const out = rj(`${SD(`N2-${arg}`, m)}/n2/out.json`).results
  const rows2 = rj(`${J}/${label}/read2-A.json`)
  const meta = rj(`${FROZEN}/n2-meta-${m}.json`).answers
  const samples = Object.fromEntries(rj(`${FROZEN}/samples.json`).map(x => [x.id, x]))
  const team = N.parseTeamFile(readFileSync(`${S}/team.md`, 'utf8'))
  const t = { label, run: Number(arg), n: 0, correct: 0, breakRight: 0, brokenRight: 0, noRuleLine: 0, unread: 0, keepCapped: 0, preCapWrongRight: 0, modelRight: 0, capped: 0, afterMissing: 0, rows: [] }
  for (const r of out) {
    const kind = r.id.split('-').at(-1)
    const g0 = r.isAnswered ? N.parseCheck(r.text, { rule: true }) : undefined
    const sid = meta[r.id].sid
    const sent = sentOf(rows2, sid)
    const file = samples[sid].files.find(f => f.path === sent.file || f.path.endsWith('/' + sent.file))
    const use = g0?.verdict === 'right' ? N.ruleFixUse(sent.check) : undefined
    if (use !== undefined && file === undefined) t.afterMissing += 1
    const avoids = use === undefined ? [] : N.ruleAvoidsOf(team.rules, use)
    const cap = use === undefined ? undefined : N.ruleGradeCap(sent, use, meta[r.id].mine, N.capKnownNames(rows2[sid].changes.map(c => c.diff), file?.after), N.pairLangOf(sent.file), file?.after, avoids)
    const g = cap === undefined ? g0 : { ...g0, verdict: 'partial', feedback: N.ruleCapText(cap) }
    if (g0?.verdict === 'right') t.modelRight += 1
    if (cap) t.capped += 1
    if (cap && kind === 'keep') t.keepCapped += 1
    if ((kind === 'break' || kind === 'broken') && g0?.verdict === 'right') t.preCapWrongRight += 1
    const v = g?.verdict
    const ok = { keep: v === 'right', break: v === 'partial' || v === 'wrong', broken: v === 'wrong' || v === 'partial', off: v === 'wrong' }[kind] === true
    t.n += 1
    t.correct += ok ? 1 : 0
    if (kind === 'break' && v === 'right') t.breakRight += 1
    if (kind === 'broken' && v === 'right') t.brokenRight += 1
    if (!g) t.unread += 1
    if (!g || g.rule === undefined) t.noRuleLine += 1
    t.rows.push({ id: r.id, kind, preCap: g0?.verdict ?? null, cap: cap?.why ?? null, verdict: v ?? null, rule: g?.rule ?? null, ok })
  }
  t.pass = t.correct >= 27 && t.breakRight <= 1 && t.brokenRight === 0 && t.noRuleLine <= 1 && t.keepCapped === 0 && t.preCapWrongRight <= 2
  once(`${base}.json`, JSON.stringify(t, null, 1) + '\n')
  once(`${base}.md`, `# N2 ${label} run ${arg}\n\n` + t.rows.map(x => `- ${x.id} ${x.kind} → 낮추기 전 ${x.preCap} · 낮춤 ${x.cap ?? '-'} · 보이는 판정 ${x.verdict} (규칙: ${x.rule}) ${x.ok ? 'O' : '✗'}`).join('\n') + `\n\n${JSON.stringify({ ...t, rows: undefined })}\n`)
  console.log(label, arg, JSON.stringify({ n: t.n, correct: t.correct, breakRight: t.breakRight, brokenRight: t.brokenRight, noRuleLine: t.noRuleLine, keepCapped: t.keepCapped, preCapWrongRight: t.preCapWrongRight, capped: t.capped, afterMissing: t.afterMissing, pass: t.pass }))
} else throw new Error('usage: n2build.mjs skips <label> <answers> | lines <label> | judge <label> <1|2>')
