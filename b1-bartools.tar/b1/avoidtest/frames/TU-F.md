너는 코드 사례를 쓰는 사람이다. 어떤 도구를 시험하려고, "AI 코딩 도우미가 한 턴 동안 작은 웹 앱 코드를 바꾼 일"의 사례를 JSON으로 만든다. 사례는 실제로 돌려 본다. 그러니 코드는 그대로 돌아가야 한다.

## 팀 파일 (이 저장소의 팀 규칙)

```markdown
# 우리 팀의 학습 노트 규칙

## 규칙
- 서버 요청은 `fetch`(파이썬은 `requests`)를 바로 쓰지 말고 `apiRequest`(파이썬은 `api_request`)를 쓴다. 같은 인자를 받고 같은 응답을 돌려주며, 인증 헤더와 재시도를 더한다
- 기록은 `console.log`(파이썬은 `print`) 대신 `log.info`로 남긴다
- 날짜를 글자로 보일 때는 직접 만들지 말고 `toDateText`(파이썬은 `to_date_text`)를 쓴다. 결과는 `2026-10-22` 꼴(UTC)이다
- 설정 값은 `process.env`(파이썬은 `os.environ`)를 바로 읽지 말고 `config`에서 같은 이름으로 읽는다 (`config.API_URL`)

## 용어
- **주문서**: 결제 직전에 굳힌 장바구니. 금액과 배송지가 더는 바뀌지 않는다
- **회원 등급**: 지난 1년 구매 금액으로 정하는 등급(일반 · 실버 · 골드). 할인율이 등급마다 다르다
```

## 팀 모듈 (저장소에 이미 있음. 사례 파일로 쓰지 않는다. 함정 사례만 예외)

| 규칙 (rule) | js · ts (ESM) | py |
| --- | --- | --- |
| request | `src/api/apiRequest.js`가 `export async function apiRequest(url, options)`. `fetch`와 같은 인자를 받고 같은 Response를 돌려준다 | `app/api/api_request.py`의 `def api_request(url, method="GET", **kwargs)`. `requests.get`/`requests.post`와 같은 응답 객체(`.json()`, `.status_code`, `.ok`, `.text`)를 돌려준다 |
| log | `src/log.js`가 `export const log`. `log.info(...args)`는 `console.log(...args)`와 같은 글을 찍는다 | `app/log.py`의 `log`. `log.info(*args)`는 `print(*args)`와 같은 글을 찍는다 |
| date | `src/dateText.js`가 `export function toDateText(value)`. Date · 밀리초 수 · ISO 글자를 받아 UTC `YYYY-MM-DD`를 준다 | `app/date_text.py`의 `def to_date_text(value)`. date · datetime · ISO 글자를 받아 UTC `YYYY-MM-DD`를 준다 |
| config | `src/config.js`가 `export const config`. `config.API_URL`은 같은 이름의 환경 변수 값(글자, 없으면 undefined) | `app/config.py`의 `config`. `config.API_URL` · `config["API_URL"]` · `config.get("API_URL")`이 같은 이름의 환경 변수 값(없으면 None) |

- js · ts 파일은 ESM이다. 가져오기는 상대 경로에 확장자 `.js`를 붙인다(ts 파일도 `.js`로 쓴다). 예: `src/cart/total.ts`에서 `import { log } from '../log.js'`, `src/pages/orders.js`에서 `import { apiRequest } from '../api/apiRequest.js'`. 사례 파일끼리 가져올 때도 같다.
- py 파일은 `from app.log import log` · `from app.config import config` · `from app.date_text import to_date_text` · `from app.api.api_request import api_request`처럼 저장소 맨 위 기준으로 가져온다. py 사례 파일은 `app/` 아래에 둔다(함정은 예외일 수 있음). 동기 코드만 쓴다(async 없음). 파이썬 `requests`는 `import requests`로 쓴다.
- 날짜는 UTC다. 지금 시각(`new Date()`, `datetime.now()`)은 쓰지 않는다. 날짜는 인자나 데이터로 들어온다.
- 네트워크는 대역이다. 주소는 `https://api.example.test/...` 꼴로 쓴다. `responses`에 준 주소 일부가 주소에 들어 있으면 그 JSON이 상태 200으로 온다(fetch든 apiRequest든 requests든 같다).
- 환경 변수는 `env`에 준 것뿐이다.

## 사례 하나의 JSON 꼴

```json
{
  "id": "…",
  "kind": "R | R_long | multi | double | F | N | trap",
  "lang": "js | ts | py",
  "request": "사용자가 도우미에게 한 요청 (한국어 한두 문장)",
  "answer": "도우미의 마지막 설명 (한국어 두세 문장, 무엇을 바꿨는지)",
  "files": [ { "path": "src/orders/summary.js", "before": "…바뀌기 전 파일 전체… 또는 새 파일이면 null", "after": "…바뀐 뒤 파일 전체…" } ],
  "demo": "첫 파일의 함수를 부르는 호출 식 하나, 예: summarizeOrders([{ id: 1, total: 3000 }])",
  "expected": ["demo를 돌릴 때 표준 출력에 찍히는 줄들, 차례대로"],
  "env": { "이름": "값" },
  "responses": { "주소 일부": { "JSON": "값" } },
  "violations": [ { "rule": "request | log | date | config", "file": "src/orders/summary.js", "line": "어긴 줄 그대로(들여쓰기 빼고)", "fix": "그 줄을 규칙대로 고친 줄 그대로(들여쓰기 빼고)" } ]
}
```

- `files`의 첫 파일이 demo의 함수를 정의(export)한다. demo는 그 파일 끝에 붙여 돌린다(js · ts는 `await`가 붙으니 async 함수도 된다). 그러니 demo 식은 그 파일 안의 이름만 쓴다. demo가 돌려준 값은 도구가 따로 찍으니 `expected`에는 넣지 않는다.
- 바뀐 파일은 하나나 둘. 파일 하나는 10~40줄. before와 after는 몇 줄만 다르다(도우미가 실제로 한 턴에 할 만한 크기). 새 파일이면 before는 null.
- **demo는 어긴 줄을 꼭 지나야 한다**: 어긴 줄이 있는 사례는, 그 줄이 demo를 돌릴 때 실제로 실행되게 한다(그 줄이 든 함수를 demo가 부르거나, demo가 부르는 함수가 그 줄을 지남).
- `violations`: after에서 새로 더해지거나 바뀐 줄 가운데 팀 규칙을 어긴 줄. after에 글자 그대로 있어야 한다. 어긴 줄에 쓸 표지: request는 `fetch(`(파이썬은 `requests.`), log는 `console.log`(파이썬은 `print(`), date는 `toISOString` · `toJSON` · `toLocaleDateString` · `toDateString` · `getFullYear` · `getMonth` · `getDate` · `getUTCFullYear` · `getUTCMonth` · `getUTCDate` · `strftime` · `isoformat` 가운데 하나로 날짜 글자를 직접 만듦, config는 `process.env`(파이썬은 `os.environ` 또는 `os.getenv`).
- `fix`는 그 줄만 규칙대로 고친 줄이다. 규칙의 이름을 쓰고, 표지는 남기지 않으며, 그 밖의 부분(변수 이름, 인자)은 그대로 둔다. fix로 바꾼 파일도 그대로 돌아야 하고, 그 팀 모듈은 그 파일이 이미 import하고 있어야 한다(after 안에 import 줄이 있음). fix가 필요로 하는 import가 after에 없으면 안 된다.
- 어긴 줄이 아닌 다른 줄에는 표지를 쓰지 않는다(함정 · F 사례의 정해진 꼴만 예외).
- 코드 안 문자열 · 주석 · 변수 이름은 영어나 한국어 아무거나. 코드 줄에는 백틱(`)을 되도록 쓰지 않는다(템플릿 문자열이 필요하면 써도 된다).
- 피할 이름(쓰지 마라): 맨 끝 '피할 이름' 절의 이름 모두(함수 · 파일 이름, 경로로 쓰지 마라).

## 출력

JSON 배열 하나만, ```json 코드 블록 하나로 쓴다. 그 밖의 말은 쓰지 않는다.

## 이번에 쓸 사례: 3개 (id HUF01 ~ HUF03)

- 3개 모두 kind "F": 규칙을 지키거나 규칙과 비슷해 보이지만 어기지 않는 변경. 꼴은 네가 고른다(예: 이미 규칙의 이름을 씀, 표지 글자가 문자열이나 주석 안에만 있음, 비슷한 이름의 변수). 바뀐 뒤 코드에 규칙의 이름을 쓰지 않은 40자 이하의 계산 · 조건 · 반환 줄이 둘 이상 더해짐.
- lang은 사례마다 js · ts · py 가운데 네가 고르되 셋이 고루 섞이게 한다.
- violations는 빈 배열이다.
