#!/bin/bash
# tool test only: gen/run.sh (the writer/checker runner) with the fake claude through the fake pin; no model call.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1
T="${S:?}/test/wr"; rm -rf "${T:?}"; mkdir -p "$T"
mkgen() { # <case>: a test copy of gen/ whose paths point into the case root and whose pin is the fake one
  C="$T/$1"; mkdir -p "$C/gen"
  for f in common.md parts.json parts.py avoid113.py record.py n2-frame.md; do cp "$S/gen/$f" "$C/gen/"; done
  sed "s#^S=.*#S=$C#; s#^P=.*#P=$S/test/pinned-fake.sh#" "$S/gen/run.sh" > "$C/gen/run.sh"
  sed "s#^R=.*#R=$C#" "$S/gen/precheck.sh" > "$C/gen/precheck.sh"
  sed "s#^PINNED = .*#PINNED = \"$S/test/pinned-fake.sh\"#" "$S/gen/gate.py" > "$C/gen/gate.py"
  export FAKE_STATE="$C/fake-state"
}
export FAKE_ID_OPUS=fake-opus-id
r() { echo "== $1: expect $2"; shift 2; bash "$C/gen/run.sh" "$@" > "$C.log" 2>&1; echo "exit $? STATUS $(cat "$C/out/STATUS" 2>/dev/null || cat "$C/$ROOTN/STATUS")"; }
ROOTN=out
mkgen ok; r ok "DONE 108 records" "$C/out" samples; python3 -c "import json;print(len(json.load(open('$C/out/raw.json'))))"; ls "$C/out/parts" | wc -l
cat "$C/out/parts/RB-1/prompt.md" | grep -c "이미 쓴 다른 사례"; head -c 0 /dev/null
mkgen ref2; FAKE_WRITER_SPEC='{"HA01":["refusal","refusal"]}' r "refused twice" "STOP RA" "$C/out" samples; ls "$C/out/parts" | grep '^RA'
mkgen ref1; FAKE_WRITER_SPEC='{"HB01":["refusal","ok"],"HE01":["tooltext","ok"]}' r "refused once, tool text once" "DONE" "$C/out" samples; ls "$C/out/parts" | grep -E '^(RB|RL)'; cmp "$C/out/parts/RB-1/prompt.md" "$C/out/parts/RB-2/prompt.md" && echo "RB retry prompt same bytes"
mkgen tt2; FAKE_WRITER_SPEC='{"HT01":["tooltext","tooltext"]}' r "tool text twice" "STOP T" "$C/out" samples
mkgen wait; FAKE_WRITER_SPEC='{"HF01":["limit","ok"]}' r "limit reached" "WAIT" "$C/out" samples; FAKE_WRITER_SPEC='{"HF01":["limit","ok"]}' r "resume after WAIT" "DONE" "$C/out" samples; ls "$C/out/parts" | grep '^F1'; cmp "$C/out/parts/F1-1/prompt.md" "$C/out/parts/F1-2/prompt.md" && echo "F1 resend same bytes"; cat "$C/out/parts/F1-1/ending.txt"
mkgen killed; FAKE_WRITER_SPEC='{"HN01":["killed","ok"]}' r "killed process" "WAIT" "$C/out" samples
mkgen five; FAKE_FIVE=0.7 r "five_hour 0.70" "WAIT, nothing called" "$C/out" samples; ls "$C/out/parts" | wc -l
mkgen seven; FAKE_SEVEN=0.75 r "seven_day 0.75 + 0.06" "WAIT" "$C/out" samples
mkgen ver; FAKE_VERSION="2.1.330 (Claude Code)" r "version differs" "RECORD-STOP" "$C/out" samples
mkgen pin; FAKE_PIN_BAD=0000 r "pinned sha differs" "RECORD-STOP" "$C/out" samples
mkgen void; FAKE_WRITER_ID=other-id r "writer id differs" "VOID" "$C/out" samples; r "resume after VOID" "DONE" "$C/out" samples; ls "$C/out/parts" | grep -c -- '-2$'; ls "$C"/out/parts/*-1/VOIDED | wc -l
mkgen again; r first "DONE" "$C/out" samples; r "run DONE root again" "refuse exit 1" "$C/out" samples
ROOTN=tu-R; r "top-up without CHAIN_ROOT" "exit 2" "$C/tu-R" topup R; CHAIN_ROOT="$C/out" r "top-up R" "DONE" "$C/tu-R" topup R; grep -c "이미 쓴 다른 사례" "$C/tu-R/parts/TU-R-1/prompt.md"; grep -c "(id HUR01 ~ HUR08)" "$C/tu-R/parts/TU-R-1/prompt.md"
ROOTN=files; mkdir -p "$C/files/inputs"; printf '### 연습 X1\n' > "$C/files/inputs/X1.md"; printf 'check\n' > "$C/files/inputs/chk.md"; r "files json" "DONE" "$C/files" files json; ls "$C/files/parts"
