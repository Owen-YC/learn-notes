#!/bin/bash
# tool test only (no model call): the judging pipeline of the 1.13.0 tools on the 1.13.0 G6 design dev set <k> haiku
# answers (design/G6/dev/set<k>: frozen samples, round-A note + tier-2 answers, N2-1 answers), the round used as A and B.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1
K="$1"; G=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6/dev/set$K
R="${S:?}/test/pipe-set$K"; rm -rf "${R:?}"; mkdir -p "$R/frozen" "$R/stage" "$R/judge" "$R/x"
for f in samples.json hunks.json note-lines-haiku.jsonl n2-lines-haiku.jsonl n2-meta-haiku.json; do cp "$G/frozen/$f" "$R/frozen/"; done
for st in A B; do mkdir -p "$R/stage/$st"; cp -r "$G/stage/A/haiku" "$R/stage/$st/haiku"; done
for st in N2-1 N2-2; do mkdir -p "$R/stage/$st"; cp -r "$G/stage/N2-1/haiku" "$R/stage/$st/haiku"; done
for st in A B N2-1 N2-2; do echo '{"void10": false}' > "$R/stage/$st/haiku/summary.json"; echo '{"same": true}' > "$R/stage/$st/haiku/after.json"; done
export FROZEN="$R/frozen" JUDGE="$R/judge" STAGE="$R/stage"
NODE="node --experimental-transform-types --no-warnings"
# drill lines rebuilt from the dev note answers on the 1.13.0 build tree = the pilot's drill lines (byte)
mkdir -p "$R/x/A"; cp -r "$G/stage/A/haiku/note" "$R/x/A/note"
$NODE "$S/tools/build.mjs" drill "$R/x/A" haiku > /dev/null && cmp "$R/x/A/drill-lines.jsonl" "$G/stage/A/haiku/drill-lines.jsonl" && echo "drill-lines same as pilot ($(wc -l < "$R/x/A/drill-lines.jsonl"))"
cmp <($NODE -e "1") /dev/null >/dev/null
echo '{"nonce": "test", "labels": {"haiku": "P"}}' > "$R/judge/pair.json"
python3 -I "$S/tools/label.py" read | tail -2
for r in A B; do python3 -I "$S/tools/judge.py" P $r "$R/judge/P/read2-$r.json" | tail -1; done
python3 -I "$S/tools/count.py" | tail -1
python3 -I "$S/tools/pick.py" P | tail -1
cp "$G/judge/P/n2-answers.json" "$R/judge/P/n2-answers.json"
for k in 1 2; do $NODE "$S/tools/n2build.mjs" judge P $k; done
