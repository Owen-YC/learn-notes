#!/bin/bash
# tool test only: tools/stage.sh with the fake claude (test/bin/claude) through the fake pin in test roots; no model call.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1
G=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6/dev/set2
mk() { # mk <name> : a fresh test root
  R="${S:?}/test/st/$1"; rm -rf "${R:?}"; mkdir -p "$R/frozen" "$R/stage"
  for f in samples.json hunks.json note-lines-haiku.jsonl; do cp "$G/frozen/$f" "$R/frozen/"; done
  ln -s "$S/tools" "$R/tools"; ln -s "$S/probe" "$R/probe"; ln -s "$S/d34" "$R/d34"
  sed "s#^S=.*#S=$R#; s#^P=.*#P=$S/test/pinned-fake.sh#" "$S/tools/stage.sh" > "$R/stage.sh"; chmod +x "$R/stage.sh"
  export FROZEN="$R/frozen"
}
export FAKE_ID_HAIKU="$(python3 -c "import json;print(json.load(open('/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b0/calib/pre/haiku-1/record.json'))['inits'][0])")"
python3 -c "
import json
d={r['id']:r['text'] for r in json.load(open('$G/stage/A/haiku/note/out.json'))['results'] if r.get('isAnswered')}
json.dump(d,open('$S/test/st-texts.json','w'))"
export FAKE_TEXTS="$S/test/st-texts.json"
mkdir -p "$S/test/st"
t() { echo "== $1: expect $2"; shift 2; "$@" > "$R.log" 2>&1; echo "exit $?"; grep -E "^(STOP|WAIT|VOID|THREW|DONE|refuse|not started|CUT|usage)" "$R.log" | head -3; }
mk ok
ONLY_WORKFLOW=1 t "A haiku" "DONE (seven 0.2 + 0.08)" "$R/stage.sh" A haiku
head -c 300 "$R/stage/A/haiku/summary.json"; echo; ls "$R/stage/A/haiku"; head -c 200 "$R/stage/A/haiku/d34/result.json"; echo
ONLY_WORKFLOW=1 t "A haiku again" "refuse STARTED" "$R/stage.sh" A haiku
ONLY_WORKFLOW=1 t "A sonnet" "refuse (not measured)" "$R/stage.sh" A sonnet
ONLY_WORKFLOW=1 t "A-r2 after a DONE A" "refuse (no VOID cut summary)" "$R/stage.sh" A-r2 haiku
ONLY_WORKFLOW=1 t "N2-1 no lines" "exit 2" "$R/stage.sh" N2-1 haiku
mk order; ONLY_WORKFLOW=1 t "B before A" "refuse" "$R/stage.sh" B haiku
mk att; t "no attestation" "exit 2 not started" "$R/stage.sh" A haiku; ls "$R/stage/A/haiku" | grep -c STARTED
mk five; FAKE_FIVE=0.7 ONLY_WORKFLOW=1 t "five 0.70" "WAIT exit 7" "$R/stage.sh" A haiku; ls "$R/stage/A/haiku" | grep -c STARTED
mk round; FAKE_SEVEN=0.73 ONLY_WORKFLOW=1 t "round A seven 0.73 + 0.08" "WAIT exit 7" "$R/stage.sh" A haiku
mk ver; FAKE_VERSION="2.1.330 (Claude Code)" ONLY_WORKFLOW=1 t "version drift" "STOP exit 3" "$R/stage.sh" A haiku
mk pin; FAKE_PIN_BAD=0000 ONLY_WORKFLOW=1 t "pinned sha differs" "STOP exit 3" "$R/stage.sh" A haiku
mk drift; FAKE_DRIFT=1 ONLY_WORKFLOW=1 t "id drift in probe session" "VOID exit 4" "$R/stage.sh" A haiku
mk api; FAKE_SPEC='{"E2A01":"api","E2A02":"api","E2A03":"api","E2A04":"api","E2A05":"api"}' ONLY_WORKFLOW=1 t "api errors 5/39+" "VOID exit 6" "$R/stage.sh" A haiku
mk threw; FAKE_SPEC='{"E2A03":"threw"}' ONLY_WORKFLOW=1 t "threw" "THREW exit 5" "$R/stage.sh" A haiku
# cut: the note session leaves a status file for 3 calls and no out.json (a killed probe)
mk cut; cp "$S/probe/call.sh" "$R/call-cut.sh"; rm "$R/probe"; mkdir -p "$R/probe"; ln -s "$S/probe/precheck.sh" "$S/probe/record.py" "$S/probe/mod" "$R/probe/"
printf '#!/bin/bash\nmkdir -p "$1"; head -3 "$3" | python3 -c "import json,sys;[print(json.dumps({\\"id\\":json.loads(l)[\\"id\\"],\\"answered\\":True})) for l in sys.stdin]" > "$1/status.jsonl"; exit 0\n' > "$R/probe/call.sh"
ONLY_WORKFLOW=1 t "cut stage" "CUT exit 9, void10" "$R/stage.sh" A haiku; cat "$R/stage/A/haiku/summary.json" | tr -d '\n ' | head -c 300; echo
cp "$S/probe/call.sh" "$R/probe/call.sh.real"; rm "$R/probe/call.sh"; ln -s "$S/probe/call.sh" "$R/probe/call.sh"
ONLY_WORKFLOW=1 t "A-r2 after the VOID cut" "DONE" "$R/stage.sh" A-r2 haiku
ONLY_WORKFLOW=1 t "B after A-r2" "DONE" "$R/stage.sh" B haiku
