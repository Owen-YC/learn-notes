"""learn-notes 1.13.0 G6 haiku (batch 1) bar: composes the 견본.md section from bar/head.md, the re-committed stance
(bar/stance-113.md from stance.py), bar/tail1.md, tail2.md, tail3.md, the avoid-test lines and the tool table, and cuts
judge/stance-G6.md (the '#### 판정의 입장' part up to '#### 결정 규칙') for the row and N2 checkers.
  stance   -> judge/stance-G6.md (from the composed text; run before freezing)
  section  -> bar/section.md (needs bar/tools.sha256 and avoidtest/; {{UTC}} filled from env BAR_UTC)"""
import json, os, sys
S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1"
B = f"{S}/bar"
D = json.load(open("/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6.json", encoding="utf-8"))["stance"]
rd = lambda p: open(p, encoding="utf-8").read()

STANCE = ("#### 판정의 입장\n\n"
          "설계의 입장(stance) 글입니다. 설계 stance.intro(글자 그대로): " + D["intro"] + "\n\n"
          "아래는 1.12.0 G6 입장(2f95fe1)의 '공통' 다섯 항목, 확인 줄(S-a), 견본(S-c), 판정 대상(S-b), 경계 꼴 E1 ~ E18, N2 입장, 다시 커밋하는 1.10.0 입장 §0 ~ §15, '읽는 법', 다시 커밋하는 1.10.0 세부 1 ~ 24를 글자 그대로 옮긴 것이고, 1.13.0에서 바꾼 곳은 ~~ ~~와 '(1.13.0에서 바꿈)' · '(1.13.0에서 더함)' 줄로, 더한 경계 꼴은 E19 ~ E32로 붙였습니다. 판정은 이 글자대로만 셉니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 '다시 잴 때'에 적습니다(M-11).\n\n"
          + rd(f"{B}/stance-113.md"))

TABLE_ROWS = [
    ("team.md", "팀 파일(1.10.0 것 그대로)"),
    ("gen/common.md", "쓰는 쪽 공통 틀('사례'로 고친 1.12.0 틀)"), ("gen/parts.json", "쓰는 쪽 짜임(19부분 + 보충 7)"),
    ("gen/parts.py", "부분 프롬프트 · 답 읽기 · 묶기"), ("gen/avoid113.py", "피할 목록 짓기(`impl113/gen/avoid113.py`와 같음)"),
    ("gen/run.sh", "쓰는 쪽 · 확인자 러너"), ("gen/gate.py", "쓰는 쪽 러너의 앞뒤 기록 · 관문 · 끝남 갈래"),
    ("gen/precheck.sh", "쓰는 쪽 앞뒤 'ok' 세션"), ("gen/record.py", "세션 기록 읽기"), ("gen/n2-frame.md", "N2 답 쓰는 쪽 틀(연습 하나)"),
    ("tools/extract.py", "쓰는 쪽 답 묶기"), ("tools/check.py", "얼릴 때 확인 · 예비 대체 (NAMES_FILE = `impl113/NAMES-all.txt`)"),
    ("tools/lexcode.py", "주석 · 문자열 가르기(F; 1.12.0과 같음)"), ("tools/runlib.py", "대역과 돌리기(§8)"),
    ("tools/key.py", "채점 열쇠(§5) · 이름 찾기(1.12.0과 같음)"), ("tools/prep.py", "엔진 꼴 hunk(1.12.0과 같음)"),
    ("tools/build.mjs", "노트 · 2단 줄 짜기, 켠 · 끈 읽기(§1)"), ("tools/notekit.mjs", "노트 꾸미기(1.12.0과 같음)"),
    ("tools/read2.mjs", "판정 입력(§4 · §11 · §13 · §14, 옛 창 일곱)"), ("tools/judge.py", "기계 판정자"),
    ("tools/count.py", "기계 셈(꼬리표마다)"), ("tools/label.py", "꼬리표 봉인 · 읽기"), ("tools/pick.py", "N2 고르기"),
    ("tools/n2prompt.py", "N2 쓰는 쪽 프롬프트(연습마다)"), ("tools/n2verify.py", "N2 대역 확인(세부 22)"),
    ("tools/n2build.mjs", "N2 줄 · 셈(1.13.0 N2 입장)"), ("tools/rowcheck.py", "행 확인(세부 21)"), ("tools/n2check.py", "N2 확인"),
    ("tools/decide.py", "결정 규칙"), ("tools/gate.py", "앞뒤 기록 · 사용량 관문(모델-스테이지)"), ("tools/stage.sh", "떼어 낸 러너(모델-스테이지)"),
    ("tools/tapsend.py", "빈 답의 탭(기록)"), ("tools/probe_off.mjs", "끈 바이트(짓기 때)"), ("tools/probe_off.diff", "그 출처와의 차이"),
    ("tools/oldwin113.mjs", "옛 창 일곱(짓기 때)"), ("tools/oldwin113.diff", "그 출처와의 차이"), ("tools/oldtry.mjs", "옛 창의 첫 시도 읽기(짓기 때)"),
    ("tools/mut.py", "돌연변이 탐침(짓기 때)"), ("tools/mut.diff", "그 출처와의 차이"),
    ("d34/expect.mjs", "D34 기대 요청"), ("d34/make.py", "D34 하네스 잡기 · 견줌"),
    ("probe/call.sh", "프로브 세션"), ("probe/precheck.sh", "앞 'ok' 세션"), ("probe/record.py", "세션 기록 읽기"),
    ("probe/mod/hooks/register.ts", "프로브 mod(/g6probe)"), ("probe/mod/hooks/notes.ts", "프로브 notes.ts(= mtree)"),
    ("probe/mod/hooks/hooks.json", "프로브 mod"), ("probe/mod/.claude-plugin/plugin.json", "프로브 mod"),
    ("tap/call.sh", "탭 세션"), ("tap/tap.py", "탭(1.11.0 · 1.12.0과 같음)"), ("tap/mod/hooks/register.ts", "탭 mod(/g6tap)"),
    ("tap/mod/hooks/hooks.json", "탭 mod"), ("tap/mod/.claude-plugin/plugin.json", "탭 mod"), ("tap/mod/tsconfig.json", "탭 mod"),
    ("judge/tpl-rowcheck.md", "행 확인 틀"), ("judge/tpl-n2check.md", "N2 확인 틀"), ("judge/stance-G6.md", "확인자에게 주는 입장(이 절에서 자름)"),
    ("mtree/hooks/notes.ts", "짓기 트리(fabef5d)"), ("mtree/hooks/register.tsx", "짓기 트리(fabef5d)"),
    ("jtree/hooks/notes.ts", "읽기 트리(export 셋만 더함)"),
] + [(f"old/{c}/hooks/notes.ts", f"옛 창 {c} notes.ts(git show)") for c in ("3f2b4fb", "7a7b08c", "3690021", "fca5988", "3d2f251", "de98243", "30adc2f")] + [
    ("bar/stance.py", "입장 다시 커밋 글 짓기(기록)"), ("bar/compose.py", "이 절 짓기(기록)"),
    ("../d26/rulewide113.mjs", "isRuleWide D26(묶음 0에서 얼림)"), ("../d26/g2haiku.sh", "G2 haiku D26(묶음 0에서 얼림)"),
    ("../d26/remake.py", "G2 haiku D26 요청 다시 짓기(묶음 0에서 얼림)"), ("../cli/pinned.sh", "고정한 길(묶음 0, chmod 555)"),
]

mode = sys.argv[1]
if mode == "stance":
    out = f"{S}/judge/stance-G6.md"
    if os.path.exists(out):
        sys.exit("refuse: stance-G6.md exists")
    open(out, "w", encoding="utf-8").write(STANCE)
    print(len(STANCE.split("\n")))
elif mode == "files":
    print("\n".join(p for p, _ in TABLE_ROWS))
elif mode == "section":
    sums = {}
    for l in open(f"{B}/tools.sha256", encoding="utf-8"):
        h, p = l.rstrip("\n").split("  ", 1)
        sums[p] = h
    assert STANCE == rd(f"{S}/judge/stance-G6.md"), "stance-G6.md differs from the composed stance"
    table = ["#### 틀과 도구 (sha256, 이 커밋으로 얼림, 저장소 밖 `impl113/b1/` 아래, chmod 444)", "", "| 파일 | 하는 일 | sha256 |", "| --- | --- | --- |"]
    for p, what in TABLE_ROWS:
        table.append(f"| `{p}` | {what} | `{sums[p]}` |")
    av = rd(f"{B}/avoidtest.md")
    head = rd(f"{B}/head.md").replace("{{UTC}}", os.environ["BAR_UTC"])
    assert "{{" not in head
    text = head + "\n" + STANCE + "\n" + rd(f"{B}/tail1.md") + rd(f"{B}/tail2.md") + rd(f"{B}/tail3.md") + "\n" + av + "\n" + "\n".join(table) + "\n" + rd(f"{B}/xcheck.md")
    open(f"{B}/section.md", "w", encoding="utf-8").write(text)
    print(len(text.split("\n")), "lines")
