"""learn-notes 1.13.0 G6 haiku (batch 1) bar: the re-committed stance. Takes the 1.12.0 G6 stance text of docs/qa/견본.md
at 30adc2f ('## 1.12.0 팀 규칙 연습 (G6)' > '#### 판정의 입장', lines 6215-6398 = everything after its heading and its
one intro paragraph, up to '#### 결정 규칙') word for word, and puts in the design's changes (impl113/design/G6.json
stance.changed / added / unchangedNote, Korean as written there) as 1.12.0 did: the changed words struck (~~ ~~) and
the 1.13.0 text beside them; E19-E32 added after E18. Writes bar/stance-113.md (the '#### 판정의 입장' body)."""
import json, subprocess
B = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1/bar"
D = json.load(open("/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6.json", encoding="utf-8"))["stance"]
src = subprocess.run(["git", "-C", "/home/user/learn-notes", "show", "30adc2f:docs/qa/견본.md"], capture_output=True, text=True).stdout.split("\n")
block = src[6216:6398]  # lines 6217-6398: from '공통 (…' to the line before '#### 결정 규칙'
assert src[6212] == "#### 판정의 입장" and block[0].startswith("공통 (1.10.0 입장") and src[6398] == "#### 결정 규칙", (src[6212], block[0][:20], src[6398])
T = "\n".join(block)
ch = {x.split(" ", 1)[0]: x for x in D["changed"]}
added = D["added"]


def rep(old, new):
    global T
    assert T.count(old) == 1, old[:60]
    T = T.replace(old, new)


# 공통 (the 1.12.0 '공통' list): §1, §2, §14 changed lines added under the 1.12.0 ones
rep("- §1 (바꿈) 켠 읽기: 노트 답 → fixEscapedTicks → keptNoteText(답, names) → noteRuleOf가 읽히면 그 판 트리의 ruleFixPlan(screened, rules, 그 줄). 1단이면 ruleFixMade(글, fix, changes) ?? 글, 2단이면 RULE_DRILL_SYSTEM · redactText(ruleDrillPrompt(screened, rules, 그 줄, cands)) · 3500 · 90000으로 부르고 fixEscapedTicks → ruleFixReply가 받은 글 ?? 글, 건너뜀이면 글 그대로. 끈 읽기: 같은 노트 답의 keptNoteText 글 그대로.\n",
    "- §1 (바꿈) 켠 읽기: 노트 답 → fixEscapedTicks → keptNoteText(답, names) → noteRuleOf가 읽히면 그 판 트리의 ruleFixPlan(screened, rules, 그 줄). 1단이면 ruleFixMade(글, fix, changes) ?? 글, 2단이면 RULE_DRILL_SYSTEM · redactText(ruleDrillPrompt(screened, rules, 그 줄, cands)) · 3500 · 90000으로 부르고 fixEscapedTicks → ruleFixReply가 받은 글 ?? 글, 건너뜀이면 글 그대로. 끈 읽기: 같은 노트 답의 keptNoteText 글 그대로.\n"
    f"- (1.13.0에서 바꿈) {ch['§1']}\n")
rep("- §2 그대로: 노트 호출이 답하지 않은 견본은 그 회 L · O에서 빼고 수만 적습니다. 규칙 연습 호출의 상한 닿음 · 빈 답(API 거절 포함) · 시간 한도는 '답 없음' 줄에 셉니다(n = 그 모델 두 회의 2단 호출 수). 닿았어도 글이 읽히면 읽힌 대로 매깁니다. 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.12.0 보정).\n",
    "- §2 그대로: 노트 호출이 답하지 않은 견본은 그 회 L · O에서 빼고 수만 적습니다. 규칙 연습 호출의 상한 닿음 · 빈 답(API 거절 포함) · 시간 한도는 '답 없음' 줄에 셉니다(n = 그 모델 두 회의 2단 호출 수). 닿았어도 글이 읽히면 읽힌 대로 매깁니다. 상한 닿음 = output_tokens ≥ maxTokens + H_M(~~1.12.0 보정~~ 1.13.0 보정 기록).\n"
    f"- (1.13.0에서 바꿈) {ch['§2:']}\n")
rep("- §14 (더함, 엄격하게): 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988에 3d2f251 · de98243을 더한 여섯입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.\n",
    "- §14 (더함, 엄격하게): 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988에 3d2f251 · de98243을 더한 ~~여섯~~ 일곱(1.13.0, 아래 줄)입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.\n"
    f"- (1.13.0에서 더함) {ch['§14']}\n")
# E8 (the design gives the struck text and the 1.13.0 text)
e8_old = "- E8 2단 답이 스스로 고쳐 쓴 꼴(같은 라벨에 다른 값, 'Wait —'): 코드가 받지 않아 연습 없음입니다. 판정은 저장된 글만 봅니다.\n"
rep(e8_old, f"- E8 (1.13.0에서 바꿈): {ch['E8'].split(': ', 1)[1]}\n")
# E19-E32 after E18
e18 = [l for l in T.split("\n") if l.startswith("- E18 ")][0]
rep(e18 + "\n", e18 + "\n\n1.13.0에서 더한 경계 꼴 (미리 정함, 설계 stance.added 글자 그대로)\n" + "\n".join(f"- {x}" for x in added) + "\n")
# the short N2 입장 under the 1.12.0 list: the 1.13.0 change named next to it
rep("N2 입장\n- 1.9.0 · 1.10.0 N2 입장 그대로(세부 22 · 23).",
    f"N2 입장\n- (1.13.0에서 바꿈, 아래 다시 커밋하는 'N2 입장:' 줄에 넣음) {ch['N2']}\n- 1.9.0 · 1.10.0 N2 입장 그대로(세부 22 · 23).")
# re-committed §1, §2, §14 of the 1.10.0 text
rep("- 끈 읽기: 같은 노트 답의 keptNoteText 글 그대로.\n- 두 호출 모두 redactText, effort low, timeoutMs 90000이고, 그 판 notes.ts 사본의 함수를 그대로 부릅니다.\n",
    "- 끈 읽기: 같은 노트 답의 keptNoteText 글 그대로.\n- 두 호출 모두 redactText, effort low, timeoutMs 90000이고, 그 판 notes.ts 사본의 함수를 그대로 부릅니다.\n"
    f"- (1.13.0에서 바꿈) {ch['§1']}\n")
rep("닿았어도 글이 읽히면 읽힌 대로 매깁니다. 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.12.0 보정).\n\n§3 L과 O",
    "닿았어도 글이 읽히면 읽힌 대로 매깁니다. 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.12.0 보정).\n"
    f"- (1.13.0에서 바꿈) {ch['§2:']}\n\n§3 L과 O")
rep("- (1.12.0에서 더함, 엄격하게) 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988에 3d2f251 · de98243을 더한 여섯입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.\n\n§15",
    "- (1.12.0에서 더함, 엄격하게) 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988에 3d2f251 · de98243을 더한 여섯입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.\n"
    f"- (1.13.0에서 더함) {ch['§14']}\n\n§15")
# the long N2 입장 line: the design's struck words and the 1.13.0 text
n2 = [l for l in T.split("\n") if l.startswith("N2 입장: 1.9.0 N2와 같습니다.")][0]
old_part = "parseCheck(text, { rule: true }) 뒤 '안 지킴 + 맞음 → 거의' 낮추기를 거친 판정으로 셉니다."
assert n2.count(old_part) == 1
new_text = ch["N2"].split("~~ ", 1)[1]  # the 1.13.0 text after the design's struck sentence
rep(n2, n2.replace(old_part, f"~~{old_part}~~ {new_text}"))
# details 18 and 19
rep("19. §14: 표지 노트 = 최종 글에 `- 할 일 (팀 규칙):`로 시작하는 줄이 있는 노트. 옛 창 ~~넷~~ 여섯(1.12.0, §14)의",
    "19. §14: 표지 노트 = 최종 글에 `- 할 일 (팀 규칙):`로 시작하는 줄이 있는 노트. 옛 창 ~~넷~~ ~~여섯(1.12.0, §14)~~ 일곱(1.13.0, §14)의")
rep("켠 · 끈 최종 글 모두, ~~네~~ 여섯 창 모두입니다.", "켠 · 끈 최종 글 모두, ~~네~~ ~~여섯~~ 일곱(1.13.0) 창 모두입니다.")
rep("곧 2단 호출 5548)이고, 답한 호출도 닿았으면 셉니다.", "곧 2단 호출 5548; 1.13.0 보정 기록도 haiku 2048, 곧 5548)이고, 답한 호출도 닿았으면 셉니다.")
# reading rules for 1.13.0, after the 1.12.0 ones (before the re-committed details)
rep("\n다시 커밋하는 1.10.0 세부 1 ~ 24",
    "\n읽는 법(1.13.0; 글은 바꾸지 않음, 설계 stance.intro)\n"
    "- 위 글의 '1.12.0'은 '1.13.0'으로, '1.12.0 보정 기록'(또는 '1.12.0 보정')은 '1.13.0 보정 기록'으로 읽습니다. 그 수는 같습니다(H_haiku 2048: 노트 · 2단 5548, N2 2528).\n"
    "- '그 판 트리': 1.13.0 짓기 커밋 fabef5d의 트리(`impl113/b1/mtree`, git archive)입니다. '짓기 커밋 a4ac818의 트리(`impl112/b1/mtree`)'는 1.12.0의 자리입니다.\n"
    "- 세부 20의 label.py · count.py · route.py, 세부 21의 행 확인, 세부 22의 n2verify.py, 세부 23의 n2judge.mjs, 세부 12의 runlib: 아래 '틀과 도구' 표의 1.13.0 도구(`impl113/b1/`)입니다. N2 셈은 `tools/n2build.mjs judge`(1.13.0 N2 입장)이고, N2 요청을 꼬리표의 모델로 보내는 일은 `tools/n2build.mjs lines`가 짝 파일을 읽어 하며 짝을 찍지 않습니다.\n"
    "- 세부 20의 꼬리표: 1.13.0은 haiku 하나만 재므로 꼬리표도 하나입니다(P와 Q 가운데 난수로 고름, 계획 단계 5 '잴 모델이 하나여도 회마다 난수 꼬리표'). 짝 파일은 그 하나를 봉합니다.\n"
    + f"- 바꾸지 않은 곳(설계 stance.unchangedNote 글자 그대로): {D['unchangedNote']}\n"
    "\n다시 커밋하는 1.10.0 세부 1 ~ 24")
open(f"{B}/stance-113.md", "w", encoding="utf-8").write(T + "\n")
print(len(T.split("\n")), "lines")
