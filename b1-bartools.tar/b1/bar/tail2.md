
#### 부르기

설계 calls 글(옮김)
- 플러그인과 똑같이(D20), 프로브 mod가 $.model.complete({ model: 'haiku'(설정 글자 그대로), effort: 'low', system, prompt: redactText(prompt).text, maxTokens, timeoutMs })를 부르며, 4개씩, $.clock으로 시간을 재고, 답은 fixEscapedTicks를 거칩니다. 1.13.0 보정의 고정한 CLI 사본; DISABLE_AUTOUPDATER=1; 회마다 앞뒤로 claude --version, init model과 modelUsage 키(M-10).
- 노트: SYSTEM, notePrompt(screened, 'beginner', [], team)(1.8.0 바이트), maxTokens NOTE_TOKENS 3500, timeoutMs 90000.
- 연습: 짓기 트리의 writeNote 길: keptNoteText(답, ruleNamesOf(rules)) → noteRuleOf → ruleFixPlan(screened, rules, said). 1단: 호출 없음. 2단: system RULE_DRILL_SYSTEM, prompt redactText(ruleDrillPrompt(screened, rules, said, cands)).text, maxTokens RULE_DRILL_TOKENS 3500, timeoutMs 90000, kind 'note', 'manual', 그다음 ruleFixReply. 건너뜀: 호출 없음.
- N2 채점(첫 시도만): CHECK_SYSTEM, redactText(checkPrompt({ name: '팀 규칙', question: drillQuestion(sent), answer: sent.example, kind: 'modify' }, `${sent.indent}${mine}`, 'beginner', undefined, undefined, { rule: sent.rule })).text, maxTokens 480, timeoutMs 60000, 두 번; 그다음 parseCheck(text, { rule: true })와 짓기 트리의 ruleGradeCap(sent, ruleFixUse(sent.check), mine, capKnownNames(screened diff들, after 파일), pairLangOf(sent.file), after 파일, ruleAvoidsOf(team.rules, use)) — 호출 없음.
- 다시 보내지 않음: 빈 답, 상한 닿음, 시간 한도. API 오류는 적고 다시 보내지 않음; 한 모델-스테이지의 10%를 넘으면 → M-4(무효, 끔). 스테이지마다 빈 답은 모두 탭으로 한 번 다시 보내 stop_reason/stop_details만 적음(기록).
- 첫 호출 전 D34: 짓기 트리의 플러그인 시험 하네스(level beginner, model 'haiku', 하네스 줄이 isRuleDrill + isRuleWide를 켬; 그리고 하네스 없음)로 노트 요청, 2단 요청 모두, N2를 얼린 뒤 N2 채점 요청 모두(model, effort, system, prompt, maxTokens, timeoutMs)를 잡아 도구의 줄과 바이트까지 견줍니다. 1단과 건너뛴 노트는 둘째 요청이 없고; 하네스 없는 잡기는 노트 요청 하나뿐입니다.

계획 묶음 1의 글(옮김)
- 회마다: 노트 호출 85번(SYSTEM, notePrompt(screened, 'beginner', [], team) 1.8.0 바이트, maxTokens 3500, timeoutMs 90000) + 2단 호출 약 20번(RULE_DRILL_SYSTEM, redactText(ruleDrillPrompt(…)).text, 3500, 90000); 1단과 건너뜀은 호출 없음.
- N2: 번마다 채점 호출 30번 × 두 번(CHECK_SYSTEM, checkPrompt(…{ rule }), 480, 60000, 첫 시도만); 그다음 parseCheck(text, { rule: true })와 짓기 트리의 ruleGradeCap(호출 없음).
- 모두: haiku 노트 약 170 + 2단 약 40 + N2 60 ≈ 270, 빈 답의 탭 더함; sonnet은 기본으로 0.
- 스테이지: 회 A haiku(노트 + 연습을 러너 하나로); 회 B haiku; A와 B가 저장되고 해시되기 전에는 아무것도 열지 않음; 그다음 N1′ 판정; 그다음 N2 견본; N2 1번째 haiku; N2 2번째 haiku.
- 방법: 플러그인과 똑같이(D20): 프로브 mod 사본이 $.model.complete({ model: 'haiku', effort: 'low', system, prompt: redactText(prompt).text, maxTokens, timeoutMs })를 부르고, 4개씩, $.clock 시간, 답은 fixEscapedTicks를 거침; 프롬프트는 커밋된 트리의 notes.ts를 불러 haiku의 줄 + isRuleDrill true로 지음(M-13: haiku 줄에는 rungChangedStep 2도 있지만 G6 호출은 그것을 읽지 않음).
- 다시 보내기: 빈 답, 상한 닿음, 시간 한도는 다시 보내지 않음. API 오류는 적고 다시 보내지 않음(G6 §2); M-4 10% 규칙; 빈 답은 모두 탭으로 한 번(기록).
- D34: 견본마다 짓기 트리의 시험 하네스(beginner, model 'haiku', 하네스 줄이 isRuleDrill + isRuleWide를 켬; 그리고 하네스 없음)로: 노트 요청, 2단 요청 모두(1단/건너뜀 노트는 둘째 요청이 없음), N2를 얼린 뒤 N2 채점 요청 모두, 도구 줄과 바이트로 견줌; 하네스 없는 잡기는 노트 요청 하나뿐.

이 묶음이 정한 것(위 글을 도구로 옮긴 자리, 기록)
- 모델-스테이지: `A`(회 A), `B`(회 B), `N2-1`, `N2-2`(N2 1번째 · 2번째), 모두 haiku. 계획의 관문 자리 'G6 회 A haiku(회 관문 + 스테이지 관문), 회 B haiku, N2 1번째 haiku, N2 2번째 haiku'와 하나씩 맞습니다. 회 A · B의 모델-스테이지 하나는 노트 호출 85번(프로브 세션 하나) 뒤에 그 노트 답으로 2단 줄을 짓고(`tools/build.mjs drill`), 그 2단 요청을 D34로 하네스와 견준 뒤(`d34/make.py real`; 다르면 2단 호출 없이 멈춤, 종료 8), 2단 호출을 합니다(프로브 세션 하나). M-4의 10%는 그 모델-스테이지의 노트 + 2단 호출 모두로 셉니다.
- 떼어 낸 러너(러너 규칙): `ONLY_WORKFLOW=1 setsid nohup bash tools/stage.sh <A|B|N2-1|N2-2> haiku`. 에이전트는 STARTED · 세션마다의 status.jsonl · DONE · summary.json · 러너 로그만 봅니다. 러너는 (1) sonnet을 거절하고(재지 않음), 차례(B는 A 뒤, N2-2는 N2-1 뒤)와 STARTED가 없는지를 보고, (2) 고정한 길로 앞 'ok' 세션(`probe/precheck.sh`)을 돌려 `tools/gate.py pre`로 앞 기록(고정한 `claude --version` 2.1.329, 그때 다시 센 고정 바이너리 sha256 `30e2724e…6d6d` · `c3484833…8e74`, 별칭의 init model과 modelUsage 키가 '보정 기록 (1.13.0)'의 haiku 기록 `impl113/b0/calib/pre/haiku-1/record.json`과 같음)과 사용량 관문(위 '사용량 관문')을 봅니다. 기록이 다르면 부르지 않고 멈추고(종료 3), 관문을 못 넘으면 STARTED 없이 resetsAt을 찍고 기다립니다(종료 7), 다른 워크플로가 돌지 않는다는 밝힘(ONLY_WORKFLOW=1)이 없으면 시작하지 않습니다. (3) STARTED(UTC, 요청 파일 sha256)를 쓰고 부르며, (4) 뒤 기록을 `tools/gate.py after`로 견주어 다르면 무효(종료 4), 던진 호출은 M-4 넷째 줄(종료 5), api-error가 10%를 넘으면 무효(종료 6)이고, 아니면 summary.json(상태 수와 답 파일 sha256)과 DONE을 씁니다. 어떤 호출도 다시 보내지 않습니다.
- 끊긴 스테이지(끊긴 스테이지 규칙): 프로브 세션이 답 파일 없이 끝나면 러너는 상태 수로만 summary.json을 씁니다(상태 줄이 없는 얼린 요청 = api-error; 아직 짓지 않은 2단 요청은 셀 수 없어 뺌; `cut: true`) — 종료 9. 10%를 넘으면 무효이고, 다른 날 같은 요청 파일로 `<stage>-r2`를 통째로 한 번 돌릴 수 있습니다(러너가 요청 파일 sha256이 같은지, 원래 스테이지에 무효(끊김) 요약이 있는지 확인; 그 밖의 STARTED는 모두 거절). 그 뒤 도구들은 `<stage>-r2`의 DONE이 있으면 그 폴더를 읽습니다. 무효 스테이지의 파일은 건드리지 않습니다.
- 모델 기록(M-10, D19): 앞 기록은 모델-스테이지마다의 앞 'ok' 세션과 고정한 길의 --record, 뒤 기록은 그 스테이지의 프로브 세션들(세션마다 앞뒤 claude --version, 턴마다 init model, result의 modelUsage 키)과 끝의 --record입니다. 모두 '보정 기록 (1.13.0)'(2.1.329, 고정 사본 sha256, haiku의 풀린 id)과 같아야 합니다.
- 빈 답의 탭(기록만): 모델-스테이지마다 답 파일별로 `tools/tapsend.py <스테이지> haiku <note|drill|n2>`.
- 쓰는 쪽 · 확인자 호출: 모두 `gen/run.sh`(떼어 낸 러너, 아래 도구 6)로 돕니다: 견본 쓰는 쪽(`gen/out`, samples), 보충(`gen/out-topup-<K>`), N2 쓰는 쪽(`gen/n2/<꼬리표>`, files json), 행 확인자(`judge/rowcheck/<꼬리표>`), N2 확인자(`judge/n2check/<꼬리표>`), 번역 확인자(`bar/xcheck`).

#### 위험 (재기 전에 적음; 설계 risks 옮김)

- haiku N2: 상한이 볼 수 없는 깨짐 하위 꼴(리터럴과 함께 바뀐 인자 차례, 빠진 안쪽 호출/멤버나 인자, 빠진 `await`, 감싸개)을 맞음이라 매김 → 깨짐→맞음 1로 N2 못 넘음. 모음: 그런 깨짐 답 28개 가운데 11개를 잡지 못함; 지금까지 본 haiku의 거짓 맞음(3)은 모두 이름이나 규칙 꼴이었음. 잰 N2마다 약 10–20%.
- haiku N2: 상한이 낮추는 꼴로 쓴 지킴(예시 답 꼴에 정의되었지만 다른 이름, 날 · 이스케이프 문자열 꼴) → NEW 지킴 낮춤 줄을 못 넘음: 마지막 상한으로 지킴 168개 가운데 0개가 낮춰졌고, 다듬기 전에는 1개; 약 5%.
- 실제 플러그인은 연습 파일을 지금 있는 그대로 읽고, N2는 얼린 after 파일을 넘깁니다. diff와의 합집합은 이름을 더하기만 하므로 실제 상한은 잰 것보다 엄하지 않습니다(실제 파일의 다른 곳에 있는 이름을 쓰는 학습자의 깨진 줄은 잡히지 않음).
- 두 번째 시도 요청은 코드가 쓴 '첫 판정: 거의'와 피드백을 싣습니다; N2는 이것을 재지 않습니다(앞선 모든 회처럼 첫 시도만). 잘못 낮춰진 맞는 줄은 같은 까닭으로 다른 맞는 다시 해 보기에서도 거의로 남습니다(끈끈함); 규칙 연습은 개념을 표시하지 않으므로 값은 그날의 수와 일지 줄입니다.
- den 여유: 두 회 모두 ≥ 80%여야 하고, 회마다 구조적 den 놓침 약 1개를 거절함(os.getenv, 인용 없는 날짜 노트, api_request 인자 차례).
- sonnet: 기본으로 재지 않음; 재면 이 설계와 상관없이 P(할 일 둘 줄을 넘음) ≈ 39%.
- 어느 회에서든 isRuleWide W 오탐 하나가 isRuleDrill을 막음(함께 쓰는 W2; 1.12.0 잼과 1.13.0 개발에서 haiku 0).
- checkPrompt/parseCheck, notePrompt, keptNoteText/ruleLabelled/ruleNamesOf, drillOf/hideDrillAnswer 끈 길을 건드리는 다른 1.13.0 설계는 잰 바이트를 바꿉니다(D26) — 이 기준 커밋 전에 차례를 정하거나 다시 고정해야 함. (기록: 묶음 차례로 G6이 첫 잰 묶음이고, 뒤 묶음은 D26으로 이것을 다시 확인합니다.)
- sonnet 따라가기 거절 사실: 새 프롬프트 문구가 없으므로 새 거절 위험도 없습니다(2단과 채점 프롬프트 그대로; 1.12.0 잼과 1.13.0 개발에서 거절 0). (이 묶음의 기록) 세 요청(노트 notePrompt 1.8.0 바이트, 2단 ruleDrillPrompt — 규칙 · 줄 · 예시 답 세 줄만 묻는 닫힌 꼴, N2 checkPrompt 1.9.0 바이트)은 코드를 한 줄씩 따라간 과정을 적으라고 하지 않으며, 이 묶음은 haiku만 부릅니다. 그래도 빈 답 · 거절은 E18대로 '답 없음'에 셉니다(노트 호출이면 §2대로 그 회 L · O에서 빠짐). 탭 기록은 따로 적는 열입니다.
- (이 묶음의 기록) 보정: 1.13.0 보정 기록(2.1.329, H_haiku 2048)이 각 회의 앞 기록과 같아야 합니다(M-10). 설치된 claude가 컨테이너가 다시 켜진 뒤 바뀌어도 모든 부르기는 고정한 2.1.329 사본으로 합니다(base.cliPin); 고정 사본을 잃으면 남은 회차는 재지 않습니다(주인 물음 1).
