#### 결정 규칙

설계 decisionRule 글(옮김)
1. 모델 m ∈ {haiku, sonnet}마다, m의 수로만, 다시 굴리기 없이: isRuleDrill_m = 기준 커밋에서 MODEL_SWITCHES[m].isRuleWide가 true ∧ W 줄이 두 회 모두에서 넘음 ∧ N1′의 모든 줄이 회 A와 회 B에서 넘음 ∧ N2가 두 번 모두 넘음(바른 판정 ≥ 27, 어김→맞음 ≤ 1, 깨짐→맞음 = 0, 규칙 빠짐 ≤ 1, 지킴 낮춤 = 0, 낮추기 전 (어김+깨짐)→맞음 ≤ 2) — 아니면 false.
2. 1.13.0에서 재지 않은 모델(기본으로 sonnet)은 끔 그대로입니다; haiku에서 넘겨받지 않습니다.
3. 무효인 회(M-4, M-10) → 그 모델은 끔, 1.13.0에서 다시 재지 않음. 정하지 못한 꼴은 못 넘는 쪽으로 셉니다.
4. isRuleWide_m은 다시 정하지 않습니다; W 오탐은 isRuleDrill_m만 막습니다(적음).
5. 스위치 줄은 결정 커밋 다음 커밋에서만 바뀌고, 그때 옛 창 확인(30adc2f를 포함한 notes.ts 일곱)과 coexist19를 켠 값으로 다시 돌립니다(R9). 잰 요청을 짓는 코드나 문장을 그 뒤에 바꾸면 그 칸은 끔이 됩니다(D26 재확인).

계획 묶음 1의 글(같은 규칙): isRuleDrill_haiku = 기준 커밋에서 MODEL_SWITCHES.haiku.isRuleWide가 true ∧ W가 두 회 모두 넘음 ∧ N1′의 모든 줄이 A와 B에서 넘음 ∧ N2가 두 번 모두 넘음; 아니면 false. sonnet은 재지 않으므로 → false 그대로(넘겨받지 않음). isRuleWide_m은 다시 정하지 않습니다; W 오탐은 isRuleDrill만 막습니다.

- 판정자(계획 judges): 꼬리표마다 얼린 기계 판정자(`impl112/b1/tools/judge.py` + `key.py`를 다시 지은 것, 1.13.0 입장의 더함 E19ff를 넣고, 기준 커밋에서 해시를 적고, 커밋된 입장과 줄마다 다시 견줌; 이 묶음의 `tools/judge.py`)와 그 꼬리표만 보는 새 opus 행 확인자 하나(D7). 판정자와 확인자가 갈리면 못 넘는 쪽으로 셉니다(M-9). N2: 낮추기 전 판정과 항목마다 낮춘 까닭을 포함한 기계 셈(`tools/n2build.mjs judge`)과 새 opus 확인자 하나(`tools/n2check.py`). 확인자가 적은 행은 모두 못 넘는 쪽으로 셉니다(`tools/decide.py`).
- 멈춤(계획 stop, 옮김)
  - 조건 (a) → 묶음 통째로 건너뜀(묶음 0에 적음). 걸리지 않았습니다(H_haiku 2048).
  - 짓기 트리에서 isRuleWide나 G2 haiku의 D26 다름 → 짓기 커밋 전에 고침; 같게 만들 수 없으면 멈추고 알림. 짓기에서 다름 0이었습니다.
  - 회 무효(M-10)나 M-4 → isRuleDrill haiku 끔, 다시 재지 않음.
  - 회 A의 바른 연습이 5개보다 적음 → N2 못 넘음(셈).
  - 끈 읽기의 W 오탐 → isRuleDrill haiku만 막고 isRuleWide는 그대로(적음).
  - 같은 호출에서 쓰는 쪽이 두 번 거절됨(commonPerBatch.writerRunner의 거절; 사용량 한도로 끝난 것은 WAIT) → STOP, 재지 않음(적음).

#### 모델마다 (설계 perModel, 기록만 · B-12, 결정에 들지 않음)

- haiku: 잼. 개발 기록(B-12, 새 세트 2개, 노트 75개; 마지막 상한으로 다시 읽음): N1′의 반드시 0인 줄 모두 0(해로움 0, 두 읽기의 할 일 둘 0, 함정 0/12, 표지 없음 0, (c) 0, W 오탐 0), den 26 바름 24 = 92.3%(92.9% / 91.7%), 2단 답 없음 0/19, 거절 0; 작은 N2 28/29와 30/30, 어김→맞음 0, 깨짐→맞음 0, 빠짐 0, 지킴 낮춤 0, 낮추기 전 (어김+깨짐)→맞음 1과 1(≤ 2). 1.12.0에서 실패한 꼴이 개발에서 두 번 다시 나왔고 상한이 둘 다 잡았습니다. 넘을 확률 약 55–60%(위험: 상한이 볼 수 없는 깨짐 꼴을 맞음이라 함, N2마다 약 10–20%; 상한이 낮추는 지킴 꼴, 약 5%; den 여유).
- sonnet: 1.13.0에서 재지 않음(기본값). 개발 수는 모든 줄 이상입니다(den 41 바름 38 = 92.7%, 노트 75개에서 반드시 0인 줄 모두 0, N2 두 번 모두 29/30, 거절 0). 그러나 상한은 sonnet에 잰 이득을 주지 않으며(1.12.0 잼과 1.13.0 개발에서 sonnet 혼자 낸 break/broken→맞음 0), 1.12.0의 유일한 실패인 자기 낸 노트 호출의 끈 읽기 할 일 둘은 이 설계로 바뀌지 않습니다: 한 회는 같은 실패 줄을 다시 굴리는 것입니다(그 줄을 넘을 확률 약 39%, 전체 약 30%). 바뀌어야 할 것: 주인이 isRuleDrill의 할 일 둘 줄은 켠(저장되는) 읽기만 센다고 정함(ownerQuestions[0] (a)), 또는 이 확률로 재는 것을 분명히 받아들임((b)), 또는 sonnet용 isRuleWide/노트 호출 설계를 따로 만들어 스스로 고쳐 쓰는 할 일 둘 노트를 없앰(그 자신의 D26 결과).

#### 견본의 짜임

설계 samples 글(옮김)
- 새 얼린 견본 세트 하나, 1.12.0 짜임 글자 그대로(85 + 예비): R 40(규칙마다 10; js 14 · ts 12 · py 14), R_long 4, F 12, N 12, 함정 9(규칙 모듈 ×4, 규칙마다 하나, py ≥ 1, ts ≥ 1; 테스트 ×2; 빌드 스크립트 ×1; 쓰라는 이름을 내보내는 줄기 아닌 모듈 ×1; process.env를 읽는 `*.config.*` 파일 ×1), multi 4, double 4. 같은 팀 파일(규칙 넷 + `## 용어` 2, 그대로)과 열쇠 §5. 두 모델용으로 씀(sonnet은 주인이 켤 때만 같은 세트를 씀, ownerQuestions[0]); haiku 스테이지 먼저.
- 쓰는 쪽: 새 `claude -p --model opus --tools ''` 하위 에이전트, 호출마다 기록 10개 이하, 호출마다 세트 종류 하나(G3 STOP 교훈: 약 12번, 예: R 10개씩 4번, R_long+F 2, N 2, 함정 9개 1번, multi+double 1, 그리고 예비). 각자 팀 파일, 모듈 표, 견본 JSON 꼴, 1.10.0 작성 규칙(규칙마다 표지; 표지 · 호출 꼴 · 인자 수는 마음대로)과 이름만 든 피할 목록(견본.md 글은 절대 아님)만 받습니다. RULE_DRILL_SYSTEM, ruleDrillPrompt, ruleFixPlan, ruleGradeCap, notePrompt, RULE_CHECK, ruleLabelled, 이 설계, 입장, 어느 모델을 재는지는 보지 않습니다. 도구 호출 글을 찍거나 거절된 쓰는 쪽은 같은 입력으로 한 번 다시 돌리고(기록), 고쳐 쓰지 않습니다.
- 얼릴 때 확인(모델 호출 0), 1.12.0과 같음: JSON이 읽힘; demo가 §8대로 돌고 expected와 같음; violation마다 fix로 돌린 것이 돌고 적힌 그대로 돌린 것보다 대역 기록을 더 많이 씀(엄격한 S1), 그 표준 출력은 expected_fixed로 얼림; violation 줄은 `after`에 있고 §5 표지를 품으며, fix는 쓰라는 이름을 품고 표지가 없음; 함정이 아닌 견본의 표지 줄은 모두 violation(F: 주석/문자열 안에만 있는 표지 글자는 됨); R/multi/double은 들여쓰기 빼고 40자 이하, R_long ≥ 41; R/multi/double은 그 모듈을 import함; F/N/함정의 violations는 빔; 개발 경로와 같은 파일 경로는 거절. 못 넘은 견본은 같은 무리 예비로 id 차례대로 바꾸고, 고쳐 쓰지 않습니다; 바꾼 수를 적습니다. samples.json, team.md, 열쇠를 얼림(chmod 444, sha256, 쓴 쪽, UTC 시각을 견본.md에).
- 둘째 스테이지: 잰 꼬리표마다 N2: pick.py가 그 꼬리표의 회 A에서 바른 연습 5개를 고릅니다(규칙 넷 모두, py ≥ 1, ts ≥ 1; 채울 수 없는 조건은 빼고 적음; 바른 것이 5개보다 적으면 → N2 못 넘음). 고른 연습마다 새 opus 쓰는 쪽 하나(호출마다 답 10개 이하, 얼린 1.12.0 틀에 그 연습 하나만; gradeDrill이 보이는 대로의 연습 — 코드가 쓴 할 일과 확인, 줄, 예시, 규칙 줄, 파일, demo — 와 팀 파일만 봄)가 지킴 2 · 어김 2 · 깨짐 1 · 엉뚱함 1과 갈래마다 예비 하나를 씁니다; n2verify(세부 22)가 얼리기 전에 돌려 봅니다; 예비로 채우고, 고쳐 쓰지 않습니다.
- 겹치지 않을 개발 이름
  - 1.13.0 개발 id: E1A01-E1A10, E1B01-E1B10, E1C01-E1C08, E1D01-E1D10(세트 1, 얼린 36개, sha256 10491a07…)과 E2A01-E2A10, E2B01-E2B10, E2C01-E2C10, E2D01-E2D10(세트 2, 얼린 39개 + 뺀 E2A08, sha256 c3d309c5…); E1A01-E1A10, E1B04, E1B06의 상한 모음 답.
  - 이름(파일 이름과 식별자): `impl113/NAMES-all.txt`에서 'G6-dev-113' 꼬리표를 단 209개(`impl113/design/G6/dev/set1/names.txt` 94, `impl113/design/G6/dev/set2/names.txt` 115).
  - 앞선 G6 이름: `impl113/NAMES-all.txt`의 모든 'G6-dev'(1.12.0 개발 D1A01–D4B24, 이름 1214) 줄과 'G6-measured'(1.12.0 GA–GD, 이름 337) 줄, 견본.md의 모든 id(1.10.0 TA/TB/TC/TD; 1.9.0 C/G id; 1.12.0 GA–GD). 잰 쓰는 쪽은 그 합집합을 이름만 든 피할 목록으로 받고, check.py는 파일 경로가 그 경로 가운데 하나와 같은 견본을 거절합니다.

계획 묶음 1의 글(옮김)
- 짜임: 새 얼린 세트 하나, 1.12.0 짜임 글자 그대로(85 + 예비): R 40(규칙마다 10; js 14 · ts 12 · py 14), R_long 4, F 12, N 12, 함정 9(규칙 모듈 ×4, 규칙마다 하나, py ≥ 1, ts ≥ 1; 테스트 ×2; 빌드 스크립트 ×1; 쓰라는 이름을 내보내는 줄기 아닌 모듈 ×1; process.env를 읽는 *.config.* 파일 ×1), multi 4, double 4; 팀 파일 = 1.10.0 것 그대로(규칙 4 + 용어 2); 열쇠 §5. 원칙상 두 모델용으로 씀(sonnet 스테이지는 주인이 1/4 첫 커밋 전에 ownerQuestions 15에 (a)/(b)로 답할 때만 돎; 답이 오지 않아 돌지 않음); haiku 스테이지 먼저.
- 쓰는 쪽: 새 눈가림 opus 쓰는 쪽, 호출마다 기록 10개 이하, 호출마다 세트 종류 하나. 기준 커밋은 이것을 설계의 'R_long+F 2 … multi+double 1'에서 바꾼 쓰는 쪽 짜임으로 밝힙니다(기반 짜임이지 기준 줄이 아님). R 10개씩 4번(규칙마다 하나, 언어 섞임은 고루); R_long 4(1번); F 12를 6개씩 2번; N 12를 6개씩 2번; 함정 9(1번); multi 4(1번); double 4(1번). 세트 종류마다 예비 호출 하나(각 예비 ≤ 10; 수는 기준 커밋에서 정함)로 모두 약 18번. 쓰는 쪽마다 팀 파일, 모듈 표, 견본 JSON 꼴, 1.10.0 작성 규칙, avoid113.py의 이름 목록만 봅니다. RULE_DRILL_SYSTEM, ruleDrillPrompt, ruleFixPlan, ruleGradeCap, notePrompt, RULE_CHECK, ruleLabelled, 설계, 입장, 어느 모델을 재는지는 보지 않습니다. 예비 뒤에도 수를 못 채우면: 그 종류의 미리 정한 보충 호출 하나, 그다음 STOP(재지 않음, 적음).
- 얼릴 때 확인: 모델 호출 0, 1.12.0처럼: JSON이 읽힘; demo를 돌린 것 = expected; violation마다 fix로 돌린 것이 대역 기록을 더 많이 씀(엄격한 S1), 표준 출력은 expected_fixed로 얼림; violation 줄은 after에 있고 §5 표지를 품으며, fix는 쓰라는 이름을 품고 표지가 없음; 함정이 아닌 견본의 표지 줄은 모두 violation; R/multi/double ≤ 40자(들여쓰기 빼고), R_long ≥ 41; R/multi/double은 모듈을 import함; F/N/함정의 violations는 빔; impl113/NAMES-all.txt나 넓힌 겹침 모음(commonPerBatch.freezeCheckInputs)의 어느 개발 경로나 앞서 잰 경로와 같은 파일 경로는 거절. 못 넘은 견본은 같은 무리 예비로 id 차례대로 바꾸고, 고쳐 쓰지 않음; 바꾼 수를 적음. samples.json, team.md, 열쇠를 얼림(chmod 444, sha256, 쓴 쪽, UTC를 견본.md에). id는 NAMES-all.txt와 견본.md에 없음을 확인한 새 머리 글자를 씀(제안 HA–HD).
- 둘째 스테이지: 회 A에서 haiku 꼬리표의 N2: pick.py가 바른 연습 5개를 고름(규칙 넷 모두, py ≥ 1, ts ≥ 1; 채울 수 없는 조건은 빼고 적음; 바른 것이 5개보다 적으면 → N2 못 넘음). 고른 연습마다 새 opus 쓰는 쪽 하나: 호출마다 답 10개(지킴 2 · 어김 2 · 깨짐 1 · 엉뚱함 1 + 갈래마다 예비 하나). 이것은 '호출마다 세트 종류 하나'의 밝혀 둔 예외입니다: 연습 하나의 답 갈래 넷, 기록 10개, 기준 커밋에 그 수와 함께 이름으로 적음(이 줄). gradeDrill이 보이는 대로의 연습과 팀 파일만 봄; n2verify가 얼리기 전에 돌려 봄; 예비로 채우고, 고쳐 쓰지 않음.
- 피할 목록: 그 스테이지가 시작할 때 NAMES-all.txt에 돌린 avoid113.py의 출력(calibration.avoidBuilder): 모든 G6 꼬리표(G6-dev, G6-measured, G6-dev-113: E1A01–E1D10, E2A01–E2D10과 그 파일 경로)의 개념 · 파일 · 코드 이름, 다른 모든 G의 개발과 잰 기록 파일의 이름, 그리고 거르기를 넘는 견본.md 이름 칸. check.py(NAMES_FILE = impl113/NAMES-all.txt)는 파일 경로가 온전한 이름 목록(commonPerBatch.freezeCheckInputs)의 어느 경로와 같은 견본을 거절합니다.

이 묶음이 정한 것(위 글을 도구로 옮긴 자리, 기록)
- 쓰는 쪽 짜임(`gen/parts.json`): 본 호출 12번(견본 85) + 예비 호출 7번(예비 23) = 19번. 계획의 '약 18번'은 R 4 + R_long 1 + F 2 + N 2 + 함정 1 + multi 1 + double 1 = 12번에 예비 7번을 더한 19번입니다(계획 글의 셈 그대로; '약'). 모두 호출마다 세트 종류 하나, 기록 10개 이하입니다.

| 부분 | 종류 | id | 수 · 언어 | 사슬 |
| --- | --- | --- | --- | --- |
| RA | R, request | HA01–HA10 | 10 · js 3 · ts 3 · py 4 | A |
| RB | R, log | HB01–HB10 | 10 · js 4 · ts 3 · py 3 | A |
| RC | R, date | HC01–HC10 | 10 · js 3 · ts 3 · py 4 | A |
| RD | R, config | HD01–HD10 | 10 · js 4 · ts 3 · py 3 | A |
| RL | R_long | HE01–HE04 | 4 · 규칙과 언어는 쓰는 쪽이 고름 | B |
| F1 · F2 | F | HF01–HF06 · HF07–HF12 | 6 + 6 · 셋이 고루 | B |
| NA · NB | N | HN01–HN06 · HN07–HN12 | 6 + 6 · 셋이 고루 | B |
| T | 함정 | HT01–HT09 | module request · log · date · config(py ≥ 1, ts ≥ 1), test ×2, script, export, config | C |
| M | multi | HM01–HM04 | 4 | C |
| W | double | HW01–HW04 | 4 | C |
| RS | R 예비 | HR01–HR08 | 8 · 규칙마다 2 | A |
| LS | R_long 예비 | HL01–HL02 | 2 | A |
| FS | F 예비 | HS01–HS03 | 3 | B |
| NS | N 예비 | HO01–HO03 | 3 | C |
| TS | 함정 예비 | HQ01–HQ03 | module(아무 규칙), export, config | C |
| MS | multi 예비 | HK01–HK02 | 2 | C |
| WS | double 예비 | HP01–HP02 | 2 | C |
| TU-R · TU-L · TU-F · TU-N · TU-T · TU-M · TU-W | 미리 정한 보충(그 종류가 예비 뒤에도 모자랄 때만, 종류마다 한 번) | HUR01–08 · HUL01–02 · HUF01–03 · HUN01–03 · HUT01–03 · HUM01–02 · HUW01–02 | 그 종류의 예비 호출과 같은 짜임 | 따로 |

- 머리 글자 HA · HB · HC · HD · HE · HF · HN · HT · HM · HW · HR · HL · HS · HO · HQ · HK · HP · HU는 NAMES-all.txt에도 견본.md에도 없습니다(확인함). 규칙마다 R의 언어 수는 1.12.0과 같습니다(합 js 14 · ts 12 · py 14).
- 바꾸는 차례(check.py RESERVES, id 차례): R HR01–HR08, 그다음 HUR01–HUR08; R_long HL01–HL02, HUL01–HUL02; F HS01–HS03, HUF01–HUF03; N HO01–HO03, HUN01–HUN03; 함정 HQ01–HQ03, HUT01–HUT03; multi HK01–HK02, HUM01–HUM02; double HP01–HP02, HUW01–HUW02.
- 보충 차례: 먼저 `OUTDIR=frozen-pre`로 check.py를 돌려(기록) 예비 뒤에도 모자란 종류를 봅니다. 모자란 종류마다 그 보충 호출 하나(`gen/run.sh <root> topup <K>`, 자기 폴더, CHAIN_ROOT = 견본 폴더)를 부르고, 그다음 extract.py와 check.py를 `frozen/`에 한 번 돌립니다. 그래도 모자라면 STOP(재지 않음, 적음).
- 쓰는 쪽 프롬프트 = `gen/common.md` + 부분 단락(`gen/parts.py`가 1.12.0 부분 글에서 지음: id, 종류, 규칙, 언어, 그 종류의 1.12.0 글) + 같은 사슬의 앞 부분이 이미 쓴 파일 경로와 demo 함수 이름('다시 쓰지 마라') + 피할 단락(그 쓰는 쪽 스테이지가 시작할 때 `gen/avoid113.py`, `impl113/gen/avoid113.py`와 바이트까지 같음). 세 사슬 A · B · C는 나란히 돌고 사슬 안에서는 차례대로 돕니다.
- 틀 고침(피할 목록 짓기 합성 시험 (1)이 틀에 걸려 기준 커밋 전에 고침, 그 바꿈을 적음): 1.12.0 `gen/common.md`(`1d55fe37…de4c`)와 `gen/n2-frame.md`(`e5ea60af…7d78`)에서 (1) '견본'이라는 낱말(거르기 (b) 패턴의 하나)을 '사례'로 바꾸고 조사를 맞춤, (2) common.md 피할 이름 줄에서 손으로 적은 여섯 이름(storeMap, buildInfo, unansweredCount, searchProducts, format_date, countPassing)을 빼고 '맨 끝 피할 이름 절의 이름 모두'만 남김(피할 목록은 짓기 도구의 출력만; 여섯 모두 짓기 도구의 출력에 들어 있음을 확인함), (3) n2-frame.md는 연습 하나에 대한 글로 바꿈('연습마다' → '연습 하나에 대해', 출력 꼴의 끝 '…' 뺌). 그 밖의 글은 그대로입니다.
- 피할 목록 거르기(짓기 도구가 쓰는 그대로, 위 '피할 목록 짓기'를 옮김)
  - (a) 개념 이름은 꼬리표가 '견본'이 아닌 줄(기록 파일)에서만 옵니다: 개발 이름의 ': ' 앞 주제, 2–30자, avoid.py와 같음. '견본' 꼬리표 줄은 개념 이름을 주지 않습니다.
  - (b) 대소문자를 가리지 않고 haiku|sonnet|opus|fable|claude|anthropic|model|isRule|rung|isThink|isBase|isChanged|worked|stance|judge|verdict|calib|impl11|alias|gateway|bedrock|vertex|override|provider|모델|채점|견본|판정|프롬프트에 맞는 항목(개념, 파일, 코드 이름; 어느 줄에서 왔든)은 모두 뺍니다.
  - (c) 파일 이름과 코드 이름은 기록 파일 줄(꼬리표 ≠ '견본')과 names.json에서 옵니다. '견본' 꼬리표 줄은 다음일 때만 파일이나 코드 이름을 줍니다: 공백이 없음; 경로의 어느 부분도 judge, tools, calib, gen, stage, frozen, pilot, audit, review, fix, sw, cli, probe, d26, oldprobe, proofs, design, b<숫자>, b<숫자>r, impl11<숫자>가 아님; 경로의 마지막 부분이 impl111 · impl112 · impl113 아래 어느 tools.sha256 / SHA256SUMS 표에 적힌 파일 이름도 아님. 공백이 든 '견본' 항목(글 조각)은 쓰지 않습니다.
  - (c′) 도구 이름 목록에 있는 파일 이름은 어느 줄에서 왔든 파일 목록에서 뺍니다.
- 얼릴 때 확인(`tools/check.py`; 1.12.0 check.py에 M-15 고침(모듈 함정의 팀 모듈 경로)을 처음부터 넣은 check2.py에서 지음): 위 계획 글의 확인 모두. 거절하는 경로 = NAMES_FILE(`impl113/NAMES-all.txt`, 그 순간의 sha256을 보고서에 적음)의 빗금 든 항목 모두(모든 꼬리표) ∪ 겹침 모음(`impl113/design/*/dev`, `impl113/design/*/pilot`, `impl113/b*/frozen`, `impl112/design/*/dev`, `impl112/b1/frozen`, `impl112/b2/frozen`, `impl112/b3r/frozen` · `dev`, `impl112/b4/frozen` 아래 JSON 기록의 'path' · 'file' 값 가운데 빗금 든 것; 지금 1,352 파일에서 경로 2,419개). 더해서(1.13.0, 더 엄함): 파일 이름(경로의 마지막 부분)이 기록 파일 줄(꼬리표 ≠ '견본')의 파일 이름이거나 겹침 모음 경로의 마지막 부분이면 거절합니다. 쓰는 쪽 틀의 모듈 표에 있는 팀 모듈 파일 이름 열둘(apiRequest.js/.ts, log.js/.ts, dateText.js/.ts, config.js/.ts, api_request.py, log.py, date_text.py, config.py)은 주어진 이름이라 이 규칙에서 뺍니다. 이것으로 얼릴 때 확인 입력의 합성 시험 (1)(`impl113/design/G6/dev/set1/names.txt`의 파일 이름으로 쓴 견본)이 거절이 됩니다(그 names.txt는 경로가 아니라 파일 이름 목록). G6 견본 기록에는 개념 칸이 없고 이 확인에는 인용 · 코드 겹침 규칙이 없어, 합성 시험 (2)는 'G2-dev-113' 경로로 보이고(그 목록 전체를 읽음을 보임) (3)은 해당이 없습니다.
- 팀 파일과 채점 열쇠: `impl113/b1/team.md`(sha256 `18f9d5c755f49db4f9dd767b380bdda569609ffa6a6021ca9f9525881a9b0c9b`, 1.12.0 `impl112/b1/team.md` · 1.13.0 개발 세트의 팀 파일과 바이트까지 같음). 채점 열쇠(§5 표)도 그대로이고, 도구에서는 `tools/key.py`(1.12.0과 바이트까지 같음)입니다. 대역 모듈의 자리(작성 프롬프트와 대역에만): js · ts `src/api/apiRequest` · `src/log` · `src/dateText` · `src/config`, py `app/api/api_request.py` · `app/log.py` · `app/date_text.py` · `app/config.py`.
