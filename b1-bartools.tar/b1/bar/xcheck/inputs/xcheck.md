너는 번역 확인자다. 아래 '원문'(설계 파일 G6의 bar · stance · decisionRule · samples · calls · risks · perModel · ownerQuestions 필드, 계획 묶음 1의 barSource · samples · calls · judges · stop · models · notMeasured 필드; 영어와 한국어)과 '1.12.0 입장 원문'(이 설계가 글자 그대로 다시 커밋한다고 한 1.12.0 글), 그리고 '옮긴 글'(docs/qa/견본.md에 넣을 한국어 절)을 견준다. 코드를 돌릴 수 없고 다른 파일도 없다.

확인할 것:
1. 원문의 모든 수(개수, 비율, 토큰, 밀리초, 문턱, id, 커밋, sha256 앞자리 등)가 옮긴 글에 같은 값으로 있는가.
2. 원문의 모든 조항 · 조건 · 예외 · 미리 정한 경계 꼴이 빠짐없이, 뜻을 바꾸지 않고(더 너그럽게도, 더 엄하게도 아니게) 옮겨졌는가. 특히 bar의 줄마다, decisionRule의 줄마다, stance의 changed · added · unchangedNote · intro마다(stance는 한국어 원문이므로 글자까지).
3. 옮긴 글의 '#### 판정의 입장'이 '1.12.0 입장 원문'을 글자 그대로 담고, 바꾼 곳은 설계 stance.changed가 말한 곳뿐인가(~~ ~~와 '(1.13.0에서 …)' 줄로 표시).
4. 옮긴 글이 원문에 없는 조건을 기준이나 결정에 더했는가. 단, 옮긴 글이 '이 묶음이 정한 것', '읽는 법', '기록', '도구가 글을 읽는 방식', '1.12.0 기준과 다른 점', '밝혀 둔 벗어남', '사용량 관문', '피할 목록 합성 시험', '틀과 도구'로 따로 표시한 곳은 원문 밖의 기록으로 보고, 그것이 원문과 어긋나는지만 본다.
5. 원문끼리(설계와 계획) 어긋나는 곳이 있으면 적고, 옮긴 글이 더 엄한 쪽을 따랐는지 본다.

출력: JSON 하나만 ```json 블록으로. 문제가 없으면 빈 배열.
[{"where": "<옮긴 글의 자리>", "source": "<원문 필드와 줄>", "kind": "number|clause-missing|clause-changed|added|conflict|other", "detail": "<무엇이 어떻게 다른지, 한두 문장>", "fix": "<고칠 글 제안>"}]

## 원문 (JSON)

```json
{
 "design": {
  "bar": {
   "source": "The last committed bar: 1.12.0 G6 (commit 2f95fe1, docs/qa/견본.md '## 1.12.0 팀 규칙 연습 (G6)' > '#### 기준'), which re-commits 1.10.0's (432ced4). Every line below is that bar word for word unless marked NEW (stricter) or STANCE (an explicit, justified counting statement). den is the committed den; the scope is not narrowed.",
   "lines": [
    "Samples: the same fresh frozen samples for both models (85 + spares: R 40 [10 per rule; js 14 · ts 12 · py 14], R_long 4, F 12, N 12, traps 9, multi 4, double 4). Per model two independent rounds A and B; every N1′ line must pass in BOTH rounds; per model only, never combined or transferred.",
    "N1′ (a): O ≥ 20 and rule practices in O notes = 0 (O = a note whose keptNoteText has no `팀 규칙과 다를 수 있음:` line before the practice heading; a `팀 규칙:` line alone is O).",
    "N1′ (b) den: L notes whose sample has a violations line ≤ 40 chars without indent; den ≥ 20.",
    "N1′ (b) correct: correct rule practices (§6 (i)–(vi) all true) ≥ 80% of den; a den note with no practice made (skip, `줄: 없음`, reply not taken, failed call) is not correct.",
    "N1′ (b) harmful = 0 over ALL answered notes of the round (h1 no rule brought in; h2 line not a violations line of a brought rule, incl. traps / R_long / wrong-guess notes; h3 a marker of the brought rule left in the example, incl. reversal/wrap; h4 syntax error in the changed file).",
    "N1′ (b) two-task = 0: notes whose final 직접 해 보기 section(s) hold ≥ 2 task lines (taskLineOf), over ALL answered notes, in BOTH the ON reading and the OFF reading (OFF reading = keptNoteText(same note reply, names), the shipped isRuleWide path; owner question default: keep counting it).",
    "N1′ (c): O notes: note prompt byte-identical ON vs OFF (tests + D34), no practice call for any O note (call log), every O note's final text byte-identical in the ON and OFF readings.",
    "Traps (9) → rule practices = 0.",
    "R_long notes and L notes with no ≤ 40-char violation (F · N · traps) → rule practices = 0 (their own concept practice allowed as in OFF).",
    "Unlabelled rule practice (§9) = 0 in the ON and OFF readings.",
    "Rule-practice no-answer: cap hit (output_tokens ≥ 3500 + H_M), empty reply (API refusal included, E18) or timeout ≤ max(1, ⌊n/60⌋), n = that model's tier-2 calls over both rounds; API errors counted, never re-sent.",
    "Old windows (0 calls): notes.ts of 3f2b4fb · 7a7b08c · 3690021 · fca5988 · 3d2f251 · de98243 + NEW 30adc2f (1.12.0; stricter): on every marked final text (ON and OFF) drillOf gives no practice and hideDrillAnswer shows no `고칠 줄` / `예시 답` line; on every unmarked text each window gives the same task · line · example · file · row as 3d2f251's drillOf.",
    "W gate (isRuleDrill only): in both rounds' OFF reading §11 W false positives = 0 and keptNoteText idempotent on every answer; a W FP blocks isRuleDrill only, never re-decides isRuleWide.",
    "N2 (per measured label, second-stage samples from that model's round A): 5 correct practices picked (all 4 rules, py ≥ 1, ts ≥ 1; < 5 → N2 fails); 30 answers (per practice keep 2 · break 2 · broken 1 · off 1, n2verify-checked, spares fill), graded twice exactly as gradeDrill grades (480, 60000 ms, first try). EACH run: correct verdicts ≥ 27/30, break→맞음 ≤ 1, broken→맞음 = 0, missing `규칙:` line ≤ 1 (unanswered/unreadable = not correct and missing). Excluded answers shrink the denominator but 27 correct are still required.",
    "STANCE (N2 counting, decided before any sample): 'graded exactly as gradeDrill grades' is the 1.13.0 build tree's gradeDrill, i.e. the verdict the learner is shown: parseCheck's 안 지킴 + 맞음 → 거의, THEN ruleGradeCap's 맞음 → 거의. The committed 1.12.0 stance text named only the first lowering because 1.12.0's gradeDrill had only that one; this design states the change openly (it would turn 1.12.0's GA02-10 into 거의). The two NEW lines below make sure the cap can neither hide a grader collapse nor cost a right line.",
    "NEW (stricter), each run: ruleGradeCap on an n2verify keep answer = 0 (a code cap on a right line fails N2).",
    "NEW (stricter), each run: pre-cap (break + broken)→맞음 ≤ 2, counted on parseCheck's verdict before ruleGradeCap (a grader that calls many wrong lines right fails N2 even when code catches them). 1.12.0 measured haiku had 1 per run; 1.13.0 dev haiku 1 per run; sonnet 0.",
    "Decision rule (mechanical, decide.py): isRuleDrill_m = MODEL_SWITCHES[m].isRuleWide true at the bar commit ∧ W passes both rounds ∧ every N1′ line passes in A and B ∧ N2 passes both runs (all its lines, the two NEW included); else false. Invalid round (M-4 infrastructure 10%, M-10 before/after record ≠ the 1.13.0 calibration) → OFF, not re-measured. An undecided case (§15 / M-11) counts toward failing. Stance, key, judge and scripts frozen at the bar commit; tool defects per M-15 (a fail never becomes a pass).",
    "Cap thresholds: 3500 + H_M (note, tier 2) and 480 + H_M (N2) from the 1.13.0 M-5 calibration on a fresh pinned copy of the installed Claude Code (2.1.327 now); every round's before and after record must equal it (M-10), else the round is void and the cell OFF.",
    "Recorded only (S-d / B-12, never in the decision): tier per note, skip reasons, tier-2 fault codes, candidate counts, 1.9.0-definition (b), den misses in 1.10.0 shape, output tokens/time, strict-S1 replacements, practice calls per L note, refusal column; NEW records: cap reason and pre-cap verdict per N2 item, destructuring tier-1/tier-2 hits, last-answer parses, anchored-only lists (and notes skipped 'no-hint' by them)."
   ],
   "statedRisk": "Sonnet's two-task line counts the OFF reading of its own shipped 1.8.0 note call, which this design cannot touch (≈ 39% to pass that line alone, ≈ 30% overall). That is why sonnet is not measured here unless the owner decides otherwise (ownerQuestions[0])."
  },
  "stance": {
   "intro": "판정의 입장(1.13.0 G6). 1.12.0 G6 입장(2f95fe1, 견본.md '## 1.12.0 팀 규칙 연습 (G6)' > '#### 판정의 입장')의 모든 글 — 공통 다섯 항목, 확인 줄(S-a), 견본(S-c), 판정 대상(S-b), 경계 꼴 E1 ~ E18, N2 입장, 다시 커밋하는 1.10.0 입장 §0 ~ §15와 세부 1 ~ 24, '읽는 법' — 을 글자 그대로 다시 커밋합니다. 그 글의 '1.12.0'은 '1.13.0'으로, '1.12.0 보정 기록'은 '1.13.0 보정 기록'으로, '그 판 트리'는 1.13.0 짓기 커밋의 트리로 읽습니다. 아래는 바꾸거나 더하는 곳뿐이며, 바꾼 곳은 1.12.0이 한 대로 원문을 지운 줄(~~ ~~)로 남기고 1.13.0 글을 붙입니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 견본.md '다시 잴 때'에 적습니다(M-11).",
   "changed": [
    "§1 켠 읽기(1.13.0): 1.12.0 글 그대로이고, 그 판 트리의 ruleFixLines · renamedLine · usePlaces · isOneSpanFix · parseRuleFix가 1.13.0 것입니다(피할 이름 없는 규칙은 인용된 줄만 후보, 한 줄 구조 분해의 객체 바꿈, 스스로 고친 답은 마지막 온전한 답). 끈 읽기는 같은 노트 답의 keptNoteText 글 그대로입니다.",
    "§2: 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.13.0 보정 기록). 그 밖은 그대로.",
    "§14 (더함, 엄격하게): 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988 · 3d2f251 · de98243에 30adc2f(1.12.0)를 더한 일곱입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.",
    "E8 (바꿈): ~~2단 답이 스스로 고쳐 쓴 꼴(같은 라벨에 다른 값, 'Wait —'): 코드가 받지 않아 연습 없음입니다.~~ 1.13.0: 코드가 마지막 온전한 답(줄, 줄: 없음이 아니면 예시 답, 첫 답에 규칙이 있었으면 규칙)을 받아 같은 확인(ruleFixFault)을 거칩니다. 마지막 답이 온전하지 않으면 연습 없음입니다. 판정은 언제나 저장된 글만 봅니다.",
    "N2 입장 (바꿈, 재기 전에 밝힘): ~~parseCheck(text, { rule: true }) 뒤 '안 지킴 + 맞음 → 거의' 낮추기를 거친 판정으로 셉니다.~~ 1.13.0: 기준의 'gradeDrill이 매기는 대로'는 1.13.0 짓기 트리의 gradeDrill이 학습자에게 보이는 판정입니다. 곧 parseCheck(text, { rule: true })의 '안 지킴 + 맞음 → 거의'를 거친 뒤, 그 판정이 맞음이면 짓기 트리의 ruleGradeCap(sent, ruleFixUse(sent.check), 답 줄, capKnownNames(그 노트의 screened 변경 diff, 그 견본 파일의 after 글), pairLangOf(sent.file), after 글, ruleAvoidsOf(얼린 팀 파일의 규칙, use))이 무엇을 내면 거의로 셉니다. 바른 판정은 그대로(지키고 동작함 → 맞음, 어겼지만 동작함 → 거의 · 틀림, 깨짐 → 틀림 · 거의, 엉뚱함 → 틀림). 낮추기 전 판정(parseCheck의 판정)은 따로 적고, 새 줄 '낮추기 전 (어김 + 깨짐)→맞음 ≤ 2'만 그것으로 셉니다."
   ],
   "added": [
    "E19 한 줄 구조 분해 예시 답(`const { API_URL, CDN } = config;`, 줄은 `= process.env;`): 쓰라는 이름 config를 품고 표지가 없으므로 (iv)의 출력 비교가 정합니다. 1단이 만들었어도 같은 §6 · §10으로 매깁니다.",
    "E20 GA17 꼴에서 2단 답이 꼴을 바꾼 것(`const SUPPORT_EMAIL = config.SUPPORT_EMAIL;`): 한 자리 고침이 아니라 코드가 받지 않음 → 연습 없음. den이면 바르지 않음, 해롭지 않음.",
    "E21 스스로 고친 2단 답에서 첫 답과 마지막 답이 다른 줄을 고름: 코드가 마지막 온전한 답만 봅니다. 저장된 글의 줄 · 예시로만 §6 · §10을 매기며, 첫 답의 줄은 보지 않습니다.",
    "E22 피할 이름 없는 규칙(날짜)을 짚은 노트에서 인용된 줄이 없음: 후보 없음 → 건너뜀(no-hint) → 연습 없음. den이면 바르지 않음, 해롭지 않음(E17과 같은 셈).",
    "E23 날짜 규칙 2단 예시 답이 값을 다시 감쌈(`toDateText(new Date(at))`): `new Date(`는 §5 표지가 아니므로 h3가 아니고 (iv)의 출력이 정합니다(E1 · E2와 같음).",
    "E24 N2: n2verify keep 답에 ruleGradeCap이 무엇이든 내면 그 답은 바른 판정이 아니고 '지킴 답 낮춤' 줄에 1로 셉니다(그 줄은 0이어야 함).",
    "E25 N2: off(엉뚱함) 답을 모델이 맞음이라 하고 코드가 거의로 낮춤: off의 바른 판정은 틀림뿐이므로 바르지 않음(1.12.0 그대로, 예: 1.13.0 개발 E1A09-28 off → 거의 ✗).",
    "E26 N2: break · broken 답을 모델이 맞음이라 하고 코드가 거의로 낮춤: 바른 판정(거의)으로 세고, 낮추기 전 (어김 + 깨짐)→맞음 줄에 1로 셉니다.",
    "E27 N2: 모델이 거의 · 틀림이라 한 답에 코드는 아무 일도 하지 않습니다(낮추기만, 올리지 않음). 코드가 무엇을 냈을지는 적지 않습니다.",
    "E28 N2: 견본 파일의 after 글을 찾지 못하면(경로가 다름) 코드는 diff 이름만으로 봅니다(플러그인이 파일을 읽지 못한 때와 같음). 그 수를 적습니다.",
    "E29 N2: 도구가 짓기 트리의 ruleGradeCap과 다르게 센 것이 드러나면 M-15로 두 꼬리표를 다시 세고, 못 넘음이 넘음으로 바뀌지 않습니다.",
    "E30 N2는 첫 시도만 잽니다(1.9.0부터 그대로). 낮춘 뒤의 두 번째 시도 요청(첫 판정: 거의 + 코드가 쓴 피드백)은 재지 않고 '위험'에 적습니다.",
    "E31 sonnet 노트가 스스로 고쳐 할 일 줄을 여럿 씀(1.12.0 GD15 꼴, 끈 읽기): E9 그대로 할 일 줄 둘인 노트로 셉니다(두 읽기, 답한 모든 노트). 이 설계가 바꿀 수 없는 끈 읽기의 일이어도 기준 줄은 그대로입니다.",
    "E32 N2 keep 답이 예시 답과 다른 뜻의 같은 꼴(같은 모양에 다른 이름, 예: `toDateText(when)` ↔ 예시 `toDateText(value)`)이고 n2verify가 keep(출력 같음)으로 가름: 코드가 swap으로 낮추면 E24대로 셉니다(넘는 쪽에 불리하게, 미리 정함)."
   ],
   "unchangedNote": "§3 L과 O, §4 연습의 종류, §5 채점 열쇠(요청 · 기록 · 날짜 · 설정의 쓰라는 이름 · 표지 · 낱말 표), §6 바름 (i)–(vi), §7 확인 줄, §8 대역과 돌리기(B-14 py 다섯 번, B-15), §9 표지 없는 규칙 연습, §10 h1–h4, §11 W 오탐, §12 (c), §13 할 일 줄 둘, §15 판정 파일, S-a · S-b · S-c, E1–E7 · E9–E18, 세부 1–24는 1.12.0 글자 그대로입니다."
  },
  "decisionRule": [
   "Per model m ∈ {haiku, sonnet}, from m's counts only, no re-rolls: isRuleDrill_m = MODEL_SWITCHES[m].isRuleWide is true at the bar commit ∧ the W line passes in both rounds ∧ every N1′ line passes in round A and in round B ∧ N2 passes in both runs (correct ≥ 27, break→맞음 ≤ 1, broken→맞음 = 0, missing 규칙 ≤ 1, keep caps = 0, pre-cap (break+broken)→맞음 ≤ 2) — else false.",
   "A model not measured in 1.13.0 (sonnet by default) stays OFF; no transfer from haiku.",
   "A void round (M-4, M-10) → that model OFF, not re-measured in 1.13.0. An undecided case counts toward failing.",
   "isRuleWide_m is not re-decided; a W false positive blocks isRuleDrill_m only (recorded).",
   "The switch row changes only in the commit after the decision commit, with the old-window probe (seven notes.ts incl. 30adc2f) and coexist19 re-run on the ON value (R9). Any later change to code or sentences building a measured request turns the cell OFF (D26 recheck)."
  ],
  "samples": {
   "measured": [
    "One fresh frozen sample set, the 1.12.0 composition word for word (85 + spares): R 40 (10 per rule; js 14 · ts 12 · py 14), R_long 4, F 12, N 12, traps 9 (rule module ×4, one per rule, py ≥ 1, ts ≥ 1; tests ×2; build script ×1; a non-stem module exporting a use name ×1; a `*.config.*` file reading process.env ×1), multi 4, double 4. Same team file (the 4 rules + `## 용어` 2, unchanged) and key §5. Written for both models (sonnet uses the same set only if the owner turns it on, ownerQuestions[0]); haiku stage first.",
    "Writers: fresh `claude -p --model opus --tools ''` sub-agents, at most 10 records per call, one set kind per call (G3 STOP lesson: ~12 calls, e.g. R 4 calls of 10, R_long+F 2, N 2, traps 1 of 9, multi+double 1, plus spares), each given only the team file, the module table, the sample JSON form, the 1.10.0 writing rules (markers per rule; free choice of marker, call shape, argument count) and a NAMES-ONLY avoid list (never 견본.md prose). They never see RULE_DRILL_SYSTEM, ruleDrillPrompt, ruleFixPlan, ruleGradeCap, notePrompt, RULE_CHECK, ruleLabelled, this design, the stance or which model is measured. A writer that prints tool-call text or is refused is re-run once with the same input (records), never edited.",
    "Freeze-time checks (0 model calls), as 1.12.0: JSON reads; demo runs per §8 = expected; each violation's fix-run runs and writes MORE stub records than as written (strict S1) with its stdout frozen as expected_fixed; violation lines in `after`, hold a §5 marker, fix holds a use name and no marker; every marker line of a non-trap sample is a violation (F: comment/string-only marker text allowed); R/multi/double ≤ 40 chars without indent, R_long ≥ 41; R/multi/double import the module; F/N/trap violations empty; a file path equal to a dev path is rejected. Failing samples are replaced by the same group's spares in id order, never rewritten; replacement counts are recorded. samples.json, team.md, key frozen (chmod 444, sha256, writer, UTC time in 견본.md)."
   ],
   "secondStage": "N2 per measured label: pick.py takes 5 correct practices from that label's round A (all 4 rules, py ≥ 1, ts ≥ 1; unfillable conditions dropped and recorded; < 5 correct → N2 fails). One fresh opus writer per picked practice (≤ 10 answers per call, the frozen 1.12.0 frame with that practice alone; sees only the practice as gradeDrill shows it — code task and check, line, example, rule line, file, demo — and the team file) writes keep 2 · break 2 · broken 1 · off 1 + one spare per kind; n2verify (detail 22) runs them before freezing; spares fill, never rewritten.",
   "devNamesNotToOverlap": [
    "1.13.0 dev ids: E1A01-E1A10, E1B01-E1B10, E1C01-E1C08, E1D01-E1D10 (set 1, 36 frozen, sha256 10491a07…) and E2A01-E2A10, E2B01-E2B10, E2C01-E2C10, E2D01-E2D10 (set 2, 39 frozen + dropped E2A08, sha256 c3d309c5…); cap-corpus answers on E1A01-E1A10, E1B04, E1B06.",
    "Names (file basenames and identifiers): the 209 entries tagged 'G6-dev-113' in /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/NAMES-all.txt (/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6/dev/set1/names.txt 94, /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6/dev/set2/names.txt 115).",
    "Earlier G6 names: every 'G6-dev' (1.12.0 dev D1A01–D4B24, 1214 names) and 'G6-measured' (1.12.0 GA–GD, 337 names) entry of /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/NAMES-all.txt, every 견본.md id (TA/TB/TC/TD 1.10.0; 1.9.0 C/G ids; 1.12.0 GA–GD). The measured writers get the union as a names-only avoid list; check.py rejects a sample whose file path equals any of those paths."
   ]
  },
  "calls": [
   "Exactly as the plugin (D20), through the probe mod calling $.model.complete({ model: 'haiku' (setting string as is), effort: 'low', system, prompt: redactText(prompt).text, maxTokens, timeoutMs }), 4 at a time, $.clock timing, replies through fixEscapedTicks. The pinned CLI copy of the 1.13.0 calibration; DISABLE_AUTOUPDATER=1; claude --version, init model and modelUsage keys before and after each round (M-10).",
   "Note: SYSTEM, notePrompt(screened, 'beginner', [], team) (1.8.0 bytes), maxTokens NOTE_TOKENS 3500, timeoutMs 90000.",
   "Practice: the build tree's writeNote path: keptNoteText(reply, ruleNamesOf(rules)) → noteRuleOf → ruleFixPlan(screened, rules, said). Tier 1: no call. Tier 2: system RULE_DRILL_SYSTEM, prompt redactText(ruleDrillPrompt(screened, rules, said, cands)).text, maxTokens RULE_DRILL_TOKENS 3500, timeoutMs 90000, kind 'note', 'manual', then ruleFixReply. Skip: no call.",
   "N2 grading (first try only): CHECK_SYSTEM, redactText(checkPrompt({ name: '팀 규칙', question: drillQuestion(sent), answer: sent.example, kind: 'modify' }, `${sent.indent}${mine}`, 'beginner', undefined, undefined, { rule: sent.rule })).text, maxTokens 480, timeoutMs 60000, two runs; then parseCheck(text, { rule: true }) and the build tree's ruleGradeCap(sent, ruleFixUse(sent.check), mine, capKnownNames(screened diffs, after-file), pairLangOf(sent.file), after-file, ruleAvoidsOf(team.rules, use)) — no call.",
   "Not re-sent: empty reply, cap hit, timeout. API errors recorded, not re-sent; > 10% of a model-stage → M-4 (void, OFF). After each stage every empty reply is re-sent once through the tap for stop_reason/stop_details only (record).",
   "D34 before the first call: from the build tree's plugin test harness (level beginner, model 'haiku', harness row turning isRuleDrill + isRuleWide on; and with no harness) capture the note request, every tier-2 request and, after the N2 freeze, every N2 grading request (model, effort, system, prompt, maxTokens, timeoutMs) and byte-compare with the tool's lines. Tier-1 and skipped notes show no second request; the no-harness capture has the note request only."
  ],
  "risks": [
   "haiku N2: a broken sub-kind the cap cannot see (argument order with a literal, a dropped inner call/member or argument, a dropped `await`, a wrapper) graded 맞음 → broken→맞음 1 fails N2. Corpus: 11 of 28 such broken answers uncaught; every haiku false-맞음 seen so far (3) was a name or rule kind. ≈ 10–20% per measured N2.",
   "haiku N2: a keep written in a form the cap lowers (a defined-but-different name in the example's shape, a raw/escaped string variant) fails the NEW keep-caps line: 0 of 168 keeps capped with the final cap, 1 before refinement; ≈ 5%.",
   "The real plugin reads the drill file as it is NOW; N2 passes the frozen after-file. The union with the diff can only add names, so the real cap is at most as strict as the measured one (a learner's broken line using a name that exists elsewhere in the real file is not caught).",
   "Second-try requests carry code-written '첫 판정: 거의' and feedback; never measured by N2 (first tries only, as in every earlier round). A falsely capped right line stays 거의 on a different right retry with the same cause (sticky); a rule practice marks no concept, so the cost is the day's count and the journal line.",
   "den margin: two rounds each ≥ 80% with ≈ 1 structural den miss per round declined (os.getenv, no-quote date notes, api_request argument order).",
   "Sonnet: not measured by default; if measured, P(two-task line passes) ≈ 39% regardless of this design.",
   "isRuleWide W false positive in either round blocks isRuleDrill (shared W2; 0 in 1.12.0 measured and 1.13.0 dev for haiku).",
   "Another 1.13.0 design touching checkPrompt/parseCheck, notePrompt, keptNoteText/ruleLabelled/ruleNamesOf or drillOf/hideDrillAnswer OFF paths would change measured bytes (D26) — must be ordered or re-pinned before this bar commit.",
   "Sonnet trace-refusal fact: no new prompt wording, so no new refusal risk (tier-2 and grading prompts unchanged; 0 refusals in 1.12.0 measured and 1.13.0 dev)."
  ],
  "perModel": {
   "haiku": "Measure. Dev records (B-12, 2 fresh sets, 75 notes; final cap re-read): every N1′ zero-tolerance line 0 (harmful 0, two-task 0 in both readings, traps 0/12, unlabelled 0, (c) 0, W FP 0), den 26 correct 24 = 92.3% (92.9% / 91.7%), tier-2 no-answer 0/19, refusals 0; mini-N2 28/29 and 30/30 with break→맞음 0, broken→맞음 0, missing 0, keep caps 0, pre-cap (break+broken)→맞음 1 and 1 (≤ 2). The 1.12.0 failing kind recurred twice on dev and the cap caught both. Pass odds ≈ 55–60% (risks: a broken sub-kind the cap cannot see graded 맞음, ≈ 10–20% per N2; a keep form the cap lowers, ≈ 5%; den margin).",
   "sonnet": "Do not measure in 1.13.0 (default). Dev numbers are at or above every line (den 41 correct 38 = 92.7%, every zero-tolerance line 0 over 75 notes, N2 29/30 twice, refusals 0) but the cap gives sonnet no measured benefit (sonnet alone made 0 break/broken→맞음 in 1.12.0 measured and 1.13.0 dev), and its only 1.12.0 failure, the two-task OFF reading of its shipped note call, is unchanged by this design: a round would re-roll the same failure line (P(pass that line) ≈ 39%, overall ≈ 30%). What would have to change: the owner decides the isRuleDrill two-task line counts only the ON (stored) reading (ownerQuestions[0] (a)), or explicitly accepts measuring at these odds (b), or a separate isRuleWide/note-call design for sonnet removes the self-correcting two-task note (its own D26 consequences)."
  },
  "ownerQuestions": [
   "0. 팀 규칙 연습(isRuleDrill)의 '할 일 줄 둘 = 0' 줄은 지금 켠 읽기와 끈 읽기를 모두 셉니다. 끈 읽기는 이미 켜져 나가는 isRuleWide sonnet의 노트 호출 그대로라 이 기능이 바꿀 수 없고, 1.12.0 sonnet은 그 한 줄(GD15)로만 못 넘었습니다. (a) isRuleDrill 기준에서는 켠 읽기(저장되는 글)만 세고 끈 읽기의 할 일 줄 둘은 isRuleWide 쪽 기록으로 옮길까요? 그러면 sonnet도 같은 견본으로 1.13.0에서 잽니다(기준 줄이 너그러워지는 것은 주인 결정으로만 가능). (b) 끈 읽기도 그대로 세되, 넘을 확률 약 30%를 알고 sonnet을 잴까요? (c) 기본값: 그대로 세고 sonnet은 1.13.0에서 재지 않습니다.",
   "1. N2를 '학습자에게 보이는 판정'(모델 판정 뒤 코드가 맞음을 거의로 낮춘 것)으로 세고, 대신 더 엄격한 줄 둘(지킴 답을 코드가 낮추면 못 넘음, 낮추기 전 어김 + 깨짐→맞음 ≤ 2)을 더하는 것을 1.13.0 기준으로 커밋해도 될까요? 기본값: 예(기준 표의 'gradeDrill이 매기는 대로'를 1.13.0 gradeDrill로 읽고, 입장 바꿈을 재기 전에 밝힘). '아니오'면 이 설계는 haiku의 1.12.0 실패를 고치지 못하므로 haiku도 재지 않습니다."
  ]
 },
 "plan_batch1": {
  "barSource": {
   "fields": "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G6.json: bar.source and bar.lines (incl. the STANCE line on N2 counting and the two NEW lines: keep caps = 0, pre-cap (break + broken)→맞음 ≤ 2, each run), bar.statedRisk, stance (intro, unchangedNote, changed, added E19–E32: the 1.12.0 stance 2f95fe1 re-committed word for word with the marked changes), decisionRule, samples, calls.",
   "summary": "haiku only, two rounds A and B on the same fresh frozen samples, every N1′ line in both: (a) O ≥ 20 and 0 practices on O notes; (b) den ≥ 20, correct ≥ 80% of den, harmful 0 over all answered notes, two-task 0 in the ON and OFF readings; (c) O-note prompt and final text byte-identical ON/OFF, no practice call for an O note; traps 0 of 9; R_long/F/N/trap no-line 0; unlabelled 0; tier-2 no-answer ≤ max(1, ⌊n/60⌋); old windows (seven builds incl. 30adc2f, NEW stricter) 0 bad; W gate 0 false positives in the OFF reading and keptNoteText idempotent; N2 both runs: correct ≥ 27/30, break→맞음 ≤ 1, broken→맞음 0, missing 규칙 ≤ 1, keep caps 0 (NEW, stricter), pre-cap (break+broken)→맞음 ≤ 2 (NEW). Together with the STANCE change, this pre-cap line relaxes 2f95fe1's model-verdict tolerance; it is declared, not called stricter.",
   "decision": "isRuleDrill_haiku = MODEL_SWITCHES.haiku.isRuleWide true at the bar commit ∧ W passes both rounds ∧ every N1′ line in A and B ∧ N2 passes both runs; else false. Sonnet not measured → stays false (no transfer). isRuleWide_m is not re-decided; a W false positive blocks isRuleDrill only.",
   "capNumbers": "note and tier-2 cap hit = output_tokens ≥ 3500 + H_haiku (= 5548 at 2048), N2 = 480 + H_haiku (= 2528 at 2048), written as numbers from the 보정 기록.",
   "quotedFrom": "docs/qa/견본.md '## 1.12.0 팀 규칙 연습 (G6)' > '#### 기준' and '#### 판정의 입장' (2f95fe1) with the 1.13.0 changes; the bar commit quotes all of it as '## 1.13.0 팀 규칙 연습 (G6): 코드도 채점을 보는 규칙 연습 (isRuleDrill) · haiku'.",
   "declaredDeviations": "Stated in the bar commit before any sample: (1) N2 counting moves to the learner-visible verdict (STANCE; owner question 16 default yes). This relaxes the model-verdict tolerance of 2f95fe1 ('broken 0, break ≤ 1' on the model's verdict) to 'break + broken ≤ 2 before the cap', with break ≤ 1 / broken 0 counted after the cap. It is an owner-decided relaxation at the grader level; the learner-visible lines are unchanged. (2) keep caps = 0 is the one stricter line. (3) The NEW old-window line with 30adc2f is stricter. (4) The writer layout is one set kind per call (samples.writers), an infrastructure change."
  },
  "samples": {
   "layout": "One fresh frozen set, the 1.12.0 composition word for word (85 + spares): R 40 (10 per rule; js 14 · ts 12 · py 14), R_long 4, F 12, N 12, traps 9 (rule module ×4 one per rule with py ≥ 1 and ts ≥ 1; tests ×2; build script ×1; a non-stem module exporting a use name ×1; a *.config.* file reading process.env ×1), multi 4, double 4; team file = the 1.10.0 one unchanged (4 rules + 용어 2); key §5. Written for both models in principle (the sonnet stage runs only if the owner answers ownerQuestions 15 (a)/(b) before the 1/4 first commit; see its note); haiku stage first.",
   "writers": "Fresh blind opus writers, ≤ 10 records per call and one set kind per call. The bar commit declares this as a writer-layout change from the design's 'R_long+F 2 … multi+double 1' (an infrastructure layout, not a bar line). R 4 calls of 10 (one rule each, language mix spread); R_long 4 (1 call); F 12 in 2 calls of 6; N 12 in 2 calls of 6; traps 9 (1 call); multi 4 (1 call); double 4 (1 call). One spare call per set kind (≤ 10 spares each; counts fixed in the bar commit) makes about 18 calls in all. Each writer sees only the team file, the module table, the sample JSON form, the 1.10.0 writing rules and the avoid113.py names list. Writers never see RULE_DRILL_SYSTEM, ruleDrillPrompt, ruleFixPlan, ruleGradeCap, notePrompt, RULE_CHECK, ruleLabelled, the design, the stance or which model is measured. Unmet count after spares: one pre-committed top-up call of that kind, then STOP (not measured, recorded).",
   "freezeChecks": "0 model calls, as 1.12.0: JSON reads; demo runs = expected; each violation's fix-run writes MORE stub records (strict S1, stdout frozen as expected_fixed); violation lines in after, hold a §5 marker, fix holds a use name and no marker; every marker line of a non-trap sample is a violation; R/multi/double ≤ 40 chars without indent, R_long ≥ 41; R/multi/double import the module; F/N/trap violations empty; a file path equal to any dev or earlier measured path in impl113/NAMES-all.txt or the extended corpora (commonPerBatch.freezeCheckInputs) is rejected. Failing samples replaced from the same group's spares in id order, never rewritten; replacement counts recorded. samples.json, team.md, key frozen (chmod 444, sha256, writer, UTC in 견본.md). Ids use a fresh prefix checked absent from NAMES-all.txt and 견본.md (proposed HA–HD).",
   "secondStage": "N2 for the haiku label from its round A: pick.py takes 5 correct practices (all 4 rules, py ≥ 1, ts ≥ 1; unfillable conditions dropped and recorded; < 5 correct → N2 fails). One fresh opus writer per picked practice: 10 answers per call (keep 2 · break 2 · broken 1 · off 1 + one spare per kind). This is the declared exception to 'one set kind per call': four answer kinds of one practice, 10 records, named with its count in the bar commit, seeing only the practice as gradeDrill shows it and the team file; n2verify runs them before freezing; spares fill, never rewritten.",
   "avoid": "avoid113.py output (calibration.avoidBuilder) from NAMES-all.txt when the stage starts: concept, file and code names of every G6 tag (G6-dev, G6-measured, G6-dev-113: E1A01–E1D10, E2A01–E2D10 and their file paths), of every other G's dev and measured record files, and the 견본.md name cells that pass the filter. check.py (NAMES_FILE = impl113/NAMES-all.txt) rejects a sample whose file path equals any path in the complete registry (commonPerBatch.freezeCheckInputs)."
  },
  "calls": {
   "perRound": "85 note calls (SYSTEM, notePrompt(screened, 'beginner', [], team) 1.8.0 bytes, maxTokens 3500, timeoutMs 90000) + ≈ 20 tier-2 calls (RULE_DRILL_SYSTEM, redactText(ruleDrillPrompt(…)).text, 3500, 90000); tier 1 and skips make no call.",
   "N2": "30 grading calls per run × 2 runs (CHECK_SYSTEM, checkPrompt(…{ rule }), 480, 60000, first try only); then parseCheck(text, { rule: true }) and the build tree's ruleGradeCap (no call).",
   "total": "haiku ≈ 170 note + ≈ 40 tier-2 + 60 N2 ≈ 270, plus taps for empty replies; sonnet 0 by default.",
   "stages": "Round A haiku (note + practice in one runner); round B haiku; nothing opened until A and B are saved and hashed; then N1′ judging; then N2 samples; N2 run 1 haiku; N2 run 2 haiku.",
   "how": "Exactly as the plugin (D20): probe mod copy calling $.model.complete({ model: 'haiku', effort: 'low', system, prompt: redactText(prompt).text, maxTokens, timeoutMs }), 4 at a time, $.clock timing, replies through fixEscapedTicks; prompts built by importing the committed tree's notes.ts with haiku's row + isRuleDrill true (M-13: the haiku row also holds rungChangedStep 2, which no G6 call reads).",
   "retries": "Empty, cap hit, timeout never re-sent. API errors recorded, not re-sent (G6 §2); M-4 10% rule; every empty reply tapped once (record).",
   "D34": "Per sample, from the build tree's test harness (beginner, model 'haiku', harness row turning isRuleDrill + isRuleWide on; and with no harness): the note request, every tier-2 request (tier-1/skip notes show no second request), and after the N2 freeze every N2 grading request, byte-compared with the tool lines; the no-harness capture holds the note request only."
  },
  "judges": "Per label: the frozen machine judge (rebuilt from /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1/tools/judge.py + key.py with the 1.13.0 stance additions E19ff, hashed at the bar commit, re-checked line by line against the committed stance) plus one fresh opus row checker that sees only that label (D7); a judge/checker split counts against (M-9). N2: machine count incl. the pre-cap verdict and the cap reason per item, plus one fresh opus checker.",
  "stop": [
   "Condition (a) → batch skipped whole (recorded in batch 0).",
   "isRuleWide or G2 haiku D26 difference on the build tree → fix before the build commit; if it cannot be made identical, stop and report.",
   "Round void (M-10) or M-4 → isRuleDrill haiku OFF, not re-measured.",
   "Fewer than 5 correct practices in round A → N2 fails (counted).",
   "W false positive in the OFF reading → blocks isRuleDrill haiku only; isRuleWide unchanged (recorded).",
   "Writer refused twice on one call (refusal as commonPerBatch.writerRunner defines it; a usage-limit ending is WAIT) → STOP, not measured (recorded)."
  ],
  "models": [
   "haiku (only if calibration condition (a) holds: H_haiku = 2048)"
  ],
  "notMeasured": [
   "sonnet (ownerQuestions 15 default (c), settled before batch 0's first commit; recorded in batch 0)"
  ]
 }
}
```

## 1.12.0 입장 원문 (견본.md 30adc2f, '#### 판정의 입장'부터 '#### 결정 규칙' 앞까지)

#### 판정의 입장

설계의 입장(stance) 글입니다. '공통'의 다섯 항목, 확인 줄(S-a), 견본(S-c), 판정 대상(S-b), 경계 꼴 E1 ~ E18, N2 입장을 설계 글자 그대로 옮겼습니다. 판정은 이 글자대로만 셉니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 '다시 잴 때'에 적습니다(M-11).

공통 (1.10.0 입장 §0–§15와 세부 1–24를 그대로 다시 커밋하고, 아래만 바꾸거나 더함)
- §0 · §15 그대로: 판정 스크립트를 이 글대로 먼저 짓고 sha256을 바 커밋에 적습니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 견본.md '다시 잴 때'에 적습니다. 판정 파일을 쓴 뒤에는 입장 · 열쇠 · 기준을 바꾸지 않습니다.
- §1 (바꿈) 켠 읽기: 노트 답 → fixEscapedTicks → keptNoteText(답, names) → noteRuleOf가 읽히면 그 판 트리의 ruleFixPlan(screened, rules, 그 줄). 1단이면 ruleFixMade(글, fix, changes) ?? 글, 2단이면 RULE_DRILL_SYSTEM · redactText(ruleDrillPrompt(screened, rules, 그 줄, cands)) · 3500 · 90000으로 부르고 fixEscapedTicks → ruleFixReply가 받은 글 ?? 글, 건너뜀이면 글 그대로. 끈 읽기: 같은 노트 답의 keptNoteText 글 그대로.
- §2 그대로: 노트 호출이 답하지 않은 견본은 그 회 L · O에서 빼고 수만 적습니다. 규칙 연습 호출의 상한 닿음 · 빈 답(API 거절 포함) · 시간 한도는 '답 없음' 줄에 셉니다(n = 그 모델 두 회의 2단 호출 수). 닿았어도 글이 읽히면 읽힌 대로 매깁니다. 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.12.0 보정).
- §3 · §4 · §5 · §6 · §8 · §9 · §10 · §11 · §12 · §13 그대로(채점 열쇠 §5는 같은 팀 파일에서 나온 그대로).
- §14 (더함, 엄격하게): 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988에 3d2f251 · de98243을 더한 여섯입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.

확인 줄 (S-a, §7에 더함)
- 켠 판의 확인 줄은 코드가 쓴 '고친 줄이 돌 때 `U` 쪽을 거칩니다' 하나뿐입니다. 세부 6: 코드 칸에 호출이 없으므로 견본 demo를 돌립니다. 세부 8: 쓰라는 이름 하나만 든 코드 칸은 값이 아닙니다. 세부 10: 효과 말이며 U의 규칙이 그 규칙입니다.
- 효과 주장은 줄 단위로 매깁니다: 그 줄만 예시 답으로 바꾼 파일로 demo를 돌린 기록에 그 규칙 대역 줄(`[apiRequest] ` · `[log.info] ` · `[toDateText] ` · `[config] `로 시작)이, 원래 줄 그대로 돌린 기록보다 많아야 참입니다(파일이 다른 줄에서 이미 대역을 부르는 경우를 가름). 같으면 거짓입니다.
- 확인 줄이 이 꼴이 아닌 규칙 연습(켠 창에서 읽히지 않으므로 나올 수 없음)이 나오면 1.10.0 §7 그대로 매깁니다.

견본 (S-c)
- 얼리기 전: violations마다 fix로 바꾼 demo가 원래 demo보다 그 규칙 대역 줄을 더 많이 써야 합니다(엄격한 S1). 못 넘은 견본은 같은 무리 예비로 id 차례대로 채우고 고쳐 쓰지 않으며, 바뀐 수를 견본.md에 무리마다 적습니다(모집단 기록). 개발 견본 1–4의 짧은 어긴 줄 92개에서는 0개였습니다.
- F 견본에서 표지 글자가 문자열 글자나 주석 안에만 있는 줄은 어긴 줄이 아닙니다(F의 정해진 꼴). 그 줄에 규칙 연습이 나오면 h2(해로움)입니다.

판정 대상 (S-b)
- 연습은 저장된 노트 글로만 매깁니다. 1단(코드가 만든 예시 답)이든 2단(모델이 준 예시 답)이든 같은 §6 · §10을 씁니다. 1단이라고 덜 보지 않습니다.
- 갈래 · 건너뜀 까닭 · 2단 잘못 코드는 기록만 하고 판정에 쓰지 않습니다(S-d).

옛 기록과 개발 답에서 나온 경계 꼴 (미리 정함)
- E1 인자를 바꾼 예시 답(`toDateText(e.endsAt)`, 줄은 `d.toLocaleDateString('en-CA')`): 표지가 없고 쓰라는 이름이 있으면 (iv)의 출력 비교가 정합니다. 출력이 expected_fixed와 같으면 바름, 다르면 바르지 않음(해롭지 않음).
- E2 결과에 사슬을 남긴 예시 답(`toDateText(end).slice(0, 10)`): 남은 것이 §5 표지가 아니면 h3가 아니고 (iv) 출력이 정합니다. `.slice(0, 4)`처럼 출력이 바뀌면 바르지 않음(1.12.0 개발 D1A14).
- E3 감싼 예시 답(`toDateText(end.toJSON())`)과 옆에 남긴 예시 답(`toDateText(d) || d.toISOString()`): 표지가 남으므로 h3. 코드가 막으므로 나오면 코드 결함이며 해로움으로 셉니다.
- E4 multi: 어느 violations 줄이든 짚은 규칙의 줄이면 바를 수 있습니다. 다른 규칙의 줄이면 (ii)나 (iii)에서 바르지 않고, 들인 규칙의 violations 줄이 아니면 h2입니다.
- E5 double(같은 규칙 둘): 둘 가운데 어느 줄이든 됩니다. 다른 한 줄의 표지가 파일에 남는 것은 예시 답의 표지가 아니므로 h3가 아니고, (iv)는 그 violation의 expected_fixed로 견줍니다.
- E6 `config["X"]` · `config.get("X")` · `Number(config.X)`: 쓰라는 이름 config를 품으므로 지킴입니다(§8 대역이 모두 받침). 확인 줄의 U는 `config`입니다.
- E7 os.getenv 줄(규칙 글이 이름 짓지 않은 표지): 코드가 후보로 올리지 않아 연습 없음이면 den의 바르지 않음이고 해롭지 않습니다. 연습이 나오면 보통처럼 매깁니다.
- E8 2단 답이 스스로 고쳐 쓴 꼴(같은 라벨에 다른 값, 'Wait —'): 코드가 받지 않아 연습 없음입니다. 판정은 저장된 글만 봅니다.
- E9 노트 호출이 스스로 고쳐 쓴 꼴로 직접 해 보기 칸에 할 일 줄이 둘(1.12.0 개발 D4B02 · D4B21, 끈 읽기): §13대로 할 일 줄 둘인 노트로 셉니다(두 읽기 모두, 답한 모든 노트). 이 설계가 바꿀 수 없는 끈 읽기의 일이어도 기준 줄은 그대로입니다.
- E10 노트 호출이 상한에 닿았지만 답한 경우(개발 D3B11 haiku 5548): 읽힌 대로 매기고 상한 닿음은 노트 호출 쪽 기록입니다(규칙 연습 '답 없음' 줄은 2단 호출만 셈).
- E11 켠 창에서 W2가 표지를 단 자기 칸(코드가 만들지 않은 규칙 연습): 켠 읽기에서 연습 없음입니다. 그 노트가 den이면 바르지 않음, 표지 없는 규칙 연습(§9)도 아님(개념 연습이 아니므로). 끈 읽기의 W 오탐(§11)은 그대로 셉니다.
- E12 1단이 만든 연습이 demo가 지나지 않는 줄에 있음: (v) · (vi)에서 거짓(효과 기록이 늘지 않음). 엄격한 S1이 견본의 열쇠 줄을 보장하므로 열쇠 줄이 아니면 (iii)에서 이미 바르지 않음입니다.
- E13 1단 이름 바꿈이 같은 줄의 쓰지 말라는 다른 이름을 남김: 코드가 막음. 나오면 h3.
- E14 확인 줄 U가 예시 답의 가장 짧은 쓰라는 이름(`config`)이고 예시 답은 `config.API_URL`: 효과 말 config로 매깁니다.
- E15 규칙 연습 호출 답이 `- 줄: 없음`이고 그 노트가 den: 연습 없음 → 바르지 않음, 해롭지 않음.
- E16 N2: 학습자 줄이 예시 답과 같거나 고칠 줄과 같으면 gradeDrill이 부르지 않으므로 n2verify가 뺍니다(세부 22). 판정 셈은 세부 23 그대로.
- E17 노트 글의 `다를 수 있음` 줄이 규칙 이름을 하나도 품지 않음(코드는 건너뜀): 연습 없음. den이면 바르지 않음.
- E18 sonnet API 거절(stop_reason refusal): 빈 답으로 '답 없음'에 셉니다. 탭 기록은 따로 적는 기록입니다.

N2 입장
- 1.9.0 · 1.10.0 N2 입장 그대로(세부 22 · 23). 문제 글의 할 일 · 확인 줄은 코드가 쓴 것이며, 채점 프롬프트의 나머지 바이트는 1.9.0과 같습니다(rule19 고정, 만든 연습의 채점 요청 고정 시험 추가).

다시 커밋하는 1.10.0 입장 §0 ~ §15 (432ced4 글 그대로; 바꾼 곳은 ~~ ~~와 1.12.0 글)

§0 커밋과 스크립트
- 판정 스크립트(저장소 밖)를 이 입장대로 먼저 쓰고, 그 sha256을 이 커밋에 적습니다.
- 출력을 본 뒤 스크립트가 이 글과 다르게 센 것이 드러나면 글대로 다시 세고 스크립트 diff를 견본.md에 남깁니다. 글(입장 · 열쇠 · 기준)은 바꾸지 않습니다.

§1 부르기와 읽기는 플러그인과 같습니다 (1.12.0에서 바꿈: 켠 읽기 한 줄)
- 팀 파일은 그 판 트리의 parseTeamFile로 읽습니다. names = ruleNamesOf(team.rules)(잰 모델의 isRuleWide를 켠 상태).
- 노트: SYSTEM, notePrompt(screened, 'beginner', [], team), maxTokens NOTE_TOKENS(3500).
- 노트 답: fixEscapedTicks → keptNoteText(답, names).
- ~~켠 읽기: noteRuleOf가 읽히면 RULE_DRILL_SYSTEM · ruleDrillPrompt(screened, team.rules, 그 줄), maxTokens RULE_DRILL_TOKENS(3500)로 부르고, fixEscapedTicks → withRuleDrill(글, 답, changes, names) ?? 글.~~
- 켠 읽기(1.12.0): 노트 답 → fixEscapedTicks → keptNoteText(답, names) → noteRuleOf가 읽히면 그 판 트리의 ruleFixPlan(screened, rules, 그 줄). 1단이면 ruleFixMade(글, fix, changes) ?? 글, 2단이면 RULE_DRILL_SYSTEM · redactText(ruleDrillPrompt(screened, rules, 그 줄, cands)) · 3500 · 90000으로 부르고 fixEscapedTicks → ruleFixReply가 받은 글 ?? 글, 건너뜀이면 글 그대로.
- 끈 읽기: 같은 노트 답의 keptNoteText 글 그대로.
- 두 호출 모두 redactText, effort low, timeoutMs 90000이고, 그 판 notes.ts 사본의 함수를 그대로 부릅니다.

§2 답이 없거나 상한에 닿은 답
- 노트 호출이 답하지 않으면(빈 답 · 시간 한도 · 오류) 그 견본은 그 회의 L · O에 넣지 않고 수만 적습니다. 그래서 den이 20 아래면 (b), O가 20 아래면 (a)가 못 넘음입니다.
- 규칙 연습 호출이 답하지 않으면 그 노트는 자기 칸 그대로(플러그인과 같음)이고, 그 꼴대로 매깁니다. 상한 닿음 · 빈 답 · 시간 한도는 '답 없음' 줄에 셉니다. API 오류는 수를 적고 다시 부르지 않습니다.
- 상한 닿음은 output_tokens ≥ maxTokens + H_M입니다(계획 고침 D4, M-5: G6의 상한 몫 = H_M, ~~haiku 2048 · sonnet 0, 묶음 1 보정 기록~~ 1.12.0 보정 기록의 haiku 2048 · sonnet 2048). 닿았어도 글이 읽히면 읽힌 대로 매깁니다.
- (1.12.0, 설계 §2를 옮김) 노트 호출이 답하지 않은 견본은 그 회 L · O에서 빼고 수만 적습니다. 규칙 연습 호출의 상한 닿음 · 빈 답(API 거절 포함) · 시간 한도는 '답 없음' 줄에 셉니다(n = 그 모델 두 회의 2단 호출 수). 닿았어도 글이 읽히면 읽힌 대로 매깁니다. 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.12.0 보정).

§3 L과 O
- 노트 답의 keptNoteText 글에서 noteRuleOf(연습 제목 앞, 제목이 없으면 글 전체)가 `팀 규칙과 다를 수 있음:` 줄(없음 아님)을 읽으면 L, 아니면 O입니다. 한 번 정해 켠 읽기와 끈 읽기에 함께 씁니다.
- `팀 규칙:` 줄만 있으면 O입니다.
- den = L 가운데 그 견본의 violations에 들여쓰기 빼고 40자 이하인 줄이 하나라도 있는 노트.

§4 연습의 종류
- 최종 글(켠 읽기는 withRuleDrill 뒤, 끈 읽기는 keptNoteText 글)에 drillOf(글, changes, 그 읽기의 켬 여부)를 돌립니다.
- rule을 주면 규칙 연습, rule 없이 주면 개념 연습, undefined면 연습 없음입니다.

§5 채점 열쇠 (팀 파일에서 나오며 함께 얼림)
| 규칙 | 쓰라는 이름 | 쓰지 말라는 표지 | 낱말 |
| --- | --- | --- | --- |
| 요청 | apiRequest · api_request | fetch( · requests. | 요청 · API · 서버 |
| 기록 | log.info | console.log · print( | 기록 · 로그 |
| 날짜 | toDateText · to_date_text | toISOString · toJSON · toLocaleDateString · toDateString · getFullYear · getMonth · getDate · getUTCFullYear · getUTCMonth · getUTCDate · strftime · isoformat | 날짜 |
| 설정 | config | process.env · os.environ · os.getenv | 설정 · 환경 변수 |
- 이름과 표지는 holdsName처럼 온전한 이름으로 찾습니다(`fetch(`는 `fetch` 뒤에 공백 없이 여는 괄호, `fetcher(` 안이 아님).
- 들인 규칙: 예시 답이 고칠 줄에는 없는 그 규칙의 쓰라는 이름을 품는 규칙들.
- 짚은 규칙: 노트의 `다를 수 있음` 줄 글에 그 규칙의 쓰라는 이름이나 표지가 있는 규칙들. 하나도 없으면 낱말이 있는 규칙들. 그것도 없으면 없음입니다.

§6 바름 (모두 맞아야 함. 다음을 모두 만족하는 규칙 r이 있어야 함)
- (i) 규칙 연습입니다.
- (ii) r이 들인 규칙이고 짚은 규칙입니다.
- (iii) 고칠 줄이 r의 violations 줄입니다(같은 파일, 공백 · 끝 `;` · `,` 빼고 같음).
- (iv) 예시 답이 r을 지킵니다: r의 쓰라는 이름을 품고, r의 표지가 남지 않으며, 그 줄만 예시 답으로 바꾼 파일의 demo 표준 출력(두 번)이 그 violation의 expected_fixed와 §7 정규화로 같습니다. 규칙과 상관없는 부분을 바꿔 출력이 달라지면 지키지 않음입니다.
- (v) 그 파일이 두 번 모두 오류 없이 돕니다. 원래 파일은 얼리기 전에 대역에서 돈다는 것이 확인되었으므로, 오류는 예시 답 탓으로 셉니다(정의되지 않은 이름 · import 없는 이름 포함).
- (vi) 확인 줄이 있고 그 주장이 §7로 참입니다.

§7 확인 줄
- 돌리는 것: 확인 줄 백틱 안의 첫 호출이 바꾼 파일에 정의된 함수를 부르면 그 호출을 돌립니다. 자리표시(`…` · `[A]` · `<…>`)이거나 말로만 쓴 확인이면 견본의 demo를 돌립니다.
- 변경의 파일에 없는 함수를 부르면 거짓입니다(1.9.0 G15). 확인 줄이 없으면 거짓입니다(A01).
- 돌린 결과 = 호출 값(await한 값) · 표준 출력 줄 · 대역 기록 줄(표준 출력과 따로 모음, §8).
- 주장의 꼴
  - (1) 값(백틱 · 따옴표 안, 또는 수): 정규화한 값이 호출 값과 같거나, 표준 출력이나 기록의 한 줄과 같아야 합니다. 값이 여럿이면 모두입니다(1.9.0 C18).
  - (2) 같음 말('같은 · 그대로 · 똑같이 · 변함없이 · 달라지지 않')만 있으면: 호출 값과 표준 출력이 원래 줄로 돌린 것과 같아야 합니다.
  - (3) 효과 말(그 규칙의 쓰라는 이름, '기록 · 로그가 남', '인증 · 재시도', '설정에서 읽', '날짜 글자로'): 기록 줄에 그 규칙 함수가 그 호출 동안 불린 줄이 있어야 합니다.
  - (4) 섞이면 각 부분이 다 맞아야 합니다.
  - (5) '…라고 가정 · …이면' 같은 조건: 견본 env · responses로 돌린 결과로만 매깁니다. 견본이 그 조건을 주지 않으면 거짓입니다.
  - (6) 그 밖의 꼴(값 · 같음 말 · 효과 말이 없음)은 거짓입니다.
- 정규화: 앞뒤 공백을 떼고 공백을 하나로 줄이며, `'`를 `"`로, 끝 `;`를 뗍니다. 둘 다 JSON으로 읽히면 값으로 견주고, 수는 값으로, 파이썬 True · False · None은 true · false · null로 봅니다.
- 줄인 출력: 말한 값이 맞으면 맞음이고, 말한 값이 하나라도 틀리면 거짓입니다.
- 날짜는 TZ=UTC입니다.

§8 대역과 돌리기
- 팀 모듈 넷(js · ts · py)을 둡니다. apiRequest · api_request, 미리 심은 globalThis.fetch, requests.get이 견본 responses로 같은 응답을 줍니다.
- config와 환경 변수는 견본 env로 같은 글자를 줍니다(`config.X` · `config["X"]` · `config.get("X")` 모두). log.info는 console.log · print와 같은 글을 표준 출력에 찍습니다. toDateText는 UTC YYYY-MM-DD를 줍니다.
- 대역은 불릴 때마다 `[apiRequest] 주소` · `[log.info] 인자` · `[config] 이름` · `[toDateText] 값`을 표준 출력이 아닌 기록 파일에 씁니다.
- 빈 임시 폴더에서 `unshare -n timeout 5`, js `node`, ts `node --experimental-transform-types`, py `python3 -I`로 돌립니다. 파일에 import를 덧붙이지 않습니다. 호출 값은 돌리는 틀이 사본 끝에 붙인 한 줄이 `[value] JSON`으로 찍습니다. (계획 고침 D14: py는 B-14대로 `env -i PATH LANG=C.UTF-8 PYTHONHASHSEED=<n> python3 -s -P -B`를 n = 1~5로 다섯 번 돌려 다섯이 모두 같아야 하고, ts 실행은 B-15의 `node --experimental-transform-types`입니다.)
- 구문 오류 = 바꾼 파일을 불러올 때 SyntaxError(파이썬은 py_compile 실패).
- 돌지 않는 연습(대역이 받치지 못한 경우 포함)은 (v)나 (vi)에서 거짓입니다. 읽어서 매기는 갈래는 없습니다.

§9 표지 없는 규칙 연습
- 개념 연습 가운데, 예시 답이 어떤 규칙의 쓰라는 이름을 고칠 줄에 없이 품는 것입니다.
- 할 일 글은 보지 않습니다. 할 일이 팀을 말하지만 이름을 들이지 않는 연습(1.9.0 G19 꼴)은 개념 연습입니다.
- 켠 읽기와 끈 읽기에서 모두 셉니다.

§10 해로움 (규칙 연습인데 다음 가운데 하나)
- (h1) 들인 규칙이 없음(규칙이 아닌 일을 시킴)
- (h2) 고칠 줄이 들인 규칙 어느 것의 violations 줄도 아님(헛짚은 L · 함정 · R_long에서 낸 규칙 연습 포함)
- (h3) 예시 답에 들인 규칙의 표지가 남음(거꾸로 바꿈 포함)
- (h4) 바꾼 파일에 구문 오류
- 확인 줄만 거짓이거나 (ii) · (iv)의 출력만 다른 것은 바르지 않음이지 해로움이 아닙니다.

§11 W 오탐
- 끈 읽기에서 HEAD fca5988의 ruleLabelled 글과 keptNoteText 글이 다른 노트를 봅니다.
- 그 노트의 연습(HEAD 글을 drillOf(…, false)로 읽은 것)이 다음을 모두 만족하지 않으면 오탐입니다: 고칠 줄이 어떤 규칙 r의 violations 줄이고, 예시 답이 r의 쓰라는 이름을 고칠 줄에 없이 품습니다.
- HEAD 글에서 연습이 읽히지 않던 노트(연습 없음)에 표지가 붙은 것은 오탐이 아닙니다.

§12 (c): O 노트마다 켠 읽기와 끈 읽기의 최종 글을 바이트로 견주고, 켠 회의 호출 기록에 O 노트의 규칙 연습 호출이 없는지 봅니다.

§13 할 일 줄 둘: 최종 노트의 직접 해 보기 칸(합친 칸 포함)에 할 일 줄이 둘 이상인 경우입니다.

§14 옛 창: 3f2b4fb · 7a7b08c · 3690021 · fca5988의 notes.ts 사본(꺼진 상수 그대로)으로 모든 회의 켠 · 끈 최종 글에 drillOf · hideDrillAnswer를 돌립니다.
- (1.12.0에서 더함, 엄격하게) 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988에 3d2f251 · de98243을 더한 여섯입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.

§15 판정 파일
- 스크립트가 행마다 근거(돌린 출력 · 들인 규칙 · 짚은 규칙 · 맞춘 주장 꼴)를 verdicts-<꼬리표>-<회>.md에 먼저 쓰고, 표는 그 파일만 셉니다. (계획 고침 D7: 꼬리표마다 따로 돌려 얼리고, N2는 verdicts-<꼬리표>-n2.md. 모든 판정 파일이 얼려진 뒤 짝 파일을 엽니다.)
- 판정 파일을 쓴 뒤에는 입장 · 열쇠 · 기준을 바꾸지 않습니다.
- 이 글이 정하지 않은 꼴이 나오면 넘는 쪽에 불리하게(바르지 않음 · 해로움 · 오탐 · 표지 없는 규칙 연습) 세고, 그 꼴을 견본.md에 적습니다.
- 기록만 하는 것(판정에 넣지 않음): 할 일이 라벨 설명을 옮겨 적었거나 어느 줄을 어떻게 고칠지 말한 것, 1.9.0 정의의 (b), L 노트가 개념 연습을 규칙 연습으로 바꾼 수, 규칙 연습 호출의 출력 토큰 · 시간.

N2 입장: 1.9.0 N2와 같습니다. 얼린 기대 판정과 견주고, parseCheck(text, { rule: true }) 뒤 '안 지킴 + 맞음 → 거의' 낮추기를 거친 판정으로 셉니다. 바른 판정은 지키고 동작함 → 맞음, 어겼지만 동작함 → 거의 또는 틀림, 깨짐 → 틀림 또는 거의, 엉뚱함 → 틀림입니다.

읽는 법(1.10.0 글의 이름을 1.12.0에서 읽는 자리; 글은 바꾸지 않음)
- §4 '켠 읽기는 withRuleDrill 뒤': 1.12.0에는 withRuleDrill이 없습니다(a4ac818에서 지움). 켠 읽기의 최종 글은 §1의 1.12.0 켠 읽기 글입니다(설계 '공통' §1).
- §11 · 세부 15의 'HEAD fca5988': 1.10.0 때의 말 그대로 fca5988(1.9.0)의 ruleLabelled · drillOf입니다.
- '그 판 트리': 짓기 커밋 a4ac818의 트리(`impl112/b1/mtree`, git archive)입니다.
- 1.10.0 글의 '2단 견본'(N2)은 둘째 스테이지 견본입니다. 1.12.0 글의 '1단' · '2단'(코드가 만든 고침 · 연습 호출)과 다릅니다.
- 세부 21의 '못 넘음 → 넘음이면 새 하위 에이전트가 … 확인해야 그 수를 씀': 1.12.0에서는 결정 규칙 5('못 넘음이 켬으로 바뀌지 않음')와 계획 judges(판정자와 확인자가 갈리면 넘는 쪽에 불리하게, M-9)를 따릅니다. 확인자가 적은 행은 넘는 쪽에 불리하게 세고, 도구 결함을 고쳐 다시 센 수가 못 넘음을 넘음으로 바꾸면 그 수를 쓰지 않고 못 넘음으로 둡니다(더 엄한 쪽).
- 세부 20의 label.py · count.py · route.py, 세부 22의 n2verify.py, 세부 23의 n2judge.mjs, 세부 12의 runlib: 아래 '틀과 도구' 표의 1.12.0 도구입니다. N2 요청을 꼬리표의 모델로 보내는 일은 route.py 대신 `tools/n2build.mjs lines`가 짝 파일을 읽어 하고 짝을 찍지 않습니다.

다시 커밋하는 1.10.0 세부 1 ~ 24 (판정 스크립트가 정한 세부, 432ced4 글 그대로; 바꾼 곳은 ~~ ~~와 1.12.0 글)

1. §5 찾기: 쓰라는 이름은 holdsName 그대로 찾습니다(바로 앞이 글자 · 숫자 · `_` · `$` · `.`이 아니고 바로 뒤가 글자 · 숫자 · `_` · `$`가 아님). 표지도 온전한 이름으로 찾되 바로 앞의 `.`은 됩니다(열쇠의 날짜 표지는 `d.toISOString()`처럼 메서드라서). `(` · `.`로 끝나는 표지(`fetch(` · `print(` · `requests.`)는 그 글자가 이름 바로 뒤에 와야 합니다. 낱말은 글자 그대로 들어 있으면 찾은 것이고, `API`는 대소문자를 가리지 않습니다.
2. §5 짚은 규칙: 노트의 `다를 수 있음` 줄(규칙 연습이 든 rule 줄, noteRuleOf가 읽은 것) 글에서 찾습니다.
3. §6 (iii) 같은 파일: drillOf가 준 file(저장소 기준 경로)과 violations의 file이 같고, 두 줄에서 공백을 모두 빼고 끝 `;` · `,`를 뗀 글이 같음.
4. §6 (iv) · (v) 돌리기: 그 연습 줄(drillOf의 n행, 들여쓰기 그대로)만 예시 답으로 바꾼 파일들로 견본 demo를 첫 파일 끝에서 돌립니다. js · ts 두 번, py 다섯 번(B-14)이 종료 코드 · 표준 출력 · 기록 줄 모두 같아야 하고 종료 코드 0이어야 합니다. 표준 출력은 줄마다(빈 줄 빼고) §7 정규화로 expected_fixed와 견주고, 줄 수도 같아야 합니다. 돌리는 틀이 찍는 `[value] …` 줄도 출력에 듭니다(expected · expected_fixed도 그 줄을 품음).
5. 오류: 종료 코드가 0이 아님(시간 한도 124 포함).
6. §7 첫 호출: 확인 줄의 코드 칸(`` ` `` · `` `` ``) 가운데 `이름(`이 처음 나오는 칸에서, 그 이름부터 짝 괄호까지(앞의 `await`는 뗌). 그 호출이 자리표시(`…` · `...` · `[A]` 꼴 · `<…>`)를 품거나 코드 칸에 호출이 없으면 견본 demo를 돌립니다. 호출한 이름이 바꾼 파일의 맨 위 수준에 정의되어 있으면(js · ts의 function · const · let · var · class, py의 def · class · 이름 =) 그 호출을 바꾼 파일 끝에서 돌리고, 아니면(팀 모듈 · 내장 함수 · 변경의 다른 파일에 있는 함수 포함) 거짓입니다(§7 둘째 줄, 다른 파일의 함수는 글이 정하지 않아 §15).
7. §7 주장: 확인 줄에서 처음 나오는 `→`(또는 `->` · `=>`) 뒤의 글. 화살표가 없으면 확인 줄에서 그 호출의 코드 칸을 뺀 글.
8. §7 (1) 값: 주장 안의 코드 칸(규칙의 쓰라는 이름이나 표지 하나만 든 칸은 빼고), 따옴표(`"` · `'` · `“”` · `‘’` · `「」`) 안의 글, 수(앞뒤에 ASCII 글자 · 숫자 · `_` · `.` · `-`가 붙지 않은 것: `3개`의 3은 수, `2026-10-22`는 수가 아님). 값마다 호출 값(JSON으로 읽히면 값으로, 아니면 글자열 값의 글자나 JSON 글과), 표준 출력의 한 줄(돌리는 틀의 `[value]` 줄 빼고), 기록의 한 줄(`[apiRequest] …` 꼴 그 줄 전체) 가운데 하나와 §7 정규화로 같아야 합니다. 조건(§7 (5))의 값도 값으로 셉니다(조건을 기계로 가르는 글이 없어 §15).
9. §7 (2) 같음 말: 코드 칸 · 따옴표 밖의 글에 `같은` · `그대로` · `똑같이` · `변함없이` · `달라지지 않`이 있으면, 같은 호출을 원래 파일(견본 after)로 돌려 호출 값(§7 정규화)과 표준 출력(줄마다)이 같아야 합니다. 둘 다 오류 없이 돌아야 합니다.
10. §7 (3) 효과 말: 코드 칸 · 따옴표 밖의 글에 그 규칙의 쓰라는 이름이 있거나 쓰라는 이름 하나만 든 코드 칸이 있음, 또는 `(기록|로그)…남` → 기록, `인증` · `재시도` → 요청, `설정에서 읽` → 설정, `날짜 글자로` → 날짜. 말한 규칙마다 그 호출의 기록 줄에 그 대역의 줄(`[apiRequest] ` · `[log.info] ` · `[toDateText] ` · `[config] `로 시작)이 있어야 합니다.
11. §7 (4) · (6): 값 · 같음 말 · 효과 말 가운데 있는 것이 모두 맞아야 참이고, 하나도 없으면 거짓입니다. 확인 호출도 js · ts 두 번, py 다섯 번이 모두 같아야 하며, 다르면 거짓입니다.
12. §8 틀: 빈 임시 폴더에 대역(아래 runlib)과 견본 파일(같은 경로면 견본 파일이 대역을 갈음)을 두고, `unshare -n timeout 5 env -i PATH=… LANG=C.UTF-8 TZ=UTC <견본 env>`로 돌립니다(py는 PYTHONHASHSEED=1~5를 더하고 `python3 -s -P -B`로 폴더 맨 위의 실행 파일을 돌려, 그 파일이 폴더를 sys.path에 넣고 모듈을 run_name `__learnrun__`로 돌림. 그래서 `if __name__ == "__main__":` 아래는 돌지 않음). js · ts는 `node`(ts는 `--experimental-transform-types`)에 `--import`로 미리 심은 globalThis.fetch(견본 responses, 기록 없음)를 둡니다. 호출 값 줄은 js · ts `console.log('[value] ' + (JSON.stringify(await (호출)) ?? 'null'))`, py `print('[value] ' + __import__('json').dumps((호출), ensure_ascii=False, default=str))`이고(파일에 import 문을 더하지 않음), 응답은 주소가 품은 첫 키의 값(상태 200), 맞는 키가 없으면 404와 `{}`입니다.
13. §8 구문 오류: js · ts는 바꾼 파일을 그것 하나만 진입점으로 불러(호출 없이) 종료 코드가 0이 아니고 stderr에 `SyntaxError`가 있음(node `--check`는 ts를 검사하지 않음), py는 py_compile이 실패함.
14. §9: 켠 읽기와 끈 읽기의 개념 연습마다, §5 '들인 규칙'이 하나라도 있으면 셉니다.
15. §11: fca5988의 조합 `ruleLabelled(closeConceptBold(cut(답, 9000)))`(= keptNoteText(답, []), 시험으로 고정)과 keptNoteText(답, names)가 다른 노트에서, fca5988 글을 fca5988의 drillOf(…, false)로 읽은 연습을 봅니다.
16. §13: 직접 해 보기 칸(제목에서 다음 제목까지, ruleLabelled가 칸을 가르는 그대로)마다 taskLineOf가 읽는 할 일 줄을 셉니다. 한 칸이라도 둘 이상이면 셉니다. 켠 읽기 · 끈 읽기 모두, 답한 모든 노트에서 셉니다(B-6).
17. (b)의 '해로운 연습 0' · '할 일 줄 둘인 노트 0'은 den만이 아니라 그 회의 답한 모든 노트에서 셉니다(B-6). '바른 규칙 연습 80%'는 den 노트의 켠 읽기 규칙 연습 가운데 바름 수 ÷ den입니다.
18. 규칙 연습 호출의 답 없음 줄: 두 회를 합친 규칙 연습 호출 n번 가운데 상한 닿음 · 빈 답 · 시간 한도인 것이 max(1, ⌊n / 60⌋)개 이하. 상한 닿음은 output_tokens ≥ maxTokens + H_M(~~haiku 2048 · sonnet 0~~ 1.12.0 보정: haiku 2048 · sonnet 2048, 곧 2단 호출 5548)이고, 답한 호출도 닿았으면 셉니다. (1.12.0) 규칙 연습 호출은 2단 호출이고(1단 · 건너뜀은 호출 없음), 빈 답은 API 거절을 포함합니다(E18).
19. §14: 표지 노트 = 최종 글에 `- 할 일 (팀 규칙):`로 시작하는 줄이 있는 노트. 옛 창 ~~넷~~ 여섯(1.12.0, §14)의 drillOf가 연습을 주지 않고, 그 창 패널이 부르는 꼴의 hideDrillAnswer 글에 `고칠 줄` · `예시 답` 라벨 줄이 없어야 합니다. 표지 없는 노트는 그 창의 drillOf가 ~~1.10.0의 그 읽기(켬 · 끔)~~ 3d2f251의 drillOf로 그 읽기(켬 · 끔)를 한 것(1.12.0, §14)과 같은 할 일 · 고칠 줄 · 예시 답 · 파일 · 행을 줘야 합니다. 켠 · 끈 최종 글 모두, ~~네~~ 여섯 창 모두입니다.
20. 꼬리표(M-8, 결정 D7): 회 A · B와 헷갈리지 않게 P · Q로 씁니다. 이 G의 모든 스테이지(N1′ 회 A · B와 N2)에 한 번 뽑은 짝을 쓰고(N2 견본이 그 꼬리표 회 A에서 나오므로), pair.json을 얼려 sha256만 적습니다. label.py가 꼬리표 파일에서 모델 이름 · 시간 · 토큰 · 상한을 빼고, 그 수는 count.py만 셉니다. N2 요청을 그 꼬리표의 모델로 보내는 일은 route.py가 짝 파일을 읽어 하고 짝을 찍지 않습니다. 부르는 쪽(이 묶음을 짓는 쪽)은 어느 모델을 부르는지 압니다. 그래서 두 모델의 그 스테이지 답이 얼려지기 전에는 답 글을 열지 않고(M-3), 판정은 스크립트가 꼬리표 파일로만 합니다.
21. 판정 파일 행 확인(설계 '사람은 스크립트가 입장 글대로 셌는지를 행마다 확인'): 꼬리표마다 새 하위 에이전트 하나(`claude -p --model opus --tools ''`, 그 꼬리표의 판정 파일과 이 절의 입장 · 세부만 받음, 한 하위 에이전트가 두 꼬리표를 보지 않음)가 글대로 세지 않은 행을 적습니다. 적힌 행이 있으면 M-15대로 합니다(글이 이김, 도구를 고쳐 두 꼬리표를 다시 세고 전후 수를 모두 적으며, 못 넘음 → 넘음이면 새 하위 에이전트가 '글을 옮긴 고침'임을 확인해야 그 수를 씀).
22. N2 대역 확인(n2verify.py, 결정 D8 (2)): gradeDrill이 부르지 않는 줄(빈 줄, sameLine으로 예시 답 · 고칠 줄과 같음, 한글 자판)은 못 넘음. 그 연습 줄만 답 줄로 바꾼 파일로 demo를 돌려(js · ts 두 번, py 다섯 번) 갈래마다: keep = 모두 같음 · 종료 0 · r의 쓰라는 이름 있음 · r의 표지 없음 · 출력이 예시 답의 출력과 같음, break = 모두 같음 · 종료 0 · (r의 표지 있음 또는 쓰라는 이름 없음), broken = 쓰라는 이름 있음 · (돌릴 때마다 다름 또는 종료가 0이 아님 또는 출력이 예시 답과 다름), off = 쓰라는 이름 없음 · (종료가 0이 아님 또는 출력이 예시 답과 다름). 못 넘은 본 답은 그 연습의 같은 갈래 예비가 넘으면 그것으로 채우고, 아니면 빼고 그 수를 적습니다(고쳐 쓰지 않음). 기대 판정: keep 맞음, break 거의 · 틀림, broken 틀림 · 거의, off 틀림(N2 입장).
23. N2 셈(n2judge.mjs): 답 없음 · 읽지 못한 답은 바른 판정이 아니고 `규칙:` 줄 빠짐으로도 셉니다(B-8). 회마다 바른 판정 27개 이상 · 어김(break)→맞음 1개 이하 · 깨짐(broken)→맞음 0 · `규칙:` 줄 빠짐 1개 이하, 두 번 모두 넘어야 N2 넘음.
24. 기록만 하는 것(판정에 넣지 않음): 1.9.0 정의의 (b)(L 전체를 분모로), L 노트가 개념 연습인 수 · 연습 없는 수, 할 일에 `한 문장으로` · `어느 줄을`이 든 규칙 연습 수(라벨 설명을 옮긴 꼴의 어림), 규칙 연습 호출 결과의 꼴, 호출마다의 output_tokens · 시간(count.py).


## 옮긴 글


## 1.13.0 팀 규칙 연습 (G6): 코드도 채점을 보는 규칙 연습 (isRuleDrill) · haiku

### 짓기 (haiku, 끔; 2/4 짓기 커밋 fabef5d)

설계 G6(1.13.0 '코드도 채점을 보는 규칙 연습')의 코드는 fabef5d에 끈 스위치 뒤로 들어갔습니다. 무엇을 바꿨고 무엇을 확인했는지(끈 바이트 · 옛 창 일곱 · 돌연변이 탐침 · D26 재확인 · 모듈 크기 · 관문)는 그 커밋 본문에 있습니다. hooks/notes.ts sha256 `30b8b7df476434f618d689a20be971234eadf64116ac4a441d09e797e35770fc` · hooks/register.tsx `c4562ae08c7006aed2c7a7ac6120bdfba28fae0899089bb915144fc0cc7e3e92`. IS_RULE_DRILL은 false 그대로이고, MODEL_SWITCHES 두 줄은 짓기 전 그대로입니다(haiku `{ ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2 }`, sonnet `{ ...SWITCHES_OFF, isRuleWide: true }`).

### 기준 · 입장 · 결정 규칙 (재기 전에 정함: 2026-11-21 00:00 UTC, 견본을 쓰거나 모델을 부르기 전)

이 절은 공통 입장 절('1.10.0 모델별 갈래 (G7): 두 모델을 재는 공통 입장'의 M-0 ~ M-15, B-1 ~ B-15, R0 ~ R11)을 따릅니다. 그 글의 '1.10.0'은 '1.13.0'으로, '묶음 1 보정 기록'은 위 '### 보정 기록 (1.13.0)'으로 읽습니다. 위 '1.13.0 꺼진 칸 다시 설계' 절의 '셈을 지키는 규칙'(CLI 고정 · 사용량 관문 · 끊긴 스테이지 규칙 · 러너 규칙 · 쓰는 쪽 · 판정자 · 확인자 러너 · 얼릴 때 확인 입력 · 백업 규칙 · 피할 목록 짓기 · D26 도구 사본 · 모듈 나눔), '이름 목록', '주인 물음 (기본값)', '묶음마다 앞선 칸 재확인'도 이 절을 다스립니다.

- 잰 설계: 설계 파일 `impl113/design/G6.json`(sha256 `25ca00f986749dbf86fe25f5cf2e334426049f5d771abbe1c6cf8267a2ed3f2c`), 시제품 패치 `impl113/design/G6/final/G6-113-final.diff`(`22885e6bfa1956da693634dd6c3cbb85a5bf43814420c28d791467fd9afbde9a`). 코드는 짓기 커밋 fabef5d(위)입니다. 계획 `impl113/plan113.json`(`21b5421c401a1c3235dac21d1d238fd6690dacfd4e94266fb0512aca81e64912`)의 묶음 1(2/4)입니다.
- 이 절의 기준 · 입장 · 결정 규칙 · 견본 · 부르기 · 위험 글은 설계의 bar · stance · decisionRule · samples · calls · risks · perModel 필드와 계획 묶음 1(barSource · samples · calls · judges · stop)의 글을 한국어로 옮긴 것입니다. 수와 조항은 하나도 바꾸지 않았습니다. 설계의 입장(stance)은 처음부터 한국어라 글자 그대로 옮겼습니다. 옮긴 글은 새 하위 에이전트가 설계 필드와 견주어 확인했습니다(아래 '옮김 확인').
- 입장은 1.12.0 G6 입장(2f95fe1, 이 파일의 '## 1.12.0 팀 규칙 연습 (G6)' > '#### 판정의 입장')의 모든 글을 글자 그대로 다시 커밋합니다. 아래 '#### 판정의 입장'에 그 글을 다시 옮겨 적었고, 설계가 바꾼 곳(§1의 켠 읽기, §2의 H_M, §14의 옛 창 일곱, E8, N2 입장)은 1.12.0이 한 대로 원문을 지운 줄(~~ ~~)로 남기고 1.13.0 글을 붙였으며, 더한 경계 꼴 E19 ~ E32를 붙였습니다. 그 글의 '1.12.0'은 '1.13.0'으로, '1.12.0 보정 기록'은 '1.13.0 보정 기록'으로, '그 판 트리'는 1.13.0 짓기 커밋 fabef5d의 트리로 읽습니다(설계 stance.intro).
- M-0 대응: G6의 상한 몫('회 앞의 작은 호출로 확인한 max_tokens') → H_M(1.13.0 보정 기록: H_haiku 2048). G의 작은 호출(maxTokens 60)은 하지 않습니다(1.10.0 결정 D4 그대로).
- 상한 닿음(output_tokens ≥ maxTokens + H_M, '보정 기록 (1.13.0)'의 수 그대로, 그 기록의 '상한 닿음 줄' 표의 묶음 1 세 줄): 노트 3500 → haiku 5548(기록; 상한에 닿은 노트의 연습은 입장대로 읽음), 2단 규칙 연습 3500 → haiku 5548('답 없음' 줄 ≤ max(1, ⌊n/60⌋)), N2 채점 480 → haiku 2528(읽히지 않음 = 맞음 아님이고 `규칙:` 줄 빠짐).
- M-6: G6의 기준에는 토큰 절댓값 줄이 없어(수와 비율뿐) 바꿀 것이 없습니다('보정 기록 (1.13.0)'의 M-6 표: G2 · G6 바꿀 것 없음).
- 수준: 견본은 beginner로 잽니다(켠 값도 beginner에서만 닿음, 1.10.0 계획 고침 D17).
- 잴 모델: haiku 하나입니다. sonnet은 재지 않습니다(주인 물음 15 기본값 (c), 1/4 첫 커밋에 적음; '1.13.0 설계만 하고 재지 않음'의 G6 sonnet 칸). 그래서 이 절의 기준 · 결정은 haiku에만 쓰고, sonnet의 isRuleDrill은 false 그대로입니다(넘겨받지 않음).
- 앞선 칸 재확인(D26): 묶음 1이 다시 확인할 칸은 isRuleWide haiku · isRuleWide sonnet · G2 rungChangedStep haiku입니다. 짓기 커밋 전 작업 트리에서 돌렸고 다름 0이었습니다(fabef5d 본문: `impl113/d26/rulewide113.mjs` 639경우 모든 견줌 다름 0; `impl113/d26/g2haiku.sh` (가) 9/9 · (나) build.json 같음 · (다) read.json `05aa93f5…` 같음). 이 기준 커밋은 견본.md만 바꿉니다.
- 주인 물음(위 '주인 물음 (기본값)' 표의 15 · 16, 다른 답이 오지 않아 기본값): 15 — (c) sonnet은 1.13.0에서 재지 않습니다. 16 — 예: N2를 학습자에게 보이는 판정(1.13.0 gradeDrill)으로 세고, 그 너그러움을 아래 '밝혀 둔 벗어남' (1)로 이 커밋에 주인의 결정으로 밝힙니다.
- 계획과 SCOPE.md가 다른 곳: 없습니다. 계획이 SCOPE.md보다 엄한 곳(쓰는 쪽 짜임, 피할 목록, 회 수준 관문)은 계획을 따릅니다.

밝혀 둔 벗어남 (계획 barSource.declaredDeviations, 견본을 쓰기 전에 적음)
1. N2 셈은 학습자에게 보이는 판정으로 옮깁니다(입장; 주인 물음 16 기본값 예). 마지막으로 커밋된 G6 기준(2f95fe1: 모델 자신의 판정에서 어김→맞음 ≤ 1, 깨짐→맞음 = 0)에 견주면, 이것은 모델 판정의 허용을 '낮추기 전 (어김 + 깨짐)→맞음 ≤ 2'로 너그럽게 하고, 어김 ≤ 1 · 깨짐 0은 낮춘 뒤에 셉니다. 채점자 수준에서 주인이 정한 너그러움으로 밝힙니다. 학습자에게 보이는 줄은 그대로입니다.
2. '지킴 답 낮춤 = 0'은 하나뿐인 더 엄한 줄입니다.
3. 30adc2f를 더한 새 옛 창 줄은 더 엄합니다.
4. 쓰는 쪽 짜임은 호출마다 세트 종류 하나입니다(아래 '견본의 짜임'의 쓰는 쪽). 기반 바꿈입니다. 설계의 'R_long+F 2 … multi+double 1'(약 12번)과 다르고, 기준 줄이 아닙니다.

사용량 관문 (계획 usageGate; R과 그 이끌어 냄은 이 커밋 본문에도 적음)
- 묶음 예측 0.24 = 호출 4 × c_stage(A ≈ 105, B ≈ 105, N2-1 30, N2-2 30) 0.04 + 하위 ≈ 26 × c_sub(쓰는 쪽 ≈ 18, N2 쓰는 쪽 5, 행 확인자, N2 확인자, 번역 확인) 0.08 + 에이전트 ≈ 12 × c_agent 0.12.
- 회 R(회 A에서) = 0.04(회 A · B, N2 1번째 · 2번째의 모델-스테이지 넷) + 7 × c_sub 0.02(N1′ 행 확인자, N2 쓰는 쪽 5, N2 확인자) + 2 × c_agent 0.02(n2verify와 판정 · 결정 단계) = 0.08. 회 A haiku는 seven_day + 0.08 < 0.80일 때만 시작하고, 아니면 seven_day.resetsAt 바로 뒤에 시작합니다.
- 스테이지 관문: 모델-스테이지마다(회 A · 회 B · N2 1번째 · N2 2번째, 모두 haiku) five_hour ≤ 0.60 그리고 seven_day + 0.01 < 0.80 그리고 다른 워크플로가 돌지 않음.
- 쓰는 쪽 · 판정자 · 확인자 러너는 자기 관문(five_hour ≤ 0.60 그리고 seven_day + 그 스테이지 예측 < 0.80; 견본 쓰는 쪽 19번 = 0.06, N2 쓰는 쪽 5번 = 0.02, 확인자 하나 = 0.01)을 가집니다. 쓰는 쪽 러너가 스테이지 앞뒤로 적은 seven_day의 잰 차이가 c_sub보다 크면 그 뒤 예측은 잰 값을 씁니다.

#### 기준

출처: 마지막으로 커밋된 기준 1.12.0 G6(커밋 2f95fe1, 이 파일의 '## 1.12.0 팀 규칙 연습 (G6)' > '#### 기준')이고, 그것은 1.10.0의 기준(432ced4)을 다시 커밋한 것입니다. 아래 줄은 NEW(더 엄함)나 STANCE(분명하고 까닭을 단 셈 문장)라고 적은 곳 말고는 모두 그 기준 글자 그대로입니다. den은 커밋된 den이고 범위를 좁히지 않습니다.

| 기준 | 넘는 선 (haiku; 회 A · 회 B 모두) |
| --- | --- |
| 견본 | 두 모델에 같은 새 얼린 견본(85 + 예비: R 40 [규칙마다 10; js 14 · ts 12 · py 14], R_long 4, F 12, N 12, 함정 9, multi 4, double 4). 모델마다 서로 독립인 두 회 A와 B; N1′의 모든 줄이 두 회 모두에서 넘어야 함; 모델마다 따로, 합치거나 옮기지 않음 |
| N1′ (a) | O ≥ 20이고 O 노트의 규칙 연습 = 0 (O = keptNoteText 글에서 연습 제목 앞에 `팀 규칙과 다를 수 있음:` 줄이 없는 노트; `팀 규칙:` 줄만 있으면 O) |
| N1′ (b) den | 들여쓰기 빼고 40자 이하인 violations 줄이 있는 견본의 L 노트; den ≥ 20 |
| N1′ (b) 바름 | 바른 규칙 연습(§6 (i) ~ (vi) 모두 참) ≥ den의 80%; 연습이 만들어지지 않은 den 노트(건너뜀, `줄: 없음`, 받지 않은 답, 실패한 호출)는 바르지 않음 |
| N1′ (b) 해로움 | 그 회의 답한 모든 노트에서 0 (h1 들인 규칙 없음; h2 줄이 들인 규칙의 violations 줄이 아님, 함정 · R_long · 헛짚은 노트 포함; h3 들인 규칙의 표지가 예시 답에 남음, 거꾸로 바꿈 · 감쌈 포함; h4 바꾼 파일에 구문 오류) |
| N1′ (b) 할 일 둘 | 0: 최종 직접 해 보기 칸(들)에 할 일 줄(taskLineOf)이 둘 이상인 노트, 답한 모든 노트에서, 켠 읽기와 끈 읽기 모두에서 (끈 읽기 = 같은 노트 답의 keptNoteText(답, names), 낸 isRuleWide 길; 주인 물음 기본값: 계속 셈) |
| N1′ (c) | O 노트: 노트 프롬프트가 켬 · 끔에서 바이트까지 같음(시험 + D34), O 노트에 연습 호출 없음(호출 기록), O 노트마다 최종 글이 켠 읽기와 끈 읽기에서 바이트까지 같음 |
| 함정 | 9개 → 규칙 연습 = 0 |
| R_long, 그리고 40자 이하 어긴 줄이 없는 L 노트(F · N · 함정) | 규칙 연습 = 0 (그 노트 자신의 개념 연습은 끈 판처럼 허용) |
| 표지 없는 규칙 연습(§9) | 켠 읽기 · 끈 읽기 모두 0 |
| 규칙 연습 답 없음 | 상한 닿음(output_tokens ≥ 3500 + H_M; 1.13.0 보정 haiku 5548), 빈 답(API 거절 포함, E18), 시간 한도가 max(1, ⌊n/60⌋) 이하, n = 그 모델 두 회의 2단 호출 수; API 오류는 세고 다시 보내지 않음 |
| 옛 창(호출 0) | 3f2b4fb · 7a7b08c · 3690021 · fca5988 · 3d2f251 · de98243의 notes.ts + NEW 30adc2f(1.12.0; 더 엄함): 표지가 있는 모든 최종 글(켬 · 끔)에서 drillOf가 연습을 주지 않고 hideDrillAnswer가 `고칠 줄` / `예시 답` 줄을 보이지 않음; 표지 없는 모든 글에서 창마다 3d2f251의 drillOf와 같은 할 일 · 줄 · 예시 · 파일 · 행을 줌 |
| W 관문(isRuleDrill만) | 두 회의 끈 읽기에서 §11 W 오탐 = 0이고 모든 답에서 keptNoteText가 멱등; W 오탐은 isRuleDrill만 막고 isRuleWide를 다시 정하지 않음 |
| N2 | 잰 꼬리표마다, 그 모델 회 A에서 나온 둘째 스테이지 견본: 바른 연습 5개를 고름(규칙 넷 모두, py ≥ 1, ts ≥ 1; 5개보다 적으면 → N2 못 넘음); 답 30개(연습마다 지킴 2 · 어김 2 · 깨짐 1 · 엉뚱함 1, n2verify로 확인, 예비로 채움)를 gradeDrill이 매기는 그대로 두 번 매김(480, 60000 ms, 첫 시도). 번마다: 바른 판정 ≥ 27/30, 어김→맞음 ≤ 1, 깨짐→맞음 = 0, `규칙:` 줄 빠짐 ≤ 1 (답 없음 · 읽지 못함 = 바르지 않고 빠짐). 뺀 답은 분모를 줄이지만 바른 판정은 여전히 27개가 있어야 함 |
| STANCE (N2 셈, 어느 견본보다 먼저 정함) | 'gradeDrill이 매기는 그대로'는 1.13.0 짓기 트리의 gradeDrill, 곧 학습자에게 보이는 판정입니다: parseCheck의 안 지킴 + 맞음 → 거의, 그다음 ruleGradeCap의 맞음 → 거의. 커밋된 1.12.0 입장 글은 1.12.0의 gradeDrill에 낮추기가 그 하나뿐이었기 때문에 첫 낮추기만 이름 지었습니다; 이 설계는 그 바꿈을 드러내어 밝힙니다(1.12.0의 GA02-10을 거의로 바꿈). 아래 NEW 두 줄은 상한이 채점자 무너짐을 가리지도, 맞는 줄을 잃게 하지도 못하게 합니다 |
| NEW (더 엄함), 번마다 | n2verify keep 답에 대한 ruleGradeCap = 0 (맞는 줄에 코드 상한이 걸리면 N2 못 넘음) |
| NEW (더 엄함), 번마다 | 낮추기 전 (어김 + 깨짐)→맞음 ≤ 2, ruleGradeCap 전의 parseCheck 판정으로 셈 (틀린 줄을 많이 맞다고 하는 채점자는 코드가 잡더라도 N2를 못 넘음). 1.12.0에서 잰 haiku는 번마다 1; 1.13.0 개발 haiku 번마다 1; sonnet 0 |
| 결정 규칙 (기계, decide.py) | isRuleDrill_m = 기준 커밋에서 MODEL_SWITCHES[m].isRuleWide가 true ∧ W가 두 회 모두 넘음 ∧ N1′의 모든 줄이 A와 B에서 넘음 ∧ N2가 두 번 모두 넘음(그 모든 줄, NEW 둘 포함); 아니면 false. 무효인 회(M-4 기반 10%, M-10 앞뒤 기록 ≠ 1.13.0 보정) → 끔, 다시 재지 않음. 정하지 못한 꼴(§15 / M-11)은 못 넘는 쪽으로 셈. 입장, 열쇠, 판정자와 스크립트는 기준 커밋에서 얼림; 도구 결함은 M-15대로(못 넘음이 넘음으로 바뀌지 않음) |
| 상한 문턱 | 3500 + H_M(노트, 2단)과 480 + H_M(N2), 설치된 Claude Code의 새 고정 사본(설계 때 2.1.327; 고정한 것은 2.1.329)으로 한 1.13.0 M-5 보정에서 나옴: 5548 · 2528; 모든 회의 앞뒤 기록이 그 기록과 같아야 하고(M-10), 아니면 그 회는 무효이고 칸은 끔 |

기록만(결정에 들지 않음, S-d / B-12): 노트마다의 단, 건너뜀 까닭, 2단 잘못 코드, 후보 수, 1.9.0 정의의 (b), den 놓침의 1.10.0 꼴 나눔, output tokens · 시간, 엄격한 S1 대체 수, L 노트마다 연습 호출 수, 거절 열; NEW 기록: N2 답마다 낮춘 까닭과 낮추기 전 판정, 구조 분해 1단 · 2단 닿음, 마지막 답 읽기, 앵커만 든 목록(그리고 그것으로 'no-hint' 건너뜀이 된 노트).

밝힌 위험(설계 bar.statedRisk): sonnet의 할 일 둘 줄은 이 설계가 건드릴 수 없는 자기 낸 1.8.0 노트 호출의 끈 읽기를 셉니다(그 줄만 넘을 확률 약 39%, 전체 약 30%). 그래서 주인이 달리 정하지 않으면 sonnet은 여기서 재지 않습니다(설계 ownerQuestions[0] = 위 표의 15).

계획 묶음 1의 글(같은 기준, 줄여 적음): haiku만, 같은 새 얼린 견본으로 두 회 A와 B, 두 회 모두에서 N1′의 모든 줄: (a) O ≥ 20이고 O 노트의 연습 0; (b) den ≥ 20, 바름 ≥ den의 80%, 답한 모든 노트에서 해로움 0, 켠 읽기와 끈 읽기에서 할 일 둘 0; (c) O 노트의 프롬프트와 최종 글이 켬/끔에서 바이트까지 같음, O 노트에 연습 호출 없음; 함정 9개 가운데 0; R_long/F/N/함정 줄 없음 0; 표지 없음 0; 2단 답 없음 ≤ max(1, ⌊n/60⌋); 옛 창(30adc2f를 포함한 일곱 빌드, NEW 더 엄함) 나쁜 것 0; 끈 읽기의 W 관문 오탐 0이고 keptNoteText 멱등; N2 두 번 모두: 바름 ≥ 27/30, 어김→맞음 ≤ 1, 깨짐→맞음 0, 규칙 빠짐 ≤ 1, 지킴 낮춤 0(NEW, 더 엄함), 낮추기 전 (어김 + 깨짐)→맞음 ≤ 2(NEW). 입장 바꿈과 함께, 이 낮추기 전 줄은 2f95fe1의 모델 판정 허용을 너그럽게 합니다; 이것은 밝혀 두며 더 엄하다고 부르지 않습니다.

1.12.0 기준과 다른 점(재기 전에 적는 까닭)
- 옛 창에 30adc2f(1.12.0)를 더했습니다(일곱; 더 엄함).
- N2 셈을 1.13.0 gradeDrill의 학습자에게 보이는 판정으로 옮겼습니다(STANCE; 위 '밝혀 둔 벗어남' 1). 그와 함께 NEW 두 줄(지킴 낮춤 0, 낮추기 전 (어김 + 깨짐)→맞음 ≤ 2)을 더했습니다.
- 상한 닿음의 H_M은 1.13.0 보정 기록의 값입니다(M-0 · M-5: H_haiku 2048, 1.12.0과 같은 수 5548 · 2528). 이것은 설계가 바꾼 것이 아니라 커밋된 공통 입장(M-5: 판마다 다시 잼, M-10)이 주는 수입니다.
- 나머지 줄 · 선 · den은 1.12.0(= 1.10.0) 그대로입니다.

#### 판정의 입장

설계의 입장(stance) 글입니다. 설계 stance.intro(글자 그대로): 판정의 입장(1.13.0 G6). 1.12.0 G6 입장(2f95fe1, 견본.md '## 1.12.0 팀 규칙 연습 (G6)' > '#### 판정의 입장')의 모든 글 — 공통 다섯 항목, 확인 줄(S-a), 견본(S-c), 판정 대상(S-b), 경계 꼴 E1 ~ E18, N2 입장, 다시 커밋하는 1.10.0 입장 §0 ~ §15와 세부 1 ~ 24, '읽는 법' — 을 글자 그대로 다시 커밋합니다. 그 글의 '1.12.0'은 '1.13.0'으로, '1.12.0 보정 기록'은 '1.13.0 보정 기록'으로, '그 판 트리'는 1.13.0 짓기 커밋의 트리로 읽습니다. 아래는 바꾸거나 더하는 곳뿐이며, 바꾼 곳은 1.12.0이 한 대로 원문을 지운 줄(~~ ~~)로 남기고 1.13.0 글을 붙입니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 견본.md '다시 잴 때'에 적습니다(M-11).

아래는 1.12.0 G6 입장(2f95fe1)의 '공통' 다섯 항목, 확인 줄(S-a), 견본(S-c), 판정 대상(S-b), 경계 꼴 E1 ~ E18, N2 입장, 다시 커밋하는 1.10.0 입장 §0 ~ §15, '읽는 법', 다시 커밋하는 1.10.0 세부 1 ~ 24를 글자 그대로 옮긴 것이고, 1.13.0에서 바꾼 곳은 ~~ ~~와 '(1.13.0에서 바꿈)' · '(1.13.0에서 더함)' 줄로, 더한 경계 꼴은 E19 ~ E32로 붙였습니다. 판정은 이 글자대로만 셉니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 '다시 잴 때'에 적습니다(M-11).

공통 (1.10.0 입장 §0–§15와 세부 1–24를 그대로 다시 커밋하고, 아래만 바꾸거나 더함)
- §0 · §15 그대로: 판정 스크립트를 이 글대로 먼저 짓고 sha256을 바 커밋에 적습니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 견본.md '다시 잴 때'에 적습니다. 판정 파일을 쓴 뒤에는 입장 · 열쇠 · 기준을 바꾸지 않습니다.
- §1 (바꿈) 켠 읽기: 노트 답 → fixEscapedTicks → keptNoteText(답, names) → noteRuleOf가 읽히면 그 판 트리의 ruleFixPlan(screened, rules, 그 줄). 1단이면 ruleFixMade(글, fix, changes) ?? 글, 2단이면 RULE_DRILL_SYSTEM · redactText(ruleDrillPrompt(screened, rules, 그 줄, cands)) · 3500 · 90000으로 부르고 fixEscapedTicks → ruleFixReply가 받은 글 ?? 글, 건너뜀이면 글 그대로. 끈 읽기: 같은 노트 답의 keptNoteText 글 그대로.
- (1.13.0에서 바꿈) §1 켠 읽기(1.13.0): 1.12.0 글 그대로이고, 그 판 트리의 ruleFixLines · renamedLine · usePlaces · isOneSpanFix · parseRuleFix가 1.13.0 것입니다(피할 이름 없는 규칙은 인용된 줄만 후보, 한 줄 구조 분해의 객체 바꿈, 스스로 고친 답은 마지막 온전한 답). 끈 읽기는 같은 노트 답의 keptNoteText 글 그대로입니다.
- §2 그대로: 노트 호출이 답하지 않은 견본은 그 회 L · O에서 빼고 수만 적습니다. 규칙 연습 호출의 상한 닿음 · 빈 답(API 거절 포함) · 시간 한도는 '답 없음' 줄에 셉니다(n = 그 모델 두 회의 2단 호출 수). 닿았어도 글이 읽히면 읽힌 대로 매깁니다. 상한 닿음 = output_tokens ≥ maxTokens + H_M(~~1.12.0 보정~~ 1.13.0 보정 기록).
- (1.13.0에서 바꿈) §2: 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.13.0 보정 기록). 그 밖은 그대로.
- §3 · §4 · §5 · §6 · §8 · §9 · §10 · §11 · §12 · §13 그대로(채점 열쇠 §5는 같은 팀 파일에서 나온 그대로).
- §14 (더함, 엄격하게): 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988에 3d2f251 · de98243을 더한 ~~여섯~~ 일곱(1.13.0, 아래 줄)입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.
- (1.13.0에서 더함) §14 (더함, 엄격하게): 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988 · 3d2f251 · de98243에 30adc2f(1.12.0)를 더한 일곱입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.

확인 줄 (S-a, §7에 더함)
- 켠 판의 확인 줄은 코드가 쓴 '고친 줄이 돌 때 `U` 쪽을 거칩니다' 하나뿐입니다. 세부 6: 코드 칸에 호출이 없으므로 견본 demo를 돌립니다. 세부 8: 쓰라는 이름 하나만 든 코드 칸은 값이 아닙니다. 세부 10: 효과 말이며 U의 규칙이 그 규칙입니다.
- 효과 주장은 줄 단위로 매깁니다: 그 줄만 예시 답으로 바꾼 파일로 demo를 돌린 기록에 그 규칙 대역 줄(`[apiRequest] ` · `[log.info] ` · `[toDateText] ` · `[config] `로 시작)이, 원래 줄 그대로 돌린 기록보다 많아야 참입니다(파일이 다른 줄에서 이미 대역을 부르는 경우를 가름). 같으면 거짓입니다.
- 확인 줄이 이 꼴이 아닌 규칙 연습(켠 창에서 읽히지 않으므로 나올 수 없음)이 나오면 1.10.0 §7 그대로 매깁니다.

견본 (S-c)
- 얼리기 전: violations마다 fix로 바꾼 demo가 원래 demo보다 그 규칙 대역 줄을 더 많이 써야 합니다(엄격한 S1). 못 넘은 견본은 같은 무리 예비로 id 차례대로 채우고 고쳐 쓰지 않으며, 바뀐 수를 견본.md에 무리마다 적습니다(모집단 기록). 개발 견본 1–4의 짧은 어긴 줄 92개에서는 0개였습니다.
- F 견본에서 표지 글자가 문자열 글자나 주석 안에만 있는 줄은 어긴 줄이 아닙니다(F의 정해진 꼴). 그 줄에 규칙 연습이 나오면 h2(해로움)입니다.

판정 대상 (S-b)
- 연습은 저장된 노트 글로만 매깁니다. 1단(코드가 만든 예시 답)이든 2단(모델이 준 예시 답)이든 같은 §6 · §10을 씁니다. 1단이라고 덜 보지 않습니다.
- 갈래 · 건너뜀 까닭 · 2단 잘못 코드는 기록만 하고 판정에 쓰지 않습니다(S-d).

옛 기록과 개발 답에서 나온 경계 꼴 (미리 정함)
- E1 인자를 바꾼 예시 답(`toDateText(e.endsAt)`, 줄은 `d.toLocaleDateString('en-CA')`): 표지가 없고 쓰라는 이름이 있으면 (iv)의 출력 비교가 정합니다. 출력이 expected_fixed와 같으면 바름, 다르면 바르지 않음(해롭지 않음).
- E2 결과에 사슬을 남긴 예시 답(`toDateText(end).slice(0, 10)`): 남은 것이 §5 표지가 아니면 h3가 아니고 (iv) 출력이 정합니다. `.slice(0, 4)`처럼 출력이 바뀌면 바르지 않음(1.12.0 개발 D1A14).
- E3 감싼 예시 답(`toDateText(end.toJSON())`)과 옆에 남긴 예시 답(`toDateText(d) || d.toISOString()`): 표지가 남으므로 h3. 코드가 막으므로 나오면 코드 결함이며 해로움으로 셉니다.
- E4 multi: 어느 violations 줄이든 짚은 규칙의 줄이면 바를 수 있습니다. 다른 규칙의 줄이면 (ii)나 (iii)에서 바르지 않고, 들인 규칙의 violations 줄이 아니면 h2입니다.
- E5 double(같은 규칙 둘): 둘 가운데 어느 줄이든 됩니다. 다른 한 줄의 표지가 파일에 남는 것은 예시 답의 표지가 아니므로 h3가 아니고, (iv)는 그 violation의 expected_fixed로 견줍니다.
- E6 `config["X"]` · `config.get("X")` · `Number(config.X)`: 쓰라는 이름 config를 품으므로 지킴입니다(§8 대역이 모두 받침). 확인 줄의 U는 `config`입니다.
- E7 os.getenv 줄(규칙 글이 이름 짓지 않은 표지): 코드가 후보로 올리지 않아 연습 없음이면 den의 바르지 않음이고 해롭지 않습니다. 연습이 나오면 보통처럼 매깁니다.
- E8 (1.13.0에서 바꿈): ~~2단 답이 스스로 고쳐 쓴 꼴(같은 라벨에 다른 값, 'Wait —'): 코드가 받지 않아 연습 없음입니다.~~ 1.13.0: 코드가 마지막 온전한 답(줄, 줄: 없음이 아니면 예시 답, 첫 답에 규칙이 있었으면 규칙)을 받아 같은 확인(ruleFixFault)을 거칩니다. 마지막 답이 온전하지 않으면 연습 없음입니다. 판정은 언제나 저장된 글만 봅니다.
- E9 노트 호출이 스스로 고쳐 쓴 꼴로 직접 해 보기 칸에 할 일 줄이 둘(1.12.0 개발 D4B02 · D4B21, 끈 읽기): §13대로 할 일 줄 둘인 노트로 셉니다(두 읽기 모두, 답한 모든 노트). 이 설계가 바꿀 수 없는 끈 읽기의 일이어도 기준 줄은 그대로입니다.
- E10 노트 호출이 상한에 닿았지만 답한 경우(개발 D3B11 haiku 5548): 읽힌 대로 매기고 상한 닿음은 노트 호출 쪽 기록입니다(규칙 연습 '답 없음' 줄은 2단 호출만 셈).
- E11 켠 창에서 W2가 표지를 단 자기 칸(코드가 만들지 않은 규칙 연습): 켠 읽기에서 연습 없음입니다. 그 노트가 den이면 바르지 않음, 표지 없는 규칙 연습(§9)도 아님(개념 연습이 아니므로). 끈 읽기의 W 오탐(§11)은 그대로 셉니다.
- E12 1단이 만든 연습이 demo가 지나지 않는 줄에 있음: (v) · (vi)에서 거짓(효과 기록이 늘지 않음). 엄격한 S1이 견본의 열쇠 줄을 보장하므로 열쇠 줄이 아니면 (iii)에서 이미 바르지 않음입니다.
- E13 1단 이름 바꿈이 같은 줄의 쓰지 말라는 다른 이름을 남김: 코드가 막음. 나오면 h3.
- E14 확인 줄 U가 예시 답의 가장 짧은 쓰라는 이름(`config`)이고 예시 답은 `config.API_URL`: 효과 말 config로 매깁니다.
- E15 규칙 연습 호출 답이 `- 줄: 없음`이고 그 노트가 den: 연습 없음 → 바르지 않음, 해롭지 않음.
- E16 N2: 학습자 줄이 예시 답과 같거나 고칠 줄과 같으면 gradeDrill이 부르지 않으므로 n2verify가 뺍니다(세부 22). 판정 셈은 세부 23 그대로.
- E17 노트 글의 `다를 수 있음` 줄이 규칙 이름을 하나도 품지 않음(코드는 건너뜀): 연습 없음. den이면 바르지 않음.
- E18 sonnet API 거절(stop_reason refusal): 빈 답으로 '답 없음'에 셉니다. 탭 기록은 따로 적는 기록입니다.

1.13.0에서 더한 경계 꼴 (미리 정함, 설계 stance.added 글자 그대로)
- E19 한 줄 구조 분해 예시 답(`const { API_URL, CDN } = config;`, 줄은 `= process.env;`): 쓰라는 이름 config를 품고 표지가 없으므로 (iv)의 출력 비교가 정합니다. 1단이 만들었어도 같은 §6 · §10으로 매깁니다.
- E20 GA17 꼴에서 2단 답이 꼴을 바꾼 것(`const SUPPORT_EMAIL = config.SUPPORT_EMAIL;`): 한 자리 고침이 아니라 코드가 받지 않음 → 연습 없음. den이면 바르지 않음, 해롭지 않음.
- E21 스스로 고친 2단 답에서 첫 답과 마지막 답이 다른 줄을 고름: 코드가 마지막 온전한 답만 봅니다. 저장된 글의 줄 · 예시로만 §6 · §10을 매기며, 첫 답의 줄은 보지 않습니다.
- E22 피할 이름 없는 규칙(날짜)을 짚은 노트에서 인용된 줄이 없음: 후보 없음 → 건너뜀(no-hint) → 연습 없음. den이면 바르지 않음, 해롭지 않음(E17과 같은 셈).
- E23 날짜 규칙 2단 예시 답이 값을 다시 감쌈(`toDateText(new Date(at))`): `new Date(`는 §5 표지가 아니므로 h3가 아니고 (iv)의 출력이 정합니다(E1 · E2와 같음).
- E24 N2: n2verify keep 답에 ruleGradeCap이 무엇이든 내면 그 답은 바른 판정이 아니고 '지킴 답 낮춤' 줄에 1로 셉니다(그 줄은 0이어야 함).
- E25 N2: off(엉뚱함) 답을 모델이 맞음이라 하고 코드가 거의로 낮춤: off의 바른 판정은 틀림뿐이므로 바르지 않음(1.12.0 그대로, 예: 1.13.0 개발 E1A09-28 off → 거의 ✗).
- E26 N2: break · broken 답을 모델이 맞음이라 하고 코드가 거의로 낮춤: 바른 판정(거의)으로 세고, 낮추기 전 (어김 + 깨짐)→맞음 줄에 1로 셉니다.
- E27 N2: 모델이 거의 · 틀림이라 한 답에 코드는 아무 일도 하지 않습니다(낮추기만, 올리지 않음). 코드가 무엇을 냈을지는 적지 않습니다.
- E28 N2: 견본 파일의 after 글을 찾지 못하면(경로가 다름) 코드는 diff 이름만으로 봅니다(플러그인이 파일을 읽지 못한 때와 같음). 그 수를 적습니다.
- E29 N2: 도구가 짓기 트리의 ruleGradeCap과 다르게 센 것이 드러나면 M-15로 두 꼬리표를 다시 세고, 못 넘음이 넘음으로 바뀌지 않습니다.
- E30 N2는 첫 시도만 잽니다(1.9.0부터 그대로). 낮춘 뒤의 두 번째 시도 요청(첫 판정: 거의 + 코드가 쓴 피드백)은 재지 않고 '위험'에 적습니다.
- E31 sonnet 노트가 스스로 고쳐 할 일 줄을 여럿 씀(1.12.0 GD15 꼴, 끈 읽기): E9 그대로 할 일 줄 둘인 노트로 셉니다(두 읽기, 답한 모든 노트). 이 설계가 바꿀 수 없는 끈 읽기의 일이어도 기준 줄은 그대로입니다.
- E32 N2 keep 답이 예시 답과 다른 뜻의 같은 꼴(같은 모양에 다른 이름, 예: `toDateText(when)` ↔ 예시 `toDateText(value)`)이고 n2verify가 keep(출력 같음)으로 가름: 코드가 swap으로 낮추면 E24대로 셉니다(넘는 쪽에 불리하게, 미리 정함).

N2 입장
- (1.13.0에서 바꿈, 아래 다시 커밋하는 'N2 입장:' 줄에 넣음) N2 입장 (바꿈, 재기 전에 밝힘): ~~parseCheck(text, { rule: true }) 뒤 '안 지킴 + 맞음 → 거의' 낮추기를 거친 판정으로 셉니다.~~ 1.13.0: 기준의 'gradeDrill이 매기는 대로'는 1.13.0 짓기 트리의 gradeDrill이 학습자에게 보이는 판정입니다. 곧 parseCheck(text, { rule: true })의 '안 지킴 + 맞음 → 거의'를 거친 뒤, 그 판정이 맞음이면 짓기 트리의 ruleGradeCap(sent, ruleFixUse(sent.check), 답 줄, capKnownNames(그 노트의 screened 변경 diff, 그 견본 파일의 after 글), pairLangOf(sent.file), after 글, ruleAvoidsOf(얼린 팀 파일의 규칙, use))이 무엇을 내면 거의로 셉니다. 바른 판정은 그대로(지키고 동작함 → 맞음, 어겼지만 동작함 → 거의 · 틀림, 깨짐 → 틀림 · 거의, 엉뚱함 → 틀림). 낮추기 전 판정(parseCheck의 판정)은 따로 적고, 새 줄 '낮추기 전 (어김 + 깨짐)→맞음 ≤ 2'만 그것으로 셉니다.
- 1.9.0 · 1.10.0 N2 입장 그대로(세부 22 · 23). 문제 글의 할 일 · 확인 줄은 코드가 쓴 것이며, 채점 프롬프트의 나머지 바이트는 1.9.0과 같습니다(rule19 고정, 만든 연습의 채점 요청 고정 시험 추가).

다시 커밋하는 1.10.0 입장 §0 ~ §15 (432ced4 글 그대로; 바꾼 곳은 ~~ ~~와 1.12.0 글)

§0 커밋과 스크립트
- 판정 스크립트(저장소 밖)를 이 입장대로 먼저 쓰고, 그 sha256을 이 커밋에 적습니다.
- 출력을 본 뒤 스크립트가 이 글과 다르게 센 것이 드러나면 글대로 다시 세고 스크립트 diff를 견본.md에 남깁니다. 글(입장 · 열쇠 · 기준)은 바꾸지 않습니다.

§1 부르기와 읽기는 플러그인과 같습니다 (1.12.0에서 바꿈: 켠 읽기 한 줄)
- 팀 파일은 그 판 트리의 parseTeamFile로 읽습니다. names = ruleNamesOf(team.rules)(잰 모델의 isRuleWide를 켠 상태).
- 노트: SYSTEM, notePrompt(screened, 'beginner', [], team), maxTokens NOTE_TOKENS(3500).
- 노트 답: fixEscapedTicks → keptNoteText(답, names).
- ~~켠 읽기: noteRuleOf가 읽히면 RULE_DRILL_SYSTEM · ruleDrillPrompt(screened, team.rules, 그 줄), maxTokens RULE_DRILL_TOKENS(3500)로 부르고, fixEscapedTicks → withRuleDrill(글, 답, changes, names) ?? 글.~~
- 켠 읽기(1.12.0): 노트 답 → fixEscapedTicks → keptNoteText(답, names) → noteRuleOf가 읽히면 그 판 트리의 ruleFixPlan(screened, rules, 그 줄). 1단이면 ruleFixMade(글, fix, changes) ?? 글, 2단이면 RULE_DRILL_SYSTEM · redactText(ruleDrillPrompt(screened, rules, 그 줄, cands)) · 3500 · 90000으로 부르고 fixEscapedTicks → ruleFixReply가 받은 글 ?? 글, 건너뜀이면 글 그대로.
- 끈 읽기: 같은 노트 답의 keptNoteText 글 그대로.
- 두 호출 모두 redactText, effort low, timeoutMs 90000이고, 그 판 notes.ts 사본의 함수를 그대로 부릅니다.
- (1.13.0에서 바꿈) §1 켠 읽기(1.13.0): 1.12.0 글 그대로이고, 그 판 트리의 ruleFixLines · renamedLine · usePlaces · isOneSpanFix · parseRuleFix가 1.13.0 것입니다(피할 이름 없는 규칙은 인용된 줄만 후보, 한 줄 구조 분해의 객체 바꿈, 스스로 고친 답은 마지막 온전한 답). 끈 읽기는 같은 노트 답의 keptNoteText 글 그대로입니다.

§2 답이 없거나 상한에 닿은 답
- 노트 호출이 답하지 않으면(빈 답 · 시간 한도 · 오류) 그 견본은 그 회의 L · O에 넣지 않고 수만 적습니다. 그래서 den이 20 아래면 (b), O가 20 아래면 (a)가 못 넘음입니다.
- 규칙 연습 호출이 답하지 않으면 그 노트는 자기 칸 그대로(플러그인과 같음)이고, 그 꼴대로 매깁니다. 상한 닿음 · 빈 답 · 시간 한도는 '답 없음' 줄에 셉니다. API 오류는 수를 적고 다시 부르지 않습니다.
- 상한 닿음은 output_tokens ≥ maxTokens + H_M입니다(계획 고침 D4, M-5: G6의 상한 몫 = H_M, ~~haiku 2048 · sonnet 0, 묶음 1 보정 기록~~ 1.12.0 보정 기록의 haiku 2048 · sonnet 2048). 닿았어도 글이 읽히면 읽힌 대로 매깁니다.
- (1.12.0, 설계 §2를 옮김) 노트 호출이 답하지 않은 견본은 그 회 L · O에서 빼고 수만 적습니다. 규칙 연습 호출의 상한 닿음 · 빈 답(API 거절 포함) · 시간 한도는 '답 없음' 줄에 셉니다(n = 그 모델 두 회의 2단 호출 수). 닿았어도 글이 읽히면 읽힌 대로 매깁니다. 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.12.0 보정).
- (1.13.0에서 바꿈) §2: 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.13.0 보정 기록). 그 밖은 그대로.

§3 L과 O
- 노트 답의 keptNoteText 글에서 noteRuleOf(연습 제목 앞, 제목이 없으면 글 전체)가 `팀 규칙과 다를 수 있음:` 줄(없음 아님)을 읽으면 L, 아니면 O입니다. 한 번 정해 켠 읽기와 끈 읽기에 함께 씁니다.
- `팀 규칙:` 줄만 있으면 O입니다.
- den = L 가운데 그 견본의 violations에 들여쓰기 빼고 40자 이하인 줄이 하나라도 있는 노트.

§4 연습의 종류
- 최종 글(켠 읽기는 withRuleDrill 뒤, 끈 읽기는 keptNoteText 글)에 drillOf(글, changes, 그 읽기의 켬 여부)를 돌립니다.
- rule을 주면 규칙 연습, rule 없이 주면 개념 연습, undefined면 연습 없음입니다.

§5 채점 열쇠 (팀 파일에서 나오며 함께 얼림)
| 규칙 | 쓰라는 이름 | 쓰지 말라는 표지 | 낱말 |
| --- | --- | --- | --- |
| 요청 | apiRequest · api_request | fetch( · requests. | 요청 · API · 서버 |
| 기록 | log.info | console.log · print( | 기록 · 로그 |
| 날짜 | toDateText · to_date_text | toISOString · toJSON · toLocaleDateString · toDateString · getFullYear · getMonth · getDate · getUTCFullYear · getUTCMonth · getUTCDate · strftime · isoformat | 날짜 |
| 설정 | config | process.env · os.environ · os.getenv | 설정 · 환경 변수 |
- 이름과 표지는 holdsName처럼 온전한 이름으로 찾습니다(`fetch(`는 `fetch` 뒤에 공백 없이 여는 괄호, `fetcher(` 안이 아님).
- 들인 규칙: 예시 답이 고칠 줄에는 없는 그 규칙의 쓰라는 이름을 품는 규칙들.
- 짚은 규칙: 노트의 `다를 수 있음` 줄 글에 그 규칙의 쓰라는 이름이나 표지가 있는 규칙들. 하나도 없으면 낱말이 있는 규칙들. 그것도 없으면 없음입니다.

§6 바름 (모두 맞아야 함. 다음을 모두 만족하는 규칙 r이 있어야 함)
- (i) 규칙 연습입니다.
- (ii) r이 들인 규칙이고 짚은 규칙입니다.
- (iii) 고칠 줄이 r의 violations 줄입니다(같은 파일, 공백 · 끝 `;` · `,` 빼고 같음).
- (iv) 예시 답이 r을 지킵니다: r의 쓰라는 이름을 품고, r의 표지가 남지 않으며, 그 줄만 예시 답으로 바꾼 파일의 demo 표준 출력(두 번)이 그 violation의 expected_fixed와 §7 정규화로 같습니다. 규칙과 상관없는 부분을 바꿔 출력이 달라지면 지키지 않음입니다.
- (v) 그 파일이 두 번 모두 오류 없이 돕니다. 원래 파일은 얼리기 전에 대역에서 돈다는 것이 확인되었으므로, 오류는 예시 답 탓으로 셉니다(정의되지 않은 이름 · import 없는 이름 포함).
- (vi) 확인 줄이 있고 그 주장이 §7로 참입니다.

§7 확인 줄
- 돌리는 것: 확인 줄 백틱 안의 첫 호출이 바꾼 파일에 정의된 함수를 부르면 그 호출을 돌립니다. 자리표시(`…` · `[A]` · `<…>`)이거나 말로만 쓴 확인이면 견본의 demo를 돌립니다.
- 변경의 파일에 없는 함수를 부르면 거짓입니다(1.9.0 G15). 확인 줄이 없으면 거짓입니다(A01).
- 돌린 결과 = 호출 값(await한 값) · 표준 출력 줄 · 대역 기록 줄(표준 출력과 따로 모음, §8).
- 주장의 꼴
  - (1) 값(백틱 · 따옴표 안, 또는 수): 정규화한 값이 호출 값과 같거나, 표준 출력이나 기록의 한 줄과 같아야 합니다. 값이 여럿이면 모두입니다(1.9.0 C18).
  - (2) 같음 말('같은 · 그대로 · 똑같이 · 변함없이 · 달라지지 않')만 있으면: 호출 값과 표준 출력이 원래 줄로 돌린 것과 같아야 합니다.
  - (3) 효과 말(그 규칙의 쓰라는 이름, '기록 · 로그가 남', '인증 · 재시도', '설정에서 읽', '날짜 글자로'): 기록 줄에 그 규칙 함수가 그 호출 동안 불린 줄이 있어야 합니다.
  - (4) 섞이면 각 부분이 다 맞아야 합니다.
  - (5) '…라고 가정 · …이면' 같은 조건: 견본 env · responses로 돌린 결과로만 매깁니다. 견본이 그 조건을 주지 않으면 거짓입니다.
  - (6) 그 밖의 꼴(값 · 같음 말 · 효과 말이 없음)은 거짓입니다.
- 정규화: 앞뒤 공백을 떼고 공백을 하나로 줄이며, `'`를 `"`로, 끝 `;`를 뗍니다. 둘 다 JSON으로 읽히면 값으로 견주고, 수는 값으로, 파이썬 True · False · None은 true · false · null로 봅니다.
- 줄인 출력: 말한 값이 맞으면 맞음이고, 말한 값이 하나라도 틀리면 거짓입니다.
- 날짜는 TZ=UTC입니다.

§8 대역과 돌리기
- 팀 모듈 넷(js · ts · py)을 둡니다. apiRequest · api_request, 미리 심은 globalThis.fetch, requests.get이 견본 responses로 같은 응답을 줍니다.
- config와 환경 변수는 견본 env로 같은 글자를 줍니다(`config.X` · `config["X"]` · `config.get("X")` 모두). log.info는 console.log · print와 같은 글을 표준 출력에 찍습니다. toDateText는 UTC YYYY-MM-DD를 줍니다.
- 대역은 불릴 때마다 `[apiRequest] 주소` · `[log.info] 인자` · `[config] 이름` · `[toDateText] 값`을 표준 출력이 아닌 기록 파일에 씁니다.
- 빈 임시 폴더에서 `unshare -n timeout 5`, js `node`, ts `node --experimental-transform-types`, py `python3 -I`로 돌립니다. 파일에 import를 덧붙이지 않습니다. 호출 값은 돌리는 틀이 사본 끝에 붙인 한 줄이 `[value] JSON`으로 찍습니다. (계획 고침 D14: py는 B-14대로 `env -i PATH LANG=C.UTF-8 PYTHONHASHSEED=<n> python3 -s -P -B`를 n = 1~5로 다섯 번 돌려 다섯이 모두 같아야 하고, ts 실행은 B-15의 `node --experimental-transform-types`입니다.)
- 구문 오류 = 바꾼 파일을 불러올 때 SyntaxError(파이썬은 py_compile 실패).
- 돌지 않는 연습(대역이 받치지 못한 경우 포함)은 (v)나 (vi)에서 거짓입니다. 읽어서 매기는 갈래는 없습니다.

§9 표지 없는 규칙 연습
- 개념 연습 가운데, 예시 답이 어떤 규칙의 쓰라는 이름을 고칠 줄에 없이 품는 것입니다.
- 할 일 글은 보지 않습니다. 할 일이 팀을 말하지만 이름을 들이지 않는 연습(1.9.0 G19 꼴)은 개념 연습입니다.
- 켠 읽기와 끈 읽기에서 모두 셉니다.

§10 해로움 (규칙 연습인데 다음 가운데 하나)
- (h1) 들인 규칙이 없음(규칙이 아닌 일을 시킴)
- (h2) 고칠 줄이 들인 규칙 어느 것의 violations 줄도 아님(헛짚은 L · 함정 · R_long에서 낸 규칙 연습 포함)
- (h3) 예시 답에 들인 규칙의 표지가 남음(거꾸로 바꿈 포함)
- (h4) 바꾼 파일에 구문 오류
- 확인 줄만 거짓이거나 (ii) · (iv)의 출력만 다른 것은 바르지 않음이지 해로움이 아닙니다.

§11 W 오탐
- 끈 읽기에서 HEAD fca5988의 ruleLabelled 글과 keptNoteText 글이 다른 노트를 봅니다.
- 그 노트의 연습(HEAD 글을 drillOf(…, false)로 읽은 것)이 다음을 모두 만족하지 않으면 오탐입니다: 고칠 줄이 어떤 규칙 r의 violations 줄이고, 예시 답이 r의 쓰라는 이름을 고칠 줄에 없이 품습니다.
- HEAD 글에서 연습이 읽히지 않던 노트(연습 없음)에 표지가 붙은 것은 오탐이 아닙니다.

§12 (c): O 노트마다 켠 읽기와 끈 읽기의 최종 글을 바이트로 견주고, 켠 회의 호출 기록에 O 노트의 규칙 연습 호출이 없는지 봅니다.

§13 할 일 줄 둘: 최종 노트의 직접 해 보기 칸(합친 칸 포함)에 할 일 줄이 둘 이상인 경우입니다.

§14 옛 창: 3f2b4fb · 7a7b08c · 3690021 · fca5988의 notes.ts 사본(꺼진 상수 그대로)으로 모든 회의 켠 · 끈 최종 글에 drillOf · hideDrillAnswer를 돌립니다.
- (1.12.0에서 더함, 엄격하게) 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988에 3d2f251 · de98243을 더한 여섯입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.
- (1.13.0에서 더함) §14 (더함, 엄격하게): 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988 · 3d2f251 · de98243에 30adc2f(1.12.0)를 더한 일곱입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.

§15 판정 파일
- 스크립트가 행마다 근거(돌린 출력 · 들인 규칙 · 짚은 규칙 · 맞춘 주장 꼴)를 verdicts-<꼬리표>-<회>.md에 먼저 쓰고, 표는 그 파일만 셉니다. (계획 고침 D7: 꼬리표마다 따로 돌려 얼리고, N2는 verdicts-<꼬리표>-n2.md. 모든 판정 파일이 얼려진 뒤 짝 파일을 엽니다.)
- 판정 파일을 쓴 뒤에는 입장 · 열쇠 · 기준을 바꾸지 않습니다.
- 이 글이 정하지 않은 꼴이 나오면 넘는 쪽에 불리하게(바르지 않음 · 해로움 · 오탐 · 표지 없는 규칙 연습) 세고, 그 꼴을 견본.md에 적습니다.
- 기록만 하는 것(판정에 넣지 않음): 할 일이 라벨 설명을 옮겨 적었거나 어느 줄을 어떻게 고칠지 말한 것, 1.9.0 정의의 (b), L 노트가 개념 연습을 규칙 연습으로 바꾼 수, 규칙 연습 호출의 출력 토큰 · 시간.

N2 입장: 1.9.0 N2와 같습니다. 얼린 기대 판정과 견주고, ~~parseCheck(text, { rule: true }) 뒤 '안 지킴 + 맞음 → 거의' 낮추기를 거친 판정으로 셉니다.~~ 1.13.0: 기준의 'gradeDrill이 매기는 대로'는 1.13.0 짓기 트리의 gradeDrill이 학습자에게 보이는 판정입니다. 곧 parseCheck(text, { rule: true })의 '안 지킴 + 맞음 → 거의'를 거친 뒤, 그 판정이 맞음이면 짓기 트리의 ruleGradeCap(sent, ruleFixUse(sent.check), 답 줄, capKnownNames(그 노트의 screened 변경 diff, 그 견본 파일의 after 글), pairLangOf(sent.file), after 글, ruleAvoidsOf(얼린 팀 파일의 규칙, use))이 무엇을 내면 거의로 셉니다. 바른 판정은 그대로(지키고 동작함 → 맞음, 어겼지만 동작함 → 거의 · 틀림, 깨짐 → 틀림 · 거의, 엉뚱함 → 틀림). 낮추기 전 판정(parseCheck의 판정)은 따로 적고, 새 줄 '낮추기 전 (어김 + 깨짐)→맞음 ≤ 2'만 그것으로 셉니다. 바른 판정은 지키고 동작함 → 맞음, 어겼지만 동작함 → 거의 또는 틀림, 깨짐 → 틀림 또는 거의, 엉뚱함 → 틀림입니다.

읽는 법(1.10.0 글의 이름을 1.12.0에서 읽는 자리; 글은 바꾸지 않음)
- §4 '켠 읽기는 withRuleDrill 뒤': 1.12.0에는 withRuleDrill이 없습니다(a4ac818에서 지움). 켠 읽기의 최종 글은 §1의 1.12.0 켠 읽기 글입니다(설계 '공통' §1).
- §11 · 세부 15의 'HEAD fca5988': 1.10.0 때의 말 그대로 fca5988(1.9.0)의 ruleLabelled · drillOf입니다.
- '그 판 트리': 짓기 커밋 a4ac818의 트리(`impl112/b1/mtree`, git archive)입니다.
- 1.10.0 글의 '2단 견본'(N2)은 둘째 스테이지 견본입니다. 1.12.0 글의 '1단' · '2단'(코드가 만든 고침 · 연습 호출)과 다릅니다.
- 세부 21의 '못 넘음 → 넘음이면 새 하위 에이전트가 … 확인해야 그 수를 씀': 1.12.0에서는 결정 규칙 5('못 넘음이 켬으로 바뀌지 않음')와 계획 judges(판정자와 확인자가 갈리면 넘는 쪽에 불리하게, M-9)를 따릅니다. 확인자가 적은 행은 넘는 쪽에 불리하게 세고, 도구 결함을 고쳐 다시 센 수가 못 넘음을 넘음으로 바꾸면 그 수를 쓰지 않고 못 넘음으로 둡니다(더 엄한 쪽).
- 세부 20의 label.py · count.py · route.py, 세부 22의 n2verify.py, 세부 23의 n2judge.mjs, 세부 12의 runlib: 아래 '틀과 도구' 표의 1.12.0 도구입니다. N2 요청을 꼬리표의 모델로 보내는 일은 route.py 대신 `tools/n2build.mjs lines`가 짝 파일을 읽어 하고 짝을 찍지 않습니다.

읽는 법(1.13.0; 글은 바꾸지 않음, 설계 stance.intro)
- 위 글의 '1.12.0'은 '1.13.0'으로, '1.12.0 보정 기록'(또는 '1.12.0 보정')은 '1.13.0 보정 기록'으로 읽습니다. 그 수는 같습니다(H_haiku 2048: 노트 · 2단 5548, N2 2528).
- '그 판 트리': 1.13.0 짓기 커밋 fabef5d의 트리(`impl113/b1/mtree`, git archive)입니다. '짓기 커밋 a4ac818의 트리(`impl112/b1/mtree`)'는 1.12.0의 자리입니다.
- 세부 20의 label.py · count.py · route.py, 세부 21의 행 확인, 세부 22의 n2verify.py, 세부 23의 n2judge.mjs, 세부 12의 runlib: 아래 '틀과 도구' 표의 1.13.0 도구(`impl113/b1/`)입니다. N2 셈은 `tools/n2build.mjs judge`(1.13.0 N2 입장)이고, N2 요청을 꼬리표의 모델로 보내는 일은 `tools/n2build.mjs lines`가 짝 파일을 읽어 하며 짝을 찍지 않습니다.
- 세부 20의 꼬리표: 1.13.0은 haiku 하나만 재므로 꼬리표도 하나입니다(P와 Q 가운데 난수로 고름, 계획 단계 5 '잴 모델이 하나여도 회마다 난수 꼬리표'). 짝 파일은 그 하나를 봉합니다.
- 바꾸지 않은 곳(설계 stance.unchangedNote 글자 그대로): §3 L과 O, §4 연습의 종류, §5 채점 열쇠(요청 · 기록 · 날짜 · 설정의 쓰라는 이름 · 표지 · 낱말 표), §6 바름 (i)–(vi), §7 확인 줄, §8 대역과 돌리기(B-14 py 다섯 번, B-15), §9 표지 없는 규칙 연습, §10 h1–h4, §11 W 오탐, §12 (c), §13 할 일 줄 둘, §15 판정 파일, S-a · S-b · S-c, E1–E7 · E9–E18, 세부 1–24는 1.12.0 글자 그대로입니다.

다시 커밋하는 1.10.0 세부 1 ~ 24 (판정 스크립트가 정한 세부, 432ced4 글 그대로; 바꾼 곳은 ~~ ~~와 1.12.0 글)

1. §5 찾기: 쓰라는 이름은 holdsName 그대로 찾습니다(바로 앞이 글자 · 숫자 · `_` · `$` · `.`이 아니고 바로 뒤가 글자 · 숫자 · `_` · `$`가 아님). 표지도 온전한 이름으로 찾되 바로 앞의 `.`은 됩니다(열쇠의 날짜 표지는 `d.toISOString()`처럼 메서드라서). `(` · `.`로 끝나는 표지(`fetch(` · `print(` · `requests.`)는 그 글자가 이름 바로 뒤에 와야 합니다. 낱말은 글자 그대로 들어 있으면 찾은 것이고, `API`는 대소문자를 가리지 않습니다.
2. §5 짚은 규칙: 노트의 `다를 수 있음` 줄(규칙 연습이 든 rule 줄, noteRuleOf가 읽은 것) 글에서 찾습니다.
3. §6 (iii) 같은 파일: drillOf가 준 file(저장소 기준 경로)과 violations의 file이 같고, 두 줄에서 공백을 모두 빼고 끝 `;` · `,`를 뗀 글이 같음.
4. §6 (iv) · (v) 돌리기: 그 연습 줄(drillOf의 n행, 들여쓰기 그대로)만 예시 답으로 바꾼 파일들로 견본 demo를 첫 파일 끝에서 돌립니다. js · ts 두 번, py 다섯 번(B-14)이 종료 코드 · 표준 출력 · 기록 줄 모두 같아야 하고 종료 코드 0이어야 합니다. 표준 출력은 줄마다(빈 줄 빼고) §7 정규화로 expected_fixed와 견주고, 줄 수도 같아야 합니다. 돌리는 틀이 찍는 `[value] …` 줄도 출력에 듭니다(expected · expected_fixed도 그 줄을 품음).
5. 오류: 종료 코드가 0이 아님(시간 한도 124 포함).
6. §7 첫 호출: 확인 줄의 코드 칸(`` ` `` · `` `` ``) 가운데 `이름(`이 처음 나오는 칸에서, 그 이름부터 짝 괄호까지(앞의 `await`는 뗌). 그 호출이 자리표시(`…` · `...` · `[A]` 꼴 · `<…>`)를 품거나 코드 칸에 호출이 없으면 견본 demo를 돌립니다. 호출한 이름이 바꾼 파일의 맨 위 수준에 정의되어 있으면(js · ts의 function · const · let · var · class, py의 def · class · 이름 =) 그 호출을 바꾼 파일 끝에서 돌리고, 아니면(팀 모듈 · 내장 함수 · 변경의 다른 파일에 있는 함수 포함) 거짓입니다(§7 둘째 줄, 다른 파일의 함수는 글이 정하지 않아 §15).
7. §7 주장: 확인 줄에서 처음 나오는 `→`(또는 `->` · `=>`) 뒤의 글. 화살표가 없으면 확인 줄에서 그 호출의 코드 칸을 뺀 글.
8. §7 (1) 값: 주장 안의 코드 칸(규칙의 쓰라는 이름이나 표지 하나만 든 칸은 빼고), 따옴표(`"` · `'` · `“”` · `‘’` · `「」`) 안의 글, 수(앞뒤에 ASCII 글자 · 숫자 · `_` · `.` · `-`가 붙지 않은 것: `3개`의 3은 수, `2026-10-22`는 수가 아님). 값마다 호출 값(JSON으로 읽히면 값으로, 아니면 글자열 값의 글자나 JSON 글과), 표준 출력의 한 줄(돌리는 틀의 `[value]` 줄 빼고), 기록의 한 줄(`[apiRequest] …` 꼴 그 줄 전체) 가운데 하나와 §7 정규화로 같아야 합니다. 조건(§7 (5))의 값도 값으로 셉니다(조건을 기계로 가르는 글이 없어 §15).
9. §7 (2) 같음 말: 코드 칸 · 따옴표 밖의 글에 `같은` · `그대로` · `똑같이` · `변함없이` · `달라지지 않`이 있으면, 같은 호출을 원래 파일(견본 after)로 돌려 호출 값(§7 정규화)과 표준 출력(줄마다)이 같아야 합니다. 둘 다 오류 없이 돌아야 합니다.
10. §7 (3) 효과 말: 코드 칸 · 따옴표 밖의 글에 그 규칙의 쓰라는 이름이 있거나 쓰라는 이름 하나만 든 코드 칸이 있음, 또는 `(기록|로그)…남` → 기록, `인증` · `재시도` → 요청, `설정에서 읽` → 설정, `날짜 글자로` → 날짜. 말한 규칙마다 그 호출의 기록 줄에 그 대역의 줄(`[apiRequest] ` · `[log.info] ` · `[toDateText] ` · `[config] `로 시작)이 있어야 합니다.
11. §7 (4) · (6): 값 · 같음 말 · 효과 말 가운데 있는 것이 모두 맞아야 참이고, 하나도 없으면 거짓입니다. 확인 호출도 js · ts 두 번, py 다섯 번이 모두 같아야 하며, 다르면 거짓입니다.
12. §8 틀: 빈 임시 폴더에 대역(아래 runlib)과 견본 파일(같은 경로면 견본 파일이 대역을 갈음)을 두고, `unshare -n timeout 5 env -i PATH=… LANG=C.UTF-8 TZ=UTC <견본 env>`로 돌립니다(py는 PYTHONHASHSEED=1~5를 더하고 `python3 -s -P -B`로 폴더 맨 위의 실행 파일을 돌려, 그 파일이 폴더를 sys.path에 넣고 모듈을 run_name `__learnrun__`로 돌림. 그래서 `if __name__ == "__main__":` 아래는 돌지 않음). js · ts는 `node`(ts는 `--experimental-transform-types`)에 `--import`로 미리 심은 globalThis.fetch(견본 responses, 기록 없음)를 둡니다. 호출 값 줄은 js · ts `console.log('[value] ' + (JSON.stringify(await (호출)) ?? 'null'))`, py `print('[value] ' + __import__('json').dumps((호출), ensure_ascii=False, default=str))`이고(파일에 import 문을 더하지 않음), 응답은 주소가 품은 첫 키의 값(상태 200), 맞는 키가 없으면 404와 `{}`입니다.
13. §8 구문 오류: js · ts는 바꾼 파일을 그것 하나만 진입점으로 불러(호출 없이) 종료 코드가 0이 아니고 stderr에 `SyntaxError`가 있음(node `--check`는 ts를 검사하지 않음), py는 py_compile이 실패함.
14. §9: 켠 읽기와 끈 읽기의 개념 연습마다, §5 '들인 규칙'이 하나라도 있으면 셉니다.
15. §11: fca5988의 조합 `ruleLabelled(closeConceptBold(cut(답, 9000)))`(= keptNoteText(답, []), 시험으로 고정)과 keptNoteText(답, names)가 다른 노트에서, fca5988 글을 fca5988의 drillOf(…, false)로 읽은 연습을 봅니다.
16. §13: 직접 해 보기 칸(제목에서 다음 제목까지, ruleLabelled가 칸을 가르는 그대로)마다 taskLineOf가 읽는 할 일 줄을 셉니다. 한 칸이라도 둘 이상이면 셉니다. 켠 읽기 · 끈 읽기 모두, 답한 모든 노트에서 셉니다(B-6).
17. (b)의 '해로운 연습 0' · '할 일 줄 둘인 노트 0'은 den만이 아니라 그 회의 답한 모든 노트에서 셉니다(B-6). '바른 규칙 연습 80%'는 den 노트의 켠 읽기 규칙 연습 가운데 바름 수 ÷ den입니다.
18. 규칙 연습 호출의 답 없음 줄: 두 회를 합친 규칙 연습 호출 n번 가운데 상한 닿음 · 빈 답 · 시간 한도인 것이 max(1, ⌊n / 60⌋)개 이하. 상한 닿음은 output_tokens ≥ maxTokens + H_M(~~haiku 2048 · sonnet 0~~ 1.12.0 보정: haiku 2048 · sonnet 2048, 곧 2단 호출 5548; 1.13.0 보정 기록도 haiku 2048, 곧 5548)이고, 답한 호출도 닿았으면 셉니다. (1.12.0) 규칙 연습 호출은 2단 호출이고(1단 · 건너뜀은 호출 없음), 빈 답은 API 거절을 포함합니다(E18).
19. §14: 표지 노트 = 최종 글에 `- 할 일 (팀 규칙):`로 시작하는 줄이 있는 노트. 옛 창 ~~넷~~ ~~여섯(1.12.0, §14)~~ 일곱(1.13.0, §14)의 drillOf가 연습을 주지 않고, 그 창 패널이 부르는 꼴의 hideDrillAnswer 글에 `고칠 줄` · `예시 답` 라벨 줄이 없어야 합니다. 표지 없는 노트는 그 창의 drillOf가 ~~1.10.0의 그 읽기(켬 · 끔)~~ 3d2f251의 drillOf로 그 읽기(켬 · 끔)를 한 것(1.12.0, §14)과 같은 할 일 · 고칠 줄 · 예시 답 · 파일 · 행을 줘야 합니다. 켠 · 끈 최종 글 모두, ~~네~~ ~~여섯~~ 일곱(1.13.0) 창 모두입니다.
20. 꼬리표(M-8, 결정 D7): 회 A · B와 헷갈리지 않게 P · Q로 씁니다. 이 G의 모든 스테이지(N1′ 회 A · B와 N2)에 한 번 뽑은 짝을 쓰고(N2 견본이 그 꼬리표 회 A에서 나오므로), pair.json을 얼려 sha256만 적습니다. label.py가 꼬리표 파일에서 모델 이름 · 시간 · 토큰 · 상한을 빼고, 그 수는 count.py만 셉니다. N2 요청을 그 꼬리표의 모델로 보내는 일은 route.py가 짝 파일을 읽어 하고 짝을 찍지 않습니다. 부르는 쪽(이 묶음을 짓는 쪽)은 어느 모델을 부르는지 압니다. 그래서 두 모델의 그 스테이지 답이 얼려지기 전에는 답 글을 열지 않고(M-3), 판정은 스크립트가 꼬리표 파일로만 합니다.
21. 판정 파일 행 확인(설계 '사람은 스크립트가 입장 글대로 셌는지를 행마다 확인'): 꼬리표마다 새 하위 에이전트 하나(`claude -p --model opus --tools ''`, 그 꼬리표의 판정 파일과 이 절의 입장 · 세부만 받음, 한 하위 에이전트가 두 꼬리표를 보지 않음)가 글대로 세지 않은 행을 적습니다. 적힌 행이 있으면 M-15대로 합니다(글이 이김, 도구를 고쳐 두 꼬리표를 다시 세고 전후 수를 모두 적으며, 못 넘음 → 넘음이면 새 하위 에이전트가 '글을 옮긴 고침'임을 확인해야 그 수를 씀).
22. N2 대역 확인(n2verify.py, 결정 D8 (2)): gradeDrill이 부르지 않는 줄(빈 줄, sameLine으로 예시 답 · 고칠 줄과 같음, 한글 자판)은 못 넘음. 그 연습 줄만 답 줄로 바꾼 파일로 demo를 돌려(js · ts 두 번, py 다섯 번) 갈래마다: keep = 모두 같음 · 종료 0 · r의 쓰라는 이름 있음 · r의 표지 없음 · 출력이 예시 답의 출력과 같음, break = 모두 같음 · 종료 0 · (r의 표지 있음 또는 쓰라는 이름 없음), broken = 쓰라는 이름 있음 · (돌릴 때마다 다름 또는 종료가 0이 아님 또는 출력이 예시 답과 다름), off = 쓰라는 이름 없음 · (종료가 0이 아님 또는 출력이 예시 답과 다름). 못 넘은 본 답은 그 연습의 같은 갈래 예비가 넘으면 그것으로 채우고, 아니면 빼고 그 수를 적습니다(고쳐 쓰지 않음). 기대 판정: keep 맞음, break 거의 · 틀림, broken 틀림 · 거의, off 틀림(N2 입장).
23. N2 셈(n2judge.mjs): 답 없음 · 읽지 못한 답은 바른 판정이 아니고 `규칙:` 줄 빠짐으로도 셉니다(B-8). 회마다 바른 판정 27개 이상 · 어김(break)→맞음 1개 이하 · 깨짐(broken)→맞음 0 · `규칙:` 줄 빠짐 1개 이하, 두 번 모두 넘어야 N2 넘음.
24. 기록만 하는 것(판정에 넣지 않음): 1.9.0 정의의 (b)(L 전체를 분모로), L 노트가 개념 연습인 수 · 연습 없는 수, 할 일에 `한 문장으로` · `어느 줄을`이 든 규칙 연습 수(라벨 설명을 옮긴 꼴의 어림), 규칙 연습 호출 결과의 꼴, 호출마다의 output_tokens · 시간(count.py).


#### 결정 규칙

설계 decisionRule 글(옮김)
1. 모델 m ∈ {haiku, sonnet}마다, m의 수로만, 다시 굴리기 없이: isRuleDrill_m = 기준 커밋에서 MODEL_SWITCHES[m].isRuleWide가 true ∧ W 줄이 두 회 모두에서 넘음 ∧ N1′의 모든 줄이 회 A와 회 B에서 넘음 ∧ N2가 두 번 모두 넘음(바른 판정 ≥ 27, 어김→맞음 ≤ 1, 깨짐→맞음 = 0, 규칙 빠짐 ≤ 1, 지킴 낮춤 = 0, 낮추기 전 (어김+깨짐)→맞음 ≤ 2) — 아니면 false.
2. 1.13.0에서 재지 않은 모델(기본으로 sonnet)은 끔 그대로입니다; haiku에서 넘겨받지 않습니다.
3. 무효인 회(M-4, M-10) → 그 모델은 끔, 1.13.0에서 다시 재지 않음. 정하지 못한 꼴은 못 넘는 쪽으로 셉니다.
4. isRuleWide_m은 다시 정하지 않습니다; W 오탐은 isRuleDrill_m만 막습니다(적음).
5. 스위치 줄은 결정 커밋 다음 커밋에서만 바뀌고, 그때 옛 창 확인(30adc2f를 포함한 notes.ts 일곱)과 coexist19를 켠 값으로 다시 돌립니다(R9). 잰 요청을 짓는 코드나 문장을 그 뒤에 바꾸면 그 칸은 끔이 됩니다(D26 재확인).

계획 묶음 1의 글(같은 규칙): isRuleDrill_haiku = 기준 커밋에서 MODEL_SWITCHES.haiku.isRuleWide가 true ∧ W가 두 회 모두 넘음 ∧ N1′의 모든 줄이 A와 B에서 넘음 ∧ N2가 두 번 모두 넘음; 아니면 false. sonnet은 재지 않으므로 → false 그대로(넘겨받지 않음). isRuleWide_m은 다시 정하지 않습니다; W 오탐은 isRuleDrill만 막습니다.

- 판정자(계획 judges): 꼬리표마다 얼린 기계 판정자(`impl112/b1/tools/judge.py` + `key.py`를 다시 지은 것, 1.13.0 입장의 더함 E19ff를 넣고, 기준 커밋에서 해시를 적고, 커밋된 입장과 줄마다 다시 견줌; 이 묶음의 `tools/judge.py`)와 그 꼬리표만 보는 새 opus 행 확인자 하나(D7). 판정자와 확인자가 갈리면 못 넘는 쪽으로 셉니다(M-9). N2: 낮추기 전 판정과 항목마다 낮춘 까닭을 포함한 기계 셈(`tools/n2build.mjs judge`)과 새 opus 확인자 하나(`tools/n2check.py`). 확인자가 적은 행은 모두 못 넘는 쪽으로 셉니다(`tools/decide.py`).
- 멈춤(계획 stop, 옮김)
  - 조건 (a) → 묶음 통째로 건너뜀(묶음 0에 적음). 걸리지 않았습니다(H_haiku 2048).
  - 짓기 트리에서 isRuleWide나 G2 haiku의 D26 다름 → 짓기 커밋 전에 고침; 같게 만들 수 없으면 멈추고 알림. 짓기에서 다름 0이었습니다.
  - 회 무효(M-10)나 M-4 → isRuleDrill haiku 끔, 다시 재지 않음.
  - 회 A의 바른 연습이 5개보다 적음 → N2 못 넘음(셈).
  - 끈 읽기의 W 오탐 → isRuleDrill haiku만 막고 isRuleWide는 그대로(적음).
  - 같은 호출에서 쓰는 쪽이 두 번 거절됨(commonPerBatch.writerRunner의 거절; 사용량 한도로 끝난 것은 WAIT) → STOP, 재지 않음(적음).

#### 모델마다 (설계 perModel, 기록만 · B-12, 결정에 들지 않음)

- haiku: 잼. 개발 기록(B-12, 새 세트 2개, 노트 75개; 마지막 상한으로 다시 읽음): N1′의 반드시 0인 줄 모두 0(해로움 0, 두 읽기의 할 일 둘 0, 함정 0/12, 표지 없음 0, (c) 0, W 오탐 0), den 26 바름 24 = 92.3%(92.9% / 91.7%), 2단 답 없음 0/19, 거절 0; 작은 N2 28/29와 30/30, 어김→맞음 0, 깨짐→맞음 0, 빠짐 0, 지킴 낮춤 0, 낮추기 전 (어김+깨짐)→맞음 1과 1(≤ 2). 1.12.0에서 실패한 꼴이 개발에서 두 번 다시 나왔고 상한이 둘 다 잡았습니다. 넘을 확률 약 55–60%(위험: 상한이 볼 수 없는 깨짐 꼴을 맞음이라 함, N2마다 약 10–20%; 상한이 낮추는 지킴 꼴, 약 5%; den 여유).
- sonnet: 1.13.0에서 재지 않음(기본값). 개발 수는 모든 줄 이상입니다(den 41 바름 38 = 92.7%, 노트 75개에서 반드시 0인 줄 모두 0, N2 두 번 모두 29/30, 거절 0). 그러나 상한은 sonnet에 잰 이득을 주지 않으며(1.12.0 잼과 1.13.0 개발에서 sonnet 혼자 낸 break/broken→맞음 0), 1.12.0의 유일한 실패인 자기 낸 노트 호출의 끈 읽기 할 일 둘은 이 설계로 바뀌지 않습니다: 한 회는 같은 실패 줄을 다시 굴리는 것입니다(그 줄을 넘을 확률 약 39%, 전체 약 30%). 바뀌어야 할 것: 주인이 isRuleDrill의 할 일 둘 줄은 켠(저장되는) 읽기만 센다고 정함(ownerQuestions[0] (a)), 또는 이 확률로 재는 것을 분명히 받아들임((b)), 또는 sonnet용 isRuleWide/노트 호출 설계를 따로 만들어 스스로 고쳐 쓰는 할 일 둘 노트를 없앰(그 자신의 D26 결과).

#### 견본의 짜임

설계 samples 글(옮김)
- 새 얼린 견본 세트 하나, 1.12.0 짜임 글자 그대로(85 + 예비): R 40(규칙마다 10; js 14 · ts 12 · py 14), R_long 4, F 12, N 12, 함정 9(규칙 모듈 ×4, 규칙마다 하나, py ≥ 1, ts ≥ 1; 테스트 ×2; 빌드 스크립트 ×1; 쓰라는 이름을 내보내는 줄기 아닌 모듈 ×1; process.env를 읽는 `*.config.*` 파일 ×1), multi 4, double 4. 같은 팀 파일(규칙 넷 + `## 용어` 2, 그대로)과 열쇠 §5. 두 모델용으로 씀(sonnet은 주인이 켤 때만 같은 세트를 씀, ownerQuestions[0]); haiku 스테이지 먼저.
- 쓰는 쪽: 새 `claude -p --model opus --tools ''` 하위 에이전트, 호출마다 기록 10개 이하, 호출마다 세트 종류 하나(G3 STOP 교훈: 약 12번, 예: R 10개씩 4번, R_long+F 2, N 2, 함정 9개 1번, multi+double 1, 그리고 예비). 각자 팀 파일, 모듈 표, 견본 JSON 꼴, 1.10.0 작성 규칙(규칙마다 표지; 표지 · 호출 꼴 · 인자 수는 마음대로)과 이름만 든 피할 목록(견본.md 글은 절대 아님)만 받습니다. RULE_DRILL_SYSTEM, ruleDrillPrompt, ruleFixPlan, ruleGradeCap, notePrompt, RULE_CHECK, ruleLabelled, 이 설계, 입장, 어느 모델을 재는지는 보지 않습니다. 도구 호출 글을 찍거나 거절된 쓰는 쪽은 같은 입력으로 한 번 다시 돌리고(기록), 고쳐 쓰지 않습니다.
- 얼릴 때 확인(모델 호출 0), 1.12.0과 같음: JSON이 읽힘; demo가 §8대로 돌고 expected와 같음; violation마다 fix로 돌린 것이 돌고 적힌 그대로 돌린 것보다 대역 기록을 더 많이 씀(엄격한 S1), 그 표준 출력은 expected_fixed로 얼림; violation 줄은 `after`에 있고 §5 표지를 품으며, fix는 쓰라는 이름을 품고 표지가 없음; 함정이 아닌 견본의 표지 줄은 모두 violation(F: 주석/문자열 안에만 있는 표지 글자는 됨); R/multi/double은 들여쓰기 빼고 40자 이하, R_long ≥ 41; R/multi/double은 그 모듈을 import함; F/N/함정의 violations는 빔; 개발 경로와 같은 파일 경로는 거절. 못 넘은 견본은 같은 무리 예비로 id 차례대로 바꾸고, 고쳐 쓰지 않습니다; 바꾼 수를 적습니다. samples.json, team.md, 열쇠를 얼림(chmod 444, sha256, 쓴 쪽, UTC 시각을 견본.md에).
- 둘째 스테이지: 잰 꼬리표마다 N2: pick.py가 그 꼬리표의 회 A에서 바른 연습 5개를 고릅니다(규칙 넷 모두, py ≥ 1, ts ≥ 1; 채울 수 없는 조건은 빼고 적음; 바른 것이 5개보다 적으면 → N2 못 넘음). 고른 연습마다 새 opus 쓰는 쪽 하나(호출마다 답 10개 이하, 얼린 1.12.0 틀에 그 연습 하나만; gradeDrill이 보이는 대로의 연습 — 코드가 쓴 할 일과 확인, 줄, 예시, 규칙 줄, 파일, demo — 와 팀 파일만 봄)가 지킴 2 · 어김 2 · 깨짐 1 · 엉뚱함 1과 갈래마다 예비 하나를 씁니다; n2verify(세부 22)가 얼리기 전에 돌려 봅니다; 예비로 채우고, 고쳐 쓰지 않습니다.
- 겹치지 않을 개발 이름
  - 1.13.0 개발 id: E1A01-E1A10, E1B01-E1B10, E1C01-E1C08, E1D01-E1D10(세트 1, 얼린 36개, sha256 10491a07…)과 E2A01-E2A10, E2B01-E2B10, E2C01-E2C10, E2D01-E2D10(세트 2, 얼린 39개 + 뺀 E2A08, sha256 c3d309c5…); E1A01-E1A10, E1B04, E1B06의 상한 모음 답.
  - 이름(파일 이름과 식별자): `impl113/NAMES-all.txt`에서 'G6-dev-113' 꼬리표를 단 209개(`impl113/design/G6/dev/set1/names.txt` 94, `impl113/design/G6/dev/set2/names.txt` 115).
  - 앞선 G6 이름: `impl113/NAMES-all.txt`의 모든 'G6-dev'(1.12.0 개발 D1A01–D4B24, 이름 1214) 줄과 'G6-measured'(1.12.0 GA–GD, 이름 337) 줄, 견본.md의 모든 id(1.10.0 TA/TB/TC/TD; 1.9.0 C/G id; 1.12.0 GA–GD). 잰 쓰는 쪽은 그 합집합을 이름만 든 피할 목록으로 받고, check.py는 파일 경로가 그 경로 가운데 하나와 같은 견본을 거절합니다.

계획 묶음 1의 글(옮김)
- 짜임: 새 얼린 세트 하나, 1.12.0 짜임 글자 그대로(85 + 예비): R 40(규칙마다 10; js 14 · ts 12 · py 14), R_long 4, F 12, N 12, 함정 9(규칙 모듈 ×4, 규칙마다 하나, py ≥ 1, ts ≥ 1; 테스트 ×2; 빌드 스크립트 ×1; 쓰라는 이름을 내보내는 줄기 아닌 모듈 ×1; process.env를 읽는 *.config.* 파일 ×1), multi 4, double 4; 팀 파일 = 1.10.0 것 그대로(규칙 4 + 용어 2); 열쇠 §5. 원칙상 두 모델용으로 씀(sonnet 스테이지는 주인이 1/4 첫 커밋 전에 ownerQuestions 15에 (a)/(b)로 답할 때만 돎; 답이 오지 않아 돌지 않음); haiku 스테이지 먼저.
- 쓰는 쪽: 새 눈가림 opus 쓰는 쪽, 호출마다 기록 10개 이하, 호출마다 세트 종류 하나. 기준 커밋은 이것을 설계의 'R_long+F 2 … multi+double 1'에서 바꾼 쓰는 쪽 짜임으로 밝힙니다(기반 짜임이지 기준 줄이 아님). R 10개씩 4번(규칙마다 하나, 언어 섞임은 고루); R_long 4(1번); F 12를 6개씩 2번; N 12를 6개씩 2번; 함정 9(1번); multi 4(1번); double 4(1번). 세트 종류마다 예비 호출 하나(각 예비 ≤ 10; 수는 기준 커밋에서 정함)로 모두 약 18번. 쓰는 쪽마다 팀 파일, 모듈 표, 견본 JSON 꼴, 1.10.0 작성 규칙, avoid113.py의 이름 목록만 봅니다. RULE_DRILL_SYSTEM, ruleDrillPrompt, ruleFixPlan, ruleGradeCap, notePrompt, RULE_CHECK, ruleLabelled, 설계, 입장, 어느 모델을 재는지는 보지 않습니다. 예비 뒤에도 수를 못 채우면: 그 종류의 미리 정한 보충 호출 하나, 그다음 STOP(재지 않음, 적음).
- 얼릴 때 확인: 모델 호출 0, 1.12.0처럼: JSON이 읽힘; demo를 돌린 것 = expected; violation마다 fix로 돌린 것이 대역 기록을 더 많이 씀(엄격한 S1), 표준 출력은 expected_fixed로 얼림; violation 줄은 after에 있고 §5 표지를 품으며, fix는 쓰라는 이름을 품고 표지가 없음; 함정이 아닌 견본의 표지 줄은 모두 violation; R/multi/double ≤ 40자(들여쓰기 빼고), R_long ≥ 41; R/multi/double은 모듈을 import함; F/N/함정의 violations는 빔; impl113/NAMES-all.txt나 넓힌 겹침 모음(commonPerBatch.freezeCheckInputs)의 어느 개발 경로나 앞서 잰 경로와 같은 파일 경로는 거절. 못 넘은 견본은 같은 무리 예비로 id 차례대로 바꾸고, 고쳐 쓰지 않음; 바꾼 수를 적음. samples.json, team.md, 열쇠를 얼림(chmod 444, sha256, 쓴 쪽, UTC를 견본.md에). id는 NAMES-all.txt와 견본.md에 없음을 확인한 새 머리 글자를 씀(제안 HA–HD).
- 둘째 스테이지: 회 A에서 haiku 꼬리표의 N2: pick.py가 바른 연습 5개를 고름(규칙 넷 모두, py ≥ 1, ts ≥ 1; 채울 수 없는 조건은 빼고 적음; 바른 것이 5개보다 적으면 → N2 못 넘음). 고른 연습마다 새 opus 쓰는 쪽 하나: 호출마다 답 10개(지킴 2 · 어김 2 · 깨짐 1 · 엉뚱함 1 + 갈래마다 예비 하나). 이것은 '호출마다 세트 종류 하나'의 밝혀 둔 예외입니다: 연습 하나의 답 갈래 넷, 기록 10개, 기준 커밋에 그 수와 함께 이름으로 적음(이 줄). gradeDrill이 보이는 대로의 연습과 팀 파일만 봄; n2verify가 얼리기 전에 돌려 봄; 예비로 채우고, 고쳐 쓰지 않음.
- 피할 목록: 그 스테이지가 시작할 때 NAMES-all.txt에 돌린 avoid113.py의 출력(calibration.avoidBuilder): 모든 G6 꼬리표(G6-dev, G6-measured, G6-dev-113: E1A01–E1D10, E2A01–E2D10과 그 파일 경로)의 개념 · 파일 · 코드 이름, 다른 모든 G의 개발과 잰 기록 파일의 이름, 그리고 거르기를 넘는 견본.md 이름 칸. check.py(NAMES_FILE = impl113/NAMES-all.txt)는 파일 경로가 온전한 이름 목록(commonPerBatch.freezeCheckInputs)의 어느 경로와 같은 견본을 거절합니다.

이 묶음이 정한 것(위 글을 도구로 옮긴 자리, 기록)
- 쓰는 쪽 짜임(`gen/parts.json`): 본 호출 12번(견본 85) + 예비 호출 7번(예비 23) = 19번. 계획의 '약 18번'은 R 4 + R_long 1 + F 2 + N 2 + 함정 1 + multi 1 + double 1 = 12번에 예비 7번을 더한 19번입니다(계획 글의 셈 그대로; '약'). 모두 호출마다 세트 종류 하나, 기록 10개 이하입니다.

| 부분 | 종류 | id | 수 · 언어 | 사슬 |
| --- | --- | --- | --- | --- |
| RA | R, request | HA01–HA10 | 10 · js 3 · ts 3 · py 4 | A |
| RB | R, log | HB01–HB10 | 10 · js 4 · ts 3 · py 3 | A |
| RC | R, date | HC01–HC10 | 10 · js 3 · ts 3 · py 4 | A |
| RD | R, config | HD01–HD10 | 10 · js 4 · ts 3 · py 3 | A |
| RL | R_long | HE01–HE04 | 4 · 규칙과 언어는 쓰는 쪽이 고름 | B |
| F1 · F2 | F | HF01–HF06 · HF07–HF12 | 6 + 6 · 셋이 고루 | B |
| NA · NB | N | HN01–HN06 · HN07–HN12 | 6 + 6 · 셋이 고루 | B |
| T | 함정 | HT01–HT09 | module request · log · date · config(py ≥ 1, ts ≥ 1), test ×2, script, export, config | C |
| M | multi | HM01–HM04 | 4 | C |
| W | double | HW01–HW04 | 4 | C |
| RS | R 예비 | HR01–HR08 | 8 · 규칙마다 2 | A |
| LS | R_long 예비 | HL01–HL02 | 2 | A |
| FS | F 예비 | HS01–HS03 | 3 | B |
| NS | N 예비 | HO01–HO03 | 3 | C |
| TS | 함정 예비 | HQ01–HQ03 | module(아무 규칙), export, config | C |
| MS | multi 예비 | HK01–HK02 | 2 | C |
| WS | double 예비 | HP01–HP02 | 2 | C |
| TU-R · TU-L · TU-F · TU-N · TU-T · TU-M · TU-W | 미리 정한 보충(그 종류가 예비 뒤에도 모자랄 때만, 종류마다 한 번) | HUR01–08 · HUL01–02 · HUF01–03 · HUN01–03 · HUT01–03 · HUM01–02 · HUW01–02 | 그 종류의 예비 호출과 같은 짜임 | 따로 |

- 머리 글자 HA · HB · HC · HD · HE · HF · HN · HT · HM · HW · HR · HL · HS · HO · HQ · HK · HP · HU는 NAMES-all.txt에도 견본.md에도 없습니다(확인함). 규칙마다 R의 언어 수는 1.12.0과 같습니다(합 js 14 · ts 12 · py 14).
- 바꾸는 차례(check.py RESERVES, id 차례): R HR01–HR08, 그다음 HUR01–HUR08; R_long HL01–HL02, HUL01–HUL02; F HS01–HS03, HUF01–HUF03; N HO01–HO03, HUN01–HUN03; 함정 HQ01–HQ03, HUT01–HUT03; multi HK01–HK02, HUM01–HUM02; double HP01–HP02, HUW01–HUW02.
- 보충 차례: 먼저 `OUTDIR=frozen-pre`로 check.py를 돌려(기록) 예비 뒤에도 모자란 종류를 봅니다. 모자란 종류마다 그 보충 호출 하나(`gen/run.sh <root> topup <K>`, 자기 폴더, CHAIN_ROOT = 견본 폴더)를 부르고, 그다음 extract.py와 check.py를 `frozen/`에 한 번 돌립니다. 그래도 모자라면 STOP(재지 않음, 적음).
- 쓰는 쪽 프롬프트 = `gen/common.md` + 부분 단락(`gen/parts.py`가 1.12.0 부분 글에서 지음: id, 종류, 규칙, 언어, 그 종류의 1.12.0 글) + 같은 사슬의 앞 부분이 이미 쓴 파일 경로와 demo 함수 이름('다시 쓰지 마라') + 피할 단락(그 쓰는 쪽 스테이지가 시작할 때 `gen/avoid113.py`, `impl113/gen/avoid113.py`와 바이트까지 같음). 세 사슬 A · B · C는 나란히 돌고 사슬 안에서는 차례대로 돕니다.
- 틀 고침(피할 목록 짓기 합성 시험 (1)이 틀에 걸려 기준 커밋 전에 고침, 그 바꿈을 적음): 1.12.0 `gen/common.md`(`1d55fe37…de4c`)와 `gen/n2-frame.md`(`e5ea60af…7d78`)에서 (1) '견본'이라는 낱말(거르기 (b) 패턴의 하나)을 '사례'로 바꾸고 조사를 맞춤, (2) common.md 피할 이름 줄에서 손으로 적은 여섯 이름(storeMap, buildInfo, unansweredCount, searchProducts, format_date, countPassing)을 빼고 '맨 끝 피할 이름 절의 이름 모두'만 남김(피할 목록은 짓기 도구의 출력만; 여섯 모두 짓기 도구의 출력에 들어 있음을 확인함), (3) n2-frame.md는 연습 하나에 대한 글로 바꿈('연습마다' → '연습 하나에 대해', 출력 꼴의 끝 '…' 뺌). 그 밖의 글은 그대로입니다.
- 피할 목록 거르기(짓기 도구가 쓰는 그대로, 위 '피할 목록 짓기'를 옮김)
  - (a) 개념 이름은 꼬리표가 '견본'이 아닌 줄(기록 파일)에서만 옵니다: 개발 이름의 ': ' 앞 주제, 2–30자, avoid.py와 같음. '견본' 꼬리표 줄은 개념 이름을 주지 않습니다.
  - (b) 대소문자를 가리지 않고 haiku|sonnet|opus|fable|claude|anthropic|model|isRule|rung|isThink|isBase|isChanged|worked|stance|judge|verdict|calib|impl11|alias|gateway|bedrock|vertex|override|provider|모델|채점|견본|판정|프롬프트에 맞는 항목(개념, 파일, 코드 이름; 어느 줄에서 왔든)은 모두 뺍니다.
  - (c) 파일 이름과 코드 이름은 기록 파일 줄(꼬리표 ≠ '견본')과 names.json에서 옵니다. '견본' 꼬리표 줄은 다음일 때만 파일이나 코드 이름을 줍니다: 공백이 없음; 경로의 어느 부분도 judge, tools, calib, gen, stage, frozen, pilot, audit, review, fix, sw, cli, probe, d26, oldprobe, proofs, design, b<숫자>, b<숫자>r, impl11<숫자>가 아님; 경로의 마지막 부분이 impl111 · impl112 · impl113 아래 어느 tools.sha256 / SHA256SUMS 표에 적힌 파일 이름도 아님. 공백이 든 '견본' 항목(글 조각)은 쓰지 않습니다.
  - (c′) 도구 이름 목록에 있는 파일 이름은 어느 줄에서 왔든 파일 목록에서 뺍니다.
- 얼릴 때 확인(`tools/check.py`; 1.12.0 check.py에 M-15 고침(모듈 함정의 팀 모듈 경로)을 처음부터 넣은 check2.py에서 지음): 위 계획 글의 확인 모두. 거절하는 경로 = NAMES_FILE(`impl113/NAMES-all.txt`, 그 순간의 sha256을 보고서에 적음)의 빗금 든 항목 모두(모든 꼬리표) ∪ 겹침 모음(`impl113/design/*/dev`, `impl113/design/*/pilot`, `impl113/b*/frozen`, `impl112/design/*/dev`, `impl112/b1/frozen`, `impl112/b2/frozen`, `impl112/b3r/frozen` · `dev`, `impl112/b4/frozen` 아래 JSON 기록의 'path' · 'file' 값 가운데 빗금 든 것; 지금 1,352 파일에서 경로 2,419개). 더해서(1.13.0, 더 엄함): 파일 이름(경로의 마지막 부분)이 기록 파일 줄(꼬리표 ≠ '견본')의 파일 이름이거나 겹침 모음 경로의 마지막 부분이면 거절합니다. 쓰는 쪽 틀의 모듈 표에 있는 팀 모듈 파일 이름 열둘(apiRequest.js/.ts, log.js/.ts, dateText.js/.ts, config.js/.ts, api_request.py, log.py, date_text.py, config.py)은 주어진 이름이라 이 규칙에서 뺍니다. 이것으로 얼릴 때 확인 입력의 합성 시험 (1)(`impl113/design/G6/dev/set1/names.txt`의 파일 이름으로 쓴 견본)이 거절이 됩니다(그 names.txt는 경로가 아니라 파일 이름 목록). G6 견본 기록에는 개념 칸이 없고 이 확인에는 인용 · 코드 겹침 규칙이 없어, 합성 시험 (2)는 'G2-dev-113' 경로로 보이고(그 목록 전체를 읽음을 보임) (3)은 해당이 없습니다.
- 팀 파일과 채점 열쇠: `impl113/b1/team.md`(sha256 `18f9d5c755f49db4f9dd767b380bdda569609ffa6a6021ca9f9525881a9b0c9b`, 1.12.0 `impl112/b1/team.md` · 1.13.0 개발 세트의 팀 파일과 바이트까지 같음). 채점 열쇠(§5 표)도 그대로이고, 도구에서는 `tools/key.py`(1.12.0과 바이트까지 같음)입니다. 대역 모듈의 자리(작성 프롬프트와 대역에만): js · ts `src/api/apiRequest` · `src/log` · `src/dateText` · `src/config`, py `app/api/api_request.py` · `app/log.py` · `app/date_text.py` · `app/config.py`.

#### 부르기

설계 calls 글(옮김)
- 플러그인과 똑같이(D20), 프로브 mod가 $.model.complete({ model: 'haiku'(설정 글자 그대로), effort: 'low', system, prompt: redactText(prompt).text, maxTokens, timeoutMs })를 부르며, 4개씩, $.clock으로 시간을 재고, 답은 fixEscapedTicks를 거칩니다. 1.13.0 보정의 고정한 CLI 사본; DISABLE_AUTOUPDATER=1; 회마다 앞뒤로 claude --version, init model과 modelUsage 키(M-10).
- 노트: SYSTEM, notePrompt(screened, 'beginner', [], team)(1.8.0 바이트), maxTokens NOTE_TOKENS 3500, timeoutMs 90000.
- 연습: 짓기 트리의 writeNote 길: keptNoteText(답, ruleNamesOf(rules)) → noteRuleOf → ruleFixPlan(screened, rules, said). 1단: 호출 없음. 2단: system RULE_DRILL_SYSTEM, prompt redactText(ruleDrillPrompt(screened, rules, said, cands)).text, maxTokens RULE_DRILL_TOKENS 3500, timeoutMs 90000, kind 'note', 'manual', 그다음 ruleFixReply. 건너뜀: 호출 없음.
- N2 채점(첫 시도만): CHECK_SYSTEM, redactText(checkPrompt({ name: '팀 규칙', question: drillQuestion(sent), answer: sent.example, kind: 'modify' }, `${sent.indent}${mine}`, 'beginner', undefined, undefined, { rule: sent.rule })).text, maxTokens 480, timeoutMs 60000, 두 번; 그다음 parseCheck(text, { rule: true })와 짓기 트리의 ruleGradeCap(sent, ruleFixUse(sent.check), mine, capKnownNames(screened diff들, after 파일), pairLangOf(sent.file), after 파일, ruleAvoidsOf(team.rules, use)) — 호출 없음.
- 다시 보내지 않음: 빈 답, 상한 닿음, 시간 한도. API 오류는 적고 다시 보내지 않음; 한 모델-스테이지의 10%를 넘으면 → M-4(무효, 끔). 스테이지마다 빈 답은 모두 탭으로 한 번 다시 보내 stop_reason/stop_details만 적음(기록).
- 첫 호출 전 D34: 짓기 트리의 플러그인 시험 하네스(level beginner, model 'haiku', 하네스 줄이 isRuleDrill + isRuleWide를 켬; 그리고 하네스 없음)로 노트 요청, 2단 요청 모두, N2를 얼린 뒤 N2 채점 요청 모두(model, effort, system, prompt, maxTokens, timeoutMs)를 잡아 도구의 줄과 바이트까지 견줍니다. 1단과 건너뛴 노트는 둘째 요청이 없고; 하네스 없는 잡기는 노트 요청 하나뿐입니다.

계획 묶음 1의 글(옮김)
- 회마다: 노트 호출 85번(SYSTEM, notePrompt(screened, 'beginner', [], team) 1.8.0 바이트, maxTokens 3500, timeoutMs 90000) + 2단 호출 약 20번(RULE_DRILL_SYSTEM, redactText(ruleDrillPrompt(…)).text, 3500, 90000); 1단과 건너뜀은 호출 없음.
- N2: 번마다 채점 호출 30번 × 두 번(CHECK_SYSTEM, checkPrompt(…{ rule }), 480, 60000, 첫 시도만); 그다음 parseCheck(text, { rule: true })와 짓기 트리의 ruleGradeCap(호출 없음).
- 모두: haiku 노트 약 170 + 2단 약 40 + N2 60 ≈ 270, 빈 답의 탭 더함; sonnet은 기본으로 0.
- 스테이지: 회 A haiku(노트 + 연습을 러너 하나로); 회 B haiku; A와 B가 저장되고 해시되기 전에는 아무것도 열지 않음; 그다음 N1′ 판정; 그다음 N2 견본; N2 1번째 haiku; N2 2번째 haiku.
- 방법: 플러그인과 똑같이(D20): 프로브 mod 사본이 $.model.complete({ model: 'haiku', effort: 'low', system, prompt: redactText(prompt).text, maxTokens, timeoutMs })를 부르고, 4개씩, $.clock 시간, 답은 fixEscapedTicks를 거침; 프롬프트는 커밋된 트리의 notes.ts를 불러 haiku의 줄 + isRuleDrill true로 지음(M-13: haiku 줄에는 rungChangedStep 2도 있지만 G6 호출은 그것을 읽지 않음).
- 다시 보내기: 빈 답, 상한 닿음, 시간 한도는 다시 보내지 않음. API 오류는 적고 다시 보내지 않음(G6 §2); M-4 10% 규칙; 빈 답은 모두 탭으로 한 번(기록).
- D34: 견본마다 짓기 트리의 시험 하네스(beginner, model 'haiku', 하네스 줄이 isRuleDrill + isRuleWide를 켬; 그리고 하네스 없음)로: 노트 요청, 2단 요청 모두(1단/건너뜀 노트는 둘째 요청이 없음), N2를 얼린 뒤 N2 채점 요청 모두, 도구 줄과 바이트로 견줌; 하네스 없는 잡기는 노트 요청 하나뿐.

이 묶음이 정한 것(위 글을 도구로 옮긴 자리, 기록)
- 모델-스테이지: `A`(회 A), `B`(회 B), `N2-1`, `N2-2`(N2 1번째 · 2번째), 모두 haiku. 계획의 관문 자리 'G6 회 A haiku(회 관문 + 스테이지 관문), 회 B haiku, N2 1번째 haiku, N2 2번째 haiku'와 하나씩 맞습니다. 회 A · B의 모델-스테이지 하나는 노트 호출 85번(프로브 세션 하나) 뒤에 그 노트 답으로 2단 줄을 짓고(`tools/build.mjs drill`), 그 2단 요청을 D34로 하네스와 견준 뒤(`d34/make.py real`; 다르면 2단 호출 없이 멈춤, 종료 8), 2단 호출을 합니다(프로브 세션 하나). M-4의 10%는 그 모델-스테이지의 노트 + 2단 호출 모두로 셉니다.
- 떼어 낸 러너(러너 규칙): `ONLY_WORKFLOW=1 setsid nohup bash tools/stage.sh <A|B|N2-1|N2-2> haiku`. 에이전트는 STARTED · 세션마다의 status.jsonl · DONE · summary.json · 러너 로그만 봅니다. 러너는 (1) sonnet을 거절하고(재지 않음), 차례(B는 A 뒤, N2-2는 N2-1 뒤)와 STARTED가 없는지를 보고, (2) 고정한 길로 앞 'ok' 세션(`probe/precheck.sh`)을 돌려 `tools/gate.py pre`로 앞 기록(고정한 `claude --version` 2.1.329, 그때 다시 센 고정 바이너리 sha256 `30e2724e…6d6d` · `c3484833…8e74`, 별칭의 init model과 modelUsage 키가 '보정 기록 (1.13.0)'의 haiku 기록 `impl113/b0/calib/pre/haiku-1/record.json`과 같음)과 사용량 관문(위 '사용량 관문')을 봅니다. 기록이 다르면 부르지 않고 멈추고(종료 3), 관문을 못 넘으면 STARTED 없이 resetsAt을 찍고 기다립니다(종료 7), 다른 워크플로가 돌지 않는다는 밝힘(ONLY_WORKFLOW=1)이 없으면 시작하지 않습니다. (3) STARTED(UTC, 요청 파일 sha256)를 쓰고 부르며, (4) 뒤 기록을 `tools/gate.py after`로 견주어 다르면 무효(종료 4), 던진 호출은 M-4 넷째 줄(종료 5), api-error가 10%를 넘으면 무효(종료 6)이고, 아니면 summary.json(상태 수와 답 파일 sha256)과 DONE을 씁니다. 어떤 호출도 다시 보내지 않습니다.
- 끊긴 스테이지(끊긴 스테이지 규칙): 프로브 세션이 답 파일 없이 끝나면 러너는 상태 수로만 summary.json을 씁니다(상태 줄이 없는 얼린 요청 = api-error; 아직 짓지 않은 2단 요청은 셀 수 없어 뺌; `cut: true`) — 종료 9. 10%를 넘으면 무효이고, 다른 날 같은 요청 파일로 `<stage>-r2`를 통째로 한 번 돌릴 수 있습니다(러너가 요청 파일 sha256이 같은지, 원래 스테이지에 무효(끊김) 요약이 있는지 확인; 그 밖의 STARTED는 모두 거절). 그 뒤 도구들은 `<stage>-r2`의 DONE이 있으면 그 폴더를 읽습니다. 무효 스테이지의 파일은 건드리지 않습니다.
- 모델 기록(M-10, D19): 앞 기록은 모델-스테이지마다의 앞 'ok' 세션과 고정한 길의 --record, 뒤 기록은 그 스테이지의 프로브 세션들(세션마다 앞뒤 claude --version, 턴마다 init model, result의 modelUsage 키)과 끝의 --record입니다. 모두 '보정 기록 (1.13.0)'(2.1.329, 고정 사본 sha256, haiku의 풀린 id)과 같아야 합니다.
- 빈 답의 탭(기록만): 모델-스테이지마다 답 파일별로 `tools/tapsend.py <스테이지> haiku <note|drill|n2>`.
- 쓰는 쪽 · 확인자 호출: 모두 `gen/run.sh`(떼어 낸 러너, 아래 도구 6)로 돕니다: 견본 쓰는 쪽(`gen/out`, samples), 보충(`gen/out-topup-<K>`), N2 쓰는 쪽(`gen/n2/<꼬리표>`, files json), 행 확인자(`judge/rowcheck/<꼬리표>`), N2 확인자(`judge/n2check/<꼬리표>`), 번역 확인자(`bar/xcheck`).

#### 위험 (재기 전에 적음; 설계 risks 옮김)

- haiku N2: 상한이 볼 수 없는 깨짐 하위 꼴(리터럴과 함께 바뀐 인자 차례, 빠진 안쪽 호출/멤버나 인자, 빠진 `await`, 감싸개)을 맞음이라 매김 → 깨짐→맞음 1로 N2 못 넘음. 모음: 그런 깨짐 답 28개 가운데 11개를 잡지 못함; 지금까지 본 haiku의 거짓 맞음(3)은 모두 이름이나 규칙 꼴이었음. 잰 N2마다 약 10–20%.
- haiku N2: 상한이 낮추는 꼴로 쓴 지킴(예시 답 꼴에 정의되었지만 다른 이름, 날 · 이스케이프 문자열 꼴) → NEW 지킴 낮춤 줄을 못 넘음: 마지막 상한으로 지킴 168개 가운데 0개가 낮춰졌고, 다듬기 전에는 1개; 약 5%.
- 실제 플러그인은 연습 파일을 지금 있는 그대로 읽고, N2는 얼린 after 파일을 넘깁니다. diff와의 합집합은 이름을 더하기만 하므로 실제 상한은 잰 것보다 엄하지 않습니다(실제 파일의 다른 곳에 있는 이름을 쓰는 학습자의 깨진 줄은 잡히지 않음).
- 두 번째 시도 요청은 코드가 쓴 '첫 판정: 거의'와 피드백을 싣습니다; N2는 이것을 재지 않습니다(앞선 모든 회처럼 첫 시도만). 잘못 낮춰진 맞는 줄은 같은 까닭으로 다른 맞는 다시 해 보기에서도 거의로 남습니다(끈끈함); 규칙 연습은 개념을 표시하지 않으므로 값은 그날의 수와 일지 줄입니다.
- den 여유: 두 회 모두 ≥ 80%여야 하고, 회마다 구조적 den 놓침 약 1개를 거절함(os.getenv, 인용 없는 날짜 노트, api_request 인자 차례).
- sonnet: 기본으로 재지 않음; 재면 이 설계와 상관없이 P(할 일 둘 줄을 넘음) ≈ 39%.
- 어느 회에서든 isRuleWide W 오탐 하나가 isRuleDrill을 막음(함께 쓰는 W2; 1.12.0 잼과 1.13.0 개발에서 haiku 0).
- checkPrompt/parseCheck, notePrompt, keptNoteText/ruleLabelled/ruleNamesOf, drillOf/hideDrillAnswer 끈 길을 건드리는 다른 1.13.0 설계는 잰 바이트를 바꿉니다(D26) — 이 기준 커밋 전에 차례를 정하거나 다시 고정해야 함. (기록: 묶음 차례로 G6이 첫 잰 묶음이고, 뒤 묶음은 D26으로 이것을 다시 확인합니다.)
- sonnet 따라가기 거절 사실: 새 프롬프트 문구가 없으므로 새 거절 위험도 없습니다(2단과 채점 프롬프트 그대로; 1.12.0 잼과 1.13.0 개발에서 거절 0). (이 묶음의 기록) 세 요청(노트 notePrompt 1.8.0 바이트, 2단 ruleDrillPrompt — 규칙 · 줄 · 예시 답 세 줄만 묻는 닫힌 꼴, N2 checkPrompt 1.9.0 바이트)은 코드를 한 줄씩 따라간 과정을 적으라고 하지 않으며, 이 묶음은 haiku만 부릅니다. 그래도 빈 답 · 거절은 E18대로 '답 없음'에 셉니다(노트 호출이면 §2대로 그 회 L · O에서 빠짐). 탭 기록은 따로 적는 열입니다.
- (이 묶음의 기록) 보정: 1.13.0 보정 기록(2.1.329, H_haiku 2048)이 각 회의 앞 기록과 같아야 합니다(M-10). 설치된 claude가 컨테이너가 다시 켜진 뒤 바뀌어도 모든 부르기는 고정한 2.1.329 사본으로 합니다(base.cliPin); 고정 사본을 잃으면 남은 회차는 재지 않습니다(주인 물음 1).

#### 도구가 글을 읽는 방식 (재기 전에 정함)

도구는 1.12.0 G6 도구(`impl112/b1/`, 1.12.0 기준 커밋 표의 sha256과 62개 모두 같음을 복사 전에 확인)를 짓기 커밋 fabef5d의 트리에 맞춰 `impl113/b1/` 아래에 다시 지었고, 설계 파일럿 도구(`impl113/design/G6/tools113/`)의 1.13.0 바꿈(옛 창 30adc2f, N2의 1.13.0 셈)을 넣었습니다. 1.12.0에서 바꾸지 않은 도구는 경로(S · P · 이름 목록 기본값)와 머리 주석만 다르고, `key.py` · `lexcode.py` · `prep.py` · `notekit.mjs` · `tap/tap.py`는 1.12.0과 바이트까지 같습니다. 짓기 때 쓴 도구(`tools/probe_off.mjs` · `oldwin113.mjs` · `oldtry.mjs` · `mut.py`와 그 diff)도 이 커밋으로 함께 얼립니다.

1. 트리: `mtree/`는 짓기 커밋 fabef5d의 `git archive`(docs · README · CHANGELOG 뺌)이고 `mtree/hooks/notes.ts` · `register.tsx`는 위 sha256과 같습니다. 판정의 읽기 트리 `jtree/hooks/`는 mtree의 hooks를 복사하고 notes.ts의 `ANY_HEADING` · `DRILL_HEADING` · `taskLineOf` 앞에 `export `만 더한 것입니다(다른 바이트 같음). 옛 창 일곱 `old/<커밋>/hooks/notes.ts`는 `git show <커밋>:hooks/notes.ts`입니다(3f2b4fb = 7a7b08c, 3d2f251 = de98243). 프로브 mod의 `probe/mod/hooks/notes.ts`는 mtree의 notes.ts와 바이트까지 같습니다.
2. 견본 쓰기(`gen/common.md` · `gen/parts.json` · `gen/parts.py` · `gen/avoid113.py` · `gen/run.sh`): 위 '견본의 짜임'의 19번. 답 · 시각 · 쓴 쪽(result의 modelUsage 키)을 `gen/out/parts/<부분>-<시도>/`에 둡니다. 답은 고치지 않습니다.
3. 꺼내기와 얼리기(`tools/extract.py` · `tools/check.py` · `tools/lexcode.py` · `tools/runlib.py` · `tools/key.py` · `tools/prep.py`): extract가 부분들의 답(그리고 돈 보충)을 `frozen/raw.json`(chmod 444)과 쓴 쪽 기록으로 묶고, check가 '얼릴 때 확인'을 모두 해서 `frozen/samples.json` · `frozen/check-report.json`(chmod 444; 무리마다 대체 수, 짜임, 모자란 종류, 이름 목록과 겹침 모음의 sha256)을 씁니다. 대역과 돌리기는 runlib(§8, 세부 4 · 5 · 12 · 13), 열쇠와 이름 찾기는 key(§5, 세부 1), F의 주석 · 문자열 가르기는 lexcode, 엔진 꼴의 hunk는 prep(`frozen/hunks.json`)입니다.
4. 짜기(`tools/build.mjs` · `tools/notekit.mjs`): note는 노트 줄 85개(`frozen/note-lines-haiku.jsonl`), drill은 그 회의 노트 답으로 plan.json과 2단 줄(`stage/<회>/haiku/drill-lines.jsonl`), read는 켠 · 끈 최종 글(§1)입니다. 1.13.0 트리의 ruleFixLines/renamedLine/usePlaces/isOneSpanFix/parseRuleFix를 그대로 부릅니다.
5. D34(`d34/expect.mjs` · `d34/make.py`, 셈에 들지 않음): 짓기 트리 사본의 flowkit에 요청을 통째로 잡는 줄과 얼린 변경의 Edit/Write 결과를 주는 줄만 더하고, 견본마다 시험 하나로 잡은 요청을 도구 줄과 견줍니다. pre: 부르기 전, 견본마다 O 답(요청 하나), 그 견본의 첫 규칙을 짚는 고정 답(노트 + 2단 요청 또는 없음), 하네스 없는 같은 답(노트 요청 하나). real: 모델-스테이지 안에서 실제 노트 답으로 노트 + 도구의 2단 줄. n2: N2를 얼린 뒤 채점 요청 = N2 줄. haiku만 짓습니다.
6. 부르기(`tools/stage.sh` · `tools/gate.py` · `probe/precheck.sh` · `probe/call.sh` · `probe/record.py` · `probe/mod/`): 위 '부르기'의 러너. 프로브 mod(명령 `/g6probe <줄> <답 파일> <상태 파일>`)는 1.12.0 것과 notes.ts와 머리 줄 말고 같습니다. 쓰는 쪽 · 확인자 러너(`gen/run.sh` · `gen/gate.py` · `gen/precheck.sh` · `gen/record.py`)는 `impl112/b3r/gen/run.sh`(`a6d02c75…`) + gate.py 꼴을 impl113 경로로 옮기고, 계획 writerRunner의 거절(stop_reason refusal, safety_stops > 0, 찍힌 도구 호출 글 또는 읽을 수 없는 답 → 같은 입력으로 한 번 더, 두 번째면 STOP)과 WAIT(api 오류, 한도 닿음, 결과 없음, 죽거나 멈춘 프로세스 → 다시 돌리기나 STOP에 세지 않고 초기화 뒤 같은 바이트로 다시)를 넣었습니다. 쓰는 쪽 모델(opus)은 보정 기록이 없어 그 스테이지의 앞 세션 init id를 기준으로, 호출마다와 뒤 세션이 같아야 합니다(다르면 VOID: 그 실행의 답은 VOIDED로 두고 쓰지 않으며 같은 얼린 프롬프트로 다시).
7. 탭(`tools/tapsend.py` · `tap/`): 1.12.0 탭의 사본(명령 `/g6tap`). 기록만.
8. 꼬리표와 읽기(`tools/label.py` · `tools/read2.mjs`): seal은 회 A · B(haiku)가 DONE일 때 haiku의 꼬리표를 P · Q 가운데 난수로 봉하고(`judge/pair.json` chmod 444, sha256만 찍음), read는 build.mjs read와 read2.mjs로 `judge/<꼬리표>/read-<회>.json` · `read2-<회>.json`을 씁니다. read2는 §4, §13(세부 16), §14(세부 19, 옛 창 일곱), §11(세부 15), 멱등을 셉니다.
9. 판정(`tools/judge.py`): 꼬리표 · 회마다 `judge/verdicts-<꼬리표>-<회>.md`(행마다 근거 먼저)와 `.json`. 1.12.0 판정자 그대로입니다: 1.13.0 입장의 바꿈은 입력으로만 닿습니다(§1은 1.13.0 트리의 build.mjs, §14는 일곱 창의 read2.mjs). E19–E23과 E31은 바꾸지 않은 §6 · §10 · §13 규칙이 정하고, E24–E30과 E32는 N2 규칙이라 n2build.mjs judge가 셉니다. 모델 이름 · 토큰 · 시간 · 상한은 읽지 않습니다. 글이 정하지 않은 꼴은 못 넘는 쪽으로 세고 undecided에 적습니다(§15).
10. 기계 셈(`tools/count.py`): 꼬리표마다 스테이지별 호출 · 답함 · 까닭 · api-error · 상한 닿음(노트 · 2단 5548, N2 2528) · output_tokens · 시간, 탭의 거절 열, 규칙 연습 답 없음 줄(세부 18)을 `judge/count-<꼬리표>.json`에. 판정자와 확인자는 이 파일을 받지 않습니다.
11. 행 확인(`tools/rowcheck.py` · `judge/tpl-rowcheck.md` · `judge/stance-G6.md`): 세부 21. stance-G6.md는 이 절의 '#### 판정의 입장'에서 '#### 결정 규칙' 앞까지를 그대로 자른 것입니다. 부르기는 `gen/run.sh <judge/rowcheck/<꼬리표>> files json`. 확인자가 적은 행은 못 넘는 쪽으로 셉니다(M-9).
12. N2(`tools/pick.py` · `tools/n2prompt.py` · `gen/n2-frame.md` · `tools/n2verify.py` · `tools/n2build.mjs`): pick은 1.12.0 그대로입니다. n2prompt가 고른 연습마다 프롬프트 하나(`gen/n2/<꼬리표>/inputs/<연습 id>.md`)를 짓고, `gen/run.sh gen/n2/<꼬리표> files json`이 연습마다 새 opus 쓰는 쪽을 부릅니다. n2verify가 세부 22대로 답을 돌려 보고 예비로 채우거나 빼고 적습니다. n2build.mjs lines가 짝 파일로 줄을 짓고(짝을 찍지 않음), n2build.mjs judge가 1.13.0 N2 입장대로 셉니다: parseCheck(text, { rule: true }) 뒤 맞음이면 1.13.0 트리의 ruleGradeCap(sent, ruleFixUse(sent.check), 답 줄, capKnownNames(read2의 그 노트 변경 diff, 얼린 견본 파일의 after), pairLangOf(sent.file), after, ruleAvoidsOf(얼린 팀 파일의 규칙, use)) — register.tsx gradeDrill과 같은 부름 — 이 무엇을 내면 거의; 행마다 낮추기 전 판정과 낮춘 까닭; 지킴 낮춤(E24, E32), 낮추기 전 (어김 + 깨짐)→맞음(E26), after 파일을 찾지 못한 수(E28)를 셉니다. N2 확인자(`tools/n2check.py` · `judge/tpl-n2check.md`)는 그 꼬리표의 N2 셈 파일 둘과 stance-G6.md만 봅니다.
13. 결정(`tools/decide.py`): 모든 판정 파일이 얼려진 뒤 위 결정 규칙을 꼬리표마다 기계로 쓰고(N2는 NEW 두 줄과 N2 확인자가 적은 행을 넣어), 끝에 짝을 열어 모델마다 적습니다(`judge/decision.json` chmod 444). 짝에 없는 모델(sonnet)은 '재지 않음, 끔'으로 적습니다. 기준 커밋의 isRuleWide 값은 mtree의 MODEL_SWITCHES에서 읽습니다.
14. 끊긴 스테이지의 '-r2'를 돈 뒤에는 count · decide · label · n2build가 그 스테이지의 '-r2' 폴더를 읽습니다(DONE이 있을 때만).

도구 시험(견본 · 잰 모델 호출 0, 저장소 밖 `impl113/b1/test/`, 출력은 해시를 적은 파일로 남김)
- 판정 길(`test/pipe.sh 1|2`): 1.13.0 G6 개발 세트 1 · 2(측정에 쓰지 않음)의 얼린 견본과 적어 둔 haiku 답(회 A, N2 1번째)을 회 A · B와 N2 1 · 2번째로 놓고 build.mjs drill → label.py read → read2 → judge.py → count.py → pick.py → n2build.mjs judge를 돌렸습니다. 1.13.0 트리에서 다시 지은 2단 줄이 파일럿의 2단 줄과 바이트까지 같고(세트 1 11줄, 세트 2 8줄), 판정이 설계 기록과 같은 수를 냅니다: 세트 1 den 14 · 바름 13, 세트 2 den 12 · 바름 11, 해로움 0, 할 일 둘 0, 함정 · 표지 없음 · 옛 창 일곱 나쁜 것 0, W 오탐 0; N2 세트 1 28/29, 세트 2 30/30, 어김→맞음 0, 깨짐→맞음 0, 빠짐 0, 지킴 낮춤 0, 낮추기 전 (어김 + 깨짐)→맞음 1과 1(설계 pilot.finalReReads와 같음).
- N2 쓰는 쪽 길: 세트 1의 고른 연습 5개로 n2prompt가 연습마다 프롬프트를 짓고(거르기 (b) 패턴 0), 파일럿의 N2 답을 부분마다의 답으로 놓아 n2verify를 돌리면 파일럿의 `n2-answers.json`과 같은 답 29개(대체 2, 뺌 1)를 냅니다.
- decide.py: 세트 2로 끝까지 돌아 den < 20인 줄(A:b · B:b)을 못 넘음으로 내고, sonnet을 '재지 않음, 끔'으로 적습니다. N2 확인자가 지킴 낮춤 한 행을 적으면 N2가 못 넘음이 되고, 낮추기 전 줄에 한 행을 더해 2가 되면 넘음 그대로입니다.
- check.py: 개발 세트 1의 날 답 40개(빈 이름 목록, 겹침 모음 없음)에 개발 때 얼림과 같은 판정(못 넘음 0)을 냅니다. 온전한 이름 목록과 겹침 모음으로, 세트 1 names.txt의 파일 이름을 새 폴더 아래 쓴 견본 · 그 이름을 그대로 경로로 쓴 견본 · 'G2-dev-113' 경로를 쓴 견본을 모두 거절하고, 새 경로의 같은 견본은 받습니다(얼릴 때 확인 입력의 합성 시험; (2)는 개념 칸이 없어 경로로, (3)은 해당 없음).
- 쓰는 쪽 러너(`test/wrtest.sh`, 가짜 `claude`와 가짜 고정 길): 19부분 모두 → DONE과 기록 108개; 한 부분이 두 번 거절됨 → STOP; 한 번 거절 · 한 번 도구 호출 글 뒤 넘음 → DONE(다시 보낸 프롬프트가 바이트까지 같음); 도구 호출 글 두 번 → STOP; 한도 닿음 → WAIT, 다시 돌리면 그 부분만 같은 바이트로 → DONE; 죽은 프로세스 → WAIT; five_hour 0.70 → WAIT(호출 0); seven_day 0.75 + 0.06 → WAIT; 판 다름 · 고정 sha 다름 → RECORD-STOP; 쓰는 쪽 id 다름 → VOID(답 19개 VOIDED), 다시 돌리면 19부분 모두 다시 → DONE; DONE 폴더를 다시 → 거절; CHAIN_ROOT 없는 보충 → 거절, 있으면 → DONE; files json → DONE.
- 스테이지 러너(`test/stagetest.sh`): 회 A haiku → DONE(노트 39 + 2단 8, 안의 D34 real 39개 시험 · 요청 47개 같음); 다시 → STARTED로 거절; sonnet → 거절; 무효 요약 없는 A-r2 → 거절; N2 줄 없음 → 종료 2; A 전의 B → 거절; ONLY_WORKFLOW 없음 → 시작 안 함; five_hour 0.70 → WAIT(STARTED 없음); 회 A seven_day 0.73 + 0.08 → WAIT; 판 다름 · 고정 sha 다름 → STOP; 세션 id 다름 → VOID; api-error 5/39 → VOID; 던진 호출 → THREW; 끊긴 노트 세션(상태 3줄, 답 파일 없음) → CUT, 상태 수로 무효(api-error/상태 없음 36/39); 그 뒤 A-r2 → DONE, 그다음 B → DONE.
- D34(실제 `claude plugin test`, 고정한 CLI, 모델 호출 0): 개발 세트 2로 pre 117개 시험의 요청 123개, real 39개 시험의 요청 47개, 세트 1로 n2 29개가 모두 바이트까지 같음; 2단 줄 한 글자를 바꾼 사본은 다름 1로 잡힘(종료 1).
- 프로브 mod와 탭 mod: 1.12.0 시험 키트(`test/probemod` · `test/tapmod`)를 새 mod로 돌려 모두 넘음(4개씩 · redactText · fixEscapedTicks · 상태 줄이 늘기만 함 · 글 없음).
- 피할 목록 짓기(`impl113/gen/avoidtest113.py`, 이 묶음의 쓰는 쪽 틀 27개 = 부분 19 + 보충 7 + N2 틀): 아래 '피할 목록 합성 시험'.

#### 피할 목록 합성 시험 (이 커밋의 도구 표와 함께, 얼린 뒤 다시 돌림)

- 도구: `impl113/gen/avoidtest113.py`(`b6bab55b81a87c4e72dbe7a243f2790a52f5c355d59ab9a04b4d49fc472cdb34`, 묶음 0에서 얼림)를 `gen/avoid113.py`의 출력과 이 묶음의 쓰는 쪽 틀 27개(부분 19 + 보충 7의 `gen/common.md` + 부분 단락, 그리고 `gen/n2-frame.md`)에 돌렸습니다(`impl113/b1/avoidtest/`, chmod 444). 도구를 얼린 뒤 돌려, 도구 이름 목록에 이 묶음의 표(`impl113/b1/bar/tools.sha256`)가 듭니다.
- 입력: NAMES = `impl113/NAMES-all.txt` `0366dcd338cb7797b119878baebf8e6f428add7faecfa36b0e184f40443f0109`(1/4 첫 커밋 뒤 바뀌지 않음); 도구 이름 표 22개에서 도구 이름 198개(`toolnames.txt` `9720fc63b2acc2b2361de281fcd226e03fdcdcb20609b431974f5044e155aa5d`). 개념 1,848 · 파일 2,217 · 코드 이름 1,590. 피할 단락 `section.md` `7e4c5c1d739db687aa19152e89c6315d59cc1321676efd3183abc3cb6040f793`, 세 목록 `lists.txt` `056f8820b54d0f9366b33a0bc1654c47c5e456c27b98e9b60d6873b809ab6f15`, 짓기 출력 `build.json` `9816298eda478add85ab0974000cdeaee0e25228ddd26b26549ba1844ded168f`, 시험 출력 `test.json` `5b49987e38348013f4995d00460c0b7d4fc0f7359bcff95429a8fa66f2091a59`(종료 0).
- (1) 틀 27개 모두: (b) 패턴 0번, 도구 표 파일 이름 0번. 음성 대조: 1.12.0 틀 그대로(common.md, n2-frame.md)를 같은 도구에 넣으면 둘 다 (b) 패턴 '견본'에 걸려 실패합니다(종료 1, `test/avoidneg/test.json` `26cd4b5cfc072f956d5b93046e001e8e8b8ace4c9e5aae0b31cc03af4d9986a4`); 위 '틀 고침' 뒤 0입니다.
- (2) 이름 든 일곱 줄 0개 있음; 공백 든 '견본' 항목 370개 가운데 '견본'에서만 온 것 0개(20개는 기록 파일 줄의 개념 이름이기도 해서 (a)로 들어감; 묶음 0과 같은 읽기).
- (3) '<G>-dev-113' 꼬리표마다 기록 파일의 개념 · 파일 · 코드 이름이 있음(종류가 그 꼬리표에 없으면 해당 없음): 놓친 것 0.
- 견본 쓰는 쪽 스테이지가 시작할 때 쓰는 쪽마다 피할 단락을 그때의 NAMES-all.txt로 다시 짓고(`gen/parts.py make`), 그 sha256을 부분 폴더(`avoid-build.json`)에 둡니다. 피할 단락은 손으로 고치지 않습니다.

#### 틀과 도구 (sha256, 이 커밋으로 얼림, 저장소 밖 `impl113/b1/` 아래, chmod 444)

| 파일 | 하는 일 | sha256 |
| --- | --- | --- |
| `team.md` | 팀 파일(1.10.0 것 그대로) | `18f9d5c755f49db4f9dd767b380bdda569609ffa6a6021ca9f9525881a9b0c9b` |
| `gen/common.md` | 쓰는 쪽 공통 틀('사례'로 고친 1.12.0 틀) | `ff7289bea414a8c99dc449a1a38e2e79433faaeb080cae314854a06060d1391f` |
| `gen/parts.json` | 쓰는 쪽 짜임(19부분 + 보충 7) | `a99fbec2634698ce9651ffecb3e49074d794deaeb076096cb2c6a9a0750a1a3d` |
| `gen/parts.py` | 부분 프롬프트 · 답 읽기 · 묶기 | `f283419f9b37f4a0fb04d445191e27c09428776db843a1cb46fa8eaaaece5806` |
| `gen/avoid113.py` | 피할 목록 짓기(`impl113/gen/avoid113.py`와 같음) | `66b0528bae2375f59ce4d3363503d0317b9a37dbd19da1a2c80240edefb395de` |
| `gen/run.sh` | 쓰는 쪽 · 확인자 러너 | `d8174bf16a46d88b2e8ad9f59ff341ff666f4aad98a84b698b72f3549585b2e9` |
| `gen/gate.py` | 쓰는 쪽 러너의 앞뒤 기록 · 관문 · 끝남 갈래 | `38fbedfe2ba5d4591aa2e9bb68d19e416d8d7b0f1122d2dd2ab30c23b37cf492` |
| `gen/precheck.sh` | 쓰는 쪽 앞뒤 'ok' 세션 | `0b5d5f8a66e05d9f2ecfc311e63ef97624ebe10915fb8f76644f8f063b2c9b99` |
| `gen/record.py` | 세션 기록 읽기 | `a50da824e3ccfa74f5514e7edd8f1098089083efe59f0d36c31e2265312dcc38` |
| `gen/n2-frame.md` | N2 답 쓰는 쪽 틀(연습 하나) | `311d0da40a303750e9de4b33636cc843ccd57aee29d6bd80c8f00d6edb079952` |
| `tools/extract.py` | 쓰는 쪽 답 묶기 | `0dc32ecda2ef58af9d469ce7f009b32523d2d37ab847d194809f8b32f120d92f` |
| `tools/check.py` | 얼릴 때 확인 · 예비 대체 (NAMES_FILE = `impl113/NAMES-all.txt`) | `18f0a82db7bdc966ea0fed618e94bc509264eb2685ef1c1f5d91c203bdecfaec` |
| `tools/lexcode.py` | 주석 · 문자열 가르기(F; 1.12.0과 같음) | `fdc422b4e846f17d398ace243e2a09306a47137f5acc24f86c85c0a309ff1e94` |
| `tools/runlib.py` | 대역과 돌리기(§8) | `7b71144f5a907c5fbf809ff9dbb4e3e8484fdd70ea88cca1eb6cc12fb878500a` |
| `tools/key.py` | 채점 열쇠(§5) · 이름 찾기(1.12.0과 같음) | `d99012f6fb85b1c28b08cda7aeac51d556b5a141eda65facb2cd823ec2f72ceb` |
| `tools/prep.py` | 엔진 꼴 hunk(1.12.0과 같음) | `ecbd0f9d00a43cd0cffb057e1261004926d24f2c82621565f516fd08b4310cfe` |
| `tools/build.mjs` | 노트 · 2단 줄 짜기, 켠 · 끈 읽기(§1) | `b59faf1a0b8b1fb5a6b4d986aa6797211a12731ccc76fa8bc4518a29a7c6253e` |
| `tools/notekit.mjs` | 노트 꾸미기(1.12.0과 같음) | `ade740be098b73b630a132a98cab6911d9eba8bf0f07d195f38935bb28da1dd6` |
| `tools/read2.mjs` | 판정 입력(§4 · §11 · §13 · §14, 옛 창 일곱) | `50e99b0a916a739d27b73d87498c7a6bca5dc6630eaea9de178a2b3dab07cd1f` |
| `tools/judge.py` | 기계 판정자 | `192d13f8a53fa4bad67a989829a52b2bd0fe3b6fd93915a769da0a073f557690` |
| `tools/count.py` | 기계 셈(꼬리표마다) | `20f9db425b5a22bdec0779675d1042666b8603cc5f26f7aa92aa8d71c8e50d6d` |
| `tools/label.py` | 꼬리표 봉인 · 읽기 | `7e909fb4c94dc4419666f83407180821ff18bda7dc4bb56b188adb5b95867af3` |
| `tools/pick.py` | N2 고르기 | `9ee3bbebd00fcf9e4bbe81fa9df6248134a75f47423a219143d94a0005893473` |
| `tools/n2prompt.py` | N2 쓰는 쪽 프롬프트(연습마다) | `1b0591a720d2a8d3d42634c24fa56a0e0a27ba732b2eb0f0450637bdb8255e6a` |
| `tools/n2verify.py` | N2 대역 확인(세부 22) | `57d4d43af81b120d28ec99db512be5423ead8e60f3b45d4fac03c66a62b0cb33` |
| `tools/n2build.mjs` | N2 줄 · 셈(1.13.0 N2 입장) | `40810fe0832316f40c55a81b242f030eca99dbde7013a84deb595c016f879c93` |
| `tools/rowcheck.py` | 행 확인(세부 21) | `734aca943f12e1d9d8cc73316557f31b15839e7db30538afd6d96947c527b488` |
| `tools/n2check.py` | N2 확인 | `e0bb5b367ad5640dfb10a81b98259d7d4aa0e04d81238197269f8faac7cddbd3` |
| `tools/decide.py` | 결정 규칙 | `994ece91b70911c4ccf453baef5d0ecf3976f0c9c5bbd7f2d85df863ec8ace22` |
| `tools/gate.py` | 앞뒤 기록 · 사용량 관문(모델-스테이지) | `dfdbdeefda9c420820dae41362799500847c3686a2762b5b991f445ac72e0dff` |
| `tools/stage.sh` | 떼어 낸 러너(모델-스테이지) | `1d9d9380695211b5c155025b7f0fe589ff6253e218fefe1a6be0ec976013386e` |
| `tools/tapsend.py` | 빈 답의 탭(기록) | `bb333d792b20137e955a60dbfac178c99043547e8c880e6352bb15e67bc5789c` |
| `tools/probe_off.mjs` | 끈 바이트(짓기 때) | `9e911ba9a484594f3c6ca512b63cea69c0f6a491dea7bf7a86c37d9771d3bae4` |
| `tools/probe_off.diff` | 그 출처와의 차이 | `55fe0d4e160d8c78bb12184a023068639eff4ebf5235d416a3b92e4d76dc0ae9` |
| `tools/oldwin113.mjs` | 옛 창 일곱(짓기 때) | `a9bc5fe92d4998bd9e402c7863942ca1e54631eb36b7289a0acfbf21bb09dba6` |
| `tools/oldwin113.diff` | 그 출처와의 차이 | `2e2d3228974a38da49f183286b23bf2495e72f63295f9954f9ea5452aa9a7567` |
| `tools/oldtry.mjs` | 옛 창의 첫 시도 읽기(짓기 때) | `0af30fef9c0d4501ad6272839aab09d596ffb7cd40c1f9d78a08de5ecab45d85` |
| `tools/mut.py` | 돌연변이 탐침(짓기 때) | `33a485db6466ea3af855cc7dc5884ed571ed5e99bf4f80d974e75d8db463059e` |
| `tools/mut.diff` | 그 출처와의 차이 | `91a01abec829bc9a90077ca00e7e4d6f80c2303fba3ef6fc818b3a3b571c3bc9` |
| `d34/expect.mjs` | D34 기대 요청 | `fe213e1255188aaab6bf912a5ebbf7bbf0533de11bdb452061632793c4a525ba` |
| `d34/make.py` | D34 하네스 잡기 · 견줌 | `0aa74848f15d6e31e49b28d694666823585ddd5197b4502bd0fa90169ee337a9` |
| `probe/call.sh` | 프로브 세션 | `0d6114b81dac8452cac28bef0e127d6fbf2f60d0bc5338090e33411ad8cb11b7` |
| `probe/precheck.sh` | 앞 'ok' 세션 | `4b4a6c5e65cbdd4774f2d40b7f7877e50d1b5caf13e73c0f262c04f40870d62f` |
| `probe/record.py` | 세션 기록 읽기 | `1dc4562fdd81b415033f08b99bf509ffb3707effc6436750a4abd64486239591` |
| `probe/mod/hooks/register.ts` | 프로브 mod(/g6probe) | `b0620c58f04110d56652e213ca8778fa35d77431ba3d3a58296c913525a3e239` |
| `probe/mod/hooks/notes.ts` | 프로브 notes.ts(= mtree) | `30b8b7df476434f618d689a20be971234eadf64116ac4a441d09e797e35770fc` |
| `probe/mod/hooks/hooks.json` | 프로브 mod | `c835c92d8e1159d20a40ca78ad654da7433942c3694ffeda0b376b0c4dfd52cf` |
| `probe/mod/.claude-plugin/plugin.json` | 프로브 mod | `c338bf1acc8746e53f0444f3a56456265d521ef0917440ffef1a32683cd0cb07` |
| `tap/call.sh` | 탭 세션 | `8615dcbb69a341da1cac166e248533ceeb467f585d71dfaf09740a935324b24a` |
| `tap/tap.py` | 탭(1.11.0 · 1.12.0과 같음) | `e8d8174b09e11c74e6d744e4c44bc62033436d2ab35be6daa95d27026d17db9b` |
| `tap/mod/hooks/register.ts` | 탭 mod(/g6tap) | `ddaa11d190bdf35a7440f0924c5ef20ecc5198fdf96bde5c4d753621d0cb1198` |
| `tap/mod/hooks/hooks.json` | 탭 mod | `c835c92d8e1159d20a40ca78ad654da7433942c3694ffeda0b376b0c4dfd52cf` |
| `tap/mod/.claude-plugin/plugin.json` | 탭 mod | `6d5e9564b2b985dc0a29b95e95b213dcb8aa294a0f6b3451497761520b824e3b` |
| `tap/mod/tsconfig.json` | 탭 mod | `88437ec880f7008b5df208a95a7d47330f0e3a8204d78d6c5cc272e5941c3511` |
| `judge/tpl-rowcheck.md` | 행 확인 틀 | `dc946471c509fdbb787470e696d2087a56dcd98befcd6c48bafdbeb253692dfd` |
| `judge/tpl-n2check.md` | N2 확인 틀 | `b11e5e8d33af7fb0e93f504e00b84b95d97d43ed591490eef7917fc63ad98363` |
| `judge/stance-G6.md` | 확인자에게 주는 입장(이 절에서 자름) | `5a92501e421ede9f25f84d831fd9e348fd9df7a6f879ffb225234c88f0d54ed3` |
| `mtree/hooks/notes.ts` | 짓기 트리(fabef5d) | `30b8b7df476434f618d689a20be971234eadf64116ac4a441d09e797e35770fc` |
| `mtree/hooks/register.tsx` | 짓기 트리(fabef5d) | `c4562ae08c7006aed2c7a7ac6120bdfba28fae0899089bb915144fc0cc7e3e92` |
| `jtree/hooks/notes.ts` | 읽기 트리(export 셋만 더함) | `59793624565ee792ace801bc66d89a21eefc1741ee7e55cde9829fe9ce8df062` |
| `old/3f2b4fb/hooks/notes.ts` | 옛 창 3f2b4fb notes.ts(git show) | `ff5a9624e030f27e79cfb2532ef1c555e686ea1b3aae723823146efbb74cb5f4` |
| `old/7a7b08c/hooks/notes.ts` | 옛 창 7a7b08c notes.ts(git show) | `ff5a9624e030f27e79cfb2532ef1c555e686ea1b3aae723823146efbb74cb5f4` |
| `old/3690021/hooks/notes.ts` | 옛 창 3690021 notes.ts(git show) | `67412721bfc3b68f7b10278d07af9acdf114bd595614f6d9bb83e0ee16a4e0bd` |
| `old/fca5988/hooks/notes.ts` | 옛 창 fca5988 notes.ts(git show) | `ff4b2cfcbd2bce53d90dad21865f07fbc4b99205868bc27ead0b1990e54bc8f7` |
| `old/3d2f251/hooks/notes.ts` | 옛 창 3d2f251 notes.ts(git show) | `acabacdfbcc85b73518db9ac129585e958f92e726b1c6dad30649500b13b37ee` |
| `old/de98243/hooks/notes.ts` | 옛 창 de98243 notes.ts(git show) | `acabacdfbcc85b73518db9ac129585e958f92e726b1c6dad30649500b13b37ee` |
| `old/30adc2f/hooks/notes.ts` | 옛 창 30adc2f notes.ts(git show) | `6edd705daf11339a8d5f2f424fc17c1664b8fceccad3e3438ec00afd7f1a8bd2` |
| `bar/stance.py` | 입장 다시 커밋 글 짓기(기록) | `8af9499e02128ca767cd11a2b84d8b4f6b2906dffd5575aea242dde75d6da29a` |
| `bar/compose.py` | 이 절 짓기(기록) | `b49459bfce8c9b0e3fa083deee0874ac27e0ade7caef157c95836665bb778e85` |
| `../d26/rulewide113.mjs` | isRuleWide D26(묶음 0에서 얼림) | `21dfa038a63071f51c660331f796cf24f6101e3c199fc91a1cefd7fe8ab11ca9` |
| `../d26/g2haiku.sh` | G2 haiku D26(묶음 0에서 얼림) | `894c2ca4260aa73d249e1af7b40c2be7558f2968077b92e9be26b0bb2e9835a5` |
| `../d26/remake.py` | G2 haiku D26 요청 다시 짓기(묶음 0에서 얼림) | `a36cf1ec181b538141d7e4ca428aca7a88c6c18611d60f5831349cd9471f58db` |
| `../cli/pinned.sh` | 고정한 길(묶음 0, chmod 555) | `bbe2dc0a6212d1865c4d253bdc451645174c3d5cceef3a0feb662d5c791aba5f` |

#### 옮김 확인

(확인 뒤에 적음)
