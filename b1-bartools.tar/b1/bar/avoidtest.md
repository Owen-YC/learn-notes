#### 피할 목록 합성 시험 (이 커밋의 도구 표와 함께, 얼린 뒤 다시 돌림)

- 도구: `impl113/gen/avoidtest113.py`(`b6bab55b81a87c4e72dbe7a243f2790a52f5c355d59ab9a04b4d49fc472cdb34`, 묶음 0에서 얼림)를 `gen/avoid113.py`의 출력과 이 묶음의 쓰는 쪽 틀 27개(부분 19 + 보충 7의 `gen/common.md` + 부분 단락, 그리고 `gen/n2-frame.md`)에 돌렸습니다(`impl113/b1/avoidtest/`, chmod 444). 도구를 얼린 뒤 돌려, 도구 이름 목록에 이 묶음의 표(`impl113/b1/bar/tools.sha256`)가 듭니다.
- 입력: NAMES = `impl113/NAMES-all.txt` `0366dcd338cb7797b119878baebf8e6f428add7faecfa36b0e184f40443f0109`(1/4 첫 커밋 뒤 바뀌지 않음); 도구 이름 표 22개에서 도구 이름 198개(`toolnames.txt` `9720fc63b2acc2b2361de281fcd226e03fdcdcb20609b431974f5044e155aa5d`). 개념 1,848 · 파일 2,217 · 코드 이름 1,590. 피할 단락 `section.md` `7e4c5c1d739db687aa19152e89c6315d59cc1321676efd3183abc3cb6040f793`, 세 목록 `lists.txt` `056f8820b54d0f9366b33a0bc1654c47c5e456c27b98e9b60d6873b809ab6f15`, 짓기 출력 `build.json` `9816298eda478add85ab0974000cdeaee0e25228ddd26b26549ba1844ded168f`, 시험 출력 `test.json` `5b49987e38348013f4995d00460c0b7d4fc0f7359bcff95429a8fa66f2091a59`(종료 0).
- (1) 틀 27개 모두: (b) 패턴 0번, 도구 표 파일 이름 0번. 음성 대조: 1.12.0 틀 그대로(common.md, n2-frame.md)를 같은 도구에 넣으면 둘 다 (b) 패턴 '견본'에 걸려 실패합니다(종료 1, `test/avoidneg/test.json` `26cd4b5cfc072f956d5b93046e001e8e8b8ace4c9e5aae0b31cc03af4d9986a4`); 위 '틀 고침' 뒤 0입니다.
- (2) 이름 든 일곱 줄 0개 있음; 공백 든 '견본' 항목 370개 가운데 '견본'에서만 온 것 0개(20개는 기록 파일 줄의 개념 이름이기도 해서 (a)로 들어감; 묶음 0과 같은 읽기).
- (3) '<G>-dev-113' 꼬리표마다 기록 파일의 개념 · 파일 · 코드 이름이 있음(종류가 그 꼬리표에 없으면 해당 없음): 놓친 것 0.
- 견본 쓰는 쪽 스테이지가 시작할 때 쓰는 쪽마다 피할 단락을 그때의 NAMES-all.txt로 다시 짓고(`gen/parts.py make`), 그 sha256을 부분 폴더(`avoid-build.json`)에 둡니다. 피할 단락은 손으로 고치지 않습니다.
