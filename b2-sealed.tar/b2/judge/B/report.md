# 꼬리표 B: 비슷한 코드 자리 20개 (도구 결과)

도구(⚙)가 센 것과 판정자(✎)가 볼 것을 자리마다 적었습니다. 모델 이름 · 토큰 · 시간은 없습니다.

## c1 (Q1의 1번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const sizes = [20, 25, 30];
function areaOf(cm) {
  const r = cm / 2;
  return Math.round(Math.PI * r * r);
}
for (const size of sizes) {
  console.log(size + 'cm 피자: ' + areaOf(size) + '㎠');
}
```
학습자 결과(조항 3, 얼린 것):
```
20cm 피자: 314㎠
25cm 피자: 491㎠
30cm 피자: 707㎠
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const sizes = [40, 25, 30];
function areaOf(cm) {
  const r = cm / 2;
  return Math.round(Math.PI * r * r);
}
for (const size of sizes) {
  console.log(size + 'cm 피자: ' + areaOf(size) + '㎠');
}
```
````
hint:
````
바뀐 곳은 1번째 줄 `const sizes = [40, 25, 30];`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
40cm 피자: 1257㎠
25cm 피자: 491㎠
30cm 피자: 707㎠
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
40cm 피자: 1257㎠
25cm 피자: 491㎠
30cm 피자: 707㎠
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c2 (Q1의 2번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
def mode_label(mode):
    if mode == 'hard':
        return '어려움: 점수 2배'
    if mode == 'easy':
        return '쉬움: 기본 점수'
    return '알 수 없는 모드'
for m in ['hard', 'easy', 'zen']:
    print(m, '→', mode_label(m))
```
학습자 결과(조항 3, 얼린 것):
```
hard → 어려움: 점수 2배
easy → 쉬움: 기본 점수
zen → 알 수 없는 모드
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
def mode_label(mode):
    if mode == 'hard':
        return '어려움: 점수 2배'
    if mode == 'easy':
        return '쉬움: 기본 점수'
    return '알 수 없는 모드'
for m in ['expert', 'easy', 'zen']:
    print(m, '→', mode_label(m))
```
````
hint:
````
바뀐 곳은 7번째 줄 `for m in ['expert', 'easy', 'zen']:`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
expert → 알 수 없는 모드
easy → 쉬움: 기본 점수
zen → 알 수 없는 모드
````
kind predict · rung changed · 펜스 이름 'python' → 언어 py
### 보인 코드를 돌린 결과(조항 3)
```
expert → 알 수 없는 모드
easy → 쉬움: 기본 점수
zen → 알 수 없는 모드
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c3 (Q1의 3번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const books = [
  { title: '어린 왕자', pages: 120 },
  { title: '모모', pages: 300 },
  { title: '데미안', pages: 340 },
];
console.log(books[1].title);
let longest = books[0];
for (const b of books) {
  if (b.pages > longest.pages) {
    longest = b;
  }
}
console.log('가장 긴 책: ' + longest.title);
```
학습자 결과(조항 3, 얼린 것):
```
모모
가장 긴 책: 데미안
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const books = [
  { title: '어린 왕자', pages: 120 },
  { title: '모모', pages: 400 },
  { title: '데미안', pages: 340 },
];
console.log(books[1].title);
let longest = books[0];
for (const b of books) {
  if (b.pages > longest.pages) {
    longest = b;
  }
}
console.log('가장 긴 책: ' + longest.title);
```
````
hint:
````
바뀐 곳은 3번째 줄 `{ title: '모모', pages: 400 },`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
모모
가장 긴 책: 모모
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
모모
가장 긴 책: 모모
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c4 (Q2의 1번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const laps = [62.4, 59.8, 61.2, 60.5];
let best = Infinity;
for (const t of laps) {
  if (t < best) {
    best = t;
  }
}
console.log('최고 기록: ' + best + '초');
console.log(best < Infinity);
```
학습자 결과(조항 3, 얼린 것):
```
최고 기록: 59.8초
true
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const laps = [62.4, 59.8, 61.2, 60.5];
let best = Infinity;
for (const t of laps) {
  if (t >= best) {
    best = t;
  }
}
console.log('최고 기록: ' + best + '초');
console.log(best < Infinity);
```
````
hint:
````
바뀐 곳은 4번째 줄 `if (t >= best) {`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
최고 기록: Infinity초
false
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
최고 기록: Infinity초
false
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c5 (Q2의 2번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
results = [('민지', 88), ('준호', 95), ('서연', 79)]
best = results[0]
for item in results:
    if item[1] > best[1]:
        best = item
best_name, best_score = best
print('최고 점수:', best_name, best_score)
```
학습자 결과(조항 3, 얼린 것):
```
최고 점수: 준호 95
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
results = [('민지', 88), ('준호', 95), ('서연', 79)]
best = results[0]
for item in results:
    if item[1] < best[1]:
        best = item
best_name, best_score = best
print('최고 점수:', best_name, best_score)
```
````
hint:
````
바뀐 곳은 4번째 줄 `if item[1] < best[1]:`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
최고 점수: 서연 79
````
kind predict · rung changed · 펜스 이름 'python' → 언어 py
### 보인 코드를 돌린 결과(조항 3)
```
최고 점수: 서연 79
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c6 (Q2의 3번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
function fillNick(user) {
  user.nick ||= '손님' + user.id;
  return user;
}
const users = [{ id: 1, nick: '하늘' }, { id: 2, nick: '' }];
const filled = users.map(fillNick);
console.log(filled);
```
학습자 결과(조항 3, 얼린 것):
```
[ { id: 1, nick: '하늘' }, { id: 2, nick: '손님2' } ]
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
function fillNick(user) {
  user.nick ||= '고객' + user.id;
  return user;
}
const users = [{ id: 1, nick: '하늘' }, { id: 2, nick: '' }];
const filled = users.map(fillNick);
console.log(filled);
```
````
hint:
````
바뀐 곳은 2번째 줄 `user.nick ||= '고객' + user.id;`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
[ { id: 1, nick: '하늘' }, { id: 2, nick: '고객2' } ]
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
[ { id: 1, nick: '하늘' }, { id: 2, nick: '고객2' } ]
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c7 (Q3의 1번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const hero = { name: '루나', level: 5, hp: 80 };
const bonus = { hp: 20 };
hero.hp = hero.hp + bonus.hp;
console.log(hero.name + ' 레벨 ' + hero.level);
console.log(hero);
console.log(typeof hero);
```
학습자 결과(조항 3, 얼린 것):
```
루나 레벨 5
{ name: '루나', level: 5, hp: 100 }
object
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const hero = { name: '밤비', level: 5, hp: 80 };
const bonus = { hp: 20 };
hero.hp = hero.hp + bonus.hp;
console.log(hero.name + ' 레벨 ' + hero.level);
console.log(hero);
console.log(typeof hero);
```
````
hint:
````
바뀐 곳은 1번째 줄 `const hero = { name: '밤비', level: 5, hp: 80 };`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
밤비 레벨 5
{ name: '밤비', level: 5, hp: 100 }
object
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
밤비 레벨 5
{ name: '밤비', level: 5, hp: 100 }
object
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c8 (Q3의 2번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
basket = {'apple': 3, 'pear': 2}
basket['grape'] = 5
basket['apple'] = basket['apple'] + 1
print(basket)
print(len(basket))
print('grape' in basket)
```
학습자 결과(조항 3, 얼린 것):
```
{'apple': 4, 'pear': 2, 'grape': 5}
3
True
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
basket = {'apple': 3, 'pear': 2}
basket['kiwi'] = 5
basket['apple'] = basket['apple'] + 1
print(basket)
print(len(basket))
print('grape' in basket)
```
````
hint:
````
바뀐 곳은 2번째 줄 `basket['kiwi'] = 5`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
{'apple': 4, 'pear': 2, 'kiwi': 5}
3
False
````
kind predict · rung changed · 펜스 이름 'python' → 언어 py
### 보인 코드를 돌린 결과(조항 3)
```
{'apple': 4, 'pear': 2, 'kiwi': 5}
3
False
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c9 (Q4의 2번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const PASS_LINE = 60;
const results = { 민지: 72, 준호: 58, 서연: 60 };
for (const name in results) {
  const score = results[name];
  if (score >= PASS_LINE) {
    console.log(name + ': 합격');
  } else {
    console.log(name + ': 불합격 (' + score + '점)');
  }
}
```
학습자 결과(조항 3, 얼린 것):
```
민지: 합격
준호: 불합격 (58점)
서연: 합격
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const PASS_LINE = 60;
const results = { 민지: 72, 준호: 58, 서연: 60 };
for (const name in results) {
  const score = results[name];
  if (score > PASS_LINE) {
    console.log(name + ': 합격');
  } else {
    console.log(name + ': 불합격 (' + score + '점)');
  }
}
```
````
hint:
````
바뀐 곳은 5번째 줄 `if (score > PASS_LINE) {`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
민지: 합격
준호: 불합격 (58점)
서연: 불합격 (60점)
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
민지: 합격
준호: 불합격 (58점)
서연: 불합격 (60점)
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c10 (Q4의 3번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
function lineTotal(item) {
  return item.price * item.qty;
}
const order = [
  { menu: '아메리카노', price: 4500, qty: 2 },
  { menu: '라테', price: 5000, qty: 1 },
];
let total = 0;
for (const item of order) {
  total += lineTotal(item);
  console.log(item.menu + ' x' + item.qty + ' = ' + lineTotal(item));
}
console.log('합계: ' + total + '원');
```
학습자 결과(조항 3, 얼린 것):
```
아메리카노 x2 = 9000
라테 x1 = 5000
합계: 14000원
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
function lineTotal(item) {
  return item.price * item.qty;
}
const order = [
  { menu: '아메리카노', price: 4500, qty: 3 },
  { menu: '라테', price: 5000, qty: 1 },
];
let total = 0;
for (const item of order) {
  total += lineTotal(item);
  console.log(item.menu + ' x' + item.qty + ' = ' + lineTotal(item));
}
console.log('합계: ' + total + '원');
```
````
hint:
````
바뀐 곳은 5번째 줄 `{ menu: '아메리카노', price: 4500, qty: 3 },`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
아메리카노 x3 = 13500
라테 x1 = 5000
합계: 18500원
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
아메리카노 x3 = 13500
라테 x1 = 5000
합계: 18500원
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c11 (Q5의 1번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
riders = [('하준', 135, 9), ('지우', 118, 7), ('도윤', 142, 12)]
for name, height, age in riders:
    if height >= 120 and age >= 8:
        print(name + ': 탑승 가능')
    else:
        print(name + ': 탑승 불가')
```
학습자 결과(조항 3, 얼린 것):
```
하준: 탑승 가능
지우: 탑승 불가
도윤: 탑승 가능
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
riders = [('서연', 135, 9), ('지우', 118, 7), ('도윤', 142, 12)]
for name, height, age in riders:
    if height >= 120 and age >= 8:
        print(name + ': 탑승 가능')
    else:
        print(name + ': 탑승 불가')
```
````
hint:
````
바뀐 곳은 1번째 줄 `riders = [('서연', 135, 9), ('지우', 118, 7), ('도윤', 142, 12)]`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
서연: 탑승 가능
지우: 탑승 불가
도윤: 탑승 가능
````
kind predict · rung changed · 펜스 이름 'python' → 언어 py
### 보인 코드를 돌린 결과(조항 3)
```
서연: 탑승 가능
지우: 탑승 불가
도윤: 탑승 가능
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c12 (Q5의 3번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const rows = ['A', 'B', 'C'];
const cols = [1, 2, 3, 4];
for (const r of rows) {
  let line = '';
  for (const c of cols) {
    line += r + c + ' ';
  }
  console.log(line.trim());
}
```
학습자 결과(조항 3, 얼린 것):
```
A1 A2 A3 A4
B1 B2 B3 B4
C1 C2 C3 C4
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const rows = ['A', 'B', 'C'];
const cols = [1, 2, 3, 9];
for (const r of rows) {
  let line = '';
  for (const c of cols) {
    line += r + c + ' ';
  }
  console.log(line.trim());
}
```
````
hint:
````
바뀐 곳은 2번째 줄 `const cols = [1, 2, 3, 9];`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
A1 A2 A3 A9
B1 B2 B3 B9
C1 C2 C3 C9
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
A1 A2 A3 A9
B1 B2 B3 B9
C1 C2 C3 C9
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c13 (Q6의 1번째 자리)

- 읽힌 문항 없음(조항 2 · 13). (가) 놓침, (나) 셈 밖. 판정자는 이 자리를 적지 않습니다.

## c14 (Q6의 3번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
def ship_fee(total, is_member):
    if total >= 30000 or is_member:
        return 0
    return 3000
orders = [(25000, False), (32000, False), (12000, True)]
for total, member in orders:
    print(str(total) + '원 배송비: ' + str(ship_fee(total, member)))
```
학습자 결과(조항 3, 얼린 것):
```
25000원 배송비: 3000
32000원 배송비: 0
12000원 배송비: 0
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
def ship_fee(total, is_member):
    if total < 30000 or is_member:
        return 0
    return 3000
orders = [(25000, False), (32000, False), (12000, True)]
for total, member in orders:
    print(str(total) + '원 배송비: ' + str(ship_fee(total, member)))
```
````
hint:
````
바뀐 곳은 2번째 줄 `if total < 30000 or is_member:`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
25000원 배송비: 0
32000원 배송비: 3000
12000원 배송비: 0
````
kind predict · rung changed · 펜스 이름 'python' → 언어 py
### 보인 코드를 돌린 결과(조항 3)
```
25000원 배송비: 0
32000원 배송비: 3000
12000원 배송비: 0
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c15 (Q7의 1번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const prices = { sword: 300, shield: 250, potion: 50 };
const cart = ['sword', 'potion', 'potion'];
let total = 0;
for (const item of cart) {
  total = total + prices[item];
}
console.log('총 가격: ' + total);
console.log(prices['shield']);
```
학습자 결과(조항 3, 얼린 것):
```
총 가격: 400
250
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const prices = { sword: 100, shield: 250, potion: 50 };
const cart = ['sword', 'potion', 'potion'];
let total = 0;
for (const item of cart) {
  total = total + prices[item];
}
console.log('총 가격: ' + total);
console.log(prices['shield']);
```
````
hint:
````
바뀐 곳은 1번째 줄 `const prices = { sword: 100, shield: 250, potion: 50 };`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
총 가격: 200
250
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
총 가격: 200
250
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c16 (Q7의 3번째 자리)

- 읽힌 문항 없음(조항 2 · 13). (가) 놓침, (나) 셈 밖. 판정자는 이 자리를 적지 않습니다.

## c17 (Q8의 2번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
correct = ['B', 'C', 'A', 'D']
marked = ['B', 'A', 'A', 'C']
wrong = []
for i in range(4):
    if marked[i] != correct[i]:
        wrong.append(str(i + 1))
print('틀린 문제: ' + ', '.join(wrong))
```
학습자 결과(조항 3, 얼린 것):
```
틀린 문제: 2, 4
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
correct = ['B', 'C', 'A', 'D']
marked = ['D', 'A', 'A', 'C']
wrong = []
for i in range(4):
    if marked[i] != correct[i]:
        wrong.append(str(i + 1))
print('틀린 문제: ' + ', '.join(wrong))
```
````
hint:
````
바뀐 곳은 2번째 줄 `marked = ['D', 'A', 'A', 'C']`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
틀린 문제: 1, 2, 4
````
kind predict · rung changed · 펜스 이름 'python' → 언어 py
### 보인 코드를 돌린 결과(조항 3)
```
틀린 문제: 1, 2, 4
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c18 (Q8의 3번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const todos = [
  { title: '장보기', done: true },
  { title: '빨래', done: false },
  { title: '운동', done: true },
];
let allDone = true;
for (const t of todos) {
  if (!t.done) {
    allDone = false;
    console.log('남은 일: ' + t.title);
  }
}
console.log(allDone);
```
학습자 결과(조항 3, 얼린 것):
```
남은 일: 빨래
false
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const todos = [
  { title: '장보기', done: false },
  { title: '빨래', done: false },
  { title: '운동', done: true },
];
let allDone = true;
for (const t of todos) {
  if (!t.done) {
    allDone = false;
    console.log('남은 일: ' + t.title);
  }
}
console.log(allDone);
```
````
hint:
````
바뀐 곳은 2번째 줄 `{ title: '장보기', done: false },`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
남은 일: 장보기
남은 일: 빨래
false
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
남은 일: 장보기
남은 일: 빨래
false
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c19 (Q9의 2번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
const pet = { name: '콩이', kind: '강아지' };
console.log(Object.keys(pet).length);
pet.age = 3;
pet.weight = 4.2;
console.log(Object.keys(pet).length);
console.log(pet);
```
학습자 결과(조항 3, 얼린 것):
```
2
4
{ name: '콩이', kind: '강아지', age: 3, weight: 4.2 }
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const pet = { name: '콩이', kind: '강아지' };
console.log(Object.keys(pet).length);
pet.age = 9;
pet.weight = 4.2;
console.log(Object.keys(pet).length);
console.log(pet);
```
````
hint:
````
바뀐 곳은 3번째 줄 `pet.age = 9;`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
2
4
{ name: '콩이', kind: '강아지', age: 9, weight: 4.2 }
````
kind predict · rung changed · 펜스 이름 'js' → 언어 js
### 보인 코드를 돌린 결과(조항 3)
```
2
4
{ name: '콩이', kind: '강아지', age: 9, weight: 4.2 }
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

## c20 (Q9의 3번째 자리)

### 학습자 코드(학습자 조각 = 파일 전체)
```
present = {'민지': True, '준호': False, '서연': True}
count = 0
for name, here in present.items():
    if here:
        count = count + 1
print(present['준호'])
print(type(present['민지']))
print(count, '명 출석')
```
학습자 결과(조항 3, 얼린 것):
```
False
<class 'bool'>
2 명 출석
```
### 저장된 문항
question:
````
전에 만든 코드에서 한 곳을 바꿨습니다. 이 코드를 실행하면 무엇이 출력될까요? 오류로 멈추면 그때까지 찍힌 것과 오류 이름을 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
present = {'민지': True, '준호': False, '서연': True}
count = 5
for name, here in present.items():
    if here:
        count = count + 1
print(present['준호'])
print(type(present['민지']))
print(count, '명 출석')
```
````
hint:
````
바뀐 곳은 2번째 줄 `count = 5`입니다. 그 줄 때문에 달라지는 값부터 보세요.
````
answer(A):
````
False
<class 'bool'>
7 명 출석
````
kind predict · rung changed · 펜스 이름 'python' → 언어 py
### 보인 코드를 돌린 결과(조항 3)
```
False
<class 'bool'>
7 명 출석
```
여러 번 돌린 결과가 모두 같음: True · 5초 넘음: False
### 도구(⚙)
- 조항 7: (ㄱ) 예 · (ㅁ) 예 · (ㅂ) 예 · (ㅈ) 예 · (ㄴ) 예 · (ㄷ) 예 · (ㄹ) 예 · (ㅅ) 예 · (ㅇ) 예
- 조항 10: (i) 예 · (ii) 예 · (iii) 예 · (iv) 예
- (가) 도구 결과: ⚙ 모두 갖춤
- (나) 도구 결과: 맞음(6 · 11 (tool))

