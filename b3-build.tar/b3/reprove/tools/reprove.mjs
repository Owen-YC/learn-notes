// Batch 3 re-proof (0 model calls): the design's offline evidence re-made from the tree at TREE, written under OUT.
//   note/r request lines (build.mjs note · r), what askNote stores of r and the line it opens (build.mjs stored),
//   and the replay of the saved check replies (replay.mjs), for dev sets 1–3, both models, every label and round.
import { mkdirSync, writeFileSync } from 'node:fs'
import { N, C, samples, readJson, shownOf, noteOf } from './lib.mjs'
import { keptNote, outOf, R_AT, ASKED_AT, LEVEL, DEV, NUMS, rLine, readR } from './build.mjs'
const OUT = process.env.OUT
if (!OUT) throw new Error('OUT unset')
mkdirSync(OUT, { recursive: true })
const PD = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G5/pilot'
const LABELS = { set1: ['X', 'Y'], set2: ['V', 'W'], set3: ['S', 'T'] }
for (const set of ['set1', 'set2', 'set3']) {
  const P = `${PD}/${set}`
  const all = samples(`${DEV}/${set}`)
  for (const model of ['haiku', 'sonnet']) {
    const note = all.map(({ sample, entry }) => {
      const shown = shownOf(noteOf(entry, sample))
      return { id: sample.id, model, system: N.SYSTEM, prompt: N.redactText(N.notePrompt(shown, LEVEL, N.knownNames({}), undefined)).text, maxTokens: NUMS.NOTE_TOKENS, timeoutMs: NUMS.MODEL_TIMEOUT_MS }
    })
    writeFileSync(`${OUT}/${set}-note-lines-${model}.jsonl`, note.map(l => JSON.stringify(l)).join('\n') + '\n')
    const notes = outOf(`${P}/note/${model}/out.json`)
    const rs = outOf(`${P}/r/${model}/out.json`)
    const lines = []
    const stored = {}
    for (const { sample, entry } of all) {
      const n = notes[sample.id]
      if (!n?.isAnswered || !n.text?.trim()) continue
      lines.push(rLine(model, sample, entry, n.text).line)
      const r = rs[sample.id]
      if (!r) continue
      const got = readR(sample, entry, n.text, r.isAnswered ? r.text : '')
      const call = got.think?.call
      const name = call ? /^([A-Za-z_$][\w$]*)\(/.exec(call)[1] : undefined
      const callee = got.scope.callees.find(c => c.name === name)
      const calc = call ? C.calcCall(got.scope.mods.get(callee.file), call) : undefined
      stored[sample.id] = { line: got.think?.question, call, calc: calc ? (calc.kind === 'value' ? `RETURN ${calc.show}` : calc.kind === 'error' ? `ERROR ${calc.name}` : 'UNKNOWN') : undefined, stored: got.stored }
    }
    writeFileSync(`${OUT}/${set}-r-lines-${model}.jsonl`, lines.map(l => JSON.stringify(l)).join('\n') + '\n')
    writeFileSync(`${OUT}/${set}-stored-${model}.json`, JSON.stringify(stored, null, 1) + '\n')
    for (const label of LABELS[set]) for (const round of ['n1', 'n2']) {
      const qs = Object.fromEntries(readJson(`${P}/questions-${label}.json`).questions.map(q => [q.q, q]))
      const texts = readJson(`${P}/texts-${label}.json`).texts
      const st = readJson(`${P}/r/stored-${model}.json`)
      const byId = Object.fromEntries(all.map(one => [one.sample.id, one]))
      const old = Object.fromEntries(readJson(`${P}/n/read-${label}-${round}.json`).map(r => [r.id, r]))
      let res
      try { res = outOf(`${P}/n/${model}-${round}/out.json`) } catch { continue }
      const rows = []
      let isMine = true
      for (const t of texts) {
        const id = qs[t.q].id
        const { sample, entry } = byId[id]
        const kn = { ...keptNote(sample, entry, notes[id].text), asks: [{ question: N.TRACE_LABEL, answer: st[id].stored, at: R_AT }] }
        const shown = shownOf(kn)
        const think = N.openThink(shown.asks, ASKED_AT, true, true)
        if (think === undefined) { isMine = false; break }
        const masked = N.redactText(t.text).text
        const plan = N.thinkCalcPlan(shown, think, masked, LEVEL, N.thinkVariantOf(model))
        const seen = [shown.text, think.trace, masked, ...shown.changes.map(c => c.diff)].join('\n')
        const r = res[`${t.q}-${t.k}`]
        const o = old[`${t.q}-${t.k}`]
        let text = ''
        if (plan.kind === 'code') text = N.cut(plan.text, 4000)
        else if (plan.kind === 'check') { if (o.path === 'code') text = null; else if (r?.isAnswered) text = N.cut(N.thinkCalcReply(r.text, plan.facts, masked, seen), 4000) }
        const req = plan.kind === 'check' ? { system: plan.system, prompt: plan.prompt } : undefined
        rows.push({ id: `${t.q}-${t.k}`, path: plan.kind, shown: text, req })
      }
      if (!isMine) continue
      writeFileSync(`${OUT}/${set}-read-${label}-${round}-${model}.json`, JSON.stringify(rows, null, 1) + '\n')
    }
  }
}
console.log('done', OUT)
