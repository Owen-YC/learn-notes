"""Compare the re-made outputs (OUT dir) with the design's recorded final files (design/G5/final/replay)."""
import json, sys, glob, os
out, rec = sys.argv[1], sys.argv[2]
bad = 0; n = 0
for s in ('set1', 'set2', 'set3'):
    for m in ('haiku', 'sonnet'):
        a = json.load(open(f'{out}/{s}-stored-{m}.json')); b = json.load(open(f'{rec}/{s}-stored-{m}.json'))
        for k in sorted(set(a) | set(b)):
            n += 1
            x = a.get(k); y = b.get(k)
            if x is None or y is None or any(x.get(f) != y.get(f) for f in ('line', 'call', 'calc', 'stored')):
                bad += 1; print('STORED DIFF', s, m, k)
for f in sorted(glob.glob(f'{rec}/read-*-n?.json')):
    lab, rnd = os.path.basename(f)[5:-5].split('-')
    recd = {r['id']: r['shown'] for r in json.load(open(f))}
    cands = glob.glob(f'{out}/set*-read-{lab}-{rnd}-*.json')
    hits = []
    for c in cands:
        mine = {r['id']: r['shown'] for r in json.load(open(c))}
        diff = [k for k in recd if mine.get(k) != recd[k]]
        hits.append((len(diff), os.path.basename(c), diff[:5]))
    hits.sort()
    n += 1
    print('READ', lab, rnd, 'best', hits[0][1], 'differ', hits[0][0], hits[0][2], '| others', [(h[1], h[0]) for h in hits[1:]])
    if hits[0][0]: bad += 1
print('compared', n, 'bad', bad)
