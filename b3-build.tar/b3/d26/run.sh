#!/bin/bash
# batch 3 build: D26 recheck on the working-tree snapshot impl113/b3/d26/tree (0 model calls).
# isRuleWide haiku + sonnet: impl113/d26/rulewide113.mjs --extra impl112/b1/audit/d26x/extra.json (isRuleDrill haiku OFF after batch 1: one run).
# G2 haiku: impl113/d26/g2haiku.sh. isRuleDrill haiku: not ON (batch 1 STOP); G2 sonnet: not ON (batch 2 STOP) → no recheck.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b3
H=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/d26
X=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1/audit/d26x/extra.json
export DISABLE_AUTOUPDATER=1
cd "${S:?}/d26" || exit 1
[ -e STARTED ] && { echo "refuse: STARTED exists"; exit 9; }
date -u +%FT%TZ > STARTED
node --experimental-transform-types --no-warnings "$H/rulewide113.mjs" "$S/d26/tree" "$S/d26/out-rw" --extra "$X" > rw.log 2> rw.err; echo $? > rw.exit
"$H/g2haiku.sh" "$S/d26/tree" "$S/d26/out-g2" > g2.log 2>&1; echo $? > g2.exit
date -u +%FT%TZ > DONE
