#!/bin/bash
# usage: sub.sh <name> <test files comma-sep>  : copy repo (working tree) to rv/run-<name> with only those tests, run pinned plugin test
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3
R=/home/user/learn-notes
D="${S:?}/run-$1"
rm -rf "${D:?}"; mkdir -p "$D/tests"
cp -r $R/hooks $R/types $R/.claude-plugin $R/tsconfig.json "$D/"; [ -f $R/package.json ] && cp $R/package.json "$D/"
ln -s $R/node_modules "$D/node_modules"
cp -r $R/tests/fixtures "$D/tests/"; cp $R/tests/flowkit.ts "$D/tests/"
IFS=, read -ra T <<< "$2"; for t in "${T[@]}"; do cp "$R/tests/$t" "$D/tests/"; done
cd "$D" && /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh claude plugin test . > "$S/$1.out" 2>&1; echo "exit $?" >> "$S/$1.out"
grep -E "^\(fail\)| pass$| fail$|^exit" "$S/$1.out" | cut -c1-260
