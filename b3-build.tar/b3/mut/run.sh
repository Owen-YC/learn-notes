#!/bin/bash
M=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b3/mut
export DISABLE_AUTOUPDATER=1
[ -e "$M/STARTED" ] && exit 9
date -u +%FT%TZ > "$M/STARTED"
python3 "$M/mut.py" > "$M/mut.log" 2>&1; echo $? > "$M/mut.exit"
date -u +%FT%TZ > "$M/DONE"
