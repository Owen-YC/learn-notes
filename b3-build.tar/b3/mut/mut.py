"""Batch 3 build mutation probes (0 model calls): G5.json tests.mutationProbes m1, m5-m12 on a copy of the working-tree
snapshot impl113/b3/tree (the module layout: calc.ts or notes.ts), each run with the G5 test files (think113, think112,
flowkit and fixtures) through the pinned CLI; a mutation dies when a test fails. Output: impl113/b3/mut/result.txt."""
import subprocess, shutil, os, re
B = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b3'
P = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/cli/pinned.sh'
M = {
 'm1 pyRound half-up': ('calc.ts', "    const s = pyHalfEven(x, 0)\n", "    const s = String(Math.floor(Math.abs(x) + 0.5))\n"),
 'm5 the line ending on a stop': ('notes.ts', "적어 보세요 (오류면 \\`오류\\`)`\n}", "적어 보세요 (오류면 \\`오류\\`).`\n}"),
 'm6 no regex shape check': ('calc.ts', "      if (!isSafeRegex(source)) calcNo('regex shape')\n", ""),
 'm7 answerKept falls back to the line reason': ('notes.ts', "  return body !== '' ? body : SLOT_UNREAD\n}", "  return body !== '' ? body : calcReasons(facts, facts.asked).join(' ') || SLOT_UNREAD\n}"),
 'm8 py int equals py float': ('calc.ts', "  if (typeof a === 'bigint' || typeof b === 'bigint') return typeof a === typeof b && a === b", "  if (typeof a === 'bigint' || typeof b === 'bigint') return Number(a) === Number(b)"),
 'm9 no unit-word match for a string result': ('notes.ts', "  if (typeof run.value === 'string' && typeof guess.value !== 'string' && guess.said !== undefined && !guess.isPlain)", "  if (false && typeof run.value === 'string' && typeof guess.value !== 'string' && guess.said !== undefined && !guess.isPlain)"),
 'm10 learner literal call not read': ('notes.ts', "  if (mineCalls.length === 1) return mineCalls[0]\n", ""),
 'm11 no render size check': ('calc.ts', "    if (calcSizeOver(value, CALC_SHOW_MAX)) calcNo('size')\n", ""),
 'm12 no claimed-result check': ('notes.ts', "    return claimed.every(v => isIn(own, v, `${code}\\n${mine}`)) && !claimed.some(isAnswer)", "    return true"),
}
out = []
for name, (f, a, b) in M.items():
    src = open(f'{B}/tree/hooks/{f}', encoding='utf-8').read()
    assert src.count(a) == 1, (name, src.count(a))
    d = f'{B}/mut/w'
    if os.path.exists(d): shutil.rmtree(d)
    os.makedirs(f'{d}/tests')
    for x in ('hooks', 'types', '.claude-plugin'): shutil.copytree(f'{B}/tree/{x}', f'{d}/{x}')
    shutil.copy(f'{B}/tree/tsconfig.json', d)
    shutil.copytree(f'{B}/tree/tests/fixtures', f'{d}/tests/fixtures')
    for t in ('flowkit.ts', 'think113.test.ts', 'think112.test.ts'): shutil.copy(f'{B}/tree/tests/{t}', f'{d}/tests/{t}')
    open(f'{d}/hooks/{f}', 'w', encoding='utf-8').write(src.replace(a, b))
    r = subprocess.run(['timeout', '900', P, 'claude', 'plugin', 'test', '.'], cwd=d, capture_output=True, text=True, env={**os.environ, 'DISABLE_AUTOUPDATER': '1'})
    text = r.stdout + r.stderr
    fails = [l for l in text.splitlines() if l.startswith('(fail)')]
    m = re.search(r'(\d+) pass', text)
    out.append(f'{name} [{f}]: {len(fails)} failing (exit {r.returncode}, pass {m.group(1) if m else "?"})' + ''.join('\n   ' + re.sub(r' \[[\d.]+ms\]$', '', x) for x in fails))
    if not fails and r.returncode != 0: out[-1] += '\n   ' + '\n   '.join(text.strip().splitlines()[-6:])
    print(out[-1], flush=True)
open(f'{B}/mut/result.txt', 'w').write('\n'.join(out) + '\n')
