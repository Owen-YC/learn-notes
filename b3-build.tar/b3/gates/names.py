import sys,re
cur=None;out=[]
for line in open(sys.argv[1],encoding='utf-8',errors='replace'):
    line=line.rstrip('\n')
    m=re.match(r'^(tests/\S+\.ts):$',line)
    if m: cur=m.group(1); continue
    m=re.match(r'^\((pass|fail|skip|todo)\) (.*?)(?: \[[\d.]+m?s\])?$',line)
    if m and cur: out.append(f'{cur} :: {m.group(2)}')
print('\n'.join(sorted(out)))
