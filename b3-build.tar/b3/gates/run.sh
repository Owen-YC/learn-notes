#!/bin/bash
# gates on the working tree (tsc installed; validate and test through the pinned CLI); usage: run.sh <outdir>
G=$1; P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/cli/pinned.sh
export DISABLE_AUTOUPDATER=1
mkdir -p "$G"; cd /home/user/learn-notes || exit 1
date -u +%FT%TZ > "$G/STARTED"
git rev-parse HEAD > "$G/head.txt"; git status --short > "$G/status.txt"
npx tsc -p . --noEmit > "$G/tsc.log" 2>&1; echo $? > "$G/tsc.exit"
"$P" claude plugin validate . > "$G/validate.log" 2>&1; echo $? > "$G/validate.exit"
"$P" claude plugin test . > "$G/test.log" 2>&1; echo $? > "$G/test.exit"
python3 /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b3/gates/names.py "$G/test.log" > "$G/names.txt"
date -u +%FT%TZ > "$G/DONE"
