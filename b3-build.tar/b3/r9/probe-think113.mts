// learn-notes 1.13.0 batch 3 old-window probe (R9; record): the asks a 1.13.0 window stores while 생각해 보기 is on
// (G5e: r's answer ending on code's own line (thinkCalcKept), then a guess answered by code (thinkCalcPlan 'code') and a
// question answered by the check (thinkCalcReply)), read by seven real builds' functions (git archive under
// impl113/b3/oldprobe: 3f2b4fb 1.7.0 · 7a7b08c 1.7.1 · 3690021 1.8.0 · fca5988 1.9.0 · 3d2f251 1.10.0 · de98243 1.11.0 ·
// 30adc2f 1.12.0) plus 0af3abf (1.12.0 release) and the tree: whether the line opens (thinkOf / openThink, each build's
// default, its closed form, and 1.12.0's called form), whether the text after it follows it (isThinkFollow), screenNote
// over the asks (the stored ask loads as {question, answer, at}), and 1.7.x's askPrompt with the earlier asks.
// usage: node --experimental-transform-types probe-think113.mts
const B = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b3'
const TREE = `${B}/tree`
const T = await import(`${TREE}/hooks/notes.ts`)
const change = { file: 'src/odd.js', path: '/p/src/odd.js', tool: 'Edit', kind: 'update', added: 1, removed: 1, diff: '@@ -1,5 +1,5 @@\n function sumOdd(xs) {\n   let t = 0\n-  for (const x of xs) t += x\n+  for (const x of xs) if (x % 2) t += x\n   return t\n }', isCut: false }
const pyChange = { file: 'app/song.py', path: '/p/app/song.py', tool: 'Write', kind: 'create', added: 3, removed: 0, diff: '@@ -0,0 +1,3 @@\n+def song_seconds(text):\n+    mins, secs = text.split(":")\n+    return int(mins) * 60 + int(secs)', isCut: false }
const NOW = 10_000_000
const cases: Record<string, unknown> = {}
const bad: string[] = []
for (const [name, ch, reply] of [
  ['js', change, '예시 호출: `sumOdd([1, 2, 3])`\n\n1. `t`는 0에서 시작합니다.\n2. 홀수 1과 3만 더해 `t`는 4가 됩니다.\n\n결과: `4`\n\n**생각해 보기:** `sumOdd([5, 7])`의 결과는?'],
  ['py', pyChange, '예시 호출: `song_seconds("3:25")`\n\n1. `mins`는 `"3"`, `secs`는 `"25"`입니다.\n2. 3 * 60 + 25 = 205입니다.\n\n결과: `205`'],
] as const) {
  const scope = T.thinkCalcScope([ch])
  const noteText = '### 한 줄 요약\n바꿈'
  const kept = T.thinkCalcKept(reply, scope, noteText, [ch.diff])
  const call = T.valueThinkOf(kept)
  if (call === undefined) { bad.push(`${name}: the tree made no line`); continue }
  const note = { id: 'n1', turnId: 't1', at: NOW - 600_000, prompt: '바꿔줘', answer: '', changes: [ch], moreFiles: 0, status: 'ready', text: noteText, savedAs: 'ready', withheld: [], asks: [{ question: '예시로 따라가기', answer: kept, at: NOW - 5 * 60_000 }] }
  const think = T.openThink(note.asks, NOW - 4 * 60_000, true, true)
  const plan = T.thinkCalcPlan(note, think, '12요', 'beginner', T.thinkVariantOf('sonnet'))
  if (plan.kind !== 'code') bad.push(`${name}: a value guess did not go to code`)
  const asks = [...note.asks, { question: '12요', answer: plan.kind === 'code' ? plan.text : '', at: NOW - 4 * 60_000 }]
  const full = { ...note, asks }
  const tree = { call, kept, guessShown: asks[1]!.answer, opensOn: T.openThink(asks.slice(0, 1), NOW, true, true)?.call ?? null, opensOff: T.openThink(asks.slice(0, 1), NOW)?.question ?? null, followsOn: T.isThinkFollow(asks, 1, true, true), followsOff: T.isThinkFollow(asks, 1) }
  if (tree.opensOn !== call || tree.opensOff !== null || !tree.followsOn || tree.followsOff) bad.push(`${name}: tree ON/OFF reading`)
  const rows: Record<string, unknown> = { tree }
  for (const c of ['3f2b4fb', '7a7b08c', '3690021', 'fca5988', '3d2f251', 'de98243', '30adc2f', '0af3abf']) {
    const N = await import(`${B}/oldprobe/${c}/hooks/notes.ts`)
    const row: Record<string, unknown> = { traceLabel: N.TRACE_LABEL === undefined ? 'none' : N.TRACE_LABEL === '예시로 따라가기' }
    if (N.thinkOf) row.thinkOf = [N.thinkOf(kept) ?? null, N.thinkOf(kept, true) ?? null]
    if (N.openThink) {
      row.opens = [N.openThink(asks.slice(0, 1), NOW)?.question ?? null, N.openThink(asks.slice(0, 1), NOW, true)?.question ?? null, N.openThink(asks.slice(0, 1), NOW, true, true)?.question ?? null]
      row.follows = [N.isThinkFollow(asks, 1), N.isThinkFollow(asks, 1, true), N.isThinkFollow(asks, 1, true, true)]
      if ((row.opens as unknown[]).some(x => x !== null) || (row.follows as boolean[]).some(Boolean) || (row.thinkOf as unknown[] ?? []).some(x => x !== null)) bad.push(`${name} ${c}: the ON line opens`)
    } else {
      const p = N.askPrompt({ ...full }, '더 알려 줘', 'beginner')
      row.askPrompt = { earlierAsks: p.includes('12요') && p.includes(asks[1]!.answer.slice(0, 40)) }
      if (!(row.askPrompt as { earlierAsks: boolean }).earlierAsks) bad.push(`${name} ${c}: 1.7.x askPrompt lost the asks`)
    }
    const screened = N.screenNote ? N.screenNote(full) : undefined
    row.screened = screened ? JSON.stringify(screened.asks) === JSON.stringify(asks) : 'none'
    if (screened && row.screened !== true) bad.push(`${name} ${c}: screenNote changed the asks`)
    rows[c] = row
  }
  cases[name] = rows
}
console.log(JSON.stringify({ bad, cases }, null, 1))
