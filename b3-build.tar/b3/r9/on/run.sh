#!/bin/bash
D=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b3/r9/on
P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/cli/pinned.sh
export DISABLE_AUTOUPDATER=1
[ -e "$D/STARTED" ] && exit 9
date -u +%FT%TZ > "$D/STARTED"
(cd "$D/tree" && "$P" claude plugin test . > "$D/test.log" 2>&1; echo $? > "$D/test.exit")
date -u +%FT%TZ > "$D/DONE"
