// learn-notes 1.13.0 batch 3 D34 capture (scratch only, never committed): one real request per G5e call kind, caught
// from the plugin test harness (routeCalls) at a tree, printed as `B3CAP <kind> <json>` lines: note; r in scope with an
// anchor; r in scope without one; r out of scope; the check of a question; the fallback (a line calc cannot run in the
// note as it now is); and the code path (a value guessed: no call). Run the same file in two trees and compare the lines.
import { describe, expect, test } from 'claude-code/testing'
import { NOW, PANE_PROPS, finish, pane, routeCalls, start, thinkStore, turn, world } from './flowkit'
import { valueThinkLine } from '../hooks/notes'

const MIN = 60_000
const FN = 'function sumOdd(xs) {\n  let t = 0\n  for (const x of xs) if (x % 2) t += x\n  return t\n}\n'
const WALK = '예시 호출: `sumOdd([1, 2, 3])`\n\n1. `t`는 0에서 시작합니다.\n2. 홀수 1과 3만 더해 `t`는 4가 됩니다.\n\n결과: `4`'
const show = (kind: string, calls: unknown[]) => console.log(`B3CAP ${kind} ${JSON.stringify(calls)}`)

for (const model of ['sonnet', 'haiku'] as const) {
  describe(`b3 D34 capture (${model})`, () => {
    test(`${model}: note, r without an anchor, a value guessed (no call), a question (check)`, { options: { model } }, async ($, on) => {
      const calls = routeCalls(on)
      const w = world(on, 'ok', null, true, new Map())
      w.harness = { isThinkAsked: true }
      w.files.set('/proj/src/odd.js', FN.replace('if (x % 2) ', ''))
      await start($)
      w.answer = '### 한 줄 요약\n홀수만 더합니다.'
      await turn($, () => $.tool.call({ tool: 'Edit', tool_use_id: 'u1', file_path: '/proj/src/odd.js', old_string: 't += x', new_string: 'if (x % 2) t += x' }), 't1', 'sumOdd가 홀수만 더하게 해줘')
      await finish(w)
      show('note', calls.splice(0))
      const ui = await pane($, 'terminal', { ...PANE_PROPS, isFocused: true })
      w.answer = WALK
      await ui.press({ key: 'trace' })
      await w.clock.settle()
      show('r-in-noanchor', calls.splice(0))
      const id = (w.store.get('history') as Record<string, { notes: { id: string }[] }>)['/proj']!.notes.at(-1)!.id
      w.answer = '네.'
      await ui.input({ key: `ask-${id}`, text: '12요' })
      await w.clock.settle()
      show('code-value', calls.splice(0))
      w.answer = '종류: 질문\n짐작값: 없음\n다른 호출: 없음\n식: 없음\n식: 없음\n답: 홀수인지 보는 검사입니다.\n판정: 없음'
      await ui.input({ key: `ask-${id}`, text: '왜 x % 2를 써요?' })
      await w.clock.settle()
      show('check', calls.splice(0))
      await ui.unmount()
      expect(true).toBe(true)
    })
    test(`${model}: r in scope with an anchor`, { options: { model } }, async ($, on) => {
      const calls = routeCalls(on)
      const w = world(on, 'ok', null, true, new Map())
      w.harness = { isThinkAsked: true }
      await start($)
      w.answer = '### 한 줄 요약\n홀수만 더합니다.'
      await turn($, () => $.tool.call({ tool: 'Write', tool_use_id: 'h1', file_path: '/proj/src/odd.js', content: `${FN}console.log(sumOdd([1, 2, 3]))\n` }), 't1', '홀수만 더하는 함수를 만들어줘')
      await finish(w)
      calls.splice(0)
      const ui = await pane($, 'terminal', { ...PANE_PROPS, isFocused: true })
      w.answer = WALK
      await ui.press({ key: 'trace' })
      await w.clock.settle()
      show('r-in-anchor', calls.splice(0))
      await ui.unmount()
    })
    test(`${model}: r out of scope`, { options: { model } }, async ($, on) => {
      const calls = routeCalls(on)
      const w = world(on, 'ok', null, true, thinkStore('css'))
      w.harness = { isThinkAsked: true }
      await start($)
      const ui = await pane($, 'terminal', { ...PANE_PROPS, isFocused: true })
      w.answer = '1. `color`가 red가 됩니다.'
      await ui.press({ key: 'trace' })
      await w.clock.settle()
      show('r-out', calls.splice(0))
      await ui.unmount()
    })
    test(`${model}: the fallback`, { options: { model } }, async ($, on) => {
      const calls = routeCalls(on)
      const asks = [{ question: '예시로 따라가기', answer: `${WALK}\n\n${valueThinkLine('sumOdd([5, 7])')}`, at: NOW - 10 * MIN }]
      const v = world(on, 'ok', null, true, thinkStore('css', asks))
      v.harness = { isThinkAsked: true }
      await start($)
      const ui2 = await pane($, 'terminal', { ...PANE_PROPS, isFocused: true })
      v.answer = '네.'
      await ui2.input({ key: 'ask-think-css', text: '12요' })
      await v.clock.settle()
      show('fallback', calls.splice(0))
      await ui2.unmount()
    })
  })
}
