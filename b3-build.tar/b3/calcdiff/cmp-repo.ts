// calc against the truth files: value shown or error name must equal whenever calc gives a definite result.
import { readFileSync } from 'node:fs'
import { calcModule, calcExpr } from '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b3/tree/hooks/calc.ts'
const [lang, exprFile, truthFile] = process.argv.slice(2) as ['js' | 'py', string, string]
const exprs = readFileSync(exprFile, 'utf8').split('\n').filter(Boolean)
const truth = readFileSync(truthFile, 'utf8').split('\n').filter(Boolean)
const mod = calcModule([[]], lang)
let ok = 0, refused = 0
const bad: string[] = []
const why: Record<string, number> = {}
exprs.forEach((e, i) => {
  const r = calcExpr(mod, e)
  const t = truth[i]!
  if (r.kind === 'unknown') { refused++; why[r.why] = (why[r.why] ?? 0) + 1; return }
  const got = r.kind === 'error' ? `ERROR ${r.name}` : `RETURN ${r.show.replace(/\n/g, '\\n')}`
  if (got === t) ok++
  else bad.push(`${e}\n   calc: ${got}\n   true: ${t}`)
})
console.log(`${lang}: ${exprs.length} exprs, agree ${ok}, refused ${refused}, MISMATCH ${bad.length}`)
console.log(bad.slice(0, 60).join('\n'))
console.log(JSON.stringify(Object.entries(why).sort((a, b) => b[1] - a[1]).slice(0, 25)))
