"""G3 다시: build the re-committed bar subsection from 5bd430e's text (bar-5bd430e.txt) with only the allowed changes.
usage: build.py <UTC 'YYYY-MM-DD HH:MM'> <out.md>"""
import sys

W = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3r/work/recommit"
when, out = sys.argv[1], sys.argv[2]
L = open(f"{W}/bar-5bd430e.txt", encoding="utf-8").read().rstrip("\n").split("\n")
OLDHEAD = "### 기준 · 입장 · 결정 규칙 (재기 전에 정함: 2026-11-14 10:20 UTC, 견본을 쓰거나 모델을 부르기 전)"
assert L[0] == OLDHEAD
body = L[1:]


def sub(old, new):
    hits = [i for i, l in enumerate(body) if old in l]
    assert len(hits) == 1, (old[:60], hits)
    i = hits[0]
    assert body[i].count(old) == 1
    body[i] = body[i].replace(old, new)


def after_line(start, new_lines):
    hits = [i for i, l in enumerate(body) if l.startswith(start)]
    assert len(hits) == 1, (start, hits)
    body[hits[0] + 1:hits[0] + 1] = new_lines


# 1 owner decision (a new line after the owner-questions line)
after_line("- 주인 물음(위 '주인 물음 (기본값)' 5 · 6 · 7 · 8 · 9 · 18", [
    "- (G3 다시) 주인 결정(2026-11-15): 'G3 haiku를 1.12.0에서 다시 할지(기준 · 입장 · 결정 규칙은 글자 그대로 다시 커밋하고 견본 쓰는 쪽 짜임만 나눔)'를 묻자 주인이 '다시 시도해 주세요'라고 답했습니다. 그래서 G3 haiku를 한 회 잽니다. 까닭: 멈춘 회차(아래 '견본 쓰기 STOP', cbad928)는 견본을 얼리지 않았고 잴 모델 호출이 0이라 어느 답도 보지 않았습니다. 그래서 이 회는 같은 설계를 같은 모델에 다시 부르는 다시 재기가 아니라 이 설계 · 모델의 한 회입니다. 앞선 예는 1.11.0 G5의 다시 커밋(위 '기준 · 입장 · 결정 규칙 (1.11.0, 다시 커밋: 2026-11-04 12:40 UTC, …)')입니다. G3 sonnet은 계획 기본값대로 재지 않습니다(Infinity 그대로).",
])

# 2 plan writers line
sub("- 쓰는 쪽(writers): S-A1 + S-A2 + S-O + S-U를 쓰는 새 가린 쓰는 쪽 1–2;",
    "- 쓰는 쪽(writers): S-A1 + S-A2 + S-O + S-U를 쓰는 새 가린 쓰는 쪽 ~~1–2~~ (G3 다시) 14(나눈 짜임, 아래 '읽는 법' 6; 주인 결정);")

# 3 usage: the Opus count follows the writer count
sub("Opus: 견본 쓰는 쪽 1–2, 채점 답 쓰는 쪽 1(+ 다시 부르기 1), 판정자 1, 번역 확인, 감사, 검토자 2 ≈ 8회.",
    "Opus: 견본 쓰는 쪽 ~~1–2~~ (G3 다시) 14(+ 호출마다 다시 부르기 많아야 1, 앞뒤 'ok' 세션 2), 채점 답 쓰는 쪽 1(+ 다시 부르기 1), 판정자 1, 번역 확인, 감사, 검토자 2 ≈ ~~8회~~ (G3 다시) 20회.")

# 4 reading 6: the split layout
sub("6. 쓰는 쪽의 수와 다시 부르기: 쓰는 쪽은 둘입니다(A: S-A1 + S-A2 68개, B: S-O 채우는 것 6개 + S-U 9개; 계획 '1–2'). ",
    "6. 쓰는 쪽의 수와 다시 부르기: ~~쓰는 쪽은 둘입니다(A: S-A1 + S-A2 68개, B: S-O 채우는 것 6개 + S-U 9개; 계획 '1–2').~~ "
    "(G3 다시) 쓰는 쪽은 `gen/parts.json`의 호출 14번이고, 호출마다 새 가린 쓰는 쪽입니다. 한 호출은 한 세트 종류만, 기록 10개 이하를 씁니다: "
    "S-A 12번(세트 P마다 T js pT01–pT06 · T py pT07–pT12 · R js pR01–pR06과 pR07–pR12 · R py pR13–pR17과 pR18–pR22, 세트 Q도 q로 같은 꼴), "
    "S-O 1번(om1 · om2 · os1 · os2 · oc1 · oc2), S-U 1번(ou1–ou9). 기록의 수 · id · 무리 · 언어와 예비 자리(그래서 잴 것 js 16 · py 14)는 멈춘 회차의 쓰는 쪽 A · B와 같습니다. "
    "세트마다의 최소 몫(이름난 함정 5 · 반복 안에서 찍음 4 · 문자열을 찍음 3 · True/False/None을 찍는 py 3 · 3줄을 찍음 3)은 그 세트의 호출들에 나눠 적었고, 호출마다의 몫을 더하면 세트마다의 최소와 같습니다(7). "
    "한 답 안에서 같은 개념을 막던 것은 호출을 사슬로 이어 지킵니다: 사슬 A는 S-A 12번을 차례로, 사슬 B는 S-O 다음 S-U이고, 두 사슬은 함께 돕니다. "
    "호출마다 프롬프트에 같은 사슬에서 먼저 읽은 기록의 이름과 파일 경로를 넣어 같은 개념 · 이름 · 파일을 쓰지 말라고 합니다. "
    "모든 호출을 읽으면 `gen/parts.py assemble`이 답을 고치지 않고 호출 차례대로 `gen/out/A1/result.txt`({P, Q})와 `gen/out/B1/result.txt`로 묶고, 얼리기(아래 '도구가 글을 읽는 방식' 3)가 그것을 읽습니다. "
    "(G3 다시 끝) ")
sub("다시 부르는 것은 답에 읽을 수 있는 JSON 값이 하나도 없을 때뿐이고(G-7의 꼴을 견본 쓰는 쪽에 쓴 도구 규칙, 같은 프롬프트 파일), 그것도 읽을 수 없으면 STOP(재지 않음, 보고)입니다.",
    "다시 부르는 것은 (G3 다시: 호출마다) 답에 읽을 수 있는 JSON 값이 하나도 없을 때뿐이고(G-7의 꼴을 견본 쓰는 쪽에 쓴 도구 규칙, 같은 프롬프트 파일), 그것도 읽을 수 없으면 STOP(재지 않음, 보고)입니다 "
    "(G3 다시: 한 호출이라도 STOP이면 두 사슬 모두 다음 호출을 하지 않고 아무것도 얼리지 않습니다. 묶은 답에서 얼리기가 'WRITE <part> 2'(종료 5)를 내면 그것도 STOP입니다. 호출마다의 다시 부르기는 이미 했기 때문입니다).")

# 5 reading 7: minimums per set spread over the set's calls
sub("세트마다(34개) 쓰는 쪽 프롬프트에 최소로 적고,",
    "세트마다(34개) ~~쓰는 쪽 프롬프트에~~ (G3 다시) 그 세트의 호출 프롬프트들에 나눠(호출마다의 몫의 합 = 세트마다의 최소) 최소로 적고,")

# 6 how the tools read, 2: writing the samples
sub("2. 견본 쓰기(`gen/writer-A.md` · `gen/writer-A-end.md` · `gen/writer-B.md` · `gen/writer-B-end.md` · `gen/avoid.py` · `gen/run.sh`): ",
    "2. 견본 쓰기(~~`gen/writer-A.md` · `gen/writer-A-end.md` · `gen/writer-B.md` · `gen/writer-B-end.md` · `gen/avoid.py` · `gen/run.sh`~~ "
    "(G3 다시) `impl112/b3r/gen/`의 `writer-A-part.md` · `writer-A-part-end.md` · `writer-O.md` · `writer-O-end.md` · `writer-U.md` · `writer-U-end.md` · "
    "`parts.json` · `parts.py` · `avoid.py` · `run.sh` · `gate.py` · `precheck.sh` · `record.py`): ")
sub("와 S-U(ou1–ou5 js, ou6–ou9 py)를 씁니다. ",
    "와 S-U(ou1–ou5 js, ou6–ou9 py)를 씁니다 (G3 다시: '쓰는 쪽 A'는 S-A 호출 12번, '쓰는 쪽 B'는 S-O 호출 1번과 S-U 호출 1번이고, 쓰는 기록은 같음; '읽는 법' 6). ")
sub("범위(ts · 타입 · 실행 차례 · 문자열 글자 개념 없음)와 세트마다의 최소 몫을 적은 것입니다. ",
    "범위(ts · 타입 · 실행 차례 · 문자열 글자 개념 없음)와 세트마다의 최소 몫을 적은 것입니다 "
    "(G3 다시: 나눈 프롬프트는 멈춘 회차의 `b3/gen/writer-A.md` · `writer-A-end.md` · `writer-B.md` · `writer-B-end.md`를 글자 그대로 잘라 썼습니다. 바꾼 것은 "
    "두 세트의 id와 몫을 적은 문단을 그 호출의 문단(id · 무리 · 언어 · 그 호출의 몫, '여러 호출로 쓰는 세트의 한 부분')으로, 'no two records anywhere in this reply'를 'no two records in this reply'로, "
    "S-O · S-U의 'four arrays'를 'three arrays' · 'one array'로 나눈 것, 앞 호출의 이름 · 파일 절, 끝 글의 답 꼴(그 호출의 배열 · 객체)뿐입니다). ")
sub("피할 이름 절은 `gen/avoid.py`(묶음 2 것, 머리 글만 바꿈)가 그때의 NAMES-all.txt에서 짓습니다. ",
    "피할 이름 절은 ~~`gen/avoid.py`(묶음 2 것, 머리 글만 바꿈)~~ (G3 다시) `b3r/gen/avoid.py`(교차 검토 1의 교훈: 견본.md에서 온 줄과 모델 · 별칭 · 스위치 낱말을 넣지 않음)가 그때의 NAMES-all.txt에서 짓습니다 "
    "(G3 다시: 목록은 셋입니다 — 개념 이름(NAMES-all.txt에서 출처가 기록 파일인 줄만, '<주제>: <상황>'은 주제만, 2–30자), 파일 이름, 코드 이름(3자 이상 식별자, id 꼴은 뺌); 1.8.0 · 1.9.0의 파일 · 함수 이름 `impl111/b7/gen/names.json`도 넣음). ")
sub("답 · 시각 · 쓴 쪽을 `gen/out/<쓰는 쪽><회>/`에 둡니다.",
    "답 · 시각 · 쓴 쪽을 ~~`gen/out/<쓰는 쪽><회>/`~~ (G3 다시) `b3r/gen/out/parts/<호출>-<회>/`에 둡니다 "
    "(G3 다시: `run.sh`는 떼어 낸 러너이고 `gen/out/STATUS`에 DONE · STOP <호출> · WAIT <resetsAt> · RECORD-STOP · VOID를 씁니다. "
    "앞뒤의 opus 'ok' 세션(`precheck.sh`, `record.py`)과 `gate.py`로 고정한 길 2.1.323과 그 sha256(묶음 0과 같음), 쓰는 쪽 모델 기록(멈춘 회차의 쓰는 쪽 B1 기록과 같음)을 앞 · 호출마다 · 뒤에 보고, 앞에서 사용량 관문(five_hour ≤ 0.60, seven_day + 0.05 < 0.80)을 봅니다. "
    "앞 기록이 다르면 RECORD-STOP(호출 0), 관문을 못 넘으면 WAIT(호출 0: 리셋 뒤 그 `gen/out`을 지우지 않고 `b3r/work/` 아래로 옮겨 두고 다시 띄움), 호출 하나나 뒤 기록이 다르면 VOID(얼리지 않음, STOP과 같이 재지 않음 · 보고)입니다).")

# 7 how the tools read, 3: freezing reads the assembled replies
sub("쓰는 쪽 답 · 기록 · 짜임 · 확인 결과 · 이름(NAMES.txt)을 `frozen/`에 chmod 444로 둡니다.",
    "쓰는 쪽 답 · 기록 · 짜임 · 확인 결과 · 이름(NAMES.txt)을 `frozen/`에 chmod 444로 둡니다 "
    "(G3 다시: 얼리기의 세 파일은 `impl112/b3r/tools/`의 사본(sha256이 b3 것과 같음)으로 돌려, 자기 자리에서 `b3r/gen/out`의 묶은 답(A1, B1)을 읽고, 얼린 것은 `impl112/b3/frozen/`(멈춘 회차에서 비어 있음)에 둡니다. "
    "그 밖의 도구(4–17)는 `impl112/b3/`의 얼린 도구를 그 자리에서 씁니다).")

# 8 tools heading and list paragraph
sub("#### 틀과 도구 (sha256, 이 커밋으로 얼림, 저장소 밖 `impl112/b3/` 아래, chmod 444)",
    "#### 틀과 도구 (sha256, 이 커밋으로 얼림, 저장소 밖 `impl112/b3/` 아래 (G3 다시: 견본 쓰기 `gen/`과 얼리기 사본 셋은 `impl112/b3r/` 아래), chmod 444)")
sub("목록 파일 `impl112/b3/bar/tools.sha256`(chmod 444) sha256 `825c0076645571d8e0b2f19a83a36a7260a55914c890efb5ab6a7c6dc870cc5e`. ",
    "목록 파일 `impl112/b3/bar/tools.sha256`(chmod 444) sha256 `825c0076645571d8e0b2f19a83a36a7260a55914c890efb5ab6a7c6dc870cc5e`. "
    "(G3 다시: 그 53개는 5bd430e로 얼린 그대로이고, 이 다시 커밋 전에 모두 같았습니다(다름 0). 그 목록의 `gen/` 여섯 줄(멈춘 회차의 쓰는 쪽)은 이 회에서 쓰지 않고, 아래 표에서 `b3r/` 줄로 바꿨습니다. "
    "견본 쓰기의 목록 파일은 `impl112/b3r/gen/SHA256SUMS`(chmod 444, 13개) sha256 `dad6e06073b292c366159cf6fa99da14a90d3af4786d8456fba7bdb2615c3c0c`입니다.) ")

# 9 table rows: the six writer rows -> the b3r rows
OLDROWS = [
    "| `gen/writer-A.md` | 쓰는 쪽 A 프롬프트 앞(S-A1 + S-A2 68개) | `91d82c42ee878216f0d150214ee845e855071d89adf58ee83c4a765a3769a513` |",
    "| `gen/writer-A-end.md` | 쓰는 쪽 A 프롬프트 끝 | `92162f25417de839a4bacdff059cc4fbd5362c0185ab90d302340e6e70fc0ad0` |",
    "| `gen/writer-B.md` | 쓰는 쪽 B 프롬프트 앞(S-O 6 + S-U 9) | `40c2b534547638b611a8b048a9fb107f45992308f3b90ded172ad86ae5c4c858` |",
    "| `gen/writer-B-end.md` | 쓰는 쪽 B 프롬프트 끝 | `3fea3bfc3339c61b9a9e868af9ed125322895a4b147879b1abbbbe9b3b1edff8` |",
    "| `gen/avoid.py` | 피할 이름 절(NAMES-all.txt에서) | `e25ab57f921d9b2dbbd2bbb32b32e6133e988f895c4a08bc34a3d4072f4be295` |",
    "| `gen/run.sh` | 견본 쓰는 쪽 실행 | `fc0c294863444d88a8a73d79753322378ba0057132b2b1bfbdec34e99b13e493` |",
]
NEWROWS = [
    "| `../b3r/gen/writer-A-part.md` | (G3 다시) S-A 호출 프롬프트 앞(한 호출 5–6개, 그 호출의 문단을 넣음) | `67bc07412fbb56fc8003c885a674246cf2295059909f6eaa002dca4ed93138fa` |",
    "| `../b3r/gen/writer-A-part-end.md` | (G3 다시) S-A 호출 프롬프트 끝 | `e42c38a7437f379223e9cc8bf2d0be014cba3a6651342bb1edf9f0964efd0316` |",
    "| `../b3r/gen/writer-O.md` | (G3 다시) S-O 호출 프롬프트 앞(6개) | `dede7d8f01afef04dbc75ecb08df22d564276b25afc04b1af2bfc545a9d8c526` |",
    "| `../b3r/gen/writer-O-end.md` | (G3 다시) S-O 호출 프롬프트 끝 | `50e7e840a7f4ea108699d6b91ce94e1cd378dc39c66a273807b93d89b04bd784` |",
    "| `../b3r/gen/writer-U.md` | (G3 다시) S-U 호출 프롬프트 앞(9개) | `bbc57f3b0fd836ad5222152680b069ac591db0bf93301fd2882b5b203d68a467` |",
    "| `../b3r/gen/writer-U-end.md` | (G3 다시) S-U 호출 프롬프트 끝 | `7fcebf466c7de773bb0cd42f341be47e6963ff8dc3d97a355bf110b3d3fc7cb5` |",
    "| `../b3r/gen/parts.json` | (G3 다시) 나눈 짜임(호출 14, 사슬 둘, 호출마다의 id와 몫) | `6b6c2d67a82027313d479623bb18f4b3f7182842a31157bc4f03677496f40651` |",
    "| `../b3r/gen/parts.py` | (G3 다시) 호출 프롬프트 짓기 · 답 읽기 · 묶기(A1, B1) | `d8d9ce393ff2e0a3b92ad30df4efbce23902e0781ba38bee58003b690d679708` |",
    "| `../b3r/gen/avoid.py` | (G3 다시) 피할 이름 절(NAMES-all.txt에서; 개념 · 파일 · 코드 이름) | `a1aeca10dddec0c1d20cf6c6719cc3d7b8987b1c01013d51b3a35a9d890e0e5f` |",
    "| `../b3r/gen/run.sh` | (G3 다시) 견본 쓰는 쪽 실행(떼어 낸 러너, 사슬 둘, 호출마다 다시 부르기 한 번) | `a6d02c75ea38d2afc047aefda2ea9c6cd9b7b3299bd57af47b3b104b6aab9578` |",
    "| `../b3r/gen/gate.py` | (G3 다시) 쓰는 쪽 앞뒤 기록 · 사용량 관문 | `ca5aff876a734f3beb3a8616823fc6ecff0fc2300649ac88660786211b964aab` |",
    "| `../b3r/gen/precheck.sh` | (G3 다시) 쓰는 쪽 앞뒤 'ok' 세션 | `5350c56005c6c9f9c48d213a31cc9e5ca1ff48ba57f3ef7d32b091749176b5d2` |",
    "| `../b3r/gen/record.py` | (G3 다시) 'ok' 세션 기록 읽기 | `9336c746216dd17c9672596ea7ce3ec7c39e3a8e2a1b8bb7e48d2990f4bdc504` |",
    "| `../b3r/tools/check.py` | (G3 다시) 얼리기 사본(`tools/check.py`와 같음, `b3r/gen/out`을 읽음) | `9d29754e45f9322a8359675a33ba56831502b5f497e050772bea74d031f9ab06` |",
    "| `../b3r/tools/runlib.py` | (G3 다시) 얼리기 사본(`tools/runlib.py`와 같음) | `be34a5a8623f03399209cbe30bb276588aa4d18903df876a68b67b119d9b710d` |",
    "| `../b3r/tools/kit.mjs` | (G3 다시) 얼리기 사본(`tools/kit.mjs`와 같음) | `8d44597f57dda3a441257e7b46926a435346125edd2932889a4a7a0f319979e8` |",
]
i = body.index(OLDROWS[0])
assert body[i:i + 6] == OLDROWS
body[i:i + 6] = NEWROWS

HEAD = f"### 기준 · 입장 · 결정 규칙 (G3 다시, 다시 커밋: {when} UTC, 견본을 쓰거나 모델을 부르기 전)"
PREFACE = open(f"{W}/preface.md", encoding="utf-8").read().rstrip("\n")
open(out, "w", encoding="utf-8").write("\n".join([HEAD, "", PREFACE] + body) + "\n")
print("ok", len(body))
