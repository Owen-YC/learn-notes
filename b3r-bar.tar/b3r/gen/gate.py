"""learn-notes 1.12.0 G3 retry (b3r): the record and usage gate of a writer stage (the stopped attempt's b3/tools/gate.py
rules, for the writers' alias opus; no haiku/sonnet call).
  pre <precheck dir> <projection>   exit 0 pass, 3 STOP (record differs), 7 WAIT (five_hour > 0.60 or seven_day +
       projection >= 0.80; resetsAt written as ISO UTC in gate.json)
  after <precheck dir> <pre dir>    exit 0 same, 4 VOID (version, pinned sha256, init model or modelUsage keys differ)
  part <part dir> <pre dir>         exit 0 the part's modelUsage keys are the pre record's init model alone, else 4
The record must equal batch 0's calibration record where batch 0 has one (pinned `claude --version` 2.1.323 (Claude Code),
the pinned binaries' sha256 re-hashed now); the writers' resolved model must equal the stopped attempt's writer record
(impl112/b3/gen/out/B1/model.txt, the last writer that answered) and stay the same before, during and after the stage."""
import datetime, json, subprocess, sys

PINNED = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh"
WRITER_REC = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3/gen/out/B1/model.txt"
VERSION = "2.1.323 (Claude Code)"
PIN = {"claude": "604d29a6869409106b6a1110bdadcc8b72e8654a5a865d23258f938a696e348e",
       "claude.hot": "d2bc14daa55dcae7e85e5e0a7f80fb9c5de4572e9b3bfe28b6f11d89cba45a9e"}
FIVE_MAX, SEVEN_BELOW = 0.60, 0.80


def want():
    return json.loads(open(WRITER_REC).read())


def pin_bad():
    t = subprocess.run([PINNED, "--record"], capture_output=True, text=True).stdout
    got = {l.split()[1]: l.split()[0] for l in t.splitlines() if len(l.split()) == 2 and l.split()[1] in PIN}
    return ([] if f"version: {VERSION}" in t else ["pinned version"]) + [f"pinned {k} sha256" for k in PIN if got.get(k) != PIN[k]]


def rec_bad(d):
    rec = json.load(open(f"{d}/record.json", encoding="utf-8"))
    w = want()
    bad = []
    if list(rec["versions"].values()) != [VERSION]:
        bad.append("version")
    if not rec["inits"] or any([x] != w for x in rec["inits"]):
        bad.append("init model")
    if not rec["results"] or any(r["modelUsage"] != w for r in rec["results"]):
        bad.append("modelUsage keys")
    if rec.get("exit") != "exit=0":
        bad.append(rec.get("exit") or "no exit")
    return rec, bad


def iso(ts):
    return datetime.datetime.fromtimestamp(ts, datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ") if ts else None


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "pre":
        d, proj = sys.argv[2], float(sys.argv[3])
        rec, bad = rec_bad(d)
        bad += pin_bad()
        win = {}
        for ev in rec["rate_limit_events"]:
            for k, v in (ev.get("unifiedWindows") or {}).items():
                win[k] = v
        five, seven = win.get("five_hour", {}), win.get("seven_day", {})
        fu, su = five.get("utilization"), seven.get("utilization")
        ok = fu is not None and su is not None and fu <= FIVE_MAX and su + proj < SEVEN_BELOW
        out = {"recordSame": not bad, "differs": bad, "five_hour": {"utilization": fu, "resetsAt": iso(five.get("resetsAt"))},
               "seven_day": {"utilization": su, "resetsAt": iso(seven.get("resetsAt"))}, "projection": proj,
               "rule": "five_hour <= 0.60 AND seven_day + projection < 0.80", "pass": bool(ok) and not bad}
        json.dump(out, open(f"{d}/gate.json", "w"), indent=1)
        print(json.dumps(out))
        if bad:
            sys.exit(3)
        if not ok:
            sys.exit(7)
    elif mode == "after":
        d, pre = sys.argv[2], sys.argv[3]
        rec, bad = rec_bad(d)
        bad += pin_bad()
        json.dump({"same": not bad, "differs": bad}, open(f"{d}/after.json", "w"), indent=1)
        print(json.dumps({"same": not bad, "differs": bad}))
        sys.exit(4 if bad else 0)
    elif mode == "part":
        d = sys.argv[2]
        got = json.loads(open(f"{d}/model.txt").read())
        sys.exit(0 if got == want() else 4)
    else:
        sys.exit(2)
