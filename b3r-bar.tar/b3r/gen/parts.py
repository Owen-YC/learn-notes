"""learn-notes 1.12.0 G3 retry (b3r): the split writers' helper (gen/parts.json is the layout).
  make <root> <part> <out prompt.md>   build one part's prompt: its template, the part paragraph (ids, group, language,
       per-part minimums), the names and file paths of every earlier part of the same chain already read in <root>, the
       avoid section (gen/avoid.py, written beside the prompt), the end text. Refuses to overwrite.
  read <part dir> <part>               read result.txt with check.py's rule (exactly one ```json block, else the whole
       reply as JSON) and the part's shape (A: an array; O: an object with arrays mine, slips, codeless; U: an object
       with an array unrunnable). Exit 0 readable (reply.json written), 5 not readable. Never edits a reply.
  assemble <root>                      every part read -> <root>/A1/result.txt {"P": [...], "Q": [...]} and
       <root>/B1/result.txt {"mine", "slips", "codeless", "unrunnable"}, each one ```json block, records in part order
       (the shape tools/check.py reads). Exit 6 when a part has no reply.json."""
import json, os, re, subprocess, sys

G = os.path.dirname(os.path.abspath(__file__))
LAYOUT = json.load(open(f"{G}/parts.json", encoding="utf-8"))["parts"]
BY = {p["part"]: p for p in LAYOUT}
SHAPE = {"O": ("mine", "slips", "codeless"), "U": ("unrunnable",)}


def latest(root, part):
    for t in (2, 1):
        d = f"{root}/parts/{part}-{t}"
        if os.path.exists(f"{d}/reply.json"):
            return d
    return None


def records(reply, kind):
    if kind == "A":
        return [r for r in reply if isinstance(r, dict)]
    return [r for k in SHAPE[kind] for r in reply.get(k, []) if isinstance(r, dict)]


def one_line(s):
    return re.sub(r"\s+", " ", str(s)).strip()


def part_paragraph(p):
    n = len(p["ids"])
    grp = "T (tricky pitfall concepts)" if p["group"] == "T" else "R (basic, everyday concepts)"
    text = (f"Write exactly {n} records, ids {p['ids'][0]}..{p['ids'][-1]}, all group {grp} and all {p['language']}."
            " This is one part of a larger set that is written in several parts.\n")
    mins = [f"{v} tagged {k}" for k, v in p["minimums"].items()]
    text += f"Among these {n} records, at least: " + ", ".join(mins) + " (more is fine).\n"
    return text


def chain_section(root, p):
    earlier = []
    for q in LAYOUT:
        if q["part"] == p["part"]:
            break
        if q["chain"] != p["chain"]:
            continue
        d = latest(root, q["part"])
        if d:
            earlier += records(json.load(open(f"{d}/reply.json", encoding="utf-8")), q["kind"])
    rows = []
    for r in earlier:
        name, f = one_line(r.get("name", "")), one_line(r.get("file", ""))
        if name or f:
            rows.append(f"- {name}" + (f" ({f})" if f else ""))
    if not rows:
        return ""
    return ("\nRecords that the other parts already hold. Write no record about the same concept as any of these, and do"
            " not reuse any of their names or file paths:\n" + "\n".join(rows) + "\n")


def make(root, part, out):
    if os.path.exists(out):
        sys.exit(f"refuse: {out} exists")
    p = BY[part]
    d = os.path.dirname(out)
    av, keep = f"{d}/avoid.md", f"{d}/avoid-names.txt"
    r = subprocess.run(["python3", "-I", f"{G}/avoid.py", av, keep], capture_output=True, text=True)
    if r.returncode:
        sys.exit("avoid.py: " + r.stderr)
    open(f"{d}/avoid-count.txt", "w").write(r.stdout)
    avoid = open(av, encoding="utf-8").read()
    if p["kind"] == "A":
        head = open(f"{G}/writer-A-part.md", encoding="utf-8").read().replace("{{PART}}", part_paragraph(p))
        end = open(f"{G}/writer-A-part-end.md", encoding="utf-8").read().replace("{{N}}", str(len(p["ids"])))
    else:
        head = open(f"{G}/writer-{p['kind']}.md", encoding="utf-8").read()
        end = open(f"{G}/writer-{p['kind']}-end.md", encoding="utf-8").read()
    assert "{{" not in head + end
    open(out, "w", encoding="utf-8").write(head + chain_section(root, p) + avoid + end)


def read(d, part):
    kind = BY[part]["kind"]
    text = open(f"{d}/result.txt", encoding="utf-8").read() if os.path.exists(f"{d}/result.txt") else ""
    blocks = re.findall(r"```json[ \t]*\n(.*?)\n```", text, re.S)
    body = blocks[0] if len(blocks) == 1 else (text if not blocks else None)
    v = None
    if body is not None:
        try:
            v = json.loads(body)
        except Exception:
            v = None
    ok = isinstance(v, list) if kind == "A" else (isinstance(v, dict) and all(isinstance(v.get(k), list) for k in SHAPE[kind]))
    json.dump({"part": part, "readable": ok, "blocks": len(blocks), "records": len(records(v, kind)) if ok else 0},
              open(f"{d}/readable.json", "w"), indent=1)
    if not ok:
        sys.exit(5)
    json.dump(v, open(f"{d}/reply.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def assemble(root):
    got = {}
    for p in LAYOUT:
        d = latest(root, p["part"])
        if not d:
            print(f"no reply for {p['part']}")
            sys.exit(6)
        got[p["part"]] = json.load(open(f"{d}/reply.json", encoding="utf-8"))
    A = {"P": [], "Q": []}
    B = {"mine": [], "slips": [], "codeless": [], "unrunnable": []}
    for p in LAYOUT:
        v = got[p["part"]]
        if p["kind"] == "A":
            A[p["set"]] += v
        else:
            for k in SHAPE[p["kind"]]:
                B[k] += v[k]
    for name, v in (("A1", A), ("B1", B)):
        os.makedirs(f"{root}/{name}", exist_ok=False)
        open(f"{root}/{name}/result.txt", "w", encoding="utf-8").write("```json\n" + json.dumps(v, ensure_ascii=False, indent=1) + "\n```\n")
    print(json.dumps({"P": len(A["P"]), "Q": len(A["Q"]), **{k: len(v) for k, v in B.items()}}))


if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "make":
        make(sys.argv[2], sys.argv[3], sys.argv[4])
    elif cmd == "read":
        read(sys.argv[2], sys.argv[3])
    elif cmd == "assemble":
        assemble(sys.argv[2])
    else:
        sys.exit(2)
