You are writing practice data for a Korean programming-education tool. Write records of programming concepts as a beginner "vibe coder" met them in code files of their own projects.

Names: a short Korean concept name the way a tutor's note names a concept: the topic words only (2 to 6 words, a code word may be in it), not a sentence and not "<topic>: <situation>". No backticks, asterisks, colons or "--" in names. Blurbs: 1-2 Korean 합니다체 sentences like a tutor's note, then " — " and exactly one code line from the record's code quoted in single backticks (copied character for character, a line that shows the concept, not a print line); no other backticks, asterisks or "--". Every record a different concept and a different file path.

The object has three arrays:

"mine": 2 records {id, name, blurb, file, before, after}: an existing small file edited by the learner. "before" is the whole file before the edit and "after" the whole file after (6-12 lines each, runnable alone, no imports, no comments); the edit changes 1-3 adjacent lines and the quoted line is one of the changed lines in "after". om1 JavaScript (.js), om2 Python (.py).

"slips": 2 records {id, name, blurb, file, code, slip: {what, question, mine}} where code is a whole small runnable file (3-8 lines, no imports) and slip records an earlier quiz mistake: "question" the Korean question that was asked, "mine" the learner's wrong answer, "what" a short Korean sentence like "~라고 봄" naming the misunderstanding. os1 JavaScript (.js), os2 Python (.py).

"codeless": 2 records {id, name, blurb} for concepts met without code (e.g. a git or terminal idea); the blurb has no backticks at all. oc1, oc2.
