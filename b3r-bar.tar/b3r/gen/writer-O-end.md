
Output ONLY one JSON object {"mine": [...], "slips": [...], "codeless": [...]} inside one ```json fenced block, and nothing else.
You have no tools in this session: do not try to run or test code, and do not write any tool call. Write the JSON block directly as your whole reply.
