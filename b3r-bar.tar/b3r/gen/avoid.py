"""learn-notes 1.12.0 G3 retry (b3r; batch-4 avoid.py style with the lesson of 견본.md '교차 검토 1': no 견본.md prose, no
model, alias or switch words): the writers' avoid section, from impl112/NAMES-all.txt as it is when a writer part runs,
plus impl111/b7/gen/names.json (1.8.0, 1.9.0 file and function names). Three lists:
- concept names: the Korean concept names of earlier sample records only, i.e. NAMES-all rows whose source is a record
  file (every tag but '견본'; rows taken from 견본.md prose are never used), the topic before ': ' of a '<topic>: <situation>'
  dev name, 2-30 characters. They are the names tools/check.py rejects on equality (the committed avoid rule: G3 dev
  sets 1-2, the P1-P6 probe items, the other G dev and measured sets).
- files: an entry with a code or document extension, its last path part.
- code names: an entry that is an identifier of 3+ characters, not an id like K01 or pT01.
Entries holding a model, alias or plugin switch word (WORDS) are left out. Sorted, joined with ' · '.
usage: avoid.py <out.md> <names.txt out>   (refuses to overwrite; the second file keeps the three lists, one a line)"""
import json, os, re, sys

NAMES = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/NAMES-all.txt"
OLD = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl111/b7/gen/names.json"
IDENT = re.compile(r"^[A-Za-z_$][\w$]*$")
ID = re.compile(r"^[A-Za-z]{1,4}\d+[A-Za-z]?\d*$")
FILE = re.compile(r"^[\w./@-]+\.(js|mjs|cjs|ts|mts|cts|tsx|jsx|py|json|md|css|scss|html|go|rb|sh|vue|txt|yml|yaml|toml)$")
HANGUL = re.compile(r"[가-힣]")
WORDS = re.compile(r"(?i)haiku|sonnet|opus|fable|claude|anthropic|model|rung|isrule|isbase|isthink|worked|alias|gateway|bedrock|vertex|override|provider|모델|채점|견본|판정|프롬프트")


def lists():
    rows = [l.rstrip("\n").split("\t") for l in open(NAMES, encoding="utf-8") if l.strip()]
    old = json.load(open(OLD, encoding="utf-8"))
    firsts = [r[0] for r in rows]
    files = sorted({r.rsplit("/", 1)[-1] for r in firsts + old["files"] if FILE.match(r)})
    names = sorted({r for r in firsts + old["functions"] if IDENT.match(r) and len(r) >= 3 and not ID.match(r)})
    concepts = set()
    for r in rows:
        n, tag = r[0], (r[1] if len(r) > 1 else "")
        if tag == "견본" or not HANGUL.search(n) or FILE.match(n):
            continue
        n = n.split(": ")[0].strip()
        if 2 <= len(n) <= 30 and n[0] not in "'\"`":
            concepts.add(n)
    keep = lambda xs: [x for x in xs if not WORDS.search(x)]
    return keep(sorted(concepts)), keep(files), keep(names)


if __name__ == "__main__":
    out, keepf = sys.argv[1], sys.argv[2]
    for p in (out, keepf):
        if os.path.exists(p):
            sys.exit(f"refuse: {p} exists")
    concepts, files, names = lists()
    q = lambda xs: " · ".join(f"`{x}`" for x in xs)
    open(out, "w", encoding="utf-8").write(
        "\nNames already used by earlier sample sets. Do not use any of these concept names as a record's name, and do not"
        " write a record about any of these concepts; do not use any of these file names as a record's file name (the last"
        " part of its path); do not name a function or class you define with any of these code names.\n\n- concept names: "
        + q(concepts) + "\n- file names: " + q(files) + "\n- code names: " + q(names) + "\n")
    open(keepf, "w", encoding="utf-8").write("\n".join(["# concepts"] + concepts + ["# files"] + files + ["# names"] + names) + "\n")
    print(json.dumps({"concepts": len(concepts), "files": len(files), "names": len(names)}, ensure_ascii=False))
