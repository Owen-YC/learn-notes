#!/bin/bash
# learn-notes 1.12.0 G3 retry (b3r; from the stopped attempt's b3/gen/run.sh): the split sample writers. Every part of
# gen/parts.json is one fresh blind writer (`claude -p --model opus --tools '' --output-format json`, prompt on stdin, an
# empty dir of its own, through the pinned CLI cli/pinned.sh with DISABLE_AUTOUPDATER=1). A part asks for at most 10
# records of one set kind: the 12 S-A parts (set P = S-A1, set Q = S-A2; T js 6 · T py 6 · R js 6 + 6 · R py 5 + 5 per
# set) run one after another as chain A, S-O then S-U as chain B, the two chains side by side. A part's prompt =
# its template + part paragraph + the names and file paths of the earlier parts of its chain in this run + the avoid
# section (gen/avoid.py: file names and code names only) + the end text (gen/parts.py make).
# A writer sees only the record form, the code rules, its minimums, the earlier parts' names and the avoid lists: never
# the rule wording, a prompt, the code, the stance, the design or which model is measured.
# Retry ('읽는 법' 6 per part): a reply with no readable JSON value of the part's shape is sent once more with the same
# prompt file byte for byte (<part>-2); a second unreadable reply is a STOP (no third call; the chains halt).
# usage: run.sh <root> [part ...]   root: <b3r>/gen/out (the measured writers, every part) or <b3r>/dev/<name> (dev only,
#        names recorded as dev; with a part list only those parts run, chained among themselves). PROJ = the stage's
#        weekly projection for the usage gate (default 0.05). Refuses when <root>/STATUS exists.
# STATUS: RUNNING <pid> → DONE | STOP <part> | WAIT <resetsAt> | RECORD-STOP | VOID. Detached: the caller waits on STATUS.
R=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3r
P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh
ROOT="$1"; shift
case "$ROOT" in "${R:?}/gen/out"|"${R:?}/dev/"[A-Za-z0-9]*) ;; *) echo "usage: run.sh <b3r>/gen/out | <b3r>/dev/<name> [part ...]"; exit 2;; esac
case "$ROOT" in *..*|*[!A-Za-z0-9/_.-]*) echo "refuse: root path"; exit 2;; esac
if [ "$ROOT" = "${R:?}/gen/out" ] && [ $# -gt 0 ]; then echo "refuse: the measured run runs every part"; exit 2; fi
[ -e "$ROOT/STATUS" ] && { echo "refuse: $ROOT/STATUS exists"; exit 1; }
ALL=$(python3 -I -c 'import json,sys; print(" ".join(p["part"] for p in json.load(open(sys.argv[1]))["parts"]))' "${R:?}/gen/parts.json")
SEL="${*:-$ALL}"
for x in $SEL; do case " $ALL " in *" $x "*) ;; *) echo "unknown part $x"; exit 2;; esac; done
mkdir -p "$ROOT/parts"
echo "RUNNING $$" > "$ROOT/STATUS"
echo "$SEL" > "$ROOT/selected.txt"
"$P" --record > "$ROOT/pin-before.txt" 2>&1

# before record + usage gate (an opus 'ok' session)
"$P" bash "${R:?}/gen/precheck.sh" "$ROOT/pre" > "$ROOT/pre.log" 2>&1
python3 -I "${R:?}/gen/gate.py" pre "$ROOT/pre" "${PROJ:-0.05}" >> "$ROOT/pre.log" 2>&1
g=$?
if [ $g = 3 ]; then echo "RECORD-STOP" > "$ROOT/STATUS"; exit 3; fi
if [ $g = 7 ]; then echo "WAIT $(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["five_hour"]["resetsAt"])' "$ROOT/pre/gate.json")" > "$ROOT/STATUS"; exit 7; fi
[ $g = 0 ] || { echo "RECORD-STOP gate exit $g" > "$ROOT/STATUS"; exit 3; }

call() { # <part dir>
  local d="$1"
  sha256sum "$d/prompt.md" > "$d/prompt.sha256"
  mkdir -p "${R:?}/work/gen-$(basename "$ROOT")-$(basename "$d")"
  date -u +%FT%TZ > "$d/started.txt"
  ( cd "${R:?}/work/gen-$(basename "$ROOT")-$(basename "$d")" && "$P" bash -c 'timeout 3000 claude -p --model opus --tools "" --output-format json' < "$d/prompt.md" > "$d/out.json" 2> "$d/err.txt" )
  echo "exit=$?" > "$d/exit.txt"
  date -u +%FT%TZ > "$d/ended.txt"
  python3 -I - "$d" <<'PY'
import json, sys
d = sys.argv[1]
try:
    o = json.load(open(d + "/out.json", encoding="utf-8"))
except Exception as e:
    o = {"result": "", "is_error": f"unreadable out.json: {e}"}
open(d + "/result.txt", "w", encoding="utf-8").write(o.get("result") or "")
open(d + "/model.txt", "w").write(json.dumps(sorted((o.get("modelUsage") or {}).keys())) + "\n")
u = o.get("usage") or {}
json.dump({"is_error": o.get("is_error"), "stop_reason": o.get("stop_reason"), "safety_stops": o.get("safety_stops"),
           "num_turns": o.get("num_turns"), "output_tokens": u.get("output_tokens"),
           "thinking_tokens": (u.get("output_tokens_details") or {}).get("thinking_tokens"),
           "duration_ms": o.get("duration_ms"), "cost_usd": o.get("total_cost_usd")}, open(d + "/stats.json", "w"))
PY
}

part() { # <part>
  local x="$1" t d
  for t in 1 2; do
    d="$ROOT/parts/$x-$t"
    [ -e "$d" ] && { echo "refuse: $d exists" > "$ROOT/STOP-$x"; return 6; }
    mkdir -p "$d"
    if [ $t = 1 ]; then
      python3 -I "${R:?}/gen/parts.py" make "$ROOT" "$x" "$d/prompt.md" || { echo "make failed" > "$ROOT/STOP-$x"; return 6; }
    else
      cp "$ROOT/parts/$x-1/prompt.md" "$d/prompt.md"
    fi
    call "$d"
    python3 -I "${R:?}/gen/gate.py" part "$d" || echo "model differs" > "$ROOT/VOID-$x"
    python3 -I "${R:?}/gen/parts.py" read "$d" "$x" && return 0
  done
  echo "second reply unreadable" > "$ROOT/STOP-$x"
  return 6
}

chain() { # <A|B>
  local x c
  for x in $SEL; do
    c=$(python3 -I -c 'import json,sys; print({p["part"]: p["chain"] for p in json.load(open(sys.argv[1]))["parts"]}[sys.argv[2]])' "${R:?}/gen/parts.json" "$x")
    [ "$c" = "$1" ] || continue
    ls "$ROOT"/STOP-* > /dev/null 2>&1 && return 6
    part "$x" || return 6
  done
}

chain A & ca=$!
chain B & cb=$!
wait $ca; wait $cb

# after record
"$P" bash "${R:?}/gen/precheck.sh" "$ROOT/after" > "$ROOT/after.log" 2>&1
python3 -I "${R:?}/gen/gate.py" after "$ROOT/after" "$ROOT/pre" >> "$ROOT/after.log" 2>&1
a=$?
"$P" --record > "$ROOT/pin-after.txt" 2>&1
if ls "$ROOT"/STOP-* > /dev/null 2>&1; then echo "STOP $(ls "$ROOT"/STOP-* | xargs -n1 basename | tr '\n' ' ')" > "$ROOT/STATUS"; exit 6; fi
if [ $a != 0 ] || ls "$ROOT"/VOID-* > /dev/null 2>&1; then echo "VOID" > "$ROOT/STATUS"; exit 4; fi
if [ "$SEL" = "$ALL" ]; then
  python3 -I "${R:?}/gen/parts.py" assemble "$ROOT" > "$ROOT/assemble.log" 2>&1 || { echo "STOP assemble" > "$ROOT/STATUS"; exit 6; }
fi
echo "DONE" > "$ROOT/STATUS"
