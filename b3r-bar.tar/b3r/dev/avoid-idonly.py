"""DEV RECORD (b3r, not frozen for the measured run): the identifier-and-file-name-only avoid section used by dev run s1
and diagnostic c (gen/avoid.py before concept names were added). Kept so the variant can be rebuilt; its NAMES path is
the live NAMES-all.txt. usage: avoid-idonly.py <out.md> <names.txt out>"""
import json, os, re, sys

NAMES = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/NAMES-all.txt"
OLD = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl111/b7/gen/names.json"
IDENT = re.compile(r"^[A-Za-z_$][\w$]*$")
ID = re.compile(r"^[A-Za-z]{1,4}\d+[A-Za-z]?\d*$")
FILE = re.compile(r"^[\w./@-]+\.(js|mjs|cjs|ts|mts|cts|tsx|jsx|py|json|md|css|scss|html|go|rb|sh|vue|txt|yml|yaml|toml)$")
WORDS = re.compile(r"(?i)haiku|sonnet|opus|fable|claude|anthropic|model|switch|rung|isrule|isbase|isthink|worked|alias|gateway|bedrock|vertex|override|provider")


def lists(names_path=NAMES):
    rows = [l.split("\t", 1)[0] for l in open(names_path, encoding="utf-8") if l.strip()]
    old = json.load(open(OLD, encoding="utf-8"))
    files = sorted({r.rsplit("/", 1)[-1] for r in rows + old["files"] if FILE.match(r)})
    names = sorted({r for r in rows + old["functions"] if IDENT.match(r) and len(r) >= 3 and not ID.match(r)})
    return [f for f in files if not WORDS.search(f)], [n for n in names if not WORDS.search(n)]


def text(files, names):
    q = lambda xs: " · ".join(f"`{x}`" for x in xs)
    return ("\nNames already used by earlier sample sets: do not use any of these as a record's file name (the last part of"
            " its path), and do not name a function or class you define with any of them.\n\n- files: " + q(files)
            + "\n- names: " + q(names) + "\n")


if __name__ == "__main__":
    out, keep = sys.argv[1], sys.argv[2]
    for p in (out, keep):
        if os.path.exists(p):
            sys.exit(f"refuse: {p} exists")
    files, names = lists()
    open(out, "w", encoding="utf-8").write(text(files, names))
    open(keep, "w", encoding="utf-8").write("\n".join(["# files"] + files + ["# names"] + names) + "\n")
    print(json.dumps({"files": len(files), "names": len(names)}))
