"""learn-notes 1.12.0 G3 (batch 3): running code and the machine (⚙) clauses of the committed stance ('판정의 입장' in
docs/qa/견본.md, 1.12.0 G3 section). Rebuilt from the design pilot's runner.py and judge.py (impl112/design/G3/pilot).
- run(code, lang): stance 5. An empty new temp dir under b3/work/run, stdin empty, `unshare -n timeout 5`; js `node
  case.js` twice and, only when both runs stop on a module syntax error (stderr names 'Cannot use import statement
  outside a module', 'require is not defined in ES module scope', "Unexpected token 'export'" or 'To load an ES
  module'), `node case.cjs` once more, whose run is then the result; py B-14 `env -i PATH=… LANG=C.UTF-8
  PYTHONHASHSEED=n python3 -s -P -B case.py` for n = 1..5. `lines`: stdout with one end newline taken off, split on
  newlines (an empty stdout is no line). `agree`: every run's (exit code, stdout) the same. stderr is never compared.
- ok5(run): exit 0, agree, at most 3 lines, each at most 40 code points.
- forbidden(code, lang): stance 5's list by grep (a hit is listed for the judge, who says whether it is a use).
- n6(line): stance 6: ends trimmed, runs of spaces and tabs one space, one period at the end taken off, the quote kinds
  ' " ` ‘ ’ “ ” read as one kind (a quote there or not stays a difference). same6(answer, run): the answer's lines
  (split on newlines, empty lines kept) equal the run's lines one for one after n6, same count.
- clause3(code, concept, lang): stance 3 (가) (나) (다) -> '가' | '나' | '다' | None.
  (가) the two texts with all white space removed are equal. (나) of the problem code's lines (leaving out blank lines and
  lines made only of ( ) [ ] { } , ; : and spaces) at least half equal, white space removed, some line of the concept
  code. (다) names (identifier tokens other than the language's reserved words and console print len range str int
  float list dict Math Object Array JSON String Number) renamed v1, v2 … by first appearance, white space removed: the
  token lists are equal, or the same length and differ at exactly one place where both tokens are literals (a number or
  a string); compared with the whole concept code and with every run of consecutive concept lines (blank lines left
  out) of the problem code's line count.
- clause7m(prose, code, lines): stance 7's machine rule: a run line's value (n6, 2 characters or more) found in `prose`
  as a word (no letter, digit or underscore of any script right before it, Python's \\w; no ASCII letter, digit or
  underscore right after it, so a Korean ending such as 가 · 이 · 입니다 may follow) while it is not a literal of the
  code (a string literal's text read with n6, a number token, or one of true false null undefined None True False).
  Reserved words (stance 3 (다) '그 언어의 예약어'): js the ECMAScript reserved words (strict-mode and module ones
  included: await, enum, implements, interface, let, package, private, protected, public, static, yield) and the
  literals true false null; py keyword.kwlist. Property and method names are identifiers too.
- fence(question): the question's fenced blocks (a line of ``` or ~~~ and a name opens; the same mark alone closes):
  [(name, code)].
usage as a script: runlib.py <js|py> <file>   (prints the run as JSON)"""
import hashlib, json, keyword, os, re, subprocess, sys, tempfile

ROOT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "work", "run")
_cache = {}
MODULE_ERR = ("Cannot use import statement outside a module", "require is not defined in ES module scope", "Unexpected token 'export'", "To load an ES module")


def _write(d, name, code):
    f = os.path.join(d, name)
    with open(f, "w", encoding="utf-8") as fh:
        fh.write(code if code.endswith("\n") else code + "\n")
    return f


def _go(cmd, d):
    p = subprocess.run(cmd, cwd=d, stdin=subprocess.DEVNULL, capture_output=True, text=True)
    return p.returncode, p.stdout, p.stderr


def run(code, lang):
    key = hashlib.sha256((lang + "\0" + code).encode()).hexdigest()
    if key in _cache:
        return _cache[key]
    os.makedirs(ROOT, exist_ok=True)
    runs, cjs = [], False
    with tempfile.TemporaryDirectory(dir=ROOT) as d:
        if lang == "js":
            f = _write(d, "case.js", code)
            for _ in range(2):
                runs.append(_go(["unshare", "-n", "timeout", "5", "node", f], d))
            if all(r[0] != 0 and any(m in r[2] for m in MODULE_ERR) for r in runs):
                g = _write(d, "case.cjs", code)
                runs = [_go(["unshare", "-n", "timeout", "5", "node", g], d)]
                cjs = True
        elif lang == "py":
            f = _write(d, "case.py", code)
            for n in range(1, 6):
                runs.append(_go(["unshare", "-n", "timeout", "5", "env", "-i", f"PATH={os.environ['PATH']}", "LANG=C.UTF-8", f"PYTHONHASHSEED={n}", "python3", "-s", "-P", "-B", f], d))
        else:
            raise ValueError(f"lang {lang}")
    rc, out, err = runs[0]
    text = out[:-1] if out.endswith("\n") else out
    lines = text.split("\n") if text != "" else []
    res = {"rc": rc, "stdout": out, "lines": lines, "agree": len({r[:2] for r in runs}) == 1, "timeout": any(r[0] == 124 for r in runs), "runs": len(runs), "cjs": cjs, "stderrTail": err.strip().splitlines()[-1][:200] if err.strip() else ""}
    _cache[key] = res
    return res


def ok5(r):
    return r["rc"] == 0 and r["agree"] and len(r["lines"]) <= 3 and all(len(l) <= 40 for l in r["lines"])


FORB = {"js": [r"Math\.random", r"\bDate\b", r"performance\.", r"\bfetch\b", r"XMLHttpRequest", r"WebSocket", r"require\(", r"\bimport\b", r"\bprocess\b", r"\bfs\b", r"\bdocument\b", r"\bwindow\b", r"localStorage", r"sessionStorage", r"alert\(", r"prompt\(", r"readline"],
        "py": [r"\brandom\b", r"\btime\b", r"\bdatetime\b", r"input\(", r"open\(", r"\bos\b", r"\bsys\b", r"subprocess", r"socket", r"urllib", r"requests", r"pathlib"]}


def forbidden(code, lang):
    return [p for p in FORB[lang] if re.search(p, code)]


QUOTES = re.compile(r"['\"`‘’“”]")


def n6(line):
    x = re.sub(r"[ \t]+", " ", line.strip())
    x = re.sub(r"\.$", "", x)
    return QUOTES.sub("'", x)


def same6(answer, r):
    a = answer.split("\n")
    return len(a) == len(r["lines"]) and all(n6(x) == n6(y) for x, y in zip(a, r["lines"]))


JS_RESERVED = set("await break case catch class const continue debugger default delete do else enum export extends false finally for function if implements import in instanceof interface let new null package private protected public return static super switch this throw true try typeof var void while with yield".split())
PY_RESERVED = set(keyword.kwlist)
KEEP = set("console print len range str int float list dict Math Object Array JSON String Number".split())
TOKEN = re.compile(r'"""(?:.|\n)*?"""|\'\'\'(?:.|\n)*?\'\'\'|"(?:\\.|[^"\\\n])*"|\'(?:\\.|[^\'\\\n])*\'|`(?:\\.|[^`\\])*`|\d+(?:\.\d+)?(?:[eE][+-]?\d+)?|[A-Za-z_$][\w$]*|\S')
IDENT = re.compile(r"^[A-Za-z_$][\w$]*$")
LIT = re.compile(r'^(?:["\'`]|\d)')


def tokens(code):
    return TOKEN.findall(code)


def shape(toks, lang):
    keep = (JS_RESERVED if lang == "js" else PY_RESERVED) | KEEP
    names, out = {}, []
    for t in toks:
        if IDENT.match(t) and t not in keep:
            names.setdefault(t, f"v{len(names) + 1}")
            out.append(names[t])
        else:
            out.append(t)
    return out


def squash(t):
    return re.sub(r"\s+", "", t)


def trivial(line):
    return re.fullmatch(r"[\s()\[\]{},;:]*", line) is not None


def _same_or_one_literal(a_toks, b_toks, lang):
    a, b = shape(a_toks, lang), shape(b_toks, lang)
    if a == b:
        return True
    if len(a) != len(b):
        return False
    diff = [i for i, (x, y) in enumerate(zip(a, b)) if x != y]
    return len(diff) == 1 and LIT.match(a_toks[diff[0]]) is not None and LIT.match(b_toks[diff[0]]) is not None


def clause3(code, concept, lang):
    if squash(code) == squash(concept):
        return "가"
    own = [l for l in code.split("\n") if l.strip() and not trivial(l)]
    theirs = {squash(l) for l in concept.split("\n") if l.strip() and not trivial(l)}
    if own and 2 * sum(squash(l) in theirs for l in own) >= len(own):
        return "나"
    ct = tokens(code)
    if _same_or_one_literal(ct, tokens(concept), lang):
        return "다"
    clines = [l for l in concept.split("\n") if l.strip()]
    k = len([l for l in code.split("\n") if l.strip()])
    for i in range(0, max(0, len(clines) - k) + 1):
        if 0 < k <= len(clines) and _same_or_one_literal(ct, tokens("\n".join(clines[i:i + k])), lang):
            return "다"
    return None


KEYWORD_LITERALS = {"true", "false", "null", "undefined", "None", "True", "False"}


def literals(code):
    out = set()
    for t in tokens(code):
        if t[:1] in "\"'`":
            body = t[3:-3] if t[:3] in ('"""', "'''") else t[1:-1]
            out.add(n6(body))
        elif re.match(r"^\d", t) or t in KEYWORD_LITERALS:
            out.add(t)
    return out


def clause7m(prose, code, lines):
    lits = literals(code)
    hits = []
    for v in lines:
        v6 = n6(v)
        if len(v6) >= 2 and v6 not in lits and re.search(r"(?<!\w)" + re.escape(v6) + r"(?![A-Za-z0-9_])", prose):
            hits.append(v6)
    return hits


FENCE = re.compile(r"^(`{3,}|~{3,})([\w+.-]*)[ \t]*\n(.*?)\n\1[ \t]*$", re.S | re.M)


def fence(question):
    return [(m.group(2), m.group(3)) for m in FENCE.finditer(question)]


GROUP = {"js": {"js", "javascript", "mjs", "cjs", "node"}, "py": {"py", "python", "python3"}}


def lang_of_file(path):
    ext = path.rsplit(".", 1)[-1].lower()
    return "py" if ext == "py" else "js" if ext in ("js", "mjs", "cjs") else ext


if __name__ == "__main__":
    print(json.dumps(run(open(sys.argv[2], encoding="utf-8").read(), sys.argv[1]), ensure_ascii=False, indent=1))
