"""learn-notes 1.12.0 G3 (batch 3): the freeze step of the samples (design samples, plan batches[3].samples).
usage: check.py <frozen dir> [--names <NAMES file>] [--day YYYY-MM-DD]
Reads the writers' replies gen/out/A<try>/result.txt and gen/out/B<try>/result.txt (the latest try of each), never edits
an answer, and writes into <frozen> (refuses an existing samples.json): raw.json (the two replies as read), samples.json,
layout.json, check.json (every record's checks, replacements, kept-failing slots, mix counts), NAMES.txt (names, the
writers' situation phrases and file paths, for impl112/NAMES-all.txt), all chmod 444.
Exit 0 frozen; 5 'WRITE <part> 2' (a reply holds no one readable JSON value of the asked shape: try 2 sends the same
prompt once more); 6 STOP (try 2 also unreadable, or a filler the layout needs fails: nothing frozen).

Reading a reply: exactly one ```json fenced block, else the whole reply as JSON; A = {"P": [34], "Q": [34]}, B = {"mine",
"slips", "codeless", "unrunnable"}.

S-A record checks (a record failing any is not used; reasons kept):
 shape   id, group (T for ?T.., R for ?R..), file ext js/mjs/cjs for a JavaScript id and py for a Python id; name 2-40
         characters without backtick, asterisk, '--' or ':'; the plugin reads name and blurb from a note as written
         (kit readConcept); blurb is text, ' — ', one backticked line, nothing after; the quoted line is a line of the code
         (trimmed equal) and prints nothing (no console.log / print( in it); code has 3-8 non-blank lines.
 run     stance 5's runner (runlib.run): exit 0, all runs agree, 1-3 lines each at most 40 code points, and the lines equal
         the record's declared output exactly (output split on newlines).
 new     the committed rungOf + ladderMixed + withScenes reach 'new' for it at step 4 in a quiz [it, 내 코드 om1, 내 코드
         om2] built by kit.quizOf on --day (the record's scope as the plugin asks: isNewAskable, isNewInScope, …).
 apart   (name, blurb, code) disjoint from earlier sets (design samples.mustNotOverlapNames): its name, spaces removed,
         equals no entry of --names (impl112/NAMES-all.txt) and no other new record's name; its blurb quote line (n6)
         equals no earlier record's and no other new record's; its code is not equal under stance 3 (가) or (다) (either
         direction) to the code of any earlier record or other new record of the same language. Earlier records: every
         JSON object with a string name and a string code / lines / blurb in impl112/design/*/dev/** and impl112/b1/frozen,
         b2/frozen (calls and work folders left out), and the G3 final probe items P1-P6 (their question's code).
Replacement, per set: measured slots T js ?T01-?T05, T py ?T07-?T11, R js ?R01-?R11, R py ?R13-?R21; spares ?T06, ?T12,
?R12, ?R22. A failing measured record is replaced by a passing unused spare of its group (T or R; each group has one js
and one py spare): its language's first, which keeps the measured js 16 · py 14, then the group's other (id order
within each); with none left the failing record stays in its slot ('kept-failing': a Q1 miss).
Layout, per set (the design pilot's layout.py): Tm = T js and T py interleaved; Rm = R js 1-9 and R py 1-9 interleaved,
then R js 10, 11; N01-N15 = [Tm[q], Rm[q]] for q < 10, else [Rm[10 + 2(q-10)], Rm[11 + 2(q-10)]], steps 4 / 5
alternating (first slot 4 on even q, the second 9 - that), the 내 코드 filler om1 (even q) or om2 (odd q) at step 2 put
at place q mod 3; M1 [os1 다시 도전, spare T js step 4, spare R js step 5], M2 [os2 다시 도전, spare R py step 4, oc1 왜
step 2], M3 [spare T py step 4, Rm[0] step 5, Tm[1] step 4]. A spare used as a replacement leaves its M place to the
same group's and language's measured record of lowest id not yet in M1-M3 (M questions are records only for Q1).
S-O fillers: om1 js / om2 py edits (before, after) with the quote in after's changed lines; os1/os2 a whole runnable
file and slip {what, question, mine}; oc1/oc2 no backtick. S-U: ou1-ou5 js/mjs, ou6-ou9 py, lines 12-20, the quote a
line of lines with at least 8 lines above it; a failing S-U record stays and counts toward failing Q3 (no spare).
Mix (tags, the writer's words, not checked against the code; record only): per set of 34 the counts of each tag."""
import glob, hashlib, json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.dirname(HERE)
I = os.path.dirname(S)
sys.path.insert(0, HERE)
import runlib  # noqa: E402

PART_SHAPE = {"A": ("P", "Q"), "B": ("mine", "slips", "codeless", "unrunnable")}
MIN_MIX = {"canonical-pitfall": 5, "prints-in-loop": 4, "string-output": 3, "py-bool-none": 3, "three-lines": 3}


GEN = os.environ.get("GEN", f"{S}/gen/out")  # another folder for a tool test only
CORPUS_ROOT = os.environ.get("CORPUS_ROOT", I)  # likewise


def latest(part):
    for t in (2, 1):
        p = f"{GEN}/{part}{t}/result.txt"
        if os.path.exists(p):
            return t, open(p, encoding="utf-8").read()
    return None, None


def parse(text, part):
    blocks = re.findall(r"```json[ \t]*\n(.*?)\n```", text, re.S)
    body = blocks[0] if len(blocks) == 1 else (text if not blocks else None)
    if body is None:
        return None
    try:
        d = json.loads(body)
    except Exception:
        return None
    if not isinstance(d, dict) or any(not isinstance(d.get(k), list) for k in PART_SHAPE[part]):
        return None
    return d


def ids_of(prefix):
    return [f"{prefix}T{i:02d}" for i in range(1, 13)] + [f"{prefix}R{i:02d}" for i in range(1, 23)]


def lang_of_id(i):
    n = int(i[2:])
    return ("js" if n <= 6 else "py") if i[1] == "T" else ("js" if n <= 12 else "py")


def quote_of(blurb):
    m = re.fullmatch(r"(.+?) — `([^`]+)`", blurb or "", re.S)
    return (m.group(1), m.group(2)) if m and "`" not in m.group(1) else (None, None)


def node_kit(script, payload):
    p = subprocess.run(["node", "--experimental-transform-types", "--no-warnings", "--input-type=module", "-e", script], input=json.dumps(payload, ensure_ascii=False), capture_output=True, text=True, cwd=HERE)
    if p.returncode != 0:
        raise RuntimeError(p.stderr[-2000:])
    return json.loads(p.stdout)


KIT_REACH = """
import { readFileSync } from 'node:fs'
import { quizOf, readConcept } from './kit.mjs'
const { recs, fillers, day } = JSON.parse(readFileSync(0, 'utf8'))
const out = {}
for (const r of recs) {
  const read = readConcept(r)
  let rung = null, err = null
  try {
    const all = { [r.id]: r, ...Object.fromEntries(fillers.map(f => [f.id, f])) }
    const q = quizOf([{ id: r.id, step: 4 }, { id: fillers[0].id, step: 2 }, { id: fillers[1].id, step: 2 }], all, day)
    rung = q.rungs[0] ?? null
  } catch (e) { err = String(e).slice(0, 200) }
  out[r.id] = { read: read ? read.name === r.name && read.blurb === r.blurb : false, rung, err }
}
process.stdout.write(JSON.stringify(out))
"""


def corpus():
    """Earlier records with a name and code / lines / blurb (design/*/dev/**, b1/b2 frozen) and P1-P6."""
    R = CORPUS_ROOT
    files = sorted(glob.glob(f"{R}/design/*/dev/**/*.json", recursive=True) + glob.glob(f"{R}/b1/frozen/**/*.json", recursive=True) + glob.glob(f"{R}/b2/frozen/**/*.json", recursive=True))
    files = [f for f in files if "/calls/" not in f and "/work/" not in f and os.path.getsize(f) < 3_000_000]
    recs = []

    def walk(x, src):
        if isinstance(x, dict):
            if isinstance(x.get("name"), str) and any(isinstance(x.get(k), str) for k in ("code", "lines", "blurb", "after")):
                code = x.get("code") if isinstance(x.get("code"), str) else x.get("lines") if isinstance(x.get("lines"), str) else x.get("after") if isinstance(x.get("after"), str) else None
                f = x.get("file") if isinstance(x.get("file"), str) else ""
                recs.append({"src": src, "name": x["name"], "blurb": x.get("blurb") if isinstance(x.get("blurb"), str) else None, "code": code, "lang": runlib.lang_of_file(f) if f else None})
            for v in x.values():
                walk(v, src)
        elif isinstance(x, list):
            for v in x:
                walk(v, src)
    for f in files:
        try:
            walk(json.load(open(f, encoding="utf-8")), os.path.relpath(f, R))
        except Exception:
            pass
    for it in json.load(open(f"{R}/design/G3/final/probe/items-X.json", encoding="utf-8")) if os.path.exists(f"{R}/design/G3/final/probe/items-X.json") else []:
        fs = runlib.fence(it["item"]["question"])
        if fs:
            recs.append({"src": "design/G3/final/probe/items-X.json", "name": it["item"]["name"], "blurb": None, "code": fs[0][1], "lang": "py" if fs[0][0].startswith("py") else "js"})
    return files, recs


def main():
    out = sys.argv[1]
    names_file = sys.argv[sys.argv.index("--names") + 1] if "--names" in sys.argv else f"{I}/NAMES-all.txt"
    day = sys.argv[sys.argv.index("--day") + 1] if "--day" in sys.argv else None
    if not day:
        sys.exit("give --day YYYY-MM-DD (the scene day = the measuring day)")
    if os.path.exists(f"{out}/samples.json"):
        sys.exit(f"refuse: {out}/samples.json exists")
    os.makedirs(out, exist_ok=True)
    got = {}
    for part in ("A", "B"):
        t, text = latest(part)
        if t is None:
            sys.exit(f"no writer reply for {part}")
        d = parse(text, part)
        if d is None:
            print(f"{part} try {t}: no one readable JSON value of the asked shape")
            if t == 1:
                print(f"WRITE {part} 2")
                sys.exit(5)
            print("STOP: the second reply is unreadable too")
            sys.exit(6)
        got[part] = {"try": t, "data": d}
    A, B = got["A"]["data"], got["B"]["data"]
    fill = {r.get("id"): r for k in ("mine", "slips", "codeless") for r in B[k] if isinstance(r, dict)}
    unr = [r for r in B["unrunnable"] if isinstance(r, dict)]
    report = {"day": day, "tries": {p: got[p]["try"] for p in got}, "records": {}, "fillers": {}, "unrunnable": {}}

    # fillers
    def bad_filler(i):
        r = fill.get(i)
        if not r:
            return ["missing"]
        why = []
        name = r.get("name") or ""
        if not (2 <= len(name) <= 40) or re.search(r"[`*:]|--", name):
            why.append("name")
        if i.startswith("om"):
            want = "js" if i == "om1" else "py"
            if runlib.lang_of_file(r.get("file", "")) != want or not isinstance(r.get("before"), str) or not isinstance(r.get("after"), str):
                why.append("shape")
            else:
                _, q = quote_of(r.get("blurb"))
                if q is None or not any(l.strip() == q.strip() for l in r["after"].split("\n")) or q.strip() in [l.strip() for l in r["before"].split("\n")]:
                    why.append("quote")
        elif i.startswith("os"):
            want = "js" if i == "os1" else "py"
            sl = r.get("slip") or {}
            if runlib.lang_of_file(r.get("file", "")) != want or not isinstance(r.get("code"), str) or not all(isinstance(sl.get(k), str) and sl.get(k) for k in ("what", "question", "mine")):
                why.append("shape")
        else:
            if "`" in (r.get("blurb") or "") or not r.get("blurb"):
                why.append("blurb")
        return why
    for i in ("om1", "om2", "os1", "os2", "oc1", "oc2"):
        report["fillers"][i] = bad_filler(i)
    need = ("om1", "om2", "os1", "os2", "oc1")
    if any(report["fillers"][i] for i in need):
        json.dump(report, open(f"{out}/check.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print("STOP: a filler the layout needs fails", {i: report["fillers"][i] for i in need if report["fillers"][i]})
        sys.exit(6)

    # S-A records
    sets = {}
    for s, prefix in (("P", "p"), ("Q", "q")):
        recs = {r.get("id"): r for r in A[s] if isinstance(r, dict) and isinstance(r.get("id"), str)}
        sets[s] = (prefix, recs)
    allnew = [r for _, (_, recs) in sets.items() for r in recs.values()] + [fill[i] for i in fill] + unr
    files, earlier = corpus()
    names_taken = {}
    for line in open(names_file, encoding="utf-8"):
        if line.strip():
            names_taken.setdefault(re.sub(r"\s+", "", line.split("\t", 1)[0]), line.split("\t")[1] if "\t" in line else "")
    reach_in = []
    for s, (prefix, recs) in sets.items():
        for i in ids_of(prefix):
            if i in recs:
                reach_in.append(recs[i])
    reach = node_kit(KIT_REACH, {"recs": reach_in, "fillers": [fill["om1"], fill["om2"]], "day": day})
    for s, (prefix, recs) in sets.items():
        for i in ids_of(prefix):
            r = recs.get(i)
            why = []
            if r is None:
                report["records"][i] = ["missing"]
                continue
            lang = lang_of_id(i)
            if r.get("group") != i[1] or runlib.lang_of_file(r.get("file", "")) != lang or not all(isinstance(r.get(k), str) for k in ("name", "blurb", "file", "code", "output")):
                why.append("shape")
                report["records"][i] = why
                continue
            name = r["name"]
            if not (2 <= len(name) <= 40) or re.search(r"[`*:]|--", name):
                why.append("name")
            if not reach[i]["read"]:
                why.append("note-read")
            _, q = quote_of(r["blurb"])
            lines = [l for l in r["code"].split("\n") if l.strip()]
            if q is None or not any(l.strip() == q.strip() for l in lines) or re.search(r"console\.log|print\(", q):
                why.append("quote")
            if not (3 <= len(lines) <= 8):
                why.append("lines")
            run = runlib.run(r["code"], lang)
            if not (run["rc"] == 0 and run["agree"] and 1 <= len(run["lines"]) <= 3 and all(len(l) <= 40 for l in run["lines"]) and run["lines"] == r["output"].split("\n")):
                why.append("run")
            if reach[i]["rung"] != "new":
                why.append(f"rung:{reach[i]['rung']}")
            key = re.sub(r"\s+", "", name)
            if key in names_taken:
                why.append("name-taken")
            if sum(1 for o in allnew if isinstance(o, dict) and re.sub(r"\s+", "", o.get("name") or "") == key) > 1:
                why.append("name-twice")
            qn = runlib.n6(q) if q else None
            for o in earlier:
                if qn and o["blurb"]:
                    _, oq = quote_of(o["blurb"])
                    if oq and runlib.n6(oq) == qn:
                        why.append(f"quote-taken:{o['src']}")
                        break
            for o in allnew:
                if o is not r and isinstance(o, dict) and qn:
                    _, oq = quote_of(o.get("blurb"))
                    if oq and runlib.n6(oq) == qn:
                        why.append(f"quote-twice:{o.get('id')}")
                        break
            for o in earlier + [{"src": o.get("id"), "code": o.get("code") or o.get("lines") or o.get("after"), "lang": runlib.lang_of_file(o.get("file", ""))} for o in allnew if isinstance(o, dict) and o is not r]:
                if o.get("code") and o.get("lang") == lang:
                    c = runlib.clause3(r["code"], o["code"], lang) or runlib.clause3(o["code"], r["code"], lang)
                    if c in ("가", "다"):
                        why.append(f"code-taken:{c}:{o['src']}")
                        break
            report["records"][i] = why
            r["_run"] = run["lines"]
    # replacement and layout
    lay, samples = {}, {"day": day, "sets": {}, "fillers": fill, "unrunnable": unr}
    report["replacements"], report["keptFailing"], report["mix"] = {}, {}, {}
    for s, (prefix, recs) in sets.items():
        ok = lambda i: report["records"].get(i) == []
        slots = {("T", "js"): [f"{prefix}T{n:02d}" for n in range(1, 6)], ("T", "py"): [f"{prefix}T{n:02d}" for n in range(7, 12)],
                 ("R", "js"): [f"{prefix}R{n:02d}" for n in range(1, 12)], ("R", "py"): [f"{prefix}R{n:02d}" for n in range(13, 22)]}
        spares = {("T", "js"): f"{prefix}T06", ("T", "py"): f"{prefix}T12", ("R", "js"): f"{prefix}R12", ("R", "py"): f"{prefix}R22"}
        used, repl, kept_failing = set(), [], []
        measured = {}
        for (g, l), ids in slots.items():
            measured[(g, l)] = []
            for i in ids:
                if ok(i):
                    measured[(g, l)].append(i)
                    continue
                order = [spares[(g, l)], spares[(g, "py" if l == "js" else "js")]]
                sp = next((x for x in order if x not in used and ok(x)), None)
                if sp:
                    used.add(sp)
                    repl.append({"slot": i, "spare": sp, "why": report["records"].get(i)})
                    measured[(g, l)].append(sp)
                else:
                    kept_failing.append(i)
                    measured[(g, l)].append(i)
        Tjs, Tpy, Rjs, Rpy = measured[("T", "js")], measured[("T", "py")], measured[("R", "js")], measured[("R", "py")]
        Tm = [x for pair in zip(Tjs[:5], Tpy[:5]) for x in pair]
        Rm = [x for pair in zip(Rjs[:9], Rpy[:9]) for x in pair] + Rjs[9:11]
        quizzes = []
        for q in range(15):
            pair = [Tm[q], Rm[q]] if q < 10 else [Rm[10 + 2 * (q - 10)], Rm[11 + 2 * (q - 10)]]
            step = 4 if q % 2 == 0 else 5
            sl = [{"id": pair[0], "step": step}, {"id": pair[1], "step": 9 - step}]
            sl.insert(q % 3, {"id": "om1" if q % 2 == 0 else "om2", "step": 2})
            quizzes.append({"id": f"{s}-N{q + 1:02d}", "slots": sl})
        in_m = set()

        def m_rec(g, l):
            sp = spares[(g, l)]
            if sp not in used and ok(sp):
                in_m.add(sp)
                return sp
            pool = sorted(x for x in (Tjs + Tpy if g == "T" else Rjs + Rpy) if lang_of_id(x) == l and x not in in_m and x not in (Rm[0], Tm[1]))
            in_m.add(pool[0])
            return pool[0]
        m1 = [m_rec("T", "js"), m_rec("R", "js")]
        m2 = m_rec("R", "py")
        m3 = m_rec("T", "py")
        quizzes.append({"id": f"{s}-M1", "slots": [{"id": "os1", "step": 2, "slip": True}, {"id": m1[0], "step": 4}, {"id": m1[1], "step": 5}]})
        quizzes.append({"id": f"{s}-M2", "slots": [{"id": "os2", "step": 2, "slip": True}, {"id": m2, "step": 4}, {"id": "oc1", "step": 2}]})
        quizzes.append({"id": f"{s}-M3", "slots": [{"id": m3, "step": 4}, {"id": Rm[0], "step": 5}, {"id": Tm[1], "step": 4}]})
        lay[s] = {"measured": Tm + Rm, "keptFailing": kept_failing, "quizzes": quizzes}
        report["replacements"][s], report["keptFailing"][s] = repl, kept_failing
        mix = {k: 0 for k in MIN_MIX}
        for r in recs.values():
            for t in r.get("tags") or []:
                if t in mix:
                    mix[t] += 1
        report["mix"][s] = {"counts": mix, "short": [k for k, v in MIN_MIX.items() if mix[k] < v]}
        samples["sets"][s] = {i: recs[i] for i in ids_of(prefix) if i in recs}
    # S-U
    for k, r in enumerate(unr):
        want = f"ou{k + 1}"
        why = []
        if r.get("id") != want:
            why.append("id")
        lang = "js" if k < 5 else "py"
        lines = (r.get("lines") or "").split("\n")
        _, q = quote_of(r.get("blurb"))
        at = next((j for j, l in enumerate(lines) if q and l.strip() == q.strip()), None)
        if runlib.lang_of_file(r.get("file", "")) != lang or not (12 <= len([l for l in lines if l.strip()]) <= 20):
            why.append("shape")
        if at is None or at < 8:
            why.append("quote")
        report["unrunnable"][r.get("id") or want] = why
    if len(unr) != 9:
        report["unrunnable"]["count"] = [f"{len(unr)} records, not 9"]
    raw = {"A": A, "B": B}
    open(f"{out}/raw.json", "w", encoding="utf-8").write(json.dumps(raw, ensure_ascii=False, indent=1) + "\n")
    open(f"{out}/samples.json", "w", encoding="utf-8").write(json.dumps(samples, ensure_ascii=False, indent=1) + "\n")
    open(f"{out}/layout.json", "w", encoding="utf-8").write(json.dumps(lay, ensure_ascii=False, indent=1) + "\n")
    report["corpus"] = {"files": len(files), "records": len(earlier), "sha256": hashlib.sha256(json.dumps(earlier, ensure_ascii=False, sort_keys=True).encode()).hexdigest()}
    open(f"{out}/check.json", "w", encoding="utf-8").write(json.dumps(report, ensure_ascii=False, indent=1) + "\n")
    names = []
    for r in allnew:
        if isinstance(r, dict):
            for k in ("name", "situation", "file"):
                if isinstance(r.get(k), str) and r[k].strip():
                    names.append(f"{r[k].strip()}\tG3-measured\timpl112/b3/frozen/samples.json")
    open(f"{out}/NAMES.txt", "w", encoding="utf-8").write("\n".join(names) + "\n")
    for f in ("raw.json", "samples.json", "layout.json", "check.json", "NAMES.txt"):
        os.chmod(f"{out}/{f}", 0o444)
    bad = {i: w for i, w in report["records"].items() if w}
    print(json.dumps({"failing": bad, "replacements": report["replacements"], "keptFailing": report["keptFailing"], "mix": report["mix"], "unrunnable": {k: v for k, v in report["unrunnable"].items() if v}, "fillers": {k: v for k, v in report["fillers"].items() if v}}, ensure_ascii=False, indent=1))
    print("FROZEN", out)


if __name__ == "__main__":
    main()
