// learn-notes 1.12.0 G3 (batch 3): the plugin side of a record, made with the committed tree's notes.ts (b3/mtree =
// f03b362; NOTES env to point elsewhere, for a tool test only). Rebuilt from the design pilot's build.mjs and batch 2's kit.mjs.
// - ROW: haiku's row of the tree's MODEL_SWITCHES (as the earlier 1.12.0 batches left it, M-13: isRuleWide true,
//   rungChangedStep 2) with rungNewStep 4 over it, as the measured route runs (the D34 harness row
//   `models: { haiku: { rungNewStep: 4 } }`). newStep = ROW.rungNewStep; STEPS = ladderSteps() of that row.
// - readConcept(rec): the record's name and blurb as the plugin reads them from a note (conceptsOf over the note answer the
//   D34 test gives: '### 배울 개념' then '- **name**: blurb'); check.py refuses a record whose read form differs.
// - changeFor(rec, shape): a whole file (rec.code, or rec.lines for an S-U record) as a Write create (creationHunk) in
//   the shape 'create'; an S-U record in the shape 'edit' as an Edit whose one hunk is the quoted line added with 3 lines
//   of context (the imports above stay outside the hunk); a 내 코드 filler (rec.before/after) as an Edit (one -U3 hunk).
// - pickOf(rec, step, extra, shape, now): a quiz pick as makeQuiz's withCode makes it (codeFor's lines; isChanged,
//   isNew, the file read for an edit (importsText: the worktree file's whole text = rec.lines or rec.after), isLibrary,
//   isImporting, isNewLibrary, isWhole, `around`), every pick due (isDue true), no session miss lists.
// - quizOf(slots, recs, day): rungOf(…, newStep, STEPS) per pick, ladderMixed, withScenes(laid, kept, day) when a rung is
//   new, pickForRung + scene, quizPrompt(picks, 'beginner') through redactText, maxTokens QUIZ_TRACE_TOKENS when a pick
//   is changed/new/worked else QUIZ_TOKENS as register.tsx picks it (expression and constants read from register.tsx).
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'

export const TREE = process.env.TREE ?? '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3/mtree'
const NOTES = process.env.NOTES ?? join(TREE, 'hooks/notes.ts')
export const N = await import(NOTES)
const REG = readFileSync(join(dirname(NOTES), 'register.tsx'), 'utf8')
if (!REG.includes('maxTokens: isLong ? QUIZ_TRACE_TOKENS : QUIZ_TOKENS')) throw new Error('register.tsx: the quiz cap expression is not as read')
if (!REG.includes('return { changedStep: build.rungChangedStep, workedAfter: build.workedAfterTimes, workedPlainAfter: build.workedPlainAfterTimes }')) throw new Error('register.tsx: ladderSteps is not as read')
const num = name => Number(new RegExp(`\\nconst ${name} = ([\\d_]+)\\n`).exec(REG)[1].replace(/_/g, ''))
export const QUIZ_TRACE_TOKENS = num('QUIZ_TRACE_TOKENS')
export const QUIZ_TOKENS = num('QUIZ_TOKENS')
export const ROW = { ...N.MODEL_SWITCHES.haiku, rungNewStep: 4 }
export const STEPS = { changedStep: ROW.rungChangedStep, workedAfter: ROW.workedAfterTimes, workedPlainAfter: ROW.workedPlainAfterTimes }
const DAY = 86_400_000

export const nowOf = day => Date.parse(`${day}T01:00:00Z`)
export const noteAnswer = rec => ['### 한 줄 요약', '만들었습니다', '### 배울 개념', `- **${rec.name}**: ${rec.blurb}`, '### 직접 확인해 볼 것', '- 실행해 보기'].join('\n')
export function readConcept(rec) {
  const got = N.conceptsOf(noteAnswer(rec))
  return got.length === 1 ? { name: got[0].name, blurb: got[0].blurb, key: got[0].key } : undefined
}

export function hunkOf(before, after) {
  const a = before.replace(/\n$/, '').split('\n'), b = after.replace(/\n$/, '').split('\n')
  let s = 0
  while (s < a.length && s < b.length && a[s] === b[s]) s++
  let ea = a.length - 1, eb = b.length - 1
  while (ea >= s && eb >= s && a[ea] === b[eb]) { ea--; eb-- }
  const from = Math.max(0, s - 3), toA = Math.min(a.length - 1, ea + 3), toB = Math.min(b.length - 1, eb + 3)
  const lines = [...a.slice(from, s).map(l => ' ' + l), ...a.slice(s, ea + 1).map(l => '-' + l), ...b.slice(s, eb + 1).map(l => '+' + l), ...a.slice(ea + 1, toA + 1).map(l => ' ' + l)]
  return { oldStart: from + 1, oldLines: toA - from + 1, newStart: from + 1, newLines: toB - from + 1, lines }
}

/** The S-U edit shape: the file before = the whole text without the quoted line, after = the whole text. */
export function editAround(text, blurb) {
  const lines = text.replace(/\n$/, '').split('\n')
  const q = (blurb.split('`')[1] ?? '').trim()
  const at = lines.findIndex(l => q !== '' && l.includes(q))
  if (at < 0) return undefined
  const before = [...lines.slice(0, at), ...lines.slice(at + 1)].join('\n') + '\n'
  return { before, after: lines.join('\n') + '\n' }
}

export function wholeText(rec) {
  return rec.code ?? rec.lines
}

export function changeFor(rec, shape = 'create') {
  const path = `/proj/${rec.file}`
  if (rec.before !== undefined) return N.changeOf({ path, root: '/proj', tool: 'Edit', kind: 'update', hunks: [hunkOf(rec.before, rec.after)] })
  if (shape === 'edit') {
    const e = editAround(wholeText(rec), rec.blurb)
    if (!e) throw new Error(`${rec.id}: the quoted line is not in its file`)
    return N.changeOf({ path, root: '/proj', tool: 'Edit', kind: 'update', hunks: [hunkOf(e.before, e.after)] })
  }
  return N.changeOf({ path, root: '/proj', tool: 'Write', kind: 'create', hunks: [N.creationHunk(wholeText(rec))] })
}

/** The worktree file's text as importsText reads it for an edit (the file after the edit). */
export function fileAfter(rec, shape) {
  if (rec.before !== undefined) return rec.after
  return shape === 'edit' ? editAround(wholeText(rec), rec.blurb).after : undefined
}

export function pickOf(rec, step, extra = {}, shape = 'create', now = nowOf('2026-10-03')) {
  const read = readConcept(rec) ?? { name: rec.name, blurb: rec.blurb, key: N.conceptKey(rec.name) }
  const base = { key: read.key, name: read.name, count: 3, firstAt: now - 60 * DAY, lastAt: now - 60 * DAY, blurb: read.blurb, files: [], step, reviewedAt: now - 90 * DAY, noteId: `note-${rec.id}` }
  if (wholeText(rec) === undefined && rec.after === undefined) return { ...base, ...extra }
  const change = changeFor(rec, shape)
  const text = N.codeFor(change, read.blurb)
  if (!text) return { ...base, ...extra }
  const isChanged = change.kind === 'create' && N.isChangedAskable({ ...base }, change.file, STEPS.changedStep)
  const isNew = N.isNewAskable({ ...base }, change.file, true, ROW.rungNewStep)
  const isAskable = isNew || isChanged
  const file = isAskable && change.kind !== 'create' ? fileAfter(rec, shape) : undefined
  const isLibrary = isAskable && N.isUnrunnableChange(change, file)
  const isImporting = isChanged && N.isImportingChange(change, file)
  const isNewLibrary = isNew && N.isNewLibraryChange(change)
  const isWhole = isChanged && N.isWholeShown(change, text)
  const code = {
    file: N.baseName(change.file),
    text,
    ...(isLibrary ? { isLibrary: true } : {}),
    ...(isImporting ? { isImporting: true } : {}),
    ...(isNewLibrary ? { isNewLibrary: true } : {}),
    ...(isWhole ? { isWhole: true } : {}),
    ...(isNew && file !== undefined ? { around: file } : {}),
  }
  return { ...base, code, ...extra }
}

export function rungAlone(one, slot = {}) {
  return N.rungOf(one, { ...(one.code ? { code: one.code } : {}), ...(slot.slip ? { slip: { times: 1 } } : {}), isAsking: slot.slip === true, isTeam: false, isDue: true }, ROW.rungNewStep, STEPS)
}

export function quizOf(slots, recs, day) {
  const now = nowOf(day)
  const laid = slots.map(s => pickOf(recs[s.id], s.step, s.slip ? { slip: recs[s.id].slip } : {}, s.shape ?? 'create', now))
  const rungs = laid.map((one, i) => rungAlone(one, slots[i]))
  const kept = N.ladderMixed(rungs, laid)
  const { asIs, scenes } = kept.includes('new') ? N.withScenes(laid, kept, day) : { asIs: kept, scenes: [] }
  const picks = laid.map((one, i) => {
    const pick = N.pickForRung(one, asIs[i])
    return scenes[i] !== undefined ? { ...pick, scene: scenes[i] } : pick
  })
  const isLong = picks.some(one => one.rung === 'changed' || one.rung === 'new' || one.rung === 'worked')
  const red = N.redactText(N.quizPrompt(picks, 'beginner'))
  return { picks, rungsAlone: rungs, rungsMixed: kept, rungs: asIs, scenes, prompt: red.text, redactHits: red.hits, maxTokens: isLong ? QUIZ_TRACE_TOKENS : QUIZ_TOKENS }
}
