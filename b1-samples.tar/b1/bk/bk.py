"""learn-notes 1.12.0 batch 1: a freeze-point backup tar (plan backup (2)). usage: bk.py <point> <path...>
Paths are relative to impl112/; directories are walked. Left out: raw sessions (stream.jsonl, record.json, debug.log)
and the writers' raw out.json / model.txt. Any other file whose text holds a resolved model id gets the id replaced by
'<model-id>' in the tar (the file on disk is not touched); the list of redacted files goes in the tar as
REDACTED.txt. Writes impl112/backup/b1-<point>.tar (refuses to overwrite), chmod 444, checks the tar holds 0 ids."""
import hashlib, io, os, re, sys, tarfile, time
I = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112"
ID = re.compile(rb"claude-(haiku|sonnet|opus)-[0-9][0-9a-z.\-]*")
SKIP = {"stream.jsonl", "record.json", "debug.log"}
point, paths = sys.argv[1], sys.argv[2:]
dst = f"{I}/backup/b1-{point}.tar"
if os.path.exists(dst) or ID.search(point.encode()):
    sys.exit(f"refuse: {dst}")
files = []
for p in paths:
    a = f"{I}/{p}"
    if os.path.isdir(a):
        for root, _, fs in os.walk(a):
            files += [os.path.join(root, f) for f in sorted(fs)]
    elif os.path.exists(a):
        files.append(a)
    else:
        sys.exit(f"missing {p}")
red, n = [], 0
with tarfile.open(dst, "w") as t:
    for f in sorted(set(files)):
        rel = os.path.relpath(f, I)
        base = os.path.basename(f)
        if base in SKIP or (("/gen/out/" in f or "/gen-n2/" in f) and base in ("out.json", "model.txt")) or os.path.islink(f):
            continue
        if ID.search(rel.encode()):
            sys.exit(f"model id in a file name: {rel}")
        b = open(f, "rb").read()
        if ID.search(b):
            b = ID.sub(b"<model-id>", b)
            red.append(rel)
        ti = tarfile.TarInfo(rel); ti.size = len(b); ti.mtime = int(os.path.getmtime(f)); ti.mode = os.stat(f).st_mode & 0o777
        t.addfile(ti, io.BytesIO(b)); n += 1
    b = ("\n".join(red) + "\n").encode()
    ti = tarfile.TarInfo(f"b1/bk/REDACTED-{point}.txt"); ti.size = len(b); ti.mtime = int(time.time())
    t.addfile(ti, io.BytesIO(b))
raw = open(dst, "rb").read()
assert not ID.search(raw), "id left in tar"
os.chmod(dst, 0o444)
print(f"{dst} files {n} redacted {len(red)} sha256 {hashlib.sha256(raw).hexdigest()} bytes {len(raw)}")
