"""learn-notes 1.12.0 G6 (batch 1): append this batch's measured names to impl112/NAMES-all.txt right after the
sample freeze (견본.md '이름 목록' 덧붙임). Names = every id of frozen/raw.json (main and reserve), every file path,
and every name a file defines (function/def/class, export const/let, top-level const NAME = ( / function / arrow).
Tag G6-measured, source impl112/b1/frozen/raw.json. Also writes names/overlap.json: defined names and paths already
in NAMES-all.txt before the append (record only). Sorted in byte order, duplicate lines dropped; chmod 444 again.
usage: append.py   (model calls 0; refuses when G6-measured lines are already there)"""
import hashlib, json, os, re
SP = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad"
NAMES = SP + "/impl112/NAMES-all.txt"
RAW = SP + "/impl112/b1/frozen/raw.json"
SRC = os.path.relpath(RAW, SP)
old = open(NAMES, "rb").read().decode("utf-8").split("\n")
old = [l for l in old if l]
if any(l.split("\t")[1] == "G6-measured" for l in old):
    raise SystemExit("refuse: G6-measured already appended")
before = {l.split("\t")[0] for l in old}
DEF = [re.compile(p, re.M) for p in (r"\bfunction\s*\*?\s*([A-Za-z_$][\w$]*)", r"^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)",
       r"^\s*class\s+([A-Za-z_$][\w$]*)", r"^\s*export\s+(?:const|let|var)\s+([A-Za-z_$][\w$]*)",
       r"^(?:const|let)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\(|function|[A-Za-z_$][\w$]*\s*=>)")]
names, defined, paths = set(), set(), set()
for s in json.load(open(RAW, encoding="utf-8")):
    names.add(s["id"])
    for f in s["files"]:
        paths.add(f["path"])
        for t in (f.get("before") or "", f.get("after") or ""):
            for p in DEF:
                defined.update(m.group(1) for m in p.finditer(t))
names |= paths | defined
rows = set(old) | {f"{n}\t G6-measured\t{SRC}".replace("\t ", "\t") for n in names}
lines = sorted(rows, key=lambda s: s.encode("utf-8"))
os.chmod(NAMES, 0o644)
open(NAMES, "wb").write(("\n".join(lines) + "\n").encode("utf-8"))
os.chmod(NAMES, 0o444)
ov = {"definedAlready": sorted(defined & before), "pathsAlready": sorted(paths & before)}
json.dump(ov, open(SP + "/impl112/b1/names/overlap.json", "w"), ensure_ascii=False, indent=1)
print(json.dumps({"lines": len(lines), "added": len(lines) - len(old), "measuredNames": len(names), "ids": sum(1 for n in names if re.fullmatch(r"G[ABCD]\d\d", n)),
                  "paths": len(paths), "defined": len(defined), "overlapDefined": len(ov["definedAlready"]), "overlapPaths": ov["pathsAlready"],
                  "sha256": hashlib.sha256(open(NAMES, "rb").read()).hexdigest()}, ensure_ascii=False))
