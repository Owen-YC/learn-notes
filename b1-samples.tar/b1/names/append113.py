"""learn-notes 1.13.0 G6 haiku (batch 1; from impl112/b1/names/append.py, made append-only as 견본.md '### 이름 목록'
requires for 1.13.0: no line is removed, changed or re-sorted): append this batch's measured names to impl113/NAMES-all.txt
right after the sample freeze (tag 'G6-measured-113', plan/견본.md '덧붙임'). Names = every id of frozen/raw.json (main
and reserve), every file path, and every name a file defines (function/def/class, export const/let, top-level const
NAME = ( / function / arrow) -- the 1.12.0 rule unchanged. New rows (`name TAB G6-measured-113 TAB impl113/b1/frozen/raw.json`)
are appended after the last line in byte order; a row already present byte for byte is not added twice. Also writes
names/overlap.json: defined names and paths already in NAMES-all.txt (any tag) before the append (record only).
chmod 444 again. usage: append113.py   (model calls 0; refuses when G6-measured-113 lines are already there)"""
import hashlib, json, os, re
SP = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad"
NAMES = SP + "/impl113/NAMES-all.txt"
RAW = SP + "/impl113/b1/frozen/raw.json"
TAG = "G6-measured-113"
SRC = os.path.relpath(RAW, SP)
data = open(NAMES, "rb").read()
assert data.endswith(b"\n"), "NAMES-all.txt must end with a newline"
old = [l for l in data.decode("utf-8").split("\n") if l]
if any(len(l.split("\t")) > 1 and l.split("\t")[1] == TAG for l in old):
    raise SystemExit(f"refuse: {TAG} already appended")
before = {l.split("\t")[0] for l in old}
DEF = [re.compile(p, re.M) for p in (r"\bfunction\s*\*?\s*([A-Za-z_$][\w$]*)", r"^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)",
       r"^\s*class\s+([A-Za-z_$][\w$]*)", r"^\s*export\s+(?:const|let|var)\s+([A-Za-z_$][\w$]*)",
       r"^(?:const|let)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\(|function|[A-Za-z_$][\w$]*\s*=>)")]
ids, defined, paths = set(), set(), set()
for s in json.load(open(RAW, encoding="utf-8")):
    ids.add(s["id"])
    for f in s["files"]:
        paths.add(f["path"])
        for t in (f.get("before") or "", f.get("after") or ""):
            for p in DEF:
                defined.update(m.group(1) for m in p.finditer(t))
names = ids | paths | defined
have = set(old)
new = sorted({f"{n}\t{TAG}\t{SRC}" for n in names} - have, key=lambda s: s.encode("utf-8"))
before_sha = hashlib.sha256(data).hexdigest()
os.chmod(NAMES, 0o644)
open(NAMES, "ab").write(("\n".join(new) + "\n").encode("utf-8"))
os.chmod(NAMES, 0o444)
after = open(NAMES, "rb").read()
assert after[:len(data)] == data, "the old lines changed"
ov = {"definedAlready": sorted(defined & before), "pathsAlready": sorted(paths & before)}
json.dump(ov, open(SP + "/impl113/b1/names/overlap.json", "w"), ensure_ascii=False, indent=1)
print(json.dumps({"linesBefore": len(old), "lines": len(old) + len(new), "added": len(new), "ids": len(ids), "paths": len(paths),
                  "defined": len(defined), "overlapDefined": ov["definedAlready"], "overlapPaths": ov["pathsAlready"],
                  "sha256Before": before_sha, "sha256": hashlib.sha256(after).hexdigest()}, ensure_ascii=False))
