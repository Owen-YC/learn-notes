"""(check2.py: check.py with the M-15 module-trap path fix below; everything else byte-identical.)
learn-notes 1.12.0 G6 (batch 1) freeze-time check (model calls 0; design samples.measured 'Freeze-time checks',
plan samples.freezeChecks; copy of design/G6/final/tools/check4.py made strict where the design says so).
Each sample of frozen/raw.json is checked; a failing main sample is replaced by the first passing reserve of its own
kind in id order (never rewritten), else dropped; the replacement count per group is written (population record).
Checks (any one failing = the sample fails):
  - JSON fields there; kind and lang known; files 1-2 with path and after.
  - the demo runs (§8: js/ts twice, py five times, all the same, exit 0) and its stdout lines (the runner's [value]
    line apart) equal `expected` under §7's normalisation.
  - F · N · trap: violations empty. R · R_long · multi · double: violations there (R and R_long one, multi and double
    two; multi two different rules, double one rule twice on two different lines).
  - each violation: its file is one of the sample's; its line is in that file's after (a line the same as it, spaces
    and an end ; , apart); the line holds a §5 marker of its rule; the fix holds a use name of the rule and no marker
    of it; R · multi · double lines ≤ 40 characters, R_long > 40 (indent apart); the file imports that rule's team
    module; the fix run (that line alone made the fix) runs as the demo does (exit 0, all the same) and writes MORE of
    that rule's stub records than the run as written (strict S1, S-c); its stdout is frozen as expected_fixed.
  - every line of every after of a non-trap sample that holds a §5 marker in its code is a violation line; in F
    samples a marker only inside a comment or a string/docstring literal does not count (lexcode.code_only); in the
    other kinds a comment or string counts too.
  - no file path equal to a dev path (an entry of impl112/NAMES-all.txt with a slash; the 1.12.0 dev and measured
    names and every 견본.md path).
Writes frozen/samples.json (chmod 444), frozen/check-report.json (chmod 444). usage: check.py"""
import hashlib, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import runlib as R
from key import KEY, STUB, holds_use, markers_in, line_key
from lexcode import code_only

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1"
NAMES = os.environ.get("NAMES_FILE", "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/NAMES-all.txt")
RAW = os.environ.get("RAW", f"{S}/frozen/raw.json")
OUT = os.environ.get("OUTDIR", f"{S}/frozen")
RESERVES = {"R": ["GA21", "GA22", "GB25", "GB26"], "R_long": ["GB27", "GB28"], "F": ["GC25", "GC26"], "N": ["GC27", "GC28"],
            "trap": ["GD18", "GD19"], "multi": ["GD20", "GD21"], "double": ["GD22", "GD23"]}
if os.environ.get("RESERVES"):
    RESERVES = json.loads(os.environ["RESERVES"])
TARGET = {"R": 40, "R_long": 4, "F": 12, "N": 12, "trap": 9, "multi": 4, "double": 4}
IMPORT = {
    "js": {"request": r"""from\s+['"][^'"]*api/apiRequest(\.js|\.ts)?['"]""", "log": r"""from\s+['"][^'"]*(^|/)log(\.js|\.ts)?['"]""",
           "date": r"""from\s+['"][^'"]*dateText(\.js|\.ts)?['"]""", "config": r"""from\s+['"][^'"]*(^|/)config(\.js|\.ts)?['"]"""},
    "py": {"request": r"^\s*(from\s+app\.api\.api_request\s+import|import\s+app\.api\.api_request)", "log": r"^\s*(from\s+app\.log\s+import|import\s+app\.log)",
           "date": r"^\s*(from\s+app\.date_text\s+import|import\s+app\.date_text)", "config": r"^\s*(from\s+app\.config\s+import|import\s+app\.config)"},
}
dev_paths = {l.split("\t", 1)[0] for l in open(NAMES, encoding="utf-8") if "/" in l.split("\t", 1)[0]}
# M-15 tool fix (batch 1, before any measured call; check.py is kept as it was): a module trap must edit a team
# module at its table path (bar '대역 모듈의 자리', writer part D), and those paths are also dev paths, so for a module
# trap only these paths are not refused. Every other path check is unchanged.
TEAM_MODULE_PATHS = {"src/api/apiRequest.js", "src/api/apiRequest.ts", "src/log.js", "src/log.ts", "src/dateText.js", "src/dateText.ts",
                     "src/config.js", "src/config.ts", "app/api/api_request.py", "app/log.py", "app/date_text.py", "app/config.py"}


def imports(text, lang, rule):
    pat = IMPORT["py" if lang == "py" else "js"][rule]
    return re.search(pat, text, re.M) is not None


def check(s):
    errs = []
    for k in ("id", "kind", "lang", "files", "demo", "expected"):
        if k not in s:
            errs.append(f"field {k} missing")
    if errs:
        return errs
    if s["kind"] not in TARGET:
        errs.append(f"kind {s['kind']}")
    files = R.files_of(s)
    if not (1 <= len(s["files"]) <= 2) or any(not f.get("path") or f.get("after") is None for f in s["files"]):
        errs.append("files: 1-2 with path and after")
        return errs
    for f in s["files"]:
        if f["path"] in dev_paths and not (s.get("kind") == "trap" and s.get("trap") == "module" and f["path"] in TEAM_MODULE_PATHS):
            errs.append(f"path is a dev path: {f['path']}")
    first = s["files"][0]["path"]
    base = R.run(s, files, first, s["demo"])
    if base["exit"] != 0 or not base["same"]:
        errs.append(f"demo run exit={base['exit']} same={base['same']} err={base['stderr'][-300:]}")
    got = [l for l in R.out_lines(base["stdout"]) if not l.startswith("[value]")]
    if got != [R.norm(x) for x in s.get("expected") or []]:
        errs.append(f"expected differs: wrote {s.get('expected')} ran {got}")
    s["expected_run"] = R.out_lines(base["stdout"])
    vs = s.get("violations") or []
    kind = s["kind"]
    if kind in ("F", "N", "trap"):
        if vs:
            errs.append("violations not empty")
    else:
        want = {"R": 1, "R_long": 1, "multi": 2, "double": 2}[kind]
        if len(vs) != want:
            errs.append(f"{kind} needs {want} violations, has {len(vs)}")
        if kind == "multi" and len({v.get("rule") for v in vs}) != 2:
            errs.append("multi: two different rules")
        if kind == "double" and (len({v.get("rule") for v in vs}) != 1 or len({line_key(v.get("line", "")) for v in vs}) != 2):
            errs.append("double: one rule on two different lines")
    if kind != "trap":
        for f in s["files"]:
            lang = R.lang_of(f["path"])
            code = code_only(f["after"], lang).split("\n") if kind == "F" else f["after"].split("\n")
            for raw, cl in zip(f["after"].split("\n"), code):
                for rule in KEY:
                    if markers_in(rule, cl) and not any(v.get("file") == f["path"] and line_key(v.get("line", "")) == line_key(raw) for v in vs):
                        errs.append(f"marker line not in violations: {f['path']}: {raw.strip()} ({rule})")
    for v in vs:
        if v.get("rule") not in KEY:
            errs.append(f"rule {v.get('rule')}")
            continue
        f = next((x for x in s["files"] if x["path"] == v.get("file")), None)
        if f is None:
            errs.append(f"violation file missing {v.get('file')}")
            continue
        n = len(v["line"].strip())
        if kind in ("R", "multi", "double") and n > 40:
            errs.append(f"{kind} line over 40: {n}")
        if kind == "R_long" and n <= 40:
            errs.append(f"R_long line not over 40: {n}")
        if not markers_in(v["rule"], v["line"]):
            errs.append(f"line holds no marker of {v['rule']}")
        if not any(holds_use(v["fix"], u) for u in KEY[v["rule"]]["use"]) or markers_in(v["rule"], v["fix"]):
            errs.append(f"fix bad: {v['fix']}")
        if not imports(f["after"], R.lang_of(f["path"]), v["rule"]):
            errs.append(f"{f['path']} does not import the {v['rule']} module")
        new, at = R.swap_line(f["after"], v["line"], v["fix"])
        if new is None:
            errs.append(f"violation line not in after: {v['line']}")
            continue
        v["n"] = at
        fx = R.run(s, {**files, v["file"]: new}, first, s["demo"])
        if fx["exit"] != 0 or not fx["same"]:
            errs.append(f"fix run exit={fx['exit']} same={fx['same']} err={fx['stderr'][-300:]}")
        cnt = lambda rec: sum(l.strip().startswith(STUB[v["rule"]].strip()) for l in rec.split("\n"))
        if cnt(fx["rec"]) <= cnt(base["rec"]):
            errs.append(f"S1 strict: fix run writes {cnt(fx['rec'])} {STUB[v['rule']].strip()} records, the run as written {cnt(base['rec'])}")
        v["expected_fixed"] = R.out_lines(fx["stdout"])
        v["rec_fixed"] = fx["rec"]
    return errs


if __name__ == "__main__":
    dst = f"{OUT}/samples.json"
    if os.path.exists(dst):
        sys.exit(f"refuse: {dst} exists")
    raw = json.load(open(RAW, encoding="utf-8"))
    report, ok = {}, {}
    for s in raw:
        errs = check(s)
        report[s["id"]] = {"kind": s.get("kind"), "lang": s.get("lang"), "errors": errs}
        ok[s["id"]] = not errs
        print(s["id"], s.get("kind"), s.get("lang"), "OK" if not errs else "FAIL", errs[:2])
    reserve_ids = {i for ids in RESERVES.values() for i in ids}
    used, final, replaced = [], [], {}
    for s in raw:
        if s["id"] in reserve_ids:
            continue
        if ok[s["id"]]:
            final.append(s)
            continue
        sub = next((r for r in sorted(RESERVES.get(s.get("kind"), [])) if ok.get(r) and r not in used), None)
        replaced.setdefault(s.get("kind"), []).append({"failed": s["id"], "by": sub})
        if sub:
            used.append(sub)
            final.append(next(x for x in raw if x["id"] == sub))
            report[s["id"]]["replaced_by"] = sub
        else:
            report[s["id"]]["dropped"] = True
    comp = {}
    for s in final:
        c = comp.setdefault(s["kind"], {"n": 0, "lang": {}, "rule": {}})
        c["n"] += 1
        c["lang"][s["lang"]] = c["lang"].get(s["lang"], 0) + 1
        for v in s.get("violations") or []:
            c["rule"][v["rule"]] = c["rule"].get(v["rule"], 0) + 1
        if s["kind"] == "trap":
            c.setdefault("trap", {})[s.get("trap")] = c.setdefault("trap", {}).get(s.get("trap"), 0) + 1
    txt = json.dumps(final, ensure_ascii=False, indent=1) + "\n"
    os.makedirs(OUT, exist_ok=True)
    open(dst, "w", encoding="utf-8").write(txt)
    os.chmod(dst, 0o444)
    rep = {"samplesSha256": hashlib.sha256(txt.encode("utf-8")).hexdigest(), "rawSha256": hashlib.sha256(open(RAW, "rb").read()).hexdigest(),
           "ids": [s["id"] for s in final], "composition": comp, "target": TARGET, "replaced": replaced,
           "shortViolations": sum(1 for s in final for v in s.get("violations") or [] if len(v["line"].strip()) <= 40), "report": report}
    open(f"{OUT}/check-report.json", "w", encoding="utf-8").write(json.dumps(rep, ensure_ascii=False, indent=1) + "\n")
    os.chmod(f"{OUT}/check-report.json", 0o444)
    print("final", len(final), "sha", rep["samplesSha256"], "replaced", json.dumps(replaced))
