"""learn-notes 1.13.0 G2 sonnet (batch 2; from impl113/b1/names/append113.py, append-only as 견본.md '### 이름 목록'
requires for 1.13.0: no line is removed, changed or re-sorted): append this batch's written names to impl113/NAMES-all.txt
right after the sample freeze (tag 'G2-measured-113', plan batches[1].samples.freeze). Names = every record of
frozen/raw.json and of the top-up roots (TOPUPS, a JSON list, as check.py reads them): its id, its concept name, its
file path, and every name its code defines (function/def/class, export const/let, top-level const NAME = ( / function /
arrow) -- the 1.12.0 rule, plus the concept name a G2 record carries. New rows (`name TAB G2-measured-113 TAB
impl113/b2/frozen/raw.json`) are appended after the last line in byte order; a row already present byte for byte is not
added twice. Also writes names/overlap.json: names and paths already in NAMES-all.txt (any tag) before the append
(record only). chmod 444 again. usage: append113.py   (model calls 0; refuses when G2-measured-113 lines are there;
env NAMES and RAW only for a tool test)"""
import glob, hashlib, json, os, re
SP = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad"
NAMES = os.environ.get("NAMES", SP + "/impl113/NAMES-all.txt")
RAW = os.environ.get("RAW", SP + "/impl113/b2/frozen/raw.json")
TOPUPS = json.loads(os.environ.get("TOPUPS", "[]"))
TAG = "G2-measured-113"
SRC = "impl113/b2/frozen/raw.json"
data = open(NAMES, "rb").read()
assert data.endswith(b"\n"), "NAMES-all.txt must end with a newline"
old = [l for l in data.decode("utf-8").split("\n") if l]
if any(len(l.split("\t")) > 1 and l.split("\t")[1] == TAG for l in old):
    raise SystemExit(f"refuse: {TAG} already appended")
before = {l.split("\t")[0] for l in old}
DEF = [re.compile(p, re.M) for p in (r"\bfunction\s*\*?\s*([A-Za-z_$][\w$]*)", r"^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)",
       r"^\s*class\s+([A-Za-z_$][\w$]*)", r"^\s*export\s+(?:const|let|var)\s+([A-Za-z_$][\w$]*)",
       r"^(?:const|let)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\(|function|[A-Za-z_$][\w$]*\s*=>)")]
recs = json.load(open(RAW, encoding="utf-8"))
for root in TOPUPS:
    for p in sorted(glob.glob(f"{root}/parts/TU-*-*/reply.json")):
        if not os.path.exists(os.path.join(os.path.dirname(p), "VOIDED")):
            recs += json.load(open(p, encoding="utf-8"))
ids, concepts, defined, paths = set(), set(), set(), set()
for s in recs:
    if not isinstance(s, dict):
        continue
    if isinstance(s.get("id"), str):
        ids.add(s["id"])
    if isinstance(s.get("name"), str) and s["name"].strip() and "\n" not in s["name"] and "\t" not in s["name"]:
        concepts.add(s["name"].strip())
    if isinstance(s.get("file"), str) and "\n" not in s["file"] and "\t" not in s["file"]:
        paths.add(s["file"])
    for t in (s.get("code") or "", s.get("before") or "", s.get("after") or ""):
        if isinstance(t, str):
            for p in DEF:
                defined.update(m.group(1) for m in p.finditer(t))
names = ids | concepts | paths | defined
have = set(old)
new = sorted({f"{n}\t{TAG}\t{SRC}" for n in names} - have, key=lambda s: s.encode("utf-8"))
before_sha = hashlib.sha256(data).hexdigest()
os.chmod(NAMES, 0o644)
open(NAMES, "ab").write(("\n".join(new) + "\n").encode("utf-8"))
os.chmod(NAMES, 0o444)
after = open(NAMES, "rb").read()
assert after[:len(data)] == data, "the old lines changed"
ov = {"conceptsAlready": sorted(concepts & before), "definedAlready": sorted(defined & before), "pathsAlready": sorted(paths & before)}
json.dump(ov, open(os.environ.get("OVERLAP", SP + "/impl113/b2/names/overlap.json"), "w"), ensure_ascii=False, indent=1)
print(json.dumps({"linesBefore": len(old), "lines": len(old) + len(new), "added": len(new), "ids": len(ids), "concepts": len(concepts), "paths": len(paths),
                  "defined": len(defined), "overlapConcepts": ov["conceptsAlready"], "overlapPaths": ov["pathsAlready"],
                  "sha256Before": before_sha, "sha256": hashlib.sha256(after).hexdigest()}, ensure_ascii=False))
