"""learn-notes 1.12.0 G3 (batch 3; batch 2 gate.py with the check point names of G3): the record and gate checks of a model-stage (M-10 · D19 · plan stopAlways,
usageGate; calibration record = '### 보정 기록 (1.12.0)').
  pre <precheck dir> <alias> <stage> <pin file>   -> gate.json beside it; exit 0 pass, 3 STOP (record differs: not
       called), 7 WAIT (usage gate: five_hour > 0.60 or seven_day >= 0.80; resetsAt written as ISO UTC), 9 not started
       (ONLY_WORKFLOW=1 not given). Check points (plan usageGate): 'G3 <stage> haiku' for the stages quiz-P (G3 quiz), quiz-Q (S-A2 quiz), quiz-U and every grade stage.
  after <stage dir> <alias> <pin file>             -> after.json; exit 0 same, 4 VOID (a session or the pin differs)
The before-record must equal the calibration: pinned `claude --version` 2.1.323 (Claude Code), pinned binary sha256
re-hashed now, the alias's init model the one the calibration resolved (read from the calibration's own record files,
never printed here), the result's modelUsage keys that id alone, exit 0.
'No other workflow running' is the agent's statement, passed as ONLY_WORKFLOW=1 and written to gate.json."""
import datetime, json, os, sys

CAL = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b0/calib/pre"
CAL_REC = {"haiku": f"{CAL}/haiku-2/record.json", "sonnet": f"{CAL}/sonnet-1/record.json"}
VERSION = "2.1.323 (Claude Code)"
PIN = {"claude": "604d29a6869409106b6a1110bdadcc8b72e8654a5a865d23258f938a696e348e",
       "claude.hot": "d2bc14daa55dcae7e85e5e0a7f80fb9c5de4572e9b3bfe28b6f11d89cba45a9e"}
WEEKLY_PROJECTION = 0.0  # plan usageGate: the weekly projection is for batch 1 and batch 4 only
FIVE_MAX, SEVEN_BELOW = 0.60, 0.80


def want_id(alias):
    return json.load(open(CAL_REC[alias], encoding="utf-8"))["inits"][0]


def pin_ok(path):
    text = open(path, encoding="utf-8").read()
    got = {}
    for line in text.splitlines():
        parts = line.split()
        if len(parts) == 2 and parts[1] in PIN:
            got[parts[1]] = parts[0]
    bad = [] if f"version: {VERSION}" in text else ["pinned version"]
    bad += [f"pinned {k} sha256" for k in PIN if got.get(k) != PIN[k]]
    return bad


def session_bad(rec, alias):
    i = want_id(alias)
    bad = []
    vs = list(rec["versions"].values())
    if not vs or any(v != VERSION for v in vs):
        bad.append("version")
    if not rec["inits"] or any(x != i for x in rec["inits"]):
        bad.append("init model")
    if not rec["results"] or any(r["modelUsage"] != [i] for r in rec["results"] if r["modelUsage"]) or not any(r["modelUsage"] == [i] for r in rec["results"]):
        bad.append("modelUsage keys")
    if rec.get("exit") != "exit=0":
        bad.append(rec.get("exit") or "no exit")
    return bad


def iso(ts):
    return datetime.datetime.fromtimestamp(ts, datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ") if ts else None


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "pre":
        d, alias, stage, pin = sys.argv[2:6]
        rec = json.load(open(f"{d}/record.json", encoding="utf-8"))
        bad = session_bad(rec, alias) + pin_ok(pin)
        win = {}
        for ev in rec["rate_limit_events"]:
            for k, v in (ev.get("unifiedWindows") or {}).items():
                win[k] = v
        five, seven = win.get("five_hour", {}), win.get("seven_day", {})
        fu, su = five.get("utilization"), seven.get("utilization")
        proj = WEEKLY_PROJECTION
        only = os.environ.get("ONLY_WORKFLOW") == "1"
        gate = fu is not None and su is not None and fu <= FIVE_MAX and su < SEVEN_BELOW and su + proj < SEVEN_BELOW
        out = {"checkPoint": f"G3 {stage} {alias}", "precheck": d, "started": rec.get("started"),
               "recordSame": not bad, "differs": bad, "five_hour": {"utilization": fu, "resetsAt": iso(five.get("resetsAt"))},
               "seven_day": {"utilization": su, "resetsAt": iso(seven.get("resetsAt"))}, "weeklyProjection": proj,
               "rule": "five_hour <= 0.60 AND seven_day < 0.80 AND seven_day + projection < 0.80 AND no other workflow running",
               "onlyThisWorkflow": only, "pass": bool(gate) and only and not bad}
        json.dump(out, open(f"{d}/gate.json", "w"), indent=1)
        print(json.dumps({k: out[k] for k in ("recordSame", "differs", "five_hour", "seven_day", "weeklyProjection", "onlyThisWorkflow", "pass")}))
        if bad:
            sys.exit(3)
        if not only:
            print("NOT ATTESTED: set ONLY_WORKFLOW=1 only after checking that no other workflow runs in the session")
            sys.exit(9)
        if not gate:
            wait = five.get("resetsAt") if (fu is None or fu > FIVE_MAX) else seven.get("resetsAt")
            print(f"WAIT {iso(wait)}")
            sys.exit(7)
    elif mode == "after":
        d, alias, pin = sys.argv[2:5]
        bad = pin_ok(pin)
        sessions = []
        for sub in sorted(os.listdir(d)):
            p = f"{d}/{sub}/record.json"
            if os.path.exists(p) and sub != "pre":
                b = session_bad(json.load(open(p, encoding="utf-8")), alias)
                sessions.append(sub)
                bad += [f"{sub}: {x}" for x in b]
        out = {"stage": d, "sessions": sessions, "same": not bad, "differs": bad}
        json.dump(out, open(f"{d}/after.json", "w"), indent=1)
        print(json.dumps(out))
        sys.exit(0 if not bad else 4)
    else:
        sys.exit("usage: gate.py pre <dir> <alias> <stage> <pin> | after <dir> <alias> <pin>")
