"""learn-notes 1.12.0 G3 (batch 3; from batch 2's tapsend.py; record only, B-12, SCOPE's batch-3 fact, design calls.tap):
after a stage is DONE and its answers saved and hashed, each empty reply (reason empty-reply) of any attempt and each cut
reply is sent once more, its frozen line as it is, through the local pass-through tap (tap/call.sh through
cli/pinned.sh), to record stop_reason and stop_details. Cut (the engine's reply carries no stop reason, so the tool sees
the second half of the design's rule): a quiz reply answered with a slot missing while output_tokens < 4600 + H_haiku
= 6648 (read.mjs 'cut'); a grade reply answered that the grade reader could not read while output_tokens < 480 + H_haiku
= 2528 (grade.mjs 'unreadUnderCap'). The ids come in a file the reader wrote. It never enters a count or a decision and
no answer text is read or kept (the tap keeps lengths and sha256 alone); refusals are their own column (count.py).
usage: tapsend.py <stage> [<cut ids .json: a list of request ids>]  -> stage/<stage>/haiku/tap.json (chmod 444)"""
import hashlib, json, os, subprocess, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3"
P = os.environ.get("PINNED", "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh")
sha = lambda text: hashlib.sha256(text.encode("utf-8")).hexdigest()
st = sys.argv[1]
m = "haiku"
d = f"{S}/stage/{st}/{m}"
if not os.path.exists(f"{d}/DONE"):
    sys.exit(f"refuse: {d}/DONE missing")
out_path = f"{d}/tap.json"
if os.path.exists(out_path):
    sys.exit(f"refuse: {out_path} exists")
started = open(f"{d}/STARTED", encoding="utf-8").read().split("\n")
lines_p = started[1].split()[1]
lines = {json.loads(x)["id"]: json.loads(x) for x in open(lines_p, encoding="utf-8") if x.strip()}
empty = []
for a in (1, 2):
    p = f"{d}/call-{a}/out.json"
    if os.path.exists(p):
        empty += [r["id"] for r in json.load(open(p, encoding="utf-8"))["results"] if r.get("reason") == "empty-reply"]
cut = json.load(open(sys.argv[2], encoding="utf-8")) if len(sys.argv) > 2 else []
send = list(dict.fromkeys(empty + [i for i in cut if i in lines]))
rec = {"stage": st, "empty": empty, "cut": cut, "sent": {}}
if send:
    t = f"{d}/tap"
    os.makedirs(t, exist_ok=True)
    tl = f"{t}/tap-lines.jsonl"
    with open(tl, "w", encoding="utf-8") as f:
        for i in send:
            f.write(json.dumps(lines[i], ensure_ascii=False) + "\n")
    subprocess.run([P, "bash", f"{S}/tap/call.sh", t, m, tl], check=False)
    seen = [json.loads(x) for x in open(f"{t}/tap.jsonl", encoding="utf-8")] if os.path.exists(f"{t}/tap.jsonl") else []
    for i in send:
        want = sha(lines[i]["prompt"])
        hits = [s for s in seen if any(u.get("sha256") == want for u in (s.get("request") or {}).get("user_texts", []))]
        last = hits[-1] if hits else None
        rec["sent"][i] = {"why": "empty" if i in empty else "cut", "matched": len(hits), **({k: last.get(k) for k in ("status", "stop_reason", "stop_details", "output_tokens", "error_type", "tap_error")} if last else {})}
body = json.dumps(rec, ensure_ascii=False, indent=1) + "\n"
open(out_path, "w", encoding="utf-8").write(body)
os.chmod(out_path, 0o444)
print(json.dumps({"stage": st, "empty": len(empty), "cut": len(cut), "refusals": sum(1 for v in rec["sent"].values() if v.get("stop_reason") == "refusal"), "sha256": sha(body)}))
