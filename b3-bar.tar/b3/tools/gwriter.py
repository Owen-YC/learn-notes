"""learn-notes 1.12.0 G3 (batch 3): the grading answers (design samples 'Grading answers', stance G-2 · G-3 · G-7), from
the design pilot's gwriter.py. Per label and set, after the quiz stage is frozen and judged (tally.py quiz).
usage: gwriter.py prompt <set> <label>   items = judge/<L>/tally-quiz-<set>.json 'passing' (the measured questions
                                          that met clauses 1-7; correct = the stored answer's lines); refuses unless judge/<L>/grading.json runs it for <set>.
                                          -> grade/<set>/gw-items.json (key, question, hint, answer, correct lines,
                                          item) and gw-prompt.md (the writer sees only the label and each item's
                                          question as shown, hint and correct printed lines)
       gwriter.py write <set> <try: 1|2>  a fresh blind writer: `claude -p --model opus --tools ''` in an empty dir
                                          through cli/pinned.sh, the prompt on stdin (try 2 = the same prompt file)
                                          -> grade/<set>/gw-<try>/ (out.json, result.txt, model.txt, pin.txt, times)
       gwriter.py parse <set>             G-7: the latest reply must hold exactly one ```json block that reads as a
                                          list; else 'WRITE GW 2' (exit 5) after try 1, and after try 2 'C1-C4 FAIL'
                                          (grade/<set>/gw-fail.json, exit 6). The session never chooses a block.
                                          -> grade/<set>/gw.json (chmod 444)
       gwriter.py items <set> <label>     after gvalid.mjs and the label's judge (verdicts-grade-<set>.json): items.json
                                          with valid[kind] = true (the tool found nothing and the judge said valid),
                                          false (the tool or the judge found it invalid: left out before any call, G-2)
                                          or 'undecided' (the tool found nothing, the judge's verdict undecided or
                                          missing: never called, a miss in its cells, tally.py), chmod 444
The prompt's rules (design): beginner register; every 3rd item's right joins its values with commas on one line unless
a printed line holds a comma (then lines); every 5th item's right adds a short reason; again differs from right in
wording; wrongOne exactly one line's value wrong; wrongAll no line's value right; never a different printed form (1 and
1.0, True and true) as right; never a shortened value; `values` = each answer's value per printed line."""
import hashlib, json, os, re, subprocess, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3"
P = os.environ.get("PINNED", "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh")
J = os.environ.get("JUDGE", f"{S}/judge")
G = os.environ.get("GRADE", f"{S}/grade")
CLAUDE = os.environ.get("WRITER_CMD", "timeout 2400 claude -p --model opus --tools '' --output-format json")


def frozen_write(path, text):
    if os.path.exists(path):
        sys.exit(f"refuse: {path} exists")
    open(path, "w", encoding="utf-8").write(text)
    os.chmod(path, 0o444)


def prompt(s, label):
    g = json.load(open(f"{J}/{label}/grading.json", encoding="utf-8"))
    if not g.get("runs") or s not in g.get("sets", []):
        sys.exit(f"refuse: judge/{label}/grading.json says grading does not run for set {s} ({g.get('why')})")
    t = json.load(open(f"{J}/{label}/tally-quiz-{s}.json", encoding="utf-8"))
    rd = json.load(open(f"{J}/{label}/read-{s}.json", encoding="utf-8"))
    stored = {f"{q['id']}#{sl['place']}": sl["item"] for q in rd["quizzes"] for sl in q["slots"] if sl.get("item")}
    items = []
    for key in t["passing"]:
        it = stored[key]
        items.append({"key": key, "question": it["question"], "hint": it["hint"], "answer": it["answer"], "correct": it["answer"].split("\n"), "item": it})
    d = f"{G}/{s}"
    os.makedirs(d, exist_ok=True)
    shown = [{"key": i["key"], "question": i["question"], "hint": i["hint"], "correct": i["correct"]} for i in items]
    text = f"""꼬리표 {label}의 퀴즈 문항 {len(items)}개에 대해, 코딩을 막 배우는 학습자가 입력칸에 쓸 법한 답을 문항마다 네 가지 쓴다. 답은 짧은 한국어 글이다(입문자 말투, 합니다체가 아니어도 됨). 문항의 question은 학습자에게 보인 글 그대로이고, correct는 그 문항의 모범 답, 곧 그 코드를 돌리면 찍히는 줄이다.

- right: 맞는 답. 찍히는 값을 줄마다 모두 차례대로 말한다. 문항 차례로 3번째마다(3, 6, 9 …번째 문항) 값을 쉼표로 이어 한 줄에 쓴다. 단, correct의 어느 줄에 쉼표가 있으면 그 문항은 언제나 줄을 바꿔 쓴다. 5번째마다(5, 10 …번째 문항) 값 뒤에 짧은 까닭을 덧붙인다(까닭 속에 다른 값을 줄 값처럼 말하지 않는다).
- again: 처음엔 틀렸다가 다시 낸 맞는 답. right와 글이 달라야 한다(말투나 꼴을 바꿈). 값은 모두 맞고 차례대로다. correct의 어느 줄에 쉼표가 있으면 줄을 바꿔 쓴다.
- wrongOne: 줄 수는 같고 정확히 한 줄의 값만 틀린 답(입문자가 흔히 할 법한 실수).
- wrongAll: 어느 줄의 값도 제자리에서 맞지 않는 답(줄 수가 달라도 됨. 오류가 난다, 아무것도 안 나온다도 됨).
- 찍히는 글자가 다른 꼴(1과 1.0, True와 true)을 맞는 답으로 쓰지 않는다. 값을 줄여 쓰지 않는다(… 나 ... 를 쓰지 않는다).
- 문항마다 각 답이 줄마다 말한 값을 values에 적는다(줄 값을 말하지 않았으면 null, wrongAll에서 줄 수가 다르면 말한 값들을 차례대로).

문항(JSON):
{json.dumps(shown, ensure_ascii=False, indent=1)}

출력: ```json 블록 하나만. 다른 말은 쓰지 않는다. 꼴:
[{{"key": "...", "right": "...", "again": "...", "wrongOne": "...", "wrongAll": "...", "values": {{"right": [...], "again": [...], "wrongOne": [...], "wrongAll": [...]}}}}, ...]
도구는 없다. 도구 호출을 쓰지 말고 JSON 블록을 바로 답으로 쓴다.
"""
    frozen_write(f"{d}/gw-items.json", json.dumps(items, ensure_ascii=False, indent=1) + "\n")
    frozen_write(f"{d}/gw-prompt.md", text)
    print(json.dumps({"set": s, "items": len(items), "prompt_sha256": hashlib.sha256(text.encode()).hexdigest()}))


def write(s, tr):
    d = f"{G}/{s}"
    o = f"{d}/gw-{tr}"
    if os.path.exists(o):
        sys.exit(f"refuse: {o} exists")
    if tr == "2" and not os.path.exists(f"{d}/gw-1/result.txt"):
        sys.exit("refuse: no try 1")
    os.makedirs(o)
    w = f"{S}/work/gw-{s}-{tr}"
    os.makedirs(w, exist_ok=True)
    open(f"{o}/started.txt", "w").write(subprocess.run(["date", "-u", "+%FT%TZ"], capture_output=True, text=True).stdout)
    with open(f"{d}/gw-prompt.md", "rb") as fin, open(f"{o}/out.json", "wb") as fout:
        subprocess.run([P, "bash", "-c", CLAUDE], stdin=fin, stdout=fout, stderr=open(f"{o}/err.txt", "w"), cwd=w)
    open(f"{o}/ended.txt", "w").write(subprocess.run(["date", "-u", "+%FT%TZ"], capture_output=True, text=True).stdout)
    subprocess.run([P, "--record"], stdout=open(f"{o}/pin.txt", "w"), stderr=subprocess.STDOUT)
    try:
        out = json.load(open(f"{o}/out.json", encoding="utf-8"))
    except Exception:
        out = {}
    open(f"{o}/result.txt", "w", encoding="utf-8").write(out.get("result") or "")
    open(f"{o}/model.txt", "w").write(json.dumps(sorted((out.get("modelUsage") or {}).keys())) + "\n")
    print("writer", o, "is_error", out.get("is_error"))


def parse(s):
    d = f"{G}/{s}"
    tr = "2" if os.path.exists(f"{d}/gw-2/result.txt") else "1"
    text = open(f"{d}/gw-{tr}/result.txt", encoding="utf-8").read()
    blocks = re.findall(r"```json[ \t]*\n(.*?)\n```", text, re.S)
    data = None
    if len(blocks) == 1:
        try:
            data = json.loads(blocks[0])
        except Exception:
            data = None
    if not isinstance(data, list):
        print(f"try {tr}: {len(blocks)} json blocks, readable list: {isinstance(data, list)}")
        if tr == "1":
            print("WRITE GW 2")
            sys.exit(5)
        frozen_write(f"{d}/gw-fail.json", json.dumps({"set": s, "why": "G-7: the second reply holds no one readable json block", "blocks": len(blocks)}) + "\n")
        print("C1-C4 FAIL (G-7)")
        sys.exit(6)
    frozen_write(f"{d}/gw.json", json.dumps(data, ensure_ascii=False, indent=1) + "\n")
    print(json.dumps({"set": s, "try": tr, "answers": len(data)}))


def items(s, label):
    d = f"{G}/{s}"
    base = json.load(open(f"{d}/gw-items.json", encoding="utf-8"))
    W = {w["key"]: w for w in json.load(open(f"{d}/gw.json", encoding="utf-8")) if isinstance(w, dict) and "key" in w}
    tool = json.load(open(f"{d}/gvalid.json", encoding="utf-8"))
    vj = f"{J}/{label}/verdicts-grade-{s}.json"
    if not (os.path.exists(vj) and os.stat(vj).st_mode & 0o222 == 0):
        sys.exit("refuse: the judge's grade verdicts are not frozen")
    judge = {v["key"]: v for v in json.load(open(vj, encoding="utf-8"))["verdicts"]}
    out = []
    for b in base:
        w = W.get(b["key"], {})
        valid = {}
        for k in ("right", "again", "wrongOne", "wrongAll"):
            t_ok = not tool.get(b["key"], {}).get(k, ["missing"])
            j = judge.get(b["key"], {}).get(k)
            valid[k] = False if (not t_ok or j == "invalid") else True if j == "valid" else "undecided"
        out.append({"key": b["key"], "item": b["item"], **{k: w.get(k) for k in ("right", "again", "wrongOne", "wrongAll")}, "valid": valid})
    frozen_write(f"{d}/items.json", json.dumps(out, ensure_ascii=False, indent=1) + "\n")
    print(json.dumps({"set": s, "items": len(out), "invalid": {k: sum(1 for o in out if o["valid"][k] is False) for k in ("right", "again", "wrongOne", "wrongAll")}, "undecided": {k: sum(1 for o in out if o["valid"][k] == "undecided") for k in ("right", "again", "wrongOne", "wrongAll")}}))


if __name__ == "__main__":
    c = sys.argv[1]
    {"prompt": lambda: prompt(sys.argv[2], sys.argv[3]), "write": lambda: write(sys.argv[2], sys.argv[3]), "parse": lambda: parse(sys.argv[2]), "items": lambda: items(sys.argv[2], sys.argv[3])}.get(c, lambda: sys.exit(__doc__))()
