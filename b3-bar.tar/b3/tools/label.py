"""learn-notes 1.12.0 G3 (batch 3; from batch 2's label.py): blind label (M-8; plan commonPerBatch step 5). One measured
model, one label for the whole round (every quiz and grade stage).
  seal          after stage/quiz-P/haiku/DONE: draws the label at random from A and B (secrets), writes judge/pair.json
                {label: model, nonce} chmod 444 and prints its sha256 alone (sealed until every verdict file is frozen);
                writes judge/label.txt (the label alone).
  read <P|Q|U>  judge/<L>/read-<set>.json from stage quiz-<set>'s final replies (tools/read.mjs); named by the label, no
                model field.
  open          after every judge/<L>/verdicts-*.json, tally-*.json and grading.json is frozen (chmod 444) and
                tally-grade.json exists: prints the pair.
No file written before 'open' names the model next to the label (batch 1 audit lesson 1)."""
import hashlib, json, os, secrets, subprocess, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3"
J = os.environ.get("JUDGE", f"{S}/judge")
ST = os.environ.get("STAGES", f"{S}/stage")
FROZEN = os.environ.get("FROZEN", f"{S}/frozen")
mode = sys.argv[1]
if mode == "seal":
    if not os.path.exists(f"{ST}/quiz-P/haiku/DONE"):
        sys.exit("refuse: stage quiz-P is not DONE")
    if os.path.exists(f"{J}/pair.json"):
        sys.exit("refuse: judge/pair.json exists")
    os.makedirs(J, exist_ok=True)
    label = secrets.choice(["A", "B"])
    body = json.dumps({label: "haiku", "nonce": secrets.token_hex(16)}) + "\n"
    open(f"{J}/pair.json", "w").write(body)
    os.chmod(f"{J}/pair.json", 0o444)
    open(f"{J}/label.txt", "w").write(label + "\n")
    os.chmod(f"{J}/label.txt", 0o444)
    print("pair.json sha256", hashlib.sha256(body.encode()).hexdigest())
elif mode == "read":
    s = sys.argv[2]
    label = open(f"{J}/label.txt").read().strip()
    if not os.path.exists(f"{ST}/quiz-{s}/haiku/DONE"):
        sys.exit(f"refuse: stage quiz-{s} is not DONE")
    os.makedirs(f"{J}/{label}", exist_ok=True)
    subprocess.run(["node", "--experimental-transform-types", "--no-warnings", f"{S}/tools/read.mjs", f"{ST}/quiz-{s}/haiku", FROZEN, s, f"{J}/{label}/read-{s}.json"], check=True)
elif mode == "open":
    label = open(f"{J}/label.txt").read().strip()
    d = f"{J}/{label}"
    files = [f for f in os.listdir(d) if f.startswith(("verdicts-", "tally-")) or f == "grading.json"]
    if "tally-grade.json" not in files or not all(os.stat(f"{d}/{f}").st_mode & 0o222 == 0 for f in files):
        sys.exit("refuse: the verdict files and the tallies are not all frozen")
    print(open(f"{J}/pair.json").read().strip())
else:
    sys.exit("usage: label.py seal | read <P|Q|U> | open")
