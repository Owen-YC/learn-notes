"""learn-notes 1.12.0 G3 (batch 3; from batch 2's count.py): the machine counts of one label (M-8: by label, never shown to a
judge). usage: count.py <label> <stage>  -> judge/count-<L>-<stage>.json (chmod 444; refuses an existing one). Run
when that stage is DONE and its tap.json written.
Per stage (quiz-P, quiz-Q, quiz-U, grade1-P, grade2-P, grade1-Q, grade2-Q): calls per attempt, each
request's final status (how), resends, cap hits (output_tokens >= maxTokens + H_haiku: quiz 4600 + 2048 = 6648, grade
480 + 2048 = 2528), output_tokens max and median of the answered, time (ms) max and median, the tap's empty and cut
replies with their stop_reason (refusals as their own column); per request {how, cap, output_tokens, ms} (tally.py reads
how and cap). For the grade stages also the local share (grade/<set>/plan-<k>.json local paths of all planned) and L0's
machine count (a valid wrongOne or wrongAll that localRight read as right)."""
import json, os, statistics, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3"
J = os.environ.get("JUDGE", f"{S}/judge")
ST = os.environ.get("STAGES", f"{S}/stage")
G = os.environ.get("GRADE", f"{S}/grade")
H = 2048
label, only = sys.argv[1], sys.argv[2]
outp = f"{J}/count-{label}-{only}.json"
if os.path.exists(outp):
    sys.exit(f"refuse: {outp} exists")
res = {"label": label, "H_haiku": H, "stages": {}}
for st in ("quiz-P", "quiz-Q", "quiz-U", "grade1-P", "grade2-P", "grade1-Q", "grade2-Q"):
    d = f"{ST}/{st}/haiku"
    if st != only:
        continue
    if not os.path.exists(f"{d}/DONE"):
        sys.exit(f"refuse: {d}/DONE missing")
    cap_at = (4600 if st.startswith("quiz") else 480) + H
    final, attempts = {}, []
    for a in (1, 2):
        p = f"{d}/call-{a}/out.json"
        if not os.path.exists(p):
            continue
        rs = json.load(open(p, encoding="utf-8"))["results"]
        attempts.append({"attempt": a, "calls": len(rs)})
        for r in rs:
            how = "threw" if r.get("threw") is not None else "answered" if r.get("isAnswered") else r.get("reason")
            if how == "api-error":
                how += f"/{r.get('status')}"
            tok = (r.get("usage") or {}).get("output_tokens")
            final[r["id"]] = {"how": how, "output_tokens": tok, "ms": r.get("ms"), "cap": isinstance(tok, int) and tok >= cap_at, "attempt": a}
    toks = sorted(v["output_tokens"] for v in final.values() if v["how"] == "answered" and isinstance(v["output_tokens"], int))
    ms = sorted(v["ms"] for v in final.values() if v["how"] == "answered" and isinstance(v["ms"], (int, float)))
    tap = json.load(open(f"{d}/tap.json", encoding="utf-8")) if os.path.exists(f"{d}/tap.json") else None
    counts = {}
    for v in final.values():
        counts[v["how"]] = counts.get(v["how"], 0) + 1
    row = {"capAt": cap_at, "attempts": attempts, "requests": len(final), "counts": counts, "resent": sum(1 for v in final.values() if v["attempt"] == 2),
           "caps": sum(1 for v in final.values() if v["cap"]), "timeouts": counts.get("timeout", 0), "empty": counts.get("empty-reply", 0),
           "tokens": {"max": toks[-1] if toks else None, "median": statistics.median(toks) if toks else None},
           "ms": {"max": ms[-1] if ms else None, "median": statistics.median(ms) if ms else None},
           "tap": None if tap is None else {"empty": len(tap["empty"]), "cut": len(tap["cut"]), "refusals": sum(1 for v in tap["sent"].values() if v.get("stop_reason") == "refusal"), "stop": {i: v.get("stop_reason") for i, v in tap["sent"].items()}},
           "byId": final}
    if st.startswith("grade"):
        k, s = st[5], st.split("-")[1]
        pf = f"{G}/{s}/plan-{k}.json"
        if os.path.exists(pf):
            plan = json.load(open(pf, encoding="utf-8"))
            row["paths"] = len(plan)
            row["local"] = sum(1 for p in plan if p.get("local"))
            row["L0"] = sum(1 for p in plan if p.get("local") and p["kind"] in ("wrongOne", "wrongAll"))
    res["stages"][st] = row
body = json.dumps(res, ensure_ascii=False, indent=1) + "\n"
open(outp, "w", encoding="utf-8").write(body)
os.chmod(outp, 0o444)
print(json.dumps({st: {k: v for k, v in r.items() if k != "byId"} for st, r in res["stages"].items()}, ensure_ascii=False))
