// learn-notes 1.12.0 G3 (batch 3): stance G-3's machine part (the tool looks before any grading call; the label's judge
// confirms). From the design pilot's gvalid.py, on the committed tree's own isSameValue (b3/mtree = f03b362), with the
// writer's own `values` (what each answer says each printed line is).
// usage: node --experimental-transform-types gvalid.mjs <grade set dir>   reads gw-items.json and gw.json; writes
//   gvalid.json ({ key: { right, again, wrongOne, wrongAll: [reasons] } }, [] = valid) and gw-report.md (the judge's
//   report: per item the question as stored, hint, printed lines, the four answers and the tool's reasons), chmod 444.
// right · again: values has one entry per printed line and each isSameValue(value, printed line); the values are found
//   in the answer in order (each as written, or its isSameValue-equal form); where a printed line holds a comma the answer
//   has its values on separate lines (a comma-joined answer is invalid); no '…' or '...' unless a printed line has it
//   (a shortened value); again is not right's text (trimmed).
// wrongOne: values has one non-empty entry per printed line and exactly one differs (isSameValue false).
// wrongAll: no place i where values[i] is said and isSameValue(values[i], printed[i]) (a full reversal counts as all wrong).
import { readFileSync, writeFileSync, existsSync, chmodSync } from 'node:fs'
import { join } from 'node:path'

const P = await import(process.env.NOTES ?? '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3/mtree/hooks/notes.ts')
const dir = process.argv[2]
for (const f of ['gvalid.json', 'gw-report.md']) if (existsSync(join(dir, f))) { console.log(`refuse: ${f} exists`); process.exit(1) }
const items = Object.fromEntries(JSON.parse(readFileSync(join(dir, 'gw-items.json'), 'utf8')).map(i => [i.key, i]))
const W = JSON.parse(readFileSync(join(dir, 'gw.json'), 'utf8'))
const out = {}
const report = []
const inOrder = (text, vals, printed) => {
  let at = 0
  for (let i = 0; i < vals.length; i++) {
    const forms = [String(vals[i]).trim(), P.gradeSame(String(vals[i])), String(printed[i]).trim()]
    const hit = forms.map(f => (f ? text.indexOf(f, at) : -1)).filter(k => k >= 0).sort((a, b) => a - b)[0]
    if (hit === undefined) return false
    at = hit + 1
  }
  return true
}
for (const key of Object.keys(items)) {
  const it = items[key]
  const printed = it.correct
  const w = W.find(x => x && x.key === key)
  const why = { right: [], again: [], wrongOne: [], wrongAll: [] }
  if (!w || !w.values) { for (const k of Object.keys(why)) why[k].push('missing'); out[key] = why; continue }
  const comma = printed.some(l => l.includes(','))
  const dots = printed.some(l => l.includes('…') || l.includes('...'))
  for (const kind of ['right', 'again']) {
    const v = w.values[kind] ?? []
    const text = String(w[kind] ?? '')
    if (!text.trim()) why[kind].push('empty')
    if (v.length !== printed.length || v.some((x, i) => x === null || !P.isSameValue(String(x), printed[i]))) why[kind].push('values')
    else if (!inOrder(text, v, printed)) why[kind].push('order')
    if (comma && !text.includes('\n')) why[kind].push('comma-joined')
    if (!dots && (text.includes('…') || text.includes('...'))) why[kind].push('shortened')
  }
  if (String(w.again ?? '').trim() === String(w.right ?? '').trim()) why.again.push('again=right')
  const vo = w.values.wrongOne ?? []
  if (vo.length !== printed.length || vo.some(x => x === null || String(x).trim() === '') || vo.filter((x, i) => !P.isSameValue(String(x), printed[i])).length !== 1) why.wrongOne.push('values')
  const va = w.values.wrongAll ?? []
  if (va.some((x, i) => i < printed.length && x !== null && P.isSameValue(String(x), printed[i]))) why.wrongAll.push('a value right in its place')
  for (const kind of ['right', 'again', 'wrongOne', 'wrongAll']) if (typeof w[kind] !== 'string' || !w[kind].trim()) if (!why[kind].includes('empty')) why[kind].push('empty')
  out[key] = why
  report.push([
    `### ${key}`,
    '- 저장된 question (학습자에게 보인 글 그대로):', '````', it.question, '````',
    `- 저장된 hint: ${it.hint}`,
    '- 실제로 찍히는 줄(stdout):', '```', printed.join('\n'), '```',
    ...['right', 'again', 'wrongOne', 'wrongAll'].flatMap(kind => [`- ${kind}:`, '```', String(w[kind] ?? ''), '```', `  도구가 본 것: ${why[kind].length ? '무효(' + why[kind].join(', ') + ')' : '유효'}`]),
  ].join('\n'))
}
writeFileSync(join(dir, 'gvalid.json'), JSON.stringify(out, null, 1) + '\n')
writeFileSync(join(dir, 'gw-report.md'), `# 채점 견본 답 확인 자료\n\n문항 ${report.length}개.\n\n` + report.join('\n\n') + '\n')
for (const f of ['gvalid.json', 'gw-report.md']) chmodSync(join(dir, f), 0o444)
const bad = Object.entries(out).flatMap(([k, v]) => Object.entries(v).filter(([, w]) => w.length).map(([kind, w]) => `${k} ${kind} ${w.join(',')}`))
console.log(`items ${report.length}, invalid by the tool ${bad.length}`)
for (const b of bad) console.log('  ' + b)
