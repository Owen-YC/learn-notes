"""learn-notes 1.12.0 G3 (batch 3; from batch 2's judge.py): the judge of one label ('판정 하위 에이전트': one per label,
G3 1.10.0 as it was; design judges: quiz clauses and grading-answer validity). One agent: the label's first job starts a
fresh sub-agent (`claude -p --model opus --tools '' --output-format json` in the label's own empty work dir through
cli/pinned.sh, prompt on stdin) and every later job of that label resumes the same session (`--resume <session id>`,
same work dir), so the label has one judge. It never took part in the design, the sample writing or the calls; it is
given this stance text whole at the start (judge/stance-quiz.md then judge/stance-grade.md: cut from this section's
'판정의 입장' as committed, plan tools.rule; together every line of it), each job's template (which clauses it rules and
the answer form; it adds no clause) and that job's per-item material: no model name, token, time or cap, no other label.
usage: judge.py quiz <label> <set: P|Q|U>   rows: every stored new item of judge/<L>/eval-<set>.json (its report-<set>.md)
       judge.py grade <label> <set: P|Q>    rows: every item of grade/<set>/gw-items.json (grade/<set>/gw-report.md)
       -> judge/<L>/judge-<kind>-<set>/ (prompt.md, out.json, result.txt, model.txt, pin.txt) and
          judge/<L>/verdicts-<kind>-<set>.json (chmod 444; refuses an existing one); judge/<L>/session.txt holds the
          session id after the first job.
The reply must be a JSON array, one entry per key, each verdict field with its '<field>_why' (the clause number and one
line). A verdict missing, unreadable, without its reason, or 'undecided' is 'undecided' and counts against (a quiz
miss; a grading answer neither valid nor excluded: a miss in its cells). No job is asked again (a judge error or a
missing verdict is a miss)."""
import hashlib, json, os, subprocess, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3"
P = os.environ.get("PINNED", "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh")
J = os.environ.get("JUDGE", f"{S}/judge")
G = os.environ.get("GRADE", f"{S}/grade")
CLAUDE = os.environ.get("JUDGE_CMD", "timeout 2400 claude -p --model opus --tools '' --output-format json")
STANCE = os.environ.get("STANCE_DIR", f"{S}/judge")
kind, label, s = sys.argv[1:4]
d = f"{J}/{label}"
vp = f"{d}/verdicts-{kind}-{s}.json"
if os.path.exists(vp):
    sys.exit(f"refuse: {vp} exists")
if kind == "quiz":
    rows = json.load(open(f"{d}/eval-{s}.json", encoding="utf-8"))["rows"]
    want = {r["key"]: (["c3ra", "c4", "c5use", "c7"] + (["mimic"] if r["u"] else [])) for r in rows if "question" in r and "code" in r}
    report = open(f"{d}/report-{s}.md", encoding="utf-8").read()
    tpl = open(f"{S}/judge/tpl-quiz.md", encoding="utf-8").read()
    vals = ("pass", "miss")
elif kind == "grade":
    items = json.load(open(f"{G}/{s}/gw-items.json", encoding="utf-8"))
    want = {w["key"]: ["right", "again", "wrongOne", "wrongAll"] for w in items}
    report = open(f"{G}/{s}/gw-report.md", encoding="utf-8").read()
    tpl = open(f"{S}/judge/tpl-grade.md", encoding="utf-8").read()
    vals = ("valid", "invalid")
else:
    sys.exit(__doc__)
sid_f = f"{d}/session.txt"
first = not os.path.exists(sid_f)
stance = open(f"{STANCE}/stance-quiz.md", encoding="utf-8").read() + "\n" + open(f"{STANCE}/stance-grade.md", encoding="utf-8").read()
head = "# 판정의 입장\n\n" + stance + "\n" if first else "(판정의 입장은 이 대화의 처음에 받은 글 그대로입니다.)\n\n"
prompt = head + tpl + "\n# 보고서\n\n" + report
o = f"{d}/judge-{kind}-{s}"
if os.path.exists(o):
    sys.exit(f"refuse: {o} exists")
os.makedirs(o)
w = f"{S}/work/judge-{label}"
os.makedirs(w, exist_ok=True)
open(f"{o}/prompt.md", "w", encoding="utf-8").write(prompt)
cmd = CLAUDE if first else f"{CLAUDE} --resume {open(sid_f).read().strip()}"
with open(f"{o}/prompt.md", "rb") as fin, open(f"{o}/out.json", "wb") as fout:
    subprocess.run([P, "bash", "-c", cmd], stdin=fin, stdout=fout, stderr=open(f"{o}/err.txt", "w"), cwd=w)
subprocess.run([P, "--record"], stdout=open(f"{o}/pin.txt", "w"), stderr=subprocess.STDOUT)
try:
    out = json.load(open(f"{o}/out.json", encoding="utf-8"))
except Exception:
    out = {}
if first and out.get("session_id"):
    open(sid_f, "w").write(out["session_id"] + "\n")
    os.chmod(sid_f, 0o444)
text = out.get("result") or ""
open(f"{o}/result.txt", "w", encoding="utf-8").write(text)
open(f"{o}/model.txt", "w").write(json.dumps(sorted((out.get("modelUsage") or {}).keys())) + "\n")
try:
    a, b = text.find("["), text.rfind("]")
    got = {g["key"]: g for g in json.loads(text[a:b + 1]) if isinstance(g, dict) and "key" in g}
except Exception:
    got = {}
verdicts = []
for k, fields in want.items():
    g = got.get(k) or {}
    row = {"key": k}
    for f in fields:
        ok = g.get(f) in vals and isinstance(g.get(f"{f}_why"), str) and g.get(f"{f}_why").strip() != ""
        row[f] = g.get(f) if ok else "undecided"
        row[f"{f}_why"] = g.get(f"{f}_why") if ok else (g.get(f"{f}_why") or "답에 없거나 읽지 못함 · 이유 없음 · 정하지 못함(도구)")
    verdicts.append(row)
body = json.dumps({"label": label, "kind": kind, "set": s, "session": "new" if first else "resumed", "verdicts": verdicts}, ensure_ascii=False, indent=1) + "\n"
open(vp, "w", encoding="utf-8").write(body)
os.chmod(vp, 0o444)
print(json.dumps({"label": label, "kind": kind, "set": s, "session": "new" if first else "resumed", "keys": len(verdicts), "undecided": sum(1 for v in verdicts for f in want[v["key"]] if v[f] == "undecided"), "sha256": hashlib.sha256(body.encode()).hexdigest()}))
