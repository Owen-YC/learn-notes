#!/bin/bash
# learn-notes 1.12.0 G3 (batch 3; from batch 2's stage.sh): one model-stage of the round, haiku only, run DETACHED (plan
# runnerRules), e.g.  ONLY_WORKFLOW=1 setsid nohup bash tools/stage.sh quiz-P haiku > stage/quiz-P.log 2>&1 < /dev/null &
# Stages and their frozen lines (each refused without its D34 file showing every compared request the same; a quiz
# stage's lines are those built for the UTC day it starts on, frozen/ or frozen/day-<day>/, see below):
#   quiz-P   frozen/lines-P.jsonl (S-A1, 18 quizzes)          D34 frozen/d34/P/compare.json (same = of = 18)
#   quiz-Q   frozen/lines-Q.jsonl (S-A2, 18; only after judge/sa2.json says run: Q1 of S-A1 is 27 or 28)   frozen/d34/Q
#   quiz-U   frozen/lines-U.jsonl (the U quiz, only when build.mjs made one)                                 frozen/d34/U
#   grade1-P · grade2-P · grade1-Q · grade2-Q   grade/<set>/lines-<k>.jsonl (grade.mjs; 1 = first try and after the
#            hint, 2 = after the nudge)                         D34 grade/<set>/d34-<k>/compare.json (same = of >= 1)
# sonnet is not measured for G3 in 1.12.0 (refused). Refuses a stage whose STARTED exists (cut-stage rule: the main loop
# decides). Before: an 'ok' session (probe/precheck.sh) = the before record and the usage gate (tools/gate.py pre):
# record differs -> exit 3 (STOP, not called); gate fails -> exit 7 (WAIT, its resetsAt printed; no STARTED written, may
# run again later); no ONLY_WORKFLOW=1 -> exit 2. Then STARTED (UTC, request file sha256), attempt 1 (probe session
# call-1: each call's status line in call-1/status.jsonl), then the G's api-error rule (stance Q2 · G-5): a call whose
# reply is an api-error (the error before an answer, any status) is sent again once, its frozen line as it is (call-2;
# nothing else is ever sent again: an empty reply, a timeout, a cap hit stay as they are); the after record (exit 4 VOID
# when it differs). A call that threw (the engine refused before sending) -> exit 5 (M-4 line 4). Then M-4's 10% rule
# on each request's final status: api-errors left above 10% of the stage's requests -> exit 6 (void, nothing opened);
# api-errors left at or under 10% count as empty replies (stance Q2: '다시도 api-error면 빈 답'). DONE, exit 0.
# Only status is printed; never an answer's text. Every claude process goes through cli/pinned.sh.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3
P=${PINNED:-/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh}
ST="$1"; M="$2"
[ "$M" = haiku ] || { echo "refuse: only haiku is measured for G3 in 1.12.0"; exit 2; }
# The scene day is the measuring day: a quiz stage takes the lines built for the UTC day it starts on (frozen/ when
# build.json's day is today, else frozen/day-<today>/ with its own D34; none -> refuse: rebuild first, nothing sent).
TODAY="${STAGE_TODAY:-$(date -u +%F)}"
BDAY=$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["day"])' "${S:?}/frozen/build.json" 2>/dev/null)
if [ "$BDAY" = "$TODAY" ]; then FD="${S:?}/frozen"; else FD="${S:?}/frozen/day-$TODAY"; fi
case "$ST" in
  quiz-P) LINES="$FD/lines-P.jsonl"; CMP="$FD/d34/P/compare.json"; KIND=quiz ;;
  quiz-Q) LINES="$FD/lines-Q.jsonl"; CMP="$FD/d34/Q/compare.json"; KIND=quiz
          grep -q '"run": true' "${S:?}/judge/sa2.json" 2>/dev/null || { echo "refuse: judge/sa2.json does not say run (S-A2 only for Q1 27 or 28)"; exit 2; } ;;
  quiz-U) LINES="$FD/lines-U.jsonl"; CMP="$FD/d34/U/compare.json"; KIND=quiz ;;
  grade1-P|grade2-P|grade1-Q|grade2-Q) SET="${ST#*-}"; K="${ST%%-*}"; K="${K#grade}"
          LINES="${S:?}/grade/$SET/lines-$K.jsonl"; CMP="${S:?}/grade/$SET/d34-$K/compare.json"; KIND=grade ;;
  *) echo "usage: stage.sh <quiz-P|quiz-Q|quiz-U|grade1-P|grade2-P|grade1-Q|grade2-Q> haiku"; exit 2 ;;
esac
D="${S:?}/stage/$ST/$M"
[ -e "$D/STARTED" ] && { echo "refuse: $D/STARTED exists (cut-stage rule: report to the main loop)"; exit 1; }
[ -s "$LINES" ] || { echo "no frozen lines: $LINES (a quiz stage on $TODAY needs lines built for $TODAY: build.mjs frozen frozen/day-$TODAY $TODAY, then its D34)"; exit 2; }
[ "$(stat -c %a "$LINES")" = 444 ] || { echo "refuse: $LINES is not frozen (chmod 444)"; exit 2; }
NL=$(grep -c . "$LINES")
python3 -I - "$CMP" "$KIND" "$NL" <<'PY' || { echo "refuse: no D34 for this stage ($CMP)"; exit 2; }
import json, sys
p, kind, n = sys.argv[1], sys.argv[2], int(sys.argv[3])
try:
    c = json.load(open(p, encoding="utf-8"))
except Exception:
    sys.exit(1)
ok = c.get("same") == c.get("of") and (c.get("of") == n if kind == "quiz" else c.get("of", 0) >= 1)
sys.exit(0 if ok else 1)
PY
mkdir -p "$D"
N=$(ls -d "$D"/pre-*/ 2>/dev/null | wc -l); PRE="$D/pre-$((N + 1))"
"$P" --record > "$PRE.pin.txt" 2>&1
"$P" bash "${S:?}/probe/precheck.sh" "$PRE" "$M" || { echo "precheck failed to run"; exit 3; }
python3 -I "${S:?}/tools/gate.py" pre "$PRE" "$M" "$ST" "$PRE.pin.txt"; rc=$?
[ $rc -eq 3 ] && { echo "STOP: the before record differs from the 1.12.0 calibration: not called"; exit 3; }
[ $rc -eq 7 ] && { echo "WAIT: usage gate failed: not started"; exit 7; }
[ $rc -eq 9 ] && { echo "not started: no statement that no other workflow runs (ONLY_WORKFLOW=1)"; exit 2; }
[ $rc -ne 0 ] && { echo "gate error $rc"; exit 3; }
{ date -u +%FT%TZ; sha256sum "$LINES"; echo "gate $PRE/gate.json"; } > "$D/STARTED"
"$P" --record > "$D/pin-before.txt" 2>&1
threw() { grep -q '"reason": *"threw"' "$1/status.jsonl" 2>/dev/null; }
CUR="$LINES"
for A in 1 2; do
  "$P" bash "${S:?}/probe/call.sh" "$D/call-$A" "$M" "$CUR"
  [ -f "$D/call-$A/out.json" ] || { echo "CUT: no call-$A out.json"; "$P" --record > "$D/pin-after.txt" 2>&1; exit 9; }
  threw "$D/call-$A" && { echo "THREW: the engine refused before sending (M-4 line 4)"; exit 5; }
  chmod 444 "$D/call-$A/out.json"
  [ $A -eq 2 ] && break
  python3 -I - "$D/call-$A/out.json" "$LINES" "$D/again-2.jsonl" <<'PY'
import json, sys
out, lines_p, nxt = sys.argv[1:4]
lines = {json.loads(x)["id"]: x for x in open(lines_p, encoding="utf-8") if x.strip()}
again = [lines[r["id"]].rstrip("\n") for r in json.load(open(out, encoding="utf-8"))["results"] if not r.get("isAnswered") and r.get("reason") == "api-error"]
if again:
    open(nxt, "w", encoding="utf-8").write("\n".join(again) + "\n")
print(f"api-errors to send again: {len(again)}")
PY
  [ -s "$D/again-2.jsonl" ] || break
  CUR="$D/again-2.jsonl"
done
"$P" --record > "$D/pin-after.txt" 2>&1
python3 -I "${S:?}/tools/gate.py" after "$D" "$M" "$D/pin-after.txt"; after=$?
python3 -I - "$D" "$LINES" <<'PY'
import hashlib, json, os, sys
d, lines_p = sys.argv[1:3]
ids = [json.loads(x)["id"] for x in open(lines_p, encoding="utf-8") if x.strip()]
final, summ = {}, {"attempts": [], "sha256": {}}
for a in (1, 2):
    p = f"{d}/call-{a}/out.json"
    if not os.path.exists(p):
        continue
    summ["sha256"][f"call-{a}"] = hashlib.sha256(open(p, "rb").read()).hexdigest()
    rs = json.load(open(p, encoding="utf-8"))["results"]
    summ["attempts"].append({"attempt": a, "calls": len(rs)})
    for r in rs:
        how = "answered" if r.get("isAnswered") else r.get("reason")
        if how == "api-error":
            how += f"/{r.get('status')}"
        final[r["id"]] = {"attempt": a, "how": how}
for i in ids:
    final.setdefault(i, {"attempt": None, "how": "no-status"})
counts = {}
for v in final.values():
    counts[v["how"]] = counts.get(v["how"], 0) + 1
api = sum(n for k, n in counts.items() if k.startswith("api-error") or k == "no-status")
summ.update({"requests": len(ids), "final": final, "counts": counts, "apiErrorsLeft": api, "void10": api * 10 > len(ids)})
open(f"{d}/summary.json", "w").write(json.dumps(summ, indent=1) + "\n")
print(json.dumps({k: summ[k] for k in ("requests", "counts", "apiErrorsLeft", "void10", "sha256")}))
PY
[ $after -ne 0 ] && { echo "VOID: the after record differs (D19): this model's cell is off"; exit 4; }
grep -q '"void10": true' "$D/summary.json" && { echo "VOID: api-errors above 10% (M-4)"; exit 6; }
date -u +%FT%TZ > "$D/DONE"
echo "DONE $ST $M"
