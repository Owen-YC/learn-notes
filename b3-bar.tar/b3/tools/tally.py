"""learn-notes 1.12.0 G3 (batch 3): the counts of the bar for one label, from frozen files only (eval, the judge's
verdicts, the machine counts, the frozen layout/check/build, the grade reads). Writes chmod 444 files, refusing existing.
usage: tally.py quiz <label> <P|Q>   -> judge/<L>/tally-quiz-<set>.json, and judge/<L>/grading.json once grading is
                                       decided (P: Q1 >= 29 or <= 26 or Q2/Q3 failing; Q: always)
       tally.py grade <label>        -> judge/<L>/tally-grade.json
Q1 (stance 0, 1-7): the set's 30 measured slots = each slot of an N quiz holding one of the set's measured records
   (layout), key '<quiz>#<place>'. A slot passes only if: check.py did not keep it failing; its quiz's final status is
   answered with no cap hit (Q2: an empty reply, a timeout or a cap hit misses every question of that quiz); eval found
   no miss (1, 2, 3(가)(나)(다), 5, 6, 7m); the judge said pass on 3(라), 4, 5's use and 7 (undecided, a missing verdict
   = miss). M1-M3 slots are records only.
Q2: over the set's 18 quiz calls (set P: and the U quiz when one is made): 0 empty replies (refusals arrive as empty replies; an api-error left after its one
   resend counts as an empty reply), 0 timeouts, 0 cap hits (output_tokens >= 6648).
Q3 (set P's tally; S-U does not depend on the set): per S-U record and shape (build.json q3): a non-new path when the
   committed rungOf gives no 'new', or when it gave 'new', the U quiz asked it, that quiz was answered with no cap hit and
   the plugin's reader refused its slot (stance Q3); a stored U item went to new (and must pass clause 5: eval 1/5 and
   the judge's 5 use; and not mimic); 'new' not asked (beyond the U quiz's three, or its second shape), or a U quiz that
   was empty, timed out, capped or failed: counted as reaching new (M-11); a record check.py found failing counts as
   reaching new. Each shape needs at least 8 of 9 non-new, 0 mimicking code, every stored U item passing clause 5.
Grading: P alone when Q1(P) >= 29 and Q2 and Q3; S-A2 first when Q1(P) is 27 or 28 (decide.py sa2), then both sets when
   Q1(P) + Q1(Q) >= 57 and Q2 holds for both; else skipped (the decision is already Infinity; C cells recorded as not
   run). Grading also needs at least 10 passing questions (else C1-C4 fail without grading).
C cells (stance G-1, G-4, G-5): misses by the verdict the plugin keeps; a path not answered (empty, timeout, api-error,
   missing), a cap hit (output_tokens >= 2528) or an unreadable reply is a miss in every cell. C1 first/right kept right;
   C2(a) first/wrongOne kept wrong; C3 first/wrongAll kept wrong; C2(b) hint/wrongOne kept wrong; C4(b) hint/again kept
   right; C4(a) nudge/again kept right (secondVerdict). Limits C1 1, C2(a) 3, C2(b) 3, C3 3, C4(a) 1, C4(b) 1, doubled
   for a cell whose graded count is 31-60 (a cell under 31 keeps the fixed count); a cell with nothing graded fails
   (M-11). An answer the judge left undecided (valid 'undecided', never called) is a miss in each cell it feeds (C1
   right; C2(a), C2(b) wrongOne; C3 wrongAll; C4(b) again, and C4(a) again where the first-try wrongOne was kept short of
   right with a kept nudge); an invalid answer is left out (G-2). L0: a valid wrongOne or wrongAll read right by
   localRight on any path: 0 allowed. A G-7 failure (grade/<set>/gw-fail.json) fails C1-C4."""
import json, os, statistics, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3"
J = os.environ.get("JUDGE", f"{S}/judge")
F = os.environ.get("FROZEN", f"{S}/frozen")
G = os.environ.get("GRADE", f"{S}/grade")


def load(p):
    return json.load(open(p, encoding="utf-8"))


def frozen(p):
    return os.path.exists(p) and os.stat(p).st_mode & 0o222 == 0


def write(p, obj):
    if os.path.exists(p):
        sys.exit(f"refuse: {p} exists")
    open(p, "w", encoding="utf-8").write(json.dumps(obj, ensure_ascii=False, indent=1) + "\n")
    os.chmod(p, 0o444)


def need(*ps):
    for p in ps:
        if not frozen(p):
            sys.exit(f"refuse: {p} is not there or not frozen")


def quiz(label, s):
    d = f"{J}/{label}"
    ev, vq, cnt = f"{d}/eval-{s}.json", f"{d}/verdicts-quiz-{s}.json", f"{J}/count-{label}-quiz-{s}.json"
    need(ev, vq, cnt)
    L, C, B = load(f"{F}/layout.json")[s], load(f"{F}/check.json"), load(f"{F}/build.json")
    rows = {r["key"]: r for r in load(ev)["rows"]}
    ver = {v["key"]: v for v in load(vq)["verdicts"]}
    by = load(cnt)["stages"][f"quiz-{s}"]["byId"]
    measured, failing = set(L["measured"]), set(L["keptFailing"])
    slots = []
    for q in L["quizzes"]:
        if "-N" not in q["id"]:
            continue
        st = by.get(q["id"], {"how": "no-status", "cap": False})
        for place, sl in enumerate(q["slots"], 1):
            if sl["id"] not in measured:
                continue
            key = f"{q['id']}#{place}"
            why = []
            if sl["id"] in failing:
                why.append("kept-failing")
            if st["how"] != "answered":
                why.append(f"Q2:{st['how']}")
            if st.get("cap"):
                why.append("Q2:cap")
            r = rows.get(key)
            if r is None:
                why.append("1:not new")
            else:
                why += r["miss"]
                v = ver.get(key)
                if "question" in r and "code" in r:
                    for f in ("c3ra", "c4", "c5use", "c7"):
                        if (v or {}).get(f) != "pass":
                            why.append(f"{f}:{(v or {}).get(f, 'missing')}")
            slots.append({"key": key, "id": sl["id"], "pass": not why, "why": why})
    q_ids = [q["id"] for q in L["quizzes"]]
    st_all = {i: by.get(i, {"how": "no-status", "cap": False}) for i in q_ids}
    q2 = {"calls": len(q_ids), "empty": sum(1 for v in st_all.values() if v["how"] in ("empty-reply",) or v["how"].startswith("api-error") or v["how"] == "no-status"),
          "timeouts": sum(1 for v in st_all.values() if v["how"] == "timeout"), "caps": sum(1 for v in st_all.values() if v.get("cap"))}
    if s == "P" and B.get("uquiz"):
        # the U quiz is a quiz call too: stance Q2's statuses fail Q2 for it as for any quiz (the stricter reading)
        cu = f"{J}/count-{label}-quiz-U.json"
        need(cu)
        u = load(cu)["stages"]["quiz-U"]["byId"].get(B["uquiz"]["id"], {"how": "no-status", "cap": False})
        q2["calls"] += 1
        q2["empty"] += u["how"] == "empty-reply" or u["how"].startswith("api-error") or u["how"] == "no-status"
        q2["timeouts"] += u["how"] == "timeout"
        q2["caps"] += bool(u.get("cap"))
    q2["pass"] = q2["empty"] == 0 and q2["timeouts"] == 0 and q2["caps"] == 0
    out = {"label": label, "set": s, "Q1": sum(1 for x in slots if x["pass"]), "of": len(slots), "passing": [x["key"] for x in slots if x["pass"]], "slots": slots, "Q2": q2}
    if s == "P":
        bad_u = {k for k, v in C["unrunnable"].items() if v}
        uq = B.get("uquiz")
        u_read, u_eval, u_ver, u_st = {}, {}, {}, {"how": "not asked", "cap": False}
        if uq:
            eu, vu, cu, ru = f"{d}/eval-U.json", f"{d}/verdicts-quiz-U.json", f"{J}/count-{label}-quiz-U.json", f"{d}/read-U.json"
            need(eu, vu, cu, ru)
            u_st = load(cu)["stages"]["quiz-U"]["byId"].get(uq["id"], {"how": "no-status", "cap": False})
            u_read = {(sl["id"], sl["shape"]): sl for q in load(ru)["quizzes"] for sl in q["slots"]}
            u_eval = {r["key"]: r for r in load(eu)["rows"]}
            u_ver = {v["key"]: v for v in load(vu)["verdicts"]}
        q3 = {"paths": []}
        stored, mimic, c5 = [], 0, 0
        for x in B["q3"]:
            path, why = "new", ""
            if x["id"] in bad_u:
                why = "failed its freeze check (no spare): counted as reaching new"
            elif x["rung"] != "new":
                path, why = "not new", f"rung {x['rung']}"
            else:
                sl = u_read.get((x["id"], x["shape"]))
                if sl is None:
                    why = "reached new, not asked (M-11: counted against)"
                elif u_st["how"] != "answered" or u_st.get("cap"):
                    why = f"U quiz {u_st['how']}{' cap' if u_st.get('cap') else ''} (M-11: counted against)"
                elif not sl["kept"]:
                    path, why = "not new", f"reader refused ({sl.get('reason')})"
                else:
                    key = f"{uq['id']}#{sl['place']}"
                    stored.append(key)
                    why = "stored: went to new"
                    r, v = u_eval.get(key, {"miss": ["missing"]}), u_ver.get(key, {})
                    mimic += v.get("mimic") != "pass"
                    c5 += ("5" in r["miss"]) or ("1" in r["miss"]) or v.get("c5use") != "pass"
            q3["paths"].append({"id": x["id"], "shape": x["shape"], "path": path, "why": why})
        for shape in ("edit", "create"):
            q3[shape] = sum(1 for p in q3["paths"] if p["shape"] == shape and p["path"] == "not new")
        q3.update({"storedU": stored, "mimicMisses": mimic, "clause5Misses": c5, "badRecords": sorted(bad_u)})
        q3["pass"] = q3["edit"] >= 8 and q3["create"] >= 8 and mimic == 0 and c5 == 0
        out["Q3"] = q3
        q1 = out["Q1"]
        if not (q2["pass"] and q3["pass"]):
            nxt, why = "skip", "Q2 or Q3 fails: Infinity already"
        elif q1 >= 29:
            nxt, why = ("grade", "Q1 >= 29") if q1 >= 10 else ("skip", "fewer than 10")
        elif q1 in (27, 28):
            nxt, why = "S-A2", "Q1 is 27 or 28"
        else:
            nxt, why = "skip", "Q1 <= 26: Infinity already"
        out["next"], out["nextWhy"] = nxt, why
        if nxt != "S-A2":
            write(f"{d}/grading.json", {"runs": nxt == "grade", "sets": ["P"] if nxt == "grade" else [], "why": why, "passing": q1})
    else:
        tp = f"{d}/tally-quiz-P.json"
        need(tp)
        P = load(tp)
        total = P["Q1"] + out["Q1"]
        ok = total >= 57 and P["Q2"]["pass"] and q2["pass"] and P["Q3"]["pass"]
        out["total"] = total
        out["next"], out["nextWhy"] = ("grade", "total >= 57") if ok else ("skip", "total < 57 or Q2/Q3 fails: Infinity already")
        write(f"{d}/grading.json", {"runs": ok, "sets": ["P", "Q"] if ok else [], "why": out["nextWhy"], "passing": total})
    write(f"{d}/tally-quiz-{s}.json", out)
    print(json.dumps({k: out[k] for k in ("set", "Q1", "of", "Q2", "next")} | ({"Q3": {k: v for k, v in out["Q3"].items() if k != "storedU"}} if "Q3" in out else {}), ensure_ascii=False))


LIMITS = {"C1": 1, "C2a": 3, "C2b": 3, "C3": 3, "C4a": 1, "C4b": 1}
CELL = {("first", "right"): ("C1", "right"), ("first", "wrongOne"): ("C2a", "wrong"), ("first", "wrongAll"): ("C3", "wrong"),
        ("hint", "wrongOne"): ("C2b", "wrong"), ("hint", "again"): ("C4b", "right"), ("nudge", "again"): ("C4a", "right")}


def grade(label):
    d = f"{J}/{label}"
    gp = f"{d}/grading.json"
    need(gp)
    gr = load(gp)
    out = {"label": label, "runs": gr["runs"], "sets": gr["sets"]}
    if not gr["runs"]:
        out.update({"cells": None, "why": gr["why"], "pass": False})
        write(f"{d}/tally-grade.json", out)
        print(json.dumps(out, ensure_ascii=False))
        return
    cells = {c: {"n": 0, "miss": 0, "misses": []} for c in LIMITS}
    l0, n_items, failed7, nudges_dropped, undecided = [], 0, [], 0, []
    for s in gr["sets"]:
        if os.path.exists(f"{G}/{s}/gw-fail.json"):
            failed7.append(s)
            continue
        need(f"{G}/{s}/items.json")
        items = load(f"{G}/{s}/items.json")
        n_items += len(items)
        s1 = {r["id"]: r for r in load(f"{G}/{s}/read-1.json")}
        # an answer the judge left undecided (never called): a miss in every cell it feeds (judge '판정이 빠지면 놓침')
        for it in items:
            v = it["valid"]
            feeds = {"right": ["C1"], "wrongOne": ["C2a", "C2b"], "wrongAll": ["C3"], "again": ["C4b"]}
            for kind, cs in feeds.items():
                if v.get(kind) == "undecided":
                    for c in cs:
                        cells[c]["n"] += 1
                        cells[c]["miss"] += 1
                        cells[c]["misses"].append({"id": f"{it['key']}|{kind}", "why": ["validity undecided"]})
                        undecided.append(f"{it['key']}|{kind}|{c}")
            one = s1.get(f"{it['key']}|first|wrongOne")
            if v.get("again") == "undecided" and v.get("wrongOne") is True and one and one.get("kept") not in (None, "right") and one.get("nudge"):
                cells["C4a"]["n"] += 1
                cells["C4a"]["miss"] += 1
                cells["C4a"]["misses"].append({"id": f"{it['key']}|again", "why": ["validity undecided"]})
                undecided.append(f"{it['key']}|again|C4a")
        for k in ("1", "2"):
            rp = f"{G}/{s}/read-{k}.json"
            if k == "2" and not os.path.exists(rp):
                continue
            need(rp)
            cp = f"{J}/count-{label}-grade{k}-{s}.json"
            by = load(cp)["stages"][f"grade{k}-{s}"]["byId"] if os.path.exists(cp) else {}
            for r in load(rp):
                cell, want = CELL[(r["path"], r["kind"])]
                c = cells[cell]
                c["n"] += 1
                miss = []
                if r["how"] not in ("answered", "local"):
                    miss.append(r["how"])
                elif r["how"] == "answered" and (by.get(r["id"]) or {}).get("cap"):
                    miss.append("cap")
                elif r.get("kept") is None and r.get("counted") is None:
                    miss.append("unread")
                else:
                    got = r["kept"] if r["path"] != "first" else r["counted"]
                    if got != want:
                        miss.append(f"kept {got}")
                if miss:
                    c["miss"] += 1
                    c["misses"].append({"id": r["id"], "why": miss})
                if r.get("local") and r["kind"] in ("wrongOne", "wrongAll"):
                    l0.append(r["id"])
        nudges_dropped += sum(1 for r in s1.values() if r["path"] == "first" and r["kind"] == "wrongOne" and r.get("kept") not in (None, "right") and not r.get("nudge"))
    for c, lim in LIMITS.items():
        x = cells[c]
        x["limit"] = lim * (2 if 31 <= x["n"] <= 60 else 1)
        x["doubled"] = 31 <= x["n"] <= 60
        x["pass"] = not failed7 and x["n"] > 0 and x["miss"] <= x["limit"]
        if x["n"] == 0:
            x["why"] = "no answer graded in this cell: a case the stance does not decide (M-11)"
    out.update({"items": n_items, "cells": cells, "L0": {"count": len(l0), "ids": l0, "pass": not l0}, "G7failed": failed7, "validityUndecided": undecided, "nudgesDroppedRecord": nudges_dropped})
    out["pass"] = all(cells[c]["pass"] for c in LIMITS) and not l0 and not failed7
    write(f"{d}/tally-grade.json", out)
    print(json.dumps({k: (v if k != "cells" else {c: (x["miss"], x["n"], x["limit"]) for c, x in v.items()}) for k, v in out.items()}, ensure_ascii=False))


if __name__ == "__main__":
    if sys.argv[1] == "quiz":
        quiz(sys.argv[2], sys.argv[3])
    elif sys.argv[1] == "grade":
        grade(sys.argv[2])
    else:
        sys.exit(__doc__)
