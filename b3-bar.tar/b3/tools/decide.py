"""learn-notes 1.12.0 G3 (batch 3): the decision rule (design decisionRule; plan batches[3].decision), from frozen tallies.
usage: decide.py sa2 <label>    after tally-quiz-P.json: judge/sa2.json {"run": true|false, "Q1": n} (chmod 444) — the
                                stage runner sends S-A2 (quiz-Q) only when it says run (Q1 of S-A1 is 27 or 28).
       decide.py final <label>  after every verdict file and tally of the round is frozen: opens the pair (label.py
                                open's rule) and writes judge/decision.json (chmod 444):
  haiku: rungNewStep = 4 iff Q1 ∧ Q2 ∧ Q3 ∧ C1 ∧ C2(a) ∧ C2(b) ∧ C3 ∧ C4(a) ∧ C4(b) ∧ L0, else Infinity. Q1: S-A1 >= 29,
  or with S-A2 measured the total of 60 >= 57; Q2 over every quiz call measured (18, or 36); Q3 from S-A1's tally; C cells
  and L0 from tally-grade.json (grading skipped or fewer than 10 passing: fail). sonnet: not measured (Infinity).
  RUNG_NEW_STEP stays Infinity."""
import hashlib, json, os, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3"
J = os.environ.get("JUDGE", f"{S}/judge")


def load(p):
    return json.load(open(p, encoding="utf-8"))


def frozen(p):
    return os.path.exists(p) and os.stat(p).st_mode & 0o222 == 0


def write(p, obj):
    if os.path.exists(p):
        sys.exit(f"refuse: {p} exists")
    body = json.dumps(obj, ensure_ascii=False, indent=1) + "\n"
    open(p, "w", encoding="utf-8").write(body)
    os.chmod(p, 0o444)
    return hashlib.sha256(body.encode()).hexdigest()


mode, label = sys.argv[1], sys.argv[2]
d = f"{J}/{label}"
if mode == "sa2":
    tp = f"{d}/tally-quiz-P.json"
    if not frozen(tp):
        sys.exit("refuse: tally-quiz-P.json not frozen")
    t = load(tp)
    print(write(f"{J}/sa2.json", {"run": t["next"] == "S-A2", "Q1": t["Q1"]}))
elif mode == "final":
    files = sorted(f for f in os.listdir(d) if f.startswith(("verdicts-", "tally-", "eval-", "read-")) or f == "grading.json")
    if not all(frozen(f"{d}/{f}") for f in files) or "tally-quiz-P.json" not in files or "tally-grade.json" not in files:
        sys.exit("refuse: not every verdict file and tally is frozen (or tally-grade.json is missing)")
    P = load(f"{d}/tally-quiz-P.json")
    Q = load(f"{d}/tally-quiz-Q.json") if os.path.exists(f"{d}/tally-quiz-Q.json") else None
    Gt = load(f"{d}/tally-grade.json")
    q1 = (Q["total"] >= 57) if Q else P["Q1"] >= 29
    q2 = P["Q2"]["pass"] and (Q["Q2"]["pass"] if Q else True)
    q3 = P["Q3"]["pass"]
    cells = {c: bool(Gt["cells"] and Gt["cells"][c]["pass"]) for c in ("C1", "C2a", "C2b", "C3", "C4a", "C4b")}
    l0 = bool(Gt.get("L0") and Gt["L0"]["pass"])
    ok = q1 and q2 and q3 and all(cells.values()) and l0 and Gt["pass"]
    pair = load(f"{J}/pair.json")
    model = pair.get(label)
    res = {"label": label, "model": model, "Q1": {"S-A1": P["Q1"], "S-A2": Q["Q1"] if Q else None, "total": Q["total"] if Q else None, "pass": q1},
           "Q2": {"pass": q2}, "Q3": {"pass": q3}, "C": cells, "L0": l0, "grading": {"runs": Gt["runs"], "items": Gt.get("items"), "cells": {c: {k: x[k] for k in ("n", "miss", "limit")} for c, x in (Gt.get("cells") or {}).items()}},
           "pass": ok, "MODEL_SWITCHES": {"haiku": {"rungNewStep": 4 if (ok and model == "haiku") else "Infinity"}, "sonnet": {"rungNewStep": "Infinity (not measured in 1.12.0)"}}, "RUNG_NEW_STEP": "Infinity"}
    print(write(f"{J}/decision.json", res))
    print(json.dumps(res, ensure_ascii=False))
else:
    sys.exit(__doc__)
