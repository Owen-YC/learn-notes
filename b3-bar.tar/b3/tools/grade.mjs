// learn-notes 1.12.0 G3 (batch 3): the grade stages (design calls, stance G-1 · G-4 · G-5 · G-6), from the design's
// final grade2.mjs, on the committed tree (b3/mtree = f03b362) as gradeTyped grades a prediction in code never seen
// with the rung on (isExact): localRight first (a no-call 맞음, NEW_LOCAL_RIGHT), else checkPrompt(item, mine,
// 'beginner', first, undefined, { exact: true }) with CHECK_SYSTEM, maxTokens 480, timeoutMs 60000, read by
// parseCheck(text, { exact: item.answer, mine }) (the probe already passed the reply through fixEscapedTicks).
// usage: node --experimental-transform-types grade.mjs lines <grade set dir> <1|2> [<stage-1 dir>]
//          stage 1 (paths first: right, wrongOne, wrongAll; hint: again, wrongOne with first = { mine: '모르겠어요',
//          verdict: 'wrong', feedback: '', nudge: item.hint }); stage 2 (nudge: again, for each item whose first-try
//          wrongOne was kept other than right and whose nudge keptNudge kept; first = { mine: that wrongOne, verdict: its
//          kept verdict, feedback, nudge }; needs read-1.json). Only answers valid under G-3 (items.json `valid`) are
//          planned. -> plan-<k>.json (every path, local ones marked) and lines-<k>.jsonl (the calls), chmod 444.
//        node --experimental-transform-types grade.mjs read <grade set dir> <1|2> <stage dir>
//          -> read-<k>.json (chmod 444): per planned path: expect (right for right · again, wrong for wrongOne ·
//          wrongAll), local (localRight), how (answered · empty-reply · timeout · api-error/… · threw · missing),
//          counted (the verdict valuesVerdict gave: parseCheck's), kept (what gradeTyped keeps: a first try's or an
//          answer after 모르겠어요 as graded, an answer after a nudge secondVerdict(first.verdict, graded)), nudge
//          (keptNudge, first try short of right), feedback, unguarded (parseCheck without mine, record), copied (값 lines,
//          record), notSaid (a NEW_NOT_SAID mark copied, record), firstId. No output_tokens or time (count.py has them;
//          tally.py joins its caps). Also <stage dir>/unread-ids.json: answered replies the reader could not read
//          (tapsend.py takes those under the cap as cut; it has the tokens).
import { readFileSync, writeFileSync, existsSync, chmodSync } from 'node:fs'
import { join } from 'node:path'

const P = await import(process.env.NOTES ?? '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3/mtree/hooks/notes.ts')
const [cmd, dir, k, stageDir] = process.argv.slice(2)
const items = JSON.parse(readFileSync(join(dir, 'items.json'), 'utf8'))
const byKey = Object.fromEntries(items.map(w => [w.key, w]))
const said = mine => (mine.length > 1500 ? mine.slice(0, 1500) : mine)
const writeOnce = (f, body) => {
  if (existsSync(f)) { console.log(`refuse: ${f} exists`); process.exit(1) }
  writeFileSync(f, body)
  chmodSync(f, 0o444)
}

if (cmd === 'lines') {
  const plan = []
  for (const w of items) {
    const ok = kind => w.valid?.[kind] === true
    if (k === '1') {
      for (const kind of ['right', 'wrongOne', 'wrongAll']) if (ok(kind)) plan.push({ id: `${w.key}|first|${kind}`, key: w.key, path: 'first', kind, mine: w[kind] })
      const hint = { mine: '모르겠어요', verdict: 'wrong', feedback: '', nudge: w.item.hint }
      for (const kind of ['again', 'wrongOne']) if (ok(kind)) plan.push({ id: `${w.key}|hint|${kind}`, key: w.key, path: 'hint', kind, mine: w[kind], first: hint })
    } else {
      const s1 = Object.fromEntries(JSON.parse(readFileSync(join(dir, 'read-1.json'), 'utf8')).map(x => [x.id, x]))
      const one = s1[`${w.key}|first|wrongOne`]
      if (!one || !ok('again') || one.kept === undefined || one.kept === 'right' || !one.nudge) continue
      plan.push({ id: `${w.key}|nudge|again`, key: w.key, path: 'nudge', kind: 'again', mine: w.again, firstId: one.id, first: { mine: said(w.wrongOne), verdict: one.kept, feedback: one.feedback ?? '', nudge: one.nudge } })
    }
  }
  const lines = []
  for (const p of plan) {
    const item = byKey[p.key].item
    p.local = P.localRight(p.mine, item.answer)
    if (p.local) continue
    p.prompt = P.checkPrompt(item, p.mine, 'beginner', p.first, undefined, { exact: true })
    lines.push(JSON.stringify({ id: p.id, model: 'haiku', system: P.CHECK_SYSTEM, prompt: p.prompt, maxTokens: 480, timeoutMs: 60000 }))
  }
  writeOnce(join(dir, `plan-${k}.json`), JSON.stringify(plan, null, 1) + '\n')
  writeOnce(join(dir, `lines-${k}.jsonl`), lines.join('\n') + (lines.length ? '\n' : ''))
  console.log(`stage ${k}: paths ${plan.length}, local ${plan.filter(p => p.local).length}, calls ${lines.length}`)
} else if (cmd === 'read') {
  const plan = JSON.parse(readFileSync(join(dir, `plan-${k}.json`), 'utf8'))
  const res = {}
  for (const a of [1, 2]) {
    const f = join(stageDir, `call-${a}`, 'out.json')
    if (existsSync(f)) for (const r of JSON.parse(readFileSync(f, 'utf8')).results) res[r.id] = r
  }
  const unread = []
  const rows = plan.map(p => {
    const item = byKey[p.key].item
    const expect = p.kind === 'right' || p.kind === 'again' ? 'right' : 'wrong'
    const second = p.first && !P.isBlankAnswer(p.first.mine)
    const base = { id: p.id, key: p.key, path: p.path, kind: p.kind, expect, ...(p.firstId ? { firstId: p.firstId } : {}) }
    if (p.local) return { ...base, local: true, how: 'local', counted: 'right', kept: second ? P.secondVerdict(p.first.verdict, 'right') : 'right' }
    const r = res[p.id]
    const how = !r ? 'missing' : r.threw !== undefined ? 'threw' : r.isAnswered ? 'answered' : r.reason === 'api-error' ? `api-error/${r.status}` : r.reason
    if (how !== 'answered') return { ...base, local: false, how }
    const g = P.parseCheck(r.text, { exact: item.answer, mine: p.mine })
    if (!g) unread.push(p.id)
    const unguarded = P.parseCheck(r.text, { exact: item.answer })?.verdict
    const kept = g ? (second ? P.secondVerdict(p.first.verdict, g.verdict) : g.verdict) : undefined
    const nudge = g && !p.first && g.verdict !== 'right' ? P.keptNudge(g.nudge, item.answer) : undefined
    const copied = [...r.text.matchAll(/^\s*(?:\*\*)?값\s*(\d+|더)(?:\*\*)?\s*[:：]\s*(.*)$/gm)].map(m => [m[1], m[2].trim()])
    return { ...base, local: false, how, counted: g?.verdict, kept, nudge, feedback: g?.feedback, unguarded, copied, notSaid: copied.some(c => c[1].includes('말하지 않음')) }
  })
  writeOnce(join(dir, `read-${k}.json`), JSON.stringify(rows, null, 1) + '\n')
  const uf = join(stageDir, 'unread-ids.json')
  if (!existsSync(uf)) { writeFileSync(uf, JSON.stringify(unread) + '\n'); chmodSync(uf, 0o444) }
  console.log(`read stage ${k}: ${rows.length} paths, local ${rows.filter(x => x.local).length}, answered ${rows.filter(x => x.how === 'answered').length}, unread ${unread.length}`)
} else {
  console.log('usage: grade.mjs lines <dir> <1|2> | read <dir> <1|2> <stage dir>')
  process.exit(2)
}
