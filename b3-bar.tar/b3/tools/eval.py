"""learn-notes 1.12.0 G3 (batch 3): the eval tool, the stance's ⚙ clauses on one label's read file (from the design
pilot's judge.py, rebuilt on runlib.py), and the judge's report.
usage: eval.py <label dir> <set: P|Q|U> <frozen dir>   -> <label dir>/eval-<set>.json and report-<set>.md (chmod 444,
       refusing existing files). No output_tokens, time or cap anywhere (blinding, M-8); the quiz statuses come from
       the read file ('how').
Per 'new' slot of each quiz (key '<quiz>#<place>'; measured = an N quiz's slot of the set's 30 measured records; M and U
slots are records for Q1, U slots count for Q3):
 1 ⚙  an item is stored for the slot with rung new, kind predict and question, hint and answer all there; else miss 1
      (the reader's reason recorded: missing · long · print-place · … · the quiz's how when it gave no text).
 2 ⚙  the question holds exactly one fenced block, at most 8 lines in it that are not blank, its name in the asked
      language's group (js = js javascript mjs cjs node, py = py python python3; the asked language from the record's
      file); else miss 2.
 3 ⚙  (가) (나) (다) of the shown code against the record's code (runlib.clause3); a hit is miss 3<가|나|다>. (라) is the
      judge's.
 5 ⚙  the shown code run as shown (runlib.run): exit 0, the runs agree, at most 3 lines of at most 40 code points
      (runlib.ok5); else miss 5. Forbidden words found by grep (runlib.forbidden) go to the judge, who says whether each
      is a use (a use is miss 5).
 6 ⚙  the stored answer against the run's lines (runlib.same6); a run that does not exit 0 misses 6 too.
 7 ⚙  a run line's value as a word in the hint or in the question outside its fence while not a literal of the code
      (runlib.clause7m): miss 7m. The rest of 7 is the judge's.
A stored U item (Q3) is evaluated the same way; clause 5 is what Q3 asks of it, with the judge's mimic verdict.
The report gives the judge, per stored new item, only: the key, the concept's name, blurb and code (the learner's),
the question as stored, the hint, the answer, the run's lines (or the run's failure), and the grep hits."""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import runlib  # noqa: E402


def main():
    ldir, s, frozen = sys.argv[1:4]
    out_e, out_r = f"{ldir}/eval-{s}.json", f"{ldir}/report-{s}.md"
    for f in (out_e, out_r):
        if os.path.exists(f):
            sys.exit(f"refuse: {f} exists")
    rd = json.load(open(f"{ldir}/read-{s}.json", encoding="utf-8"))
    Sm = json.load(open(f"{frozen}/samples.json", encoding="utf-8"))
    L = json.load(open(f"{frozen}/layout.json", encoding="utf-8"))
    recs = {**Sm["sets"]["P"], **Sm["sets"]["Q"], **{r["id"]: r for r in Sm["unrunnable"]}}
    measured = set(L[s]["measured"]) if s in L else set()
    rows, report = [], []
    for q in rd["quizzes"]:
        isN = "-N" in q["id"]
        for sl in q["slots"]:
            if sl["rung"] != "new":
                continue
            rec = recs[sl["id"]]
            lang = runlib.lang_of_file(rec["file"])
            row = {"key": f"{q['id']}#{sl['place']}", "quiz": q["id"], "id": sl["id"], "how": q["how"], "measured": isN and sl["id"] in measured, "u": s == "U", "reason": sl.get("reason"), "miss": []}
            it = sl.get("item")
            if not it or it.get("rung") != "new" or it.get("kind") != "predict" or not all(it.get(k) for k in ("question", "hint", "answer")):
                row["miss"].append("1")
                rows.append(row)
                continue
            fs = runlib.fence(it["question"])
            if len(fs) != 1:
                row["miss"].append("2")
                row.update({"question": it["question"], "hint": it["hint"], "answer": it["answer"]})
                rows.append(row)
                continue
            name, code = fs[0]
            if len([l for l in code.split("\n") if l.strip()]) > 8 or name not in runlib.GROUP[lang]:
                row["miss"].append("2")
            src = rec.get("code") or rec.get("lines")
            c3 = runlib.clause3(code, src, lang)
            if c3:
                row["miss"].append("3" + c3)
            run = runlib.run(code, lang)
            if not runlib.ok5(run):
                row["miss"].append("5")
            if not (run["rc"] == 0 and runlib.same6(it["answer"], run)):
                row["miss"].append("6")
            prose = it["hint"] + "\n" + it["question"].split("```")[0].split("~~~")[0]
            hits7 = runlib.clause7m(prose, code, run["lines"])
            if hits7:
                row["miss"].append("7m")
            row.update({"question": it["question"], "hint": it["hint"], "answer": it["answer"], "code": code, "lang": lang, "run": {"rc": run["rc"], "agree": run["agree"], "lines": run["lines"], "timeout": run["timeout"], "tail": run["stderrTail"] if run["rc"] else ""}, "forbiddenWords": runlib.forbidden(code, lang), "hits7": hits7})
            rows.append(row)
            runtext = "\n".join(run["lines"]) if run["rc"] == 0 else f"(끝 코드 {run['rc']}{', 5초 넘음' if run['timeout'] else ''}; 찍힌 줄: {json.dumps(run['lines'], ensure_ascii=False)})"
            report.append("\n".join([
                f"### {row['key']}",
                f"- 개념 이름: {rec['name']}",
                f"- 개념 견본 blurb: {rec['blurb']}",
                "- 개념 견본 code (학습자 코드):", "```", src.rstrip("\n"), "```",
                "- 저장된 question (학습자에게 보인 글 그대로):", "````", it["question"], "````",
                f"- 저장된 hint: {it['hint']}",
                "- 저장된 answer:", "```", it["answer"], "```",
                "- 보인 그대로 돌린 출력(stdout 줄):", "```", runtext, "```",
                f"- grep에 걸린 금지 낱말: {', '.join(row['forbiddenWords']) if row['forbiddenWords'] else '없음'}",
                f"- 판정할 것: {'Q3 U 항목(흉내 코드 여부와 5의 쓰임)' if row['u'] else '3 (라) · 4 · 5의 쓰임 · 7의 나머지'}",
            ]))
    json.dump({"set": s, "rows": rows}, open(out_e, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    open(out_r, "w", encoding="utf-8").write(f"# 판정 자료 (꼬리표 {os.path.basename(ldir)}, 묶음 {s})\n\n저장된 처음 보는 코드 문항 {len(report)}개.\n\n" + "\n\n".join(report) + "\n")
    for f in (out_e, out_r):
        os.chmod(f, 0o444)
    meas = [r for r in rows if r["measured"]]
    print(json.dumps({"set": s, "newSlots": len(rows), "measured": len(meas), "machinePass": sum(1 for r in meas if not r["miss"]), "stored": len(report), "misses": {r["key"]: r["miss"] for r in rows if r["miss"]}}, ensure_ascii=False))


if __name__ == "__main__":
    main()
