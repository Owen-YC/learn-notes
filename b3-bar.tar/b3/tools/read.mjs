// learn-notes 1.12.0 G3 (batch 3): stance 1, the plugin's own reading of a quiz stage's final replies. Each quiz's final
// reply is its last attempt's (stage.sh: only an api-error is sent again, once); the probe already passed it through
// fixEscapedTicks; parseQuiz(text, picks) of the committed tree (b3/mtree, the picks from frozen/build.json) gives the
// items a learner would get. Per slot: kept (an item with that pick's key) and the item; per 'new' slot, for the record
// only, newItem's reason over the parts parseQuiz reads (b3/jtree: mtree's notes.ts with quizParts exported, nothing else
// changed; markers QHATRKL, lastWins KLA, fence-aware) — 'ok' when an item was made.
// Per quiz: how (answered · empty-reply · timeout · api-error/<status> · threw · missing). No output_tokens, time or cap
// in the label's file (blinding, M-8). The cut ids (an answered reply with a 'new' slot or any slot left without an item
// while output_tokens < 4600 + 2048 = 6648; design calls.tap) go to <stage>/cut-ids.json beside the stage, for
// tapsend.py alone.
// usage: node --experimental-transform-types read.mjs <stage dir> <frozen dir> <set: P|Q|U> <out.json>   (refuses an existing out)
import { readFileSync, writeFileSync, existsSync, chmodSync } from 'node:fs'
import { join } from 'node:path'

const [stage, frozen, set, out] = process.argv.slice(2)
if (existsSync(out)) { console.log(`refuse: ${out} exists`); process.exit(1) }
const M = await import(process.env.NOTES ?? '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3/mtree/hooks/notes.ts')
const J = await import(process.env.JNOTES ?? '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3/jtree/hooks/notes.ts')
const CAP = 4600 + 2048
// The build the stage sent (the folder of the lines file STARTED names: frozen/ or frozen/day-<day>/).
const started = existsSync(join(stage, 'STARTED')) ? readFileSync(join(stage, 'STARTED'), 'utf8').split('\n')[1]?.split(/\s+/)[1] : undefined
const bdir = started ? started.replace(/\/[^/]+$/, '') : frozen
const B = JSON.parse(readFileSync(join(bdir, 'build.json'), 'utf8'))
const list = set === 'U' ? (B.uquiz ? [B.uquiz] : []) : B.sets[set]
const final = new Map()
for (const a of [1, 2]) {
  const p = join(stage, `call-${a}`, 'out.json')
  if (!existsSync(p)) continue
  for (const r of JSON.parse(readFileSync(p, 'utf8')).results) final.set(r.id, r)
}
const cut = []
const quizzes = list.map(q => {
  const r = final.get(q.id)
  const how = !r ? 'missing' : r.threw !== undefined ? 'threw' : r.isAnswered ? 'answered' : r.reason === 'api-error' ? `api-error/${r.status}` : r.reason
  const text = r && r.isAnswered ? r.text : ''
  const items = text ? M.parseQuiz(text, q.picks) : []
  const parts = text ? J.quizParts(text, true, 'QHATRKL', 'KLA') : new Map()
  const slots = q.picks.map((pick, i) => {
    const item = items.find(it => it.key === pick.key) ?? null
    const slot = { place: i + 1, id: q.slots[i].id, shape: q.slots[i].shape ?? 'create', rung: pick.rung ?? null, lang: pick.lang ?? null, kept: !!item, item }
    if (pick.rung === 'new') {
      const made = text ? J.newItem(parts, i + 1, pick) : { reason: how }
      slot.reason = 'item' in made ? 'ok' : made.reason
    }
    return slot
  })
  if (r && r.isAnswered && slots.some(s => !s.kept) && (r.usage?.output_tokens ?? 0) < CAP) cut.push(q.id)
  return { id: q.id, how, slots }
})
const body = JSON.stringify({ set, quizzes }, null, 1) + '\n'
writeFileSync(out, body)
chmodSync(out, 0o444)
const cutFile = join(stage, 'cut-ids.json')
if (!existsSync(cutFile)) { writeFileSync(cutFile, JSON.stringify(cut) + '\n'); chmodSync(cutFile, 0o444) }
for (const q of quizzes) console.log(q.id, q.how, q.slots.map(s => `${s.rung ?? '-'}:${s.rung === 'new' ? s.reason : s.kept ? 'kept' : 'none'}`).join(' '))
console.log('cut', cut.length)
