너는 번역 확인자다. 아래 '원문'(영어 설계 필드와 계획 글; 입장 stance는 원문도 한국어)과, 그것을 한국어로 옮긴 '옮긴 절'을 견준다. 도구는 없다. 도구 호출을 쓰지 말고 바로 답한다.

확인할 것:
1. 옮긴 절의 '설계 bar(옮김)', '설계 decisionRule(옮김)', '모델마다', '설계 samples 글(옮김)', '설계 calls 글(옮김)', '설계 risks(옮김)'와 '계획 묶음 3의 글'들이 원문의 모든 수와 조항을 빠짐없이, 바꾸지 않고 옮겼는가. 빠진 줄, 바뀐 수, 더해진 조건, 느슨해지거나 엄격해진 뜻을 모두 적는다.
2. '판정의 입장'이 원문 stance를 글자 그대로 옮겼는가(머리말, 모든 조항, 경계 사례 모두). 다른 글자가 있으면 적는다.
3. 옮긴 절이 Q2의 셈을 '36 호출 모두'(S-A2를 18 프롬프트 짜임 전체로) 하나로만 읽고, 다른 읽기를 담지 않는가.
4. '(이 묶음의 기록, 원문 밖)'처럼 표시된 글은 원문에 없어도 된다. 표시 없이 원문에 없는 뜻이 옮긴 글 안에 들어가 있으면 적는다. '읽는 법'과 '도구가 글을 읽는 방식'은 이 절이 더한 글이다: 그 글이 원문의 어느 조항을 바꾸거나 느슨하게 하는지만 본다.

답의 꼴: 번호 매긴 목록. 항목마다 (어디) (원문) (옮긴 글) (무엇이 다른가). 다른 것이 없으면 '다름 없음'이라고만 쓴다.

# 원문
{
 "design": {
  "name": "처음 보는 코드 (rungNewStep) — G3-KLA final: 모델은 코드(K) · 눈여겨볼 줄(L) · 찍히는 글자(A)만 쓰고, 플러그인이 확인해 문제를 짓고, 채점은 값만 옮겨 플러그인이 정한다",
  "bar": [
   "Unchanged from the last committed bar in every number and clause: docs/qa/견본.md '1.10.0 처음 보는 코드 (G3)' > '기준 · 입장 · 결정 규칙' (888113d, built code 17c10c4), inheriting 1.9.0 F3 and governed by the G7 common stance M-0..M-15, B-1..B-15, R0..R11. Nothing laxer.",
   "Q1: 30 questions in code never seen (the 30 measured new slots of the 15 quizzes), each meeting all seven clauses of the stance. 29 or more pass; 26 or fewer fail; 27 or 28 → the pre-frozen second set S-A2 of 30 is measured (one more round of the same 18-prompt layout on S-A2, quiz and grading) and the total must reach 57/60. Only questions verified by running count. A slot with no stored item (empty reply, cut, refused by the reader) is a miss.",
   "Q2: 0 cap hits (output_tokens ≥ 4600 + H_M), 0 empty replies (a refusal is an empty reply) and 0 timeouts (90 s) over the 15 quizzes plus M1, M2 and M3 (30 + 3 if the second set runs). Any one fails Q2 and misses every question of that quiz.",
   "Q3: the 9 U concepts, each in the edit shape and the new-file shape: at least 8 of 9 take a non-new path in each shape; 0 library-mimicking code; any question in code never seen actually stored must pass clause 5.",
   "C1: first-try right answers → 맞음: at most 1 miss (at most 2 if 31-60 graded).",
   "C2 (a): one-value-wrong answers at the first try → 틀림: at most 3 misses (6 if 31-60). C2 (b): the same after 모르겠어요 + hint: at most 3 (6).",
   "C3: all-wrong answers at the first try → 틀림: at most 3 misses (6).",
   "C4 (a): the re-submitted right answer after the nudge → 맞음: at most 1 miss (2). C4 (b): after the hint: at most 1 (2). A set smaller than 30 keeps the fixed counts (C1/C4: 1, C2/C3: 3).",
   "Grading prerequisite: grading answers are written only if at least 10 questions passed all seven clauses; with fewer, C1-C4 fail.",
   "NEW, stricter — L0: 0 validated wrongOne or wrongAll answers, at the first try or on either try-again path, graded 맞음 locally (localRight). A single one fails the model. localRight's closed lists (SAID_TAIL, SAID_HEAD, SAID_SPLIT, SAID_FILLER) are frozen by sha256 in the bar commit.",
   "Counting word for C1-C4 (committed in advance, argued not laxer in stance G-1): the verdict the plugin keeps — localRight's 맞음 (no model text), or valuesVerdict from the 값 lines with the value guard. An unreadable (a 값 line missing), empty, timed-out or capped grade reply is a miss in every cell, C2/C3 included.",
   "Grading cap hit = output_tokens ≥ 480 + H_M; a miss.",
   "Writer-reply rule: a grading-answer writer reply that does not hold exactly one ```json block is re-called once with the same prompt; if the second still does not, that label's C1-C4 fail. The session never chooses a block. Tap and resend file names carry labels, never model names.",
   "Decision rule (per model): MODEL_SWITCHES[model].rungNewStep = 4 iff Q1 ∧ Q2 ∧ Q3 ∧ C1 ∧ C2(a) ∧ C2(b) ∧ C3 ∧ C4(a) ∧ C4(b) ∧ L0; otherwise Infinity. RUNG_NEW_STEP stays Infinity. One round per model, no re-measure, no transfer between models. An undecided case is a miss (M-11). One judge per label; a judge error or missing verdict is a miss.",
   "Cap thresholds are written as numbers (4600 + H_M, 480 + H_M) only after the 1.12.0 calibration; a version or alias mismatch before or after the round voids it and the cell stays OFF (M-10, D19).",
   "Narrowed scope (no ts; no type-level, run-order or string-letter concepts; js/mjs/cjs/py only) is a general mechanism, not fitted to dev samples: under D33 (measured = enabled) the samples are drawn from the population the plugin asks, so every number keeps its meaning on that population. The U set is all js/mjs/cjs/py (js 5 · py 4), so dropping ts does not make Q3 trivially easier.",
   "Q2 gains M3 [new, new, new] (stricter): the plugin can produce this prompt branch (no non-new slot, no kinds block), so it is measured; M1-M3 questions are recorded only for Q1, as in 1.10.0.",
   "Record only (rule 5 of 1.10.0, plus): local-grade share; copy fidelity (copied vs written value per line); value-guard flips; reader drop reasons; plain-hint share; over-width code lines (> 48 cells) and hints; refused, empty and cut replies with the tap's stop_reason; scene skips; output-token and time median/max; NEW_NOT_SAID marks; feedback/verdict mismatches; nudges dropped by keptNudge."
  ],
  "stance": {
   "머리": "판정의 입장 (G3, 1.12.0 G3-KLA). 기준 · 결정 규칙 · 짜임 · 견본 쓰기 프롬프트와 함께, 견본을 쓰거나 부르기 전에 docs/qa/견본.md 새 절로 한 커밋에 넣습니다(UTC 시각, 가리키는 코드 커밋 해시). 매기는 쪽은 이 글의 조항만 따르고 판정마다 조항 번호를 적습니다. ⚙ 조항은 eval 도구(부르기 전에 sha256으로 얼림)가 세고, ✎ 조항만 매기는 하위 에이전트(꼬리표마다 한 명)가 매깁니다. 1.10.0의 일곱 조항 번호와 뜻을 그대로 두고, 이 설계에서 쓰이지 않는 갈래는 \"쓰이지 않음\"으로 적었습니다. 이 글이 정하지 않은 경우는 못 넘음입니다(M-11).",
   "0 셈의 단위": "Q1은 15퀴즈의 처음 보는 코드 자리 30개(둘째 묶음을 재면 60개)입니다. M1 · M2 · M3의 처음 보는 코드 자리는 Q1에 넣지 않고 기록만 하며 Q2에는 넣습니다. 같은 퀴즈의 내 코드 · 왜 · 다시 도전 문항은 셈 밖이고 기록만 합니다. Q3는 U 개념 아홉의 두 꼴(편집 · 새 파일)입니다.",
   "1 읽기 ⚙": "플러그인처럼 fixEscapedTicks → 그 커밋의 parseQuiz로 읽어 저장될 문항(question · hint · answer · kind · rung)만 매깁니다. 모델의 K · L · A 날글, 상황 줄, 되풀이해 쓴 앞의 K · L · A(나중 것이 읽힘), A 아래 빈 줄 뒤의 글은 저장되지 않으므로 판정 대상이 아닙니다. 1을 넘으려면 그 자리의 문항이 저장되어 rung new · kind predict이고 question(펜스 하나) · hint · answer가 모두 있어야 합니다. 플러그인 읽기가 그 자리를 거절해 문항이 없으면(missing · blocks · lang · comment · string · long · forbidden · spacing · print-form · print-place · print-count · output · count · mine · question-long) 1에서 놓침이고 거절 까닭은 기록만 합니다. 코드 없이 물은 문제는 생길 수 없고, 생기면 1에서 놓침입니다.",
   "2 꼴 ⚙": "저장된 question 안의 펜스 블록이 꼭 하나이고(플러그인이 씀), 펜스 안에서 공백뿐인 줄을 뺀 줄이 8 이하입니다. 판정은 학습자가 보는 그대로, 곧 플러그인이 주석을 지운 뒤의 코드로 합니다. 언어 무리: js = js · javascript · mjs · cjs · node, py = py · python · python3; 플러그인 펜스(js 또는 python)는 물은 언어(파일 확장자)의 무리와 늘 같아야 하며 다르면 놓침입니다. ts는 이 설계에서 쓰이지 않음(ts 개념은 처음 보는 코드로 묻지 않음).",
   "3 내 코드가 아님": "문제 코드와 그 개념 견본의 code를 견줍니다. ⚙ (가) 공백을 모두 뺀 두 글이 같음. ⚙ (나) 문제 코드의 줄(공백뿐인 줄과 괄호 · 중괄호 · 대괄호 · 쉼표 · 세미콜론 · 콜론만 있는 줄은 뺌) 가운데 절반 이상이, 공백을 뺀 꼴로 개념 코드의 어느 줄과 같음. ⚙ (다) 두 코드의 이름(식별자; 그 언어의 예약어와 console · print · len · range · str · int · float · list · dict · Math · Object · Array · JSON · String · Number는 그대로)을 처음 나온 차례대로 v1, v2 …로 바꾸고 공백을 뺀 뒤 같거나, 다른 곳이 리터럴(숫자 · 문자열) 하나뿐임(개념 코드 전체나 같은 줄 수의 이어진 줄과 견줌). ✎ (라) 판정 하위 에이전트가 같은 상황(이름 · 값 · 쓰임이 모두 개념 코드와 같은 일)이라고 이유와 함께 적음. 넷 가운데 하나면 놓침입니다. 같은 메서드 · 연산자나 흔한 예(정렬 기본 순서 · map · reduce · 클로저 push)를 쓴 것, 플러그인이 준 상황 이름을 쓰지 않은 것만으로는 놓침이 아닙니다. 흔한 예를 이름과 값을 바꿔 다시 쓴 것은 (다)에 걸리지 않고 이름 · 값이 다르면 (라)에서 넘음입니다(1.10.0 셈 그대로; 개발 기록 set1 T07).",
   "4 개념이 출력을 정함 ✎": "출력의 적어도 한 줄이 개념 견본 blurb가 말한 동작으로 정해져야 합니다(그 동작을 모르면 그 줄을 맞힐 수 없음). 판정 하위 에이전트가 이유 한 줄과 함께 매깁니다. 판정은 6의 꼴로 맞춘 출력(줄 앞뒤 공백을 떼고 안쪽 공백을 하나로)에 대해 합니다: 공백에만 드러나는 동작은 그 꼴에서 보이지 않으므로 놓침입니다. 개념의 동작이 일어나지 않게 짠 코드(가변 기본 인자를 한 번만 부름, 클로저를 반복 안에서 바로 부름, 얕은 복사를 고치지 않고 찍음)는 놓침입니다(개발 기록 set1 N02-r2#1 T07). 그 동작을 모르는 학습자가 흔한 짐작으로 맞히게 되는 줄만 있으면 놓침이고, 다른 한 줄이라도 그 동작에 달렸으면 넘음입니다. 타입 표기 · 실행 순서 · 문자열 글자 개념은 이 설계의 범위 밖이라 견본에 없어야 하며, 있다면 이 조항대로 매깁니다.",
   "5 돌림 ⚙": "보인 그대로 돌립니다(보이지 않는 정의 · import · 입력 · 파일 · 환경 · 앞선 상태를 채우지 않음; B-1, B-2). 빈 임시 폴더에서 `unshare -n timeout 5`: js는 node로 두 번, 모듈 문법 오류일 때만 .cjs로 한 번 더; py는 B-14(`env -i PATH=\"$PATH\" LANG=C.UTF-8 PYTHONHASHSEED=<n> python3 -s -P -B 파일`, n = 1~5, 다섯 번 모두 같아야 함). 끝 코드 0, 같은 출력. 금지 기능(grep 뒤 하위 에이전트가 쓰임인지 확인; 문자열 · 주석 안 낱말은 쓰임이 아님): js Math.random · Date · performance. · fetch · XMLHttpRequest · WebSocket · require( · import · process · fs · document · window · localStorage · sessionStorage · alert( · prompt( · readline; py random · time · datetime · input( · open( · os · sys · subprocess · socket · urllib · requests · pathlib. 출력은 끝 줄바꿈 하나를 떼고 3줄 이하, 줄마다 40 코드 포인트 이하. 위 목록에 없는 표준 기능(math, functools, itertools …)과 플러그인 읽기가 더 막는 것(set, 타이머 등)은 이 조항의 금지가 아닙니다(읽기가 막으면 1에서 놓침).",
   "6 A와 출력 ⚙": "저장된 answer와 stdout을 견줍니다. stdout은 끝 줄바꿈 하나를 떼고 줄로 나눕니다. 줄마다 앞뒤 공백을 떼고 안쪽 공백 · 탭이 이어진 곳을 하나로, 줄 끝 마침표 하나를 떼고, 따옴표의 종류(' \" ` ‘ ’ “ ”)만 같게 봅니다. 따옴표가 있고 없음은 다름입니다. 값 · 순서 · 줄 수(빈 줄 포함)는 그대로 봅니다. True와 true, None과 null, 1과 1.0은 다른 값입니다. stderr는 보지 않습니다. 틀리게 짐작한 A(`'pythonista'[7:]` → ista, 개발 기록 R18 44 대 45)는 놓침입니다. 일부 줄만 묻는 문제의 셈(A가 출력 전부면 넘음, 물은 줄만 적었으면 놓침)은 1.10.0 그대로 두지만, 플러그인의 질문이 늘 출력 전부를 묻고 A가 찍는 호출 수만큼의 줄이어야 저장되므로 쓰이지 않습니다.",
   "7 힌트 · 문제가 답을 말하지 않음": "⚙ 기계 규칙: H나 Q의 글(펜스 밖)에 출력 줄의 값(6의 꼴, 두 글자 이상)이 낱말로 들어 있고 그 값이 문제 코드 안에 리터럴로 없으면 놓침입니다. 플러그인의 질문 글(NEW_LEAD · NEW_LEAD_LINES)과 힌트 틀은 모델 글과 똑같이 이 규칙으로 봅니다. ✎ 그 밖은 판정 하위 에이전트가 이유와 함께 매깁니다. 힌트가 보인 코드의 한 줄을 그대로 옮긴 것(`…` 줄에서 무슨 일이 일어나는지부터 보세요)은 그 줄에 리터럴로 든 값이 있어도 그것만으로 놓침이 아닙니다(학습자가 이미 보는 줄). 옮긴 줄이 보인 코드의 줄이 아니면 놓침입니다(더 엄격; 플러그인은 그런 힌트를 만들지 않음). 고정 힌트 NEW_HINT_PLAIN은 넘음입니다.",
   "Q2 퀴즈 답의 상태 ⚙": "빈 답(empty-reply; API 거절 stop_reason refusal은 엔진이 빈 답으로 넘기므로 빈 답) · 시간 한도(90초)에 끊긴 답 · 상한 닿음(output_tokens ≥ 4600 + H_M)은 그 퀴즈의 모든 처음 보는 코드 자리를 놓침으로 하고 Q2를 못 넘음으로 합니다. 상한에 닿지 않았는데 글 가운데에서 끊겨 자리가 빠진 답(cut)은 빠진 자리가 1에서 놓침이고 Q2 자체는 위 셋에 들 때만 놓침입니다; cut과 빈 답은 모두 tap으로 한 번 다시 보내 stop_reason을 기록만 합니다(B-12). api-error(답 전 오류)만 한 번 다시 보내고, 다시도 api-error면 빈 답입니다. M-4 셋째 줄(남은 api-error가 한 스테이지 호출의 10% 초과면 그 스테이지 무효)은 그대로입니다.",
   "Q3 부를 수 없는 개념 ⚙✎": "한 U 개념은 그 꼴에서 committed rungOf가 new가 아니면(범위 밖 · 라이브러리 · NEW_UNRUNNABLE 포함) 처음 보는 코드가 아닌 길입니다. new였고 U 퀴즈로 불렸는데 플러그인 읽기가 그 자리를 거절해 문항이 없으면, 학습자에게 처음 보는 코드로 아무것도 보이지 않았으므로 처음 보는 코드가 아닌 길입니다(1.10.0의 \"parseQuiz 뒤 rung이 남지 않음\"과 같은 셈). 문항이 저장되었으면 처음 보는 코드로 간 것이며 5를 넘어야 합니다. 흉내 코드(라이브러리 · 프레임워크 · 브라우저 · 네트워크의 이름이나 동작을 손으로 만든 함수 · 객체로 흉내 냄)는 판정 하위 에이전트가 이유와 함께 매기며 하나라도 있으면 Q3 못 넘음입니다.",
   "G-1 채점의 셈 낱말 ⚙": "셈 낱말은 플러그인이 남기는 판정입니다. (1) localRight가 맞음이라 한 답은 모델을 부르지 않고 맞음으로 셉니다(모델 글 없음). (2) 그 밖은 parseCheck(fixEscapedTicks(text), { exact: answer, mine })의 verdict입니다: 값 줄로 valuesVerdict가 정한 맞음 · 틀림. 모델이 판정: 줄이나 거의를 써도 읽지 않습니다. 이것이 1.10.0(쓴 낱말)보다 느슨하지 않은 까닭: localRight는 맞음만 말하고, 실행으로 확인한(6) answer와 값마다 같을 때만 말하며, L0가 틀린 답의 지역 맞음을 하나라도 막습니다; 모델 길의 맞음은 옮긴 값이 줄마다 같고, 학습자가 쓴 글에 그 값이 저마다 제자리로 있고, 값 더가 없을 때만입니다; 값 줄이 빠진 답 · 빈 답 · 시간 한도 · 상한 닿음은 C2 · C3에서도 놓침입니다(쓴 낱말 셈에서는 그런 답이 틀림 기대 묶음에서 넘을 길이 없었던 것과 같음). 1.10.0이 쓴 낱말로 센 까닭(플러그인의 읽기가 모델 낱말과 달랐음)은 낱말이 없는 이 채점에 해당하지 않습니다. 셈 낱말과 다른 기록(피드백과의 어긋남, 옮긴 값 충실도, 가드가 뒤집은 수)은 기록만 합니다.",
   "G-2 기대 판정": "기대 판정은 얼린 견본 꼬리표로 정합니다(right · again → 맞음, wrongOne · wrongAll → 틀림). 답을 본 뒤 다시 매기지 않습니다. 부르기 전에 무효로 적은 답만 뺍니다.",
   "G-3 견본 답의 유효성 ⚙✎": "부르기 전에 도구가 보고, 그 꼬리표의 판정 하위 에이전트가 확인합니다. 학습자 값의 규칙(isSameValue와 같음): 앞뒤 공백 · 안쪽 공백 하나 · 따옴표 종류 · 끝 마침표 하나를 맞추고, 찍힌 줄에 감싼 따옴표가 없을 때만 학습자가 감싼 따옴표를 뗍니다(찍힌 줄이 'abc'면 abc는 다른 값). 조사 · 말투 · 덧붙인 까닭은 값이 아닙니다. right · again: 찍힌 줄마다 그 값이 차례대로 모두 있고, 다른 값을 줄 값으로 말하지 않아야 합니다; 찍힌 줄에 쉼표가 있는 문항은 줄을 바꿔 써야 하고 쉼표로 이은 답은 무효입니다; 줄인 값은 무효; again이 right와 같은 글이면 무효. wrongOne: 줄 수가 같고 꼭 한 줄의 값만 다름(따옴표만 다른 것도 찍힌 줄에 따옴표가 있으면 다름). wrongAll: 어느 자리에서도 찍힌 값과 같은 값이 없음(전체 순서 뒤바뀜 포함). 찍히는 글자가 다른 꼴(1과 1.0, True와 true)은 맞는 답으로 쓰지 않습니다.",
   "G-4 경로": "첫 시도: right · wrongOne · wrongAll. 힌트 뒤(C2 (b) · C4 (b)): first = { mine: '모르겠어요', verdict: 'wrong', feedback: '', nudge: item.hint }; again · wrongOne. 되묻기 뒤(C4 (a)): 첫 시도 wrongOne의 남긴 판정이 맞음이 아니고 keptNudge가 되묻기를 남긴 문항만 again을 부릅니다(first = { mine: wrongOne, verdict: 남긴 판정, feedback, nudge }); 되묻기가 버려진 문항은 그 묶음에 들지 않고 수만 적습니다. 둘째 답의 셈은 남긴 verdict가 맞음일 때만 넘음입니다(secondVerdict도 그때만 right). localRight는 세 경로 모두에서 먼저 봅니다.",
   "G-5 채점 답의 상태 ⚙": "값 줄이 하나라도 빠져 읽지 못함(undefined) · 빈 답 · 시간 한도(60초) · 상한 닿음(output_tokens ≥ 480 + H_M)은 그 견본에서 놓침입니다(어느 묶음이든). 다시 부르지 않습니다(api-error 규칙 제외).",
   "G-6 L0 ⚙": "유효한 wrongOne · wrongAll이 어느 경로에서든 localRight로 맞음이 되면 하나라도 L0 못 넘음입니다. localRight의 닫힌 목록은 커밋에서 sha256으로 얼립니다.",
   "G-7 견본 쓰기 답의 블록 ⚙": "채점 견본 쓰기 하위 에이전트의 답에 ```json 블록이 꼭 하나가 아니면 같은 프롬프트로 한 번 다시 부릅니다. 다시도 꼭 하나가 아니면 그 꼬리표의 C1~C4는 못 넘음입니다. 재는 세션이 블록을 고르지 않습니다(1.10.0 M-11의 교훈).",
   "판정 하위 에이전트": "꼬리표마다 한 명(G3 1.10.0 그대로)이 이 입장 글과 문항별 자료(저장된 question · hint · answer, 돌린 stdout, 개념 견본의 name · blurb · code)만 받습니다. 모델 이름, 다른 꼬리표, 토큰 · 시간은 받지 않습니다. 판정마다 조항 번호와 이유 한 줄을 씁니다. 판정이 빠지거나 읽히지 않으면 놓침입니다.",
   "1.9.0 · 1.10.0 기록과 개발 답이 부딪힌 경계와 정한 셈": [
    "A를 산문 · 설명으로 씀(1.9.0 1차 22): 읽기가 거절 → 1 놓침.",
    "A를 \" / \"로 한 줄에 이음(N05Q1 · N05Q3), 쉼표로 이음: 찍는 호출 수와 줄 수가 다르거나 기호가 코드 문자열에 없어 거절 → 1 놓침.",
    "A 줄 수가 찍는 호출 수와 다름: 거절 → 1 놓침.",
    "코드 없이 왜로 물음(1.9.0 1): 문항이 생기지 않음 → 1 놓침.",
    "코드 9줄 · 10줄(1.9.0, sonnet 개발 long): 거절 → 1 놓침.",
    "반복문 · 함수 · 조건 · 콜백 안의 찍기(haiku 개발 set1 r2 둘): 거절(print-place) → 1 놓침. 같은 줄에 몸이 있는 if · for 아래 맨 바깥 찍기는 거절하지 않음.",
    "찍기 하나에 값 여럿(쉼표 · end= · sep= · *xs · ...xs): 거절 → 1 놓침.",
    "A가 틀림(`'pythonista'[7:]`, R18 44 대 45): 6 놓침.",
    "내 코드와 거의 같은 코드(let 블록 범위, N02Q1 클로저 push, N09Q1 5/6줄): (가)(나)(다)는 읽기가 먼저 거절(1 놓침), 남은 것은 (라).",
    "흔한 예를 이름 · 값만 바꿈(set1 T07): (다)에 안 걸리면 (라)에서 넘음.",
    "비슷한 흔한 예(sort 기본 순서 · map · reduce): (가)~(라)에 안 걸리면 넘음.",
    "개념의 동작이 일어나지 않는 코드(set1 N02-r2#1 가변 기본 인자 한 번 부름): 4 놓침.",
    "타입 표기 개념(N11): 범위 밖; 견본 검사에서 빠져야 하며 들어오면 4 놓침.",
    "실행 순서 개념(N03 setTimeout과 Promise): 범위 밖; 들어오면 그대로 매김(대개 읽기 거절 → 1 놓침).",
    "문자열 글자 개념(역순 슬라이싱 · 회문 · 패딩, 개발 R17 · R18 · set1 R01): 범위 밖. 범위 안 개념에서 모델이 라틴 글자를 뒤섞은 출력('mpl', 'miws')을 쓰면 읽기 거절 → 1 놓침; 한글은 음절 단위로 읽으므로 '사코기' 같은 첫 글자 모음은 저장되어 6으로 매김.",
    "되풀이 조각 출력('****', 'abab', '====장미===='): 저장되어 6으로 매김(옛 창의 마크다운 표시는 판정과 상관없음).",
    "찍힌 줄에 쉼표(T06 '7,NaN,NaN'): 질문은 쉼표로 잇기를 권하지 않는 NEW_LEAD_LINES; 채점 견본의 맞는 답은 줄을 바꿔 씀(G-3).",
    "없음 · None · - 을 찍음: 혼자인 기호 한 글자 줄('-')은 읽기 거절(1 놓침, 최종 탐침 P5); 없음 · None은 저장되고 채점은 isSameValue와 가드로 봄.",
    "공백이 뜻을 지니는 출력(rjust · 폭 지정 · 공백 되풀이 · 안쪽 두 칸): 읽기 거절(spacing) → 1 놓침; 문자열 양 끝 공백(strip 개념)은 허용하고 4 · 6은 맞춘 꼴로 봄.",
    "주석이 든 코드: 줄 주석은 플러그인이 지운 뒤로 매김; 블록 주석 · 세 따옴표 문자열은 거절(1 놓침).",
    "모델이 K · L · A를 다시 씀(자기 고침): 나중 것이 저장됨; 저장된 것만 매김.",
    "A 아래 빈 줄 뒤의 메모: 출력이 아님; 저장되지 않음.",
    "힌트가 값만 넣는 줄을 가리킴(haiku 개발 약 20/69): 이제 고정 힌트로 바뀜; 어느 쪽이든 7 넘음(기록: 고정 힌트 비율).",
    "상한에 닿아 셋째 문제가 없음(1.9.0 N01 · N11): 그 자리 1 놓침, Q2 놓침.",
    "빈 답 · 거절(1.10.0 sonnet N08): 그 퀴즈 모든 자리 놓침, Q2 놓침.",
    "상한 아래에서 글 가운데 끊김(1.10.0 sonnet N04 · N05 · N12 · N15): 빠진 자리 1 놓침; tap stop_reason 기록.",
    "채점: 한 값만 틀린 답을 거의(1.9.0 9): 이 채점에는 판정 낱말이 없음; 값 줄로 틀림.",
    "채점: 쉼표로 이은 맞는 답을 틀림(N15Q1 · N08Q3 · N13Q3): localRight 또는 값 줄로 셈.",
    "채점: 대조가 모두 같음인데 틀림, 대조 안에서 뒤집음, 첫 시도 값을 둘째 답으로 읽음(1.10.0 C4): 이 채점에는 대조 · 판정이 없고 첫 시도 값이 프롬프트에 없음; 남긴 판정으로 셈.",
    "채점: 모델이 옮긴 값이 학습자 글에 없음(모범 답을 베낌) 또는 한 번 쓴 값을 두 줄에 씀: 틀림(가드).",
    "채점: 값을 백틱 · 따옴표로 감싸 옮김: isSameValue와 가드가 감싼 쌍을 뗀 꼴도 봄.",
    "채점: 값 줄 대신 판정: 줄만 씀: 읽지 못함 → 놓침.",
    "채점 피드백이 맞은 줄을 인정 · 판정과 어긋남: 셈과 상관없음(기록만).",
    "따옴표를 붙인 A(`'abc'`)와 따옴표 없이 찍힌 출력: 읽기가 대개 거절(따옴표가 코드 문자열 안에 없음) → 1 놓침; 저장되면 6 놓침.",
    "True와 true, None과 null, 1과 1.0: 다른 값.",
    "보이지 않는 정의(1.9.0 W10): 보인 그대로 돌림, 오류면 5 · 6 놓침."
   ]
  },
  "decisionRule": [
   "Per model m, from m's counts only (R1-R4): Q1 = number of the 30 measured new slots whose stored item meets clauses 1-7 (a reader-refused, unread or unreturned slot, a judge split or an undecided case = miss); if Q1 ∈ {27, 28}, S-A2 is measured in the same layout and the total of 60 must be ≥ 57. Q2 = 0 cap hits, 0 empty (refusals included), 0 timeouts over the 18 (or 36) quiz calls. Q3 = in each shape at least 8 of 9 U concepts on a non-new path, 0 mimicking code, every stored U item passing clause 5.",
   "If Q1 has fewer than 10 passing questions, C1-C4 fail without grading. Else each cell counts misses by the kept verdict (stance G-1): C1 ≤ 1, C2(a) ≤ 3, C2(b) ≤ 3, C3 ≤ 3, C4(a) ≤ 1, C4(b) ≤ 1 (doubled if 31-60 graded; fixed counts for a set smaller than 30); L0 = 0 local rights on validated wrong answers.",
   "Pass iff Q1 ∧ Q2 ∧ Q3 ∧ C1 ∧ C2(a) ∧ C2(b) ∧ C3 ∧ C4(a) ∧ C4(b) ∧ L0.",
   "Pass → MODEL_SWITCHES[m].rungNewStep = 4 in the commit after the decision, tests/route.test.ts SHIPPED equal to the 견본.md decision table, the old-build probe re-run with the ON value (R9), README/CHANGELOG naming the model (docs phase). Fail → Infinity. RUNG_NEW_STEP stays Infinity.",
   "haiku is measured; sonnet is not measured in 1.12.0 (its cell stays Infinity), by the pre-stated pilot gate (Q1-equivalent ≥ 28/30 in each D2 run and ≤ 1 wrong answer among ≥ 60 kept): sonnet had 26 in one run.",
   "A version or alias mismatch against the calibration voids the round (cell OFF, not re-measured in 1.12.0). Changing a measured prompt or the reader after the round turns the cell OFF (D26 recheck); changing only reading code re-reads the same frozen answers and a fail never turns into ON (R5, D22)."
  ],
  "perModel": {
   "haiku": "measure. Dev (records only): final quiz prompt (rev1, unchanged since) on fresh dev set 2, measured layout, each quiz twice, final reader: Q1-equivalent 29/30 and 29/30 (each run's only drop is R17 거꾸로 슬라이싱, now out of scope by isStringShape: 29/29 of in-scope slots), 0 wrong answers in 58 kept, 0 judge misses on 72 items; Q2 0 caps (max 3075 vs 6648, median 2371), 0 empty, 0 refused, 0 cut (one set-1 slot omission re-sent through the tap: end_turn); Q3 9/9 in both shapes, DN 8/8 not new. Grading: pilot arm b 0 misses on every cell over 48 items (sets 1 and 2); final grade re-checked on set 2 with real concept names: C1 0/20, C2a 0/20, C2b 0/20, C3 0/20, C4a 0/20, C4b 0/20, L0 0, unread 0, max 1675 tokens (cap 2528 at H 2048); 382 frozen pilot grade replies re-read with the value guard: 0 verdict changes. Q1 sits at the bar: roughly even odds of 29+ on the first set, a real chance of the second set.",
   "sonnet": "do-not-measure. Dev set 2 on the final text: Q1-equivalent 28/30 and 26/30 (in-scope 27/29 and 26/29), 1 wrong answer in 55 kept (R18 44 vs 45), reader drops long 1 + 1 and string-letter output 1 + 2; 0 refused, empty or cut replies in 320 calls (the refusal hypothesis held); grading 0 misses on 49 items but max 424 output tokens against a 480 cap if H_sonnet stays 0. Below the Q1 bar and below the pre-stated sonnet gate."
  },
  "samples": {
   "design": [
    "Measured samples are written after the bar commit by fresh blind sub-agents (`claude -p --model opus --tools ''`, DISABLE_AUTOUPDATER=1) that never see the rule wording, prompts, stance, design, code or which model is measured; frozen (chmod 444, sha256, author, UTC) before any call and recorded in docs/qa/견본.md.",
    "S-A1 (first set): 34 concept records, all whole-file creates in js/mjs/cjs/py: T 10 tricky-pitfall concepts + 2 spares, R 20 basic concepts + 2 spares; measured js 16 · py 14. Each: id, name, blurb (1-2 sentences 합니다체 + \" — \" + one non-print code line of the file in backticks), file, code (3-8 non-blank lines, runs alone, deterministic, prints 1-3 lines of at most 40 code points), output. No ts, no type-level, run-order or string-letter (slice/reverse/pad/palindrome) concept; each frozen record must reach new through the committed rungOf + ladderMixed before freezing; a failing record is replaced by a spare in id order and recorded; a slot with no spare left stays and counts as a miss.",
    "Names in the plugin's style: a short concept name (e.g. \"var 반복문 클로저\", \"기본 정렬 순서\"), not \"<주제>: <상황>\"; the situation phrase, if the writer gives one, goes only into NAMES.txt. Disjointness from earlier sets is checked on (name, blurb, code): no name equal after removing spaces, no blurb quote line equal, no code equal under clause 3 (가)(다) to any record of the sets listed below.",
    "The writer prompt has no worked example name (the dev writer's \"문자열 반복: 구분선을 별표로 만들기\" seeded repeat concepts) and keeps the dev quotas only as minimums: at least 5 canonical pitfalls, at least 4 concepts usually shown by printing inside a loop, at least 3 string-output concepts, at least 3 py concepts printing True/False/None, at least 3 concepts whose natural output is 3 lines.",
    "S-A2 (second set, frozen with S-A1, used only if Q1 is 27 or 28): another 34 records of the same shape, disjoint names.",
    "S-O fillers: 2 내 코드 concepts with code (js, py), 2 slips for 다시 도전, 2 codeless concepts for 왜; the 4 spares of S-A1 feed M1-M3.",
    "S-U: 9 unrunnable concepts (js 5 · py 4: a library import outside the hunk, jQuery $(, a decorator, fetch/XHR/WebSocket, process./node: I/O), each built by tool in the edit shape (imports outside the hunk, worktree file text supplied) and the new-file shape.",
    "Layout (18 prompts): 15 quizzes [new, new, 내 코드] at steps 4/5 alternating, 내 코드 place rotated, the first 10 holding T + R and the last 5 R + R; M1 [다시 도전, new, new]; M2 [다시 도전, new, codeless 왜]; M3 [new, new, new]; one U quiz only if a U concept reaches new in a shape. The scene day is the measuring day (recorded in every prompt file).",
    "Grading answers: per label, after the quiz stage, a fresh blind writer gets each kept-and-passing item (question, answer, hint) and writes right, again, wrongOne, wrongAll in beginner register (every 3rd right comma-joined unless a printed line holds a comma, every 5th with a short reason). Validated mechanically (stance G-3) then by that label's judge, then frozen before any grading call. The reply must hold exactly one ```json block; else one re-call with the same prompt; if that also fails, that label's C1-C4 fail."
   ],
   "mustNotOverlapNames": [
    "All 1.8.0-1.11.0 sample names (docs/qa/견본.md), 1.10.0 S-A1/S-A2/S-U.",
    "G3 dev set 1 and set 2: /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/design/G3/dev/NAMES.txt (34 + 23 records each, e.g. var 반복문 클로저, 기본 정렬 순서, 느슨한 비교, 얕은 복사, 문자열과 숫자 연산, forEach 안의 return, 가변 기본 인자, 리스트 곱셈 함정, 나눗셈 두 종류, 0의 참거짓, return 빠뜨리기, 순회 중 삭제, 앞자리 채우기, 배열 map/filter/reduce, 객체 구조 분해, for...of 반복, 삼항 연산자, Object.keys 길이, 배열 includes, 대문자 변환, while 카운트다운, 기본 매개변수, f-문자열, 리스트 컴프리헨션, 딕셔너리 get 기본값, enumerate 번호 붙이기, 문자열 in 검사, 역순 슬라이싱, zip 짝짓기, range 음수 간격, 문자열 join, max의 key 인자, is와 == 구분, map에 parseInt 넘기기, strip 공백 제거, Math.min과 전개, toUpperCase, 문자열 repeat …) — the measured check is on (name, blurb, code), so a canonical concept may recur only with a new name, blurb and code.",
    "The G3 final targeted probe items P1-P6 (/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/design/G3/final/probe/items-X.json).",
    "The other Gs' 1.12.0 dev and measured samples (G2 dev NAMES.txt, G1/G4/G5/G6 lists)."
   ]
  },
  "calls": "Exactly as the plugin calls (D20), through a copy of the probe mod: $.model.complete({ model: 'haiku' (the setting string as is), effort: 'low', system: QUIZ_SYSTEM, prompt: redactText(quizPrompt(picks, 'beginner')).text, maxTokens: 4600, timeoutMs: 90000 }) for each quiz (every measured quiz has a new pick), 4 at a time, timed with $.clock, replies through fixEscapedTicks, read with the committed parseQuiz. Grades: $.model.complete({ model: 'haiku', effort: 'low', system: CHECK_SYSTEM, prompt: redactText(checkPrompt(item, mine, 'beginner', first, undefined, { exact: true })).text, maxTokens: 480, timeoutMs: 60000 }) only where localRight(mine, item.answer) is false (a local right is a no-call verdict, recorded), read with parseCheck(fixEscapedTicks(text), { exact: item.answer, mine }). Paths: first try (right, wrongOne, wrongAll), after 모르겠어요 + hint (again, wrongOne; first = { mine: '모르겠어요', verdict: 'wrong', feedback: '', nudge: item.hint }), after the nudge (again, for each wrongOne whose first kept verdict is not right and whose nudge keptNudge kept; first = { mine: wrongOne, verdict: kept, feedback, nudge }). Prompts built by importing the committed tree's notes.ts with only haiku's rungNewStep = 4 (the other haiku cells as the earlier 1.12.0 batches left them, M-13), picks built as makeQuiz builds them (codeFor, rungOf, ladderMixed, withScenes(day), pickForRung). D34 before the first call: one real request each for the quiz and the three grade paths captured from the plugin test harness must equal the tool's prompt file to the byte (the prototype's tests/d34g3.test.ts already does this for one quiz and one item: 4/4 identical). Tap: every empty reply and every cut reply (stop not end_turn, or a slot missing while output_tokens < 4600 + H_M) is re-sent once through the pass-through tap and its stop_reason/stop_details recorded (B-12). DISABLE_AUTOUPDATER=1; claude --version and the resolved aliases recorded before and after.",
  "risks": [
   "Q1 at the bar: haiku dev 29/30 twice on in-scope-equivalent slots; one more refused or wrong slot in 30 calls the second set (57/60), two fail. Expect roughly even odds of passing the first set outright.",
   "Fresh samples may hold concepts outside the dev mix where haiku writes prints inside blocks when it answers without thinking (~400-token replies, set 1 r2 lost 2 slots this way).",
   "A single wrong stored answer is a Q1 miss and reaches learners; the plugin cannot run code. Haiku 0 wrong in 58 kept on the final text; the scope and top-level rule lower but cannot remove it.",
   "Calibration: if the 1.12.0 calibration changes H_haiku from 2048, haiku's accuracy (which relies on its thinking share) and the cap threshold change; the round must use the measured H and the same CLI version.",
   "Grading on fresh answers: the local share depends on the writer's phrasing; the value guard could mark a right answer written in a form other than the printed text (e.g. 참 for True) 틀림 — strict by design, but a C1 risk if the writer uses such forms (the validity rule forbids different printed forms as right answers).",
   "Reach is narrower than 1.10.0: no ts/tsx, no type-level, run-order or string-letter concepts; only quizzes of 3+ picks with no team term or worked example. App builders working in ts/tsx get no 처음 보는 코드.",
   "Half of haiku's hints become the plain sentence (it names a value line); the hint path's usefulness is not measured by any bar clause.",
   "Old windows show mark-only answers as Markdown rules; a 1.7 window invisible to the stamps stock-grades a K/L/A item with 거의.",
   "G2-C and G3 both change quizParts, quizRun resets, recheckRemap in makeQuiz and the ON grade path; if G3 turns ON for haiku while G2 also does, a G2 pick beside a new pick becomes 내 코드 (ladderMixed), which lowers G2's reach."
  ]
 },
 "plan_batch3": {
  "barSource": {
   "fields": "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/design/G3.json: bar, stance (0–7, Q2, Q3, G-1..G-7, 판정 하위 에이전트, the pre-decided boundary cases), decisionRule, samples, calls.",
   "summary": "Q1 ≥ 29/30 (27–28 → the pre-frozen S-A2 set is measured and the total must reach 57/60; ≤ 26 fail); Q2 0 cap hits, 0 empty (refusals included), 0 timeouts over the 18 quiz calls (36 with S-A2: S-A2 is measured in the full 18-prompt layout, M1–M3 from S-A2's spares, and Q2 is counted over all 36 calls); Q3 ≥ 8 of 9 U concepts non-new in each shape, 0 mimicking code; C1 ≤ 1, C2(a) ≤ 3, C2(b) ≤ 3, C3 ≤ 3, C4(a) ≤ 1, C4(b) ≤ 1 (doubled for 31–60 graded); NEW stricter L0 = 0 local rights on validated wrong answers; grading only if ≥ 10 questions passed.",
   "decision": "MODEL_SWITCHES.haiku.rungNewStep = 4 iff Q1 ∧ Q2 ∧ Q3 ∧ C1 ∧ C2(a) ∧ C2(b) ∧ C3 ∧ C4(a) ∧ C4(b) ∧ L0; else Infinity. RUNG_NEW_STEP stays Infinity.",
   "quotedFrom": "docs/qa/견본.md '1.10.0 처음 보는 코드 (G3)' > '기준 · 입장 · 결정 규칙' (888113d, built code 17c10c4) with the design's stricter additions (L0, M3 in Q2) and the narrowed scope (D33).",
   "q2Reading": "G3.json is inconsistent on Q2's count with S-A2 ('15 quizzes plus M1, M2 and M3 (30 + 3 if the second set runs)' vs '18 (or 36) quiz calls' in decisionRule and the Q1 line '18-prompt layout'). The bar commit states one reading before any call and notes the inconsistency: 'S-A2 is measured in the full 18-prompt layout (M1–M3 from S-A2's spares), and Q2 is counted over all 36 calls' (the stricter reading, matching Q1 and decisionRule). The translation checker confirms the bar commit holds no other reading."
  },
  "samples": {
   "layout": "S-A1: 34 records (T 10 + 2 spare, R 20 + 2 spare; measured js 16 · py 14), whole-file creates js/mjs/cjs/py, 3–8 lines, 1–3 printed lines ≤ 40 code points; S-A2: another 34, frozen with S-A1, used only if Q1 ∈ {27, 28}; S-O fillers 2 내 코드 · 2 다시 도전 slips · 2 codeless 왜; S-U 9 unrunnable (js 5 · py 4) built by tool in edit and new-file shapes. 18 prompts: 15 [new, new, 내 코드] at steps 4/5 (first 10 T+R, last 5 R+R), M1 [다시 도전,new,new], M2 [다시 도전,new,왜], M3 [new,new,new]; one U quiz only if a U concept reaches new. Scene day = measuring day.",
   "writers": "1–2 fresh blind writers for S-A1 + S-A2 + S-O + S-U; no worked example name in the writer prompt; quotas only as minimums.",
   "secondStage": "Grading answers per label after the quiz stage is frozen and judged: a fresh writer sees each kept-and-passing item (question, answer, hint) and writes right, again, wrongOne, wrongAll; validated mechanically (G-3) then by the label's judge; exactly one ```json block, else one re-call, else C1–C4 fail.",
   "avoid": "design/G3/dev/NAMES.txt (sets 1–2), the final probe items P1–P6, all 1.8.0–1.11.0 names, 1.10.0 S-A1/S-A2/S-U, impl112/NAMES-all.txt; disjointness on (name, blurb, code)."
  },
  "calls": {
   "haiku": "18 quiz calls (36 with S-A2) (QUIZ_SYSTEM, 4600, 90000) + grade calls (CHECK_SYSTEM, checkPrompt(…{ exact: true }), 480, 60000) only where localRight is false: ≈ 100–120 (≈ 200–240 with S-A2), paths first try / after 모르겠어요 + hint / after the nudge.",
   "D34": "Quiz + the three grade paths captured from the harness at the committed tree = tool prompt files to the byte (prototype d34g3: 4/4).",
   "tap": "Every empty reply and every cut reply (stop not end_turn, or a slot missing while output_tokens < 4600 + H_haiku) re-sent once through the tap (record)."
  },
  "judges": "One judge for the haiku label (quiz clauses and grading-answer validity); a judge error or missing verdict is a miss.",
  "stop": [
   "Q1 ≤ 26 (with S-A2: total < 57), or Q2 or Q3 fails → the decision is already Infinity; the grading stage is then skipped to save usage. This skip rule is written in the bar commit before any call (it cannot change the outcome; the C cells are recorded as not run). Fewer than 10 passing questions → C1–C4 fail without grading (bar).",
   "Q1 ∈ {27, 28} → S-A2 measured in the full 18-prompt layout (M1–M3 from S-A2's spares; quiz and grading), the only second set allowed; Q2 counted over all 36 quiz calls.",
   "checkPrompt {rule} request bytes (G6 N2) or N2/tier selection differ vs batch 1 (D26 (가)/(나)) → that isRuleDrill cell OFF (R5).",
   "parseCheck {rule} or ruleFixReply reading differs (D26 (다)) → re-read the frozen N2 and tier-2 answers with the new reader; that isRuleDrill pass stands only if it still passes."
  ],
  "d26Recheck": [
   "isRuleWide haiku",
   "isRuleWide sonnet",
   "isRuleDrill haiku/sonnet if ON (N2 checkPrompt {rule} bytes, parseCheck {rule} reading)",
   "G2 rungChangedStep haiku if ON: its 9 frozen requests to the byte, rungOf/ladderMixed selection on its frozen samples, changedItem/parseQuiz reading of its frozen answers. Not OFF only if the difference is exactly that some of G2's 9 frozen quizzes or 20 slots are no longer built with a changed pick (G3's ON value through ladderMixed) and every remaining G2 request is byte-identical to its frozen request; any other (가) or (나) difference turns G2 haiku OFF in batch 3 (R5), recorded. The recheck script prints the dropped slot ids and a byte comparison of the remaining requests."
  ],
  "switchCommit": "If pass: MODEL_SWITCHES.haiku.rungNewStep = 4; route SHIPPED; old-build probe (six real builds 3f2b4fb (1.7.0) · 7a7b08c (1.7.1) · 3690021 (1.8.0) · fca5988 (1.9.0) · 3d2f251 (1.10.0) · de98243 (1.11.0)) and coexist19 with the ON value; the two G7 cross-route tests; measured prompts re-made byte-identical; G2 haiku recheck at the switch tree.",
  "usage": "haiku 18 quiz + ≈ 110 grade calls (double with S-A2): input ≈ 0.25M (0.5M), output ≈ 0.15M (0.3M) tokens (quiz median ~2.4k incl. thinking; grade median ~0.8k). Opus: 1–2 sample writers, 1 grading-answer writer (+1 re-call), 1 judge, translation check, audit, 2 reviewers ≈ 8 runs.",
  "k": "4/5",
  "models": [
   "haiku"
  ],
  "notMeasured": [
   "sonnet (cell stays Infinity; recorded in batch 0)"
  ]
 }
}

# 옮긴 절
## 1.12.0 처음 보는 코드 (G3): 모델은 코드(K) · 눈여겨볼 줄(L) · 찍히는 글자(A)만 쓰고, 플러그인이 확인해 문제를 짓고, 채점은 값만 옮겨 플러그인이 정함 (rungNewStep) · haiku

### 짓기 (두 모델 모두 끔, 3/5 함께 짓기 3f9084c · 4/5 짓기 f03b362)

설계 G3(1.12.0 G3-KLA final)의 코드는 G2의 코드와 한 메커니즘으로 3f9084c에 끈 스위치 뒤로 들어갔습니다(위 'G2+G3 함께 짓기'). 계획 묶음 3의 짓기 단계는 새 G3 코드 없이 지금 HEAD에서 다시 확인만 하고, SCOPE의 2026-11-14 09:1x 메모대로 퀴즈 호출이 빈 답이거나 시간 한도로 끊기면 그 퀴즈의 처음 보는 코드 개념도 세션 상태 quizRun.newMissed에 넣는 고침(5b112e9가 changedMissed에 한 것과 같음)을 넣었습니다: 짓기 커밋 f03b362. 무엇을 바꿨고 무엇을 확인했는지(실패 먼저 쓴 시험 3 · 끈 바이트 949/553/592 · d34g3 · 옛 창 여섯과 coexist19 · 돌연변이 탐침 5 · G2 haiku와 isRuleWide의 D26 재확인 · 관문)는 그 커밋 본문에 있습니다. hooks/notes.ts sha256 `4a86a55118245765c64a3ebe626602e22a260358aa98715b0c75c79c2b8bfbad` · hooks/register.tsx `ea49420a7d39c44e8e5498bb16f66d45907ca4a515e16b31263329d845de3b6f`. RUNG_NEW_STEP은 Infinity 그대로이고, MODEL_SWITCHES는 haiku `{ ...SWITCHES_OFF, isRuleWide: true, rungChangedStep: 2 }` · sonnet `{ ...SWITCHES_OFF, isRuleWide: true }` 그대로입니다(rungNewStep은 두 줄 모두 Infinity). 짓기 때의 얼린 입력 백업은 `impl112/backup/b3-build.tar` sha256 `251f0dd2209fd68cdaf0d73005ecbab933b44bfee4c2d05d0f6383f39b50aa90`(1,751,040바이트, 91항목; 묶음 1 감사 교훈 3: 백업 tar의 sha256은 견본.md에 적음)입니다.

### 기준 · 입장 · 결정 규칙 (재기 전에 정함: __BARTIME__ UTC, 견본을 쓰거나 모델을 부르기 전)

이 절은 공통 입장 절('1.10.0 모델별 갈래 (G7): 두 모델을 재는 공통 입장'의 M-0 ~ M-15, B-1 ~ B-15, R0 ~ R11)을 따릅니다. 그 글의 '1.10.0'은 '1.12.0'으로, '묶음 1 보정 기록'은 위 '### 보정 기록 (1.12.0)'으로 읽습니다(위 '1.12.0 미뤄 둔 기능 다시 설계' 절의 첫 항목). 같은 절의 '셈을 지키는 규칙'(CLI 고정 · 사용량 관문 · 끊긴 스테이지 규칙 · 러너 규칙 · 백업 규칙)과 '이름 목록'도 이 절을 다스립니다.

- 잰 설계: 설계 파일 `impl112/design/G3.json`(sha256 `7122dbfb27ee4004e6603906ae748a337982b4ac108cc29fd9a9ff0ca874c6b4`), 시제품 패치 `impl112/design/G3/proto/final/G3-final.diff`(`a4b83376cc61751c5ba6bfc5a41c75773b7819d0009bdd51c0c71c4aa1a598a9`). 계획 `impl112/plan112.json`의 묶음 3(4/5)입니다. 이 커밋이 가리키는 코드 커밋은 f03b362(2026-11-14 09:26 UTC 커밋)입니다(입장 머리말의 '가리키는 코드 커밋 해시'). G3 코드 자체는 3f9084c(06:04 UTC)에 들어갔고, f03b362는 그 위에 newMissed 고침만 더했습니다.
- 이 절의 기준 · 결정 규칙 · 모델마다 · 견본 · 부르기 · 위험 글은 설계의 bar · decisionRule · perModel · samples · calls · risks 필드와 계획 묶음 3의 barSource · samples · calls · judges · stop · d26Recheck · switchCommit · usage 글을 한국어로 옮긴 것입니다. 수와 조항은 하나도 바꾸지 않았습니다. 설계의 입장(stance)은 처음부터 한국어라 글자 그대로 옮겼습니다.
- M-0 대응: 입장 Q2의 상한 닿음(output_tokens ≥ 4600 + H_M)과 G-5의 채점 상한 닿음(output_tokens ≥ 480 + H_M) → M-5의 `output_tokens ≥ maxTokens + H_M`, 1.12.0 보정 기록의 H_haiku 2048. 그래서 haiku의 퀴즈 상한 닿음은 `output_tokens ≥ 6648`, 채점 상한 닿음은 `output_tokens ≥ 2528`, 끊긴 답의 탭 규칙은 '자리가 없는데 output_tokens < 6648'입니다(보정 기록의 상한 닿음 줄 표, 묶음 3 줄 셋과 같음). M-6: G3의 기준에는 토큰 절댓값 줄이 없어(수와 개수뿐) 바꿀 것이 없습니다(보정 기록의 M-6 표 'G2 · G3 · G6'). 판정자는 꼬리표마다 하나(입장 '판정 하위 에이전트', 설계 judges; D7: G가 정한 수)이고, 다시 보내기는 입장 Q2의 api-error 줄(한 번)과 M-4 셋째 줄(10%)입니다(아래 '읽는 법' 2).
- 수준: 견본은 beginner로 잽니다(켠 값도 beginner에서만 닿음, 1.10.0 계획 고침 D17).
- 잴 모델: haiku 하나. sonnet 칸은 Infinity 그대로이고 재지 않습니다(위 '1.12.0 설계만 하고 재지 않음'의 'G3 처음 보는 코드 (rungNewStep) · sonnet', 주인 물음 5의 기본값).
- 회차의 트리(M-13): haiku의 칸은 앞 묶음이 남긴 그대로(isRuleWide true, 묶음 2의 G2 결정 rungChangedStep 2)이고 그 위에 rungNewStep 4만 켭니다. 1.12.0 묶음 1의 isRuleDrill은 두 모델 모두 끔입니다.
- 앞선 칸 재확인(D26, 계획 묶음 3 d26Recheck): 짓기 커밋 전 작업 트리에서 isRuleWide haiku · sonnet은 `impl112/d26/rulewide.mjs`로 639경우 다름 0이었고, G2 haiku(rungChangedStep 2)는 얼린 요청 9/9가 바이트까지 같고 얼린 답을 다시 읽은 read.json도 같았습니다(sha256 05aa93f5…; 빠진 자리 0). isRuleDrill은 두 모델 모두 끔이라 해당 없습니다(f03b362 본문). 이 기준 커밋은 견본.md만 바꿉니다.
- localRight의 닫힌 목록(입장 G-6, 설계 bar L0 줄: 기준 커밋에서 sha256으로 얼림). f03b362의 hooks/notes.ts에서 각 목록 한 줄의 글 그대로(끝 줄바꿈 없이) 센 sha256입니다(짓기 단계의 `impl112/b3/said-lists.sha256`):
  - SAID_TAIL `e0730b63eed35695853be9816d5299e434fcd5b6337bd763135babcb082e5448`
  - SAID_HEAD `d3ca3da20d587b43352c6faf04c4d08447d27891d64b9ea397fdac18549604f9`
  - SAID_SPLIT `4eff0b4dd461ef88fd0851760d1005468666600ac472f02fae22e0eeb0c8a752`
  - SAID_FILLER `0e7df2d3a9829856fd00297f79e78abc27c160aa1bd9b469984d640e86d0512b`
- 주인 물음(위 '주인 물음 (기본값)' 5 · 6 · 7 · 8 · 9 · 18, 다른 답이 오지 않아 기본값): 5 — sonnet은 재지 않음. 6 — 좁힌 범위(js/mjs/cjs/py만; ts · 타입 수준 · 실행 차례 · 문자열 글자 개념 없음)를 받아들이고 그대로 잼. 7 — quizRun.newMissed(저장하지 않는 세션 상태)를 둠. 8 — haiku가 L로 평범한 값 줄을 들어 일반 힌트가 나가는 것을 그대로 두고 잰 퀴즈 프롬프트를 바꾸지 않음. 9 — 표시만으로 된 답('****', '---')이 1.9–1.11 창에서 가로줄로 보이는 것을 받아들이고 문서에 적음(표시만). 18 — 함께 짓기가 G3 시제품의 켠 요청 바이트를 다시 냈으므로(3f9084c 본문) G3 haiku는 잽니다.

#### 기준

출처: 설계 bar(아래 옮김)와 계획 묶음 3의 barSource. 설계 bar는 이 파일의 '1.10.0 처음 보는 코드 (G3)' > '기준 · 입장 · 결정 규칙'(888113d, 지은 코드 17c10c4)의 기준에서 수와 조항을 바꾸지 않고, 더 엄격한 것(L0, Q2의 M3)과 좁힌 범위(D33)만 더합니다.

설계 bar(옮김)
- 마지막으로 커밋된 기준에서 모든 수와 조항을 바꾸지 않습니다: docs/qa/견본.md '1.10.0 처음 보는 코드 (G3)' > '기준 · 입장 · 결정 규칙'(888113d, 지은 코드 17c10c4). 1.9.0 F3을 이어받고 G7 공통 입장 M-0..M-15, B-1..B-15, R0..R11이 다스립니다. 더 너그러운 것은 없습니다.
- Q1: 처음 보는 코드의 문제 30개(퀴즈 15개에서 잰 처음 보는 코드 자리 30개), 각각 입장의 일곱 조항을 모두 갖춤. 29개 이상이면 넘음; 26개 이하면 못 넘음; 27 또는 28이면 → 미리 얼린 둘째 세트 S-A2(30개)를 잽니다(S-A2로 같은 18 프롬프트 짜임을 한 회 더, 퀴즈와 채점), 그리고 합이 57/60에 닿아야 합니다. 돌려서 확인한 문제만 셉니다. 저장된 문항이 없는 자리(빈 답, 끊김, 읽기가 거절함)는 놓침입니다.
- Q2: 상한 닿음(output_tokens ≥ 4600 + H_M) 0, 빈 답(거절은 빈 답) 0, 시간 한도(90초) 0 — 퀴즈 15개와 M1, M2, M3에서(둘째 세트를 재면 30 + 3). 하나라도 있으면 Q2를 못 넘고 그 퀴즈의 모든 문제를 놓칩니다.
- Q3: U 개념 9개를 각각 편집 꼴과 새 파일 꼴로: 각 꼴에서 9개 가운데 적어도 8개가 처음 보는 코드가 아닌 길로 감; 라이브러리 흉내 코드 0; 실제로 저장된 처음 보는 코드 문제는 모두 조항 5를 넘어야 함.
- C1: 첫 시도의 맞는 답 → 맞음: 놓침 1 이하(31–60개를 채점하면 2 이하).
- C2 (a): 첫 시도의 한 값만 틀린 답 → 틀림: 놓침 3 이하(31–60이면 6). C2 (b): 같은 것을 모르겠어요 + 힌트 뒤에: 3 이하(6).
- C3: 첫 시도의 모두 틀린 답 → 틀림: 놓침 3 이하(6).
- C4 (a): 되묻기 뒤 다시 낸 맞는 답 → 맞음: 놓침 1 이하(2). C4 (b): 힌트 뒤: 1 이하(2). 30보다 작은 세트는 정한 수를 그대로 둡니다(C1/C4: 1, C2/C3: 3).
- 채점의 전제: 일곱 조항을 모두 넘은 문제가 적어도 10개일 때만 채점 견본 답을 씁니다; 그보다 적으면 C1–C4는 못 넘음입니다.
- 새로, 더 엄격함 — L0: 검증된 wrongOne이나 wrongAll 답이 첫 시도에서든 두 다시 하기 길 어느 쪽에서든 플러그인 안에서(localRight) 맞음으로 매겨진 것 0. 하나라도 있으면 그 모델은 못 넘습니다. localRight의 닫힌 목록(SAID_TAIL, SAID_HEAD, SAID_SPLIT, SAID_FILLER)은 기준 커밋에서 sha256으로 얼립니다. (이 묶음의 기록, 원문 밖: 위 네 sha256.)
- C1–C4의 셈 낱말(미리 커밋함; 입장 G-1에서 더 너그럽지 않다고 밝힘): 플러그인이 남기는 판정 — localRight의 맞음(모델 글 없음), 또는 값 줄과 값 가드로 valuesVerdict가 정한 것. 읽을 수 없는(값 줄이 빠진) 답, 빈 답, 시간 한도로 끊긴 답, 상한에 닿은 채점 답은 모든 칸에서 놓침이고, C2/C3도 그렇습니다.
- 채점 상한 닿음 = output_tokens ≥ 480 + H_M; 놓침입니다. (이 묶음의 기록, 원문 밖: H_haiku 2048 → 2528.)
- 쓰는 쪽 답 규칙: 채점 견본 쓰는 쪽의 답에 ```json 블록이 꼭 하나가 아니면 같은 프롬프트로 한 번 다시 부릅니다; 둘째도 아니면 그 꼬리표의 C1–C4는 못 넘음입니다. 세션이 블록을 고르지 않습니다. 탭과 다시 보내기의 파일 이름은 모델 이름이 아니라 꼬리표를 씁니다.
- 결정 규칙(모델마다): MODEL_SWITCHES[model].rungNewStep = 4 ⇔ Q1 ∧ Q2 ∧ Q3 ∧ C1 ∧ C2(a) ∧ C2(b) ∧ C3 ∧ C4(a) ∧ C4(b) ∧ L0; 아니면 Infinity. RUNG_NEW_STEP은 Infinity 그대로. 모델마다 한 회, 다시 재지 않음, 모델 사이에 옮기지 않음. 정해지지 않은 경우는 놓침(M-11). 꼬리표마다 판정자 하나; 판정자의 오류나 빠진 판정은 놓침.
- 상한의 문턱은 1.12.0 보정 뒤에만 수(4600 + H_M, 480 + H_M)로 적습니다; 회차 앞이나 뒤에 판이나 별칭이 다르면 그 회차는 무효이고 칸은 끔으로 남습니다(M-10, D19). (이 묶음의 기록, 원문 밖: 위 M-0 대응의 6648 · 2528.)
- 좁힌 범위(ts 없음; 타입 수준 · 실행 차례 · 문자열 글자 개념 없음; js/mjs/cjs/py만)는 개발 견본에 맞춘 것이 아니라 일반 메커니즘입니다: D33(잰 것 = 켠 것) 아래에서 견본은 플러그인이 묻는 모집단에서 뽑으므로, 모든 수가 그 모집단에서 뜻을 지킵니다. U 세트는 모두 js/mjs/cjs/py(js 5 · py 4)라 ts를 뺀 것이 Q3를 저절로 쉽게 하지 않습니다.
- Q2에 M3 [new, new, new]를 더함(더 엄격): 플러그인이 이 프롬프트 갈래(처음 보는 코드 아닌 자리 없음, 유형 블록 없음)를 낼 수 있으므로 잽니다; M1–M3의 문제는 1.10.0처럼 Q1에는 기록만 합니다.
- 기록만(1.10.0 규칙 5에 더해): 플러그인 안에서 매긴 몫(local-grade share); 옮긴 값의 충실도(줄마다 옮긴 값과 쓴 값); 값 가드가 뒤집은 수; 읽기가 뺀 까닭; 일반 힌트의 몫; 넓이를 넘은 코드 줄(> 48칸)과 힌트; 거절 · 빈 답 · 끊긴 답과 탭의 stop_reason; 상황을 건너뛴 것; output-token과 시간의 가운데 · 가장 큰 값; NEW_NOT_SAID 표시; 피드백과 판정의 어긋남; keptNudge가 버린 되묻기.

계획 묶음 3의 글(같은 기준, barSource summary): Q1 ≥ 29/30(27–28 → 미리 얼린 S-A2 세트를 재고 합이 57/60에 닿아야 함; ≤ 26 못 넘음); Q2 퀴즈 호출 18개에서 상한 닿음 0, 빈 답 0(거절 포함), 시간 한도 0(S-A2와 함께면 36: S-A2는 18 프롬프트 짜임 전체로 재고, M1–M3는 S-A2의 예비에서 오며, Q2는 36 호출 모두에서 셈); Q3 U 개념 9개 가운데 각 꼴에서 처음 보는 코드가 아닌 것 ≥ 8, 흉내 코드 0; C1 ≤ 1, C2(a) ≤ 3, C2(b) ≤ 3, C3 ≤ 3, C4(a) ≤ 1, C4(b) ≤ 1(31–60개를 채점하면 두 배); 새로 더 엄격한 L0 = 검증된 틀린 답의 플러그인 안 맞음 0; 채점은 넘은 문제가 10개 이상일 때만. 결정(barSource decision): MODEL_SWITCHES.haiku.rungNewStep = 4 ⇔ Q1 ∧ Q2 ∧ Q3 ∧ C1 ∧ C2(a) ∧ C2(b) ∧ C3 ∧ C4(a) ∧ C4(b) ∧ L0; 아니면 Infinity. RUNG_NEW_STEP은 Infinity 그대로. 옮긴 곳(barSource quotedFrom): docs/qa/견본.md '1.10.0 처음 보는 코드 (G3)' > '기준 · 입장 · 결정 규칙'(888113d, 지은 코드 17c10c4)에 설계가 더한 더 엄격한 것(L0, Q2의 M3)과 좁힌 범위(D33).

Q2의 셈을 읽는 법(계획 barSource q2Reading, 부르기 전에 하나로 정함): 설계 G3.json은 S-A2를 잴 때의 Q2 호출 수가 서로 맞지 않습니다 — bar의 Q2 줄은 '퀴즈 15개와 M1, M2, M3(둘째 세트를 재면 30 + 3)'라 하고, decisionRule은 '18(또는 36) 퀴즈 호출', bar의 Q1 줄은 '같은 18 프롬프트 짜임'이라 합니다. 이 절은 더 엄격한 하나로 읽습니다: **S-A2는 18 프롬프트 짜임 전체로 재고(M1–M3는 S-A2의 예비에서), Q2는 36 호출 모두에서 셉니다**(Q1 줄과 decisionRule에 맞음). 다른 읽기는 이 절에 없습니다.

1.10.0 기준과 다른 점(재기 전에 적는 까닭)
- 수(Q1 29/30 · 27–28이면 둘째 세트 57/60, Q2 0 · 0 · 0, Q3 8/9, C1 1 · C2 3 · C3 3 · C4 1, 31–60이면 두 배)와 단위(퀴즈 15개의 30자리, U 9개 두 꼴)는 같습니다.
- 더 엄격한 것 둘: L0(검증된 틀린 답의 플러그인 안 맞음 0)과 Q2의 M3. 셈 낱말은 1.10.0의 '모델이 쓴 판정 낱말'에서 '플러그인이 남기는 판정'으로 바뀌었고, 더 너그럽지 않은 까닭은 입장 G-1에 적었습니다(이 설계의 채점에는 판정 낱말이 없음).
- 잰 짜임: 범위가 좁아져(주인 물음 6: ts · 타입 수준 · 실행 차례 · 문자열 글자 개념 없음, js/mjs/cjs/py만) 잰 것 = 켠 것(D33)이 되도록 견본을 그 범위에서 씁니다. 퀴즈 꼴 [new, new, 내 코드]와 M1 · M2는 1.10.0과 같고 M3이 더해졌습니다.
- 상한 닿음의 H_M은 1.12.0 보정 기록의 값(H_haiku 2048)입니다. 1.10.0의 haiku H_M도 2048이었습니다(1.10.0 묶음 1 보정 기록).
- 1.10.0의 sonnet 칸 측정은 이 판에 없습니다(재지 않음).

#### 판정의 입장

설계의 입장(stance) 글입니다. 머리말, 조항 0–7, Q2, Q3, G-1–G-7, 판정 하위 에이전트, 미리 가른 경계 사례를 설계 글자 그대로 옮겼습니다(설계가 처음부터 한국어로 썼음). 판정은 이 글자대로만 셉니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 '다시 잴 때'에 적습니다(M-11).

판정의 입장 (G3, 1.12.0 G3-KLA). 기준 · 결정 규칙 · 짜임 · 견본 쓰기 프롬프트와 함께, 견본을 쓰거나 부르기 전에 docs/qa/견본.md 새 절로 한 커밋에 넣습니다(UTC 시각, 가리키는 코드 커밋 해시). 매기는 쪽은 이 글의 조항만 따르고 판정마다 조항 번호를 적습니다. ⚙ 조항은 eval 도구(부르기 전에 sha256으로 얼림)가 세고, ✎ 조항만 매기는 하위 에이전트(꼬리표마다 한 명)가 매깁니다. 1.10.0의 일곱 조항 번호와 뜻을 그대로 두고, 이 설계에서 쓰이지 않는 갈래는 "쓰이지 않음"으로 적었습니다. 이 글이 정하지 않은 경우는 못 넘음입니다(M-11).

0 셈의 단위: Q1은 15퀴즈의 처음 보는 코드 자리 30개(둘째 묶음을 재면 60개)입니다. M1 · M2 · M3의 처음 보는 코드 자리는 Q1에 넣지 않고 기록만 하며 Q2에는 넣습니다. 같은 퀴즈의 내 코드 · 왜 · 다시 도전 문항은 셈 밖이고 기록만 합니다. Q3는 U 개념 아홉의 두 꼴(편집 · 새 파일)입니다.

1 읽기 ⚙: 플러그인처럼 fixEscapedTicks → 그 커밋의 parseQuiz로 읽어 저장될 문항(question · hint · answer · kind · rung)만 매깁니다. 모델의 K · L · A 날글, 상황 줄, 되풀이해 쓴 앞의 K · L · A(나중 것이 읽힘), A 아래 빈 줄 뒤의 글은 저장되지 않으므로 판정 대상이 아닙니다. 1을 넘으려면 그 자리의 문항이 저장되어 rung new · kind predict이고 question(펜스 하나) · hint · answer가 모두 있어야 합니다. 플러그인 읽기가 그 자리를 거절해 문항이 없으면(missing · blocks · lang · comment · string · long · forbidden · spacing · print-form · print-place · print-count · output · count · mine · question-long) 1에서 놓침이고 거절 까닭은 기록만 합니다. 코드 없이 물은 문제는 생길 수 없고, 생기면 1에서 놓침입니다.

2 꼴 ⚙: 저장된 question 안의 펜스 블록이 꼭 하나이고(플러그인이 씀), 펜스 안에서 공백뿐인 줄을 뺀 줄이 8 이하입니다. 판정은 학습자가 보는 그대로, 곧 플러그인이 주석을 지운 뒤의 코드로 합니다. 언어 무리: js = js · javascript · mjs · cjs · node, py = py · python · python3; 플러그인 펜스(js 또는 python)는 물은 언어(파일 확장자)의 무리와 늘 같아야 하며 다르면 놓침입니다. ts는 이 설계에서 쓰이지 않음(ts 개념은 처음 보는 코드로 묻지 않음).

3 내 코드가 아님: 문제 코드와 그 개념 견본의 code를 견줍니다. ⚙ (가) 공백을 모두 뺀 두 글이 같음. ⚙ (나) 문제 코드의 줄(공백뿐인 줄과 괄호 · 중괄호 · 대괄호 · 쉼표 · 세미콜론 · 콜론만 있는 줄은 뺌) 가운데 절반 이상이, 공백을 뺀 꼴로 개념 코드의 어느 줄과 같음. ⚙ (다) 두 코드의 이름(식별자; 그 언어의 예약어와 console · print · len · range · str · int · float · list · dict · Math · Object · Array · JSON · String · Number는 그대로)을 처음 나온 차례대로 v1, v2 …로 바꾸고 공백을 뺀 뒤 같거나, 다른 곳이 리터럴(숫자 · 문자열) 하나뿐임(개념 코드 전체나 같은 줄 수의 이어진 줄과 견줌). ✎ (라) 판정 하위 에이전트가 같은 상황(이름 · 값 · 쓰임이 모두 개념 코드와 같은 일)이라고 이유와 함께 적음. 넷 가운데 하나면 놓침입니다. 같은 메서드 · 연산자나 흔한 예(정렬 기본 순서 · map · reduce · 클로저 push)를 쓴 것, 플러그인이 준 상황 이름을 쓰지 않은 것만으로는 놓침이 아닙니다. 흔한 예를 이름과 값을 바꿔 다시 쓴 것은 (다)에 걸리지 않고 이름 · 값이 다르면 (라)에서 넘음입니다(1.10.0 셈 그대로; 개발 기록 set1 T07).

4 개념이 출력을 정함 ✎: 출력의 적어도 한 줄이 개념 견본 blurb가 말한 동작으로 정해져야 합니다(그 동작을 모르면 그 줄을 맞힐 수 없음). 판정 하위 에이전트가 이유 한 줄과 함께 매깁니다. 판정은 6의 꼴로 맞춘 출력(줄 앞뒤 공백을 떼고 안쪽 공백을 하나로)에 대해 합니다: 공백에만 드러나는 동작은 그 꼴에서 보이지 않으므로 놓침입니다. 개념의 동작이 일어나지 않게 짠 코드(가변 기본 인자를 한 번만 부름, 클로저를 반복 안에서 바로 부름, 얕은 복사를 고치지 않고 찍음)는 놓침입니다(개발 기록 set1 N02-r2#1 T07). 그 동작을 모르는 학습자가 흔한 짐작으로 맞히게 되는 줄만 있으면 놓침이고, 다른 한 줄이라도 그 동작에 달렸으면 넘음입니다. 타입 표기 · 실행 순서 · 문자열 글자 개념은 이 설계의 범위 밖이라 견본에 없어야 하며, 있다면 이 조항대로 매깁니다.

5 돌림 ⚙: 보인 그대로 돌립니다(보이지 않는 정의 · import · 입력 · 파일 · 환경 · 앞선 상태를 채우지 않음; B-1, B-2). 빈 임시 폴더에서 `unshare -n timeout 5`: js는 node로 두 번, 모듈 문법 오류일 때만 .cjs로 한 번 더; py는 B-14(`env -i PATH="$PATH" LANG=C.UTF-8 PYTHONHASHSEED=<n> python3 -s -P -B 파일`, n = 1~5, 다섯 번 모두 같아야 함). 끝 코드 0, 같은 출력. 금지 기능(grep 뒤 하위 에이전트가 쓰임인지 확인; 문자열 · 주석 안 낱말은 쓰임이 아님): js Math.random · Date · performance. · fetch · XMLHttpRequest · WebSocket · require( · import · process · fs · document · window · localStorage · sessionStorage · alert( · prompt( · readline; py random · time · datetime · input( · open( · os · sys · subprocess · socket · urllib · requests · pathlib. 출력은 끝 줄바꿈 하나를 떼고 3줄 이하, 줄마다 40 코드 포인트 이하. 위 목록에 없는 표준 기능(math, functools, itertools …)과 플러그인 읽기가 더 막는 것(set, 타이머 등)은 이 조항의 금지가 아닙니다(읽기가 막으면 1에서 놓침).

6 A와 출력 ⚙: 저장된 answer와 stdout을 견줍니다. stdout은 끝 줄바꿈 하나를 떼고 줄로 나눕니다. 줄마다 앞뒤 공백을 떼고 안쪽 공백 · 탭이 이어진 곳을 하나로, 줄 끝 마침표 하나를 떼고, 따옴표의 종류(' " ` ‘ ’ “ ”)만 같게 봅니다. 따옴표가 있고 없음은 다름입니다. 값 · 순서 · 줄 수(빈 줄 포함)는 그대로 봅니다. True와 true, None과 null, 1과 1.0은 다른 값입니다. stderr는 보지 않습니다. 틀리게 짐작한 A(`'pythonista'[7:]` → ista, 개발 기록 R18 44 대 45)는 놓침입니다. 일부 줄만 묻는 문제의 셈(A가 출력 전부면 넘음, 물은 줄만 적었으면 놓침)은 1.10.0 그대로 두지만, 플러그인의 질문이 늘 출력 전부를 묻고 A가 찍는 호출 수만큼의 줄이어야 저장되므로 쓰이지 않습니다.

7 힌트 · 문제가 답을 말하지 않음: ⚙ 기계 규칙: H나 Q의 글(펜스 밖)에 출력 줄의 값(6의 꼴, 두 글자 이상)이 낱말로 들어 있고 그 값이 문제 코드 안에 리터럴로 없으면 놓침입니다. 플러그인의 질문 글(NEW_LEAD · NEW_LEAD_LINES)과 힌트 틀은 모델 글과 똑같이 이 규칙으로 봅니다. ✎ 그 밖은 판정 하위 에이전트가 이유와 함께 매깁니다. 힌트가 보인 코드의 한 줄을 그대로 옮긴 것(`…` 줄에서 무슨 일이 일어나는지부터 보세요)은 그 줄에 리터럴로 든 값이 있어도 그것만으로 놓침이 아닙니다(학습자가 이미 보는 줄). 옮긴 줄이 보인 코드의 줄이 아니면 놓침입니다(더 엄격; 플러그인은 그런 힌트를 만들지 않음). 고정 힌트 NEW_HINT_PLAIN은 넘음입니다.

Q2 퀴즈 답의 상태 ⚙: 빈 답(empty-reply; API 거절 stop_reason refusal은 엔진이 빈 답으로 넘기므로 빈 답) · 시간 한도(90초)에 끊긴 답 · 상한 닿음(output_tokens ≥ 4600 + H_M)은 그 퀴즈의 모든 처음 보는 코드 자리를 놓침으로 하고 Q2를 못 넘음으로 합니다. 상한에 닿지 않았는데 글 가운데에서 끊겨 자리가 빠진 답(cut)은 빠진 자리가 1에서 놓침이고 Q2 자체는 위 셋에 들 때만 놓침입니다; cut과 빈 답은 모두 tap으로 한 번 다시 보내 stop_reason을 기록만 합니다(B-12). api-error(답 전 오류)만 한 번 다시 보내고, 다시도 api-error면 빈 답입니다. M-4 셋째 줄(남은 api-error가 한 스테이지 호출의 10% 초과면 그 스테이지 무효)은 그대로입니다.

Q3 부를 수 없는 개념 ⚙✎: 한 U 개념은 그 꼴에서 committed rungOf가 new가 아니면(범위 밖 · 라이브러리 · NEW_UNRUNNABLE 포함) 처음 보는 코드가 아닌 길입니다. new였고 U 퀴즈로 불렸는데 플러그인 읽기가 그 자리를 거절해 문항이 없으면, 학습자에게 처음 보는 코드로 아무것도 보이지 않았으므로 처음 보는 코드가 아닌 길입니다(1.10.0의 "parseQuiz 뒤 rung이 남지 않음"과 같은 셈). 문항이 저장되었으면 처음 보는 코드로 간 것이며 5를 넘어야 합니다. 흉내 코드(라이브러리 · 프레임워크 · 브라우저 · 네트워크의 이름이나 동작을 손으로 만든 함수 · 객체로 흉내 냄)는 판정 하위 에이전트가 이유와 함께 매기며 하나라도 있으면 Q3 못 넘음입니다.

G-1 채점의 셈 낱말 ⚙: 셈 낱말은 플러그인이 남기는 판정입니다. (1) localRight가 맞음이라 한 답은 모델을 부르지 않고 맞음으로 셉니다(모델 글 없음). (2) 그 밖은 parseCheck(fixEscapedTicks(text), { exact: answer, mine })의 verdict입니다: 값 줄로 valuesVerdict가 정한 맞음 · 틀림. 모델이 판정: 줄이나 거의를 써도 읽지 않습니다. 이것이 1.10.0(쓴 낱말)보다 느슨하지 않은 까닭: localRight는 맞음만 말하고, 실행으로 확인한(6) answer와 값마다 같을 때만 말하며, L0가 틀린 답의 지역 맞음을 하나라도 막습니다; 모델 길의 맞음은 옮긴 값이 줄마다 같고, 학습자가 쓴 글에 그 값이 저마다 제자리로 있고, 값 더가 없을 때만입니다; 값 줄이 빠진 답 · 빈 답 · 시간 한도 · 상한 닿음은 C2 · C3에서도 놓침입니다(쓴 낱말 셈에서는 그런 답이 틀림 기대 묶음에서 넘을 길이 없었던 것과 같음). 1.10.0이 쓴 낱말로 센 까닭(플러그인의 읽기가 모델 낱말과 달랐음)은 낱말이 없는 이 채점에 해당하지 않습니다. 셈 낱말과 다른 기록(피드백과의 어긋남, 옮긴 값 충실도, 가드가 뒤집은 수)은 기록만 합니다.

G-2 기대 판정: 기대 판정은 얼린 견본 꼬리표로 정합니다(right · again → 맞음, wrongOne · wrongAll → 틀림). 답을 본 뒤 다시 매기지 않습니다. 부르기 전에 무효로 적은 답만 뺍니다.

G-3 견본 답의 유효성 ⚙✎: 부르기 전에 도구가 보고, 그 꼬리표의 판정 하위 에이전트가 확인합니다. 학습자 값의 규칙(isSameValue와 같음): 앞뒤 공백 · 안쪽 공백 하나 · 따옴표 종류 · 끝 마침표 하나를 맞추고, 찍힌 줄에 감싼 따옴표가 없을 때만 학습자가 감싼 따옴표를 뗍니다(찍힌 줄이 'abc'면 abc는 다른 값). 조사 · 말투 · 덧붙인 까닭은 값이 아닙니다. right · again: 찍힌 줄마다 그 값이 차례대로 모두 있고, 다른 값을 줄 값으로 말하지 않아야 합니다; 찍힌 줄에 쉼표가 있는 문항은 줄을 바꿔 써야 하고 쉼표로 이은 답은 무효입니다; 줄인 값은 무효; again이 right와 같은 글이면 무효. wrongOne: 줄 수가 같고 꼭 한 줄의 값만 다름(따옴표만 다른 것도 찍힌 줄에 따옴표가 있으면 다름). wrongAll: 어느 자리에서도 찍힌 값과 같은 값이 없음(전체 순서 뒤바뀜 포함). 찍히는 글자가 다른 꼴(1과 1.0, True와 true)은 맞는 답으로 쓰지 않습니다.

G-4 경로: 첫 시도: right · wrongOne · wrongAll. 힌트 뒤(C2 (b) · C4 (b)): first = { mine: '모르겠어요', verdict: 'wrong', feedback: '', nudge: item.hint }; again · wrongOne. 되묻기 뒤(C4 (a)): 첫 시도 wrongOne의 남긴 판정이 맞음이 아니고 keptNudge가 되묻기를 남긴 문항만 again을 부릅니다(first = { mine: wrongOne, verdict: 남긴 판정, feedback, nudge }); 되묻기가 버려진 문항은 그 묶음에 들지 않고 수만 적습니다. 둘째 답의 셈은 남긴 verdict가 맞음일 때만 넘음입니다(secondVerdict도 그때만 right). localRight는 세 경로 모두에서 먼저 봅니다.

G-5 채점 답의 상태 ⚙: 값 줄이 하나라도 빠져 읽지 못함(undefined) · 빈 답 · 시간 한도(60초) · 상한 닿음(output_tokens ≥ 480 + H_M)은 그 견본에서 놓침입니다(어느 묶음이든). 다시 부르지 않습니다(api-error 규칙 제외).

G-6 L0 ⚙: 유효한 wrongOne · wrongAll이 어느 경로에서든 localRight로 맞음이 되면 하나라도 L0 못 넘음입니다. localRight의 닫힌 목록은 커밋에서 sha256으로 얼립니다.

G-7 견본 쓰기 답의 블록 ⚙: 채점 견본 쓰기 하위 에이전트의 답에 ```json 블록이 꼭 하나가 아니면 같은 프롬프트로 한 번 다시 부릅니다. 다시도 꼭 하나가 아니면 그 꼬리표의 C1~C4는 못 넘음입니다. 재는 세션이 블록을 고르지 않습니다(1.10.0 M-11의 교훈).

판정 하위 에이전트: 꼬리표마다 한 명(G3 1.10.0 그대로)이 이 입장 글과 문항별 자료(저장된 question · hint · answer, 돌린 stdout, 개념 견본의 name · blurb · code)만 받습니다. 모델 이름, 다른 꼬리표, 토큰 · 시간은 받지 않습니다. 판정마다 조항 번호와 이유 한 줄을 씁니다. 판정이 빠지거나 읽히지 않으면 놓침입니다.

1.9.0 · 1.10.0 기록과 개발 답이 부딪힌 경계와 정한 셈:
- A를 산문 · 설명으로 씀(1.9.0 1차 22): 읽기가 거절 → 1 놓침.
- A를 " / "로 한 줄에 이음(N05Q1 · N05Q3), 쉼표로 이음: 찍는 호출 수와 줄 수가 다르거나 기호가 코드 문자열에 없어 거절 → 1 놓침.
- A 줄 수가 찍는 호출 수와 다름: 거절 → 1 놓침.
- 코드 없이 왜로 물음(1.9.0 1): 문항이 생기지 않음 → 1 놓침.
- 코드 9줄 · 10줄(1.9.0, sonnet 개발 long): 거절 → 1 놓침.
- 반복문 · 함수 · 조건 · 콜백 안의 찍기(haiku 개발 set1 r2 둘): 거절(print-place) → 1 놓침. 같은 줄에 몸이 있는 if · for 아래 맨 바깥 찍기는 거절하지 않음.
- 찍기 하나에 값 여럿(쉼표 · end= · sep= · *xs · ...xs): 거절 → 1 놓침.
- A가 틀림(`'pythonista'[7:]`, R18 44 대 45): 6 놓침.
- 내 코드와 거의 같은 코드(let 블록 범위, N02Q1 클로저 push, N09Q1 5/6줄): (가)(나)(다)는 읽기가 먼저 거절(1 놓침), 남은 것은 (라).
- 흔한 예를 이름 · 값만 바꿈(set1 T07): (다)에 안 걸리면 (라)에서 넘음.
- 비슷한 흔한 예(sort 기본 순서 · map · reduce): (가)~(라)에 안 걸리면 넘음.
- 개념의 동작이 일어나지 않는 코드(set1 N02-r2#1 가변 기본 인자 한 번 부름): 4 놓침.
- 타입 표기 개념(N11): 범위 밖; 견본 검사에서 빠져야 하며 들어오면 4 놓침.
- 실행 순서 개념(N03 setTimeout과 Promise): 범위 밖; 들어오면 그대로 매김(대개 읽기 거절 → 1 놓침).
- 문자열 글자 개념(역순 슬라이싱 · 회문 · 패딩, 개발 R17 · R18 · set1 R01): 범위 밖. 범위 안 개념에서 모델이 라틴 글자를 뒤섞은 출력('mpl', 'miws')을 쓰면 읽기 거절 → 1 놓침; 한글은 음절 단위로 읽으므로 '사코기' 같은 첫 글자 모음은 저장되어 6으로 매김.
- 되풀이 조각 출력('****', 'abab', '====장미===='): 저장되어 6으로 매김(옛 창의 마크다운 표시는 판정과 상관없음).
- 찍힌 줄에 쉼표(T06 '7,NaN,NaN'): 질문은 쉼표로 잇기를 권하지 않는 NEW_LEAD_LINES; 채점 견본의 맞는 답은 줄을 바꿔 씀(G-3).
- 없음 · None · - 을 찍음: 혼자인 기호 한 글자 줄('-')은 읽기 거절(1 놓침, 최종 탐침 P5); 없음 · None은 저장되고 채점은 isSameValue와 가드로 봄.
- 공백이 뜻을 지니는 출력(rjust · 폭 지정 · 공백 되풀이 · 안쪽 두 칸): 읽기 거절(spacing) → 1 놓침; 문자열 양 끝 공백(strip 개념)은 허용하고 4 · 6은 맞춘 꼴로 봄.
- 주석이 든 코드: 줄 주석은 플러그인이 지운 뒤로 매김; 블록 주석 · 세 따옴표 문자열은 거절(1 놓침).
- 모델이 K · L · A를 다시 씀(자기 고침): 나중 것이 저장됨; 저장된 것만 매김.
- A 아래 빈 줄 뒤의 메모: 출력이 아님; 저장되지 않음.
- 힌트가 값만 넣는 줄을 가리킴(haiku 개발 약 20/69): 이제 고정 힌트로 바뀜; 어느 쪽이든 7 넘음(기록: 고정 힌트 비율).
- 상한에 닿아 셋째 문제가 없음(1.9.0 N01 · N11): 그 자리 1 놓침, Q2 놓침.
- 빈 답 · 거절(1.10.0 sonnet N08): 그 퀴즈 모든 자리 놓침, Q2 놓침.
- 상한 아래에서 글 가운데 끊김(1.10.0 sonnet N04 · N05 · N12 · N15): 빠진 자리 1 놓침; tap stop_reason 기록.
- 채점: 한 값만 틀린 답을 거의(1.9.0 9): 이 채점에는 판정 낱말이 없음; 값 줄로 틀림.
- 채점: 쉼표로 이은 맞는 답을 틀림(N15Q1 · N08Q3 · N13Q3): localRight 또는 값 줄로 셈.
- 채점: 대조가 모두 같음인데 틀림, 대조 안에서 뒤집음, 첫 시도 값을 둘째 답으로 읽음(1.10.0 C4): 이 채점에는 대조 · 판정이 없고 첫 시도 값이 프롬프트에 없음; 남긴 판정으로 셈.
- 채점: 모델이 옮긴 값이 학습자 글에 없음(모범 답을 베낌) 또는 한 번 쓴 값을 두 줄에 씀: 틀림(가드).
- 채점: 값을 백틱 · 따옴표로 감싸 옮김: isSameValue와 가드가 감싼 쌍을 뗀 꼴도 봄.
- 채점: 값 줄 대신 판정: 줄만 씀: 읽지 못함 → 놓침.
- 채점 피드백이 맞은 줄을 인정 · 판정과 어긋남: 셈과 상관없음(기록만).
- 따옴표를 붙인 A(`'abc'`)와 따옴표 없이 찍힌 출력: 읽기가 대개 거절(따옴표가 코드 문자열 안에 없음) → 1 놓침; 저장되면 6 놓침.
- True와 true, None과 null, 1과 1.0: 다른 값.
- 보이지 않는 정의(1.9.0 W10): 보인 그대로 돌림, 오류면 5 · 6 놓침.

#### 결정 규칙

설계 decisionRule(옮김)
- 모델 m마다, m의 셈만으로(R1–R4): Q1 = 잰 처음 보는 코드 자리 30개 가운데 저장된 문항이 조항 1–7을 갖춘 수(읽기가 거절했거나 읽히지 않았거나 돌아오지 않은 자리, 판정자의 갈림, 정해지지 않은 경우 = 놓침); Q1 ∈ {27, 28}이면 S-A2를 같은 짜임으로 재고 60개의 합이 ≥ 57이어야 합니다. Q2 = 18(또는 36) 퀴즈 호출에서 상한 닿음 0, 빈 답 0(거절 포함), 시간 한도 0. Q3 = 각 꼴에서 U 개념 9개 가운데 적어도 8개가 처음 보는 코드가 아닌 길, 흉내 코드 0, 저장된 U 문항은 모두 조항 5를 넘음.
- Q1에서 넘은 문제가 10개보다 적으면 C1–C4는 채점 없이 못 넘음입니다. 아니면 칸마다 남긴 판정으로 놓침을 셉니다(입장 G-1): C1 ≤ 1, C2(a) ≤ 3, C2(b) ≤ 3, C3 ≤ 3, C4(a) ≤ 1, C4(b) ≤ 1(31–60개를 채점하면 두 배; 30보다 작은 세트는 정한 수 그대로); L0 = 검증된 틀린 답의 플러그인 안 맞음 0.
- 넘음 ⇔ Q1 ∧ Q2 ∧ Q3 ∧ C1 ∧ C2(a) ∧ C2(b) ∧ C3 ∧ C4(a) ∧ C4(b) ∧ L0.
- 넘음 → 결정 다음 커밋에서 MODEL_SWITCHES[m].rungNewStep = 4, tests/route.test.ts SHIPPED가 견본.md 결정 표와 같음, 켠 값으로 옛 빌드 확인을 다시 돌림(R9), README/CHANGELOG에 모델 이름(문서 단계). 못 넘음 → Infinity. RUNG_NEW_STEP은 Infinity 그대로.
- haiku는 잽니다; sonnet은 1.12.0에서 재지 않습니다(칸은 Infinity 그대로). 미리 정한 파일럿 관문(D2 회마다 Q1에 해당하는 수 ≥ 28/30이고 남은 ≥ 60개 가운데 틀린 답 ≤ 1) 때문이고, sonnet은 한 회에서 26이었습니다.
- 보정과 판이나 별칭이 다르면 그 회차는 무효입니다(칸 끔, 1.12.0에서 다시 재지 않음). 회차 뒤에 잰 프롬프트나 읽기를 바꾸면 칸은 끔이 됩니다(D26 재확인); 읽는 코드만 바꾸면 같은 얼린 답을 다시 읽고, 못 넘은 것은 켬이 되지 않습니다(R5, D22).

계획 묶음 3의 글(같은 규칙): decision — MODEL_SWITCHES.haiku.rungNewStep = 4 ⇔ Q1 ∧ Q2 ∧ Q3 ∧ C1 ∧ C2(a) ∧ C2(b) ∧ C3 ∧ C4(a) ∧ C4(b) ∧ L0; 아니면 Infinity. RUNG_NEW_STEP은 Infinity 그대로. 넘으면(switchCommit): MODEL_SWITCHES.haiku.rungNewStep = 4; route SHIPPED; 켠 값으로 옛 빌드 확인(실제 빌드 여섯 3f2b4fb (1.7.0) · 7a7b08c (1.7.1) · 3690021 (1.8.0) · fca5988 (1.9.0) · 3d2f251 (1.10.0) · de98243 (1.11.0))과 coexist19; G7 교차 경로 시험 둘; 잰 프롬프트를 다시 만들어 바이트까지 같음; 값 트리에서 G2 haiku 재확인.

멈춤(계획 묶음 3 stop, 부르기 전에 이 커밋에 적음)
- Q1 ≤ 26(S-A2와 함께면 합 < 57), 또는 Q2나 Q3가 못 넘음 → 결정은 이미 Infinity입니다; 사용량을 아끼려고 채점 스테이지는 건너뜁니다. 이 건너뛰기 규칙은 부르기 전에 기준 커밋에 적습니다(결과를 바꿀 수 없음; C 칸은 '돌리지 않음'으로 적음). 넘은 문제가 10개보다 적으면 → C1–C4는 채점 없이 못 넘음(기준).
- Q1 ∈ {27, 28} → S-A2를 18 프롬프트 짜임 전체로 잽니다(M1–M3는 S-A2의 예비에서; 퀴즈와 채점). 허락된 둘째 세트는 이것뿐이고, Q2는 36 퀴즈 호출 모두에서 셉니다.
- checkPrompt {rule} 요청 바이트(G6 N2)나 N2/단계 고르기가 묶음 1과 다름(D26 (가)/(나)) → 그 isRuleDrill 칸은 끔(R5). (이 묶음의 기록, 원문 밖: 묶음 1에서 isRuleDrill은 두 모델 모두 끔이라 해당 없음.)
- parseCheck {rule}이나 ruleFixReply 읽기가 다름(D26 (다)) → 얼린 N2와 단계 2 답을 새 읽기로 다시 읽음; 그 isRuleDrill의 넘음은 그래도 넘을 때만 남음. (같은 기록: 해당 없음.)

#### 모델마다 (설계 perModel; 잼 · 재지 않음은 결정 규칙과 같고, 개발 수는 기록만 · B-12, 결정에 들지 않음)

- haiku: 잼. 개발 기록(기록만): 마지막 퀴즈 프롬프트(rev1, 그 뒤로 바뀌지 않음)를 새 개발 세트 2에서 잰 짜임으로, 퀴즈마다 두 번, 마지막 읽기로: Q1에 해당하는 수 29/30과 29/30(두 회 모두 빠진 것은 R17 거꾸로 슬라이싱뿐이고, 이제 isStringShape로 범위 밖: 범위 안 자리에서 29/29), 남은 58개에서 틀린 답 0, 판정자 놓침 72문항에서 0; Q2 상한 닿음 0(가장 큰 것 3075 대 6648, 가운데 2371), 빈 답 0, 거절 0, 끊김 0(세트 1의 자리 빠짐 하나를 탭으로 다시 보냄: end_turn); Q3 두 꼴 모두 9/9, DN 8/8 처음 보는 코드 아님. 채점: 파일럿 갈래 b가 48문항(세트 1과 2)에서 모든 칸 놓침 0; 마지막 채점을 세트 2에서 실제 개념 이름으로 다시 확인: C1 0/20, C2a 0/20, C2b 0/20, C3 0/20, C4a 0/20, C4b 0/20, L0 0, 읽지 못함 0, 가장 큰 것 1675토큰(H 2048에서 상한 2528); 얼린 파일럿 채점 답 382개를 값 가드로 다시 읽음: 판정 바뀜 0. Q1은 기준에 걸쳐 있습니다: 첫 세트에서 29 이상일 가능성은 대략 반반이고, 둘째 세트로 갈 가능성이 실제로 있습니다.
- sonnet: 재지 않음. 마지막 글로 개발 세트 2: Q1에 해당하는 수 28/30과 26/30(범위 안 27/29와 26/29), 남은 55개에서 틀린 답 1(R18 44 대 45), 읽기가 뺀 것 long 1 + 1과 문자열 글자 출력 1 + 2; 320호출에서 거절 · 빈 답 · 끊긴 답 0(거절 가설이 맞음); 채점은 49문항에서 놓침 0이지만 H_sonnet이 0이면 480 상한에 대해 가장 큰 것 424 출력 토큰. Q1 기준 아래이고 미리 정한 sonnet 관문 아래입니다.

#### 견본의 짜임

설계 samples 글(옮김)
- 잰 견본은 기준 커밋 뒤에, 규칙 글 · 프롬프트 · 입장 · 설계 · 코드나 어느 모델을 재는지를 보지 않는 새 가린 하위 에이전트(`claude -p --model opus --tools ''`, DISABLE_AUTOUPDATER=1)가 씁니다. 어느 부르기보다 먼저 얼리고(chmod 444, sha256, 쓴 쪽, UTC) docs/qa/견본.md에 적습니다.
- S-A1(첫 세트): 개념 기록 34개, 모두 js/mjs/cjs/py 통째 파일 만들기: T 까다로운 함정 개념 10 + 예비 2, R 기본 개념 20 + 예비 2; 잴 것 js 16 · py 14. 하나마다: id, name, blurb(합니다체 1–2문장 + " — " + 파일의 찍지 않는 코드 한 줄을 백틱으로), file, code(공백 아닌 줄 3–8, 혼자 돎, 결정적, 40 코드 포인트 이하 줄 1–3개를 찍음), output. ts 없음, 타입 수준 · 실행 차례 · 문자열 글자(slice/reverse/pad/palindrome) 개념 없음; 얼린 기록마다 얼리기 전에 커밋된 rungOf + ladderMixed로 new에 닿아야 함; 못 넘은 기록은 id 차례로 예비가 바꾸고 기록함; 남은 예비가 없는 자리는 그대로 두고 놓침으로 셈.
- 이름은 플러그인의 꼴로: 짧은 개념 이름(예: "var 반복문 클로저", "기본 정렬 순서")이고 "<주제>: <상황>"이 아님; 쓰는 쪽이 상황 구절을 주면 그것은 NAMES.txt에만 넣음. 앞선 세트와 겹치지 않음은 (name, blurb, code)로 봅니다: 공백을 뺀 뒤 같은 이름 없음, 같은 blurb 인용 줄 없음, 아래 세트들의 어느 기록과도 조항 3 (가)(다)로 같은 code 없음.
- 쓰는 쪽 프롬프트에는 보기 이름을 넣지 않고(개발 쓰는 쪽의 "문자열 반복: 구분선을 별표로 만들기"가 되풀이 개념을 심었음), 개발 몫은 최소로만 둡니다: 이름난 함정 적어도 5, 흔히 반복 안에서 찍어 보이는 개념 적어도 4, 문자열을 찍는 개념 적어도 3, True/False/None을 찍는 py 개념 적어도 3, 본디 3줄을 찍는 개념 적어도 3.
- S-A2(둘째 세트, S-A1과 함께 얼림, Q1이 27 또는 28일 때만 씀): 같은 꼴의 기록 34개 더, 이름은 겹치지 않음.
- S-O 채우는 것: 코드가 있는 내 코드 개념 2(js, py), 다시 도전 slip 2, 왜에 쓸 코드 없는 개념 2; S-A1의 예비 4개가 M1–M3를 채움.
- S-U: 부를 수 없는 개념 9(js 5 · py 4: 조각 밖의 라이브러리 import, jQuery $(, 데코레이터, fetch/XHR/WebSocket, process./node: I/O), 각각 도구가 편집 꼴(import는 조각 밖, 작업 트리의 파일 글을 줌)과 새 파일 꼴로 지음.
- 짜임(18 프롬프트): 퀴즈 15개 [new, new, 내 코드] 단계 4/5를 번갈아, 내 코드 자리를 돌려 가며, 처음 10개는 T + R, 마지막 5개는 R + R; M1 [다시 도전, new, new]; M2 [다시 도전, new, 코드 없는 왜]; M3 [new, new, new]; U 개념이 한 꼴에서 new에 닿을 때만 U 퀴즈 하나. 상황의 날은 재는 날입니다(프롬프트 파일마다 적음).
- 채점 답: 꼬리표마다, 퀴즈 스테이지 뒤에, 새 가린 쓰는 쪽이 남아서 넘은 문항마다(question, answer, hint) right, again, wrongOne, wrongAll을 입문자 말투로 씁니다(3번째마다 right는 쉼표로 이음, 찍힌 줄에 쉼표가 있으면 빼고; 5번째마다 짧은 까닭을 붙임). 기계로(입장 G-3) 그다음 그 꼬리표의 판정자가 검증하고, 어느 채점 호출보다 먼저 얼립니다. 답에는 ```json 블록이 꼭 하나여야 합니다; 아니면 같은 프롬프트로 한 번 다시 부르고; 그것도 아니면 그 꼬리표의 C1–C4는 못 넘음입니다.
- 겹치지 않을 이름(설계 mustNotOverlapNames): 1.8.0–1.11.0의 모든 견본 이름(docs/qa/견본.md), 1.10.0 S-A1/S-A2/S-U; G3 개발 세트 1과 2 `impl112/design/G3/dev/NAMES.txt`(각 34 + 23 기록, 예: var 반복문 클로저, 기본 정렬 순서, 느슨한 비교, 얕은 복사, 문자열과 숫자 연산, forEach 안의 return, 가변 기본 인자, 리스트 곱셈 함정, 나눗셈 두 종류, 0의 참거짓, return 빠뜨리기, 순회 중 삭제, 앞자리 채우기, 배열 map/filter/reduce, 객체 구조 분해, for...of 반복, 삼항 연산자, Object.keys 길이, 배열 includes, 대문자 변환, while 카운트다운, 기본 매개변수, f-문자열, 리스트 컴프리헨션, 딕셔너리 get 기본값, enumerate 번호 붙이기, 문자열 in 검사, 역순 슬라이싱, zip 짝짓기, range 음수 간격, 문자열 join, max의 key 인자, is와 == 구분, map에 parseInt 넘기기, strip 공백 제거, Math.min과 전개, toUpperCase, 문자열 repeat …) — 잰 확인은 (name, blurb, code)로 하므로 이름난 개념은 새 이름 · blurb · code로만 다시 나올 수 있음; G3 마지막 탐침 문항 P1–P6(`impl112/design/G3/final/probe/items-X.json`); 다른 G의 1.12.0 개발 견본과 잰 견본(G2 개발 NAMES.txt, G1/G4/G5/G6 목록).

계획 묶음 3의 글(같은 짜임)
- 짜임(layout): S-A1: 기록 34개(T 10 + 예비 2, R 20 + 예비 2; 잴 것 js 16 · py 14), 통째 파일 만들기 js/mjs/cjs/py, 3–8줄, 40 코드 포인트 이하 줄 1–3개를 찍음; S-A2: 34개 더, S-A1과 함께 얼림, Q1 ∈ {27, 28}일 때만 씀; S-O 채우는 것 내 코드 2 · 다시 도전 slip 2 · 코드 없는 왜 2; S-U 부를 수 없는 9개(js 5 · py 4)를 도구가 편집 꼴과 새 파일 꼴로 지음. 18 프롬프트: 15개 [new, new, 내 코드] 단계 4/5(처음 10개 T+R, 마지막 5개 R+R), M1 [다시 도전,new,new], M2 [다시 도전,new,왜], M3 [new,new,new]; U 개념이 new에 닿을 때만 U 퀴즈 하나. 상황의 날 = 재는 날.
- 쓰는 쪽(writers): S-A1 + S-A2 + S-O + S-U를 쓰는 새 가린 쓰는 쪽 1–2; 쓰는 쪽 프롬프트에 보기 이름 없음; 몫은 최소로만.
- 둘째 단계(secondStage): 꼬리표마다, 퀴즈 스테이지가 얼려지고 판정된 뒤의 채점 답: 새 쓰는 쪽이 남아서 넘은 문항마다(question, answer, hint) right, again, wrongOne, wrongAll을 씀; 기계로(G-3) 그다음 그 꼬리표의 판정자가 검증; ```json 블록이 꼭 하나, 아니면 한 번 다시 부르고, 아니면 C1–C4 못 넘음.
- 피할 것(avoid): design/G3/dev/NAMES.txt(세트 1–2), 마지막 탐침 문항 P1–P6, 1.8.0–1.11.0의 모든 이름, 1.10.0 S-A1/S-A2/S-U, impl112/NAMES-all.txt; 겹치지 않음은 (name, blurb, code)로.

#### 부르기

설계 calls 글(옮김)
- 플러그인이 부르는 그대로(D20), 프로브 mod의 사본으로: 퀴즈마다 $.model.complete({ model: 'haiku'(설정 글자 그대로), effort: 'low', system: QUIZ_SYSTEM, prompt: redactText(quizPrompt(picks, 'beginner')).text, maxTokens: 4600, timeoutMs: 90000 })(잴 퀴즈마다 처음 보는 코드 고르기가 있음), 4개씩, $.clock으로 시간을 재고, 답은 fixEscapedTicks를 거쳐 커밋된 parseQuiz로 읽음.
- 채점: localRight(mine, item.answer)가 거짓일 때만 $.model.complete({ model: 'haiku', effort: 'low', system: CHECK_SYSTEM, prompt: redactText(checkPrompt(item, mine, 'beginner', first, undefined, { exact: true })).text, maxTokens: 480, timeoutMs: 60000 })(플러그인 안의 맞음은 부르지 않는 판정이고 기록함), parseCheck(fixEscapedTicks(text), { exact: item.answer, mine })로 읽음. 길: 첫 시도(right, wrongOne, wrongAll), 모르겠어요 + 힌트 뒤(again, wrongOne; first = { mine: '모르겠어요', verdict: 'wrong', feedback: '', nudge: item.hint }), 되묻기 뒤(again, 첫 남긴 판정이 맞음이 아니고 되묻기를 keptNudge가 남긴 wrongOne마다; first = { mine: wrongOne, verdict: 남긴 판정, feedback, nudge }).
- 프롬프트는 커밋된 트리의 notes.ts를 불러와 haiku의 rungNewStep = 4만 켜고(haiku의 다른 칸은 앞 1.12.0 묶음이 남긴 그대로, M-13) 짓고, 고르기는 makeQuiz가 짓는 대로(codeFor, rungOf, ladderMixed, withScenes(day), pickForRung) 짓습니다.
- 첫 호출 전 D34: 플러그인 시험 하네스에서 잡은 퀴즈 하나와 채점 길 셋의 실제 요청이 도구의 프롬프트 파일과 바이트까지 같아야 합니다(시제품의 tests/d34g3.test.ts가 퀴즈 하나와 문항 하나로 이미 함: 4/4 같음).
- 탭: 모든 빈 답과 모든 끊긴 답(stop이 end_turn이 아님, 또는 output_tokens < 4600 + H_M인데 자리가 빠짐)을 패스스루 탭으로 한 번 다시 보내 stop_reason/stop_details를 기록합니다(B-12).
- DISABLE_AUTOUPDATER=1; claude --version과 풀린 별칭을 앞뒤로 적습니다.

계획 묶음 3의 글
- 부르기(calls.haiku): 퀴즈 호출 18개(S-A2와 함께 36)(QUIZ_SYSTEM, 4600, 90000) + localRight가 거짓인 곳만 채점 호출(CHECK_SYSTEM, checkPrompt(…{ exact: true }), 480, 60000): ≈ 100–120(S-A2와 함께 ≈ 200–240), 길은 첫 시도 / 모르겠어요 + 힌트 뒤 / 되묻기 뒤.
- D34(calls.D34): 퀴즈 + 채점 길 셋을 커밋된 트리의 하네스에서 잡아 도구 프롬프트 파일과 바이트까지 같음(시제품 d34g3: 4/4).
- 탭(calls.tap): 모든 빈 답과 모든 끊긴 답(stop이 end_turn이 아님, 또는 output_tokens < 4600 + H_haiku인데 자리가 빠짐)을 탭으로 한 번 다시 보냄(기록).
- 판정자(judges): haiku 꼬리표에 판정자 하나(퀴즈 조항과 채점 답의 유효성); 판정자 오류나 빠진 판정은 놓침.
- 사용량(usage): haiku 퀴즈 18 + 채점 ≈ 110 호출(S-A2와 함께 두 배): 입력 ≈ 0.25M(0.5M), 출력 ≈ 0.15M(0.3M) 토큰(퀴즈 가운데 ~2.4k, 생각 몫 포함; 채점 가운데 ~0.8k). Opus: 견본 쓰는 쪽 1–2, 채점 답 쓰는 쪽 1(+ 다시 부르기 1), 판정자 1, 번역 확인, 감사, 검토자 2 ≈ 8회.
- 사용량 관문의 검사점(계획 usageGate, 이 묶음 몫): G3 quiz haiku, S-A2 quiz haiku(재면), G3 채점 길 스테이지마다 haiku. (이 묶음의 기록, 원문 밖: 주간 예측은 계획대로 묶음 1과 묶음 4 몫이라 이 묶음의 관문은 five_hour ≤ 0.60 ∧ seven_day < 0.80 ∧ 다른 워크플로 없음입니다.)
- 앞선 칸 재확인(d26Recheck): isRuleWide haiku · isRuleWide sonnet · 켜졌다면 isRuleDrill haiku/sonnet(N2 checkPrompt {rule} 바이트, parseCheck {rule} 읽기) · 켜졌다면 G2 rungChangedStep haiku: 얼린 요청 9개를 바이트까지, 얼린 견본에서 rungOf/ladderMixed 고르기, 얼린 답의 changedItem/parseQuiz 읽기. 다른 것이 정확히 'G2의 얼린 퀴즈 9개나 자리 20개 가운데 일부가 더는 비슷한 코드 고르기로 지어지지 않음(ladderMixed를 거친 G3의 켠 값)'뿐이고 남은 G2 요청이 모두 얼린 요청과 바이트까지 같을 때만 끔이 아닙니다; 그 밖의 (가)나 (나)의 다름은 묶음 3에서 G2 haiku를 끔으로 합니다(R5, 기록). 재확인 스크립트는 빠진 자리 id와 남은 요청의 바이트 견줌을 찍습니다.

#### 위험 (재기 전에 적음)

설계 risks(옮김)
- 위험 1: Q1이 기준에 걸쳐 있음: haiku 개발은 범위 안에 해당하는 자리에서 두 번 29/30; 30호출에서 거절되거나 틀린 자리가 하나 더 있으면 둘째 세트(57/60)를 부르고, 둘이면 못 넘음. 첫 세트를 바로 넘을 가능성은 대략 반반.
- 위험 2: 새 견본에 개발 섞임 밖의 개념이 들 수 있고, 그런 곳에서 haiku는 생각 없이 답할 때 블록 안에서 찍는 코드를 씀(~400토큰 답, 세트 1 r2가 이렇게 자리 2개를 잃음).
- 위험 3: 저장된 틀린 답 하나가 Q1 놓침이고 학습자에게 닿음; 플러그인은 코드를 돌릴 수 없음. haiku는 마지막 글에서 남은 58개에 틀림 0; 범위와 맨 바깥 규칙이 낮추지만 없애지는 못함.
- 위험 4: 보정: 1.12.0 보정이 H_haiku를 2048에서 바꾸면, haiku의 정확도(생각 몫에 기댐)와 상한 문턱이 바뀜; 회차는 잰 H와 같은 CLI 판을 써야 함. (이 묶음의 기록: 1.12.0 보정이 H_haiku 2048을 냈고, 모든 부르기는 고정한 2.1.323 사본으로 합니다.)
- 위험 5: 새 답에 대한 채점: 플러그인 안에서 매기는 몫은 쓰는 쪽의 말투에 달림; 값 가드는 찍힌 글과 다른 꼴로 쓴 맞는 답(예: True를 참이라 씀)을 틀림으로 매길 수 있음 — 설계상 엄격하지만, 쓰는 쪽이 그런 꼴을 쓰면 C1 위험(유효성 규칙은 다른 찍힌 꼴을 맞는 답으로 금함).
- 위험 6: 닿는 범위가 1.10.0보다 좁음: ts/tsx 없음, 타입 수준 · 실행 차례 · 문자열 글자 개념 없음; 팀 용어나 풀이 보기가 없는 3개 이상 고르기 퀴즈에서만. ts/tsx로 일하는 앱 짓는 사람은 처음 보는 코드를 받지 않음.
- 위험 7: haiku 힌트의 절반은 평범한 문장이 됨(값 줄을 L로 듦); 힌트 길의 쓸모는 기준의 어느 조항으로도 재지 않음.
- 위험 8: 옛 창은 표시만으로 된 답을 마크다운 가로줄로 보임; 도장을 못 보는 1.7 창은 K/L/A 문항을 거의로 기본 채점함.
- 위험 9: G2-C와 G3는 둘 다 quizParts, quizRun 되돌리기, makeQuiz의 recheckRemap, 켠 채점 길을 바꿈; G2도 켜진 채 haiku에서 G3가 켜지면, 처음 보는 코드 고르기 옆의 G2 고르기는 내 코드가 되어(ladderMixed) G2의 닿는 범위가 줄어듦. (이 묶음의 기록: G2 haiku는 묶음 2에서 켜졌습니다(rungChangedStep 2). 이 회차의 퀴즈 꼴 [new, new, 내 코드]의 내 코드 채움은 편집이라 비슷한 코드 꼴이 아니고, ladderMixed가 정한 칸을 build.mjs가 확인합니다.)
- (이 묶음의 기록, 원문 밖) sonnet의 따라가기 거절(SCOPE 묶음 3의 사실): 이 설계의 퀴즈 요청(NEW_ASK)은 코드를 한 줄씩 따라간 과정을 적으라고 하지 않습니다. 모델이 쓰는 것은 K(코드) · L(눈여겨볼 줄 하나를 그대로) · A(찍히는 글자)뿐이고, 1.10.0 G3의 'new' NEW_TRACE_LINE(따라가기 줄)은 이 설계에 없습니다. 채점 프롬프트도 값을 옮기게만 하고 판정이나 따라가기를 쓰게 하지 않습니다. 설계 파일럿에서 sonnet 320호출에 API 거절 · 빈 답 · 끊김 0, haiku 퀴즈에 빈 답 · 거절 · 끊김 0이었습니다(perModel). 잴 모델은 haiku입니다. 빈 답과 거절은 입장 Q2대로 그 퀴즈의 모든 처음 보는 코드 자리를 놓침으로 하고 Q2를 못 넘음으로 셉니다. 탭 결과는 기록만 합니다(B-12).

#### 읽는 법 (재기 전에 정함)

1. Q2의 호출 수: 위 '기준'의 'Q2의 셈을 읽는 법' 하나로 읽습니다(S-A2는 18 프롬프트 짜임 전체, Q2는 36 호출 모두). 설계 bar의 '30 + 3'은 이 절에서 쓰지 않습니다(더 엄격한 쪽, 계획 q2Reading).
2. 다시 보내기와 M-4의 10%: 두 커밋된 규칙이 겹치는 곳이라 그대로 적습니다(묶음 1 감사 교훈 2). 계획의 끊긴 스테이지 규칙이 정한 차례대로, 먼저 이 G의 api-error 줄(입장 Q2: 답 전 오류인 api-error만 같은 줄로 한 번 다시 보냄; 채점도 입장 G-5의 'api-error 규칙 제외'로 같은 줄)을 쓰고, 그다음 스테이지의 요청마다 마지막 상태로 M-4 셋째 줄(10%)을 어느 답도 열기 전에 상태 수로만 봅니다. 상태 줄이 없는 요청(끊긴 스테이지)도 api-error로 셉니다. 남은 api-error가 그 스테이지 요청의 10%를 넘으면 그 스테이지는 무효(답을 열지 않음)이고 다른 날 같은 바이트로 한 번 더 보내며, 또 넘으면 칸은 끔입니다(M-4). 10% 이하로 남은 api-error는 입장 Q2의 '다시도 api-error면 빈 답'대로 빈 답으로 셉니다(퀴즈: Q2 못 넘음과 그 퀴즈 자리 놓침; 채점: G-5대로 그 견본 놓침). 퀴즈 18개에서는 남은 api-error 하나가 1/18 ≤ 10%라 빈 답이 되고, 둘이면 2/18 > 10%라 무효입니다. 이 글은 어느 조항도 바꾸지 않고, 두 규칙을 계획이 정한 차례로 읽은 것입니다.
3. 끊긴 답(입장 Q2, 설계 calls 탭 줄): 엔진의 `$.model.complete` 답에는 stop_reason이 없습니다(SCOPE 묶음 3의 사실). 그래서 도구가 보는 끊김은 설계 줄의 둘째 반쪽, '답했는데 자리가 빠졌고 output_tokens < 6648'입니다(퀴즈마다; 채점은 '답했는데 채점 읽기가 읽지 못했고 output_tokens < 2528'). stop_reason은 탭이 기록합니다(기록만, B-12). 끊긴 답의 셈은 입장 Q2 그대로입니다(빠진 자리는 조항 1에서 놓침; Q2 자체는 빈 답 · 시간 한도 · 상한 닿음일 때만 놓침).
4. 판정 하위 에이전트(꼬리표마다 하나): 이 회차의 판정자 일은 두 번 생깁니다 — 퀴즈 스테이지 뒤의 문항 판정(조항 3 (라) · 4 · 5의 쓰임 · 7의 ✎ 부분, U 문항의 흉내 코드), 채점 답을 쓴 뒤의 G-3 확인. 둘 다 그 꼬리표만 보는 새 하위 에이전트이고, 한 문항이나 한 답을 둘이 매기는 일은 없습니다(갈림 없음). 둘째 판정자의 일은 첫째의 판정을 보지 않습니다. 판정자에게는 입장의 그 일에 쓰이는 부분을 커밋된 이 절에서 글자 그대로 잘라 줍니다(아래 '도구가 글을 읽는 방식' 10).
5. 예비로 바꾸기(설계 samples 둘째 줄 '못 넘은 기록은 id 차례로 예비가 바꾸고'): 같은 무리(T 또는 R)의 예비를, 같은 언어 먼저, 그다음 다른 언어, id 차례로 씁니다(잴 것 js 16 · py 14를 지키려는 차례). 남은 예비가 없는 자리는 못 넘은 기록을 그대로 두고 놓침으로 셉니다. 예비가 바꾸기에 쓰이면 그 예비가 채우던 M1–M3 자리는 같은 무리 · 같은 언어의 잴 기록 가운데 id가 가장 작은 것(M3가 이미 쓰는 둘은 빼고)으로 채웁니다(M 자리는 Q1에서 기록만).
6. 쓰는 쪽의 수와 다시 부르기: 쓰는 쪽은 둘입니다(A: S-A1 + S-A2 68개, B: S-O 채우는 것 6개 + S-U 9개; 계획 '1–2'). 설계는 견본 쓰는 쪽에게 둘째 회를 두지 않으므로(못 넘은 기록은 예비로만 바꿈), 다시 부르는 것은 답에 읽을 수 있는 JSON 값이 하나도 없을 때뿐이고(G-7의 꼴을 견본 쓰는 쪽에 쓴 도구 규칙, 같은 프롬프트 파일), 그것도 읽을 수 없으면 STOP(재지 않음, 보고)입니다. 쓰는 쪽은 답을 고치지 않고 재는 세션도 고치지 않습니다.
7. 섞임 최소(설계 samples 넷째 줄 '몫은 최소로만'): 세트마다(34개) 쓰는 쪽 프롬프트에 최소로 적고, 기록마다 쓰는 쪽이 단 꼬리표(tags)를 세어 기록만 합니다. 모자라도 둘째 회가 없고(5 · 6), 꼬리표는 쓰는 쪽의 말이며 도구가 코드로 확인하지 않습니다.
8. S-U의 확인: S-U에는 예비가 없으므로 얼릴 때 확인(js 5 · py 4, 12–20줄, 인용 줄이 파일의 한 줄이고 그 위에 적어도 8줄)을 못 넘은 기록은 Q3에서 처음 보는 코드로 간 것으로 셉니다(불리한 쪽; 설계 '남은 예비가 없는 자리는 놓침'과 같은 셈).
9. 상황의 날 = 재는 날: 견본을 얼리는 날(UTC)을 build.json과 모든 프롬프트 줄의 날로 씁니다. 부르기가 사용량 관문 때문에 다음 날로 밀려도 얼린 바이트를 그대로 보냅니다(R5: 얼린 요청을 다시 짓지 않음). D34 하네스는 시험 트리 사본의 tests/flowkit.ts 시계만 그날 01:00 UTC로 맞춥니다(hooks/는 그대로).
10. U 퀴즈: S-U 기록이 한 꼴에서라도 new에 닿을 때만 하나 짓습니다(그 기록들을 처음 닿은 꼴로 하나씩, 셋까지, 나머지는 내 코드 채움). 그 호출은 Q2의 18(36) 호출에 들지 않고(설계 Q2: 퀴즈 15개와 M1–M3), 저장된 U 문항은 Q3(조항 5, 흉내 코드)로만 셉니다.
11. 채점 건너뛰기(계획 stop, 이 커밋에 적음): Q1 ≤ 26(S-A2와 함께면 합 < 57), 또는 Q2나 Q3 못 넘음 → 결정은 이미 Infinity이고 채점 스테이지는 건너뜁니다(C 칸은 '돌리지 않음'). Q1 ∈ {27, 28}이면 S-A2를 먼저 재고, 합이 57 이상이며 두 세트의 Q2와 Q3가 넘을 때 두 세트의 남아서 넘은 문항을 함께 채점합니다.
12. '31–60개를 채점하면 두 배': 채점한 수는 채점 견본 답을 쓴 문항(남아서 넘은 문항)의 수를 세트들에 걸쳐 센 것입니다. 30을 넘으면 C1/C4는 2, C2/C3는 6이고, 30 이하이면 정한 수(1, 3)입니다.
13. 무효인 채점 답(G-2 · G-3): 도구가 무효로 보거나 판정자가 무효(또는 정하지 못함)라 한 답은 부르기 전에 그 답 하나만 뺍니다(문항 전체가 아님). 뺀 답의 길은 칸에 들지 않습니다. 되묻기 길(C4 (a))은 첫 시도 wrongOne과 again이 모두 유효한 문항에서만 생깁니다.
14. 조항 7의 기계 규칙: '낱말로'는 값의 앞뒤가 어느 글자 체계의 글자 · 숫자 · 밑줄에도 붙지 않음입니다(Python `\w`; 설계 파일럿의 판정 도구와 같음). '문제 코드 안에 리터럴로 있음'은 문자열 리터럴의 글(6의 꼴)이나 수 토큰, 또는 true · false · null · undefined · None · True · False로 그 값이 코드에 있음입니다. 그 밖의 힌트 · 문제 글이 답을 말하는지는 판정자의 ✎ 부분입니다.
15. 조항 3의 이름 바꾸기 (다): 식별자 토큰 가운데 그 언어의 예약어(js는 ECMAScript 예약어와 undefined · of · async · await · static · get · set · NaN · Infinity · arguments · eval, py는 keyword.kwlist와 softkwlist)와 조항에 적힌 console · print · len · range · str · int · float · list · dict · Math · Object · Array · JSON · String · Number만 그대로 둡니다. 속성 · 메서드 이름도 식별자로 바꿉니다.
16. 입장 6의 맞춤 차례는 글 그대로입니다(앞뒤 공백 떼기 → 안쪽 공백 · 탭 하나로 → 줄 끝 마침표 하나 떼기 → 따옴표 종류만 같게).
17. 입장 5의 'js는 node로 두 번, 모듈 문법 오류일 때만 .cjs로 한 번 더': 두 번 모두 모듈 문법 오류(stderr에 'Cannot use import statement outside a module', 'require is not defined in ES module scope', "Unexpected token 'export'", 'To load an ES module')로 멈출 때만 같은 코드를 .cjs로 한 번 돌리고, 그 결과를 씁니다.
18. 도구 판(입장 5의 돌림): node v22.23.4 · Python 3.11.18(`/usr/local/bin/python3`) · git 2.43.0 · TypeScript 6.0.2(이 G는 타입 검사를 하지 않음) · Claude Code 2.1.323(고정한 길).
19. 입장 끝의 경계 사례 가운데 개발 기록(set1 · set2 · R17 · R18 · P5 등)을 든 것은 설계 때 개발 세트에서 본 꼴을 미리 가른 것이고, 개발 결과는 어느 결정에도 들지 않습니다(B-12).
20. 계획과 SCOPE: 이 단계에서 둘이 다른 곳은 없습니다. 짓기 단계에서는 계획 batches[3].build의 '새 코드 없음'과 SCOPE 09:1x 메모(newMissed 고침)가 달랐고, 더 엄격한 SCOPE 쪽(고침 + 실패 먼저 시험 + D26)을 따랐습니다(f03b362).

#### 도구가 글을 읽는 방식 (재기 전에 정함)

도구는 설계 파일럿 도구(`impl112/design/G3/pilot/`: build.mjs · read.mjs · grade.mjs · gvalid.py · gwriter.py · judge.py · judgeprompt.py · layout.py · runner.py · probe/ · tap/, `design/G3/final/`: grade2.mjs · gen-d34.mjs, `design/G3/dev/static.py`)와 묶음 2 도구(`impl112/b2/`: stage.sh · gate.py · tapsend.py · label.py · count.py · judge.py · d34/make.py · probe/ · tap/)를 짓기 커밋의 트리에 맞춰 `impl112/b3/` 아래에 다시 지었습니다. 계획이 '새로'라고 한 것(꼬리표 · 봉인 · 짝, 플러그인 안 매김 몫과 L0을 세는 기계 셈, 커밋된 rungOf로 두 꼴의 S-U를 짓는 것)도 여기서 지었습니다. 글과 도구가 다르면 글이 이깁니다(M-15).

1. 트리: `mtree/`는 짓기 커밋 f03b362의 `git archive`(docs · README · CHANGELOG 뺌)이고, `mtree/hooks/notes.ts` · `register.tsx`는 위 sha256과 같습니다. 읽기의 기록 트리 `jtree/hooks/notes.ts`는 mtree의 notes.ts에서 `quizParts` 앞에 `export `만 더한 것입니다(다른 바이트 같음). 요청을 짓고 읽는 모든 도구는 mtree를, newItem의 거절 까닭 기록만 jtree를 씁니다.
2. 견본 쓰기(`gen/writer-A.md` · `gen/writer-A-end.md` · `gen/writer-B.md` · `gen/writer-B-end.md` · `gen/avoid.py` · `gen/run.sh`): 쓰는 쪽 A는 세트 P(= S-A1, pT01–pT12 · pR01–pR22)와 세트 Q(= S-A2, qT01– · qR01–)의 기록 68개, 쓰는 쪽 B는 S-O(om1 js · om2 py 내 코드 편집, os1 js · os2 py 다시 도전, oc1 · oc2 코드 없음)와 S-U(ou1–ou5 js: 맨 위 라이브러리 import · jQuery · fetch/XHR/WebSocket · process/fs · 브라우저 화면, ou6–ou9 py: 맨 위 라이브러리 import · 웹 프레임워크 데코레이터 · 네트워크 · 파일/프로세스)를 씁니다. 프롬프트는 설계 개발 쓰는 쪽 프롬프트(`design/G3/dev/writerA.txt` · `writerB.txt`)에서 보기 이름을 빼고, 이름을 플러그인의 꼴(주제 낱말만, 쌍점 없음; 상황 구절은 따로 'situation')로 바꾸고, 범위(ts · 타입 · 실행 차례 · 문자열 글자 개념 없음)와 세트마다의 최소 몫을 적은 것입니다. 피할 이름 절은 `gen/avoid.py`(묶음 2 것, 머리 글만 바꿈)가 그때의 NAMES-all.txt에서 짓습니다. 쓰는 쪽마다 새 `claude -p --model opus --tools '' --output-format json`(고정한 길, 빈 폴더, 프롬프트는 stdin)이고 답 · 시각 · 쓴 쪽을 `gen/out/<쓰는 쪽><회>/`에 둡니다.
3. 얼리기(`tools/check.py` · `tools/runlib.py` · `tools/kit.mjs`): 쓴 그대로를 `frozen/raw.json`으로 묶고, 기록마다 꼴(id · 무리 · 확장자 · 이름 · 노트 읽기가 이름과 blurb를 쓴 그대로 읽음 · blurb의 ' — `한 줄`' · 인용 줄이 코드의 찍지 않는 한 줄 · 공백 아닌 줄 3–8), 돌림(입장 5의 돌리기: 끝 코드 0 · 모두 같음 · 1–3줄 · 줄마다 40 코드 포인트 이하 · 적힌 output과 줄마다 같음), new(kit의 quizOf로 [그 기록 단계 4, om1, om2]를 지어 ladderMixed와 withScenes 뒤 칸이 new), 겹치지 않음(위 견본의 짜임; 앞선 기록 묶음은 `impl112/design/*/dev/**` · `b1/frozen` · `b2/frozen`의 이름 있는 기록과 P1–P6이고 그 sha256을 check.json에 적음)을 봅니다. 그다음 '읽는 법' 5대로 예비로 바꾸고 짜임(layout.json)을 짓습니다. 채우는 것이 없으면 STOP입니다. 쓰는 쪽 답 · 기록 · 짜임 · 확인 결과 · 이름(NAMES.txt)을 `frozen/`에 chmod 444로 둡니다.
4. 짜기(`tools/build.mjs` · `tools/kit.mjs`): 퀴즈마다 makeQuiz처럼 개념마다의 고르기(withCode: codeFor의 줄, isChanged · isNew, 편집이면 작업 트리 파일 글(importsText = 편집 뒤 파일 전체), isLibrary · isImporting · isNewLibrary · isWhole · around), haiku 줄 칸(트리의 MODEL_SWITCHES.haiku 위에 rungNewStep 4; ladderSteps는 register.tsx 글에서 읽음), rungOf(모든 고르기는 때 됨), ladderMixed, withScenes(그날), pickForRung + scene, `redactText(quizPrompt(picks, 'beginner')).text`, maxTokens는 register.tsx의 식(`isLong ? QUIZ_TRACE_TOKENS : QUIZ_TOKENS`), system QUIZ_SYSTEM, timeoutMs 90000. 잴 N 자리(얼릴 때 못 넘어 남긴 자리 빼고)가 new가 아니거나, 내 코드 채움이 mine이 아니거나, 다시 도전 · 왜 채움에 칸이 있거나, redact 걸림이 0이 아니거나, maxTokens가 4600이 아니면 아무것도 쓰지 않고 멈춥니다. Q3 고르기(S-U마다 두 꼴, [그 기록 단계 4, om1, om2])와 U 퀴즈도 여기서 짓습니다. `frozen/build.json` · `lines-P.jsonl`(18) · `lines-Q.jsonl`(18) · `lines-U.jsonl`(있을 때), chmod 444.
5. D34(`d34/make.py`, 셈에 들지 않음): mtree 사본에서 시험 파일을 모두 빼고(flowkit.ts · fixtures는 둠) 시계만 그날로 맞춘 뒤('읽는 법' 9), 퀴즈 줄마다 시험 하나: model 'haiku', level beginner, 하네스 `models: { haiku: { rungNewStep: 4 } }`, 그 퀴즈의 개념을 단계대로 저장소에 두고 퀴즈 차례로 때 되게, 다시 도전은 저장소 slip(times 1), 통째 파일은 Write 턴, 편집은 Edit 턴(-U3 hunk 하나, 작업 트리 파일은 편집 뒤 글), 턴마다 그 개념을 이름 짓는 노트, 그다음 `/learn 퀴즈 새로`. 잡힌 요청(model · effort · system · prompt · maxTokens · timeoutMs)이 하나뿐이고 줄과 바이트까지 같아야 합니다. 채점 길은 문항을 저장소 퀴즈에 두고 첫 시도 `/learn 퀴즈 1 <답>`, 힌트 뒤는 '모르겠어요' 다음 답, 되묻기 뒤는 첫 시도 wrongOne을 첫 시도의 얼린 답 글로 받은 다음 again을 보내, 마지막 요청이 채점 줄과 같아야 합니다. 고정한 길의 `claude plugin test .`(하네스가 답함, 모델 호출 0). 같지 않은 것이 하나라도 있으면 stage.sh가 그 스테이지를 시작하지 않습니다(퀴즈는 줄마다 모두, 채점은 그 스테이지에서 잡은 것 모두).
6. 부르기(`tools/stage.sh` · `tools/gate.py` · `probe/precheck.sh` · `probe/call.sh` · `probe/record.py` · `probe/mod/`): 스테이지 quiz-P · quiz-Q · quiz-U · grade1-P · grade2-P · grade1-Q · grade2-Q를 떼어 낸 러너로 돌립니다(haiku만; quiz-Q는 `judge/sa2.json`이 run일 때만). 앞 'ok' 세션 = 앞 기록과 사용량 관문(다르면 STOP, 관문을 못 넘으면 WAIT, STARTED가 있으면 거절), 그다음 STARTED, 시도 1, api-error만 한 번 다시(시도 2), 뒤 기록(다르면 무효), 요청마다 마지막 상태로 10% 규칙(넘으면 무효). 프로브 mod(명령 `/g3probe <줄> <답 파일> <상태 파일>`)는 묶음 2 프로브의 사본(명령 이름만 바꿈)이고 `probe/mod/hooks/notes.ts`는 mtree의 notes.ts와 바이트까지 같습니다. 4개씩 부르고, 호출마다 상태 줄(id, answered, reason, status, output_tokens, ms; 글 없음)을 더합니다.
7. 탭(`tools/tapsend.py` · `tap/`): 묶음 2 탭의 사본(명령 `/g3tap`, `tap/tap.py`는 1.11.0 · 묶음 1 · 묶음 2 것과 바이트까지 같음). 스테이지가 DONE이고 답의 sha256을 적은 뒤, 어느 시도의 빈 답이든, 그리고 읽기가 적은 끊긴 답('읽는 법' 3)의 얼린 줄을 한 번 탭으로 보내 stop_reason · stop_details만 적습니다. 기록만.
8. 꼬리표와 읽기(`tools/label.py` · `tools/read.mjs`): seal은 quiz-P가 DONE일 때 꼬리표를 A · B 가운데 난수로 하나 뽑아 `judge/pair.json`({꼬리표: 모델, nonce}, chmod 444, sha256만 찍음)과 `judge/label.txt`를 씁니다(회차 전체에 꼬리표 하나). read는 퀴즈마다 마지막 시도의 답(프로브가 이미 fixEscapedTicks를 거침)을 mtree의 parseQuiz(text, build.json의 picks)로 읽어 `judge/<꼬리표>/read-<세트>.json`(chmod 444)에 둡니다: 퀴즈마다 how, 자리마다 저장된 문항과, new 자리는 기록으로 jtree의 quizParts(펜스 앎, 표지 QHATRKL, KLA는 마지막 글)와 newItem의 까닭. 모델 이름 · 토큰 · 시간은 없습니다. 끊긴 답의 id는 스테이지 폴더의 cut-ids.json에만 둡니다(탭 몫).
9. eval(`tools/eval.py` · `tools/runlib.py`): 입장의 ⚙ 조항을 new 자리마다 셉니다 — 1(저장된 문항, rung new, kind predict, question · hint · answer), 2(펜스 블록 하나: ``` 또는 ~~~와 이름이 있는 줄로 열고 같은 표만 있는 줄로 닫음, 공백 아닌 줄 ≤ 8, 펜스 이름이 물은 언어의 무리), 3 (가)(나)(다)(그 개념 기록의 code와), 5(보인 그대로 돌림: runlib.ok5; grep에 걸린 금지 낱말은 판정자에게), 6(runlib.same6; 끝 코드 0이 아니면 놓침), 7의 기계 규칙(힌트와 펜스 밖 문제 글, '읽는 법' 14). 판정자 보고서 `report-<세트>.md`에는 저장된 new 문항마다 키, 개념 이름 · blurb · code, 저장된 question · hint · answer, 돌린 출력(또는 실패), grep 걸림만 둡니다. `eval-<세트>.json` · `report-<세트>.md` chmod 444.
10. 판정(`tools/judge.py` · `judge/tpl-quiz.md` · `judge/tpl-grade.md` · `judge/stance-quiz.md` · `judge/stance-grade.md`): 꼬리표의 판정자, 일마다 새 `claude -p --model opus --tools '' --output-format json`(고정한 길, 빈 폴더, 프롬프트는 stdin). 퀴즈 판정자는 틀 · stance-quiz.md(이 절 '판정의 입장'에서 머리말 · 0–7 · Q2 · Q3 · 판정 하위 에이전트 · 경계 사례 가운데 '채점'으로 시작하지 않는 것을 글자 그대로 자름) · 보고서만 받고, 문항마다 c3ra · c4 · c5use · c7(U 문항은 mimic도)를 pass/miss/undecided로 씁니다. 채점 답 판정자는 틀 · stance-grade.md(머리말 · G-1–G-7 · 판정 하위 에이전트 · '채점'으로 시작하는 경계 사례) · 채점 답 보고서만 받고 답마다 valid/invalid/undecided를 씁니다. 읽지 못한 답이나 키 · 칸이 빠진 답은 같은 프롬프트로 새 판정자에게 한 번 더 묻고(기록), 그래도 빠진 것은 undecided(불리한 쪽)입니다. `judge/<꼬리표>/verdicts-<일>-<세트>.json`(chmod 444).
11. 채점 답(`tools/gwriter.py` · `tools/gvalid.mjs`): prompt는 `judge/<꼬리표>/grading.json`이 그 세트의 채점을 돌린다고 할 때만, 퀴즈 셈의 남아서 넘은 문항으로 쓰는 쪽 프롬프트를 짓습니다(쓰는 쪽은 꼬리표와 문항마다 저장된 question · hint · 찍히는 줄만 봄; 설계 samples의 3번째 · 5번째 규칙과 values). write는 새 `claude -p --model opus --tools ''`(고정한 길, 빈 폴더, stdin)이고, parse는 G-7(```json 블록 꼭 하나, 아니면 같은 프롬프트로 한 번 더, 또 아니면 `gw-fail.json`과 C1–C4 못 넘음)입니다. gvalid.mjs는 G-3의 기계 부분을 mtree의 isSameValue로 봅니다(right · again: values가 찍힌 줄마다 하나이고 isSameValue, 답 글 안에 차례대로 있음, 찍힌 줄에 쉼표가 있으면 줄을 바꿔 씀, '…' · '...' 없음, again ≠ right; wrongOne: 줄마다 값이 있고 꼭 하나만 다름; wrongAll: 어느 자리에서도 isSameValue 아님). items는 도구와 판정자가 모두 유효라 한 답만 남깁니다(G-2, '읽는 법' 13).
12. 채점(`tools/grade.mjs`): lines는 gradeTyped의 isExact 길 그대로(localRight 먼저: 부르지 않는 맞음; 아니면 checkPrompt(item, mine, 'beginner', first, undefined, { exact: true }), CHECK_SYSTEM, 480, 60000) 스테이지 1(첫 시도 right · wrongOne · wrongAll, 힌트 뒤 again · wrongOne)과 스테이지 2(첫 시도 wrongOne의 남긴 판정이 맞음이 아니고 keptNudge가 되묻기를 남긴 문항의 되묻기 뒤 again; first.mine은 1500자로 자른 글)의 계획과 줄을 짓습니다. read는 parseCheck(text, { exact: answer, mine })의 verdict(counted), 남긴 판정(kept: 첫 시도와 모르겠어요 뒤는 그 verdict, 되묻기 뒤는 secondVerdict(first.verdict, verdict); 플러그인 안 맞음도 같은 식), keptNudge, 기록(가드 없는 verdict, 옮긴 값 줄, NEW_NOT_SAID 표시)을 적습니다. 토큰 · 시간은 없습니다.
13. 기계 셈(`tools/count.py`): 꼬리표와 스테이지마다 시도별 호출, 요청마다 마지막 상태와 상한 닿음(퀴즈 ≥ 6648, 채점 ≥ 2528), 다시 보낸 수, output_tokens와 시간의 가장 큰 값 · 가운데, 탭의 빈 답 · 끊김 · 거절 열, 채점 스테이지의 플러그인 안 매김 몫과 L0의 기계 수를 `judge/count-<꼬리표>-<스테이지>.json`(chmod 444)에. 판정자는 이 파일을 받지 않습니다.
14. 셈(`tools/tally.py`): quiz는 eval · 판정 · count가 모두 얼었을 때만, 세트의 잴 30자리를 위 기준과 '읽는 법'대로 셉니다(얼릴 때 못 넘어 남긴 자리 · 그 퀴즈의 빈 답 · 시간 한도 · 상한 닿음 · eval 놓침 · 판정자의 pass 아님 = 놓침). Q2는 세트의 18 호출, Q3는 세트 P의 셈에서(build.json의 두 꼴, 얼릴 때 못 넘은 S-U 기록은 new로, U 문항의 흉내 코드와 조항 5). 그다음 채점을 돌릴지(`grading.json`)를 '읽는 법' 11대로 정합니다. grade는 위 기준의 칸과 L0, 두 배 규칙('읽는 법' 12), G-7 실패를 셉니다. `tally-quiz-<세트>.json` · `tally-grade.json`(chmod 444).
15. 결정(`tools/decide.py`): sa2는 세트 P의 셈이 'S-A2'라 할 때만 `judge/sa2.json`을 run으로 씁니다. final은 모든 판정 파일과 셈이 얼었을 때만 짝을 열고(label.py open의 규칙), haiku의 칸 값(4 또는 Infinity)과 sonnet '재지 않음'을 `judge/decision.json`(chmod 444)에 씁니다.
16. 짓기 때 쓴 도구(기록, 짓기 커밋 f03b362 본문과 묶음 2 표): 끈 바이트 · 옛 창 · 돌연변이 탐침 · D26 도구는 `impl112/b3/off` · `oldprobe` · `mut` · `d26`과 `impl112/d26/rulewide.mjs`에 있고, 값 커밋(R9)이 다시 씁니다. 이 커밋은 그것을 바꾸지 않습니다.
17. 도구 시험(견본 · 모델 호출 0, 저장소 밖 `impl112/b3/test/`): 설계 개발 세트 1 · 2(측정에 쓰지 않음)의 견본, 적어 둔 개발 답과 채점 답을 입력으로만 썼습니다.
    - check.py: 개발 세트 1을 세트 P, 세트 2를 세트 Q로(id를 바꾸고 이름에서 상황 구절을 떼어) 넣으면, 두 세트에 함께 있는 개념을 인용 줄 · 코드 (가)(다)로 잡고(예: pT02/qT02, pR14/qR18), 찍는 줄을 인용한 blurb, 범위 밖이 된 padStart(칸 changed)와 역순 슬라이싱(칸 mine), 시험 NAMES에 넣은 이름, 시험 앞선 기록 묶음에 이름만 바꿔 넣은 코드((다))를 거절하고 같은 무리 예비로 바꾸며, 예비가 모자라면 자리를 남기고 놓침으로 적음. 읽을 수 없는 답 → 'WRITE A 2'(종료 5), 둘째도 → STOP(6); 내 코드 채움이 빠짐 → STOP; S-U 하나를 망가뜨리면 그 기록을 적음.
    - build.mjs: 위 얼림으로 퀴즈 36개(N 30 · M 6)를 짓고, 남긴 자리 둘만 칸 mine으로 알림; 개발 세트 2의 짜임 그대로 넣으면 범위 밖이 된 R17이 남긴 자리가 아니면 멈춤(3); 실제로 돌 수 있는 S-U 기록을 하나 넣으면 두 꼴 모두 new로 잡아 Q3 8/9와 U 퀴즈(편집 꼴)를 지음.
    - D34(실제 `claude plugin test`, 고정한 CLI, 모델 호출 0): 퀴즈 18/18, 한 글자를 바꾼 사본 17/18(종료 4), U 퀴즈(편집 꼴) 1/1, 채점 스테이지 1의 67/67(첫 시도와 힌트 뒤, 여러 줄 답 포함), 스테이지 2의 3/3(되묻기 뒤, 첫 시도의 실제 개발 답 글로).
    - read.mjs → eval.py: 개발 세트 2의 haiku 개발 답(1회째)을 넣으면 설계 기록과 같은 수(잴 자리 가운데 new 29, ⚙ 모두 넘음 29; R17은 범위 밖). 손 사례 8개(그대로 · 블록 둘 · 펜스 언어 다름 · 개념 코드 그대로 · 틀린 A · 4줄 찍음 · 힌트가 답 값을 말함 · 힌트 없음)가 1 · 2 · 2 · 3가+6 · 6 · 5 · 7m · 1로 갈림. runlib: (가) · (다) 이름 바꿈 · (다) 리터럴 하나 · 리터럴 둘은 아님 · (나) · 이어진 줄 견줌 · n6 · same6(따옴표 있고 없음, True/true 다름) · 5초 넘음 · 금지 낱말 grep.
    - grade.mjs: 설계 마지막 채점 기록(세트 2, 20문항)과 같은 수 — 스테이지 1 길 100(플러그인 안 33, 호출 67), 스테이지 2 길 20(안 17, 호출 3); 호출 줄 70개가 설계 줄과 바이트까지 같음; 그 설계 답을 다시 읽어 C1–C4b 모두 0/20, L0 0. gvalid는 그 답 80개에서 무효 0.
    - tally · decide · label(가짜 판정자 명령): 개발 세트 2에서 Q1 29/30, Q2 0 · 0 · 0, Q3 9/9 · 9/9 → 채점 세트 P; 판정자 한 칸을 놓침으로 고치면 Q1 28 → S-A2(sa2 run) → 세트 Q 29로 합 57 → 두 세트 채점; 채점한 40문항 → 두 배(C1 2, C2/C3 6, C4 2), 합성한 C1 놓침 하나는 2 안이고 합성한 L0 하나는 못 넘음. 짝은 판정 파일과 셈이 모두 얼기 전에는 열리지 않음, decision.json 한 번만.
    - judge.py(가짜 판정자): 첫 답이 JSON이 아님 → 새 판정자에게 한 번 더(시도 2); 키 하나가 빠짐 → 다시 물은 뒤에도 빠지면 undecided.
    - gwriter.py: grading.json이 그 세트를 돌리지 않으면 거절; 블록 둘 → 'WRITE GW 2'(5), 둘째 블록 없음 → gw-fail.json과 'C1-C4 FAIL'(6).
    - stage.sh · gate.py · tapsend.py · count.py(가짜 `claude`와 가짜 고정 길): ONLY_WORKFLOW 없음 → 시작 안 함(2), five_hour 0.70 → WAIT(7, STARTED 없음), 판 다름 → STOP(3), 모두 넘음 → DONE, 다시 → STARTED로 거절(1), 429 · 400 한 번 다시 보낸 뒤 400이 남음(1/18) → DONE이고 빈 답으로 셈, 503 · 400이 둘 남음(2/18) → 무효(6), 던짐 → 5, sonnet · sa2 없는 quiz-Q · 줄 없는 채점 → 거절(2), 빈 답 하나와 끊긴 답 하나 → 탭 기록 둘.

#### 틀과 도구 (sha256, 이 커밋으로 얼림, 저장소 밖 `impl112/b3/` 아래, chmod 444)

목록 파일 `impl112/b3/bar/tools.sha256`(chmod 444) sha256 `__LISTSHA__`. `../cli/pinned.sh`는 실행돼야 하므로 555이고 sha256은 묶음 0과 같습니다. `mtree/` · `jtree/`는 트리 통째로 쓰기를 막았습니다. 번역 확인: __XCHECK__

| 파일 | 하는 일 | sha256 |
| --- | --- | --- |
| `gen/writer-A.md` | 쓰는 쪽 A 프롬프트 앞(S-A1 + S-A2 68개) | `91d82c42ee878216f0d150214ee845e855071d89adf58ee83c4a765a3769a513` |
| `gen/writer-A-end.md` | 쓰는 쪽 A 프롬프트 끝 | `92162f25417de839a4bacdff059cc4fbd5362c0185ab90d302340e6e70fc0ad0` |
| `gen/writer-B.md` | 쓰는 쪽 B 프롬프트 앞(S-O 6 + S-U 9) | `9e3c949d3238f66fe490ac183e4b6fdda0e080a6ea73b91f4fa93324495bd667` |
| `gen/writer-B-end.md` | 쓰는 쪽 B 프롬프트 끝 | `3fea3bfc3339c61b9a9e868af9ed125322895a4b147879b1abbbbe9b3b1edff8` |
| `gen/avoid.py` | 피할 이름 절(NAMES-all.txt에서) | `e25ab57f921d9b2dbbd2bbb32b32e6133e988f895c4a08bc34a3d4072f4be295` |
| `gen/run.sh` | 견본 쓰는 쪽 실행 | `fc0c294863444d88a8a73d79753322378ba0057132b2b1bfbdec34e99b13e493` |
| `tools/runlib.py` | 돌림(입장 5) · 맞춤(6) · 3 (가)(나)(다) · 7 기계 규칙 · 펜스 | `69cb640ac5b089e9d71a996882406f068e32cab910b6a9474008ee9f01a422d2` |
| `tools/kit.mjs` | 플러그인 쪽 고르기 · 칸 · 프롬프트(mtree, haiku 줄 + rungNewStep 4) | `8d44597f57dda3a441257e7b46926a435346125edd2932889a4a7a0f319979e8` |
| `tools/check.py` | 얼릴 때 확인 · 예비 바꾸기 · 짜임 | `c282963cd21960862885b70f3aa3e2c4f3b09546eb5b6c5106902ecdf993e41a` |
| `tools/build.mjs` | 퀴즈 요청(lines-P/Q/U) · Q3 고르기 | `7cb5d5bdd11e64dcdec125056360b73df790f3961e80793340474075d221d954` |
| `tools/stage.sh` | 떼어 낸 러너(퀴즈 · 채점 스테이지, api-error 한 번 다시) | `5ce4f767d93722b28414e69dbb29f9ab0b7f5eaa038c4320669ee6c228b0d78f` |
| `tools/gate.py` | 앞뒤 기록 · 사용량 관문 | `40a1875cfe10e0ddf87a39d9b337e510798b709f32e4fd225d51b65635bee14d` |
| `tools/tapsend.py` | 빈 답 · 끊긴 답의 탭(기록) | `516522b637e9659cdd82b4e6f29a51328c5d2dd145a0ad38af5d6724f30de1f1` |
| `tools/read.mjs` | 읽기(입장 1, parseQuiz) | `1a2791d851c5686d264f2cb04808b81a1bff2c917b89acc6b5070fdbf831ab64` |
| `tools/eval.py` | eval 도구(⚙ 조항) · 판정자 보고서 | `06509df2f1866ce3a1cee313058c68fdc60ff8d499176496b8db3927fac52118` |
| `tools/judge.py` | 판정자(꼬리표마다, 퀴즈 · 채점 답) | `1793b09287a2da69f268e789792d39899f1cc2031cc4b2fcccabb151897bb40e` |
| `tools/gwriter.py` | 채점 답 쓰는 쪽(G-7) · 유효한 답 묶기 | `e56e9dde39f517d4144a8064b6d6d43db6c0b403fbb092c3d0fb04d1163a37a8` |
| `tools/gvalid.mjs` | G-3의 기계 부분(mtree isSameValue) | `8cec3a4c91674962c1471807508fc21b9ea1531c9e468ffe62547dd29f605d6c` |
| `tools/grade.mjs` | 채점 길 셋의 줄 · 읽기(localRight 먼저) | `596b3a15b190f9ee258330f1d8d8514afb9db4cc5e5e0f14603570b85496d3f4` |
| `tools/count.py` | 기계 셈(꼬리표 · 스테이지마다) | `79df86312741f8eaa98d836cdccff2f695436bb5755d24620238d2452dd838bb` |
| `tools/tally.py` | Q1 · Q2 · Q3 · 채점 여부 · C 칸 · L0 | `1ec4a704b6d332b39e5dde714563ab963ca05ee8fee5fe4654f48b3938da06fc` |
| `tools/decide.py` | S-A2 여부 · 결정 규칙 | `643778e3dfc139565a61927eaad74917bb0f3c37db10310abeb74a6cb6262f21` |
| `tools/label.py` | 꼬리표 봉인 · 읽기 · 짝 열기 | `c7371fa147bf3a85eb53e50daa2d4a211a93655243758ede5573a41ac94d42fb` |
| `judge/tpl-quiz.md` | 퀴즈 판정자 틀 | `3cafc9c4ecab4f3ca1d16ab7e136c15dbde5ea89ac611d64b1478ec455e2cf6d` |
| `judge/tpl-grade.md` | 채점 답 판정자 틀 | `2159d6b8d3998a41523162a698b67c03c20289fdab7bd226d2050f9bb56723e0` |
| `judge/stance-quiz.md` | 퀴즈 판정자에게 주는 입장(이 절에서 자름) | `bcf9939fbeb2a3de6e8aebe4923cf247f12e8f01c20021470cdef504f71ce1fd` |
| `judge/stance-grade.md` | 채점 답 판정자에게 주는 입장(이 절에서 자름) | `be562306ed9e1dc88d63ecdd7f705b10d1acf7a926f7a7a0f37307e76ee0849c` |
| `d34/make.py` | D34 하네스 잡기 · 견줌(퀴즈 · 채점 길) | `eff9ed24eb7e5f6aa1fc59a97d613f40532a937620dd58ad4c18f2be3519cdf4` |
| `probe/call.sh` | 프로브 세션 | `a7b2d5656e26431f29564a605f35256828282cdcdaadf21c82e868531fa12558` |
| `probe/precheck.sh` | 앞 'ok' 세션 | `61e0361c8d1a1009320a87cd859a15565d03d708106d0c39c6f6c071034e1785` |
| `probe/record.py` | 세션 기록 읽기 | `8e3eeafc61ab66eb3a1613de938cdbd2231dbd4b0642632330d4298021fb45e6` |
| `probe/mod/hooks/register.ts` | 프로브 mod(/g3probe) | `b9ef3aee32c2bb07af0b70296fe4e602895a9c8a5b7778cd11f0d96e73fa3118` |
| `probe/mod/hooks/notes.ts` | 프로브 notes.ts(= mtree) | `4a86a55118245765c64a3ebe626602e22a260358aa98715b0c75c79c2b8bfbad` |
| `probe/mod/hooks/hooks.json` | 프로브 mod | `c835c92d8e1159d20a40ca78ad654da7433942c3694ffeda0b376b0c4dfd52cf` |
| `probe/mod/.claude-plugin/plugin.json` | 프로브 mod | `caf9540cb8d54e41f4a18e50f8170949e36efa109c70b16fa179bdb6fcedc717` |
| `tap/call.sh` | 탭 세션 | `fe746c277f397ba5bef8f43b69bd8b5e9f98721c1344541f06e7401d84ea2af2` |
| `tap/tap.py` | 탭(1.11.0 · 묶음 1 · 2와 같음) | `e8d8174b09e11c74e6d744e4c44bc62033436d2ab35be6daa95d27026d17db9b` |
| `tap/mod/hooks/register.ts` | 탭 mod(/g3tap) | `f5829ca09bd5fe21da15242c44a6658d1db426becf57831fe3dbfc27e88b60f9` |
| `tap/mod/hooks/hooks.json` | 탭 mod | `c835c92d8e1159d20a40ca78ad654da7433942c3694ffeda0b376b0c4dfd52cf` |
| `tap/mod/.claude-plugin/plugin.json` | 탭 mod | `d7b49f50f5c8c55328c517cc628a1486084e55fc34b8cc98e2439d2f261d28af` |
| `tap/mod/tsconfig.json` | 탭 mod | `88437ec880f7008b5df208a95a7d47330f0e3a8204d78d6c5cc272e5941c3511` |
| `mtree/hooks/notes.ts` | 짓기 트리(f03b362) | `4a86a55118245765c64a3ebe626602e22a260358aa98715b0c75c79c2b8bfbad` |
| `mtree/hooks/register.tsx` | 짓기 트리(f03b362) | `ea49420a7d39c44e8e5498bb16f66d45907ca4a515e16b31263329d845de3b6f` |
| `jtree/hooks/notes.ts` | 읽기 기록 트리(quizParts export만 더함) | `1d3a60a9b14964c367158a779154f183511abf416374fb30b943ecee75915d41` |
| `off/run-offbytes.mts` | 끈 바이트(짓기 때) | `3cdc410fc636391dda4801e95f0415ca5eb11869e22824a0a356b6c6d7e73739` |
| `off/run-offsplit.mts` | 끈 바이트 나눠 셈(짓기 때) | `a2bb952d568496e6b805b001683723d4a7ea3805ffdae866389b7b1cdc0e0714` |
| `off/run-off111.mts` | 끈 바이트 1.11.0(짓기 때) | `9c98b28a9fc103efac24140ee5d9c12979ee238107d6e34014fc671ef039644f` |
| `off/run-off190b.mts` | 끈 바이트 1.9.0(짓기 때) | `5a8618f6ad5fb68507908ee18a8b0c5a803e720c76a79aae49ccc472fb2bebdd` |
| `oldprobe/probe.mts` | 옛 창 여섯(짓기 때) | `e5fa56ba0a353dc4c8e3d35b594261692ac99937d120572cff26afb90054cacc` |
| `mut/run.py` | 돌연변이 탐침(짓기 때) | `6937c7baf3d93dd4ad4a921e9c33702913ac0440cd8e60d2765092220bc37904` |
| `said-lists.sha256` | localRight 닫힌 목록 sha256(짓기 때) | `e36aebfe7ec971016fe71fa052a960ad4ad91f680eb4bbff85fde4e1ec3c8231` |
| `../d26/rulewide.mjs` | isRuleWide D26 재확인(짓기 때) | `c89d0800f3ca4bb0e3aaf5913b359d3273e6ad888ecab31751159d77fc7a5283` |
| `../cli/pinned.sh` | 고정한 길(묶음 0, chmod 555) | `e80f767481780e27fd6915d8f603bb5c07d18d08192efb0639d9629e811e3473` |

