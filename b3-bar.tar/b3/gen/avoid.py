"""learn-notes 1.12.0 G3 (batch 3; b2 avoid.py as it was): the writers' avoid section, from impl112/NAMES-all.txt as it is when a writer runs
(plan batches[3].samples.avoid: design/G3/dev/NAMES.txt, the P1-P6 probe items and every 1.8.0-1.11.0 name are in it, with every other
G1-G6 dev and measured name and every 견본.md name). Two lists: concept names (every entry that is not an id, a path or
a file name, 2-30 characters, not starting with a quote) and file paths (every entry with a slash or a code file's
extension). Sorted, one comma list each.
usage: avoid.py <out.md>   (refuses to overwrite)"""
import os, re, sys
NAMES = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/NAMES-all.txt"
ID = re.compile(r"^[A-Za-z]{0,4}\d+[A-Za-z]?\d*$")
FILE = re.compile(r"(/|\.(js|mjs|cjs|ts|tsx|jsx|py|json|md|css|html)$)")


def lists():
    allnames = sorted({l.split("\t", 1)[0] for l in open(NAMES, encoding="utf-8") if l.strip()})
    files = [x for x in allnames if FILE.search(x)]
    concepts = [x for x in allnames if not FILE.search(x) and not ID.match(x) and 2 <= len(x) <= 30 and x[0] not in "'\"`"]
    return concepts, files


if __name__ == "__main__":
    out = sys.argv[1]
    if os.path.exists(out):
        sys.exit(f"refuse: {out} exists")
    concepts, files = lists()
    open(out, "w", encoding="utf-8").write(
        "\nDo not use any of these concepts or names as a record's name, and do not write a record about any of them (they are taken):\n"
        + ", ".join(concepts)
        + "\n\nDo not use any of these as a record's file path (they are taken):\n"
        + ", ".join(files)
        + "\n"
    )
    print(len(concepts), len(files))
