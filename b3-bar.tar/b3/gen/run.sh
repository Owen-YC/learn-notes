#!/bin/bash
# learn-notes 1.12.0 G3 (batch 3; from batch 2's run.sh): one fresh blind sample writer (plan batches[3].samples.writers:
# 1-2 writers; SCOPE step 3). A = S-A1 + S-A2 (68 records: set P = S-A1, set Q = S-A2), B = S-O fillers + the 9 S-U
# records. usage: run.sh <A|B> <try: 1|2>   try 2 only when check.py says 'WRITE <part> 2' (the reply held no one
# readable JSON value: the same prompt once more; a second failure is a STOP, never a third call).
# prompt = gen/writer-<part>.md + the avoid section (gen/avoid.py from NAMES-all.txt as it is now) + gen/writer-<part>-end.md,
# on stdin to `claude -p --model opus --tools ''` in an empty dir, through the pinned CLI (cli/pinned.sh,
# DISABLE_AUTOUPDATER=1). The writer sees only the record form, the code rules, the minimums and the avoid lists: never
# the rule wording, a prompt, the code, the stance, the design or which model is measured. Try 2 sends try 1's prompt
# file byte for byte. Refuses when its out dir exists.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3
P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh
PART="$1"; TRY="$2"
case "$PART" in A|B) ;; *) echo "usage: run.sh <A|B> <1|2>"; exit 2;; esac
case "$TRY" in 1|2) ;; *) echo "usage: run.sh <A|B> <1|2>"; exit 2;; esac
O="${S:?}/gen/out/$PART$TRY"
[ -e "$O" ] && { echo "refuse: $O exists"; exit 1; }
if [ "$TRY" = 2 ]; then
  [ -s "${S:?}/gen/out/${PART}1/prompt.md" ] || { echo "refuse: no try 1 prompt"; exit 2; }
  mkdir -p "$O" "${S:?}/work/gen-$PART$TRY"
  cp "${S:?}/gen/out/${PART}1/prompt.md" "$O/prompt.md"
else
  mkdir -p "$O" "${S:?}/work/gen-$PART$TRY"
  python3 -I "${S:?}/gen/avoid.py" "$O/avoid.md" > "$O/avoid-count.txt" || exit 1
  cat "${S:?}/gen/writer-$PART.md" "$O/avoid.md" "${S:?}/gen/writer-$PART-end.md" > "$O/prompt.md"
fi
sha256sum "$O/prompt.md" > "$O/prompt.sha256"
cd "${S:?}/work/gen-$PART$TRY" || exit 1
date -u +%FT%TZ > "$O/started.txt"
"$P" bash -c 'timeout 3000 claude -p --model opus --tools "" --output-format json' < "$O/prompt.md" > "$O/out.json" 2> "$O/err.txt"
echo "exit=$?" > "$O/exit.txt"
date -u +%FT%TZ > "$O/ended.txt"
"$P" --record > "$O/pin.txt" 2>&1
python3 -I - "$O" <<'PY'
import json, sys
o = sys.argv[1]
try:
    d = json.load(open(o + "/out.json", encoding="utf-8"))
except Exception as e:
    d = {"result": "", "is_error": f"unreadable out.json: {e}"}
open(o + "/result.txt", "w", encoding="utf-8").write(d.get("result") or "")
open(o + "/model.txt", "w").write(json.dumps(sorted((d.get("modelUsage") or {}).keys())) + "\n")
print("writer", o, "is_error", d.get("is_error"))
PY
cat "$O/exit.txt"
