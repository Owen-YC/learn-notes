You are writing practice data for a Korean programming-education tool. Write records of programming concepts as a beginner "vibe coder" met them in small code files of their own projects. Every record is one concept and the whole small file the beginner wrote with it.

Each record is a JSON object:
- "id": as specified below.
- "group": "T" (a tricky pitfall concept a beginner often gets wrong) or "R" (a basic, everyday concept).
- "name": a short Korean concept name the way a tutor's note names a concept: the topic words only (2 to 6 words, a code word such as a method or operator name may be in it), not a sentence and not "<topic>: <situation>". No backticks, no asterisks, no "--", no colon.
- "situation": optional, one short Korean phrase saying what the beginner was doing in the file (it is kept apart from the name).
- "blurb": 1-2 Korean sentences in 합니다체 that explain the concept the way a tutor's note would, then " — " and exactly one code line from the file quoted in single backticks (copied character for character from "code", a line that shows the concept; not a line that prints). No other backticks, no asterisks, no "--".
- "file": a relative path like "src/<folder>/<name>.<ext>", ext js, mjs or cjs for JavaScript and py for Python, matching the language the id asks for. Every record a different path.
- "code": the whole file, 3 to 8 non-blank lines, that runs alone with plain `node` or `python3`: no import or require, no input, no files, no network, no time or dates, no randomness, no timers, no Promise or async, no classes from a browser page, no process or sys. It always prints the same thing and prints 1 to 3 lines in total, each line at most 40 characters. No comments. Write it the way a beginner's small script looks (it may print inside a loop or a function if that is natural).
- "output": exactly what running the file prints, lines joined by "\n" (no trailing newline).
- "tags": a list chosen from ["canonical-pitfall", "prints-in-loop", "string-output", "py-bool-none", "three-lines"] that apply: canonical-pitfall = one of the classic beginner traps of the language; prints-in-loop = the code prints inside a loop; string-output = the printed values are text, not numbers; py-bool-none = Python that prints True, False or None; three-lines = prints exactly 3 lines.

Which concepts: only concepts about what plain JavaScript or Python code does when it runs. Not TypeScript and no type annotations; not concepts about types alone; not concepts about the order things run in (timers, Promise, async, events); not concepts about a string's letters or spaces (slicing a string, reversing, padding, palindromes, character positions). Every record a different concept, and no two records anywhere in this reply about the same concept.

Write exactly 68 records in two sets of 34. The two sets have the same shape and must not share a concept, a name or a file:
- Set P: ids pT01..pT12 are group T (pT01-pT06 JavaScript, pT07-pT12 Python); ids pR01..pR22 are group R (pR01-pR12 JavaScript, pR13-pR22 Python).
- Set Q: ids qT01..qT12 are group T (qT01-qT06 JavaScript, qT07-qT12 Python); ids qR01..qR22 are group R (qR01-qR12 JavaScript, qR13-qR22 Python).
In each set of 34, at least: 5 records tagged canonical-pitfall, 4 tagged prints-in-loop, 3 tagged string-output, 3 tagged py-bool-none, 3 tagged three-lines (more is fine).
Do not use floats whose printed form is long, sets, dates, or randomness. Double-check every output by tracing the code carefully; a wrong output makes the record useless.
