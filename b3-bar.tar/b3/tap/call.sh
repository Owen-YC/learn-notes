#!/bin/bash
# (learn-notes 1.12.0 G3 batch 3: batch 2 copy of impl111/b7/tap/call.sh, B and the command moved.)
# usage: call.sh <outdir> <alias> <lines.jsonl>   (record only, B-12)
# Starts the local tap (tap.py, on a free port, forwarding to the session's own ANTHROPIC_BASE_URL or
# https://api.anthropic.com) and one session with the alias whose ANTHROPIC_BASE_URL is the tap, which runs
# '/g3tap <lines> <outdir>/sent.json'. The tap writes <outdir>/tap.jsonl (request shape, stop_reason, stop_details).
B=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3
O="$1"; A="$2"; LINES="$3"
[ -n "$O" ] && [ -n "$A" ] && [ -f "$LINES" ] || { echo "usage: call.sh <outdir> <alias> <lines.jsonl>"; exit 2; }
case "$A" in haiku|sonnet) ;; *) echo "refuse: alias must be haiku or sonnet"; exit 2;; esac
mkdir -p "$O"
[ -e "$O/sent.json" ] && { echo "refuse: $O/sent.json exists"; exit 1; }
UPSTREAM="${TAP_UPSTREAM:-${ANTHROPIC_BASE_URL:-https://api.anthropic.com}}"
PORT=$(python3 -I -c 'import socket; s=socket.socket(); s.bind(("127.0.0.1",0)); print(s.getsockname()[1]); s.close()')
python3 -I "${B:?}/tap/tap.py" "$PORT" "$O/tap.jsonl" "$UPSTREAM" > "$O/tap.out" 2>&1 &
TAP=$!
for i in $(seq 50); do grep -q listening "$O/tap.out" 2>/dev/null && break; sleep 0.1; done
mkdir -p "${B:?}/work/empty" && cd "${B:?}/work/empty" || exit 1
export DISABLE_AUTOUPDATER=1
claude --version > "$O/version.txt" 2>&1
date -u +%FT%TZ > "$O/started.txt"
python3 -I - "$LINES" "$O/sent.json" > "$O/input.jsonl" <<'PY'
import json, sys
print(json.dumps({"type": "user", "message": {"role": "user", "content": f"/g3tap {sys.argv[1]} {sys.argv[2]}"}}, ensure_ascii=False))
PY
ANTHROPIC_BASE_URL="http://127.0.0.1:$PORT" timeout 1800 claude -p --model "$A" --tools '' --plugin-dir "${B:?}/tap/mod" --input-format stream-json --output-format stream-json --verbose < "$O/input.jsonl" > "$O/stream.jsonl" 2> "$O/err.txt"
echo "exit=$?" > "$O/exit.txt"
date -u +%FT%TZ > "$O/ended.txt"
kill "$TAP" 2>/dev/null; wait "$TAP" 2>/dev/null
python3 -I "${B:?}/probe/record.py" "$O" > /dev/null
echo "tap done: $(wc -l < "$O/tap.jsonl" 2>/dev/null || echo 0) requests recorded"
