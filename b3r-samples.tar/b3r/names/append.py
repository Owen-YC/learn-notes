"""learn-notes 1.12.0 G3 retry (b3r; from b2/names/append.py): append this round's measured names to impl112/NAMES-all.txt
right after the sample freeze (견본.md '이름 목록' 덧붙임). Lines = every line of b3/frozen/NAMES.txt (check.py: names,
the writers' situation phrases and file paths, tag G3-measured) plus every record id and every name a record's code
defines (function/def/class, export const/let, top-level const NAME = ( / function / arrow) from b3/frozen/raw.json,
tag G3-measured. Also writes names/overlap.json: entries already in NAMES-all.txt before the append (record only).
Sorted in byte order, duplicate lines dropped; chmod 444 again. usage: append.py (model calls 0; refuses when
G3-measured lines are already there)."""
import hashlib, json, os, re
SP = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad"
NAMES = SP + "/impl112/NAMES-all.txt"
FR = SP + "/impl112/b3/frozen"
OUT = SP + "/impl112/b3r/names"
old = [l for l in open(NAMES, "rb").read().decode("utf-8").split("\n") if l]
if any(l.split("\t")[1] == "G3-measured" for l in old if "\t" in l):
    raise SystemExit("refuse: G3-measured already appended")
before = {l.split("\t")[0] for l in old}
new = [l for l in open(FR + "/NAMES.txt", encoding="utf-8").read().split("\n") if l]
DEF = [re.compile(p, re.M) for p in (r"\bfunction\s*\*?\s*([A-Za-z_$][\w$]*)", r"^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)",
       r"^\s*class\s+([A-Za-z_$][\w$]*)", r"^\s*export\s+(?:const|let|var)\s+([A-Za-z_$][\w$]*)",
       r"^(?:const|let)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\(|function|[A-Za-z_$][\w$]*\s*=>)")]
raw = json.load(open(FR + "/raw.json", encoding="utf-8"))
recs = []
def walk(x):
    if isinstance(x, dict):
        if isinstance(x.get("id"), str):
            recs.append(x)
        for v in x.values():
            walk(v)
    elif isinstance(x, list):
        for v in x:
            walk(v)
walk(raw)
extra = set()
for r in recs:
    extra.add(r["id"])
    for k in ("code", "before", "after", "lines"):
        t = r.get(k) or ""
        if isinstance(t, str):
            for p in DEF:
                extra.update(m.group(1) for m in p.finditer(t))
src = "impl112/b3/frozen/raw.json"
add = new + [f"{n}\tG3-measured\t{src}" for n in sorted(extra)]
overlap = sorted({l.split("\t")[0] for l in add} & before)
allx = sorted(set(old + add), key=lambda s: s.encode("utf-8"))
os.chmod(NAMES, 0o644)
open(NAMES, "wb").write(("\n".join(allx) + "\n").encode("utf-8"))
os.chmod(NAMES, 0o444)
json.dump({"overlap": overlap, "added_lines": len(add), "records": len(recs)}, open(OUT + "/overlap.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps({"lines": len(allx), "added": len(set(add) - set(old)), "overlap": len(overlap), "records": len(recs),
                  "sha256": hashlib.sha256(open(NAMES, "rb").read()).hexdigest()}, ensure_ascii=False))
