// learn-notes 1.12.0 G3 (batch 3): the quiz requests of the measured round, made as makeQuiz makes them, from the committed
// tree (kit.mjs: b3/mtree = f03b362) with haiku's row as the earlier batches left it and rungNewStep 4 over it (M-13).
// usage: node --experimental-transform-types build.mjs <frozen dir> [<out dir> <YYYY-MM-DD>]
//   reads <frozen>/samples.json and layout.json (check.py). The scene day is the measuring day: samples.day, or, when the
//   calls fall on another UTC day, that day given with an out dir (frozen/day-<day>, the same frozen samples and tools,
//   its own D34; stage.sh takes the lines of the day it starts on). Writes into <out dir> (default <frozen>), chmod
//   444, refusing existing files:
//   build.json   each quiz's slots, picks, rungs alone, after ladderMixed, after withScenes, scenes, prompt, redact hits,
//                maxTokens; the Q3 screen (each S-U record in the edit and the new-file shape, alone at step 4 beside the
//                two 내 코드 fillers: its rung); the U quiz if any S-U record reaches 'new' in a shape: those records
//                (each once, in the first shape that reached it, at most 3) then the 내 코드 fillers up to three picks.
//   lines-P.jsonl  S-A1's 18 quizzes (P-N01..P-N15, P-M1..P-M3), lines-Q.jsonl S-A2's 18 (sent only if Q1 is 27 or 28),
//   lines-U.jsonl  the U quiz (absent when no S-U record reaches 'new'): { id, model 'haiku', system QUIZ_SYSTEM,
//                prompt, maxTokens, timeoutMs 90000 } per line.
//   Exit 3 (nothing written) when a measured N slot that check.py did not keep failing is not 'new', a 내 코드 filler is
//   not 'mine', a 다시 도전 or 왜 filler has a rung, a prompt's redactText hits are not 0, or a quiz's maxTokens is not 4600.
//   M slots are records for Q1 and are only reported.
import { readFileSync, writeFileSync, existsSync, chmodSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { N, quizOf, QUIZ_TRACE_TOKENS, ROW, STEPS } from './kit.mjs'

const src = process.argv[2]
const dir = process.argv[3] ?? src
if (process.argv[3] !== undefined && !/^\d{4}-\d{2}-\d{2}$/.test(process.argv[4] ?? '')) { console.log('usage: build.mjs <frozen> [<out dir> <YYYY-MM-DD>]'); process.exit(2) }
if (process.argv[3] !== undefined) mkdirSync(dir, { recursive: true })
const OUT = ['build.json', 'lines-P.jsonl', 'lines-Q.jsonl', 'lines-U.jsonl']
for (const f of OUT) if (existsSync(join(dir, f))) { console.log(`refuse: ${f} exists`); process.exit(1) }
const S = JSON.parse(readFileSync(join(src, 'samples.json'), 'utf8'))
const L = JSON.parse(readFileSync(join(src, 'layout.json'), 'utf8'))
const day = process.argv[4] ?? S.day
const recs = { ...S.sets.P, ...S.sets.Q, ...S.fillers, ...Object.fromEntries(S.unrunnable.map(r => [r.id, r])) }
const out = { day, row: ROW, steps: STEPS, sets: {}, q3: [], uquiz: null }
const bad = [], notes = []
for (const s of ['P', 'Q']) {
  const lay = L[s]
  const failing = new Set(lay.keptFailing)
  const qs = []
  for (const q of lay.quizzes) {
    const made = quizOf(q.slots, recs, day)
    q.slots.forEach((slot, i) => {
      const r = made.rungs[i]
      const isM = q.id.includes('-M')
      if (/^o(m)/.test(slot.id)) { if (r !== 'mine') bad.push(`${q.id} ${slot.id} rung ${r} not mine`) }
      else if (/^o(s|c)/.test(slot.id)) { if (r !== undefined) bad.push(`${q.id} ${slot.id} rung ${r} not none`) }
      else if (r !== 'new') (isM || failing.has(slot.id) ? notes : bad).push(`${q.id} ${slot.id} rung ${r} not new${isM ? ' (M: record)' : failing.has(slot.id) ? ' (kept failing: a Q1 miss)' : ''}`)
    })
    if (made.redactHits !== 0) bad.push(`${q.id} redact hits ${made.redactHits}`)
    if (made.maxTokens !== QUIZ_TRACE_TOKENS) bad.push(`${q.id} maxTokens ${made.maxTokens}`)
    qs.push({ id: q.id, slots: q.slots, ...made })
  }
  out.sets[s] = qs
}
// Q3 screen: each S-U record alone at step 4 beside the two 내 코드 fillers, in both shapes.
const newU = []
for (const u of S.unrunnable) for (const shape of ['edit', 'create']) {
  let rung = null, err = null
  try { rung = quizOf([{ id: u.id, step: 4, shape }, { id: 'om1', step: 2 }, { id: 'om2', step: 2 }], recs, day).rungs[0] ?? null } catch (e) { err = String(e).slice(0, 200) }
  out.q3.push({ id: u.id, shape, rung, err })
  if (rung === 'new' && !newU.some(x => x.id === u.id)) newU.push({ id: u.id, step: 4, shape })
}
if (newU.length > 0) {
  const slots = [...newU.slice(0, 3)]
  for (const f of ['om1', 'om2']) if (slots.length < 3) slots.push({ id: f, step: 2 })
  out.uquiz = { id: 'U-1', slots, ...quizOf(slots, recs, day), left: newU.slice(3) }
}
if (bad.length) { console.log(bad.join('\n')); process.exit(3) }
const line = q => JSON.stringify({ id: q.id, model: 'haiku', system: N.QUIZ_SYSTEM, prompt: q.prompt, maxTokens: q.maxTokens, timeoutMs: 90000 })
writeFileSync(join(dir, 'build.json'), JSON.stringify(out, null, 1) + '\n')
writeFileSync(join(dir, 'lines-P.jsonl'), out.sets.P.map(line).join('\n') + '\n')
writeFileSync(join(dir, 'lines-Q.jsonl'), out.sets.Q.map(line).join('\n') + '\n')
const written = ['build.json', 'lines-P.jsonl', 'lines-Q.jsonl']
if (out.uquiz) { writeFileSync(join(dir, 'lines-U.jsonl'), line(out.uquiz) + '\n'); written.push('lines-U.jsonl') }
for (const f of written) chmodSync(join(dir, f), 0o444)
for (const s of ['P', 'Q']) for (const q of out.sets[s]) console.log(q.id, q.rungs.map(r => r ?? '-').join(','), 'scenes', q.scenes.map(x => x ?? '-').join(','), 'chars', q.prompt.length, 'max', q.maxTokens)
console.log('Q3', ['edit', 'create'].map(sh => `${sh} non-new ${out.q3.filter(x => x.shape === sh && x.rung !== 'new').length}/9`).join(' '), out.uquiz ? `U quiz ${out.uquiz.slots.map(x => x.id + ':' + (x.shape ?? '')).join(' ')}` : 'no U quiz')
for (const n of notes) console.log('note:', n)
