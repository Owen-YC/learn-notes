당신은 측정 도구의 고침을 확인하는 검토자입니다. 아래의 커밋된 기준 글(A)과 견본 쓰는 쪽 프롬프트의 문장(B), 그리고 얼리기 도구에 한 고침(C)만 봅니다. 견본 자체나 측정 결과는 보지 않습니다.

규칙(M-15): "얼린 셈 도구가 커밋된 글과 다르게 센 것을 ... 찾으면, 글이 이깁니다. 도구를 글에 맞게 고치고 ... 고친 셈이 못 넘음을 넘음으로 바꾸면, 새 하위 에이전트가 글과 고친 곳만 보고 '글을 옮긴 고침'임을 확인한 뒤에만 그 수를 씁니다. 확인하지 못하면 고치기 전 수입니다."

물음: 고침 C가 도구를 글 A(그리고 A가 가리키는 B)에 맞게 옮긴 것일 뿐이고, 글이 정하지 않은 것을 더하거나 글보다 너그럽게 만든 것이 아닌지 판단하십시오. 글이 이 점(빈 줄을 세는지)을 정하지 않아 판단할 수 없다면 그렇게 답하십시오.

답의 꼴: 첫 줄에 정확히 'VERDICT: CONFIRMED'(글을 옮긴 고침) 또는 'VERDICT: NOT CONFIRMED'(아니거나 판단할 수 없음). 그 아래 한국어로 까닭 3–6줄.

(A) 커밋된 기준 글 (docs/qa/견본.md, G3 다시 기준 절)
--- 읽는 법 8 ---
8. S-U의 확인(원문에 없는 확인으로, 더 엄격함): 편집 꼴(import는 조각 밖)을 지을 수 있도록 쓰는 쪽 프롬프트가 정한 꼴(js 5 · py 4, 12–20줄, 인용 줄이 파일의 한 줄이고 그 위에 적어도 8줄)을 얼릴 때 봅니다. S-U에는 예비가 없으므로 못 넘은 기록은 Q3에서 처음 보는 코드로 간 것으로 셉니다(불리한 쪽; 설계 '남은 예비가 없는 자리는 놓침'과 같은 셈).
--- 도구가 글을 읽는 방식 3 (첫 문장) ---
3. 얼리기(`tools/check.py` · `tools/runlib.py` · `tools/kit.mjs`): 쓴 그대로를 `frozen/raw.json`으로 묶고, 기록마다 꼴(id · 무리 · 확장자 · 이름 · 노트 읽기가 이름과 blurb를 쓴 그대로 읽음 · blurb의 ' — `한 줄`' · 인용 줄이 코드의 찍지 않는 한 줄 · 공백 아닌 줄 3–8), 돌림(입장 5의 돌리기: 끝 코드 0 · 모두 같음 · 1–3줄 · 줄마다 40 코드 포인트 이하 · 적힌 output과 줄마다 같음
--- 견본의 짜임 (설계 samples, S-U 줄) ---
- S-U: 부를 수 없는 개념 9(js 5 · py 4: 조각 밖의 라이브러리 import, jQuery $(, 데코레이터, fetch/XHR/WebSocket, process./node: I/O), 각각 도구가 편집 꼴(import는 조각 밖, 작업 트리의 파일 글을 줌)과 새 파일 꼴로 지음.

(B) 견본 쓰는 쪽 프롬프트 b3r/gen/writer-U.md 의 S-U 문장 (영어 원문 그대로)
"unrunnable": 9 records {id, name, blurb, file, lines} for concepts whose code cannot run alone because it needs a library, a framework, a browser page, the network or the process and its files. "lines" is the whole file (12-20 lines) as one string with "\n": its import/require lines (if any) at the top, then at least 8 lines later the line the blurb quotes. ou1-ou5 JavaScript (.js or .mjs): ou1 a library imported at the top of the file, ou2 jQuery's $( on a page, ou3 fetch, XMLHttpRequest or WebSocket, ou4 Node's process. or a node: module's I/O, ou5 another library imported at the top of the file. ou6-ou9 Python (.py): ou6 a library imported at the top of the file, ou7 a decorator, ou8 another library imported at the top of the file, ou9 another decorator. Each a different concept.

(C) 얼리기 도구 check.py 의 고침 (머리 설명에는 "S-U: ou1-ou5 js/mjs, ou6-ou9 py, lines 12-20, the quote a line of lines with at least 8 lines above it" 라고 적혀 있음; lines 는 쓰는 쪽이 준 파일 전체 글을 "\n"으로 나눈 것)
--- tools/check.py	2026-11-14 10:17:54.954592679 +0000
+++ tools-m15/check.py	2026-11-15 04:08:56.532446542 +0000
@@ -350,7 +350,7 @@
         lines = (r.get("lines") or "").split("\n")
         _, q = quote_of(r.get("blurb"))
         at = next((j for j, l in enumerate(lines) if q and l.strip() == q.strip()), None)
-        if runlib.lang_of_file(r.get("file", "")) != lang or not (12 <= len([l for l in lines if l.strip()]) <= 20):
+        if runlib.lang_of_file(r.get("file", "")) != lang or not (12 <= len(lines) <= 20):
             why.append("shape")
         if at is None or at < 8:
             why.append("quote")
