# 판정의 입장

판정의 입장 (G3, 1.12.0 G3-KLA). 기준 · 결정 규칙 · 짜임 · 견본 쓰기 프롬프트와 함께, 견본을 쓰거나 부르기 전에 docs/qa/견본.md 새 절로 한 커밋에 넣습니다(UTC 시각, 가리키는 코드 커밋 해시). 매기는 쪽은 이 글의 조항만 따르고 판정마다 조항 번호를 적습니다. ⚙ 조항은 eval 도구(부르기 전에 sha256으로 얼림)가 세고, ✎ 조항만 매기는 하위 에이전트(꼬리표마다 한 명)가 매깁니다. 1.10.0의 일곱 조항 번호와 뜻을 그대로 두고, 이 설계에서 쓰이지 않는 갈래는 "쓰이지 않음"으로 적었습니다. 이 글이 정하지 않은 경우는 못 넘음입니다(M-11).

0 셈의 단위: Q1은 15퀴즈의 처음 보는 코드 자리 30개(둘째 묶음을 재면 60개)입니다. M1 · M2 · M3의 처음 보는 코드 자리는 Q1에 넣지 않고 기록만 하며 Q2에는 넣습니다. 같은 퀴즈의 내 코드 · 왜 · 다시 도전 문항은 셈 밖이고 기록만 합니다. Q3는 U 개념 아홉의 두 꼴(편집 · 새 파일)입니다.

1 읽기 ⚙: 플러그인처럼 fixEscapedTicks → 그 커밋의 parseQuiz로 읽어 저장될 문항(question · hint · answer · kind · rung)만 매깁니다. 모델의 K · L · A 날글, 상황 줄, 되풀이해 쓴 앞의 K · L · A(나중 것이 읽힘), A 아래 빈 줄 뒤의 글은 저장되지 않으므로 판정 대상이 아닙니다. 1을 넘으려면 그 자리의 문항이 저장되어 rung new · kind predict이고 question(펜스 하나) · hint · answer가 모두 있어야 합니다. 플러그인 읽기가 그 자리를 거절해 문항이 없으면(missing · blocks · lang · comment · string · long · forbidden · spacing · print-form · print-place · print-count · output · count · mine · question-long) 1에서 놓침이고 거절 까닭은 기록만 합니다. 코드 없이 물은 문제는 생길 수 없고, 생기면 1에서 놓침입니다.

2 꼴 ⚙: 저장된 question 안의 펜스 블록이 꼭 하나이고(플러그인이 씀), 펜스 안에서 공백뿐인 줄을 뺀 줄이 8 이하입니다. 판정은 학습자가 보는 그대로, 곧 플러그인이 주석을 지운 뒤의 코드로 합니다. 언어 무리: js = js · javascript · mjs · cjs · node, py = py · python · python3; 플러그인 펜스(js 또는 python)는 물은 언어(파일 확장자)의 무리와 늘 같아야 하며 다르면 놓침입니다. ts는 이 설계에서 쓰이지 않음(ts 개념은 처음 보는 코드로 묻지 않음).

3 내 코드가 아님: 문제 코드와 그 개념 견본의 code를 견줍니다. ⚙ (가) 공백을 모두 뺀 두 글이 같음. ⚙ (나) 문제 코드의 줄(공백뿐인 줄과 괄호 · 중괄호 · 대괄호 · 쉼표 · 세미콜론 · 콜론만 있는 줄은 뺌) 가운데 절반 이상이, 공백을 뺀 꼴로 개념 코드의 어느 줄과 같음. ⚙ (다) 두 코드의 이름(식별자; 그 언어의 예약어와 console · print · len · range · str · int · float · list · dict · Math · Object · Array · JSON · String · Number는 그대로)을 처음 나온 차례대로 v1, v2 …로 바꾸고 공백을 뺀 뒤 같거나, 다른 곳이 리터럴(숫자 · 문자열) 하나뿐임(개념 코드 전체나 같은 줄 수의 이어진 줄과 견줌). ✎ (라) 판정 하위 에이전트가 같은 상황(이름 · 값 · 쓰임이 모두 개념 코드와 같은 일)이라고 이유와 함께 적음. 넷 가운데 하나면 놓침입니다. 같은 메서드 · 연산자나 흔한 예(정렬 기본 순서 · map · reduce · 클로저 push)를 쓴 것, 플러그인이 준 상황 이름을 쓰지 않은 것만으로는 놓침이 아닙니다. 흔한 예를 이름과 값을 바꿔 다시 쓴 것은 (다)에 걸리지 않고 이름 · 값이 다르면 (라)에서 넘음입니다(1.10.0 셈 그대로; 개발 기록 set1 T07).

4 개념이 출력을 정함 ✎: 출력의 적어도 한 줄이 개념 견본 blurb가 말한 동작으로 정해져야 합니다(그 동작을 모르면 그 줄을 맞힐 수 없음). 판정 하위 에이전트가 이유 한 줄과 함께 매깁니다. 판정은 6의 꼴로 맞춘 출력(줄 앞뒤 공백을 떼고 안쪽 공백을 하나로)에 대해 합니다: 공백에만 드러나는 동작은 그 꼴에서 보이지 않으므로 놓침입니다. 개념의 동작이 일어나지 않게 짠 코드(가변 기본 인자를 한 번만 부름, 클로저를 반복 안에서 바로 부름, 얕은 복사를 고치지 않고 찍음)는 놓침입니다(개발 기록 set1 N02-r2#1 T07). 그 동작을 모르는 학습자가 흔한 짐작으로 맞히게 되는 줄만 있으면 놓침이고, 다른 한 줄이라도 그 동작에 달렸으면 넘음입니다. 타입 표기 · 실행 순서 · 문자열 글자 개념은 이 설계의 범위 밖이라 견본에 없어야 하며, 있다면 이 조항대로 매깁니다.

5 돌림 ⚙: 보인 그대로 돌립니다(보이지 않는 정의 · import · 입력 · 파일 · 환경 · 앞선 상태를 채우지 않음; B-1, B-2). 빈 임시 폴더에서 `unshare -n timeout 5`: js는 node로 두 번, 모듈 문법 오류일 때만 .cjs로 한 번 더; py는 B-14(`env -i PATH="$PATH" LANG=C.UTF-8 PYTHONHASHSEED=<n> python3 -s -P -B 파일`, n = 1~5, 다섯 번 모두 같아야 함). 끝 코드 0, 같은 출력. 금지 기능(grep 뒤 하위 에이전트가 쓰임인지 확인; 문자열 · 주석 안 낱말은 쓰임이 아님): js Math.random · Date · performance. · fetch · XMLHttpRequest · WebSocket · require( · import · process · fs · document · window · localStorage · sessionStorage · alert( · prompt( · readline; py random · time · datetime · input( · open( · os · sys · subprocess · socket · urllib · requests · pathlib. 출력은 끝 줄바꿈 하나를 떼고 3줄 이하, 줄마다 40 코드 포인트 이하. 위 목록에 없는 표준 기능(math, functools, itertools …)과 플러그인 읽기가 더 막는 것(set, 타이머 등)은 이 조항의 금지가 아닙니다(읽기가 막으면 1에서 놓침).

6 A와 출력 ⚙: 저장된 answer와 stdout을 견줍니다. stdout은 끝 줄바꿈 하나를 떼고 줄로 나눕니다. 줄마다 앞뒤 공백을 떼고 안쪽 공백 · 탭이 이어진 곳을 하나로, 줄 끝 마침표 하나를 떼고, 따옴표의 종류(' " ` ‘ ’ “ ”)만 같게 봅니다. 따옴표가 있고 없음은 다름입니다. 값 · 순서 · 줄 수(빈 줄 포함)는 그대로 봅니다. True와 true, None과 null, 1과 1.0은 다른 값입니다. stderr는 보지 않습니다. 틀리게 짐작한 A(`'pythonista'[7:]` → ista, 개발 기록 R18 44 대 45)는 놓침입니다. 일부 줄만 묻는 문제의 셈(A가 출력 전부면 넘음, 물은 줄만 적었으면 놓침)은 1.10.0 그대로 두지만, 플러그인의 질문이 늘 출력 전부를 묻고 A가 찍는 호출 수만큼의 줄이어야 저장되므로 쓰이지 않습니다.

7 힌트 · 문제가 답을 말하지 않음: ⚙ 기계 규칙: H나 Q의 글(펜스 밖)에 출력 줄의 값(6의 꼴, 두 글자 이상)이 낱말로 들어 있고 그 값이 문제 코드 안에 리터럴로 없으면 놓침입니다. 플러그인의 질문 글(NEW_LEAD · NEW_LEAD_LINES)과 힌트 틀은 모델 글과 똑같이 이 규칙으로 봅니다. ✎ 그 밖은 판정 하위 에이전트가 이유와 함께 매깁니다. 힌트가 보인 코드의 한 줄을 그대로 옮긴 것(`…` 줄에서 무슨 일이 일어나는지부터 보세요)은 그 줄에 리터럴로 든 값이 있어도 그것만으로 놓침이 아닙니다(학습자가 이미 보는 줄). 옮긴 줄이 보인 코드의 줄이 아니면 놓침입니다(더 엄격; 플러그인은 그런 힌트를 만들지 않음). 고정 힌트 NEW_HINT_PLAIN은 넘음입니다.

Q2 퀴즈 답의 상태 ⚙: 빈 답(empty-reply; API 거절 stop_reason refusal은 엔진이 빈 답으로 넘기므로 빈 답) · 시간 한도(90초)에 끊긴 답 · 상한 닿음(output_tokens ≥ 4600 + H_M)은 그 퀴즈의 모든 처음 보는 코드 자리를 놓침으로 하고 Q2를 못 넘음으로 합니다. 상한에 닿지 않았는데 글 가운데에서 끊겨 자리가 빠진 답(cut)은 빠진 자리가 1에서 놓침이고 Q2 자체는 위 셋에 들 때만 놓침입니다; cut과 빈 답은 모두 tap으로 한 번 다시 보내 stop_reason을 기록만 합니다(B-12). api-error(답 전 오류)만 한 번 다시 보내고, 다시도 api-error면 빈 답입니다. M-4 셋째 줄(남은 api-error가 한 스테이지 호출의 10% 초과면 그 스테이지 무효)은 그대로입니다.

Q3 부를 수 없는 개념 ⚙✎: 한 U 개념은 그 꼴에서 committed rungOf가 new가 아니면(범위 밖 · 라이브러리 · NEW_UNRUNNABLE 포함) 처음 보는 코드가 아닌 길입니다. new였고 U 퀴즈로 불렸는데 플러그인 읽기가 그 자리를 거절해 문항이 없으면, 학습자에게 처음 보는 코드로 아무것도 보이지 않았으므로 처음 보는 코드가 아닌 길입니다(1.10.0의 "parseQuiz 뒤 rung이 남지 않음"과 같은 셈). 문항이 저장되었으면 처음 보는 코드로 간 것이며 5를 넘어야 합니다. 흉내 코드(라이브러리 · 프레임워크 · 브라우저 · 네트워크의 이름이나 동작을 손으로 만든 함수 · 객체로 흉내 냄)는 판정 하위 에이전트가 이유와 함께 매기며 하나라도 있으면 Q3 못 넘음입니다.

판정 하위 에이전트: 꼬리표마다 한 명(G3 1.10.0 그대로)이 이 입장 글과 문항별 자료(저장된 question · hint · answer, 돌린 stdout, 개념 견본의 name · blurb · code)만 받습니다. 모델 이름, 다른 꼬리표, 토큰 · 시간은 받지 않습니다. 판정마다 조항 번호와 이유 한 줄을 씁니다. 판정이 빠지거나 읽히지 않으면 놓침입니다.

1.9.0 · 1.10.0 기록과 개발 답이 부딪힌 경계와 정한 셈:
- A를 산문 · 설명으로 씀(1.9.0 1차 22): 읽기가 거절 → 1 놓침.
- A를 " / "로 한 줄에 이음(N05Q1 · N05Q3), 쉼표로 이음: 찍는 호출 수와 줄 수가 다르거나 기호가 코드 문자열에 없어 거절 → 1 놓침.
- A 줄 수가 찍는 호출 수와 다름: 거절 → 1 놓침.
- 코드 없이 왜로 물음(1.9.0 1): 문항이 생기지 않음 → 1 놓침.
- 코드 9줄 · 10줄(1.9.0, sonnet 개발 long): 거절 → 1 놓침.
- 반복문 · 함수 · 조건 · 콜백 안의 찍기(haiku 개발 set1 r2 둘): 거절(print-place) → 1 놓침. 같은 줄에 몸이 있는 if · for 아래 맨 바깥 찍기는 거절하지 않음.
- 찍기 하나에 값 여럿(쉼표 · end= · sep= · *xs · ...xs): 거절 → 1 놓침.
- A가 틀림(`'pythonista'[7:]`, R18 44 대 45): 6 놓침.
- 내 코드와 거의 같은 코드(let 블록 범위, N02Q1 클로저 push, N09Q1 5/6줄): (가)(나)(다)는 읽기가 먼저 거절(1 놓침), 남은 것은 (라).
- 흔한 예를 이름 · 값만 바꿈(set1 T07): (다)에 안 걸리면 (라)에서 넘음.
- 비슷한 흔한 예(sort 기본 순서 · map · reduce): (가)~(라)에 안 걸리면 넘음.
- 개념의 동작이 일어나지 않는 코드(set1 N02-r2#1 가변 기본 인자 한 번 부름): 4 놓침.
- 타입 표기 개념(N11): 범위 밖; 견본 검사에서 빠져야 하며 들어오면 4 놓침.
- 실행 순서 개념(N03 setTimeout과 Promise): 범위 밖; 들어오면 그대로 매김(대개 읽기 거절 → 1 놓침).
- 문자열 글자 개념(역순 슬라이싱 · 회문 · 패딩, 개발 R17 · R18 · set1 R01): 범위 밖. 범위 안 개념에서 모델이 라틴 글자를 뒤섞은 출력('mpl', 'miws')을 쓰면 읽기 거절 → 1 놓침; 한글은 음절 단위로 읽으므로 '사코기' 같은 첫 글자 모음은 저장되어 6으로 매김.
- 되풀이 조각 출력('****', 'abab', '====장미===='): 저장되어 6으로 매김(옛 창의 마크다운 표시는 판정과 상관없음).
- 찍힌 줄에 쉼표(T06 '7,NaN,NaN'): 질문은 쉼표로 잇기를 권하지 않는 NEW_LEAD_LINES; 채점 견본의 맞는 답은 줄을 바꿔 씀(G-3).
- 없음 · None · - 을 찍음: 혼자인 기호 한 글자 줄('-')은 읽기 거절(1 놓침, 최종 탐침 P5); 없음 · None은 저장되고 채점은 isSameValue와 가드로 봄.
- 공백이 뜻을 지니는 출력(rjust · 폭 지정 · 공백 되풀이 · 안쪽 두 칸): 읽기 거절(spacing) → 1 놓침; 문자열 양 끝 공백(strip 개념)은 허용하고 4 · 6은 맞춘 꼴로 봄.
- 주석이 든 코드: 줄 주석은 플러그인이 지운 뒤로 매김; 블록 주석 · 세 따옴표 문자열은 거절(1 놓침).
- 모델이 K · L · A를 다시 씀(자기 고침): 나중 것이 저장됨; 저장된 것만 매김.
- A 아래 빈 줄 뒤의 메모: 출력이 아님; 저장되지 않음.
- 힌트가 값만 넣는 줄을 가리킴(haiku 개발 약 20/69): 이제 고정 힌트로 바뀜; 어느 쪽이든 7 넘음(기록: 고정 힌트 비율).
- 상한에 닿아 셋째 문제가 없음(1.9.0 N01 · N11): 그 자리 1 놓침, Q2 놓침.
- 빈 답 · 거절(1.10.0 sonnet N08): 그 퀴즈 모든 자리 놓침, Q2 놓침.
- 상한 아래에서 글 가운데 끊김(1.10.0 sonnet N04 · N05 · N12 · N15): 빠진 자리 1 놓침; tap stop_reason 기록.
- 따옴표를 붙인 A(`'abc'`)와 따옴표 없이 찍힌 출력: 읽기가 대개 거절(따옴표가 코드 문자열 안에 없음) → 1 놓침; 저장되면 6 놓침.
- True와 true, None과 null, 1과 1.0: 다른 값.
- 보이지 않는 정의(1.9.0 W10): 보인 그대로 돌림, 오류면 5 · 6 놓침.

판정의 입장 (G3, 1.12.0 G3-KLA). 기준 · 결정 규칙 · 짜임 · 견본 쓰기 프롬프트와 함께, 견본을 쓰거나 부르기 전에 docs/qa/견본.md 새 절로 한 커밋에 넣습니다(UTC 시각, 가리키는 코드 커밋 해시). 매기는 쪽은 이 글의 조항만 따르고 판정마다 조항 번호를 적습니다. ⚙ 조항은 eval 도구(부르기 전에 sha256으로 얼림)가 세고, ✎ 조항만 매기는 하위 에이전트(꼬리표마다 한 명)가 매깁니다. 1.10.0의 일곱 조항 번호와 뜻을 그대로 두고, 이 설계에서 쓰이지 않는 갈래는 "쓰이지 않음"으로 적었습니다. 이 글이 정하지 않은 경우는 못 넘음입니다(M-11).

G-1 채점의 셈 낱말 ⚙: 셈 낱말은 플러그인이 남기는 판정입니다. (1) localRight가 맞음이라 한 답은 모델을 부르지 않고 맞음으로 셉니다(모델 글 없음). (2) 그 밖은 parseCheck(fixEscapedTicks(text), { exact: answer, mine })의 verdict입니다: 값 줄로 valuesVerdict가 정한 맞음 · 틀림. 모델이 판정: 줄이나 거의를 써도 읽지 않습니다. 이것이 1.10.0(쓴 낱말)보다 느슨하지 않은 까닭: localRight는 맞음만 말하고, 실행으로 확인한(6) answer와 값마다 같을 때만 말하며, L0가 틀린 답의 지역 맞음을 하나라도 막습니다; 모델 길의 맞음은 옮긴 값이 줄마다 같고, 학습자가 쓴 글에 그 값이 저마다 제자리로 있고, 값 더가 없을 때만입니다; 값 줄이 빠진 답 · 빈 답 · 시간 한도 · 상한 닿음은 C2 · C3에서도 놓침입니다(쓴 낱말 셈에서는 그런 답이 틀림 기대 묶음에서 넘을 길이 없었던 것과 같음). 1.10.0이 쓴 낱말로 센 까닭(플러그인의 읽기가 모델 낱말과 달랐음)은 낱말이 없는 이 채점에 해당하지 않습니다. 셈 낱말과 다른 기록(피드백과의 어긋남, 옮긴 값 충실도, 가드가 뒤집은 수)은 기록만 합니다.

G-2 기대 판정: 기대 판정은 얼린 견본 꼬리표로 정합니다(right · again → 맞음, wrongOne · wrongAll → 틀림). 답을 본 뒤 다시 매기지 않습니다. 부르기 전에 무효로 적은 답만 뺍니다.

G-3 견본 답의 유효성 ⚙✎: 부르기 전에 도구가 보고, 그 꼬리표의 판정 하위 에이전트가 확인합니다. 학습자 값의 규칙(isSameValue와 같음): 앞뒤 공백 · 안쪽 공백 하나 · 따옴표 종류 · 끝 마침표 하나를 맞추고, 찍힌 줄에 감싼 따옴표가 없을 때만 학습자가 감싼 따옴표를 뗍니다(찍힌 줄이 'abc'면 abc는 다른 값). 조사 · 말투 · 덧붙인 까닭은 값이 아닙니다. right · again: 찍힌 줄마다 그 값이 차례대로 모두 있고, 다른 값을 줄 값으로 말하지 않아야 합니다; 찍힌 줄에 쉼표가 있는 문항은 줄을 바꿔 써야 하고 쉼표로 이은 답은 무효입니다; 줄인 값은 무효; again이 right와 같은 글이면 무효. wrongOne: 줄 수가 같고 꼭 한 줄의 값만 다름(따옴표만 다른 것도 찍힌 줄에 따옴표가 있으면 다름). wrongAll: 어느 자리에서도 찍힌 값과 같은 값이 없음(전체 순서 뒤바뀜 포함). 찍히는 글자가 다른 꼴(1과 1.0, True와 true)은 맞는 답으로 쓰지 않습니다.

G-4 경로: 첫 시도: right · wrongOne · wrongAll. 힌트 뒤(C2 (b) · C4 (b)): first = { mine: '모르겠어요', verdict: 'wrong', feedback: '', nudge: item.hint }; again · wrongOne. 되묻기 뒤(C4 (a)): 첫 시도 wrongOne의 남긴 판정이 맞음이 아니고 keptNudge가 되묻기를 남긴 문항만 again을 부릅니다(first = { mine: wrongOne, verdict: 남긴 판정, feedback, nudge }); 되묻기가 버려진 문항은 그 묶음에 들지 않고 수만 적습니다. 둘째 답의 셈은 남긴 verdict가 맞음일 때만 넘음입니다(secondVerdict도 그때만 right). localRight는 세 경로 모두에서 먼저 봅니다.

G-5 채점 답의 상태 ⚙: 값 줄이 하나라도 빠져 읽지 못함(undefined) · 빈 답 · 시간 한도(60초) · 상한 닿음(output_tokens ≥ 480 + H_M)은 그 견본에서 놓침입니다(어느 묶음이든). 다시 부르지 않습니다(api-error 규칙 제외).

G-6 L0 ⚙: 유효한 wrongOne · wrongAll이 어느 경로에서든 localRight로 맞음이 되면 하나라도 L0 못 넘음입니다. localRight의 닫힌 목록은 커밋에서 sha256으로 얼립니다.

G-7 견본 쓰기 답의 블록 ⚙: 채점 견본 쓰기 하위 에이전트의 답에 ```json 블록이 꼭 하나가 아니면 같은 프롬프트로 한 번 다시 부릅니다. 다시도 꼭 하나가 아니면 그 꼬리표의 C1~C4는 못 넘음입니다. 재는 세션이 블록을 고르지 않습니다(1.10.0 M-11의 교훈).

판정 하위 에이전트: 꼬리표마다 한 명(G3 1.10.0 그대로)이 이 입장 글과 문항별 자료(저장된 question · hint · answer, 돌린 stdout, 개념 견본의 name · blurb · code)만 받습니다. 모델 이름, 다른 꼬리표, 토큰 · 시간은 받지 않습니다. 판정마다 조항 번호와 이유 한 줄을 씁니다. 판정이 빠지거나 읽히지 않으면 놓침입니다.

1.9.0 · 1.10.0 기록과 개발 답이 부딪힌 경계와 정한 셈:
- 채점: 한 값만 틀린 답을 거의(1.9.0 9): 이 채점에는 판정 낱말이 없음; 값 줄로 틀림.
- 채점: 쉼표로 이은 맞는 답을 틀림(N15Q1 · N08Q3 · N13Q3): localRight 또는 값 줄로 셈.
- 채점: 대조가 모두 같음인데 틀림, 대조 안에서 뒤집음, 첫 시도 값을 둘째 답으로 읽음(1.10.0 C4): 이 채점에는 대조 · 판정이 없고 첫 시도 값이 프롬프트에 없음; 남긴 판정으로 셈.
- 채점: 모델이 옮긴 값이 학습자 글에 없음(모범 답을 베낌) 또는 한 번 쓴 값을 두 줄에 씀: 틀림(가드).
- 채점: 값을 백틱 · 따옴표로 감싸 옮김: isSameValue와 가드가 감싼 쌍을 뗀 꼴도 봄.
- 채점: 값 줄 대신 판정: 줄만 씀: 읽지 못함 → 놓침.
- 채점 피드백이 맞은 줄을 인정 · 판정과 어긋남: 셈과 상관없음(기록만).

너는 이 꼬리표의 판정자다. 학습 노트 앱이 만든 '처음 보는 코드' 문항이 위 '판정의 입장'을 갖추는지 매긴다. 너는 이 문항을 만든 모델이 무엇인지, 문항을 어떻게 불렀는지 모르며 알 필요도 없다. 도구는 없다. 코드를 돌리지 말고, 도구 호출도 쓰지 마라. 보인 그대로 돌린 출력은 보고서에 이미 있다.

할 일
- 보고서의 문항(### 머리 하나)마다 한 줄씩 매긴다. 키는 머리의 글 그대로다.
- 도구(⚙)가 센 조항(1, 2, 3의 (가)(나)(다), 5의 돌림, 6, 7의 기계 규칙)은 도구가 이미 셌다. 너는 ✎ 부분만 매긴다:
  - "c3ra": 조항 3의 (라). 보인 코드가 개념 견본 code와 같은 상황(이름 · 값 · 쓰임이 모두 개념 코드와 같은 일)이면 "miss", 아니면 "pass".
  - "c4": 조항 4. 출력의 적어도 한 줄이 개념 견본 blurb가 말한 동작으로 정해지면 "pass", 아니면 "miss".
  - "c5use": 조항 5의 금지 기능. grep에 걸린 낱말이 그 기능의 쓰임이면 "miss", 걸린 낱말이 없거나 쓰임이 아니면(문자열 · 주석 안의 낱말 등) "pass".
  - "c7": 조항 7의 ✎ 부분(기계 규칙 밖). 힌트나 문제 글이 답을 말하면 "miss", 아니면 "pass".
  - 보고서가 'Q3 U 항목'이라고 한 문항만: "mimic": 조항 Q3의 흉내 코드(라이브러리 · 프레임워크 · 브라우저 · 네트워크의 이름이나 동작을 손으로 만든 함수 · 객체로 흉내 냄)이면 "miss", 아니면 "pass". 다른 문항에는 "mimic"을 쓰지 않는다.
- 판정마다 그 옆 "<칸>_why"에 근거가 된 조항 번호와 이유 한 줄을 쓴다(예: "c4_why": "4: …"). 이유가 없는 판정은 판정이 빠진 것으로 센다.
- 이 입장이 가르지 못하는 경우는 "undecided"라고 적고 까닭을 쓴다(그 문항은 놓침으로 셈).
- 입장에 없는 조항을 더하거나 조항을 다르게 읽지 않는다.

답의 꼴: JSON 배열 하나만 쓴다. 다른 글, 코드 펜스를 쓰지 않는다. 문항마다
{"key": "…", "c3ra": "pass" | "miss" | "undecided", "c3ra_why": "조항 · 이유 한 줄", "c4": …, "c4_why": …, "c5use": …, "c5use_why": …, "c7": …, "c7_why": …}
(Q3 U 항목에는 "mimic"과 "mimic_why"를 더함)

# 보고서

# 판정 자료 (꼬리표 B, 묶음 P)

저장된 처음 보는 코드 문항 33개.

### P-N01#2
- 개념 이름: 함수 선언 호이스팅
- 개념 견본 blurb: function 키워드로 선언한 함수는 실행 전에 통째로 끌어올려지므로 선언보다 위에서 불러도 동작합니다. 반면 const에 담은 함수 표현식은 선언 전에 부르면 오류가 나니 둘을 구분해야 합니다. — `const note = waterNote("선인장");`
- 개념 견본 code (학습자 코드):
```
const note = waterNote("선인장");
console.log(note);
function waterNote(plant) {
  return plant + "은 일주일에 한 번";
}
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
console.log(fee(parcel.weight));
function fee(weight) {
  return weight * 500 + 1000;
}
const parcel = { weight: 4 };
console.log(fee(10));
```
````
- 저장된 hint: `return weight * 500 + 1000;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
3000
6000
```
- 보인 그대로 돌린 출력(stdout 줄):
```
(끝 코드 1; 찍힌 줄: [])
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N01#3
- 개념 이름: for 문 2씩 증가
- 개념 견본 blurb: for 문의 세 번째 칸에 += 2를 쓰면 반복할 때마다 변수가 1이 아니라 2씩 커집니다. 그래서 2, 4, 6처럼 건너뛴 값만 차례로 돌 수 있습니다. — `for (let stair = 2; stair <= 6; stair += 2) {`
- 개념 견본 code (학습자 코드):
```
for (let stair = 2; stair <= 6; stair += 2) {
  console.log("계단 " + stair);
}
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const songs = [];
for (let track = 1; track <= 7; track += 2) {
  songs.push(track * 10);
}
console.log(songs.length);
console.log(songs[2]);
```
````
- 저장된 hint: 맨 위 줄부터 이름마다 어떤 값이 들어가는지 적어 가며 보세요.
- 저장된 answer:
```
4
50
```
- 보인 그대로 돌린 출력(stdout 줄):
```
4
50
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N02#3
- 개념 이름: 딕셔너리에 담은 함수
- 개념 견본 blurb: 파이썬에서 함수도 값이라서 괄호 없이 이름만 쓰면 딕셔너리의 값으로 담을 수 있습니다. 꺼낸 뒤 괄호를 붙이면 그 함수가 실행됩니다. — `ops = {"+": plus, "-": minus}`
- 개념 견본 code (학습자 코드):
```
def plus(a, b):
    return a + b
def minus(a, b):
    return a - b
ops = {"+": plus, "-": minus}
print(ops["+"](7, 3))
print(ops["-"](7, 3))
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
def go_left():
    return "좌회전"

def go_right():
    return "우회전"

moves = {"car": go_left, "spot": go_right}
action = moves["spot"]
print(action())
print(moves["car"]())
```
````
- 저장된 hint: `action = moves["spot"]` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
우회전
좌회전
```
- 보인 그대로 돌린 출력(stdout 줄):
```
우회전
좌회전
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N03#1
- 개념 이름: 쉼표 연산자 return
- 개념 견본 blurb: return 뒤에 값을 쉼표로 나열하면 여러 값이 돌아오는 것이 아니라 쉼표 연산자 때문에 마지막 값 하나만 돌아옵니다. 여러 값을 돌려주려면 배열이나 객체로 묶어야 합니다. — `return score, rank;`
- 개념 견본 code (학습자 코드):
```
function scoreAndRank(score) {
  const rank = score >= 80 ? "A" : "B";
  return score, rank;
}
const answerPair = scoreAndRank(90);
console.log(answerPair);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
function bakery(bread, tray, oven) {
  return bread + 1, tray * 2, oven - 3;
}
const r = bakery(5, 4, 10);
console.log(r);
console.log(bakery(1, 2, 3));
```
````
- 저장된 hint: `return bread + 1, tray * 2, oven - 3;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
7
0
```
- 보인 그대로 돌린 출력(stdout 줄):
```
7
0
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N03#2
- 개념 이름: 배열 요소 덮어쓰기
- 개념 견본 blurb: 배열 이름 뒤 대괄호에 번호를 넣고 = 로 값을 주면 그 자리의 원래 값이 새 값으로 바뀝니다. 다른 자리의 값은 그대로 남습니다. — `menus[1] = "떡볶이";`
- 개념 견본 code (학습자 코드):
```
const menus = ["김밥", "라면", "우동"];
menus[1] = "떡볶이";
console.log(menus[0]);
console.log(menus[1]);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const box = [4, 7, 2];
box[1] = box[0] + 1;
console.log(box[0]);
console.log(box[1]);
console.log(box[2]);
```
````
- 저장된 hint: `box[1] = box[0] + 1;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
4
5
2
```
- 보인 그대로 돌린 출력(stdout 줄):
```
4
5
2
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N04#2
- 개념 이름: for 반복 변수 재대입
- 개념 견본 blurb: for 반복 변수는 리스트 항목의 값을 받아 둔 이름일 뿐이라서 그 이름에 새 값을 대입해도 리스트 안의 값은 그대로입니다. 리스트를 바꾸려면 인덱스로 대입하거나 새 리스트를 만들어야 합니다. — `for b in breads: b = b * 2`
- 개념 견본 code (학습자 코드):
```
breads = [1000, 2000, 3000]
for b in breads: b = b * 2
print(breads)
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
spots = [5, 7, 9]
for spot in spots:
    spot = spot + 100
print(spots[0])
print(spot)
```
````
- 저장된 hint: `spot = spot + 100` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
5
109
```
- 보인 그대로 돌린 출력(stdout 줄):
```
5
109
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N04#3
- 개념 이름: 중첩 if 문
- 개념 견본 blurb: if 블록 안에 또 if를 넣으면 바깥 조건이 참일 때만 안쪽 조건을 검사합니다. 들여쓰기 깊이로 어느 if에 속한 코드인지 구분합니다. — `if has_ticket:`
- 개념 견본 code (학습자 코드):
```
age = 15
has_ticket = True
if has_ticket:
    if age >= 12:
        print("입장 가능")
    else:
        print("보호자 필요")
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
tent = True
pack = False
result = "대기"
if tent:
    if pack:
        result = "출발"
print(result)
```
````
- 저장된 hint: `if pack:` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
대기
```
- 보인 그대로 돌린 출력(stdout 줄):
```
대기
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N05#1
- 개념 이름: 건너뛴 인덱스 대입 빈 칸
- 개념 견본 blurb: 배열 길이보다 큰 인덱스에 값을 넣으면 그 사이가 빈 칸으로 채워지고 length도 그만큼 늘어납니다. 빈 칸을 읽으면 undefined가 나옵니다. — `slots[4] = "잡지";`
- 개념 견본 code (학습자 코드):
```
const slots = ["소설", "만화"];
slots[4] = "잡지";
console.log(slots.length);
console.log(slots[2]);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const bike = ["A", "B"];
bike[4] = "C";
console.log(bike.length);
console.log(bike[2]);
console.log(bike[4]);
```
````
- 저장된 hint: `bike[4] = "C";` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
5
undefined
C
```
- 보인 그대로 돌린 출력(stdout 줄):
```
5
undefined
C
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N05#3
- 개념 이름: 개수 세는 카운터 변수
- 개념 견본 blurb: 0으로 시작한 변수를 조건에 맞을 때마다 1씩 올리면 조건에 맞는 항목이 몇 개인지 셀 수 있습니다. 반복이 끝난 뒤 그 변수에 개수가 남습니다. — `bigFish = bigFish + 1;`
- 개념 견본 code (학습자 코드):
```
const fishSizes = [12, 30, 8, 25, 40];
let bigFish = 0;
for (const fish of fishSizes) {
  if (fish >= 20) {
    bigFish = bigFish + 1;
  }
}
console.log("큰 물고기 " + bigFish + "마리");
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const bus = ["서", "동", "남", "북", "동"];
let stop = 0;
for (let i = 0; i < bus.length; i++) {
  if (bus[i] === "동") stop++;
}
console.log(stop);
console.log(bus.length);
```
````
- 저장된 hint: `if (bus[i] === "동") stop++;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
2
5
```
- 보인 그대로 돌린 출력(stdout 줄):
```
2
5
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N06#1
- 개념 이름: map 결과 한 번만 소비
- 개념 견본 blurb: map()이 돌려주는 것은 리스트가 아니라 한 번 꺼내면 비어 버리는 반복자입니다. 두 번째로 list()를 하면 이미 다 꺼낸 뒤라 빈 리스트가 나옵니다. — `doubled = map(lambda n: n * 2, seeds)`
- 개념 견본 code (학습자 코드):
```
seeds = [3, 5, 7]
doubled = map(lambda n: n * 2, seeds)
print(list(doubled))
print(list(doubled))
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
parcel = [2, 5, 3]
box = map(lambda w: w * 10, parcel)
first = list(box)
second = list(box)
print(len(first))
print(len(second))
```
````
- 저장된 hint: `second = list(box)` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
3
0
```
- 보인 그대로 돌린 출력(stdout 줄):
```
3
0
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N06#2
- 개념 이름: 한 줄 연쇄 대입
- 개념 견본 blurb: a = b = 0처럼 쓰면 여러 변수에 같은 값을 한 번에 넣습니다. 숫자는 바꿀 수 없는 값이라 한 변수를 += 로 바꿔도 다른 변수는 그대로입니다. — `wins = losses = 0`
- 개념 견본 code (학습자 코드):
```
wins = losses = 0
wins += 3
print(wins)
print(losses)
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
fruit = basket = stock = 7
basket -= 2
stock = stock * 2
print(fruit)
print(basket)
print(stock)
```
````
- 저장된 hint: `fruit = basket = stock = 7` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
7
5
14
```
- 보인 그대로 돌린 출력(stdout 줄):
```
7
5
14
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N07#2
- 개념 이름: 큰 정수 정밀도 손실
- 개념 견본 blurb: 자바스크립트 숫자는 9007199254740991보다 큰 정수를 정확히 담지 못해 가까운 다른 값으로 바뀝니다. 아주 긴 번호는 숫자 대신 문자열로 다루는 것이 안전합니다. — `const bigId = 9007199254740993;`
- 개념 견본 code (학습자 코드):
```
const bigId = 9007199254740993;
console.log(bigId);
console.log(bigId === 9007199254740992);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const bus = 9007199254740992;
const stop = bus + 1;
const route = "9007199254740992" + "1";
console.log(stop === bus);
console.log(stop);
console.log(route);
```
````
- 저장된 hint: `const stop = bus + 1;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
true
9007199254740992
90071992547409921
```
- 보인 그대로 돌린 출력(stdout 줄):
```
true
9007199254740992
90071992547409921
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N07#3
- 개념 이름: while else 문
- 개념 견본 blurb: while 뒤의 else 블록은 break 없이 조건이 거짓이 되어 반복이 끝났을 때 한 번 실행됩니다. — `while cookies > 0:`
- 개념 견본 code (학습자 코드):
```
cookies = 3
while cookies > 0:
    cookies -= 1
else:
    print("jar empty")
print(cookies)
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
stamps = 5
while stamps > 2:
    stamps -= 1
else:
    stamps += 100
print(stamps)
```
````
- 저장된 hint: `while stamps > 2:` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
102
```
- 보인 그대로 돌린 출력(stdout 줄):
```
102
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N08#1
- 개념 이름: 기본 인자 정의 시점 평가
- 개념 견본 blurb: 기본 인자의 값은 함수를 호출할 때가 아니라 def 줄이 실행될 때 한 번 정해집니다. 그래서 나중에 rate를 20으로 바꿔도 기본값은 처음의 10으로 남아 있습니다. — `def tip_amount(cost, r=rate):`
- 개념 견본 code (학습자 코드):
```
rate = 10
def tip_amount(cost, r=rate):
    return cost * r // 100
rate = 20
print(tip_amount(5000))
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
rate = 10
def mail(letter, stamp=rate):
    return f"{letter}:{stamp}"
rate = 20
print(mail("A"))
print(mail("B"))
```
````
- 저장된 hint: `def mail(letter, stamp=rate):` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
A:10
B:10
```
- 보인 그대로 돌린 출력(stdout 줄):
```
A:10
B:10
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N08#3
- 개념 이름: 튜플 크기 비교 순서
- 개념 견본 blurb: 튜플끼리 비교하면 앞 칸부터 차례로 비교하고, 처음으로 다른 칸에서 결과가 정해집니다. 그래서 (1, 9)는 첫 칸 1이 2보다 작아 (2, 0)보다 작습니다. — `need_update = mine < latest`
- 개념 견본 code (학습자 코드):
```
mine = (2, 5)
latest = (2, 9)
need_update = mine < latest
print(need_update)
print((1, 9) > (2, 0))
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
bus = (2, 7)
stop = (2, 3)
route = (1, 9)
print(bus > stop)
print(route > stop)
```
````
- 저장된 hint: 맨 위 줄부터 이름마다 어떤 값이 들어가는지 적어 가며 보세요.
- 저장된 answer:
```
True
False
```
- 보인 그대로 돌린 출력(stdout 줄):
```
True
False
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N09#1
- 개념 이름: 빠진 인자 undefined
- 개념 견본 blurb: 함수를 부를 때 인자를 덜 넘기면 오류 없이 빠진 매개변수가 undefined가 됩니다. undefined로 계산하면 결과가 NaN이 되어 버그를 알아채기 어렵습니다. — `const half = roomArea(4);`
- 개념 견본 code (학습자 코드):
```
function roomArea(width, height) {
  return width * height;
}
const full = roomArea(4, 3);
const half = roomArea(4);
console.log(full, half);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
function paint(color, brush) {
  return color + " 붓 " + brush * 2;
}
console.log(paint("빨강", 3));
console.log(paint("파랑"));
```
````
- 저장된 hint: `return color + " 붓 " + brush * 2;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
빨강 붓 6
파랑 붓 NaN
```
- 보인 그대로 돌린 출력(stdout 줄):
```
빨강 붓 6
파랑 붓 NaN
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N09#2
- 개념 이름: 객체 메서드 단축 문법
- 개념 견본 blurb: 객체 안에서 이름 뒤에 바로 괄호와 중괄호를 쓰면 function 없이도 메서드를 만들 수 있습니다. 호출할 때는 객체.이름() 처럼 괄호를 붙입니다. — `hello() {`
- 개념 견본 code (학습자 코드):
```
const robot = {
  hello() {
    return "삐삐 출동!";
  },
};
console.log(robot.hello());
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const fridge = { egg: 10, milk: 2, total() { return this.egg + this.milk; } };
console.log(fridge.total());
fridge.egg = 4;
console.log(fridge.total());
```
````
- 저장된 hint: 맨 위 줄부터 이름마다 어떤 값이 들어가는지 적어 가며 보세요.
- 저장된 answer:
```
12
6
```
- 보인 그대로 돌린 출력(stdout 줄):
```
12
6
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N10#2
- 개념 이름: 리스트 += 제자리 변경
- 개념 견본 blurb: 리스트의 +=는 원래 리스트를 그 자리에서 늘리므로 같은 리스트를 가리키는 다른 변수에도 바뀐 내용이 보입니다. 반면 a = a + [...]는 새 리스트를 만들어 이름만 옮기기 때문에 원래 리스트는 바뀌지 않습니다. — `team_b += ["서연"]`
- 개념 견본 code (학습자 코드):
```
team_a = ["민지", "도윤"]
team_b = team_a
team_b += ["서연"]
print(team_a)
team_b = team_b + ["하준"]
print(team_a)
print(team_b)
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
basket = ["사과"]
fruit = basket
stock = basket
basket += ["배"]
stock = stock + ["귤"]
print(len(fruit))
print(len(stock))
print(len(basket))
```
````
- 저장된 hint: `basket += ["배"]` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
2
3
2
```
- 보인 그대로 돌린 출력(stdout 줄):
```
2
3
2
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N10#3
- 개념 이름: range len 인덱스 반복
- 개념 견본 blurb: range(len(리스트))로 반복하면 0부터 마지막 위치까지의 번호를 얻고, 그 번호로 리스트 칸을 꺼낼 수 있습니다. — `for i in range(len(seats)):`
- 개념 견본 code (학습자 코드):
```
seats = ["A", "B", "C"]
for i in range(len(seats)):
    print(i, seats[i])
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
tent = ["텐트", "의자", "랜턴"]
pack = [1, 0, 2]
total = 0
for i in range(len(tent)):
    total += pack[i]
print(total)
print(tent[1])
```
````
- 저장된 hint: `for i in range(len(tent)):` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
3
의자
```
- 보인 그대로 돌린 출력(stdout 줄):
```
3
의자
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N11#1
- 개념 이름: 중첩 객체 속성 접근
- 개념 견본 blurb: 객체의 속성 값이 또 객체이면 점을 이어 붙여 안쪽 속성까지 차례로 들어갈 수 있습니다. 앞에서부터 하나씩 꺼낸 값에서 다시 속성을 읽는 것입니다. — `club: { clubName: "로봇부", room: 3 },`
- 개념 견본 code (학습자 코드):
```
const student = {
  nick: "지우",
  club: { clubName: "로봇부", room: 3 },
};
console.log(student.club.clubName);
console.log(student.club.room + "반 교실");
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const paint = { brush: { size: 3, color: "빨강" }, canvas: 5 };
const brush = paint.brush;
const color = brush.color;
console.log(color + "색 붓");
console.log(paint.brush.size * 2);
console.log(paint.canvas + brush.size);
```
````
- 저장된 hint: `const color = brush.color;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
빨강색 붓
6
8
```
- 보인 그대로 돌린 출력(stdout 줄):
```
빨강색 붓
6
8
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N11#3
- 개념 이름: 들여쓰기 블록 범위
- 개념 견본 blurb: 파이썬은 들여쓰기로 블록을 나누므로, 반복문 아래 들여쓴 줄만 반복되고 들여쓰기를 뺀 줄은 반복이 끝난 뒤 한 번만 실행됩니다. — `for d in days:`
- 개념 견본 code (학습자 코드):
```
days = [2, 6]
for d in days:
    if d > 4:
        print("rest", d)
print("done")
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
basket = ["사과", "배", "포도"]
stock = 0
for fruit in basket:
    stock = stock + 2
stock = stock + 10
print(stock)
print(len(basket))
```
````
- 저장된 hint: `stock = stock + 10` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
16
3
```
- 보인 그대로 돌린 출력(stdout 줄):
```
16
3
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N12#1
- 개념 이름: 배열 entries 반복
- 개념 견본 blurb: 배열의 entries 메서드는 [번호, 값] 짝을 하나씩 돌려주므로 for...of와 함께 쓰면 인덱스와 값을 동시에 꺼낼 수 있습니다. 번호는 0부터 시작하므로 사람에게 보여 줄 때는 1을 더합니다. — `for (const [i, step] of steps.entries()) {`
- 개념 견본 code (학습자 코드):
```
const steps = ["물 붓기", "면 넣기", "불 끄기"];
for (const [i, step] of steps.entries()) {
  console.log(i + 1 + ". " + step);
}
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const seats = ["가", "나", "다"];
let text = "";
for (const [row, seat] of seats.entries()) {
  text = text + (row + 1) + seat;
}
console.log(text);
```
````
- 저장된 hint: 맨 위 줄부터 이름마다 어떤 값이 들어가는지 적어 가며 보세요.
- 저장된 answer:
```
1가2나3다
```
- 보인 그대로 돌린 출력(stdout 줄):
```
1가2나3다
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N12#2
- 개념 이름: 튜플 딕셔너리 키
- 개념 견본 blurb: 튜플은 바뀌지 않는 값이라 딕셔너리의 키로 쓸 수 있어서, 좌표처럼 두 값을 묶어 하나의 키로 찾을 수 있습니다. — `marks[(0, 0)] = "home"`
- 개념 견본 code (학습자 코드):
```
marks = {(0, 1): "tree", (2, 3): "rock"}
spot = (2, 3)
print(marks[spot])
marks[(0, 0)] = "home"
print(len(marks))
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
gear = {}
gear[("tent", 1)] = "텐트"
gear[("pack", 2)] = "배낭"
gear[("tent", 1)] = "침낭"
print(gear[("pack", 2)])
print(len(gear))
print(("fire", 3) in gear)
```
````
- 저장된 hint: `gear[("tent", 1)] = "침낭"` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
배낭
2
False
```
- 보인 그대로 돌린 출력(stdout 줄):
```
배낭
2
False
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N13#2
- 개념 이름: Object.fromEntries 객체 만들기
- 개념 견본 blurb: Object.fromEntries는 [키, 값] 짝이 담긴 배열을 받아 그 짝들로 이루어진 새 객체를 만들어 줍니다. 만든 뒤에는 점 표기로 각 키의 값을 바로 읽을 수 있습니다. — `const stock = Object.fromEntries(pairs);`
- 개념 견본 code (학습자 코드):
```
const pairs = [["apple", 3], ["pear", 5]];
const stock = Object.fromEntries(pairs);
console.log(stock.apple);
console.log(stock.pear);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const pairs = [["paint", 3], ["brush", 5], ["color", 2]];
const kit = Object.fromEntries(pairs);
const total = kit.paint + kit.brush;
console.log(typeof kit);
console.log(kit.color);
console.log(total);
```
````
- 저장된 hint: `const kit = Object.fromEntries(pairs);` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
object
2
8
```
- 보인 그대로 돌린 출력(stdout 줄):
```
object
2
8
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N14#1
- 개념 이름: 즉시 실행 함수
- 개념 견본 blurb: 함수 표현식을 괄호로 감싸고 바로 뒤에 ()를 붙이면 정의하자마자 한 번 실행되고, 변수에는 함수가 아니라 그 반환값이 담깁니다. 안에서 만든 변수는 바깥에 새지 않습니다. — `})();`
- 개념 견본 code (학습자 코드):
```
const startScore = (function () {
  let n = 0;
  n += 2;
  return n * 10;
})();
console.log(startScore);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const bread = (function () {
  const tray = 3;
  const oven = tray * 2;
  return oven + 1;
})();
console.log(bread);
console.log(typeof tray);
```
````
- 저장된 hint: 맨 위 줄부터 이름마다 어떤 값이 들어가는지 적어 가며 보세요.
- 저장된 answer:
```
7
undefined
```
- 보인 그대로 돌린 출력(stdout 줄):
```
7
undefined
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N14#3
- 개념 이름: 딕셔너리 == 비교
- 개념 견본 blurb: 딕셔너리를 == 로 비교하면 넣은 순서와 상관없이 키와 값이 모두 같을 때만 True가 됩니다. — `same = left == right`
- 개념 견본 code (학습자 코드):
```
left = {"shirt": 2, "sock": 5}
right = {"sock": 5, "shirt": 2}
same = left == right
print(same)
right["sock"] = 4
print(left == right)
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
seat = {"row": "B", "ticket": 12}
ticket = {"ticket": 12, "row": "B"}
print(seat == ticket)
seat["row"] = "C"
print(seat == ticket)
```
````
- 저장된 hint: `seat["row"] = "C"` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
True
False
```
- 보인 그대로 돌린 출력(stdout 줄):
```
True
False
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N15#1
- 개념 이름: map 콜백 인덱스 인자
- 개념 견본 blurb: map에 넘긴 콜백은 첫 번째 인자로 값을, 두 번째 인자로 그 값의 인덱스를 받습니다. 인덱스는 0부터 시작하므로 등수처럼 쓰려면 1을 더합니다. — `const labels = runners.map((runner, i) => (i + 1) + "등 " + runner);`
- 개념 견본 code (학습자 코드):
```
const runners = ["민지", "도윤", "서아"];
const labels = runners.map((runner, i) => (i + 1) + "등 " + runner);
console.log(labels[0]);
console.log(labels[2]);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const pace = [330, 320, 340];
const score = pace.map((p, i) => p - i * 5);
console.log(score[1]);
console.log(score[2]);
```
````
- 저장된 hint: 맨 위 줄부터 이름마다 어떤 값이 들어가는지 적어 가며 보세요.
- 저장된 answer:
```
315
330
```
- 보인 그대로 돌린 출력(stdout 줄):
```
315
330
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N15#2
- 개념 이름: set 접근자
- 개념 견본 blurb: 객체에 set으로 정의한 속성은 값을 대입할 때 함수처럼 실행되어, 받은 값을 바꿔 다른 속성에 저장할 수 있습니다. 대입문은 평범해 보여도 안에서는 계산이 일어납니다. — `pet.months = 36;`
- 개념 견본 code (학습자 코드):
```
const pet = {
  age: 0,
  set months(m) {
    this.age = m / 12;
  },
};
pet.months = 36;
console.log(pet.age);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const plot = {
  water: 0,
  set crop(n) { this.water = n * 3 + 1; }
};
plot.crop = 4;
console.log(plot.water);
console.log(plot.crop);
```
````
- 저장된 hint: `set crop(n) { this.water = n * 3 + 1; }` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
13
undefined
```
- 보인 그대로 돌린 출력(stdout 줄):
```
13
undefined
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-M1#2
- 개념 이름: 반복 경계 하나 초과
- 개념 견본 blurb: 배열 인덱스는 0부터 length 빼기 1까지이므로 조건에 <=를 쓰면 한 번 더 돌아 없는 칸을 읽습니다. 배열을 돌 때는 i < 배열.length로 써야 합니다. — `for (let i = 0; i <= snacks.length; i++) {`
- 개념 견본 code (학습자 코드):
```
const snacks = ["과자", "젤리"];
for (let i = 0; i <= snacks.length; i++) {
  console.log(snacks[i]);
}
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const fire = ["성냥", "가스", "토치"];
let total = 0;
for (let i = 0; i < fire.length; i++) {
  total = total + fire[i].length;
}
console.log(total);
console.log(fire.length);
```
````
- 저장된 hint: `for (let i = 0; i < fire.length; i++) {` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
6
3
```
- 보인 그대로 돌린 출력(stdout 줄):
```
6
3
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-M1#3
- 개념 이름: 배열 요소 덮어쓰기
- 개념 견본 blurb: 배열 이름 뒤 대괄호에 번호를 넣고 = 로 값을 주면 그 자리의 원래 값이 새 값으로 바뀝니다. 다른 자리의 값은 그대로 남습니다. — `menus[1] = "떡볶이";`
- 개념 견본 code (학습자 코드):
```
const menus = ["김밥", "라면", "우동"];
menus[1] = "떡볶이";
console.log(menus[0]);
console.log(menus[1]);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const weight = [2, 4, 6];
weight[0] = weight[0] + 10;
weight[2] = 1;
console.log(weight[0]);
console.log(weight[1]);
console.log(weight[2]);
```
````
- 저장된 hint: `weight[2] = 1;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
12
4
1
```
- 보인 그대로 돌린 출력(stdout 줄):
```
12
4
1
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-M2#2
- 개념 이름: 딕셔너리에 담은 함수
- 개념 견본 blurb: 파이썬에서 함수도 값이라서 괄호 없이 이름만 쓰면 딕셔너리의 값으로 담을 수 있습니다. 꺼낸 뒤 괄호를 붙이면 그 함수가 실행됩니다. — `ops = {"+": plus, "-": minus}`
- 개념 견본 code (학습자 코드):
```
def plus(a, b):
    return a + b
def minus(a, b):
    return a - b
ops = {"+": plus, "-": minus}
print(ops["+"](7, 3))
print(ops["-"](7, 3))
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
def park(car):
    return car + "-P"
gate = {"in": park, "out": lambda car: car + "-L"}
car = "K"
print(gate["in"](car))
print(gate["out"](car) + "!")
```
````
- 저장된 hint: 맨 위 줄부터 이름마다 어떤 값이 들어가는지 적어 가며 보세요.
- 저장된 answer:
```
K-P
K-L!
```
- 보인 그대로 돌린 출력(stdout 줄):
```
K-P
K-L!
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-M3#1
- 개념 이름: 반복 변수 루프 밖 값
- 개념 견본 blurb: 파이썬의 for 반복 변수는 반복이 끝난 뒤에도 사라지지 않고 마지막으로 받은 값을 그대로 가지고 있습니다. 반복 밖에서 같은 이름을 쓰면 마지막 항목이 나오니 주의해야 합니다. — `for room in ["거실", "부엌", "욕실"]:`
- 개념 견본 code (학습자 코드):
```
visited = 0
for room in ["거실", "부엌", "욕실"]:
    visited += 1
print(visited)
print(room)
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
water = 0
for seed in [3, 5, 7]:
    water = water + seed
print(seed)
print(water)
```
````
- 저장된 hint: `for seed in [3, 5, 7]:` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
7
15
```
- 보인 그대로 돌린 출력(stdout 줄):
```
7
15
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-M3#2
- 개념 이름: for 문 2씩 증가
- 개념 견본 blurb: for 문의 세 번째 칸에 += 2를 쓰면 반복할 때마다 변수가 1이 아니라 2씩 커집니다. 그래서 2, 4, 6처럼 건너뛴 값만 차례로 돌 수 있습니다. — `for (let stair = 2; stair <= 6; stair += 2) {`
- 개념 견본 code (학습자 코드):
```
for (let stair = 2; stair <= 6; stair += 2) {
  console.log("계단 " + stair);
}
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
let song = 1;
let count = 0;
for (; song < 8; song += 2) count++;
console.log(song);
console.log(count);
```
````
- 저장된 hint: `for (; song < 8; song += 2) count++;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
9
4
```
- 보인 그대로 돌린 출력(stdout 줄):
```
9
4
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지
