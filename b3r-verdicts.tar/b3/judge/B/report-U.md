# 판정 자료 (꼬리표 B, 묶음 U)

저장된 처음 보는 코드 문항 1개.

### U-1#1
- 개념 이름: writeFileSync 파일 쓰기
- 개념 견본 blurb: node:fs의 writeFileSync는 문자열을 파일에 저장하며, 같은 이름의 파일이 있으면 내용을 통째로 덮어씁니다. Node로 실행해야 하고 실제 폴더에 파일이 생깁니다. — `writeFileSync(diaryPath, content, "utf8");`
- 개념 견본 code (학습자 코드):
```
import { writeFileSync } from "node:fs";

const today = new Date().toISOString().slice(0, 10);
const entries = [
  "아침에 산책했다",
  "점심은 김밥",
  "저녁에 코딩 공부",
];

const diaryPath = "diary-" + today + ".txt";
const content = entries.join("\n");

writeFileSync(diaryPath, content, "utf8");
console.log(diaryPath + " 저장 완료");
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
let box = "책 2권";
box = "옷 1벌";
let weight = box.length;
console.log(box);
console.log(weight);
```
````
- 저장된 hint: 맨 위 줄부터 이름마다 어떤 값이 들어가는지 적어 가며 보세요.
- 저장된 answer:
```
옷 1벌
4
```
- 보인 그대로 돌린 출력(stdout 줄):
```
옷 1벌
4
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: Q3 U 항목(흉내 코드 여부와 5의 쓰임)
