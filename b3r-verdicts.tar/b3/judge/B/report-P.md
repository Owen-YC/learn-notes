# 판정 자료 (꼬리표 B, 묶음 P)

저장된 처음 보는 코드 문항 33개.

### P-N01#2
- 개념 이름: 함수 선언 호이스팅
- 개념 견본 blurb: function 키워드로 선언한 함수는 실행 전에 통째로 끌어올려지므로 선언보다 위에서 불러도 동작합니다. 반면 const에 담은 함수 표현식은 선언 전에 부르면 오류가 나니 둘을 구분해야 합니다. — `const note = waterNote("선인장");`
- 개념 견본 code (학습자 코드):
```
const note = waterNote("선인장");
console.log(note);
function waterNote(plant) {
  return plant + "은 일주일에 한 번";
}
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
console.log(fee(parcel.weight));
function fee(weight) {
  return weight * 500 + 1000;
}
const parcel = { weight: 4 };
console.log(fee(10));
```
````
- 저장된 hint: `return weight * 500 + 1000;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
3000
6000
```
- 보인 그대로 돌린 출력(stdout 줄):
```
(끝 코드 1; 찍힌 줄: [])
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N01#3
- 개념 이름: for 문 2씩 증가
- 개념 견본 blurb: for 문의 세 번째 칸에 += 2를 쓰면 반복할 때마다 변수가 1이 아니라 2씩 커집니다. 그래서 2, 4, 6처럼 건너뛴 값만 차례로 돌 수 있습니다. — `for (let stair = 2; stair <= 6; stair += 2) {`
- 개념 견본 code (학습자 코드):
```
for (let stair = 2; stair <= 6; stair += 2) {
  console.log("계단 " + stair);
}
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const songs = [];
for (let track = 1; track <= 7; track += 2) {
  songs.push(track * 10);
}
console.log(songs.length);
console.log(songs[2]);
```
````
- 저장된 hint: 맨 위 줄부터 이름마다 어떤 값이 들어가는지 적어 가며 보세요.
- 저장된 answer:
```
4
50
```
- 보인 그대로 돌린 출력(stdout 줄):
```
4
50
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N02#3
- 개념 이름: 딕셔너리에 담은 함수
- 개념 견본 blurb: 파이썬에서 함수도 값이라서 괄호 없이 이름만 쓰면 딕셔너리의 값으로 담을 수 있습니다. 꺼낸 뒤 괄호를 붙이면 그 함수가 실행됩니다. — `ops = {"+": plus, "-": minus}`
- 개념 견본 code (학습자 코드):
```
def plus(a, b):
    return a + b
def minus(a, b):
    return a - b
ops = {"+": plus, "-": minus}
print(ops["+"](7, 3))
print(ops["-"](7, 3))
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
def go_left():
    return "좌회전"

def go_right():
    return "우회전"

moves = {"car": go_left, "spot": go_right}
action = moves["spot"]
print(action())
print(moves["car"]())
```
````
- 저장된 hint: `action = moves["spot"]` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
우회전
좌회전
```
- 보인 그대로 돌린 출력(stdout 줄):
```
우회전
좌회전
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N03#1
- 개념 이름: 쉼표 연산자 return
- 개념 견본 blurb: return 뒤에 값을 쉼표로 나열하면 여러 값이 돌아오는 것이 아니라 쉼표 연산자 때문에 마지막 값 하나만 돌아옵니다. 여러 값을 돌려주려면 배열이나 객체로 묶어야 합니다. — `return score, rank;`
- 개념 견본 code (학습자 코드):
```
function scoreAndRank(score) {
  const rank = score >= 80 ? "A" : "B";
  return score, rank;
}
const answerPair = scoreAndRank(90);
console.log(answerPair);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
function bakery(bread, tray, oven) {
  return bread + 1, tray * 2, oven - 3;
}
const r = bakery(5, 4, 10);
console.log(r);
console.log(bakery(1, 2, 3));
```
````
- 저장된 hint: `return bread + 1, tray * 2, oven - 3;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
7
0
```
- 보인 그대로 돌린 출력(stdout 줄):
```
7
0
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N03#2
- 개념 이름: 배열 요소 덮어쓰기
- 개념 견본 blurb: 배열 이름 뒤 대괄호에 번호를 넣고 = 로 값을 주면 그 자리의 원래 값이 새 값으로 바뀝니다. 다른 자리의 값은 그대로 남습니다. — `menus[1] = "떡볶이";`
- 개념 견본 code (학습자 코드):
```
const menus = ["김밥", "라면", "우동"];
menus[1] = "떡볶이";
console.log(menus[0]);
console.log(menus[1]);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const box = [4, 7, 2];
box[1] = box[0] + 1;
console.log(box[0]);
console.log(box[1]);
console.log(box[2]);
```
````
- 저장된 hint: `box[1] = box[0] + 1;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
4
5
2
```
- 보인 그대로 돌린 출력(stdout 줄):
```
4
5
2
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N04#2
- 개념 이름: for 반복 변수 재대입
- 개념 견본 blurb: for 반복 변수는 리스트 항목의 값을 받아 둔 이름일 뿐이라서 그 이름에 새 값을 대입해도 리스트 안의 값은 그대로입니다. 리스트를 바꾸려면 인덱스로 대입하거나 새 리스트를 만들어야 합니다. — `for b in breads: b = b * 2`
- 개념 견본 code (학습자 코드):
```
breads = [1000, 2000, 3000]
for b in breads: b = b * 2
print(breads)
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
spots = [5, 7, 9]
for spot in spots:
    spot = spot + 100
print(spots[0])
print(spot)
```
````
- 저장된 hint: `spot = spot + 100` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
5
109
```
- 보인 그대로 돌린 출력(stdout 줄):
```
5
109
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N04#3
- 개념 이름: 중첩 if 문
- 개념 견본 blurb: if 블록 안에 또 if를 넣으면 바깥 조건이 참일 때만 안쪽 조건을 검사합니다. 들여쓰기 깊이로 어느 if에 속한 코드인지 구분합니다. — `if has_ticket:`
- 개념 견본 code (학습자 코드):
```
age = 15
has_ticket = True
if has_ticket:
    if age >= 12:
        print("입장 가능")
    else:
        print("보호자 필요")
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
tent = True
pack = False
result = "대기"
if tent:
    if pack:
        result = "출발"
print(result)
```
````
- 저장된 hint: `if pack:` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
대기
```
- 보인 그대로 돌린 출력(stdout 줄):
```
대기
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N05#1
- 개념 이름: 건너뛴 인덱스 대입 빈 칸
- 개념 견본 blurb: 배열 길이보다 큰 인덱스에 값을 넣으면 그 사이가 빈 칸으로 채워지고 length도 그만큼 늘어납니다. 빈 칸을 읽으면 undefined가 나옵니다. — `slots[4] = "잡지";`
- 개념 견본 code (학습자 코드):
```
const slots = ["소설", "만화"];
slots[4] = "잡지";
console.log(slots.length);
console.log(slots[2]);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const bike = ["A", "B"];
bike[4] = "C";
console.log(bike.length);
console.log(bike[2]);
console.log(bike[4]);
```
````
- 저장된 hint: `bike[4] = "C";` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
5
undefined
C
```
- 보인 그대로 돌린 출력(stdout 줄):
```
5
undefined
C
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N05#3
- 개념 이름: 개수 세는 카운터 변수
- 개념 견본 blurb: 0으로 시작한 변수를 조건에 맞을 때마다 1씩 올리면 조건에 맞는 항목이 몇 개인지 셀 수 있습니다. 반복이 끝난 뒤 그 변수에 개수가 남습니다. — `bigFish = bigFish + 1;`
- 개념 견본 code (학습자 코드):
```
const fishSizes = [12, 30, 8, 25, 40];
let bigFish = 0;
for (const fish of fishSizes) {
  if (fish >= 20) {
    bigFish = bigFish + 1;
  }
}
console.log("큰 물고기 " + bigFish + "마리");
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const bus = ["서", "동", "남", "북", "동"];
let stop = 0;
for (let i = 0; i < bus.length; i++) {
  if (bus[i] === "동") stop++;
}
console.log(stop);
console.log(bus.length);
```
````
- 저장된 hint: `if (bus[i] === "동") stop++;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
2
5
```
- 보인 그대로 돌린 출력(stdout 줄):
```
2
5
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N06#1
- 개념 이름: map 결과 한 번만 소비
- 개념 견본 blurb: map()이 돌려주는 것은 리스트가 아니라 한 번 꺼내면 비어 버리는 반복자입니다. 두 번째로 list()를 하면 이미 다 꺼낸 뒤라 빈 리스트가 나옵니다. — `doubled = map(lambda n: n * 2, seeds)`
- 개념 견본 code (학습자 코드):
```
seeds = [3, 5, 7]
doubled = map(lambda n: n * 2, seeds)
print(list(doubled))
print(list(doubled))
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
parcel = [2, 5, 3]
box = map(lambda w: w * 10, parcel)
first = list(box)
second = list(box)
print(len(first))
print(len(second))
```
````
- 저장된 hint: `second = list(box)` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
3
0
```
- 보인 그대로 돌린 출력(stdout 줄):
```
3
0
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N06#2
- 개념 이름: 한 줄 연쇄 대입
- 개념 견본 blurb: a = b = 0처럼 쓰면 여러 변수에 같은 값을 한 번에 넣습니다. 숫자는 바꿀 수 없는 값이라 한 변수를 += 로 바꿔도 다른 변수는 그대로입니다. — `wins = losses = 0`
- 개념 견본 code (학습자 코드):
```
wins = losses = 0
wins += 3
print(wins)
print(losses)
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
fruit = basket = stock = 7
basket -= 2
stock = stock * 2
print(fruit)
print(basket)
print(stock)
```
````
- 저장된 hint: `fruit = basket = stock = 7` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
7
5
14
```
- 보인 그대로 돌린 출력(stdout 줄):
```
7
5
14
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N07#2
- 개념 이름: 큰 정수 정밀도 손실
- 개념 견본 blurb: 자바스크립트 숫자는 9007199254740991보다 큰 정수를 정확히 담지 못해 가까운 다른 값으로 바뀝니다. 아주 긴 번호는 숫자 대신 문자열로 다루는 것이 안전합니다. — `const bigId = 9007199254740993;`
- 개념 견본 code (학습자 코드):
```
const bigId = 9007199254740993;
console.log(bigId);
console.log(bigId === 9007199254740992);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const bus = 9007199254740992;
const stop = bus + 1;
const route = "9007199254740992" + "1";
console.log(stop === bus);
console.log(stop);
console.log(route);
```
````
- 저장된 hint: `const stop = bus + 1;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
true
9007199254740992
90071992547409921
```
- 보인 그대로 돌린 출력(stdout 줄):
```
true
9007199254740992
90071992547409921
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N07#3
- 개념 이름: while else 문
- 개념 견본 blurb: while 뒤의 else 블록은 break 없이 조건이 거짓이 되어 반복이 끝났을 때 한 번 실행됩니다. — `while cookies > 0:`
- 개념 견본 code (학습자 코드):
```
cookies = 3
while cookies > 0:
    cookies -= 1
else:
    print("jar empty")
print(cookies)
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
stamps = 5
while stamps > 2:
    stamps -= 1
else:
    stamps += 100
print(stamps)
```
````
- 저장된 hint: `while stamps > 2:` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
102
```
- 보인 그대로 돌린 출력(stdout 줄):
```
102
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N08#1
- 개념 이름: 기본 인자 정의 시점 평가
- 개념 견본 blurb: 기본 인자의 값은 함수를 호출할 때가 아니라 def 줄이 실행될 때 한 번 정해집니다. 그래서 나중에 rate를 20으로 바꿔도 기본값은 처음의 10으로 남아 있습니다. — `def tip_amount(cost, r=rate):`
- 개념 견본 code (학습자 코드):
```
rate = 10
def tip_amount(cost, r=rate):
    return cost * r // 100
rate = 20
print(tip_amount(5000))
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
rate = 10
def mail(letter, stamp=rate):
    return f"{letter}:{stamp}"
rate = 20
print(mail("A"))
print(mail("B"))
```
````
- 저장된 hint: `def mail(letter, stamp=rate):` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
A:10
B:10
```
- 보인 그대로 돌린 출력(stdout 줄):
```
A:10
B:10
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N08#3
- 개념 이름: 튜플 크기 비교 순서
- 개념 견본 blurb: 튜플끼리 비교하면 앞 칸부터 차례로 비교하고, 처음으로 다른 칸에서 결과가 정해집니다. 그래서 (1, 9)는 첫 칸 1이 2보다 작아 (2, 0)보다 작습니다. — `need_update = mine < latest`
- 개념 견본 code (학습자 코드):
```
mine = (2, 5)
latest = (2, 9)
need_update = mine < latest
print(need_update)
print((1, 9) > (2, 0))
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
bus = (2, 7)
stop = (2, 3)
route = (1, 9)
print(bus > stop)
print(route > stop)
```
````
- 저장된 hint: 맨 위 줄부터 이름마다 어떤 값이 들어가는지 적어 가며 보세요.
- 저장된 answer:
```
True
False
```
- 보인 그대로 돌린 출력(stdout 줄):
```
True
False
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N09#1
- 개념 이름: 빠진 인자 undefined
- 개념 견본 blurb: 함수를 부를 때 인자를 덜 넘기면 오류 없이 빠진 매개변수가 undefined가 됩니다. undefined로 계산하면 결과가 NaN이 되어 버그를 알아채기 어렵습니다. — `const half = roomArea(4);`
- 개념 견본 code (학습자 코드):
```
function roomArea(width, height) {
  return width * height;
}
const full = roomArea(4, 3);
const half = roomArea(4);
console.log(full, half);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
function paint(color, brush) {
  return color + " 붓 " + brush * 2;
}
console.log(paint("빨강", 3));
console.log(paint("파랑"));
```
````
- 저장된 hint: `return color + " 붓 " + brush * 2;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
빨강 붓 6
파랑 붓 NaN
```
- 보인 그대로 돌린 출력(stdout 줄):
```
빨강 붓 6
파랑 붓 NaN
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N09#2
- 개념 이름: 객체 메서드 단축 문법
- 개념 견본 blurb: 객체 안에서 이름 뒤에 바로 괄호와 중괄호를 쓰면 function 없이도 메서드를 만들 수 있습니다. 호출할 때는 객체.이름() 처럼 괄호를 붙입니다. — `hello() {`
- 개념 견본 code (학습자 코드):
```
const robot = {
  hello() {
    return "삐삐 출동!";
  },
};
console.log(robot.hello());
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const fridge = { egg: 10, milk: 2, total() { return this.egg + this.milk; } };
console.log(fridge.total());
fridge.egg = 4;
console.log(fridge.total());
```
````
- 저장된 hint: 맨 위 줄부터 이름마다 어떤 값이 들어가는지 적어 가며 보세요.
- 저장된 answer:
```
12
6
```
- 보인 그대로 돌린 출력(stdout 줄):
```
12
6
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N10#2
- 개념 이름: 리스트 += 제자리 변경
- 개념 견본 blurb: 리스트의 +=는 원래 리스트를 그 자리에서 늘리므로 같은 리스트를 가리키는 다른 변수에도 바뀐 내용이 보입니다. 반면 a = a + [...]는 새 리스트를 만들어 이름만 옮기기 때문에 원래 리스트는 바뀌지 않습니다. — `team_b += ["서연"]`
- 개념 견본 code (학습자 코드):
```
team_a = ["민지", "도윤"]
team_b = team_a
team_b += ["서연"]
print(team_a)
team_b = team_b + ["하준"]
print(team_a)
print(team_b)
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
basket = ["사과"]
fruit = basket
stock = basket
basket += ["배"]
stock = stock + ["귤"]
print(len(fruit))
print(len(stock))
print(len(basket))
```
````
- 저장된 hint: `basket += ["배"]` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
2
3
2
```
- 보인 그대로 돌린 출력(stdout 줄):
```
2
3
2
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N10#3
- 개념 이름: range len 인덱스 반복
- 개념 견본 blurb: range(len(리스트))로 반복하면 0부터 마지막 위치까지의 번호를 얻고, 그 번호로 리스트 칸을 꺼낼 수 있습니다. — `for i in range(len(seats)):`
- 개념 견본 code (학습자 코드):
```
seats = ["A", "B", "C"]
for i in range(len(seats)):
    print(i, seats[i])
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
tent = ["텐트", "의자", "랜턴"]
pack = [1, 0, 2]
total = 0
for i in range(len(tent)):
    total += pack[i]
print(total)
print(tent[1])
```
````
- 저장된 hint: `for i in range(len(tent)):` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
3
의자
```
- 보인 그대로 돌린 출력(stdout 줄):
```
3
의자
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N11#1
- 개념 이름: 중첩 객체 속성 접근
- 개념 견본 blurb: 객체의 속성 값이 또 객체이면 점을 이어 붙여 안쪽 속성까지 차례로 들어갈 수 있습니다. 앞에서부터 하나씩 꺼낸 값에서 다시 속성을 읽는 것입니다. — `club: { clubName: "로봇부", room: 3 },`
- 개념 견본 code (학습자 코드):
```
const student = {
  nick: "지우",
  club: { clubName: "로봇부", room: 3 },
};
console.log(student.club.clubName);
console.log(student.club.room + "반 교실");
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const paint = { brush: { size: 3, color: "빨강" }, canvas: 5 };
const brush = paint.brush;
const color = brush.color;
console.log(color + "색 붓");
console.log(paint.brush.size * 2);
console.log(paint.canvas + brush.size);
```
````
- 저장된 hint: `const color = brush.color;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
빨강색 붓
6
8
```
- 보인 그대로 돌린 출력(stdout 줄):
```
빨강색 붓
6
8
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N11#3
- 개념 이름: 들여쓰기 블록 범위
- 개념 견본 blurb: 파이썬은 들여쓰기로 블록을 나누므로, 반복문 아래 들여쓴 줄만 반복되고 들여쓰기를 뺀 줄은 반복이 끝난 뒤 한 번만 실행됩니다. — `for d in days:`
- 개념 견본 code (학습자 코드):
```
days = [2, 6]
for d in days:
    if d > 4:
        print("rest", d)
print("done")
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
basket = ["사과", "배", "포도"]
stock = 0
for fruit in basket:
    stock = stock + 2
stock = stock + 10
print(stock)
print(len(basket))
```
````
- 저장된 hint: `stock = stock + 10` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
16
3
```
- 보인 그대로 돌린 출력(stdout 줄):
```
16
3
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N12#1
- 개념 이름: 배열 entries 반복
- 개념 견본 blurb: 배열의 entries 메서드는 [번호, 값] 짝을 하나씩 돌려주므로 for...of와 함께 쓰면 인덱스와 값을 동시에 꺼낼 수 있습니다. 번호는 0부터 시작하므로 사람에게 보여 줄 때는 1을 더합니다. — `for (const [i, step] of steps.entries()) {`
- 개념 견본 code (학습자 코드):
```
const steps = ["물 붓기", "면 넣기", "불 끄기"];
for (const [i, step] of steps.entries()) {
  console.log(i + 1 + ". " + step);
}
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const seats = ["가", "나", "다"];
let text = "";
for (const [row, seat] of seats.entries()) {
  text = text + (row + 1) + seat;
}
console.log(text);
```
````
- 저장된 hint: 맨 위 줄부터 이름마다 어떤 값이 들어가는지 적어 가며 보세요.
- 저장된 answer:
```
1가2나3다
```
- 보인 그대로 돌린 출력(stdout 줄):
```
1가2나3다
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N12#2
- 개념 이름: 튜플 딕셔너리 키
- 개념 견본 blurb: 튜플은 바뀌지 않는 값이라 딕셔너리의 키로 쓸 수 있어서, 좌표처럼 두 값을 묶어 하나의 키로 찾을 수 있습니다. — `marks[(0, 0)] = "home"`
- 개념 견본 code (학습자 코드):
```
marks = {(0, 1): "tree", (2, 3): "rock"}
spot = (2, 3)
print(marks[spot])
marks[(0, 0)] = "home"
print(len(marks))
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
gear = {}
gear[("tent", 1)] = "텐트"
gear[("pack", 2)] = "배낭"
gear[("tent", 1)] = "침낭"
print(gear[("pack", 2)])
print(len(gear))
print(("fire", 3) in gear)
```
````
- 저장된 hint: `gear[("tent", 1)] = "침낭"` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
배낭
2
False
```
- 보인 그대로 돌린 출력(stdout 줄):
```
배낭
2
False
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N13#2
- 개념 이름: Object.fromEntries 객체 만들기
- 개념 견본 blurb: Object.fromEntries는 [키, 값] 짝이 담긴 배열을 받아 그 짝들로 이루어진 새 객체를 만들어 줍니다. 만든 뒤에는 점 표기로 각 키의 값을 바로 읽을 수 있습니다. — `const stock = Object.fromEntries(pairs);`
- 개념 견본 code (학습자 코드):
```
const pairs = [["apple", 3], ["pear", 5]];
const stock = Object.fromEntries(pairs);
console.log(stock.apple);
console.log(stock.pear);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const pairs = [["paint", 3], ["brush", 5], ["color", 2]];
const kit = Object.fromEntries(pairs);
const total = kit.paint + kit.brush;
console.log(typeof kit);
console.log(kit.color);
console.log(total);
```
````
- 저장된 hint: `const kit = Object.fromEntries(pairs);` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
object
2
8
```
- 보인 그대로 돌린 출력(stdout 줄):
```
object
2
8
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N14#1
- 개념 이름: 즉시 실행 함수
- 개념 견본 blurb: 함수 표현식을 괄호로 감싸고 바로 뒤에 ()를 붙이면 정의하자마자 한 번 실행되고, 변수에는 함수가 아니라 그 반환값이 담깁니다. 안에서 만든 변수는 바깥에 새지 않습니다. — `})();`
- 개념 견본 code (학습자 코드):
```
const startScore = (function () {
  let n = 0;
  n += 2;
  return n * 10;
})();
console.log(startScore);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const bread = (function () {
  const tray = 3;
  const oven = tray * 2;
  return oven + 1;
})();
console.log(bread);
console.log(typeof tray);
```
````
- 저장된 hint: 맨 위 줄부터 이름마다 어떤 값이 들어가는지 적어 가며 보세요.
- 저장된 answer:
```
7
undefined
```
- 보인 그대로 돌린 출력(stdout 줄):
```
7
undefined
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N14#3
- 개념 이름: 딕셔너리 == 비교
- 개념 견본 blurb: 딕셔너리를 == 로 비교하면 넣은 순서와 상관없이 키와 값이 모두 같을 때만 True가 됩니다. — `same = left == right`
- 개념 견본 code (학습자 코드):
```
left = {"shirt": 2, "sock": 5}
right = {"sock": 5, "shirt": 2}
same = left == right
print(same)
right["sock"] = 4
print(left == right)
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
seat = {"row": "B", "ticket": 12}
ticket = {"ticket": 12, "row": "B"}
print(seat == ticket)
seat["row"] = "C"
print(seat == ticket)
```
````
- 저장된 hint: `seat["row"] = "C"` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
True
False
```
- 보인 그대로 돌린 출력(stdout 줄):
```
True
False
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N15#1
- 개념 이름: map 콜백 인덱스 인자
- 개념 견본 blurb: map에 넘긴 콜백은 첫 번째 인자로 값을, 두 번째 인자로 그 값의 인덱스를 받습니다. 인덱스는 0부터 시작하므로 등수처럼 쓰려면 1을 더합니다. — `const labels = runners.map((runner, i) => (i + 1) + "등 " + runner);`
- 개념 견본 code (학습자 코드):
```
const runners = ["민지", "도윤", "서아"];
const labels = runners.map((runner, i) => (i + 1) + "등 " + runner);
console.log(labels[0]);
console.log(labels[2]);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const pace = [330, 320, 340];
const score = pace.map((p, i) => p - i * 5);
console.log(score[1]);
console.log(score[2]);
```
````
- 저장된 hint: 맨 위 줄부터 이름마다 어떤 값이 들어가는지 적어 가며 보세요.
- 저장된 answer:
```
315
330
```
- 보인 그대로 돌린 출력(stdout 줄):
```
315
330
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-N15#2
- 개념 이름: set 접근자
- 개념 견본 blurb: 객체에 set으로 정의한 속성은 값을 대입할 때 함수처럼 실행되어, 받은 값을 바꿔 다른 속성에 저장할 수 있습니다. 대입문은 평범해 보여도 안에서는 계산이 일어납니다. — `pet.months = 36;`
- 개념 견본 code (학습자 코드):
```
const pet = {
  age: 0,
  set months(m) {
    this.age = m / 12;
  },
};
pet.months = 36;
console.log(pet.age);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const plot = {
  water: 0,
  set crop(n) { this.water = n * 3 + 1; }
};
plot.crop = 4;
console.log(plot.water);
console.log(plot.crop);
```
````
- 저장된 hint: `set crop(n) { this.water = n * 3 + 1; }` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
13
undefined
```
- 보인 그대로 돌린 출력(stdout 줄):
```
13
undefined
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-M1#2
- 개념 이름: 반복 경계 하나 초과
- 개념 견본 blurb: 배열 인덱스는 0부터 length 빼기 1까지이므로 조건에 <=를 쓰면 한 번 더 돌아 없는 칸을 읽습니다. 배열을 돌 때는 i < 배열.length로 써야 합니다. — `for (let i = 0; i <= snacks.length; i++) {`
- 개념 견본 code (학습자 코드):
```
const snacks = ["과자", "젤리"];
for (let i = 0; i <= snacks.length; i++) {
  console.log(snacks[i]);
}
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const fire = ["성냥", "가스", "토치"];
let total = 0;
for (let i = 0; i < fire.length; i++) {
  total = total + fire[i].length;
}
console.log(total);
console.log(fire.length);
```
````
- 저장된 hint: `for (let i = 0; i < fire.length; i++) {` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
6
3
```
- 보인 그대로 돌린 출력(stdout 줄):
```
6
3
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-M1#3
- 개념 이름: 배열 요소 덮어쓰기
- 개념 견본 blurb: 배열 이름 뒤 대괄호에 번호를 넣고 = 로 값을 주면 그 자리의 원래 값이 새 값으로 바뀝니다. 다른 자리의 값은 그대로 남습니다. — `menus[1] = "떡볶이";`
- 개념 견본 code (학습자 코드):
```
const menus = ["김밥", "라면", "우동"];
menus[1] = "떡볶이";
console.log(menus[0]);
console.log(menus[1]);
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
const weight = [2, 4, 6];
weight[0] = weight[0] + 10;
weight[2] = 1;
console.log(weight[0]);
console.log(weight[1]);
console.log(weight[2]);
```
````
- 저장된 hint: `weight[2] = 1;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
12
4
1
```
- 보인 그대로 돌린 출력(stdout 줄):
```
12
4
1
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-M2#2
- 개념 이름: 딕셔너리에 담은 함수
- 개념 견본 blurb: 파이썬에서 함수도 값이라서 괄호 없이 이름만 쓰면 딕셔너리의 값으로 담을 수 있습니다. 꺼낸 뒤 괄호를 붙이면 그 함수가 실행됩니다. — `ops = {"+": plus, "-": minus}`
- 개념 견본 code (학습자 코드):
```
def plus(a, b):
    return a + b
def minus(a, b):
    return a - b
ops = {"+": plus, "-": minus}
print(ops["+"](7, 3))
print(ops["-"](7, 3))
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
def park(car):
    return car + "-P"
gate = {"in": park, "out": lambda car: car + "-L"}
car = "K"
print(gate["in"](car))
print(gate["out"](car) + "!")
```
````
- 저장된 hint: 맨 위 줄부터 이름마다 어떤 값이 들어가는지 적어 가며 보세요.
- 저장된 answer:
```
K-P
K-L!
```
- 보인 그대로 돌린 출력(stdout 줄):
```
K-P
K-L!
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-M3#1
- 개념 이름: 반복 변수 루프 밖 값
- 개념 견본 blurb: 파이썬의 for 반복 변수는 반복이 끝난 뒤에도 사라지지 않고 마지막으로 받은 값을 그대로 가지고 있습니다. 반복 밖에서 같은 이름을 쓰면 마지막 항목이 나오니 주의해야 합니다. — `for room in ["거실", "부엌", "욕실"]:`
- 개념 견본 code (학습자 코드):
```
visited = 0
for room in ["거실", "부엌", "욕실"]:
    visited += 1
print(visited)
print(room)
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```python
water = 0
for seed in [3, 5, 7]:
    water = water + seed
print(seed)
print(water)
```
````
- 저장된 hint: `for seed in [3, 5, 7]:` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
7
15
```
- 보인 그대로 돌린 출력(stdout 줄):
```
7
15
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지

### P-M3#2
- 개념 이름: for 문 2씩 증가
- 개념 견본 blurb: for 문의 세 번째 칸에 += 2를 쓰면 반복할 때마다 변수가 1이 아니라 2씩 커집니다. 그래서 2, 4, 6처럼 건너뛴 값만 차례로 돌 수 있습니다. — `for (let stair = 2; stair <= 6; stair += 2) {`
- 개념 견본 code (학습자 코드):
```
for (let stair = 2; stair <= 6; stair += 2) {
  console.log("계단 " + stair);
}
```
- 저장된 question (학습자에게 보인 글 그대로):
````
처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.
```js
let song = 1;
let count = 0;
for (; song < 8; song += 2) count++;
console.log(song);
console.log(count);
```
````
- 저장된 hint: `for (; song < 8; song += 2) count++;` 줄에서 무슨 일이 일어나는지부터 보세요.
- 저장된 answer:
```
9
4
```
- 보인 그대로 돌린 출력(stdout 줄):
```
9
4
```
- grep에 걸린 금지 낱말: 없음
- 판정할 것: 3 (라) · 4 · 5의 쓰임 · 7의 나머지
