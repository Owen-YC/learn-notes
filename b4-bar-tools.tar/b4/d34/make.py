"""learn-notes 1.12.0 G5 (batch 4) D34: the committed tree's own requests, caught from its plugin test harness, set
against the tools' requests (d34/expect.mjs, built by tools/kit.mjs) to the byte: model, effort, system, prompt,
maxTokens, timeoutMs. Rebuilt from impl111/b7/d34/make.py (1.11.0 G5) and impl112/b1/d34/make.py on the build commit's
tree (impl112/b4/mtree = git archive 9f0dff1): its tests replaced by tests/flowkit.ts (patched to catch each request
whole and to give each frozen change's Edit/Write result) and one d34.test.ts. Each test: the alias as the model, level
beginner, the harness row `models: { <alias>: { isThinkAsked: true } }` (the rest of the committed row: isRuleWide on),
the team file at /proj/.claude/learn-notes.md when the test has one; the change's request, its files by Edit/Write, the
turn ending with its answer; the note's call; r's key on the pane; a minute on the typed words in the question field.
The harness answers the calls with the test's texts in order. A test with no typed words stops after r.
  syn                                    -> d34/syn-run/        (the call kinds, both models, team file or none)
  set <set dir> <model> <out dir>        -> <out dir>/          (a frozen set's changes, fixed replies)
  real-r <set dir> <note out> <r lines> <model> <out dir>
  real-check <set dir> <note out> <r out> <check lines> <check meta> <model> <out dir>
Exit 0 only when every test ran, every request is the same and no test made a request more (result.json beside the
capture). Runs `claude plugin test .` in a copy of the tree (no model call: the harness answers every call)."""
import json, os, shutil, subprocess, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4"
PATCHES = [
    ("    w.systems.push(e.system)\n", "    w.systems.push(e.system)\n    CAUGHT.push({ model: e.model, effort: e.effort, system: e.system, prompt: e.prompt, maxTokens: e.maxTokens, timeoutMs: e.timeoutMs })\n"),
    ("  on('tool.call', { tool: 'Edit' }, (_$, e) => {\n", "  on('tool.call', { tool: 'Edit' }, (_$, e) => {\n    if (FROZEN.has(e.file_path)) return FROZEN.get(e.file_path) as never\n"),
    ("  on('tool.call', { tool: 'Write' }, (_$, e) =>\n    e.file_path.endsWith('a.ts')", "  on('tool.call', { tool: 'Write' }, (_$, e) =>\n    FROZEN.has(e.file_path)\n      ? (FROZEN.get(e.file_path) as never)\n      : e.file_path.endsWith('a.ts')"),
]
KEYS = ["model", "effort", "system", "prompt", "maxTokens", "timeoutMs"]


def tree_at(run):
    tree = f"{run}/tree"
    shutil.rmtree(tree, ignore_errors=True)
    shutil.copytree(f"{S}/mtree", tree, symlinks=True)
    for f in os.listdir(f"{tree}/tests"):
        if f.endswith(".test.ts"):
            os.remove(f"{tree}/tests/{f}")
    kit = open(f"{tree}/tests/flowkit.ts", encoding="utf-8").read()
    for old, new in PATCHES:
        assert kit.count(old) == 1, old
        kit = kit.replace(old, new)
    kit += "\nexport const CAUGHT: Record<string, unknown>[] = []\nexport const FROZEN = new Map<string, unknown>()\n"
    open(f"{tree}/tests/flowkit.ts", "w", encoding="utf-8").write(kit)
    return tree


def calls_of(entry):
    results, calls = {}, []
    for f in entry["files"]:
        if f["tool"] == "Edit":
            results[f["path"]] = {"result": {"filePath": f["path"], "oldString": "(frozen)", "newString": "(frozen)", "originalFile": f["before"], "structuredPatch": f["hunks"], "userModified": False, "replaceAll": False}}
            calls.append({"tool": "Edit", "tool_use_id": f"u{len(calls) + 1}", "file_path": f["path"], "old_string": "(frozen)", "new_string": "(frozen)"})
        else:
            results[f["path"]] = {"result": {"type": "create", "filePath": f["path"], "content": f["content"], "structuredPatch": [], "originalFile": None}}
            calls.append({"tool": "Write", "tool_use_id": f"u{len(calls) + 1}", "file_path": f["path"], "content": f["content"]})
    return results, calls


def test_src(i, t):
    s, entry = t["sample"], t["entry"]
    results, calls = calls_of(entry)
    data = json.dumps({"i": i, "id": s["id"], "model": t["model"], "request": s["request"], "answer": s["answer"], "results": results, "calls": calls, "texts": t["texts"], "team": t["team"], "typed": t["typed"]}, ensure_ascii=False)
    return f"""test({json.dumps(f"D34 {i} {t['name']}")}, {{ options: {{ model: {json.dumps(t['model'])}, level: 'beginner' }}, timeoutMs: 20000 }}, async ($, on) => {{
  const d = {data} as {{ i: number; id: string; model: string; request: string; answer: string; results: Record<string, unknown>; calls: unknown[]; texts: string[]; team: string | null; typed: string | null }}
  CAUGHT.length = 0
  FROZEN.clear()
  for (const [path, result] of Object.entries(d.results)) FROZEN.set(path, result)
  const w = world(on, 'ok', null, true, new Map())
  if (d.team !== null) w.files.set('/proj/.claude/learn-notes.md', d.team)
  w.harness = {{ models: {{ [d.model]: {{ isThinkAsked: true }} }} }}
  w.texts = [...d.texts]
  await start($)
  await $.turn.start({{ text: d.request, turnId: d.id }})
  for (const call of d.calls) await $.tool.call(call as never)
  await $.turn.complete({{ answer: d.answer, durationMs: 5, isAborted: false, turnId: d.id, reason: 'answer' }})
  await finish(w)
  const ui = await pane($, 'terminal', {{ ...PANE_PROPS, isFocused: true }})
  await ui.press({{ key: 'trace' }})
  await w.clock.settle()
  let field: string | null = null
  if (d.typed !== null) {{
    await w.clock.advance(60_000)
    await w.clock.settle()
    const input = await ui.find({{ type: 'Input' }})
    field = input ? String((input as unknown as {{ props: {{ key: string }} }}).props.key) : null
    if (field !== null) await ui.input({{ key: field, text: d.typed }})
    await w.clock.settle()
  }}
  await ui.unmount()
  console.log('D34CAP ' + JSON.stringify({{ i: d.i, field, caught: CAUGHT }}))
}})
"""


def run(run_dir, tests):
    os.makedirs(run_dir, exist_ok=True)
    if os.path.exists(f"{run_dir}/capture.log"):
        sys.exit(f"refuse: {run_dir}/capture.log exists")
    tree = tree_at(run_dir)
    body = ["import { test } from 'claude-code/testing'", "import { CAUGHT, FROZEN, PANE_PROPS, finish, pane, start, world } from './flowkit'", ""]
    for i, t in enumerate(tests):
        body.append(test_src(i, t))
    open(f"{tree}/tests/d34.test.ts", "w", encoding="utf-8").write("\n".join(body))
    p = subprocess.run(["claude", "plugin", "test", "."], cwd=tree, capture_output=True, text=True, env={**os.environ, "DISABLE_AUTOUPDATER": "1"}, timeout=3000)
    log = p.stdout + p.stderr
    open(f"{run_dir}/capture.log", "w").write(log)
    caught = {}
    for l in log.split("\n"):
        if "D34CAP " in l:
            c = json.loads(l.split("D34CAP ", 1)[1])
            caught[c["i"]] = c
    same = bad = 0
    report, kinds = [], {}
    for i, t in enumerate(tests):
        c = caught.get(i)
        if c is None:
            bad += 1
            report.append({"i": i, "name": t["name"], "bad": "no capture (test failed?)"})
            continue
        got = c["caught"]
        if t.get("typed") is not None and c.get("field") is None:
            bad += 1
            report.append({"i": i, "name": t["name"], "bad": "no question field"})
        for k, w in enumerate(t["want"]):
            g = got[k] if k < len(got) else None
            diff = [x for x in KEYS if g is None or g.get(x) != w.get(x)]
            label = ["note", t.get("kind", "r"), t.get("third", "third")][k] if k < 3 else str(k)
            kinds.setdefault(label, [0, 0])
            if diff:
                bad += 1
                kinds[label][1] += 1
                report.append({"i": i, "name": t["name"], "request": k, "differs": diff})
            else:
                same += 1
                kinds[label][0] += 1
        if len(got) > len(t["want"]):
            bad += 1
            report.append({"i": i, "name": t["name"], "extra": len(got) - len(t["want"])})
    out = {"tests": len(tests), "testExit": p.returncode, "requestsSame": same, "bad": bad, "byKind": {k: {"same": v[0], "different": v[1]} for k, v in kinds.items()}, "report": report[:60]}
    json.dump(out, open(f"{run_dir}/result.json", "w"), ensure_ascii=False, indent=1)
    shutil.rmtree(tree, ignore_errors=True)
    print(json.dumps({k: out[k] for k in ("tests", "testExit", "requestsSame", "bad", "byKind")}, ensure_ascii=False))
    return bad == 0 and p.returncode == 0


def expect(*args):
    p = subprocess.run(["node", "--experimental-transform-types", "--no-warnings", f"{S}/d34/expect.mjs", *args], capture_output=True, text=True)
    if p.returncode != 0:
        sys.exit("expect.mjs failed: " + p.stderr[-2000:])
    return json.loads(p.stdout)["tests"]


if __name__ == "__main__":
    mode, args = sys.argv[1], sys.argv[2:]
    if mode == "syn":
        ok = run(f"{S}/d34/syn-run", expect("syn"))
    elif mode == "set":
        ok = run(args[2], expect("set", args[0], args[1]))
    elif mode == "real-r":
        ok = run(args[4], expect("real-r", *args[:4]))
    elif mode == "real-check":
        ok = run(args[6], expect("real-check", *args[:6]))
    else:
        sys.exit("usage: make.py syn | set <dir> <model> <out> | real-r <dir> <note out> <r lines> <model> <out> | real-check <dir> <note out> <r out> <check lines> <meta> <model> <out>")
    sys.exit(0 if ok else 1)
