// learn-notes 1.12.0 G5 (batch 4) D34: the requests the tools expect (tools/kit.mjs), per test of d34/make.py, which
// catches the committed tree's own requests from its plugin test harness and sets them against these to the byte
// (model · effort · system · prompt · maxTokens · timeoutMs; a tool line's effort is the probe's 'low'). No model call.
// Each test: the alias, level beginner, the harness row of that model with isThinkAsked on (the rest of the committed
// row), with or without the team file (impl112/b4/d34/team.md); the change's request, its files by Edit · Write, the
// turn's answer; the note's call; r's key; a minute on, the typed words. Its requests in order: note, r, then the
// check (a line opened) or the question (none opened). Modes (prints JSON { tests: [...] }):
//   syn                        the synthetic call kinds (d34/syn: changes.json, hunks.json by tools/prep.py): note; r in scope with an anchor; r in scope
//                              without one; r out of scope (TRACE_170, 1.7.0's words); check; and a question with no
//                              line open; for haiku and sonnet, without and with the team file
//   set <set dir> <model>      every change of a frozen set, no team file (the samples carry none), fixed replies: the
//                              set's note, r and third request (check or question) before any call of that set
//   real-r <set dir> <note out.json> <r lines.jsonl> <model>
//                              each answered note's real reply: note request and r request = the frozen r line itself
//   real-check <set dir> <note out.json> <r out.json> <check lines.jsonl> <check meta.json> <model>
//                              each check line: its note's and r's real replies, its typed words: the third request =
//                              the frozen check line itself
import { readFileSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
const S = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4'
const K = await import(pathToFileURL(`${S}/tools/kit.mjs`).href)

export const NOTE_ANSWER = ['### 한 줄 요약', '함수가 받은 값을 검사한 뒤 결과를 돌려주게 바꿨습니다.', '', '### 무엇이 바뀌었나', '- 입력을 먼저 검사하고, 맞지 않으면 다른 값을 돌려줍니다.', '', '### 배울 개념', '- **조건문**: 값에 따라 다른 길로 가게 합니다.'].join('\n')
export const CHECK_REPLY = ['종류: 짐작', '근거: `1 + 1`', '바른 결과: `2`', '판정: 틀림', '까닭: 값이 다릅니다.', '답: 없음'].join('\n')
export const TYPED = '2000?'
const TEAM = readFileSync(`${S}/d34/team.md`, 'utf8')
const lines = p => readFileSync(p, 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l))
const req = l => ({ model: l.model, effort: 'low', system: l.system, prompt: l.prompt, maxTokens: l.maxTokens, timeoutMs: l.timeoutMs })
const outs = p => Object.fromEntries(JSON.parse(readFileSync(p, 'utf8')).results.map(r => [r.id, r]))

/** A walk-through ending on a literal call of the note's first target that differs from every call shown (opens), or none. */
export function rAnswerOf(callees) {
  const c = callees[0]
  if (!c) return ['1. 예시 입력으로 함수를 부릅니다.', '2. 조건을 보고 다음 줄로 갑니다.', '3. 마지막에 결과를 돌려줍니다.', '', '**생각해 보기:** `x`를 `3`으로 바꾸면 최종 결과는 무엇이 될까요?'].join('\n')
  const args = Array.from({ length: Math.max(1, c.min) }, () => '7919').join(', ')
  return [...(c.anchor ? [] : [`예시 호출: \`${c.name}(${Array.from({ length: Math.max(1, c.min) }, () => '1').join(', ')})\``]), '1. 예시 입력으로 함수를 부릅니다.', '2. 조건을 보고 다음 줄로 갑니다.', '3. 마지막에 결과를 돌려줍니다.', '바뀌기 전 코드였다면 2단계에서 결과가 달라집니다.', '', `**생각해 보기:** \`${c.name}(${args})\``].join('\n')
}

/** note, r and the third request for one change, model, team and replies; `third` says which kind went. */
export function wantOf(model, sample, entry, team, noteAnswer, rAnswer, typed) {
  const want = [req(K.noteLine(model, sample, entry, team))]
  const r = K.rLine(model, sample, entry, noteAnswer, team)
  want.push(req(r.line))
  const got = K.readR(model, sample, entry, noteAnswer, K.N.fixEscapedTicks(rAnswer), team)
  const third = got.think ? 'check' : 'question'
  want.push(req(third === 'check' ? K.checkLine(model, 'x', sample, entry, noteAnswer, got.stored, typed, team) : K.questionLine(model, 'x', sample, entry, noteAnswer, got.stored, typed, team)))
  return { want, kind: r.isCode ? (r.callees.some(c => c.anchor) ? 'r-anchor' : 'r-noanchor') : 'r-out', third }
}

const [mode, ...args] = process.argv.slice(2)
const tests = []
if (mode === 'syn') {
  for (const model of K.MODELS)
    for (const withTeam of [false, true])
      for (const { sample, entry } of K.samplesOf(`${S}/d34/syn`)) {
        const team = withTeam ? K.teamOf(TEAM) : undefined
        const rs = K.rLine(model, sample, entry, NOTE_ANSWER, team)
        const rAnswer = rAnswerOf(rs.callees)
        const w = wantOf(model, sample, entry, team, NOTE_ANSWER, rAnswer, TYPED)
        tests.push({ name: `syn ${sample.id} ${model} ${withTeam ? 'team' : 'noteam'} ${w.kind} ${w.third}`, sample, entry, model, team: withTeam ? TEAM : null, texts: [NOTE_ANSWER, rAnswer, CHECK_REPLY], typed: TYPED, want: w.want, kind: w.kind, third: w.third })
      }
} else if (mode === 'set') {
  const [dir, model] = args
  for (const { sample, entry } of K.samplesOf(dir)) {
    const rs = K.rLine(model, sample, entry, NOTE_ANSWER, undefined)
    const rAnswer = rAnswerOf(rs.callees)
    const w = wantOf(model, sample, entry, undefined, NOTE_ANSWER, rAnswer, TYPED)
    tests.push({ name: `set ${sample.id} ${model} ${w.kind} ${w.third}`, sample, entry, model, team: null, texts: [NOTE_ANSWER, rAnswer, CHECK_REPLY], typed: TYPED, want: w.want, kind: w.kind, third: w.third })
  }
} else if (mode === 'real-r') {
  const [dir, noteOut, rLines, model] = args
  const notes = outs(noteOut)
  const rl = Object.fromEntries(lines(rLines).map(l => [l.id, l]))
  for (const { sample, entry } of K.samplesOf(dir)) {
    const o = notes[sample.id]
    if (!o?.isAnswered || !o.text?.trim()) continue
    if (!rl[sample.id]) throw new Error(`${sample.id}: answered note with no r line`)
    tests.push({ name: `real-r ${sample.id} ${model}`, sample, entry, model, team: null, texts: [o.text, rAnswerOf([]), CHECK_REPLY], typed: null, want: [req(K.noteLine(model, sample, entry)), req(rl[sample.id])] })
  }
} else if (mode === 'real-check') {
  const [dir, noteOut, rOut, checkLines, metaPath, model] = args
  const notes = outs(noteOut)
  const rs = outs(rOut)
  const meta = JSON.parse(readFileSync(metaPath, 'utf8'))
  const byId = Object.fromEntries(K.samplesOf(dir).map(one => [one.sample.id, one]))
  for (const l of lines(checkLines)) {
    const m = meta.lines[l.id]
    const { sample, entry } = byId[m.sid]
    tests.push({ name: `real-check ${l.id} ${model}`, sample, entry, model, team: null, texts: [notes[m.sid].text, rs[m.sid].text, CHECK_REPLY], typed: m.typed, want: [req(K.noteLine(model, sample, entry)), req(K.rLine(model, sample, entry, notes[m.sid].text).line), req(l)] })
  }
} else throw new Error('usage: expect.mjs syn | set <dir> <model> | real-r … | real-check …')
console.log(JSON.stringify({ tests }))
