// learn-notes 1.12.0 G5 (batch 4) measurement kit: every G5 request and every reading of a reply, built by importing the
// build commit's notes.ts (impl112/b4/mtree = git archive 9f0dff1, hooks/notes.ts sha256 d899d0c1…80f0), the way
// register.tsx's writeNote and askNote use it with only that model's isThinkAsked on (the rest of that model's
// MODEL_SWITCHES row as committed: isRuleWide on, isRuleDrill off for both models). Rebuilt from design/G5/pilot/tools
// (lib.mjs, build.mjs), which were written against the prototype tree; the note is made as impl111/b7 think-code.mjs
// makes it (tool.call Edit/Write -> changeOf -> withheldOf, merge; turn.complete: request cut 2000 masked, answer
// cut(redactText, 2000)); screened -> screenNote with the team file's `## 빼기` patterns when a team file is given.
//   note   SYSTEM + notePrompt(shown, beginner, knownNames({}), team), NOTE_TOKENS
//   r      ASK_SYSTEM + askPrompt(shown, redactText(callees ? traceCallQuestion(callees) : traceQuestion(false)).text,
//          beginner, team, undefined, true), 900; shown = the kept note (keptNoteText(reply, isRuleWide ? ruleNames : []))
//   stored cut(callees ? thinkCallKept(text, callees, shown.text, diffs) : thinkKept(text, false), 4000) at R_AT
//   line   openThink(asks, R_AT + 60000, true, true)
//   check  THINK_SLOT_SYSTEM + thinkSlotCheckPrompt(shown, think, redactText(typed).text, beginner, thinkVariantOf(model)),
//          THINK_CHECK_TOKENS; shown reply = cut(thinkSlotReply(text, masked) ?? slotFallback(text), 4000)
// Every prompt in a line is redactText's output (askModel masks it; the probe masks it again, a no-op). Numbers are read
// from the tree's register.tsx and checked against the design's (3500, 900, 900, 90000).
import { readFileSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
import { createHash } from 'node:crypto'

export const S = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4'
export const TREE = process.env.G5_TREE ?? `${S}/mtree`
export const N = await import(pathToFileURL(`${TREE}/hooks/notes.ts`).href)
export const ROOT = '/proj'
export const LEVEL = 'beginner'
/** The note's time (its prompts never say it); r answered two minutes on; the line read and texts typed a minute after. */
export const NOTE_AT = Date.UTC(2026, 10, 4, 0, 0, 0)
export const R_AT = NOTE_AT + 120_000
export const ASKED_AT = R_AT + 60_000
export const MODELS = ['haiku', 'sonnet']
export const sha = text => createHash('sha256').update(text).digest('hex')
export const readJson = path => JSON.parse(readFileSync(path, 'utf8'))

/** The numbers register.tsx gives each call, read from the tree itself (a different tree fails here, not silently). */
export function registerNumbers() {
  const src = readFileSync(`${TREE}/hooks/register.tsx`, 'utf8')
  const num = name => Number(new RegExp(`^const ${name} = ([\\d_]+)$`, 'm').exec(src)?.[1]?.replaceAll('_', ''))
  const got = { NOTE_TOKENS: num('NOTE_TOKENS'), THINK_CHECK_TOKENS: num('THINK_CHECK_TOKENS'), MODEL_TIMEOUT_MS: num('MODEL_TIMEOUT_MS') }
  const ask = /\? \{ system: THINK_SLOT_SYSTEM, prompt: thinkSlotCheckPrompt\(shown, think, masked, level, thinkVariantOf\(cfg\.model\)\), maxTokens: THINK_CHECK_TOKENS \}\n\s+: \{ system: ASK_SYSTEM, prompt: askPrompt\(shown, masked, level, rules, think, isThinkAsked\), maxTokens: (\d+) \}/.exec(src)
  got.ASK_TOKENS = Number(ask?.[1])
  const want = { NOTE_TOKENS: 3500, THINK_CHECK_TOKENS: 900, MODEL_TIMEOUT_MS: 90000, ASK_TOKENS: 900 }
  for (const [k, v] of Object.entries(want)) if (got[k] !== v) throw new Error(`register.tsx ${k} is ${got[k]}, the design says ${v}`)
  return got
}
export const NUMS = registerNumbers()

/** The committed row of a model with isThinkAsked on (M-13: nothing else changed). */
export function switchesOf(model) {
  return { ...N.MODEL_SWITCHES[model], isThinkAsked: true }
}

/** The note's changes from one frozen change's files, in their order, as collect folds them (withheld named). */
export function changesOf(entry) {
  let changes = []
  const withheld = []
  for (const f of entry.files) {
    const hunks = f.tool === 'Write' && f.kind === 'create' && f.hunks.length === 0 ? [N.creationHunk(f.content)] : f.hunks
    const change = N.changeOf({ path: f.path, root: ROOT, tool: f.tool, kind: f.kind, hunks })
    const why = N.withheldOf(change.file, change.path, [])
    if (why !== undefined) {
      if (!withheld.some(one => one.file === change.file)) withheld.push({ file: change.file, why })
      continue
    }
    changes = N.merge(changes, change).changes
  }
  return { changes, withheld }
}

/** The note turn.complete keeps for the change (status writing, no text yet). */
export function noteOf(entry, sample) {
  const { changes, withheld } = changesOf(entry)
  const request = N.cut(sample.request ?? '', 2000)
  return {
    id: `${sample.id}-${NOTE_AT}`,
    turnId: sample.id,
    at: NOTE_AT,
    prompt: request !== '' ? N.redactText(request).text : '',
    answer: N.cut(N.redactText(sample.answer ?? '').text, 2000),
    changes,
    moreFiles: 0,
    ...(withheld.length > 0 ? { withheld } : {}),
    status: 'writing',
    text: '',
    savedAs: null,
    isPast: false,
    concepts: [],
    root: ROOT,
    updatedAt: NOTE_AT,
  }
}

/** The team file as loadTeam parses it (undefined: no team file). */
export const teamOf = markdown => (markdown === undefined || markdown === null ? undefined : N.parseTeamFile(markdown))

/** screened(): excludePaths none, the team file's `## 빼기`, no permission rule. */
export const shownOf = (note, team) => N.screenNote(note, team?.exclude ?? [], () => false)

const line = (id, model, system, prompt, maxTokens) => ({ id, model, system, prompt: N.redactText(prompt).text, maxTokens, timeoutMs: NUMS.MODEL_TIMEOUT_MS })

/** writeNote's call. */
export function noteLine(model, sample, entry, team) {
  const shown = shownOf(noteOf(entry, sample), team)
  return line(sample.id, model, N.SYSTEM, N.notePrompt(shown, LEVEL, N.knownNames({}), team), NUMS.NOTE_TOKENS)
}

/** The note as writeNote keeps it (isRuleWide on in both committed rows; isRuleDrill off: no practice made). */
export function keptNote(model, sample, entry, noteAnswer, team) {
  const names = team && switchesOf(model).isRuleWide ? N.ruleNamesOf(team.rules) : []
  return { ...noteOf(entry, sample), status: 'ready', text: N.keptNoteText(noteAnswer, names) }
}

/** askNote for r's key, ON: callees read from the screened note; the question built from them (or 1.7.0's). */
export function rLine(model, sample, entry, noteAnswer, team) {
  const shown = shownOf(keptNote(model, sample, entry, noteAnswer, team), team)
  const callees = N.thinkCallees(shown.changes)
  const isCode = callees.length > 0
  const masked = N.redactText(isCode ? N.traceCallQuestion(callees) : N.traceQuestion(false)).text
  return { line: line(sample.id, model, N.ASK_SYSTEM, N.askPrompt(shown, masked, LEVEL, team, undefined, true), NUMS.ASK_TOKENS), shown, callees, isCode }
}

/** What askNote stores of r's reply (text as the probe gives it: fixEscapedTicks applied) and the line a minute on. */
export function readR(model, sample, entry, noteAnswer, rText, team) {
  const { shown, callees, isCode } = rLine(model, sample, entry, noteAnswer, team)
  const stored = N.cut(isCode ? N.thinkCallKept(rText, callees, shown.text, shown.changes.map(one => one.diff)) : N.thinkKept(rText, false), 4000)
  const asks = [{ question: N.TRACE_LABEL, answer: stored, at: R_AT }]
  const think = N.openThink(asks, ASKED_AT, true, true)
  return { isCode, callees, stored, think, shown }
}

/** askNote for words typed under the open line (every text to the check while ON). */
export function checkLine(model, id, sample, entry, noteAnswer, stored, typed, team) {
  const note = { ...keptNote(model, sample, entry, noteAnswer, team), asks: [{ question: N.TRACE_LABEL, answer: stored, at: R_AT }] }
  const shown = shownOf(note, team)
  const masked = N.redactText(typed).text
  const think = N.openThink(shown.asks, ASKED_AT, true, true)
  if (!think) throw new Error(`${id}: line not open`)
  return line(id, model, N.THINK_SLOT_SYSTEM, N.thinkSlotCheckPrompt(shown, think, masked, LEVEL, N.thinkVariantOf(model)), NUMS.THINK_CHECK_TOKENS)
}

/** askNote for words typed when no line is open (a question: 1.7.0's request, think undefined). */
export function questionLine(model, id, sample, entry, noteAnswer, stored, typed, team) {
  const note = { ...keptNote(model, sample, entry, noteAnswer, team), asks: [{ question: N.TRACE_LABEL, answer: stored, at: R_AT }] }
  const shown = shownOf(note, team)
  const masked = N.redactText(typed).text
  const think = N.openThink(shown.asks, ASKED_AT, true, true)
  if (think) throw new Error(`${id}: a line is open`)
  return line(id, model, N.ASK_SYSTEM, N.askPrompt(shown, masked, LEVEL, team, undefined, true), NUMS.ASK_TOKENS)
}

/** What the check's reply shows the learner. */
export function readCheck(text, typed) {
  const masked = N.redactText(typed).text
  return N.cut(N.thinkSlotReply(text, masked) ?? N.slotFallback(text), 4000)
}

/** The head the learner sees on a shown check reply. */
export function headOf(shown) {
  return /^\*\*맞혔습니다\.\*\*/.test(shown) ? '맞음' : /^\*\*아쉽지만 틀렸습니다\.\*\*/.test(shown) ? '틀림' : '없음'
}

/** A frozen set: changes.json (+ group/lang as frozen) and the engine-shaped hunks.json, in order. */
export function samplesOf(dir) {
  const changes = readJson(`${dir}/changes.json`)
  const hunks = Object.fromEntries(readJson(`${dir}/hunks.json`).map(one => [one.id, one]))
  return changes.map(sample => ({ sample, entry: hunks[sample.id] }))
}
