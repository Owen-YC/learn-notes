"""learn-notes 1.12.0 G5 (batch 4): the measured round's blind label (G7 M-8; batch 1 audit lesson 1). One model is
measured (sonnet), so one label: a letter drawn at random from A and B (secrets.choice) when the r stage's replies are
saved and hashed, before any reply is opened. The pair file m/pair.json (label -> model) is written once, chmod 400,
and only its sha256 is printed and recorded (m/pair.sha256) until every verdict file of the round is frozen; reports,
verdict, tally and read files are named by the label, never the model. The GO pilot (records only, one model, B-12)
uses the fixed label X and no pair file.
  seal                -> m/pair.json (0400), m/pair.sha256, m/label.txt (the letter only)
  open                -> prints the pair (only after every verdict file is frozen: checks judge/m/out/*/verdict.json
                         are 0444 for a-<L>-J1/J2 and n-<L>-n1/n2-J1/J2)
usage: label.py seal | open"""
import hashlib, json, os, secrets, sys
S = os.environ.get("G5_ROOT", "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4")  # G5_ROOT: synthetic tests only
d = f"{S}/m"
mode = sys.argv[1]
if mode == "seal":
    if os.path.exists(f"{d}/pair.json"):
        sys.exit("refuse: m/pair.json exists")
    os.makedirs(d, exist_ok=True)
    label = secrets.choice(["A", "B"])
    body = json.dumps({label: "sonnet", "salt": secrets.token_hex(16)}) + "\n"
    open(f"{d}/pair.json", "w").write(body)
    os.chmod(f"{d}/pair.json", 0o400)
    h = hashlib.sha256(body.encode()).hexdigest()
    open(f"{d}/pair.sha256", "w").write(h + "\n")
    open(f"{d}/label.txt", "w").write(label + "\n")
    for n in ("pair.sha256", "label.txt"):
        os.chmod(f"{d}/{n}", 0o444)
    print(json.dumps({"label": label, "pairSha256": h}))
elif mode == "open":
    label = open(f"{d}/label.txt").read().strip()
    need = [f"a-{label}-J1", f"a-{label}-J2"] + [f"n-{label}-{r}-{j}" for r in ("n1", "n2") for j in ("J1", "J2")]
    missing = [n for n in need if not os.path.exists(f"{S}/judge/m/out/{n}/verdict.json") or oct(os.stat(f"{S}/judge/m/out/{n}/verdict.json").st_mode)[-3:] != "444"]
    tally_a = f"{d}/tally-a.json"
    if missing and os.path.exists(tally_a) and json.load(open(tally_a))["usable"] >= 10:
        sys.exit(f"refuse: verdict files not frozen: {missing}")
    os.chmod(f"{d}/pair.json", 0o444)
    body = open(f"{d}/pair.json").read()
    assert hashlib.sha256(body.encode()).hexdigest() == open(f"{d}/pair.sha256").read().strip()
    print(body)
else:
    sys.exit("usage: label.py seal | open")
