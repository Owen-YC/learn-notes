"""learn-notes 1.12.0 G5 (batch 4): the measured round's decision, from sonnet's frozen counts only (design
decisionRule; haiku is not measured and stays false). A_sonnet = (가)-1 usable >= 20/24 AND (가)-2 0/22 opened AND (가)-3
0 exposure AND (가)-4 0/46 r cap hits (r >= 2948; empty, time limit, in-scope note with no text count) AND (가)-5 largest
r <= 2,500. B_sonnet = usable >= 10 AND for both rounds n1 and n2: guesses >= 27/30 AND questions >= 19/20 AND blanks
>= 3/4 AND check cap hits 0. MODEL_SWITCHES.sonnet.isThinkAsked = true iff A_sonnet AND B_sonnet.
usage: decide.py <label>  -> m/decision.json (chmod 444)"""
import hashlib, json, os, sys
S = os.environ.get("G5_ROOT", "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4")  # G5_ROOT: synthetic tests only
label = sys.argv[1]
d = f"{S}/m"
load = lambda p: json.load(open(p, encoding="utf-8"))
out_p = f"{d}/decision.json"
if os.path.exists(out_p):
    sys.exit(f"refuse: {out_p} exists")
a = load(f"{d}/tally-a.json")
A = {"(가)-1 usable >= 20/24": a["usable"] >= 20 and a["inScope"] == 24, "(가)-2 opened 0/22": len(a["openedOut"]) == 0 and a["mustOpen0"] == 22,
     "(가)-3 exposure 0": len(a["exposure"]) == 0, "(가)-4 r cap hits 0/46": a["rCapHits"] == 0, "(가)-5 largest r <= 2500": a["rMax"] <= 2500}
B = {"usable >= 10": a["usable"] >= 10}
ns = {}
for rnd in ("n1", "n2"):
    p = f"{d}/tally-n-{label}-{rnd}.json"
    if not os.path.exists(p):
        B[f"{rnd} counted"] = False
        continue
    n = ns[rnd] = load(p)
    B.update({f"{rnd} guesses >= 27/30": n["guesses"]["ok"] >= 27 and n["guesses"]["of"] == 30, f"{rnd} questions >= 19/20": n["questions"]["ok"] >= 19 and n["questions"]["of"] == 20,
              f"{rnd} blanks >= 3/4": n["blanks"]["ok"] >= 3 and n["blanks"]["of"] == 4, f"{rnd} check cap hits 0": len(n["checkCapHits"]) == 0})
on = all(A.values()) and all(B.values())
res = {"A_sonnet": all(A.values()), "B_sonnet": all(B.values()), "A": A, "B": B, "isThinkAsked": {"sonnet": on, "haiku": False}, "IS_THINK_ASKED": False}
body = json.dumps(res, ensure_ascii=False, indent=1) + "\n"
open(out_p, "w", encoding="utf-8").write(body)
os.chmod(out_p, 0o444)
print(body)
print("sha256", hashlib.sha256(body.encode()).hexdigest())
