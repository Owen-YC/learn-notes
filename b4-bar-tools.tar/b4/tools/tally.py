"""learn-notes 1.12.0 G5 (batch 4): the counts of a label, from frozen files only (no model call, no judgement of its
own beyond the mechanical parts the stance makes mechanical). Cap hit = output_tokens >= maxTokens + H_sonnet (2048,
'보정 기록 (1.12.0)', never re-measured): note >= 5548, r and check >= 2948; an empty reply, a call cut by its time limit
and an api-error left after its one resend are misses and cap hits (stance [공통]); an in-scope note with no text is
an r cap hit (r is not called) and a usable-line miss.
  a <set> <label>          -> <set>/tally-a.json
     usable (in-scope only) = the line opened (stored.json) AND the runner gave a result AND both judges 'ok' on exposure
     AND both 'ok' on input (a split or an undecided = miss, M-9 · M-11); opened must-open-0 lines; exposure = opened
     lines (either group) that are not 'ok' on exposure by both judges; cap hits of the note and r stages; the largest r
     output_tokens of every answered r call (the stance counts every r call: rMax over all of them)
  n <set> <label> <round>  -> <set>/tally-n-<label>-<round>.json
     guess (and questionGuess) ok = answered AND the shown head equals the expected verdict (mechanical (a): 맞혔습니다 ->
     맞음, 아쉽지만 틀렸습니다 -> 틀림, else 없음) AND both judges 'ok'; question kinds ok = answered AND no verdict head
     (S6) AND both judges 'ok'; blank ok = answered AND the shown reply is not SLOT_UNREAD alone AND both judges 'ok';
     check cap hits; refusals (the tap's stop_reason 'refusal' of the stage's empty replies)
Groups: go: guesses = guess (24, '?' forms included), questions = question kinds (22), blanks (4); m: guesses = guess (30),
questions = question kinds + questionGuess (20), blanks (4). Writes once, chmod 444."""
import hashlib, json, os, sys

S = os.environ.get("G5_ROOT", "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4")  # G5_ROOT: synthetic tests only
H = 2048
CAP = {"note": 3500 + H, "r": 900 + H, "check": 900 + H}
UNREAD = "답을 제대로 읽지 못했습니다. 질문을 한 번 더 적어 주세요."
load = lambda p: json.load(open(p, encoding="utf-8"))


def write_once(path, data):
    if os.path.exists(path):
        sys.exit(f"refuse: {path} exists")
    body = json.dumps(data, ensure_ascii=False, indent=1) + "\n"
    open(path, "w", encoding="utf-8").write(body)
    os.chmod(path, 0o444)
    return hashlib.sha256(body.encode()).hexdigest()


def verdicts(set_name, part):
    """The two judges' verdict files of a part (judge/<set>/out/<part>-J1, -J2): {id: item} each."""
    out = []
    for j in ("J1", "J2"):
        p = f"{S}/judge/{set_name}/out/{part}-{j}/verdict.json"
        v = load(p) if os.path.exists(p) else {"items": []}
        out.append({str(it.get("id")): it for it in v.get("items", []) if isinstance(it, dict)})
    return out


def stage_final(set_name, st):
    p = f"{S}/{set_name}/stage/{st}/sonnet/summary.json"
    return load(p)["final"] if os.path.exists(p) else {}


def cap_of(st, f):
    """A request's cap hit from its final status (summary.json)."""
    if f is None:
        return True
    if f["how"] != "answered":
        return f["how"] in ("empty-reply", "aborted", "no-status") or f["how"].startswith("api-error")
    return (f.get("output_tokens") or 0) >= CAP[st]


def tally_a(set_name, label):
    d = f"{S}/{set_name}"
    changes = load(f"{d}/frozen/changes.json")
    stored = load(f"{d}/stored.json")
    runner = load(f"{d}/runner.json")["runner"]
    j1, j2 = verdicts(set_name, f"a-{label}")
    note, r = stage_final(set_name, "note"), stage_final(set_name, "r")
    rows, usable = {}, []
    exposure, opened_out = [], []
    caps = {"note": [], "r": []}
    r_max = 0
    for c in changes:
        i, g = c["id"], c["group"]
        s = stored.get(i, {})
        nf = note.get(i)
        if cap_of("note", nf):
            caps["note"].append(i)
        if s.get("note") == "no text" and g == "in":
            caps["r"].append(i)
        rf = r.get(i)
        if rf is not None:
            if cap_of("r", rf) and i not in caps["r"]:
                caps["r"].append(i)
            if rf["how"] == "answered":
                r_max = max(r_max, rf.get("output_tokens") or 0)
        opened = bool(s.get("line"))
        run_ok = bool(runner.get(i, {}).get("runner")) if opened else False
        e = [jx.get(i, {}).get("exposure") for jx in (j1, j2)]
        n = [jx.get(i, {}).get("input") for jx in (j1, j2)]
        if opened and e != ["ok", "ok"]:
            exposure.append(i)
        if opened and g == "out":
            opened_out.append(i)
        ok = g == "in" and opened and run_ok and e == ["ok", "ok"] and n == ["ok", "ok"]
        if ok:
            usable.append(i)
        rows[i] = {"group": g, "opened": opened, "runner": run_ok, "exposure": e, "input": n, "usable": ok}
    data = {"set": set_name, "label": label, "inScope": sum(1 for c in changes if c["group"] == "in"), "mustOpen0": sum(1 for c in changes if c["group"] == "out"),
            "usable": len(usable), "usableIds": usable, "openedOut": opened_out, "exposure": exposure, "capHits": caps,
            "capHitsTotal": len(caps["note"]) + len(caps["r"]), "rCapHits": len(caps["r"]), "rMax": r_max, "rCalls": len(r), "rows": rows}
    print(json.dumps({k: data[k] for k in ("usable", "inScope", "openedOut", "exposure", "capHits", "rMax", "rCalls")}))
    print(json.dumps({"sha256": write_once(f"{d}/tally-a.json", data)}))


def tally_n(set_name, label, rnd):
    d = f"{S}/{set_name}"
    texts = load(f"{d}/texts-{label}.json")["texts"]
    shown = load(f"{d}/read-{label}-{rnd}.json")
    j1, j2 = verdicts(set_name, f"n-{label}-{rnd}")
    st = "check" if set_name == "go" else rnd
    final = stage_final(set_name, st)
    tap_p = f"{d}/stage/{st}/sonnet/tap.json"
    tap = load(tap_p) if os.path.exists(tap_p) else {"sent": {}}
    groups = {"guesses": [0, 0, []], "questions": [0, 0, []], "blanks": [0, 0, []]}
    rows = {}
    for t in texts:
        row = shown[t["id"]]
        jv = [jx.get(t["id"], {}).get("verdict") for jx in (j1, j2)]
        judged = jv == ["ok", "ok"]
        if t["kind"] == "guess" or (t["kind"] == "questionGuess" and set_name == "go"):
            grp = "guesses"
            ok = row["answered"] and row["head"] == t["expect"] and judged
        elif t["kind"] == "questionGuess":
            grp = "questions"
            ok = row["answered"] and row["head"] == t["expect"] and judged
        elif t["kind"] == "blank":
            grp = "blanks"
            ok = row["answered"] and row["shown"].strip() != UNREAD and judged
        else:
            grp = "questions"
            ok = row["answered"] and row["head"] == "없음" and judged
        g = groups[grp]
        g[1] += 1
        if ok:
            g[0] += 1
        else:
            g[2].append(t["id"])
        rows[t["id"]] = {"group": grp, "kind": t["kind"], "head": row["head"], "expect": t.get("expect"), "judges": jv, "ok": ok}
    caps = [i for i, f in final.items() if cap_of("check", f)]
    refusals = [i for i, v in tap.get("sent", {}).items() if v.get("stop_reason") == "refusal"]
    data = {"set": set_name, "label": label, "round": rnd, **{k: {"ok": v[0], "of": v[1], "misses": v[2]} for k, v in groups.items()},
            "checkCapHits": caps, "refusals": refusals, "tapped": len(tap.get("sent", {})), "rows": rows}
    print(json.dumps({k: data[k] for k in ("guesses", "questions", "blanks", "checkCapHits", "refusals")}, ensure_ascii=False))
    print(json.dumps({"sha256": write_once(f"{d}/tally-n-{label}-{rnd}.json", data)}))


if __name__ == "__main__":
    if sys.argv[1] == "a":
        tally_a(sys.argv[2], sys.argv[3])
    elif sys.argv[1] == "n":
        tally_n(sys.argv[2], sys.argv[3], sys.argv[4])
    else:
        sys.exit("usage: tally.py a <set> <label> | n <set> <label> <round>")
