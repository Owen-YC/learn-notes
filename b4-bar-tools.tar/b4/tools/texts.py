"""learn-notes 1.12.0 G5 (batch 4), the (나) texts (no model call here; the writer and the label check are fresh
sub-agents run by gen/run.sh). From impl111/b7/tools/texts.py and pick.py (1.11.0), with the stance [(나)] first clause:
picking, the filter table and the label mending are 1.11.0's ('맞음 또는 거의' becomes '맞음': no '거의' verdict).
Sets: go (the GO pilot: every usable line in frozen order, at most 8; 50 texts) · m (the measured round: 10 questions,
js 5 (two-file js counts js) · ts 2 (ts+json and ts+ts count ts) · py 3 in frozen order of the usable lines, at least 3
whose runner result is an error, a guard value (null, None, false, False, an empty list, string or object), no change
or nothing returned: fewer -> replaced from the back by the same language's next edge line, then other languages; 54
texts). A slot's line k maps to line ((k - 1) mod u) + 1 when fewer lines than the layout's are usable.
  pick <set> <label>         -> <set>/questions-<label>.json  (from <set>/stored.json, runner.json, tally-a.json)
  prompt <set> <label>       -> gen/prompts/texts-<set>-<label>.md (judge/tpl-texts.md + per line: its question, the
                                walk-through as stored, the note, the right result, the slots to write)
  parse <set> <label>        -> <set>/texts-raw-<label>.json (exit 5 'WRITE texts-<set>-<label> 2' when unreadable or a
                                slot is missing on try 1; 6 STOP on try 2)
  filter <set> <label>       -> <set>/texts-filtered-<label>.json (the table, in its order, word for word, on question
                                kinds and on every guess written in a question mark form)
  labelprompt <set> <label>  -> gen/prompts/labelcheck-<set>-<label>.md (judge/tpl-labelcheck.md + the stance's [같음]
                                as frozen + every value guess (g1, g2, gq of a value form) with its question and result)
  apply <set> <label>        -> <set>/texts-<label>.json: value guesses: same -> expect 맞음, else 틀림 (a guess the check
                                left out keeps the writer's slot meaning: g1 맞음, g2 틀림); problem guesses (g3, gq of the
                                problem form): the stance's rule, 맞음 only when the runner result is an error, else 틀림
Kinds: guess (g1 · g2 · g3, and in go the '?' forms g2? · g3?), questionGuess (m: gq), blank (b), question (q · q2),
questionYesNo (y), questionNoMark (n). Every output chmod 444; refuses to overwrite."""
import hashlib, json, os, re, sys

S = os.environ.get("G5_ROOT", "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4")  # G5_ROOT: synthetic tests only
STANCE = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4/go/stance-G5.json"
TABLE = [("에러 나나요", "터지나요"), ("에러 나요", "터져요"), ("에러 나는", "터지는"), ("에러 날", "터질"), ("에러가 나요", "터져요"),
         ("에러가 나나요", "터지나요"), ("오류 나요", "터져요"), ("오류 나나요", "터지나요"), ("오류 나는", "터지는"),
         ("멈추나요", "서나요"), ("멈춰요", "서요")]
N_FORMS = {1: "`뭐가 달라요` 꼴", 2: "`어디서 값이 바뀌어요` 꼴", 3: "`여기가 헷갈려요` 꼴", 4: "`…설명해 주세요` 꼴", 5: "`왜 …` 꼴"}


def slots(set_name):
    """(line k, slot, kind, form) in writing order; the layout of the set (go: 8 lines, 50; m: 10 questions, 54)."""
    out = []
    if set_name == "go":
        for k in range(1, 9):
            out.append((k, "g1", "guess", None))
            out.append((k, "g2", "guess", "물음표 꼴" if k in (5, 7) else None))
            out.append((k, "g3", "guess", "물음표 꼴" if k in (1, 3) else None))
            if k % 2 == 0:
                out.append((k, "b", "blank", None))
            out.append((k, "q", "question", None))
            if k <= 4:
                out.append((k, "y", "questionYesNo", None))
            else:
                out.append((k, "n", "questionNoMark", N_FORMS[k - 4]))
            if k <= 6:
                out.append((k, "q2", "question", None))
        return out
    gq = {1: "문제 꼴", 3: "문제 꼴", 5: "문제 꼴", 7: "값에 물음표", 9: "값을 묻는 꼴"}
    for k in range(1, 11):
        out += [(k, "g1", "guess", None), (k, "g2", "guess", None), (k, "g3", "guess", None)]
        if k in (2, 4, 6, 8):
            out.append((k, "b", "blank", None))
        out.append((k, "y" if k in (1, 4, 7) else "q", "questionYesNo" if k in (1, 4, 7) else "question", None))
        if k in gq:
            out.append((k, "gq", "questionGuess", gq[k]))
        if k % 2 == 0:
            out.append((k, "n", "questionNoMark", N_FORMS[k // 2]))
    return out


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_once(path, data):
    if os.path.exists(path):
        sys.exit(f"refuse: {path} exists")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    body = data if isinstance(data, str) else json.dumps(data, ensure_ascii=False, indent=1) + "\n"
    open(path, "w", encoding="utf-8").write(body)
    os.chmod(path, 0o444)
    return sha(body)


def load(path):
    return json.load(open(path, encoding="utf-8"))


def is_edge(final):
    if final["kind"] in ("error", "none"):
        return True
    return final.get("value") in ("null", "None", "false", "False", "[]", "''", '""', "{}", "()")


def pick(set_name, label):
    d = f"{S}/{set_name}"
    stored, runner, tally = load(f"{d}/stored.json"), load(f"{d}/runner.json")["runner"], load(f"{d}/tally-a.json")
    usable = [i for i in stored if i in set(tally["usableIds"])]
    if set_name == "go":
        chosen = usable[:8]
    else:
        lang = lambda i: "ts" if stored[i]["lang"].split("+")[0] == "ts" else stored[i]["lang"].split("+")[0]
        want = {"js": 5, "ts": 2, "py": 3}
        picked = {k: [i for i in usable if lang(i) == k][:n] for k, n in want.items()}
        rest = {k: [i for i in usable if lang(i) == k][n:] for k, n in want.items()}
        edge = lambda i: is_edge(runner[i]["final"])
        count = lambda: sum(1 for k in picked for i in picked[k] if edge(i))
        for k in list(want) + list(want):
            while count() < 3:
                cand = [i for i in rest[k] if edge(i)]
                swap = [i for i in reversed(picked[k]) if not edge(i)]
                if not cand or not swap:
                    break
                picked[k][picked[k].index(swap[0])] = cand[0]
                rest[k].remove(cand[0])
        chosen = [i for i in usable if any(i in v for v in picked.values())]
    qs = []
    for n, i in enumerate(chosen, 1):
        s = stored[i]
        trace = "\n".join(l for l in s["stored"].split("\n") if not l.startswith("**생각해 보기:**")).rstrip()
        qs.append({"q": f"L{n}", "sid": i, "line": s["line"], "trace": trace, "note": s["noteText"], "result": runner[i]["final"]["text"], "resultKind": runner[i]["final"]["kind"], "edge": is_edge(runner[i]["final"])})
    print(json.dumps({"questions": len(qs), "ids": [q["sid"] for q in qs], "edge": sum(q["edge"] for q in qs), "sha256": write_once(f"{d}/questions-{label}.json", {"set": set_name, "label": label, "questions": qs})}))


def line_of(k, u):
    return ((k - 1) % u) + 1


def prompt(set_name, label):
    d = f"{S}/{set_name}"
    qs = load(f"{d}/questions-{label}.json")["questions"]
    u = len(qs)
    per = {}
    for k, slot, kind, form in slots(set_name):
        per.setdefault(line_of(k, u), []).append(f"{slot}" + (f"({form})" if form else ""))
    tpl = open(f"{S}/judge/tpl-texts.md", encoding="utf-8").read().rstrip()
    parts = [tpl, "", "## 물음"]
    for n, q in enumerate(qs, 1):
        dup = {}
        names = []
        for x in per[n]:
            base = x.split("(")[0]
            dup[base] = dup.get(base, 0) + 1
            names.append(x if dup[base] == 1 else x.replace(base, f"{base}-{dup[base]}", 1))
        parts += ["", f"### {q['q']}", "", f"생각해 보기 물음: {q['line']}", "", "따라가기 글:", "", "````", q["trace"], "````", "", "노트:", "", "````", q["note"], "````", "", f"바른 결과: {q['result']}", "", f"쓸 글: {' · '.join(names)}"]
    path = f"{S}/gen/prompts/texts-{set_name}-{label}.md"
    print(json.dumps({"prompt": path, "texts": sum(len(v) for v in per.values()), "sha256": write_once(path, "\n".join(parts) + "\n")}))


def expected_ids(set_name, u):
    ids, seen = [], {}
    for k, slot, kind, form in slots(set_name):
        n = line_of(k, u)
        seen[(n, slot)] = seen.get((n, slot), 0) + 1
        sid = slot if seen[(n, slot)] == 1 else f"{slot}-{seen[(n, slot)]}"
        ids.append((f"L{n}-{sid}", n, slot, kind, form))
    return ids


def parse(set_name, label):
    d = f"{S}/{set_name}"
    part = f"texts-{set_name}-{label}"
    tries = sorted(int(x[len(part):]) for x in os.listdir(f"{S}/gen/out") if x.startswith(part) and x[len(part):].isdigit())
    t = tries[-1]
    raw = open(f"{S}/gen/out/{part}{t}/result.txt", encoding="utf-8").read()
    qs = load(f"{d}/questions-{label}.json")["questions"]
    want = expected_ids(set_name, len(qs))
    got = None
    blocks = re.findall(r"```json\s*\n(.*?)\n```", raw, re.S)
    for cand in ([blocks[0]] if len(blocks) == 1 else []) + [raw]:
        try:
            v = json.loads(cand)
            if isinstance(v, dict) and isinstance(v.get("texts"), list):
                got = v["texts"]
                break
        except Exception:
            pass
    by = {}
    if got is not None:
        for x in got:
            if isinstance(x, dict) and isinstance(x.get("id"), str) and isinstance(x.get("text"), str) and x["text"].strip():
                by.setdefault(x["id"], x["text"].strip())
    missing = [w[0] for w in want if w[0] not in by]
    if got is None or missing:
        print(json.dumps({"missing": missing[:20], "unreadable": got is None}))
        print(f"WRITE {part} 2" if t == 1 else "STOP: texts unreadable on try 2")
        sys.exit(5 if t == 1 else 6)
    texts = []
    for i, n, slot, kind, form in want:
        texts.append({"id": i, "q": f"L{n}", "sid": qs[n - 1]["sid"], "slot": slot, "kind": kind, "form": form, "mark": "?" if form in ("물음표 꼴",) or kind == "questionGuess" else None, "text": by[i]})
    print(json.dumps({"texts": len(texts), "writer": f"{part}{t}", "sha256": write_once(f"{d}/texts-raw-{label}.json", {"set": set_name, "label": label, "writer": f"{part}{t}", "texts": texts})}))


def filtered(text):
    for old, new in TABLE:
        text = text.replace(old, new)
    return text


def filt(set_name, label):
    d = f"{S}/{set_name}"
    src = load(f"{d}/texts-raw-{label}.json")
    changes, texts = [], []
    for t in src["texts"]:
        if t["kind"].startswith("question") or t.get("mark") == "?":
            new = filtered(t["text"])
            if new != t["text"]:
                changes.append({"id": t["id"], "from": t["text"], "to": new})
            t = {**t, "text": new}
        texts.append(t)
    left = [t["id"] for t in texts if (t["kind"].startswith("question") or t.get("mark") == "?") and re.search(r"에러|오류|멈추|멈춰", t["text"])]
    print(json.dumps({"filtered": len(changes), "leftAsWritten": left, "sha256": write_once(f"{d}/texts-filtered-{label}.json", {**src, "texts": texts, "filterChanges": changes, "leftAsWritten": left})}, ensure_ascii=False))


def is_value_guess(t):
    return t["slot"] in ("g1", "g2") or (t["slot"] == "gq" and t["form"] != "문제 꼴")


def labelprompt(set_name, label):
    d = f"{S}/{set_name}"
    qs = {q["q"]: q for q in load(f"{d}/questions-{label}.json")["questions"]}
    texts = load(f"{d}/texts-filtered-{label}.json")["texts"]
    same = "\n".join(f"- {c}" for c in load(STANCE)["같음"])
    parts = [open(f"{S}/judge/tpl-labelcheck.md", encoding="utf-8").read().rstrip(), "", "## [같음]", "", same, "", "## 짐작"]
    for t in texts:
        if is_value_guess(t):
            q = qs[t["q"]]
            parts += ["", f"### {t['id']}", f"물음: {q['line']}", f"바른 결과: {q['result']}", f"짐작: {t['text']}"]
    path = f"{S}/gen/prompts/labelcheck-{set_name}-{label}.md"
    print(json.dumps({"prompt": path, "sha256": write_once(path, "\n".join(parts) + "\n")}))


def apply(set_name, label):
    d = f"{S}/{set_name}"
    qs = {q["q"]: q for q in load(f"{d}/questions-{label}.json")["questions"]}
    texts = load(f"{d}/texts-filtered-{label}.json")["texts"]
    part = f"labelcheck-{set_name}-{label}"
    tries = sorted(int(x[len(part):]) for x in os.listdir(f"{S}/gen/out") if x.startswith(part) and x[len(part):].isdigit())
    raw = open(f"{S}/gen/out/{part}{tries[-1]}/result.txt", encoding="utf-8").read()
    check = None
    for cand in re.findall(r"```json\s*\n(.*?)\n```", raw, re.S) + [raw]:
        try:
            check = json.loads(cand)
            break
        except Exception:
            pass
    items = check if isinstance(check, list) else (check or {}).get("items", []) if isinstance(check, dict) else []
    by = {str(c.get("id")): c for c in items if isinstance(c, dict)}
    out, mended, missing = [], [], []
    for t in texts:
        if t["kind"] in ("guess", "questionGuess"):
            if is_value_guess(t):
                c = by.get(t["id"])
                if c is None or not isinstance(c.get("same"), bool):
                    missing.append(t["id"])
                    expect = "맞음" if t["slot"] == "g1" else "틀림" if t["slot"] == "g2" else None
                else:
                    expect = "맞음" if c["same"] else "틀림"
                how = "labelcheck"
            else:
                expect = "맞음" if qs[t["q"]]["resultKind"] == "error" else "틀림"
                how = "runner rule"
            writer = "맞음" if t["slot"] == "g1" else "틀림" if t["slot"] == "g2" else None
            if writer is not None and writer != expect:
                mended.append({"id": t["id"], "from": writer, "to": expect})
            t = {**t, "expect": expect, "expectBy": how}
        else:
            t = {**t, "expect": None}
        out.append(t)
    print(json.dumps({"mended": mended, "checkLeftOut": missing, "sha256": write_once(f"{d}/texts-{label}.json", {"set": set_name, "label": label, "texts": out, "labelMended": mended, "checkLeftOut": missing, "labelcheck": f"{part}{tries[-1]}"})}, ensure_ascii=False))


if __name__ == "__main__":
    mode, set_name, label = sys.argv[1:4]
    {"pick": pick, "prompt": prompt, "parse": parse, "filter": filt, "labelprompt": labelprompt, "apply": apply}[mode](set_name, label)
