"""learn-notes 1.12.0 G5 (batch 4): the judges' reports and runs (stance [공통]: per label two sub-agents that get only
the stance text and the report, never each other's verdict, never the model's name; a split is a miss; a case the
stance does not decide is a miss). The stance is the frozen text go/stance-G5.json (sha256 ef1b377a…631e, the design's
stance as committed in 9f0dff1), rendered whole into every report, section by section, word for word.
  report-a <set> <label>          -> judge/<set>/report-a-<label>.md   every opened line (in-scope and must-open-0) with
                                     the line, the walk-through as stored, the anchor r was told (or none), the note text,
                                     the '## 바뀐 코드' diffs and the runner's call and result; the judge marks (4)
                                     exposure and (5) input for each, citing clauses
  report-n <set> <label> <round>  -> judge/<set>/report-n-<label>-<round>.md   every text with its kind, its expected
                                     verdict (guesses), the line, the runner result, the code, the learner's words and
                                     the shown reply; the judge marks each item ok / miss / undecided, citing clauses
  run <report.md> <judge name>    -> judge/<set>/out/<judge name>/ (prompt, result.txt, verdict.json): one fresh
                                     `claude -p --model opus --tools ''` in an empty dir through the pinned CLI; a reply
                                     with no readable JSON of the asked shape is asked once more in a new session with the
                                     same prompt (a judge tool's failure, not a re-grade: nothing was read); a second
                                     failure leaves every item undecided (= miss)
Every output chmod 444; refuses to overwrite."""
import hashlib, json, os, re, subprocess, sys

S = os.environ.get("G5_ROOT", "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4")  # G5_ROOT: synthetic tests only
STANCE = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4/go/stance-G5.json"
STANCE_SHA = "ef1b377a4f16455a0380c2604420f89c80836d974f29bf7561228c653a2c631e"
P = os.environ.get("PINNED", "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh")
KIND_KO = {"guess": "짐작", "questionGuess": "물음표 짐작", "blank": "모르겠어요", "question": "질문", "questionYesNo": "질문(예/아니요로 성질을 물음)", "questionNoMark": "질문(물음표 없음)"}


def sha(b):
    return hashlib.sha256(b if isinstance(b, bytes) else b.encode("utf-8")).hexdigest()


def write_once(path, text):
    if os.path.exists(path):
        sys.exit(f"refuse: {path} exists")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w", encoding="utf-8").write(text)
    os.chmod(path, 0o444)
    return sha(text)


def stance_text():
    raw = open(STANCE, "rb").read()
    if sha(raw) != STANCE_SHA:
        sys.exit("the stance file is not the frozen one")
    st = json.loads(raw)
    out = []
    for k, v in st.items():
        out += ["", f"### [{k}]", ""]
        out += [f"- {x}" for x in v] if isinstance(v, list) else [v]
    return "\n".join(out).strip()


def load(p):
    return json.load(open(p, encoding="utf-8"))


def fence(text):
    return "````\n" + text + "\n````"


def report_a(set_name, label):
    d = f"{S}/{set_name}"
    stored, runner = load(f"{d}/stored.json"), load(f"{d}/runner.json")["runner"]
    items = []
    for i, s in stored.items():
        if not s.get("line"):
            continue
        r = runner.get(i)
        res = (r["final"]["text"] if r and r["runner"] else "러너 결과 없음") if r else "러너 결과 없음"
        diffs = "\n\n".join(f"{c['file']} ({c['kind']})\n{c['diff']}" for c in s["changes"])
        items += [f"### {i}", "", f"- 줄(열린 생각해 보기): {s['line']}", f"- r이 따르라고 받은 앵커 호출: {('`' + s['anchor'] + '`') if s.get('anchor') else '없음'}",
                  f"- 러너가 돌린 호출: `{r['call'] if r else ''}` → 최종 결과: {res}", "", "따라가기 글(저장된 그대로, 마지막 줄이 위의 줄):", "", fence(s["stored"]), "", "노트 글:", "", fence(s["noteText"]), "", "## 바뀐 코드:", "", fence(diffs), ""]
    head = f"""# (가) 판정 (꼬리표 {label})

당신은 한 꼬리표의 (가) 보고서를 매기는 채점자입니다. 아래 '입장'의 글자만 따르고, 보고서 밖의 것을 짐작하지 않습니다. 코드를 돌리지 않습니다. 바른 결과는 보고서에 적힌 러너 결과입니다.

열린 줄마다 두 가지를 매깁니다.
- exposure: 입장 [(가)]의 노출(i)~(iv)과 S10에 따라 노출이 없으면 "ok", 있으면 "miss", 입장으로 정해지지 않으면 "undecided".
- input: 입장 S7에 따라 줄의 호출이 따라가기의 예시 호출과 인자 묶음이 다르면 "ok", 같으면 "miss", 정해지지 않으면 "undecided".
항목마다 근거 조항(예: "[(가)] 노출 (i)", "S7", "S10")과 한두 문장의 까닭을 적습니다.

## 입장

{stance_text()}

## 보고서 ({sum(1 for s in stored.values() if s.get('line'))}줄)
"""
    tail = """
## 답의 꼴

```json 울타리 안에 이 꼴의 JSON 하나만 적으세요. 다른 말은 쓰지 않습니다. 보고서의 줄마다 항목 하나씩입니다.

{"items": [{"id": "…", "exposure": "ok", "input": "ok", "clauses": ["…"], "why": "…"}]}
"""
    path = f"{S}/judge/{set_name}/report-a-{label}.md"
    print(json.dumps({"report": path, "items": sum(1 for s in stored.values() if s.get("line")), "sha256": write_once(path, head + "\n" + "\n".join(items) + tail)}))


def report_n(set_name, label, rnd):
    d = f"{S}/{set_name}"
    qs = {q["q"]: q for q in load(f"{d}/questions-{label}.json")["questions"]}
    stored = load(f"{d}/stored.json")
    texts = load(f"{d}/texts-{label}.json")["texts"]
    shown = load(f"{d}/read-{label}-{rnd}.json")
    parts = []
    for qn, q in qs.items():
        s = stored[q["sid"]]
        diffs = "\n\n".join(f"{c['file']} ({c['kind']})\n{c['diff']}" for c in s["changes"])
        parts += [f"## {qn}", "", f"- 생각해 보기 물음: {q['line']}", f"- 러너 결과(바른 결과): {q['result']}", "", "## 바뀐 코드:", "", fence(diffs), ""]
        for t in texts:
            if t["q"] != qn:
                continue
            row = shown[t["id"]]
            kind = KIND_KO[t["kind"]] + (" (물음표 꼴)" if t.get("mark") == "?" and t["kind"] == "guess" else "")
            parts += [f"### {t['id']}", "", f"- 종류: {kind}" + (f", 기대 판정: {t['expect']}" if t.get("expect") else ""), f"- 학습자의 글: {t['text']}", "- 보인 글:", "",
                      fence(row["shown"]) if row["answered"] else "(답 없음: 빈 답 · 시간 한도 · 전송 실패, 입장 [공통]대로 놓침)", ""]
    head = f"""# (나) 판정 (꼬리표 {label}, 회 {rnd})

당신은 한 꼬리표의 (나) 한 회 보고서를 매기는 채점자입니다. 아래 '입장'의 글자만 따르고, 보고서 밖의 것을 짐작하지 않습니다. 코드를 돌리지 않습니다. 바른 결과는 보고서에 적힌 러너 결과입니다(돌려주는 값은 그 값, 오류로 끝남은 그 오류).

글마다 입장 [(나)]의 그 종류 기준(짐작 (a)~(g), 모르겠어요, 질문 (a)~(c), 물음표 짐작은 짐작 (a) · (b) · (f) · (g))을 모두 보고, 모두 만족하면 "ok", 하나라도 어기면 "miss", 입장으로 정해지지 않으면 "undecided"를 적습니다. 어긴 기준(예: "(b)")과 근거 조항, 한두 문장의 까닭을 적습니다. 짐작의 (a)는 보인 머리와 보고서의 기대 판정을 견줍니다.

## 입장

{stance_text()}

# 보고서 ({len(texts)}글)
"""
    tail = """
## 답의 꼴

```json 울타리 안에 이 꼴의 JSON 하나만 적으세요. 다른 말은 쓰지 않습니다. 보고서의 글마다 항목 하나씩입니다.

{"items": [{"id": "…", "verdict": "ok", "failed": [], "clauses": ["…"], "why": "…"}]}
"""
    path = f"{S}/judge/{set_name}/report-n-{label}-{rnd}.md"
    print(json.dumps({"report": path, "items": len(texts), "sha256": write_once(path, head + "\n" + "\n".join(parts) + tail)}))


def read_items(text):
    for cand in re.findall(r"```json\s*\n(.*?)\n```", text, re.S) + [text]:
        try:
            v = json.loads(cand)
        except Exception:
            continue
        if isinstance(v, dict) and isinstance(v.get("items"), list):
            return v["items"]
    return None


def run(report, name):
    set_dir = os.path.dirname(report)
    o = f"{set_dir}/out/{name}"
    if os.path.exists(o):
        sys.exit(f"refuse: {o} exists")
    os.makedirs(o)
    work = f"{S}/work/judge-{os.path.basename(set_dir)}-{name}"
    os.makedirs(work, exist_ok=True)
    prompt = open(report, encoding="utf-8").read()
    open(f"{o}/prompt.md", "w", encoding="utf-8").write(prompt)
    items, tries = None, []
    for t in (1, 2):
        with open(f"{o}/prompt.md", "rb") as stdin:
            p = subprocess.run([P, "bash", "-c", 'timeout 3000 claude -p --model opus --tools "" --output-format json'], cwd=work, stdin=stdin, capture_output=True, timeout=3200)
        open(f"{o}/out-{t}.json", "wb").write(p.stdout)
        try:
            d = json.loads(p.stdout)
        except Exception:
            d = {"result": ""}
        res = d.get("result") or ""
        open(f"{o}/result-{t}.txt", "w", encoding="utf-8").write(res)
        tries.append({"try": t, "exit": p.returncode, "opus": any("opus" in k for k in (d.get("modelUsage") or {}))})
        items = read_items(res)
        if items is not None:
            break
    verdict = {"report": report, "reportSha256": sha(prompt), "judge": name, "tries": tries, "readable": items is not None, "items": items or []}
    body = json.dumps(verdict, ensure_ascii=False, indent=1) + "\n"
    open(f"{o}/verdict.json", "w", encoding="utf-8").write(body)
    for f in os.listdir(o):
        os.chmod(f"{o}/{f}", 0o444)
    print(json.dumps({"judge": name, "readable": items is not None, "items": len(items or []), "tries": len(tries), "sha256": sha(body)}))


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "report-a":
        report_a(sys.argv[2], sys.argv[3])
    elif mode == "report-n":
        report_n(sys.argv[2], sys.argv[3], sys.argv[4])
    elif mode == "run":
        run(sys.argv[2], sys.argv[3])
    else:
        sys.exit("usage: judge.py report-a <set> <label> | report-n <set> <label> <round> | run <report.md> <judge name>")
