"""learn-notes 1.12.0 G5 (batch 4): the pre-bar GO verdict, mechanically from the GO pilot's frozen counts (records only,
B-12; the rule as the build commit 9f0dff1 wrote it into 견본.md '기준 전 GO 관문', from plan batches[4].preBarGate.go):
GO iff (가) usable >= 7 of 8 in scope, 0 of 4 must-open-0 lines opened, 0 exposure, 0 cap hits (note and r, the strict
reading fixed in 9f0dff1: note >= 5548, r >= 2948, empty / time limit / no text as cap hits), largest r output_tokens
<= 2,300; and (나) guesses >= 23/24, questions >= 21/22, blanks >= 3/4, 0 check cap hits, 0 refusals (the tap's
refusals of every GO stage: note, r and check). The model record before and after each stage must equal batch 0
(stage.sh: a stage that is not DONE has no GO verdict). If (가) already fails, (나) is not run (it cannot change NO-GO)
and the verdict is NO-GO with (나) 'not run'.
usage: go.py <label>  -> go/go.json (chmod 444)"""
import hashlib, json, os, sys
S = os.environ.get("G5_ROOT", "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4")  # G5_ROOT: synthetic tests only
label = sys.argv[1]
d = f"{S}/go"
load = lambda p: json.load(open(p, encoding="utf-8"))
out_p = f"{d}/go.json"
if os.path.exists(out_p):
    sys.exit(f"refuse: {out_p} exists")
a = load(f"{d}/tally-a.json")
lines = {
    "(가) usable >= 7/8": a["usable"] >= 7 and a["inScope"] == 8,
    "(가) opened must-open-0 = 0/4": len(a["openedOut"]) == 0 and a["mustOpen0"] == 4,
    "(가) exposure = 0": len(a["exposure"]) == 0,
    "(가) cap hits = 0 (note + r)": a["capHitsTotal"] == 0,
    "(가) largest r <= 2300": a["rMax"] <= 2300,
}
refusals = {}
for st in ("note", "r", "check"):
    p = f"{d}/stage/{st}/sonnet/tap.json"
    if os.path.exists(p):
        refusals[st] = [i for i, v in load(p).get("sent", {}).items() if v.get("stop_reason") == "refusal"]
    done = os.path.exists(f"{d}/stage/{st}/sonnet/DONE")
    if st != "check" and not done:
        sys.exit(f"no GO verdict: stage {st} is not DONE")
a_pass = all(lines.values())
n = None
if a_pass:
    if not os.path.exists(f"{d}/stage/check/sonnet/DONE"):
        sys.exit("no GO verdict: stage check is not DONE")
    n = load(f"{d}/tally-n-{label}-n1.json")
    lines.update({
        "(나) guesses >= 23/24": n["guesses"]["ok"] >= 23 and n["guesses"]["of"] == 24,
        "(나) questions >= 21/22": n["questions"]["ok"] >= 21 and n["questions"]["of"] == 22,
        "(나) blanks >= 3/4": n["blanks"]["ok"] >= 3 and n["blanks"]["of"] == 4,
        "(나) check cap hits = 0": len(n["checkCapHits"]) == 0,
    })
lines["refusals = 0 (note, r, check)"] = sum(len(v) for v in refusals.values()) == 0
go = a_pass and all(lines.values())
res = {"verdict": "GO" if go else "NO-GO", "lines": lines, "a": {k: a[k] for k in ("usable", "inScope", "openedOut", "mustOpen0", "exposure", "capHits", "rMax")},
       "n": None if n is None else {k: n[k] for k in ("guesses", "questions", "blanks", "checkCapHits")}, "nRun": n is not None, "refusals": refusals}
body = json.dumps(res, ensure_ascii=False, indent=1) + "\n"
open(out_p, "w", encoding="utf-8").write(body)
os.chmod(out_p, 0o444)
print(body)
print("sha256", hashlib.sha256(body.encode()).hexdigest())
