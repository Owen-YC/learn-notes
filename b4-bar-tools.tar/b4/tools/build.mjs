// learn-notes 1.12.0 G5 (batch 4): the request lines of each call kind and the readings of the replies, for one frozen
// set (the GO pilot's go/frozen or the measured round's), through tools/kit.mjs (the build commit's notes.ts). No model
// call. Every output is written once (refuses to overwrite) and chmod 444.
//   note   <set dir> <model> <out.jsonl>                               writeNote's call per change (no team file)
//   r      <set dir> <model> <note out.json> <out.jsonl>               r's key per change whose note has text, in set
//                                                                      order; the rest listed (an in-scope one is a
//                                                                      (가)-1 miss and an r cap hit; must-open-0: no r)
//   stored <set dir> <model> <note out.json> <r out.json> <out.json>   per change: what askNote stores of r's reply and
//                                                                      the line openThink opens a minute on, the kept
//                                                                      note's text and changes (for the runner and the
//                                                                      judges); no reply text beyond what the plugin keeps
//   check  <set dir> <model> <note out.json> <stored.json> <texts.json> <out.jsonl> <out meta.json>
//                                                                      one check line per text (texts.json from texts.py:
//                                                                      { texts: [{ id, sid, text, kind, … }] }), the
//                                                                      typed words as the filter table left them
//   read   <check out.json> <meta.json> <out.json>                     the shown reply of each check (thinkSlotReply ??
//                                                                      slotFallback, cut 4000) and its head
import { existsSync, mkdirSync, writeFileSync, chmodSync } from 'node:fs'
import { dirname } from 'node:path'
import * as K from './kit.mjs'

function writeOnce(path, text) {
  if (existsSync(path)) throw new Error(`refuse: ${path} exists`)
  mkdirSync(dirname(path), { recursive: true })
  writeFileSync(path, text)
  chmodSync(path, 0o444)
  return K.sha(text)
}
const jsonl = lines => lines.map(l => JSON.stringify(l)).join('\n') + '\n'
const outOf = path => Object.fromEntries(K.readJson(path).results.map(r => [r.id, r]))
const hasText = o => o?.isAnswered === true && typeof o.text === 'string' && o.text.trim() !== ''

const [mode, ...a] = process.argv.slice(2)
if (mode === 'note') {
  const [dir, model, out] = a
  const lines = K.samplesOf(dir).map(({ sample, entry }) => K.noteLine(model, sample, entry))
  console.log(JSON.stringify({ lines: lines.length, sha256: writeOnce(out, jsonl(lines)) }))
} else if (mode === 'r') {
  const [dir, model, noteOut, out] = a
  const notes = outOf(noteOut)
  const lines = []
  const left = []
  const kinds = {}
  for (const { sample, entry } of K.samplesOf(dir)) {
    if (!hasText(notes[sample.id])) {
      left.push(sample.id)
      continue
    }
    const r = K.rLine(model, sample, entry, notes[sample.id].text)
    const kind = r.isCode ? (r.callees.some(c => c.anchor) ? 'anchor' : 'noanchor') : 'out'
    kinds[kind] = (kinds[kind] ?? 0) + 1
    const q = /## 학습자의 질문\n([\s\S]*?)\n\n## /.exec(r.line.prompt)?.[1] ?? ''
    if (q.endsWith('…')) throw new Error(`${sample.id}: r question cut at 1000`)
    lines.push(r.line)
  }
  console.log(JSON.stringify({ lines: lines.length, kinds, noText: left, sha256: writeOnce(out, jsonl(lines)) }))
} else if (mode === 'stored') {
  const [dir, model, noteOut, rOut, out] = a
  const notes = outOf(noteOut)
  const rs = outOf(rOut)
  const res = {}
  for (const { sample, entry } of K.samplesOf(dir)) {
    const n = notes[sample.id]
    const r = rs[sample.id]
    const base = { group: sample.group, lang: sample.lang, edge: sample.edge ?? null }
    if (!hasText(n)) {
      res[sample.id] = { ...base, note: 'no text', line: null }
      continue
    }
    if (!r?.isAnswered) {
      // askNote returns an error: nothing stored, nothing opens.
      res[sample.id] = { ...base, note: 'text', r: r ? r.reason ?? 'threw' : 'not called', line: null }
      continue
    }
    const got = K.readR(model, sample, entry, n.text, r.text)
    const name = got.think ? /`([A-Za-z_$][\w$]*)\s*\(/.exec(got.think.question)?.[1] : undefined
    const anchor = got.callees.find(c => c.anchor)?.anchor ?? null
    const example = /^\s*(?:[-*+•]\s+)?\**예시 호출\**\s*:\s*\**\s*`([^`\n]+)`/m.exec(got.stored)?.[1] ?? null
    res[sample.id] = {
      ...base,
      note: 'text',
      r: 'answered',
      isCode: got.isCode,
      callees: got.callees,
      line: got.think?.question ?? null,
      calleeFile: name ? got.callees.find(c => c.name === name)?.file ?? null : null,
      exampleCall: example,
      anchor,
      stored: got.stored,
      noteText: got.shown.text,
      changes: got.shown.changes.map(c => ({ file: c.file, kind: c.kind, diff: c.diff })),
    }
  }
  const opened = Object.entries(res).filter(([, v]) => v.line).map(([k]) => k)
  console.log(JSON.stringify({ changes: Object.keys(res).length, opened, sha256: writeOnce(out, JSON.stringify(res, null, 1) + '\n') }))
} else if (mode === 'check') {
  const [dir, model, noteOut, storedPath, textsPath, out, metaOut] = a
  const notes = outOf(noteOut)
  const stored = K.readJson(storedPath)
  const texts = K.readJson(textsPath).texts
  const byId = Object.fromEntries(K.samplesOf(dir).map(one => [one.sample.id, one]))
  const lines = []
  const meta = { lines: {} }
  for (const t of texts) {
    const { sample, entry } = byId[t.sid]
    if (!stored[t.sid]?.line) throw new Error(`${t.id}: no open line under ${t.sid}`)
    const l = K.checkLine(model, t.id, sample, entry, notes[t.sid].text, stored[t.sid].stored, t.text)
    if (!l.prompt.includes(stored[t.sid].line)) throw new Error(`${t.id}: the check does not carry the line`)
    lines.push(l)
    meta.lines[t.id] = { sid: t.sid, typed: t.text }
  }
  const sha = writeOnce(out, jsonl(lines))
  console.log(JSON.stringify({ lines: lines.length, sha256: sha, metaSha256: writeOnce(metaOut, JSON.stringify(meta, null, 1) + '\n') }))
} else if (mode === 'read') {
  const [checkOut, metaPath, out] = a
  const res = outOf(checkOut)
  const meta = K.readJson(metaPath).lines
  const rows = {}
  for (const [id, m] of Object.entries(meta)) {
    const r = res[id]
    if (!r?.isAnswered) {
      rows[id] = { answered: false, reason: r ? r.reason ?? 'threw' : 'no status', shown: null, head: null }
      continue
    }
    const shown = K.readCheck(r.text, m.typed)
    rows[id] = { answered: true, shown, head: K.headOf(shown) }
  }
  console.log(JSON.stringify({ rows: Object.keys(rows).length, sha256: writeOnce(out, JSON.stringify(rows, null, 1) + '\n') }))
} else {
  console.error('usage: build.mjs note|r|stored|check|read …')
  process.exit(2)
}
