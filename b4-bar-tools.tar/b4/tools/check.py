"""learn-notes 1.12.0 G5 (batch 4): the freeze step of a change set (no model call), before any call of that set.
usage: check.py <gate|A> <frozen dir>
Reads the latest writer try gen/out/<part><try>/result.txt (exactly one ```json fenced block, else the whole reply, as
one JSON array), never edits a scene, and writes into <frozen dir> (refuses an existing changes.json): raw.json (the
reply as read), changes.json (the scenes as written, in id order), hunks.json (tools/prep.py: the engine-shaped hunks,
impl111 prep rule), check.json (shape, layout and name checks; composition counts), NAMES.txt (ids, file names and the
defined function / class names, for design/G5/dev/NAMES.txt and impl112/NAMES-all.txt), all chmod 444.
Shape (a failing scene is not mended; the set is not frozen): ids exactly the layout's, in order; group and lang the
layout's for each id; files a non-empty list of {path (relative, no '..'), before (string or null), after (string)};
each file text ends with one newline; request and answer non-empty strings; edge a boolean.
Names: each file name (last path part) and each defined function / class name (js `function f`, `const f = (…) =>` /
`function`, `class C`; py `def f`, `class C`) against the writer's own avoid list (gen/out/<part><try>/avoid-names.txt).
Composition (writer's layout; recorded, never mended; the in-scope group is not filtered by the plugin's code):
new files and edits, scenes whose after-file calls a defined function at the top level with literal-looking arguments
(a line at column 0 holding `name(` of a function the same scene defines, inside console.log/print or bare), edge count.
Exit 0 frozen; 5 'WRITE <part> 2' (no readable JSON array: try 2 sends the same prompt once more); 6 STOP (try 2 also
unreadable, a shape failure, or for part A a name overlap: nothing frozen; the gate's dev set records overlaps only)."""
import hashlib, json, os, re, subprocess, sys

S = os.environ.get("G5_ROOT", "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4")  # G5_ROOT: synthetic tests only
LAYOUT = {
    "gate": [("PG01", "in", "js"), ("PG02", "in", "js"), ("PG03", "in", "ts"), ("PG04", "in", "ts"), ("PG05", "in", "py"),
             ("PG06", "in", "py"), ("PG07", "in", "js+js"), ("PG08", "in", "py+md"), ("PG09", "out", "py"), ("PG10", "out", "js"),
             ("PG11", "out", "ts"), ("PG12", "out", "js")],
    "A": [(f"GM{i:02d}", "in", l) for i, l in enumerate(["js"] * 7 + ["ts"] * 5 + ["py"] * 6 + ["js+js", "ts+ts", "py+py", "js+css", "ts+json", "py+md"], 1)]
    + [(f"GM{i:02d}", "out", None) for i in range(25, 34)]
    + [(f"GM{i:02d}", "out", l) for i, l in zip(range(34, 47), ["go", "rb", "sh", "vue", "js", "jsx", "tsx", "js+css", "py", "js", "ts", "js", "js"])],
}
JS_DEF = re.compile(r"\bfunction\s*\*?\s*([A-Za-z_$][\w$]*)|\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*(?::[^=]+)?=\s*(?:async\s+)?(?:function\b|\([^)]*\)\s*(?::[^=]+)?=>|[A-Za-z_$][\w$]*\s*=>)|\bclass\s+([A-Za-z_$][\w$]*)")
PY_DEF = re.compile(r"^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)|^\s*class\s+([A-Za-z_]\w*)", re.M)
sha = lambda t: hashlib.sha256(t.encode("utf-8")).hexdigest()


def read_reply(text):
    blocks = re.findall(r"```json\s*\n(.*?)\n```", text, re.S)
    for cand in ([blocks[0]] if len(blocks) == 1 else []) + [text]:
        try:
            v = json.loads(cand)
            if isinstance(v, list):
                return v
        except Exception:
            pass
    return None


def defs(scene):
    out = set()
    for f in scene["files"]:
        t = f.get("after") or ""
        if f["path"].endswith(".py"):
            out |= {a or b for a, b in PY_DEF.findall(t)}
        elif re.search(r"\.(m?[jt]sx?|c[jt]s|vue)$", f["path"]):
            out |= {next(g for g in m if g) for m in JS_DEF.findall(t)}
    return sorted(out)


def top_call(scene, names):
    for f in scene["files"]:
        for line in (f.get("after") or "").split("\n"):
            if line[:1].strip() and any(re.search(rf"(?<![\w$.]){re.escape(n)}\s*\(", line) for n in names) and not re.match(r"^(?:export\s+)?(?:async\s+)?(?:function|def|class|const\s+\w+\s*=\s*(?:\(|function))", line):
                return True
    return False


def main(part, frozen):
    tries = sorted(int(d[len(part):]) for d in os.listdir(f"{S}/gen/out") if d.startswith(part) and d[len(part):].isdigit())
    if not tries:
        sys.exit("no writer reply")
    t = tries[-1]
    o = f"{S}/gen/out/{part}{t}"
    if os.path.exists(f"{frozen}/changes.json"):
        sys.exit(f"refuse: {frozen}/changes.json exists")
    scenes = read_reply(open(f"{o}/result.txt", encoding="utf-8").read())
    if scenes is None:
        print(f"WRITE {part} 2" if t == 1 else f"STOP: try {t} unreadable")
        sys.exit(5 if t == 1 else 6)
    lay = LAYOUT[part]
    bad = []
    if [s.get("id") for s in scenes] != [x[0] for x in lay]:
        bad.append(f"ids {[s.get('id') for s in scenes]}")
    for s, (i, g, l) in zip(scenes, lay):
        if s.get("group") != g:
            bad.append(f"{i} group {s.get('group')}")
        if l is not None and s.get("lang") != l:
            bad.append(f"{i} lang {s.get('lang')}")
        if not isinstance(s.get("edge"), bool):
            bad.append(f"{i} edge")
        for k in ("request", "answer"):
            if not isinstance(s.get(k), str) or not s[k].strip():
                bad.append(f"{i} {k}")
        fs = s.get("files")
        if not isinstance(fs, list) or not fs:
            bad.append(f"{i} files")
            continue
        for f in fs:
            p = f.get("path") if isinstance(f, dict) else None
            if not isinstance(p, str) or p.startswith("/") or ".." in p.split("/"):
                bad.append(f"{i} path {p}")
                continue
            if not isinstance(f.get("after"), str) or not f["after"].endswith("\n") or f["after"].endswith("\n\n"):
                bad.append(f"{i} {p} after end")
            if f.get("before") is not None and (not isinstance(f["before"], str) or not f["before"].endswith("\n")):
                bad.append(f"{i} {p} before end")
            if f.get("before") is not None and f["before"] == f["after"]:
                bad.append(f"{i} {p} unchanged")
    avoid = set(l.strip() for l in open(f"{o}/avoid-names.txt", encoding="utf-8") if l.strip() and not l.startswith("#"))
    rows, overlap, comp = [], [], {"new": 0, "edit": 0, "topCall": [], "noTopCall": [], "edge": []}
    for s in scenes:
        names = defs(s) if isinstance(s.get("files"), list) else []
        files = [f["path"].rsplit("/", 1)[-1] for f in s.get("files", []) if isinstance(f, dict) and isinstance(f.get("path"), str)]
        rows.append({"id": s.get("id"), "files": files, "names": names})
        overlap += [f"{s.get('id')} {x}" for x in files + names if x in avoid]
        if s.get("group") == "in":
            for f in s.get("files", []):
                comp["new" if f.get("before") is None else "edit"] += 1
            (comp["topCall"] if top_call(s, names) else comp["noTopCall"]).append(s["id"])
            if s.get("edge") is True:
                comp["edge"].append(s["id"])
    if bad or (overlap and part == "A"):
        print("STOP:", json.dumps({"shape": bad, "overlap": overlap}, ensure_ascii=False))
        sys.exit(6)
    os.makedirs(frozen, exist_ok=True)
    out = {}
    raw = open(f"{o}/result.txt", encoding="utf-8").read()
    body = json.dumps({"writer": f"{part}{t}", "promptSha256": open(f"{o}/prompt.sha256").read().split()[0], "reply": raw}, ensure_ascii=False, indent=1) + "\n"
    open(f"{frozen}/raw.json", "w", encoding="utf-8").write(body)
    ch = json.dumps(scenes, ensure_ascii=False, indent=1) + "\n"
    open(f"{frozen}/changes.json", "w", encoding="utf-8").write(ch)
    out["changes"] = sha(ch)
    h = subprocess.run(["python3", "-I", f"{S}/tools/prep.py", f"{frozen}/changes.json", f"{frozen}/hunks.json"], capture_output=True, text=True, check=True)
    out["hunks"] = json.loads(h.stdout)["sha256"]
    names_txt = "\n".join(f"{r['id']}\tfiles: {' '.join(r['files'])}\tnames: {' '.join(r['names'])}" for r in rows) + "\n"
    open(f"{frozen}/NAMES.txt", "w", encoding="utf-8").write(names_txt)
    chk = {"writer": f"{part}{t}", "started": open(f"{o}/started.txt").read().strip(), "ended": open(f"{o}/ended.txt").read().strip(),
           "writerOpus": any("opus" in k for k in json.loads(open(f"{o}/model.txt").read())), "scenes": len(scenes), "shape": bad, "overlap": overlap, "composition": comp, "sha256": out}
    cj = json.dumps(chk, ensure_ascii=False, indent=1) + "\n"
    open(f"{frozen}/check.json", "w", encoding="utf-8").write(cj)
    for n in ("raw.json", "changes.json", "hunks.json", "NAMES.txt", "check.json"):
        os.chmod(f"{frozen}/{n}", 0o444)
    print(json.dumps({"frozen": frozen, "scenes": len(scenes), "overlap": overlap, "composition": {k: (v if isinstance(v, int) else len(v)) for k, v in comp.items()}, "sha256": {**out, "check": sha(cj)}}, ensure_ascii=False))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
