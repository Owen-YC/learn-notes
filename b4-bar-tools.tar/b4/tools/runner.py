"""learn-notes 1.12.0 G5 (batch 4) runner: the stance's [러너] (S2 · S14), no model call, a fixed procedure.
For each opened line (stored.json from build.mjs stored): the call is the text inside the line's backticks, verbatim
(no value changed, nothing made up). The file is the one the called function is defined in (callee.file).
  (A) that file as '## 바뀐 코드' shows it (a creation: the whole file; an edit: each hunk's after-side lines, context and
      added, in order), written under its own name in an empty temp folder, then a marker line and the fixed output line:
        js · ts  console.log('__G5_MARK__')
                 Promise.resolve().then(() => (CALL)).then(r => console.log('RETURN', JSON.stringify(r) ?? String(r)), e => console.log('ERROR', (e && e.name) || 'Error'))
        py       print('__G5_MARK__')
                 try:
                     r = CALL
                     print('RETURN', repr(r))
                 except Exception as e:
                     print('ERROR', type(e).__name__)
  (B) only when every run of A ends before the marker or has no RETURN/ERROR line after it (a syntax error, waiting for
      input: stdin is empty, any other error, or a time limit reached before the marker): the function's head to its
      body's end, the same file's shown top-level one-line definitions (constants: js `const NAME = …` and py
      `NAME = …` on one line whose value calls nothing; js import, type, interface; py import, from … import), and every shown function of that file the function calls or names (and those
      they call or name: a function passed as a value, xs.reduce(add, 0), is called by it),
      in the file's order, then the same two lines. No other file is used (each file its own module, fresh state).
Runs: js `node`, ts `node --experimental-transform-types` (no type check), twice each; py `env -i PATH=… LANG=C.UTF-8
PYTHONHASHSEED=<n> python3 -s -P -B` for n = 1..5; each under `unshare -n timeout 5`, stdin an empty file, in a fresh empty
folder. Only what comes after the marker is read (the file's own example output before it is not). Every run's
after-marker lines must be the same and none may reach the time limit, else there is no runner result (= (가)-1 (2)
miss). A procedure whose runs reach the time limit after the marker (the call does not end) gives no runner result and
B is not tried. Final result: 'ERROR <name>' = ends with that error; 'RETURN <value>' = that value (js undefined, py
None = '돌려주는 것 없음').
usage: runner.py <stored.json> <out runner.json>   (refuses to overwrite; chmod 444)"""
import hashlib, json, os, re, shutil, subprocess, sys, tempfile

WORK = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4/work/runner"
EMPTY = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4/work/empty-stdin"
LINE = re.compile(r"`([^`]+)`")
MARK = "__G5_MARK__"
JS_EXT = ("js", "mjs", "cjs", "ts", "mts", "cts")


def after_hunks(diff):
    hunks, cur = [], None
    for line in diff.split("\n"):
        if line.startswith("@@"):
            cur = []
            hunks.append(cur)
            continue
        if cur is None or line.startswith("-") or line.startswith("\\"):
            continue
        cur.append(line[1:] if line[:1] in ("+", " ") else line)
    return hunks


def shown_lines(change):
    return [l for h in after_hunks(change["diff"]) for l in h]


def tail(call, lang):
    if lang == "py":
        return [f"print('{MARK}')", "try:", f"    r = {call}", "    print('RETURN', repr(r))", "except Exception as e:", "    print('ERROR', type(e).__name__)", ""]
    return [f"console.log('{MARK}')", f"Promise.resolve().then(() => ({call})).then(r => console.log('RETURN', JSON.stringify(r) ?? String(r)), e => console.log('ERROR', (e && e.name) || 'Error'))", ""]


def strip_js(text):
    return re.sub(r"/\*.*?\*/|//.*$|`(?:\\.|[^`\\])*`|'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\"", '""', text)


JS_FUNC = re.compile(r"^(?:export\s+(?:default\s+)?)?(?:async\s+)?function\s*\*?\s*([A-Za-z_$][\w$]*)\s*\(|^(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*(?::[^=]+)?=\s*(?:async\s+)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*(?::[^=]+)?=>|^(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*(?::[^=]+)?=\s*(?:async\s+)?function\b")
JS_ONE = re.compile(r"^(?:export\s+)?(?:const\s+[A-Za-z_$][\w$]*|type\s+[A-Za-z_$][\w$]*|interface\s+[A-Za-z_$][\w$]*)\b|^import\s")
PY_FUNC = re.compile(r"^(?:async\s+)?def\s+([A-Za-z_]\w*)\s*\(")
PY_ONE = re.compile(r"^[A-Za-z_]\w*\s*(?::[^=]+)?=(?!=)|^import\s|^from\s+\S+\s+import\s")


def js_block_end(lines, i):
    """The last line of the top-level statement starting at i (brackets balanced, not continued), or None."""
    depth, opened = 0, False
    for j in range(i, len(lines)):
        code = strip_js(lines[j])
        for c in code:
            if c in "([{":
                depth += 1
                opened = True
            elif c in ")]}":
                depth -= 1
        goes_on = re.search(r"(?:=>|=|\(|,|\+|-|\*|/|&&|\|\||\?|:)\s*$", code.strip())
        nxt = lines[j + 1].lstrip() if j + 1 < len(lines) else ""
        if depth <= 0 and not goes_on and not re.match(r"^[.?:]", nxt):
            return j
    return None


def py_block_end(lines, i):
    j = i + 1
    while j < len(lines) and (lines[j].strip() == "" or lines[j][0].isspace()):
        j += 1
    while j - 1 > i and lines[j - 1].strip() == "":
        j -= 1
    return j - 1


def has_call(line, lang):
    """A one-line definition is a constant only when its value calls nothing (input(), prompt(), load() are not)."""
    if re.match(r"^(?:import|from)\s", line):
        return False
    code = strip_js(line) if lang != "py" else re.sub(r"#.*$|'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\"", '""', line)
    value = code.split("=", 1)[1] if "=" in code else ""
    return re.search(r"[\w$\])]\s*\(", value) is not None


def pieces(lines, lang):
    """Top-level pieces of the shown lines: (kind, name, start, end) with kind fn | one | other."""
    out, i = [], 0
    while i < len(lines):
        t = lines[i]
        if not t.strip() or t[0].isspace():
            i += 1
            continue
        if lang == "py":
            m = PY_FUNC.match(t)
            if m:
                e = py_block_end(lines, i)
                out.append(("fn", m.group(1), i, e))
                i = e + 1
                continue
            if PY_ONE.match(t):
                e = i if not re.search(r"[(\[{]\s*$", t) else py_block_end(lines, i)
                out.append(("one" if e == i and not has_call(t, lang) else "other", None, i, e))
                i = e + 1
                continue
            e = py_block_end(lines, i) if t.rstrip().endswith(":") else i
            out.append(("other", None, i, e))
            i = e + 1
            continue
        m = JS_FUNC.match(t)
        e = js_block_end(lines, i)
        if e is None:
            out.append(("other", None, i, len(lines) - 1))
            break
        if m:
            out.append(("fn", next(g for g in m.groups() if g), i, e))
        elif JS_ONE.match(t) and e == i and not has_call(t, lang):
            out.append(("one", None, i, e))
        else:
            out.append(("other", None, i, e))
        i = e + 1
    return out


def procedure_b(lines, lang, name):
    ps = pieces(lines, lang)
    fns = {p[1]: p for p in ps if p[0] == "fn"}
    if name not in fns:
        return None
    keep, todo = {name}, [name]
    while todo:
        f = fns[todo.pop()]
        body = "\n".join(lines[f[2]:f[3] + 1])
        for other in fns:
            if other not in keep and re.search(rf"(?<![\w$.]){re.escape(other)}(?![\w$])", body):
                keep.add(other)
                todo.append(other)
    chosen = [p for p in ps if p[0] == "one" or (p[0] == "fn" and p[1] in keep)]
    return [l for p in chosen for l in lines[p[2]:p[3] + 1]]


def run_once(name, src, lang, n):
    tmp = tempfile.mkdtemp(dir=WORK)
    try:
        open(os.path.join(tmp, name), "w", encoding="utf-8").write(src)
        if lang == "py":
            cmd = ["unshare", "-n", "timeout", "5", "env", "-i", f"PATH={os.environ['PATH']}", "LANG=C.UTF-8", f"PYTHONHASHSEED={n}", "python3", "-s", "-P", "-B", name]
        elif lang == "ts":
            cmd = ["unshare", "-n", "timeout", "5", "node", "--experimental-transform-types", "--no-warnings", name]
        else:
            cmd = ["unshare", "-n", "timeout", "5", "node", "--no-warnings", name]
        # stdin: an empty file of our own (this container's /dev/null is a plain file holding text, 2026-11-14).
        with open(EMPTY, "rb") as empty:
            p = subprocess.run(cmd, cwd=tmp, capture_output=True, text=True, stdin=empty, timeout=60)
        out = p.stdout.split("\n")
        marked = MARK in out
        after = [l for l in out[out.index(MARK) + 1:] if l != ""] if marked else []
        return {"code": p.returncode, "timedOut": p.returncode == 124, "marked": marked, "after": after, "stderrTail": p.stderr[-300:]}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def run_all(name, src, lang):
    return [run_once(name, src, lang, n) for n in range(1, (6 if lang == "py" else 3))]


def verdict(runs):
    """'ok' (result), 'fallback' (A gives nothing: try B), 'none' (no runner result)."""
    if any(r["timedOut"] and r["marked"] for r in runs):
        return "none", None
    good = [r for r in runs if r["marked"] and len(r["after"]) >= 1 and re.match(r"^(RETURN|ERROR) ", r["after"][-1] + " ")]
    if not good:
        return "fallback", None
    if len(good) != len(runs) or any(r["after"] != runs[0]["after"] for r in runs) or any(r["timedOut"] for r in runs):
        return "none", None
    if len(runs[0]["after"]) != 1:
        return "none", None
    return "ok", runs[0]["after"][0]


def final_of(line, lang):
    kind, _, value = line.partition(" ")
    if kind == "ERROR":
        return {"kind": "error", "name": value, "text": f"{value} 오류로 끝남"}
    if (lang == "py" and value == "None") or (lang != "py" and value == "undefined"):
        return {"kind": "none", "value": value, "text": "돌려주는 것 없음"}
    return {"kind": "return", "value": value, "text": value}


def run_line(entry):
    m = LINE.search(entry["line"])
    call = m.group(1)
    name = re.match(r"([A-Za-z_$][\w$]*)\s*\(", call).group(1)
    change = next(c for c in entry["changes"] if c["file"] == entry["calleeFile"])
    ext = change["file"].rsplit(".", 1)[-1].lower()
    lang = "py" if ext == "py" else "ts" if ext in ("ts", "mts", "cts") else "js"
    fname = os.path.basename(change["file"])
    shown = shown_lines(change)
    src_a = "\n".join(shown + tail(call, lang))
    runs_a = run_all(fname, src_a, lang)
    how, line = verdict(runs_a)
    rec = {"call": call, "file": change["file"], "lang": lang, "A": {"runs": runs_a, "verdict": how}, "srcA": src_a}
    if how == "fallback":
        b = procedure_b(shown, lang, name)
        if b is None:
            rec["B"] = {"verdict": "none", "why": "function not found whole in the shown lines"}
            how, line = "none", None
        else:
            src_b = "\n".join(b + tail(call, lang))
            runs_b = run_all(fname, src_b, lang)
            how_b, line = verdict(runs_b)
            rec["B"] = {"runs": runs_b, "verdict": how_b}
            rec["srcB"] = src_b
            how = "ok" if how_b == "ok" else "none"
            rec["procedure"] = "B"
    else:
        rec["procedure"] = "A"
    rec["runner"] = how == "ok"
    rec["out"] = line
    rec["final"] = final_of(line, lang) if how == "ok" else None
    return rec


if __name__ == "__main__":
    src, dst = sys.argv[1], sys.argv[2]
    if os.path.exists(dst):
        sys.exit(f"refuse: {dst} exists")
    os.makedirs(WORK, exist_ok=True)
    if not os.path.exists(EMPTY) or os.path.getsize(EMPTY) != 0:
        open(EMPTY, "w").close()
    stored = json.load(open(src, encoding="utf-8"))
    out = {}
    for id_, entry in stored.items():
        if not entry.get("line"):
            continue
        out[id_] = run_line(entry)
        r = out[id_]
        print(id_, r["lang"], r.get("procedure"), "OK" if r["runner"] else "NO", r["call"], "->", r["out"])
    body = json.dumps({"versions": {"node": subprocess.run(["node", "--version"], capture_output=True, text=True).stdout.strip(), "python3": subprocess.run(["python3", "--version"], capture_output=True, text=True).stdout.strip()}, "runner": out}, ensure_ascii=False, indent=1) + "\n"
    open(dst, "w", encoding="utf-8").write(body)
    os.chmod(dst, 0o444)
    print(json.dumps({"lines": len(out), "runner": sum(1 for r in out.values() if r["runner"]), "sha256": hashlib.sha256(body.encode()).hexdigest()}))
