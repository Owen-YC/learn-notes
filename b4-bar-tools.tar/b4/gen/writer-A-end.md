
## 꼴

장면마다 JSON 객체 하나를 쓰고, 46개 모두를 id 차례대로 JSON 배열 하나에 담아 ```json 울타리 안에만 적습니다. 다른 말은 쓰지 않습니다.

```
{"id": "GM01", "group": "in", "lang": "js", "kind": "짧은 설명(예: 새 파일, 맨 위에서 부름)", "edge": false,
 "request": "학습자의 요청 한 줄",
 "files": [{"path": "src/파일.js", "before": "바뀌기 전 파일 글 전체 (새 파일이면 null)", "after": "바뀐 뒤 파일 글 전체"}],
 "answer": "도우미가 마지막에 한 설명 (한두 문장)"}
```

- lang: group "in"과 GM34~GM46은 위 짜임의 글자 그대로(js · ts · py · js+js · ts+ts · py+py · js+css · ts+json · py+md · go · rb · sh · vue · jsx · tsx), GM25~GM33은 그 파일의 확장자(json · js · ts · css · md · html · jsx · py 따위).
- edge: group "in"에서 다른 자연스러운 입력이 오류 · 거부 값 · 바뀌지 않음 · 빈 결과를 내는 함수면 true, 그 밖(group "out" 모두)은 false.
- path는 프로젝트 안의 상대 경로이고, 파일 글은 끝에 줄바꿈 하나로 끝납니다.
- 표준 라이브러리 밖의 패키지는 쓰지 않습니다(jsx · tsx의 react는 됨).
