"""learn-notes 1.12.0 G5 (batch 4): the writers' '## 이름' section (plan batches[4].samples.avoid; SCOPE step 3), from
impl112/NAMES-all.txt as it is when the writer runs (every G1-G6 1.12.0 dev and measured name, design/G5/dev/NAMES.txt
PD01-PD30 · PE01-PE30 · PF01-PF10 · coverage set PC01-PC40, the 1.11.0 K01-K37 names and every 견본.md name, plus any
PG01-PG12 names appended after the GO pilot's writer) and impl111/b7/gen/names.json (1.8.0, 1.9.0 names). Two lists:
file names (an entry with a code or document extension, its last path part) and code names (an entry that is an
identifier of 3+ characters, not an id like K01 or D1A01). Sorted, joined with ' · ' in backticks.
usage: avoid.py <out.md> <names.txt out>   (refuses to overwrite; the second file keeps both lists, one name a line)"""
import json, os, re, sys
NAMES = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/NAMES-all.txt"
OLD = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl111/b7/gen/names.json"
IDENT = re.compile(r"^[A-Za-z_$][\w$]*$")
ID = re.compile(r"^[A-Za-z]{1,4}\d+[A-Za-z]?\d*$")
FILE = re.compile(r"^[\w./@-]+\.(js|mjs|cjs|ts|mts|cts|tsx|jsx|py|json|md|css|scss|html|go|rb|sh|vue|txt|yml|yaml|toml)$")


def lists():
    rows = [l.split("\t", 1)[0] for l in open(NAMES, encoding="utf-8") if l.strip()]
    old = json.load(open(OLD, encoding="utf-8"))
    files = sorted({r.rsplit("/", 1)[-1] for r in rows + old["files"] if FILE.match(r)})
    names = sorted({r for r in rows + old["functions"] if IDENT.match(r) and len(r) >= 3 and not ID.match(r)})
    return files, names


if __name__ == "__main__":
    out, keep = sys.argv[1], sys.argv[2]
    for p in (out, keep):
        if os.path.exists(p):
            sys.exit(f"refuse: {p} exists")
    files, names = lists()
    q = lambda xs: " · ".join(f"`{x}`" for x in xs)
    open(out, "w", encoding="utf-8").write("\n## 이름\n\n앞선 견본과 겹치지 않게, 아래 이름은 파일 이름으로도, 함수 · 클래스 · 컴포넌트 이름으로도 쓰지 않습니다.\n\n- 파일: " + q(files) + "\n- 이름: " + q(names) + "\n")
    open(keep, "w", encoding="utf-8").write("\n".join(["# files"] + files + ["# names"] + names) + "\n")
    print(json.dumps({"files": len(files), "names": len(names)}))
