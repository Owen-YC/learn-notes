#!/bin/bash
# learn-notes 1.12.0 G5 (batch 4; batch 3 copy, from batch 1's): the 'ok' session before a model-stage (the calibration's form). It is the before
# record (claude --version, init model, modelUsage keys) and holds the usage gate's numbers (rate_limit_event).
# usage: precheck.sh <out dir> <alias>     (through cli/pinned.sh)
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4
O="$1"; A="$2"
case "$A" in haiku|sonnet) ;; *) echo "refuse: alias must be haiku or sonnet"; exit 2;; esac
mkdir -p "$O" "${S:?}/work/empty"
# stdin: an empty file of our own (this container's /dev/null is a plain file holding text, 2026-11-14)
[ -f "${S:?}/work/empty-stdin" ] && [ ! -s "${S:?}/work/empty-stdin" ] || : > "${S:?}/work/empty-stdin"
cd "${S:?}/work/empty" || exit 1
export DISABLE_AUTOUPDATER=1
claude --version > "$O/version.txt" 2>&1
date -u +%FT%TZ > "$O/started.txt"
timeout 180 claude -p --model "$A" --tools '' --output-format stream-json --verbose ok < "${S:?}/work/empty-stdin" > "$O/stream.jsonl" 2> "$O/err.txt"
echo "exit=$?" > "$O/exit.txt"
date -u +%FT%TZ > "$O/ended.txt"
python3 -I "${S:?}/probe/record.py" "$O" > /dev/null
