# verdicts P round B

- HA01 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const res = await fetch(url);", "example": "const res = await apiRequest(url);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- HA02 {"kind": "R", "isL": false, "den": false, "tier": null, "why": null}
- HA03 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "return fetch(url).then((r) => r.json());", "example": "return apiRequest(url).then((r) => r.json());", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- HA05 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "return (await fetch(url, init)).json();", "example": "return (await apiRequest(url, init)).json();", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- HA06 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const jobRes = await fetch(searchUrl);", "example": "const jobRes = await apiRequest(searchUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- HA07 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "resp = requests.get(url, timeout=5)", "example": "resp = api_request(url, timeout=5)", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- HA08 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "return requests.get(url).json()", "example": "return api_request(url).json()", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- HA09 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "resp = requests.get(url, params=wanted)", "example": "resp = api_request(url, params=wanted)", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- HA10 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "r = requests.get(url, headers=HEADERS)", "example": "r = api_request(url, headers=HEADERS)", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- HB01 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('locker', chosen.no, who);", "example": "log.info('locker', chosen.no, who);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- HB02 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log(city, 'chance', chance);", "example": "log.info(city, 'chance', chance);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- HB03 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "console.log(`mean ${meanScore}`);", "example": "log.info(`mean ${meanScore}`);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- HB04 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('mentions', unique);", "example": "log.info('mentions', unique);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- HB05 {"kind": "R", "isL": false, "den": false, "tier": null, "why": null}
- HB06 {"kind": "R", "isL": false, "den": false, "tier": null, "why": null}
- HB07 {"kind": "R", "isL": false, "den": false, "tier": null, "why": null}
- HB08 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "print(f\"ticket {label} issued\")", "example": "log.info(f\"ticket {label} issued\")", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- HB09 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "print(\"ready\", counter, len(done))", "example": "log.info(\"ready\", counter, len(done))", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- HB10 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "print(\"fare after coupon:\", fare)", "example": "log.info(\"fare after coupon:\", fare)", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- HC01 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "return end.toISOString().slice(0, 10);", "example": "return toDateText(slot.endsAt);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- HC02 {"kind": "R", "isL": true, "den": true, "tier": 0, "why": "no-hint"}
- HC03 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "return when.toISOString().split('T')[0];", "example": "return toDateText(when);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- HC04 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "return day.toJSON().substring(0, 10);", "example": "return toDateText(start + stay.nights * NIGHT_MS);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- HC05 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "not-one-span"}
- HC06 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "none"}
- HC07 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "refill = next_at.strftime(\"%Y-%m-%d\")", "example": "refill = to_date_text(next_at)", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- HC08 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "return day.isoformat()", "example": "return to_date_text(day)", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- HC09 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "\"day\": shipped.isoformat()[:10],", "example": "\"day\": to_date_text(p[\"shipped_at\"]),", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- HC10 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "labels.append(d.strftime(\"%Y-%m-%d\"))", "example": "labels.append(to_date_text(d))", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- HD01 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const raw = process.env.WEEKEND_RATE;", "example": "const raw = config.WEEKEND_RATE;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- HD03 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const base = process.env.BRANCH_API;", "example": "const base = config.BRANCH_API;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- HD04 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "if (process.env.RATING_OFF === 'yes') {", "example": "if (config.RATING_OFF === 'yes') {", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- HD05 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const rate = process.env.TAX_RATE;", "example": "const rate = config.TAX_RATE;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- HD06 {"kind": "R", "isL": false, "den": false, "tier": null, "why": null}
- HD07 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "if (process.env.LOW_DATA) {", "example": "if (config.LOW_DATA) {", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- HD08 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "ahead = int(os.environ[\"BOOK_AHEAD\"])", "example": "ahead = int(config.BOOK_AHEAD)", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- HD09 {"kind": "R", "isL": true, "den": true, "tier": 0, "why": "no-line"}
- HD10 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "bonus = os.environ.get(\"BONUS_SEC\")", "example": "bonus = config.BONUS_SEC", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- HE01 {"kind": "R_long", "isL": false, "den": false, "tier": null, "why": null}
- HE02 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- HE03 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-hint"}
- HE04 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- HF01 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- HF02 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- HF03 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- HF04 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- HF05 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- HF06 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- HF07 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- HF08 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- HF09 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- HF10 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- HF11 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- HF12 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- HM01 {"kind": "multi", "isL": false, "den": false, "tier": null, "why": null}
- HM02 {"kind": "multi", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const phone = process.env.HELP_PHONE;", "example": "const phone = config.HELP_PHONE;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- HM03 {"kind": "multi", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "eta_resp = requests.get(ETA_URL + pid)", "example": "eta_resp = api_request(ETA_URL + pid)", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- HM04 {"kind": "multi", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "print(\"need\", floor_qty - g[\"qty\"])", "example": "log.info(\"need\", floor_qty - g[\"qty\"])", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- HN01 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- HN02 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- HN03 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- HN04 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- HN05 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- HN06 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- HN07 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- HN08 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- HN09 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- HN10 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- HN11 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- HN12 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- HP01 {"kind": "double", "isL": false, "den": false, "tier": null, "why": null}
- HT01 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- HT02 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- HT03 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- HT04 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- HT05 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- HT06 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- HT07 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- HT08 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- HT09 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- HW02 {"kind": "double", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "const a = j.toISOString().slice(0, 10);", "example": "const a = toDateText(j);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- HW03 {"kind": "double", "isL": false, "den": false, "tier": null, "why": null}
- HW04 {"kind": "double", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const backRes = await fetch(backUrl);", "example": "const backRes = await apiRequest(backUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}

## counts

{
 "answered": 83,
 "unanswered": [
  "HA04",
  "HD02"
 ],
 "L": 45,
 "O": 38,
 "den": 38,
 "correct": 34,
 "harmful": [],
 "twoTask": [],
 "O_rule": [],
 "c_bad": [],
 "trap_rule": [],
 "noShort_rule": [],
 "unlabelled": [],
 "old_bad": [],
 "idem_bad": [],
 "off_not_kept": [],
 "w_changed": 3,
 "w_fp": [
  "HT06"
 ],
 "undecided": [],
 "miss": {
  "no rule practice (no-hint)": 1,
  "no rule practice (not-one-span)": 1,
  "no rule practice (none)": 1,
  "no rule practice (no-line)": 1
 },
 "tiers": {
  "tier1": 12,
  "tier2": 24,
  "tier0-no-hint": 2,
  "tier0-no-line": 7
 },
 "drill_called": 24,
 "offW0_differs_tree": []
}
