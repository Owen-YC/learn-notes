너는 코딩 연습의 학습자 답 사례를 쓰는 사람이다. 아래 팀 파일과 연습 하나에 대해, 학습자가 '고칠 줄' 자리에 적었을 법한 한 줄 답을 갈래마다 정한 수만큼 쓴다. 답은 들여쓰기 없이 그 줄 하나다. 답은 실제로 그 파일의 그 줄 자리에 넣어 돌려 본다.

## 팀 파일

```markdown
# 우리 팀의 학습 노트 규칙

## 규칙
- 서버 요청은 `fetch`(파이썬은 `requests`)를 바로 쓰지 말고 `apiRequest`(파이썬은 `api_request`)를 쓴다. 같은 인자를 받고 같은 응답을 돌려주며, 인증 헤더와 재시도를 더한다
- 기록은 `console.log`(파이썬은 `print`) 대신 `log.info`로 남긴다
- 날짜를 글자로 보일 때는 직접 만들지 말고 `toDateText`(파이썬은 `to_date_text`)를 쓴다. 결과는 `2026-10-22` 꼴(UTC)이다
- 설정 값은 `process.env`(파이썬은 `os.environ`)를 바로 읽지 말고 `config`에서 같은 이름으로 읽는다 (`config.API_URL`)

## 용어
- **주문서**: 결제 직전에 굳힌 장바구니. 금액과 배송지가 더는 바뀌지 않는다
- **회원 등급**: 지난 1년 구매 금액으로 정하는 등급(일반 · 실버 · 골드). 할인율이 등급마다 다르다
```

## 갈래 (이 연습에 열 개: 본 답 여섯 + 갈래마다 예비 하나)

- keep 3개(본 2 + 예비 1): 팀 규칙을 지키고 그대로 동작하지만, 예시 답과 글자가 다른 줄(변수 이름 · 인자 · 따옴표 · 꼴을 바꿈. 같은 결과를 냄)
- break 3개(본 2 + 예비 1): 팀 규칙을 어긴 채로(규칙이 쓰지 말라는 이름이나 방식을 남기거나 쓰라는 이름을 안 씀) 동작은 하는 줄. 고칠 줄과 글자가 달라야 한다
- broken 2개(본 1 + 예비 1): 규칙이 쓰라는 이름은 들어 있지만 깨진 줄(구문 오류, 없는 변수, 결과가 달라짐)
- off 2개(본 1 + 예비 1): 규칙과 상관없는 엉뚱한 고침(쓰라는 이름 없음, 결과도 달라짐)
- 답은 영문 상태에서 친 코드 줄이다. 빈 줄, 예시 답이나 고칠 줄과 같은 줄은 쓰지 않는다.

## 연습

### 연습 HA02
- 파일: `src/reviews/reviewVote.js` (23행)
- 할 일: 바뀐 한 줄을 규칙대로 고쳐 보세요.
- 확인: 고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다
- 고칠 줄: `const res = await fetch(url, options);`
- 예시 답: `const res = await apiRequest(url, options);`
- 노트가 짚은 팀 규칙: 서버 요청은 `fetch`를 바로 쓰지 말고 `apiRequest`를 써야 하는데, 이 함수는 `fetch`를 직접 호출합니다.
- 돌려 보는 호출(첫 파일 끝에서): `voteHelpful(31, 'u9')`
- 파일 전체(바뀐 뒤):
```
import { apiRequest } from '../api/apiRequest.js';
import { log } from '../log.js';

const REVIEW_URL = 'https://api.example.test/reviews';

export async function loadReview(reviewId) {
  const res = await apiRequest(REVIEW_URL + '/' + reviewId);
  return res.json();
}

export async function listProductReviews(productId) {
  const res = await apiRequest(REVIEW_URL + '?product=' + productId);
  const data = await res.json();
  return data.reviews;
}

export async function voteHelpful(reviewId, voterId) {
  if (!voterId) {
    return null;
  }
  const url = REVIEW_URL + '/' + reviewId + '/votes';
  const options = { method: 'POST', body: JSON.stringify({ voterId }) };
  const res = await fetch(url, options);
  const data = await res.json();
  log.info('helpful votes:', data.helpful);
  return data.helpful;
}

```

## 출력

JSON 하나만 ```json 블록으로 쓴다. 갈래마다 본 답을 먼저, 예비를 마지막에 둔다(`"reserve": true`):
{"<연습 id>": [{"kind": "keep|break|broken|off", "line": "…", "reserve": false}, … 10개]}
