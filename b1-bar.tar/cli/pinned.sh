#!/bin/bash
# Pinned Claude Code for learn-notes 1.12.0 (plan base.cliPin).
# usage: pinned.sh <command> [args...]   run a command with the pinned copy first on PATH
#        pinned.sh --record              print the pinned version and the re-hashed sha256 of both files
# Every claude process that makes or records a model call (calibration, prechecks, probe sessions, GO pilot,
# taps, D34 captures, sample writers, judges) and the gates run through this wrapper.
C=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/2.1.323
WANT_SIZE=362435088
export DISABLE_AUTOUPDATER=1
export PATH="$C:$PATH"
export CLAUDE_BIN="$C/claude"
[ -x "$C/claude" ] && [ -r "$C/claude.hot" ] || { echo "pinned.sh: pinned copy missing or not runnable ($C)" >&2; exit 98; }
[ "$(stat -c %s "$C/claude")" = "$WANT_SIZE" ] || { echo "pinned.sh: pinned binary size changed" >&2; exit 98; }
[ "$(command -v claude)" = "$C/claude" ] || { echo "pinned.sh: pinned claude is not first on PATH" >&2; exit 97; }
if [ "$1" = "--record" ]; then
  echo "version: $("$C/claude" --version 2>&1)"
  ( cd "$C" && sha256sum claude claude.hot )
  exit 0
fi
[ $# -gt 0 ] || { echo "usage: pinned.sh <command> [args...] | --record" >&2; exit 2; }
exec "$@"
