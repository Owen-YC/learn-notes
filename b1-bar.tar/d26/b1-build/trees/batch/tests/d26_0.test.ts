import { describe, test } from 'claude-code/testing'
import { finish, routeCalls, start, turn, world } from './flowkit'
import { CASES, FROM } from './d26cases0'
const ALIAS = { haiku: 'ANTHROPIC_DEFAULT_HAIKU_MODEL', sonnet: 'ANTHROPIC_DEFAULT_SONNET_MODEL' } as const
type File = { path: string; tool: string; kind: string; before?: string; after?: string; content?: string; hunks: unknown[] }
describe('d26 isRuleWide capture 0', () => {
  CASES.forEach((c: { id: string; model: 'haiku' | 'sonnet'; team: string; files: File[]; request: string; reply: string }, k: number) => {
    const n = FROM + k
    for (const turned of [false, true]) {
      test(`${n} ${c.id} ${c.model} ${turned}`, { options: { model: c.model } }, async ($, on) => {
        const now: Record<string, string> = {}
        on('env.get', { name: ALIAS[c.model] }, (_$, e, next) => (now[e.name] !== undefined ? { value: now[e.name] } : next(e)))
        on('tool.call', { tool: 'Edit' }, (_$, e, next) => {
          const f = c.files.find(one => one.path === e.file_path && one.tool === 'Edit')
          if (!f) return next(e)
          return { result: { filePath: e.file_path, oldString: e.old_string, newString: e.new_string, originalFile: f.before, structuredPatch: f.hunks, userModified: false, replaceAll: false } }
        })
        on('tool.call', { tool: 'Write' }, (_$, e, next) => {
          const f = c.files.find(one => one.path === e.file_path && one.tool === 'Write')
          if (!f) return next(e)
          return { result: { type: 'create', filePath: e.file_path, content: e.content, structuredPatch: [], originalFile: null } }
        })
        const calls = routeCalls(on)
        const store = new Map<string, unknown>()
        const w = world(on, 'ok', null, true, store)
        w.files.set('/proj/.claude/learn-notes.md', c.team)
        await start($)
        if (turned) now[ALIAS[c.model]] = 'set-in-session-x'
        w.texts = [c.reply]
        await turn($, async () => {
          for (const [i, f] of c.files.entries()) {
            if (f.tool === 'Write') await $.tool.call({ tool: 'Write', tool_use_id: `d${i}`, file_path: f.path, content: f.content ?? f.after ?? '' })
            else await $.tool.call({ tool: 'Edit', tool_use_id: `d${i}`, file_path: f.path, old_string: f.before ?? '', new_string: f.after ?? '' })
          }
        }, 't1', c.request || '코드를 바꿔 줘')
        await finish(w)
        const notes = ((store.get('history') as Record<string, { notes: { text: string; status: string }[] }> | undefined)?.['/proj']?.notes) ?? []
        console.log('D26OUT ' + JSON.stringify({ n, id: c.id, model: c.model, turned, calls, text: notes.at(-1)?.text ?? null, status: notes.at(-1)?.status ?? null }))
      })
    }
  })
})
