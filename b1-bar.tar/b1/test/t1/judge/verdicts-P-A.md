# verdicts P round A

- D4A01 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const pop = await fetch(POPULAR_URL);", "example": "const pop = await apiRequest(POPULAR_URL);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- D4A02 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const doneReply = await fetch(doneUrl);", "example": "const doneReply = await apiRequest(doneUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- D4A03 {"kind": "R", "isL": false, "den": false, "tier": null, "why": null}
- D4A04 {"kind": "R", "isL": false, "den": false, "tier": null, "why": null}
- D4A05 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "hot = requests.get(HOT_API, params=opts)", "example": "hot = api_request(HOT_API, params=opts)", "check": "고친 줄이 돌 때 `api_request` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- D4A06 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "print(\"scale factor:\", factor)", "example": "log.info(\"scale factor:\", factor)", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- D4A07 {"kind": "R", "isL": false, "den": false, "tier": null, "why": null}
- D4A08 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('overtime:', names);", "example": "log.info('overtime:', names);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- D4A09 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "print(\"capped from\", charge)", "example": "log.info(\"capped from\", charge)", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- D4A10 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "console.log('password too short');", "example": "log.info('password too short');", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- D4A11 {"kind": "R", "isL": false, "den": false, "tier": null, "why": null}
- D4A12 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "bill_on = next_bill.strftime(\"%Y-%m-%d\")", "example": "bill_on = to_date_text(next_bill)", "check": "고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- D4A13 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "return ed.toISOString().slice(0, 10);", "example": "return toDateText(ed);", "check": "고친 줄이 돌 때 `toDateText` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule date; check values=[] same=False effect=['date'] call=demo", "rule": "date"}}
- D4A14 {"kind": "R", "isL": false, "den": false, "tier": null, "why": null}
- D4A15 {"kind": "R", "isL": true, "den": true, "tier": 2, "why": "not-one-span"}
- D4A16 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const chatKey = process.env.CHAT_KEY;", "example": "const chatKey = config.CHAT_KEY;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- D4A17 {"kind": "R", "isL": true, "den": true, "tier": 0, "why": "no-line"}
- D4A18 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const zoom = Number(process.env.ZOOM);", "example": "const zoom = Number(config.ZOOM);", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- D4A19 {"kind": "R", "isL": false, "den": false, "tier": null, "why": null}
- D4A20 {"kind": "R", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const ids = process.env.BETA_IDS || '';", "example": "const ids = config.BETA_IDS || '';", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- D4B01 {"kind": "multi", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const wl = await fetch(waitUrl);", "example": "const wl = await apiRequest(waitUrl);", "check": "고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule request; check values=[] same=False effect=['request'] call=demo", "rule": "request"}}
- D4B02 {"kind": "multi", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "shop = os.environ[\"SHOP_NAME\"]", "example": "shop = config.SHOP_NAME", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- D4B03 {"kind": "double", "isL": true, "den": true, "tier": 2, "why": "tier2", "rule_drillOn": {"line": "console.log('tries', attempts.length);", "example": "log.info('tries', attempts.length);", "check": "고친 줄이 돌 때 `log.info` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule log; check values=[] same=False effect=['log'] call=demo", "rule": "log"}}
- D4B04 {"kind": "double", "isL": true, "den": true, "tier": 1, "why": "tier1", "rule_drillOn": {"line": "const origin = process.env.INVITE_HOST;", "example": "const origin = config.INVITE_HOST;", "check": "고친 줄이 돌 때 `config` 쪽을 거칩니다", "task": "바뀐 한 줄을 규칙대로 고쳐 보세요.", "correct": true, "harm": [], "why": "rule config; check values=[] same=False effect=['config'] call=demo", "rule": "config"}}
- D4B05 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-hint"}
- D4B06 {"kind": "R_long", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- D4B07 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- D4B08 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- D4B11 {"kind": "F", "isL": false, "den": false, "tier": null, "why": null}
- D4B13 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- D4B14 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- D4B15 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- D4B16 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- D4B17 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- D4B18 {"kind": "N", "isL": false, "den": false, "tier": null, "why": null}
- D4B19 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- D4B20 {"kind": "trap", "isL": false, "den": false, "tier": null, "why": null}
- D4B21 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}
- D4B22 {"kind": "trap", "isL": true, "den": false, "tier": 0, "why": "no-line"}

## counts

{
 "answered": 39,
 "unanswered": [
  "D4B09",
  "D4B10",
  "D4B12"
 ],
 "L": 22,
 "O": 17,
 "den": 18,
 "correct": 16,
 "harmful": [],
 "twoTask": [],
 "O_rule": [],
 "c_bad": [],
 "trap_rule": [],
 "noShort_rule": [],
 "unlabelled": [],
 "old_bad": [],
 "idem_bad": [],
 "off_not_kept": [],
 "w_changed": 2,
 "w_fp": [],
 "undecided": [],
 "miss": {
  "no rule practice (not-one-span)": 1,
  "no rule practice (no-line)": 1
 },
 "tiers": {
  "tier1": 8,
  "tier2": 9,
  "tier0-no-line": 4,
  "tier0-no-hint": 1
 },
 "drill_called": 9,
 "offW0_differs_tree": []
}
