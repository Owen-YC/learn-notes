너는 코딩 연습의 학습자 답 견본을 쓰는 사람이다. 아래 팀 파일과 연습마다, 학습자가 '고칠 줄' 자리에 적었을 법한 한 줄 답을 갈래마다 정한 수만큼 쓴다. 답은 들여쓰기 없이 그 줄 하나다. 답은 실제로 그 파일의 그 줄 자리에 넣어 돌려 본다.

## 팀 파일

```markdown
# 우리 팀의 학습 노트 규칙

## 규칙
- 서버 요청은 `fetch`(파이썬은 `requests`)를 바로 쓰지 말고 `apiRequest`(파이썬은 `api_request`)를 쓴다. 같은 인자를 받고 같은 응답을 돌려주며, 인증 헤더와 재시도를 더한다
- 기록은 `console.log`(파이썬은 `print`) 대신 `log.info`로 남긴다
- 날짜를 글자로 보일 때는 직접 만들지 말고 `toDateText`(파이썬은 `to_date_text`)를 쓴다. 결과는 `2026-10-22` 꼴(UTC)이다
- 설정 값은 `process.env`(파이썬은 `os.environ`)를 바로 읽지 말고 `config`에서 같은 이름으로 읽는다 (`config.API_URL`)

## 용어
- **주문서**: 결제 직전에 굳힌 장바구니. 금액과 배송지가 더는 바뀌지 않는다
- **회원 등급**: 지난 1년 구매 금액으로 정하는 등급(일반 · 실버 · 골드). 할인율이 등급마다 다르다
```

## 갈래 (연습마다 열 개: 본 답 여섯 + 갈래마다 예비 하나)

- keep 3개(본 2 + 예비 1): 팀 규칙을 지키고 그대로 동작하지만, 예시 답과 글자가 다른 줄(변수 이름 · 인자 · 따옴표 · 꼴을 바꿈. 같은 결과를 냄)
- break 3개(본 2 + 예비 1): 팀 규칙을 어긴 채로(규칙이 쓰지 말라는 이름이나 방식을 남기거나 쓰라는 이름을 안 씀) 동작은 하는 줄. 고칠 줄과 글자가 달라야 한다
- broken 2개(본 1 + 예비 1): 규칙이 쓰라는 이름은 들어 있지만 깨진 줄(구문 오류, 없는 변수, 결과가 달라짐)
- off 2개(본 1 + 예비 1): 규칙과 상관없는 엉뚱한 고침(쓰라는 이름 없음, 결과도 달라짐)
- 답은 영문 상태에서 친 코드 줄이다. 빈 줄, 예시 답이나 고칠 줄과 같은 줄은 쓰지 않는다.

## 연습

### 연습 D4A01
- 파일: `src/faq/faqFeed.js` (11행)
- 할 일: 바뀐 한 줄을 규칙대로 고쳐 보세요.
- 확인: 고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다
- 고칠 줄: `const pop = await fetch(POPULAR_URL);`
- 예시 답: `const pop = await apiRequest(POPULAR_URL);`
- 노트가 짚은 팀 규칙: 인기 질문 요청에 `fetch`를 바로 썼습니다. 팀은 인증 헤더와 재시도가 더해진 `apiRequest`를 쓰도록 정해 두었습니다.
- 돌려 보는 호출(첫 파일 끝에서): `loadFaqTopics('order')`
- 파일 전체(바뀐 뒤):
```
import { apiRequest } from '../api/apiRequest.js';
import { log } from '../log.js';

const FAQ_BASE = 'https://api.example.test/faq';
const POPULAR_URL = FAQ_BASE + '/popular';

export async function loadFaqTopics(category) {
  const reply = await apiRequest(FAQ_BASE + '?cat=' + category);
  const found = await reply.json();
  const topics = found.topics.map((topic) => topic.question);
  const pop = await fetch(POPULAR_URL);
  const popIds = (await pop.json()).ids;
  const hot = found.topics.filter((topic) => popIds.includes(topic.id));
  log.info('faq topics:', topics.length);
  log.info('popular:', hot.length);
  return { topics, hot: hot.map((topic) => topic.question) };
}

```

### 연습 D4A02
- 파일: `src/study/flashDeck.ts` (13행)
- 할 일: 바뀐 한 줄을 규칙대로 고쳐 보세요.
- 확인: 고친 줄이 돌 때 `apiRequest` 쪽을 거칩니다
- 고칠 줄: `const doneReply = await fetch(doneUrl);`
- 예시 답: `const doneReply = await apiRequest(doneUrl);`
- 노트가 짚은 팀 규칙: 외운 카드 목록을 `fetch(doneUrl)`로 바로 불러왔습니다. 팀은 서버 요청에 `apiRequest`(인증 헤더와 재시도를 더한 요청 함수)를 쓰도록 정하고 있어, 이 줄도 맞추는 편이 좋습니다.
- 돌려 보는 호출(첫 파일 끝에서): `loadFlashCards('kr1')`
- 파일 전체(바뀐 뒤):
```
import { apiRequest } from '../api/apiRequest.js';
import { log } from '../log.js';

const LEARNED_BASE = 'https://api.example.test/learned/';

type Card = { id: number; front: string; back: string };

export async function loadFlashCards(deckId: string) {
  const deckUrl = 'https://api.example.test/decks/' + deckId;
  const reply = await apiRequest(deckUrl);
  const deck = (await reply.json()) as { cards: Card[] };
  const doneUrl = LEARNED_BASE + deckId;
  const doneReply = await fetch(doneUrl);
  const learned = (await doneReply.json()) as { ids: number[] };
  const todo = deck.cards.filter((card) => !learned.ids.includes(card.id));
  log.info('cards loaded:', deck.cards.length);
  log.info('to study:', todo.length);
  return todo.map((card) => card.front);
}

```

### 연습 D4A06
- 파일: `app/recipes/scale.py` (8행)
- 할 일: 바뀐 한 줄을 규칙대로 고쳐 보세요.
- 확인: 고친 줄이 돌 때 `log.info` 쪽을 거칩니다
- 고칠 줄: `print("scale factor:", factor)`
- 예시 답: `log.info("scale factor:", factor)`
- 노트가 짚은 팀 규칙: 팀은 기록을 `print` 대신 `log.info`로 남기라고 하는데, 이번 변경은 `print`를 썼습니다.
- 돌려 보는 호출(첫 파일 끝에서): `scale_recipe([{"name": "flour", "grams": 200}, {"name": "sugar", "grams": 50}], 2, 3)`
- 파일 전체(바뀐 뒤):
```
from app.log import log


def scale_recipe(ingredients, base_servings, servings):
    if servings < 1:
        servings = 1
    factor = servings / base_servings
    print("scale factor:", factor)
    scaled = []
    for entry in ingredients:
        grams = round(entry["grams"] * factor)
        scaled.append(entry["name"] + " " + str(grams) + "g")
    log.info("scaled", len(scaled), "ingredients")
    return scaled

```

### 연습 D4A12
- 파일: `app/plans/plan_card.py` (12행)
- 할 일: 바뀐 한 줄을 규칙대로 고쳐 보세요.
- 확인: 고친 줄이 돌 때 `to_date_text` 쪽을 거칩니다
- 고칠 줄: `bill_on = next_bill.strftime("%Y-%m-%d")`
- 예시 답: `bill_on = to_date_text(next_bill)`
- 노트가 짚은 팀 규칙: 날짜를 글자로 만들 때는 `to_date_text`를 쓰라는 규칙이 있는데, 새 줄은 `strftime("%Y-%m-%d")`로 직접 만들었습니다. 바로 위 `since` 줄은 `to_date_text`를 쓰고 있어 두 줄의 방식이 서로 다릅니다.
- 돌려 보는 호출(첫 파일 끝에서): `plan_card({"name": "Basic", "started": datetime(2026, 9, 1, tzinfo=timezone.utc), "cycle_days": 30})`
- 파일 전체(바뀐 뒤):
```
from datetime import datetime, timedelta, timezone

from app.date_text import to_date_text
from app.log import log


def plan_card(plan):
    started = plan["started"]
    card = [plan["name"], "since " + to_date_text(started)]
    cycle = timedelta(days=plan["cycle_days"])
    next_bill = started + cycle
    bill_on = next_bill.strftime("%Y-%m-%d")
    card.append("next bill " + bill_on)
    log.info("plan card:", plan["name"])
    return card

```

### 연습 D4A16
- 파일: `src/support/chatWidget.js` (9행)
- 할 일: 바뀐 한 줄을 규칙대로 고쳐 보세요.
- 확인: 고친 줄이 돌 때 `config` 쪽을 거칩니다
- 고칠 줄: `const chatKey = process.env.CHAT_KEY;`
- 예시 답: `const chatKey = config.CHAT_KEY;`
- 노트가 짚은 팀 규칙: 설정 값은 `process.env`를 바로 읽지 말고 `config`에서 읽는 것이 규칙인데, 새 코드는 `process.env.CHAT_KEY`를 바로 읽습니다. 같은 파일의 `config.API_URL`과 방식이 다릅니다.
- 돌려 보는 호출(첫 파일 끝에서): `chatWidgetSettings('product')`
- 파일 전체(바뀐 뒤):
```
import { config } from '../config.js';
import { log } from '../log.js';

const HIDDEN_PAGES = ['checkout', 'login'];

export function chatWidgetSettings(page) {
  const apiBase = config.API_URL;
  const widget = { endpoint: apiBase + '/chat', page };
  const chatKey = process.env.CHAT_KEY;
  const ready = Boolean(chatKey);
  widget.enabled = ready && !HIDDEN_PAGES.includes(page);
  widget.keyHint = ready ? chatKey.slice(0, 4) : '';
  log.info('chat widget on', page, widget.enabled);
  return widget;
}

```

## 출력

JSON 하나만 ```json 블록으로 쓴다. 갈래마다 본 답을 먼저, 예비를 마지막에 둔다(`"reserve": true`):
{"<연습 id>": [{"kind": "keep|break|broken|off", "line": "…", "reserve": false}, … 10개], …}
