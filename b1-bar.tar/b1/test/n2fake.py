"""tool test only: a synthetic N2 writer answer for one label's picks (no model)."""
import json, sys
S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1"
J, label = sys.argv[1], sys.argv[2]
picks = json.load(open(f"{J}/{label}/picks.json"))["picks"]
out = {}
for p in picks:
    d, py = p["drill"], p["drill"]["file"].endswith(".py")
    c = (lambda t: f"  # {t}") if py else (lambda t: f" // {t}")
    zz = "zz_undefined" if py else "zzUndefined"
    off = "zz_off = 1" if py else "const zzOff = 1"
    rows = [{"kind": "keep", "line": d["example"] + c("a"), "reserve": False}, {"kind": "keep", "line": d["example"] + c("b"), "reserve": False},
            {"kind": "break", "line": d["line"] + c("x"), "reserve": False}, {"kind": "break", "line": d["line"] + c("y"), "reserve": False},
            {"kind": "broken", "line": d["example"].rstrip(";") + " + " + zz, "reserve": False}, {"kind": "off", "line": off, "reserve": False},
            {"kind": "keep", "line": d["example"] + c("r"), "reserve": True}, {"kind": "break", "line": d["line"] + c("r"), "reserve": True},
            {"kind": "broken", "line": "ㄱㄷ셔구", "reserve": True}, {"kind": "off", "line": off, "reserve": True}]
    out[p["id"]] = rows
print("```json\n" + json.dumps(out, ensure_ascii=False, indent=1) + "\n```")
