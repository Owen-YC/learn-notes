import { expect, mock, test } from 'claude-code/testing'
const USAGE = { input_tokens: 1, output_tokens: 0, cache_read_input_tokens: 0, cache_creation_input_tokens: 0 }
test('g6tap sends each frozen line as it is, one at a time, and keeps no text', async ($, on) => {
  const files = new Map<string, string>()
  files.set('/w/l.jsonl', [JSON.stringify({ id: 'A', model: 'sonnet', system: 'S', prompt: 'key sk-ant-api03-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA', maxTokens: 900, timeoutMs: 90000 }), JSON.stringify({ id: 'B', model: 'sonnet', system: 'S', prompt: 'P', maxTokens: 900, timeoutMs: 90000 })].join('\n'))
  const asked: string[] = []
  let running = 0, most = 0
  const clock = mock.clock(on, { now: 1 })
  on('fs.read', (_$, e) => ({ value: files.get(e.path) ?? '' }))
  on('fs.exists', (_$, e) => ({ value: files.has(e.path) }))
  on('fs.write', (_$, e) => { files.set(e.path, e.text); return { value: undefined } })
  on('command.register', (_$, e) => ({ value: { command: e.name } }))
  on('session.start', (_$, e) => ({ cwd: e.cwd }))
  on('model.complete', async (_$, e) => { asked.push(e.prompt); running++; most = Math.max(most, running); await clock.sleep(5); running--; return { value: e.prompt === 'P' ? { isAnswered: true as const, text: 'secret text', usage: USAGE } : { isAnswered: false as const, reason: 'empty-reply' as const, usage: USAGE } } })
  await $.session.start({ cwd: '/w', surface: 'terminal', isInteractive: false })
  const run = $.command.run({ command: 'g6tap', args: '/w/l.jsonl /w/s.json', origin: { kind: 'composer' }, presentation: { isFullscreen: false, columns: 80 } })
  await clock.advance(50); await clock.settle()
  await run
  expect(asked[0]).toContain('sk-ant-api03')
  expect(most).toBe(1)
  const sent = files.get('/w/s.json')!
  expect(sent).not.toContain('secret text')
  expect(JSON.parse(sent).results.map((r: { id: string; reason?: string }) => r.reason ?? 'answered')).toEqual(['empty-reply', 'answered'])
})
