#!/bin/bash
# tool test only: cli/pinned.sh with the fake claude first on PATH; --record prints the pinned record (FAKE_PIN_BAD changes one sha).
export DISABLE_AUTOUPDATER=1
export PATH="/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1/test/bin:$PATH"
if [ "$1" = "--record" ]; then
  echo "version: $(claude --version)"
  echo "${FAKE_PIN_BAD:-604d29a6869409106b6a1110bdadcc8b72e8654a5a865d23258f938a696e348e}  claude"
  echo "d2bc14daa55dcae7e85e5e0a7f80fb9c5de4572e9b3bfe28b6f11d89cba45a9e  claude.hot"
  exit 0
fi
exec "$@"
