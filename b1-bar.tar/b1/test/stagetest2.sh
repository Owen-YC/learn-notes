#!/bin/bash
# tool test only: the 10% api-error line and the pre-N numbering of tools/stage.sh (fake claude, no model call).
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1
source <(sed -n '/^mk()/,/^}/p' "$S/test/stagetest.sh")
eval "$(grep '^export FAKE_ID' "$S/test/stagetest.sh")"
export FAKE_TEXTS="$S/test/st-texts.json"
mk api7; FAKE_SPEC='{"D4A01":"api","D4A02":"api","D4A03":"api","D4A04":"api","D4A05":"api","D4A06":"api","D4A07":"api"}' ONLY_WORKFLOW=1 "$R/stage.sh" A haiku > "$R.log" 2>&1; echo "api 7: exit $? (expect 6)"; tail -2 "$R.log"
mk pren; FAKE_FIVE=0.9 ONLY_WORKFLOW=1 "$R/stage.sh" A haiku > /dev/null 2>&1; FAKE_FIVE=0.9 ONLY_WORKFLOW=1 "$R/stage.sh" A haiku > /dev/null 2>&1; ls "$R/stage/A/haiku"
mk cap; FAKE_SPEC='{"D4A01":"cap","D4A02":"empty"}' ONLY_WORKFLOW=1 "$R/stage.sh" A haiku > "$R.log" 2>&1; echo "cap/empty: exit $? (expect 0)"; tail -1 "$R.log"
