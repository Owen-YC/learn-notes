"""tool test only (no model): check.py and judge.py edge cases on dev set4 samples changed by hand."""
import copy, json, os, sys
S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1"
os.environ["NAMES_FILE"] = f"{S}/test/t1/empty-names.txt"
sys.path.insert(0, f"{S}/tools")
import check as C
import judge as JG
import runlib as R
raw = {s["id"]: s for s in json.load(open("/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/design/G6/dev/set4/raw.json"))}
ok = fails = 0
def expect(name, cond):
    global ok, fails
    ok += cond; fails += not cond
    print(("PASS " if cond else "FAIL ") + name)
# check.py
s = copy.deepcopy(raw["D4A01"]); expect("check: a good R sample passes", C.check(s) == [])
s = copy.deepcopy(raw["D4A01"]); s["expected"] = s["expected"] + ["more"]; expect("check: expected differs -> fails", any("expected differs" in e for e in C.check(s)))
s = copy.deepcopy(raw["D4A01"]); f = s["files"][0]; f["after"] = f["after"].replace("\n", "\n// console.log('x')\n", 1); expect("check: a marker in a comment of an R sample -> fails", any("marker line not in violations" in e for e in C.check(s)))
s = copy.deepcopy(raw["D4B09"]); expect("check: F with a marker only inside a string passes (S-c)", C.check(s) == [])
s = copy.deepcopy(raw["D4B09"]); s["kind"] = "N"; expect("check: the same as N fails (the exemption is F's alone)", any("marker line not in violations" in e for e in C.check(s)))
s = copy.deepcopy(raw["D4B05"]); s["kind"] = "R"; expect("check: an R line over 40 fails", any("over 40" in e for e in C.check(s)))
s = copy.deepcopy(raw["D4A01"]); s["kind"] = "R_long"; expect("check: an R_long line <= 40 fails", any("not over 40" in e for e in C.check(s)))
s = copy.deepcopy(raw["D4A01"]); f = s["files"][0]; f["after"] = "\n".join(l for l in f["after"].split("\n") if "apiRequest.js" not in l); expect("check: no import of the module fails", any("does not import" in e for e in C.check(s)))
s = copy.deepcopy(raw["D4A01"]); v = s["violations"][0]; v["fix"] = v["line"].replace("fetch(", "apiRequest || fetch("); expect("check: a fix that keeps a marker fails", any("fix bad" in e for e in C.check(s)))
os.environ["NAMES_FILE"] = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/NAMES-all.txt"
import importlib; C2 = importlib.reload(C)
s = copy.deepcopy(raw["D4A01"]); expect("check: a dev file path fails (NAMES-all)", any("dev path" in e for e in C2.check(s)))
# judge.py on round A rows of the test labels
rows = json.load(open(f"{S}/test/t1/judge/P/read2-A.json")); samples = {x["id"]: x for x in json.load(open(f"{S}/test/t1/frozen/samples.json"))}
sid = next(k for k, r in rows.items() if r.get("answered") and r.get("tier") == 1 and r.get("drillOn"))
row, d = rows[sid], rows[sid]["drillOn"]
j = JG.judge_rule(samples[sid], row, d); expect(f"judge: the tier-1 practice {sid} is correct", j["correct"] and not j["harm"])
bad = dict(d, example=d["line"] + " && " + d["example"]); j = JG.judge_rule(samples[sid], row, bad); expect("judge: an example keeping the marker -> h3, not correct", "h3" in j["harm"] and not j["correct"])
bad = dict(d, check="고친 줄이 돌 때 `log.info` 쪽을 거칩니다"); j = JG.judge_rule(samples[sid], row, bad); expect("judge: a check naming another rule's stub not called -> (vi) false", not j["correct"] and "(vi)" in (j["why"] or ""))
bad = dict(d, check=""); j = JG.judge_rule(samples[sid], row, bad); expect("judge: no check line -> not correct", not j["correct"])
bad = dict(d, check="`" + samples[sid]["demo"] + "` → 같은 결과가 나옵니다"); j = JG.judge_rule(samples[sid], row, bad)
expect("judge: a same-words claim on the demo call is decided by running (the output changes? then false)", "(vi)" in (j["why"] or "") or j["correct"])
trap = next(k for k, x in samples.items() if x["kind"] == "trap")
tr = dict(rows[trap]) if rows.get(trap, {}).get("answered") else None
if tr is not None:
    fake = dict(d, file=samples[trap]["files"][0]["path"], n=1, line=samples[trap]["files"][0]["after"].split("\n")[0])
    j = JG.judge_rule(samples[trap], tr, fake); expect("judge: a rule practice on a trap -> harmful (h2 or undecided)", bool(j["harm"]))
res = JG.judge({sid: dict(row, tasksOn=[2])}, {sid: samples[sid]}); expect("judge: two task lines counted", res["c"]["twoTask"] == [sid])
r2 = dict(row, drillOff=dict(d, rule=None)); res = JG.judge({sid: r2}, {sid: samples[sid]}); expect("judge: an unmarked practice bringing a use name in -> unlabelled", res["c"]["unlabelled"] == [f"{sid}:drillOff"])
o = next(k for k, r in rows.items() if r.get("answered") and not r["isL"]); r3 = dict(rows[o], on=rows[o]["on"] + "x"); res = JG.judge({o: r3}, {o: samples[o]}); expect("judge: O note text differing ON/OFF -> (c) bad", len(res["c"]["c_bad"]) == 1)
print(f"{ok} pass, {fails} fail")
sys.exit(1 if fails else 0)
