#!/bin/bash
# tool test only: tools/stage.sh with the fake claude (test/bin/claude) in a test root; no model call.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1
G=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/design/G6
mk() { # mk <name> : a fresh test root
  R="${S:?}/test/st/$1"; rm -rf "${R:?}"; mkdir -p "$R/frozen" "$R/stage"
  cp "$S/test/t1/frozen/samples.json" "$S/test/t1/frozen/hunks.json" "$S/test/t1/frozen/note-lines-haiku.jsonl" "$S/test/t1/frozen/note-lines-sonnet.jsonl" "$R/frozen/"
  ln -s "$S/tools" "$R/tools"; ln -s "$S/probe" "$R/probe"; ln -s "$S/d34" "$R/d34"
  sed "s#^S=.*#S=$R#; s#^P=.*#P=$S/test/pinned-fake.sh#" "$S/tools/stage.sh" > "$R/stage.sh"; chmod +x "$R/stage.sh"
  export FROZEN="$R/frozen"
}
export FAKE_ID_HAIKU="$(python3 -c "import json;print(json.load(open('/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b0/calib/pre/haiku-2/record.json'))['inits'][0])")"
export FAKE_ID_SONNET="$(python3 -c "import json;print(json.load(open('/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b0/calib/pre/sonnet-1/record.json'))['inits'][0])")"
python3 -c "
import json
d={r['id']:r['text'] for r in json.load(open('$G/pilot/set4/note/haiku/out.json'))['results'] if r.get('isAnswered')}
json.dump(d,open('$S/test/st-texts.json','w'))"
export FAKE_TEXTS="$S/test/st-texts.json"
t() { echo "== $1: expect $2"; shift 2; "$@" > "$R.log" 2>&1; echo "exit $?"; grep -E "^(STOP|WAIT|VOID|THREW|DONE|refuse|not started|CUT)" "$R.log" | head -3; }
mk ok
ONLY_WORKFLOW=1 t "A haiku" "DONE (projection 0.20+0.40)" "$R/stage.sh" A haiku
cat "$R/stage/A/haiku/summary.json" | head -c 400; echo; ls "$R/stage/A/haiku"; cat "$R/stage/A/haiku/d34/result.json" | head -c 200; echo
ONLY_WORKFLOW=1 t "A haiku again" "refuse STARTED" "$R/stage.sh" A haiku
ONLY_WORKFLOW=1 t "B haiku before A sonnet" "refuse" "$R/stage.sh" B haiku
t "A sonnet no attestation" "exit 2" "$R/stage.sh" A sonnet
FAKE_FIVE=0.7 ONLY_WORKFLOW=1 t "A sonnet five 0.70" "WAIT exit 7" "$R/stage.sh" A sonnet; grep WAIT "$R.log"; ls "$R/stage/A/sonnet"
FAKE_SEVEN=0.5 ONLY_WORKFLOW=1 t "A sonnet seven 0.50 (no projection)" "DONE" "$R/stage.sh" A sonnet
ONLY_WORKFLOW=1 t "N2-1 haiku no lines" "exit 2" "$R/stage.sh" N2-1 haiku
mk proj; FAKE_SEVEN=0.45 ONLY_WORKFLOW=1 t "A haiku seven 0.45 + 0.40" "WAIT" "$R/stage.sh" A haiku
mk ver; FAKE_VERSION="2.1.325 (Claude Code)" ONLY_WORKFLOW=1 t "version drift" "STOP exit 3" "$R/stage.sh" A haiku; ls "$R/stage/A/haiku"
mk pin; FAKE_PIN_BAD=0000 ONLY_WORKFLOW=1 t "pinned sha differs" "STOP exit 3" "$R/stage.sh" A haiku
mk drift; FAKE_DRIFT=1 ONLY_WORKFLOW=1 t "id drift in probe session" "VOID exit 4" "$R/stage.sh" A haiku
mk api; FAKE_SPEC='{"D4A01":"api","D4A02":"api","D4A03":"api","D4A04":"api","D4A05":"api"}' ONLY_WORKFLOW=1 t "api errors 5/42+" "VOID exit 6" "$R/stage.sh" A haiku
mk threw; FAKE_SPEC='{"D4A03":"threw"}' ONLY_WORKFLOW=1 t "threw" "THREW exit 5" "$R/stage.sh" A haiku
