import { expect, mock, test } from 'claude-code/testing'

const USAGE = { input_tokens: 1, output_tokens: 7, cache_read_input_tokens: 0, cache_creation_input_tokens: 0 }

test('g6probe calls each line as askModel does, 4 at a time, writes every reply through fixEscapedTicks, and a status line per call (no text)', async ($, on) => {
  const files = new Map<string, string>()
  const lines = [0, 1, 2, 3, 4, 5].map(i => JSON.stringify({ id: `L${i}`, model: i % 2 ? 'sonnet' : 'haiku', system: `S${i}`, prompt: i === 0 ? 'key sk-ant-api03-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA end' : `P${i}`, maxTokens: 3500, timeoutMs: 90000 }))
  files.set('/w/lines.jsonl', lines.join('\n') + '\n')
  const asked: { model: string; effort: unknown; system: unknown; prompt: string; maxTokens: unknown; timeoutMs: unknown }[] = []
  const statusSeen: number[] = []
  let running = 0
  let most = 0
  const clock = mock.clock(on, { now: 1000 })
  on('fs.read', (_$, e) => ({ value: files.get(e.path) ?? '' }))
  on('fs.exists', (_$, e) => ({ value: files.has(e.path) }))
  on('fs.write', (_$, e) => {
    if (e.path === '/w/status.jsonl') {
      const before = files.get(e.path) ?? ''
      expect(e.text.startsWith(before)).toBe(true)
      statusSeen.push(e.text.split('\n').filter(Boolean).length)
    }
    files.set(e.path, e.text)
    return { value: undefined }
  })
  on('command.register', (_$, e) => ({ value: { command: e.name } }))
  on('session.start', (_$, e) => ({ cwd: e.cwd }))
  on('model.complete', async (_$, e) => {
    asked.push({ model: e.model, effort: e.effort, system: e.system, prompt: e.prompt, maxTokens: e.maxTokens, timeoutMs: e.timeoutMs })
    running++
    most = Math.max(most, running)
    await clock.sleep(10)
    running--
    if (e.system === 'S3') return { value: { isAnswered: false as const, reason: 'api-error' as const, status: 529, error: 'overloaded' as const, usage: USAGE } }
    if (e.system === 'S4') return { value: { isAnswered: false as const, reason: 'empty-reply' as const, usage: USAGE } }
    if (e.system === 'S5') return { deny: 'blocked' }
    return { value: { isAnswered: true as const, text: 'see `return \\`hi\\``', usage: USAGE } }
  })
  await $.session.start({ cwd: '/w', surface: 'terminal', isInteractive: false })
  const run = $.command.run({ command: 'g6probe', args: '/w/lines.jsonl /w/out.json /w/status.jsonl', origin: { kind: 'composer' }, presentation: { isFullscreen: false, columns: 80 } })
  await clock.advance(100)
  await clock.settle()
  const said = await run
  const out = JSON.parse(files.get('/w/out.json')!)
  expect(out.results.map((r: { id: string }) => r.id)).toEqual(['L0', 'L1', 'L2', 'L3', 'L4', 'L5'])
  expect(asked.map(a => a.model)).toEqual(['haiku', 'sonnet', 'haiku', 'sonnet', 'haiku', 'sonnet'])
  expect(asked.every(a => a.effort === 'low' && a.maxTokens === 3500 && a.timeoutMs === 90000)).toBe(true)
  expect(asked[0]!.prompt).toContain('«가림»')
  expect(asked[0]!.prompt).not.toContain('sk-ant-api03')
  expect(asked[1]!.prompt).toBe('P1')
  expect(most).toBe(4)
  expect(out.results[0].text).toBe('see `` return `hi` ``')
  expect(out.results[3]).toMatchObject({ isAnswered: false, reason: 'api-error', status: 529 })
  expect(out.results[4]).toMatchObject({ isAnswered: false, reason: 'empty-reply' })
  expect(out.results[5].threw).toBeDefined()
  const status = files.get('/w/status.jsonl')!.split('\n').filter(Boolean).map(l => JSON.parse(l))
  expect(status.map(s => s.id).sort()).toEqual(['L0', 'L1', 'L2', 'L3', 'L4', 'L5'])
  expect(status.find(s => s.id === 'L3')).toMatchObject({ answered: false, reason: 'api-error', status: 529, output_tokens: 7 })
  expect(status.find(s => s.id === 'L5')).toMatchObject({ answered: false, reason: 'threw' })
  expect(files.get('/w/status.jsonl')).not.toContain('hi')
  expect(statusSeen).toEqual([1, 2, 3, 4, 5, 6])
  expect(JSON.stringify(said)).toContain('G6PROBE done 6')
  expect(JSON.stringify(said)).not.toContain('hi')
  const again = await $.command.run({ command: 'g6probe', args: '/w/lines.jsonl /w/out.json /w/status2.jsonl', origin: { kind: 'composer' }, presentation: { isFullscreen: false, columns: 80 } })
  expect(JSON.stringify(again)).toContain('G6PROBE refuse')
})
