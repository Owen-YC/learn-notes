"""A local pass-through tap (record only, B-12; SCOPE's batch-3 fact): listens on 127.0.0.1:<port>, forwards each
request to <upstream> byte for byte (path, query, body; headers but the hop-by-hop ones and Accept-Encoding, so the
answer comes back plain), streams the answer back as it arrives, and writes one JSON line per request to <log>:
the request's shape (method, path, model, max_tokens, stream, top-level keys, thinking/effort fields, system and each
user text block's length and sha256, message count) and the answer's status, stop_reason, stop_details and
output_tokens (from the SSE message_delta / message_start events, or a JSON body). Never a header, a key, a token or
any text: only lengths and sha256.

usage: tap.py <port> <log.jsonl> <upstream base url>
"""
import gzip
import hashlib
import http.client
import http.server
import json
import os
import ssl
import sys
import threading
import time
import urllib.parse

PORT = int(sys.argv[1])
LOG = sys.argv[2]
UP = urllib.parse.urlsplit(sys.argv[3].rstrip("/"))
HOP = {"connection", "keep-alive", "proxy-authenticate", "proxy-authorization", "te", "trailers", "transfer-encoding",
       "upgrade", "host", "accept-encoding", "content-length"}
LOCK = threading.Lock()


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def shape_of(body, encoding):
    raw = body
    try:
        if (encoding or "").lower() == "gzip":
            raw = gzip.decompress(body)
        d = json.loads(raw.decode("utf-8"))
    except Exception:
        return {"parsed": False, "bytes": len(body)}
    if not isinstance(d, dict):
        return {"parsed": True, "kind": type(d).__name__}
    system = d.get("system")
    if isinstance(system, list):
        sys_text = "".join(b.get("text", "") for b in system if isinstance(b, dict))
    else:
        sys_text = system if isinstance(system, str) else ""
    users = []
    for m in d.get("messages") or []:
        if not isinstance(m, dict) or m.get("role") != "user":
            continue
        c = m.get("content")
        blocks = [{"type": "text", "text": c}] if isinstance(c, str) else (c if isinstance(c, list) else [])
        for b in blocks:
            if isinstance(b, dict) and b.get("type") == "text":
                users.append({"chars": len(b.get("text", "")), "sha256": sha(b.get("text", ""))})
    out = {"parsed": True, "model": d.get("model"), "max_tokens": d.get("max_tokens"), "stream": d.get("stream"),
           "keys": sorted(d.keys()), "messages": len(d.get("messages") or []),
           "system": {"chars": len(sys_text), "sha256": sha(sys_text)}, "user_texts": users}
    for key in ("thinking", "output_config", "effort"):
        if key in d:
            out[key] = d[key] if not isinstance(d[key], str) or len(d[key]) < 40 else "…"
    return out


class Tap(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def _forward(self):
        started = time.time()
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else b""
        rec = {"t": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "method": self.command,
               "path": urllib.parse.urlsplit(self.path).path, "request": shape_of(body, self.headers.get("Content-Encoding"))}
        headers = {k: v for k, v in self.headers.items() if k.lower() not in HOP}
        headers["Host"] = UP.netloc
        if UP.scheme == "https":
            ctx = ssl.create_default_context()
            for ca in (os.environ.get("SSL_CERT_FILE"), "/root/.ccr/ca-bundle.crt"):
                if ca and os.path.exists(ca):
                    try:
                        ctx.load_verify_locations(ca)
                    except Exception:
                        pass
            proxy = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")
            if proxy:
                p = urllib.parse.urlsplit(proxy)
                conn = http.client.HTTPSConnection(p.hostname, p.port or 80, context=ctx, timeout=300)
                auth = {}
                if p.username:
                    import base64
                    auth["Proxy-Authorization"] = "Basic " + base64.b64encode(f"{urllib.parse.unquote(p.username)}:{urllib.parse.unquote(p.password or '')}".encode()).decode()
                conn.set_tunnel(UP.hostname, UP.port or 443, headers=auth)
            else:
                conn = http.client.HTTPSConnection(UP.hostname, UP.port or 443, context=ctx, timeout=300)
        else:
            conn = http.client.HTTPConnection(UP.hostname, UP.port or 80, timeout=300)
        target = (UP.path or "") + self.path
        stop = {"stop_reason": None, "stop_details": None, "output_tokens": None, "error_type": None}
        try:
            conn.request(self.command, target, body=body if body else None, headers=headers)
            resp = conn.getresponse()
            rec["status"] = resp.status
            self.send_response(resp.status)
            for k, v in resp.getheaders():
                if k.lower() not in HOP:
                    self.send_header(k, v)
            self.send_header("Transfer-Encoding", "chunked")
            self.send_header("Connection", "close")
            self.end_headers()
            is_sse = "text/event-stream" in (resp.getheader("Content-Type") or "")
            buf = b""
            whole = b""
            while True:
                chunk = resp.read1(65536) if hasattr(resp, "read1") else resp.read(65536)
                if not chunk:
                    break
                self.wfile.write(f"{len(chunk):x}\r\n".encode() + chunk + b"\r\n")
                self.wfile.flush()
                if is_sse:
                    buf += chunk
                    while b"\n" in buf:
                        line, buf = buf.split(b"\n", 1)
                        self._sse(line, stop)
                else:
                    whole += chunk
            if is_sse and buf:
                self._sse(buf, stop)
            self.wfile.write(b"0\r\n\r\n")
            self.wfile.flush()
            if not is_sse:
                try:
                    d = json.loads(whole.decode("utf-8"))
                    if isinstance(d, dict):
                        stop["stop_reason"] = d.get("stop_reason")
                        stop["stop_details"] = d.get("stop_details")
                        stop["output_tokens"] = (d.get("usage") or {}).get("output_tokens")
                        if d.get("type") == "error":
                            stop["error_type"] = (d.get("error") or {}).get("type")
                except Exception:
                    pass
        except Exception as err:
            rec["tap_error"] = type(err).__name__
            try:
                self.send_error(502)
            except Exception:
                pass
        finally:
            conn.close()
        rec.update(stop)
        rec["ms"] = int((time.time() - started) * 1000)
        with LOCK:
            with open(LOG, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    @staticmethod
    def _sse(line, stop):
        line = line.strip()
        if not line.startswith(b"data:"):
            return
        try:
            d = json.loads(line[5:].strip().decode("utf-8"))
        except Exception:
            return
        kind = d.get("type")
        if kind == "message_start":
            u = ((d.get("message") or {}).get("usage") or {}).get("output_tokens")
            if u is not None:
                stop["output_tokens"] = u
        elif kind == "message_delta":
            delta = d.get("delta") or {}
            if "stop_reason" in delta:
                stop["stop_reason"] = delta.get("stop_reason")
            if "stop_details" in delta:
                stop["stop_details"] = delta.get("stop_details")
            u = (d.get("usage") or {}).get("output_tokens")
            if u is not None:
                stop["output_tokens"] = u
        elif kind == "error":
            stop["error_type"] = (d.get("error") or {}).get("type")

    do_POST = _forward
    do_GET = _forward
    do_PUT = _forward
    do_DELETE = _forward
    do_PATCH = _forward


class Server(http.server.ThreadingHTTPServer):
    daemon_threads = True


if __name__ == "__main__":
    srv = Server(("127.0.0.1", PORT), Tap)
    print(f"tap listening 127.0.0.1:{PORT}", flush=True)
    srv.serve_forever()
