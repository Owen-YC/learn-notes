너는 번역 확인자다. 아래 '원문'(설계 파일 G6의 bar · stance · decisionRule · samples · calls · risks · perModel · ownerQuestions 필드, 그리고 계획 묶음 1의 barSource · samples · calls · judges · stop 필드; 영어와 한국어)과 '옮긴 글'(docs/qa/견본.md에 넣을 한국어 절)을 견준다. 코드를 돌릴 수 없고 다른 파일도 없다.

확인할 것:
1. 원문의 모든 수(개수, 비율, 토큰, 밀리초, 문턱, id, 커밋, sha256 앞자리 등)가 옮긴 글에 같은 값으로 있는가.
2. 원문의 모든 조항 · 조건 · 예외 · 미리 정한 경계 꼴이 빠짐없이, 뜻을 바꾸지 않고(더 너그럽게도, 더 엄하게도 아니게) 옮겨졌는가. 특히 bar의 줄마다, decisionRule의 줄마다, stance의 줄마다(stance는 글자 그대로 옮겼다고 적혀 있으니 글자까지).
3. 옮긴 글이 원문에 없는 조건을 기준이나 결정에 더했는가. 단, 옮긴 글이 '이 묶음이 정한 것', '읽는 법', '기록', '도구가 글을 읽는 방식', '1.10.0 기준과 다른 점', '다시 커밋하는 1.10.0 입장 / 세부'로 따로 표시한 곳은 원문 밖의 기록으로 보고, 그것이 원문과 어긋나는지만 본다.
4. 원문끼리(설계와 계획) 어긋나는 곳이 있으면 적고, 옮긴 글이 더 엄한 쪽을 따랐는지 본다.

출력: JSON 하나만 ```json 블록으로. 문제가 없으면 빈 배열. 
[{"where": "<옮긴 글의 자리>", "source": "<원문 필드와 줄>", "kind": "number|clause-missing|clause-changed|added|conflict|other", "detail": "<무엇이 어떻게 다른지, 한두 문장>", "fix": "<고칠 글 제안>"}]

## 원문 (JSON)

```json
{
 "design": {
  "bar": [
   "SOURCE: docs/qa/견본.md '1.10.0 팀 규칙 연습 (G6)' > '기준 · 입장 · 결정 규칙' (432ced4) — every line kept, none narrowed or relaxed; den is the full committed den. Each model: two independent rounds A and B on the same fresh frozen samples; BOTH rounds must pass every N1′ line. Applied per model, never combined or transferred.",
   "N1′ (a): O ≥ 20 and rule practices on O notes = 0.",
   "N1′ (b): den = L notes whose sample has a violations line of ≤ 40 characters (indent excluded); den ≥ 20; correct rule practices (§6 (i)–(vi), all required) ≥ 80% of den (a den note where code made no practice — skip, `줄: 없음`, a rejected reply, a failed call — is not correct); harmful practices (§10 h1–h4) = 0 over ALL answered notes; notes with two task lines = 0 in BOTH the ON and the OFF reading over all answered notes.",
   "N1′ (c): O notes — the note prompt is byte-identical ON/OFF (test + D34), no practice call on any O note (call log), and each O note's final text is byte-identical between the ON and OFF readings.",
   "Traps: rule practices = 0 on the committed 7 (rule module ×4, tests ×2, build script ×1) plus the 2 added (an exporting non-stem module, a *.config.* file): 9.",
   "R_long and L notes with no ≤ 40-char violating line (F · N · trap): rule practices = 0 (the note's own concept practice allowed, as OFF).",
   "Unlabelled rule practice (§9): 0 in both the ON and the OFF reading.",
   "Rule-drill no-answer (cap hit output_tokens ≥ 3500 + H_M from the 1.12.0 calibration, empty reply incl. API refusal, timeout) ≤ max(1, ⌊n/60⌋), n = tier-2 calls over both rounds of that model. API errors counted, not re-sent (§2).",
   "Old windows (calls 0): 3f2b4fb · 7a7b08c · 3690021 · fca5988 (committed) plus 3d2f251 · de98243 (added, stricter): for every marked final text (ON and OFF) drillOf gives no practice and hideDrillAnswer shows no `고칠 줄` / `예시 답` line; for every unmarked text each window gives the same task · line · example · file · row as 3d2f251's reading.",
   "W (gate for isRuleDrill only, see decisionRule): §11 W false positives = 0 in the OFF reading of both rounds, and keptNoteText idempotent on every reply.",
   "N2 (grading bytes unchanged at 1.9.0, rule19): new second-stage samples per label from that model's round A (pick.py: 5 correct practices, all 4 rules, py ≥ 1, ts ≥ 1; an unfillable condition dropped and recorded; < 5 correct → N2 fails); 30 answers (2 keep · 2 break · 1 broken · 1 off per practice); graded twice as gradeDrill grades (480 tokens, 60000 ms). Each run: correct verdicts ≥ 27/30, break→맞음 ≤ 1, broken→맞음 = 0, missing `규칙:` line ≤ 1 (a dropped answer shrinks the denominator but 27 correct are still required).",
   "Records only (never in the decision, S-d): tier per note, skip reasons, tier-2 fault-code histogram per label, candidate counts, 1.9.0-definition (b), the 1.10.0-style breakdown of den misses, output tokens/time, the strict-S1 replacement count, drill calls per L note, refusals column."
  ],
  "stance": {
   "공통 (1.10.0 입장 §0–§15와 세부 1–24를 그대로 다시 커밋하고, 아래만 바꾸거나 더함)": [
    "§0 · §15 그대로: 판정 스크립트를 이 글대로 먼저 짓고 sha256을 바 커밋에 적습니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 견본.md '다시 잴 때'에 적습니다. 판정 파일을 쓴 뒤에는 입장 · 열쇠 · 기준을 바꾸지 않습니다.",
    "§1 (바꿈) 켠 읽기: 노트 답 → fixEscapedTicks → keptNoteText(답, names) → noteRuleOf가 읽히면 그 판 트리의 ruleFixPlan(screened, rules, 그 줄). 1단이면 ruleFixMade(글, fix, changes) ?? 글, 2단이면 RULE_DRILL_SYSTEM · redactText(ruleDrillPrompt(screened, rules, 그 줄, cands)) · 3500 · 90000으로 부르고 fixEscapedTicks → ruleFixReply가 받은 글 ?? 글, 건너뜀이면 글 그대로. 끈 읽기: 같은 노트 답의 keptNoteText 글 그대로.",
    "§2 그대로: 노트 호출이 답하지 않은 견본은 그 회 L · O에서 빼고 수만 적습니다. 규칙 연습 호출의 상한 닿음 · 빈 답(API 거절 포함) · 시간 한도는 '답 없음' 줄에 셉니다(n = 그 모델 두 회의 2단 호출 수). 닿았어도 글이 읽히면 읽힌 대로 매깁니다. 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.12.0 보정).",
    "§3 · §4 · §5 · §6 · §8 · §9 · §10 · §11 · §12 · §13 그대로(채점 열쇠 §5는 같은 팀 파일에서 나온 그대로).",
    "§14 (더함, 엄격하게): 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988에 3d2f251 · de98243을 더한 여섯입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다."
   ],
   "확인 줄 (S-a, §7에 더함)": [
    "켠 판의 확인 줄은 코드가 쓴 '고친 줄이 돌 때 `U` 쪽을 거칩니다' 하나뿐입니다. 세부 6: 코드 칸에 호출이 없으므로 견본 demo를 돌립니다. 세부 8: 쓰라는 이름 하나만 든 코드 칸은 값이 아닙니다. 세부 10: 효과 말이며 U의 규칙이 그 규칙입니다.",
    "효과 주장은 줄 단위로 매깁니다: 그 줄만 예시 답으로 바꾼 파일로 demo를 돌린 기록에 그 규칙 대역 줄(`[apiRequest] ` · `[log.info] ` · `[toDateText] ` · `[config] `로 시작)이, 원래 줄 그대로 돌린 기록보다 많아야 참입니다(파일이 다른 줄에서 이미 대역을 부르는 경우를 가름). 같으면 거짓입니다.",
    "확인 줄이 이 꼴이 아닌 규칙 연습(켠 창에서 읽히지 않으므로 나올 수 없음)이 나오면 1.10.0 §7 그대로 매깁니다."
   ],
   "견본 (S-c)": [
    "얼리기 전: violations마다 fix로 바꾼 demo가 원래 demo보다 그 규칙 대역 줄을 더 많이 써야 합니다(엄격한 S1). 못 넘은 견본은 같은 무리 예비로 id 차례대로 채우고 고쳐 쓰지 않으며, 바뀐 수를 견본.md에 무리마다 적습니다(모집단 기록). 개발 견본 1–4의 짧은 어긴 줄 92개에서는 0개였습니다.",
    "F 견본에서 표지 글자가 문자열 글자나 주석 안에만 있는 줄은 어긴 줄이 아닙니다(F의 정해진 꼴). 그 줄에 규칙 연습이 나오면 h2(해로움)입니다."
   ],
   "판정 대상 (S-b)": [
    "연습은 저장된 노트 글로만 매깁니다. 1단(코드가 만든 예시 답)이든 2단(모델이 준 예시 답)이든 같은 §6 · §10을 씁니다. 1단이라고 덜 보지 않습니다.",
    "갈래 · 건너뜀 까닭 · 2단 잘못 코드는 기록만 하고 판정에 쓰지 않습니다(S-d)."
   ],
   "옛 기록과 개발 답에서 나온 경계 꼴 (미리 정함)": [
    "E1 인자를 바꾼 예시 답(`toDateText(e.endsAt)`, 줄은 `d.toLocaleDateString('en-CA')`): 표지가 없고 쓰라는 이름이 있으면 (iv)의 출력 비교가 정합니다. 출력이 expected_fixed와 같으면 바름, 다르면 바르지 않음(해롭지 않음).",
    "E2 결과에 사슬을 남긴 예시 답(`toDateText(end).slice(0, 10)`): 남은 것이 §5 표지가 아니면 h3가 아니고 (iv) 출력이 정합니다. `.slice(0, 4)`처럼 출력이 바뀌면 바르지 않음(1.12.0 개발 D1A14).",
    "E3 감싼 예시 답(`toDateText(end.toJSON())`)과 옆에 남긴 예시 답(`toDateText(d) || d.toISOString()`): 표지가 남으므로 h3. 코드가 막으므로 나오면 코드 결함이며 해로움으로 셉니다.",
    "E4 multi: 어느 violations 줄이든 짚은 규칙의 줄이면 바를 수 있습니다. 다른 규칙의 줄이면 (ii)나 (iii)에서 바르지 않고, 들인 규칙의 violations 줄이 아니면 h2입니다.",
    "E5 double(같은 규칙 둘): 둘 가운데 어느 줄이든 됩니다. 다른 한 줄의 표지가 파일에 남는 것은 예시 답의 표지가 아니므로 h3가 아니고, (iv)는 그 violation의 expected_fixed로 견줍니다.",
    "E6 `config[\"X\"]` · `config.get(\"X\")` · `Number(config.X)`: 쓰라는 이름 config를 품으므로 지킴입니다(§8 대역이 모두 받침). 확인 줄의 U는 `config`입니다.",
    "E7 os.getenv 줄(규칙 글이 이름 짓지 않은 표지): 코드가 후보로 올리지 않아 연습 없음이면 den의 바르지 않음이고 해롭지 않습니다. 연습이 나오면 보통처럼 매깁니다.",
    "E8 2단 답이 스스로 고쳐 쓴 꼴(같은 라벨에 다른 값, 'Wait —'): 코드가 받지 않아 연습 없음입니다. 판정은 저장된 글만 봅니다.",
    "E9 노트 호출이 스스로 고쳐 쓴 꼴로 직접 해 보기 칸에 할 일 줄이 둘(1.12.0 개발 D4B02 · D4B21, 끈 읽기): §13대로 할 일 줄 둘인 노트로 셉니다(두 읽기 모두, 답한 모든 노트). 이 설계가 바꿀 수 없는 끈 읽기의 일이어도 기준 줄은 그대로입니다.",
    "E10 노트 호출이 상한에 닿았지만 답한 경우(개발 D3B11 haiku 5548): 읽힌 대로 매기고 상한 닿음은 노트 호출 쪽 기록입니다(규칙 연습 '답 없음' 줄은 2단 호출만 셈).",
    "E11 켠 창에서 W2가 표지를 단 자기 칸(코드가 만들지 않은 규칙 연습): 켠 읽기에서 연습 없음입니다. 그 노트가 den이면 바르지 않음, 표지 없는 규칙 연습(§9)도 아님(개념 연습이 아니므로). 끈 읽기의 W 오탐(§11)은 그대로 셉니다.",
    "E12 1단이 만든 연습이 demo가 지나지 않는 줄에 있음: (v) · (vi)에서 거짓(효과 기록이 늘지 않음). 엄격한 S1이 견본의 열쇠 줄을 보장하므로 열쇠 줄이 아니면 (iii)에서 이미 바르지 않음입니다.",
    "E13 1단 이름 바꿈이 같은 줄의 쓰지 말라는 다른 이름을 남김: 코드가 막음. 나오면 h3.",
    "E14 확인 줄 U가 예시 답의 가장 짧은 쓰라는 이름(`config`)이고 예시 답은 `config.API_URL`: 효과 말 config로 매깁니다.",
    "E15 규칙 연습 호출 답이 `- 줄: 없음`이고 그 노트가 den: 연습 없음 → 바르지 않음, 해롭지 않음.",
    "E16 N2: 학습자 줄이 예시 답과 같거나 고칠 줄과 같으면 gradeDrill이 부르지 않으므로 n2verify가 뺍니다(세부 22). 판정 셈은 세부 23 그대로.",
    "E17 노트 글의 `다를 수 있음` 줄이 규칙 이름을 하나도 품지 않음(코드는 건너뜀): 연습 없음. den이면 바르지 않음.",
    "E18 sonnet API 거절(stop_reason refusal): 빈 답으로 '답 없음'에 셉니다. 탭 기록은 따로 적는 기록입니다."
   ],
   "N2 입장": [
    "1.9.0 · 1.10.0 N2 입장 그대로(세부 22 · 23). 문제 글의 할 일 · 확인 줄은 코드가 쓴 것이며, 채점 프롬프트의 나머지 바이트는 1.9.0과 같습니다(rule19 고정, 만든 연습의 채점 요청 고정 시험 추가)."
   ]
  },
  "decisionRule": [
   "Per model m ∈ {haiku, sonnet}, from m's counts only, no re-rolls: isRuleDrill_m = MODEL_SWITCHES[m].isRuleWide is true at the bar commit ∧ W line passes in both rounds (0 §11 false positives in the OFF reading, keptNoteText idempotent on every reply) ∧ every N1′ line passes in round A and in round B ∧ N2 passes (both runs).",
   "isRuleWide_m is not re-decided by this round: it stays as its 1.10.0 round decided it; a W false positive here only blocks isRuleDrill_m and is recorded (B-12) — unless the owner answers ownerQuestions[0] otherwise before the bar commit.",
   "A void round (M-4 infrastructure rule, M-10 before/after record differing from the 1.12.0 calibration) → that model's isRuleDrill stays OFF (not re-measured in 1.12.0).",
   "Any other model string, level ≠ beginner, or a remapped/provider/overridden/unreadable alias: always OFF. IS_RULE_DRILL stays false; only the MODEL_SWITCHES row changes, in the commit after the decision commit, with the old-window probe (six notes.ts) and coexist19 re-run on the ON value (R9).",
   "After the bar commit no sentence, code, stance, key or script that builds or reads a measured request changes; a counting-tool defect follows M-15 (re-count both labels, a fail never turns into ON)."
  ],
  "samples": {
   "measured": [
    "Two independent rounds A and B per model on the SAME frozen samples for both models (haiku then sonnet per stage). 83 samples + reserves, 1.10.0's committed composition unchanged: R 40 (10 per rule; js 14 · ts 12 · py 14), R_long 4, F 12, N 12, traps 7 (rule module ×4, one per rule, py ≥ 1 and ts ≥ 1; tests ×2; build script ×1), multi 4, double 4.",
    "Additions (stricter, not laxer): 2 extra traps beyond the committed 7, written in the same call and counted on the trap line only: one non-stem module that exports a use name (e.g. a `utils/…` file exporting toDateText), and one `*.config.*` file reading process.env. Total 85 + reserves.",
    "Writers: four fresh sub-agents `claude -p --model opus --tools ''` (A: R 20; B: R 20 + R_long 4; C: F 12 + N 12; D: traps 9 + multi 4 + double 4), each given only the team file, the module table, the sample JSON form and the 1.10.0 writing rules: the marker list per rule (request fetch( · requests.; log console.log · print(; date toISOString · toJSON · toLocaleDateString · toDateString · getFullYear · getMonth · getDate · getUTC… · strftime · isoformat; config process.env · os.environ · os.getenv), with free choice of marker, call shape and argument count (no builder-chosen slot tables, crit 8). They never see RULE_DRILL_SYSTEM, ruleDrillPrompt, ruleFixPlan, notePrompt, RULE_CHECK, ruleLabelled, this design, the stance or which model is measured.",
    "Team file: the 1.10.0 one unchanged (the 4 rules above, `## 용어` 2). Key §5 unchanged.",
    "Freeze-time checks (model calls 0, failing samples replaced by the same group's reserves in id order, never rewritten): JSON reads; demo runs per §8 and equals expected; each violation's fix-run runs and (S1-strict, S-c) writes MORE of that rule's stub records than the run as written, its stdout frozen as expected_fixed; violations lines are in after, hold a §5 marker, fix holds a use name and no marker; every marker line of a non-trap sample is a violation, except in F samples a line whose marker text is only inside a comment or a string/docstring literal (F's own shape; dev set4 lost 3 F samples because check.py allowed comment lines only); R/multi/double ≤ 40, R_long ≥ 41; R/multi/double import the module; F/N/trap violations empty. samples.json, team.md and key frozen with sha256, writer, UTC time in 견본.md; the strict-S1 replacement count is written as a population record (dev sets 1-4: 0 of 92 short violations failed strict S1)."
   ],
   "devNamesNotToOverlap": [
    "Ids: D1A01-D1A18, D1B01-D1B16, D2A01-D2A18, D2B01-D2B16, D3A01-D3A22, D3B01-D3B16, D4A01-D4A22, D4B01-D4B24 (dev sets 1-4) and every 견본.md id (TA/TB/TC/TD 1.10.0, 1.9.0 C/G ids).",
    "Function and file names: the union of /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/design/G6/dev/set1/names.txt, set2/names.txt, set3/names.txt, set4/names.txt (file paths included: src/utils/format.js, scripts/printVersion.js, webpack.config.js, tools/makeRelease.js, src/__tests__/cart.spec.js, tests/test_orders.py, …) and the 433-name avoid list in /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/design/G6/dev/gen/set4-part-A.md; plus storeMap, buildInfo, unansweredCount, searchProducts, format_date, countPassing.",
    "Measured writers get this avoid list; check.py rejects a sample whose file path equals a dev path."
   ],
   "secondStage": "N2 per label: pick.py takes 5 correct practices from that model's round A (all 4 rules, py ≥ 1, ts ≥ 1; an unfillable condition is dropped and recorded; fewer than 5 correct → N2 fails). A fresh sub-agent (sees only the label's 5 practices as gradeDrill shows them — code-written task and check, line, example, rule line, file, demo — and the team file) writes per practice keep-and-differ 2 · break-but-works 2 · named-but-broken 1 · off-topic 1 + one reserve per kind; n2verify (detail 22) runs them before freezing."
  },
  "calls": [
   "Exactly as the plugin (D20): probe mod calling $.model.complete({ model: 'haiku' | 'sonnet' (setting string as is), effort: 'low', system, prompt: redactText(prompt).text, maxTokens, timeoutMs }), 4 at a time, $.clock timing, replies through fixEscapedTicks. Main session started with the round's alias; claude --version, init model and modelUsage keys before/after (M-10); DISABLE_AUTOUPDATER=1 throughout.",
   "Note call: SYSTEM, notePrompt(screened, 'beginner', [], team) (1.8.0 bytes), maxTokens NOTE_TOKENS 3500, timeoutMs 90000.",
   "Practice: the build tree's writeNote path run by the probe: keptNoteText(reply, ruleNamesOf(rules)) → noteRuleOf → ruleFixPlan(screened, rules, said). Tier 1: no call. Tier 2: system RULE_DRILL_SYSTEM, prompt redactText(ruleDrillPrompt(screened, rules, said, cands)).text, maxTokens RULE_DRILL_TOKENS 3500, timeoutMs 90000, then ruleFixReply. Skip: no call. (The probe makes no anchor-skip calls in a measured round; that variant was pilot-only.)",
   "N2 grading: CHECK_SYSTEM, redactText(checkPrompt(item, mine, 'beginner', undefined, undefined, { rule })).text, maxTokens 480, timeoutMs 60000, first try, two runs.",
   "Not re-sent: empty, cap hit, timeout. API errors recorded, not re-sent (§2); > 10% of a model-stage → M-4. After each stage every empty reply is re-sent once through the tap for stop_reason/stop_details only (record, B-12).",
   "D34 before the first call: from the build tree's plugin test harness (level beginner, model the alias, harness models row turning that model's isRuleDrill + isRuleWide on, and no harness), per sample capture the note request, every tier-2 request and (after N2 freeze) the N2 grading requests (model, effort, system, prompt, maxTokens, timeoutMs) and byte-compare with the tool's lines. Tier-1 and skipped notes must show no second request. The no-harness capture has one note request only."
  ],
  "risks": [
   "R1 sonnet two-task (outside this design): its own note call corrected itself inside the practice section in 2 of 40 set4 notes (OFF reading, shipped 1.8.0 prompt + isRuleWide). The committed line counts both readings over all answered notes; with 2 in 303 sonnet notes seen (1.10.0 166 + dev 137), P(0 in 170) ≈ 30–35%. This is the main reason sonnet may fail. Not fixable here without changing OFF bytes (ownerQuestions[1]).",
   "R2 haiku den margin: 87% on dev; two rounds of den ≈ 35 must both reach 80%. Structural misses per round: os.getenv rows (≈ 1–2), anchor-skips on date notes (≈ 1–2), method-call fixes the one-span rule rejects (≈ 0–1).",
   "R3 W false positive on rule-module traps (shared W2 code, set1 D1B11): one in either round blocks isRuleDrill for that model.",
   "R4 harmful = 0 over ≈ 170 notes per model: closed paths are tested; residual: a marker the rule text never names used outside a method call (e.g. a template string `${y}-${m}`) kept in the verbatim start/end of a date line, and model fixes on anchored lines of wrong-guess notes (0 seen).",
   "R5 sonnet self-correction in tier-2 replies (set4 D4A15 parse): costs den rows; no repair added (would be fitted to one dev answer).",
   "R6 Calibration: H_M is provisional; Claude Code is now 2.1.323; the 1.12.0 calibration record must equal each round's before-record (M-10).",
   "R7 Rule prose phrasing: other teams' rule files often fail closed (unread) → no practices for them; this is the intended cost of fail-closed and is invisible to the measurement (same team file).",
   "R8 Pilot judge rebuilt from 견본.md (1.10.0 tools lost); its sha is not frozen; the measured judge is re-built and frozen at the bar commit."
  ],
  "perModel": {
   "haiku": "Measure. Final-code dev records (B-12): 61/70 den correct (87.1%; sets 14/16 · 15/16 · 16/20 · 16/18), harmful 0 in 137 answered notes, two-task 0, traps 0/21, W false positive 1 (set1 D1B11, a rule-module trap; shared W2 code), no-answer 0/44 tier-2 calls (max 993 tokens), refusals 0, mini-N2 69/71 with break→맞음 0, broken→맞음 0, missing 규칙 0. Main risks: den margin (two rounds both ≥ 80%), anchor and os.getenv misses, one W false positive would block it.",
   "sonnet": "Measure. Final-code dev records: 71/78 den correct (91.0%; 17/18 · 16/16 · 19/21 · 19/23), harmful 0, traps 0, W 0 changed notes, no-answer 0/53 (max 356 tokens), refusals 0, mini-N2 70/70. Main risk outside this design: its own note call wrote two task lines in 2 of 40 set4 notes (OFF reading, 1.8.0 prompt) — the committed two-task line counts it; 0 in sets 1–3 and in 1.10.0's 166."
  },
  "ownerQuestions": [
   "If the G6 round shows an isRuleWide W false positive (§11) for a model, should isRuleWide also turn OFF for that model? Default: no — it blocks isRuleDrill only and is recorded (B-12); isRuleWide stays decided by its 1.10.0 round (re-deciding it would be a second round of an unchanged design).",
   "The committed two-task line counts the OFF reading too (the shipped 1.11.0 note path, which isRuleDrill cannot change). Keep counting it for isRuleDrill? Default: yes, keep the committed line unchanged (not laxer); sonnet's dev showed 2 such notes in 40 (R1)."
  ]
 },
 "plan_batch1": {
  "barSource": {
   "fields": "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/design/G6.json: bar, stance (공통 re-commits 1.10.0 §0–§15 and details 1–24 unchanged, plus S-a 확인 줄, S-c 견본, S-b 판정 대상, the boundary shapes, N2 입장), decisionRule, samples, calls.",
   "summary": "Per model, two rounds A and B on the same frozen samples, both must pass every N1′ line: (a) O ≥ 20 and 0 practices on O notes; (b) den ≥ 20, correct ≥ 80% of den, harmful 0 over all answered notes, two-task 0 in both ON and OFF readings; (c) O-note prompt and final text byte-identical ON/OFF; traps 0 of 9 (7 committed + 2 added, stricter); R_long/F/N/trap no-line 0; unlabelled 0; no-answer ≤ max(1, ⌊n/60⌋); old windows (six builds) 0 bad; W gate 0 false positives in the OFF reading and keptNoteText idempotent; N2 both runs ≥ 27/30, break→맞음 ≤ 1, broken→맞음 0, missing 규칙 ≤ 1.",
   "decision": "isRuleDrill_m = isRuleWide_m true ∧ W passes in both rounds ∧ every N1′ line in A and B ∧ N2; else false. isRuleWide_m is not re-decided (owner-question default).",
   "quotedFrom": "docs/qa/견본.md '1.10.0 팀 규칙 연습 (G6)' > '기준 · 입장 · 결정 규칙' (432ced4) with the design's additions; the bar commit quotes all of it."
  },
  "samples": {
   "layout": "85 + reserves, shared by both models: R 40 (10 per rule; js 14 · ts 12 · py 14), R_long 4, F 12, N 12, traps 9 (rule module ×4, tests ×2, build script ×1, exporting non-stem module ×1, *.config.* reading process.env ×1), multi 4, double 4; team file = the 1.10.0 one unchanged (4 rules, 용어 2).",
   "writers": "4 fresh blind writers (A: R 20; B: R 20 + R_long 4; C: F 12 + N 12; D: traps 9 + multi 4 + double 4) given only the team file, module table, JSON form and 1.10.0 writing rules (marker list per rule, free marker/call shape).",
   "freezeChecks": "JSON reads; demo runs equal expected; each violation's fix-run writes more stub records (strict S1); violation lines in after, hold a marker, fix holds a use name; R/multi/double ≤ 40, R_long ≥ 41; F/N/trap violations empty; replacements from reserves in id order; file paths ≠ any dev path.",
   "secondStage": "N2 per label from that model's round A: pick.py takes 5 correct practices (4 rules, py ≥ 1, ts ≥ 1; < 5 correct → N2 fails); a fresh writer (sees only the 5 practices as gradeDrill shows them + team file) writes 30 answers (2 keep · 2 break · 1 broken · 1 off per practice) + one reserve per kind; n2verify runs them before freezing.",
   "avoid": "design/G6/dev/set1..4/names.txt (ids D1A01…D4B24, file paths) + the 433-name list in design/G6/dev/gen/set4-part-A.md + every 견본.md id + impl112/NAMES-all.txt as built in batch 0 (all G1–G6 dev names, G3 P1–P6, G5 PC01–PC40, 견본.md names)."
  },
  "calls": {
   "perModelPerRound": "85 note calls (SYSTEM, notePrompt 1.8.0 bytes, 3500, 90000) + ≈ 25–30 tier-2 calls (RULE_DRILL_SYSTEM, ruleDrillPrompt, 3500, 90000); tier 1 and skips make no call.",
   "N2": "30 grading calls per label per run × 2 runs (CHECK_SYSTEM, checkPrompt(…{ rule }), 480, 60000).",
   "total": "haiku ≈ 170 note + ≈ 55 tier-2 + 60 N2 ≈ 285; sonnet the same ≈ 285; ≈ 570 in all, plus taps for empty replies.",
   "stages": "Round A note+practice stage: haiku then sonnet; round B the same; nothing opened until A and B of both models are saved and hashed; then N1′ judging; then N2 samples per label; N2 runs 1 and 2: haiku then sonnet.",
   "retries": "Empty, cap hit, timeout: never re-sent. API errors recorded, not re-sent (G6 §2); M-4 10% rule applies.",
   "D34": "Per sample, from the build tree's test harness (beginner, alias model, that model's row): the note request, every tier-2 request (tier-1/skip notes show no second request) and after N2 freeze the N2 grading requests, byte-compared with the tool lines; also a no-harness capture (one note request only)."
  },
  "judges": "Per label: the frozen machine judge (judge-final.py rebuilt and hashed at the bar commit) plus one fresh opus row checker that sees only that label (D7); a judge/checker split counts against (M-9).",
  "stop": [
   "isRuleWide D26 difference on the build tree → fix before the build commit (if it cannot be made identical, stop and report: committing it would turn isRuleWide OFF on that model, R5).",
   "A model's round void (M-10) or M-4 → that model's isRuleDrill OFF, the other model continues.",
   "Fewer than 5 correct practices in round A for a label → N2 fails for that model (counted, not a stop of the other model).",
   "W false positive in the OFF reading → blocks isRuleDrill for that model only; isRuleWide unchanged (recorded)."
  ]
 }
}
```

## 옮긴 글


## 1.12.0 팀 규칙 연습 (G6): 코드가 만드는 규칙 연습 (isRuleDrill) · haiku + sonnet

### 짓기 (두 모델 모두 끔, 2/5 첫 커밋 a4ac818)

설계 G6(1.12.0 '코드가 만드는 규칙 연습')의 코드는 a4ac818에 끈 스위치 뒤로 들어갔습니다. 무엇을 바꿨고 무엇을 확인했는지(끈 바이트 · 옛 창 · 돌연변이 탐침 · isRuleWide D26 재확인 · 관문)는 그 커밋 본문에 있습니다. hooks/notes.ts sha256 `c049d63023b649374a1f492cb67ff5237dfb2c108e3f96ebcf4c8de079f13830` · hooks/register.tsx `411036830322abb22dbe1a7f1a0f981e0d82c3d84aa239061f5d8bed60273ef0`. IS_RULE_DRILL은 false 그대로이고, MODEL_SWITCHES 두 줄은 `{ ...SWITCHES_OFF, isRuleWide: true }` 그대로입니다.

### 기준 · 입장 · 결정 규칙 (재기 전에 정함: {DATE}, 견본을 쓰거나 모델을 부르기 전)

이 절은 공통 입장 절('1.10.0 모델별 갈래 (G7): 두 모델을 재는 공통 입장'의 M-0 ~ M-15, B-1 ~ B-15, R0 ~ R11)을 따릅니다. 그 글의 '1.10.0'은 '1.12.0'으로, '묶음 1 보정 기록'은 위 '### 보정 기록 (1.12.0)'으로 읽습니다(위 '1.12.0 미뤄 둔 기능 다시 설계' 절의 첫 항목). 같은 절의 '셈을 지키는 규칙'(CLI 고정 · 사용량 관문 · 끊긴 스테이지 규칙 · 러너 규칙 · 백업 규칙)과 '이름 목록'도 이 절을 다스립니다.

- 잰 설계: 설계 파일 `impl112/design/G6.json`(sha256 `7cb9099fe0716fc6c8bd0925e1b8d0b74a2308841e7fd7436deb09436a0a0715`), 시제품 패치 `impl112/design/G6/final/G6-final.diff`(`b9eded6343a26f64e82ad3eda566863c7565eba56860d63f857fcf97dadea9bb`). 코드는 짓기 커밋 a4ac818(위)입니다. 계획 `impl112/plan112.json`의 묶음 1(2/5)입니다.
- 이 절의 기준 · 입장 · 결정 규칙 · 견본 · 부르기 글은 설계의 bar · stance · decisionRule · samples · calls 필드와 계획 묶음 1의 글을 한국어로 옮긴 것입니다. 수와 조항은 하나도 바꾸지 않았습니다. 설계의 입장(stance)은 처음부터 한국어라 글자 그대로 옮겼습니다.
- 입장의 '공통'은 1.10.0 입장 §0 ~ §15와 세부 1 ~ 24(432ced4, 지금 이 파일의 '1.10.0 팀 규칙 연습 (G6)' 절과 글자까지 같음)를 그대로 다시 커밋합니다. 아래에 그 글을 다시 옮겨 적었고, 설계가 바꾼 곳(§1의 켠 읽기, §2의 H_M과 답 없음 줄, §14의 옛 창 여섯, 세부 18 · 19)은 1.10.0이 한 대로 원문을 지운 줄(~~ ~~)로 남기고 1.12.0 글을 붙였습니다.
- M-0 대응: G6의 상한 몫('회 앞의 작은 호출로 확인한 max_tokens') → H_M(1.12.0 보정 기록: H_haiku 2048 · H_sonnet 2048). G의 작은 호출(maxTokens 60)은 하지 않습니다(1.10.0 결정 D4 그대로).
- 상한 닿음(output_tokens ≥ maxTokens + H_M, 1.12.0 보정 기록의 수 그대로): 노트 3500 → haiku 5548 · sonnet 5548(기록과 할 일 둘 · 답함 읽기; 닿았어도 글이 읽히면 읽힌 대로), 2단 규칙 연습 3500 → haiku 5548 · sonnet 5548('답 없음' 줄), N2 채점 480 → haiku 2528 · sonnet 2528(읽히지 않음 = 맞음 아님).
- M-6: G6의 기준에는 토큰 절댓값 줄이 없어(수와 비율뿐) 바꿀 것이 없습니다.
- 수준: 견본은 beginner로 잽니다(켠 값도 beginner에서만 닿음, 1.10.0 계획 고침 D17).
- 앞선 칸 재확인(D26): 묶음 1이 다시 확인할 칸은 isRuleWide haiku · isRuleWide sonnet입니다. 짓기 커밋 전 작업 트리에서 `impl112/d26/rulewide.mjs`로 돌렸고 모델마다 150경우에서 다름 0이었습니다(a4ac818 본문). 이 기준 커밋은 견본.md만 바꿉니다.
- 주인 물음(위 '주인 물음 (기본값)' 12 · 13, 다른 답이 오지 않아 기본값): 12 — 이 회차에서 한 모델에 isRuleWide W 오탐(§11)이 나와도 그 모델의 isRuleWide는 끄지 않습니다. isRuleDrill만 막고 적습니다(B-12). 13 — 할 일 줄 둘 줄은 끈 읽기도 셉니다(커밋된 줄 그대로, 더 너그럽게 하지 않음).

#### 기준

출처: 이 파일의 '1.10.0 팀 규칙 연습 (G6)' > '기준 · 입장 · 결정 규칙'(432ced4). 모든 줄을 그대로 두고, 어느 줄도 좁히거나 너그럽게 하지 않습니다. den은 커밋된 den 그대로입니다. 모델마다 같은 새 얼린 견본으로 서로 독립인 두 회 A · B를 돌리고, 두 회 모두 N1′의 모든 줄을 넘어야 합니다. 모델마다 따로 쓰고, 합치거나 옮기지 않습니다.

| 기준 | 넘는 선 (회 A · 회 B 모두) |
| --- | --- |
| N1′ (a) | O ≥ 20이고, O 노트의 규칙 연습 = 0 |
| N1′ (b) | den = 들여쓰기 빼고 40자 이하인 violations 줄이 있는 견본의 L 노트. den ≥ 20. 바른 규칙 연습(§6 (i) ~ (vi), 모두 맞아야 함) ≥ den의 80%(코드가 연습을 만들지 않은 den 노트 — 건너뜀, `줄: 없음`, 받지 않은 답, 실패한 호출 — 는 바르지 않음). 해로운 연습(§10 h1 ~ h4) = 답한 모든 노트에서 0. 할 일 줄 둘인 노트 = 답한 모든 노트에서 켠 읽기 · 끈 읽기 모두 0 |
| N1′ (c) | O 노트: 노트 프롬프트가 켬 · 끔에서 바이트까지 같음(시험 + D34), O 노트에 연습 호출 없음(호출 기록), O 노트마다 최종 글이 켠 읽기와 끈 읽기에서 바이트까지 같음 |
| 함정 | 커밋된 7개(규칙 모듈 ×4, 테스트 ×2, 빌드 스크립트 ×1)와 더한 2개(쓰라는 이름을 내보내는 줄기 아닌 모듈 하나, `*.config.*` 파일 하나), 모두 9개에서 규칙 연습 = 0 |
| R_long, 그리고 40자 이하 어긴 줄이 없는 L 노트(F · N · 함정) | 규칙 연습 = 0(노트 자신의 개념 연습은 끈 판처럼 허용) |
| 표지 없는 규칙 연습(§9) | 켠 읽기 · 끈 읽기 모두 0 |
| 규칙 연습 답 없음 | 상한 닿음(output_tokens ≥ 3500 + H_M, 1.12.0 보정: haiku · sonnet 모두 5548), 빈 답(API 거절 포함), 시간 한도가 max(1, ⌊n/60⌋) 이하, n = 그 모델 두 회의 2단 호출 수. API 오류는 세고 다시 보내지 않음(§2) |
| 옛 창(호출 0) | 3f2b4fb · 7a7b08c · 3690021 · fca5988(커밋된 넷)에 3d2f251 · de98243을 더함(더 엄격하게). 표지가 있는 모든 최종 글(켬 · 끔)에서 drillOf가 연습을 주지 않고 hideDrillAnswer가 `고칠 줄` / `예시 답` 줄을 보이지 않음. 표지 없는 모든 글에서 창마다 3d2f251의 읽기와 같은 할 일 · 줄 · 예시 · 파일 · 행을 줌 |

W (isRuleDrill만의 관문, 아래 결정 규칙): 두 회의 끈 읽기에서 §11 W 오탐 = 0이고, 모든 답에서 keptNoteText가 멱등.

N2 (채점 바이트는 1.9.0 그대로, rule19)
- 그 모델 회 A에서 꼬리표마다 새 2단 견본을 씁니다. pick.py가 바른 연습 5개를 고릅니다(규칙 넷 모두, py ≥ 1, ts ≥ 1. 채울 수 없는 조건은 빼고 적음. 바른 연습이 5개보다 적으면 N2 못 넘음).
- 답 30개(연습마다 지킴 2 · 어김 2 · 깨짐 1 · 엉뚱함 1)를 gradeDrill이 매기는 대로 두 번 매깁니다(480토큰, 60000ms).
- 매번: 바른 판정 ≥ 27/30, 어김→맞음 ≤ 1, 깨짐→맞음 = 0, `규칙:` 줄 빠짐 ≤ 1. 뺀 답은 분모를 줄이지만 바른 판정은 여전히 27개가 있어야 합니다.

기록만(결정에 들지 않음, S-d): 노트마다의 단, 건너뜀 까닭, 꼬리표마다 2단 잘못 코드 분포, 후보 수, 1.9.0 정의의 (b), den 놓침의 1.10.0 꼴 나눔, output tokens · 시간, 엄격한 S1 대체 수, L 노트마다 연습 호출 수, 거절 열.

1.10.0 기준과 다른 점(재기 전에 적는 까닭): 함정 2개를 더하고(9개), 옛 창 둘(3d2f251 · de98243)을 더했습니다. 둘 다 넘는 쪽에 더 엄격합니다. 나머지 줄 · 선 · den은 1.10.0 그대로입니다.

#### 판정의 입장

설계의 입장(stance) 글입니다. '공통'의 다섯 항목, 확인 줄(S-a), 견본(S-c), 판정 대상(S-b), 경계 꼴 E1 ~ E18, N2 입장을 설계 글자 그대로 옮겼습니다. 판정은 이 글자대로만 셉니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 '다시 잴 때'에 적습니다(M-11).

공통 (1.10.0 입장 §0–§15와 세부 1–24를 그대로 다시 커밋하고, 아래만 바꾸거나 더함)
- §0 · §15 그대로: 판정 스크립트를 이 글대로 먼저 짓고 sha256을 바 커밋에 적습니다. 글이 정하지 않은 꼴은 넘는 쪽에 불리하게 세고 견본.md '다시 잴 때'에 적습니다. 판정 파일을 쓴 뒤에는 입장 · 열쇠 · 기준을 바꾸지 않습니다.
- §1 (바꿈) 켠 읽기: 노트 답 → fixEscapedTicks → keptNoteText(답, names) → noteRuleOf가 읽히면 그 판 트리의 ruleFixPlan(screened, rules, 그 줄). 1단이면 ruleFixMade(글, fix, changes) ?? 글, 2단이면 RULE_DRILL_SYSTEM · redactText(ruleDrillPrompt(screened, rules, 그 줄, cands)) · 3500 · 90000으로 부르고 fixEscapedTicks → ruleFixReply가 받은 글 ?? 글, 건너뜀이면 글 그대로. 끈 읽기: 같은 노트 답의 keptNoteText 글 그대로.
- §2 그대로: 노트 호출이 답하지 않은 견본은 그 회 L · O에서 빼고 수만 적습니다. 규칙 연습 호출의 상한 닿음 · 빈 답(API 거절 포함) · 시간 한도는 '답 없음' 줄에 셉니다(n = 그 모델 두 회의 2단 호출 수). 닿았어도 글이 읽히면 읽힌 대로 매깁니다. 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.12.0 보정).
- §3 · §4 · §5 · §6 · §8 · §9 · §10 · §11 · §12 · §13 그대로(채점 열쇠 §5는 같은 팀 파일에서 나온 그대로).
- §14 (더함, 엄격하게): 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988에 3d2f251 · de98243을 더한 여섯입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.

확인 줄 (S-a, §7에 더함)
- 켠 판의 확인 줄은 코드가 쓴 '고친 줄이 돌 때 `U` 쪽을 거칩니다' 하나뿐입니다. 세부 6: 코드 칸에 호출이 없으므로 견본 demo를 돌립니다. 세부 8: 쓰라는 이름 하나만 든 코드 칸은 값이 아닙니다. 세부 10: 효과 말이며 U의 규칙이 그 규칙입니다.
- 효과 주장은 줄 단위로 매깁니다: 그 줄만 예시 답으로 바꾼 파일로 demo를 돌린 기록에 그 규칙 대역 줄(`[apiRequest] ` · `[log.info] ` · `[toDateText] ` · `[config] `로 시작)이, 원래 줄 그대로 돌린 기록보다 많아야 참입니다(파일이 다른 줄에서 이미 대역을 부르는 경우를 가름). 같으면 거짓입니다.
- 확인 줄이 이 꼴이 아닌 규칙 연습(켠 창에서 읽히지 않으므로 나올 수 없음)이 나오면 1.10.0 §7 그대로 매깁니다.

견본 (S-c)
- 얼리기 전: violations마다 fix로 바꾼 demo가 원래 demo보다 그 규칙 대역 줄을 더 많이 써야 합니다(엄격한 S1). 못 넘은 견본은 같은 무리 예비로 id 차례대로 채우고 고쳐 쓰지 않으며, 바뀐 수를 견본.md에 무리마다 적습니다(모집단 기록). 개발 견본 1–4의 짧은 어긴 줄 92개에서는 0개였습니다.
- F 견본에서 표지 글자가 문자열 글자나 주석 안에만 있는 줄은 어긴 줄이 아닙니다(F의 정해진 꼴). 그 줄에 규칙 연습이 나오면 h2(해로움)입니다.

판정 대상 (S-b)
- 연습은 저장된 노트 글로만 매깁니다. 1단(코드가 만든 예시 답)이든 2단(모델이 준 예시 답)이든 같은 §6 · §10을 씁니다. 1단이라고 덜 보지 않습니다.
- 갈래 · 건너뜀 까닭 · 2단 잘못 코드는 기록만 하고 판정에 쓰지 않습니다(S-d).

옛 기록과 개발 답에서 나온 경계 꼴 (미리 정함)
- E1 인자를 바꾼 예시 답(`toDateText(e.endsAt)`, 줄은 `d.toLocaleDateString('en-CA')`): 표지가 없고 쓰라는 이름이 있으면 (iv)의 출력 비교가 정합니다. 출력이 expected_fixed와 같으면 바름, 다르면 바르지 않음(해롭지 않음).
- E2 결과에 사슬을 남긴 예시 답(`toDateText(end).slice(0, 10)`): 남은 것이 §5 표지가 아니면 h3가 아니고 (iv) 출력이 정합니다. `.slice(0, 4)`처럼 출력이 바뀌면 바르지 않음(1.12.0 개발 D1A14).
- E3 감싼 예시 답(`toDateText(end.toJSON())`)과 옆에 남긴 예시 답(`toDateText(d) || d.toISOString()`): 표지가 남으므로 h3. 코드가 막으므로 나오면 코드 결함이며 해로움으로 셉니다.
- E4 multi: 어느 violations 줄이든 짚은 규칙의 줄이면 바를 수 있습니다. 다른 규칙의 줄이면 (ii)나 (iii)에서 바르지 않고, 들인 규칙의 violations 줄이 아니면 h2입니다.
- E5 double(같은 규칙 둘): 둘 가운데 어느 줄이든 됩니다. 다른 한 줄의 표지가 파일에 남는 것은 예시 답의 표지가 아니므로 h3가 아니고, (iv)는 그 violation의 expected_fixed로 견줍니다.
- E6 `config["X"]` · `config.get("X")` · `Number(config.X)`: 쓰라는 이름 config를 품으므로 지킴입니다(§8 대역이 모두 받침). 확인 줄의 U는 `config`입니다.
- E7 os.getenv 줄(규칙 글이 이름 짓지 않은 표지): 코드가 후보로 올리지 않아 연습 없음이면 den의 바르지 않음이고 해롭지 않습니다. 연습이 나오면 보통처럼 매깁니다.
- E8 2단 답이 스스로 고쳐 쓴 꼴(같은 라벨에 다른 값, 'Wait —'): 코드가 받지 않아 연습 없음입니다. 판정은 저장된 글만 봅니다.
- E9 노트 호출이 스스로 고쳐 쓴 꼴로 직접 해 보기 칸에 할 일 줄이 둘(1.12.0 개발 D4B02 · D4B21, 끈 읽기): §13대로 할 일 줄 둘인 노트로 셉니다(두 읽기 모두, 답한 모든 노트). 이 설계가 바꿀 수 없는 끈 읽기의 일이어도 기준 줄은 그대로입니다.
- E10 노트 호출이 상한에 닿았지만 답한 경우(개발 D3B11 haiku 5548): 읽힌 대로 매기고 상한 닿음은 노트 호출 쪽 기록입니다(규칙 연습 '답 없음' 줄은 2단 호출만 셈).
- E11 켠 창에서 W2가 표지를 단 자기 칸(코드가 만들지 않은 규칙 연습): 켠 읽기에서 연습 없음입니다. 그 노트가 den이면 바르지 않음, 표지 없는 규칙 연습(§9)도 아님(개념 연습이 아니므로). 끈 읽기의 W 오탐(§11)은 그대로 셉니다.
- E12 1단이 만든 연습이 demo가 지나지 않는 줄에 있음: (v) · (vi)에서 거짓(효과 기록이 늘지 않음). 엄격한 S1이 견본의 열쇠 줄을 보장하므로 열쇠 줄이 아니면 (iii)에서 이미 바르지 않음입니다.
- E13 1단 이름 바꿈이 같은 줄의 쓰지 말라는 다른 이름을 남김: 코드가 막음. 나오면 h3.
- E14 확인 줄 U가 예시 답의 가장 짧은 쓰라는 이름(`config`)이고 예시 답은 `config.API_URL`: 효과 말 config로 매깁니다.
- E15 규칙 연습 호출 답이 `- 줄: 없음`이고 그 노트가 den: 연습 없음 → 바르지 않음, 해롭지 않음.
- E16 N2: 학습자 줄이 예시 답과 같거나 고칠 줄과 같으면 gradeDrill이 부르지 않으므로 n2verify가 뺍니다(세부 22). 판정 셈은 세부 23 그대로.
- E17 노트 글의 `다를 수 있음` 줄이 규칙 이름을 하나도 품지 않음(코드는 건너뜀): 연습 없음. den이면 바르지 않음.
- E18 sonnet API 거절(stop_reason refusal): 빈 답으로 '답 없음'에 셉니다. 탭 기록은 따로 적는 기록입니다.

N2 입장
- 1.9.0 · 1.10.0 N2 입장 그대로(세부 22 · 23). 문제 글의 할 일 · 확인 줄은 코드가 쓴 것이며, 채점 프롬프트의 나머지 바이트는 1.9.0과 같습니다(rule19 고정, 만든 연습의 채점 요청 고정 시험 추가).

다시 커밋하는 1.10.0 입장 §0 ~ §15 (432ced4 글 그대로; 바꾼 곳은 ~~ ~~와 1.12.0 글)

§0 커밋과 스크립트
- 판정 스크립트(저장소 밖)를 이 입장대로 먼저 쓰고, 그 sha256을 이 커밋에 적습니다.
- 출력을 본 뒤 스크립트가 이 글과 다르게 센 것이 드러나면 글대로 다시 세고 스크립트 diff를 견본.md에 남깁니다. 글(입장 · 열쇠 · 기준)은 바꾸지 않습니다.

§1 부르기와 읽기는 플러그인과 같습니다 (1.12.0에서 바꿈: 켠 읽기 한 줄)
- 팀 파일은 그 판 트리의 parseTeamFile로 읽습니다. names = ruleNamesOf(team.rules)(잰 모델의 isRuleWide를 켠 상태).
- 노트: SYSTEM, notePrompt(screened, 'beginner', [], team), maxTokens NOTE_TOKENS(3500).
- 노트 답: fixEscapedTicks → keptNoteText(답, names).
- ~~켠 읽기: noteRuleOf가 읽히면 RULE_DRILL_SYSTEM · ruleDrillPrompt(screened, team.rules, 그 줄), maxTokens RULE_DRILL_TOKENS(3500)로 부르고, fixEscapedTicks → withRuleDrill(글, 답, changes, names) ?? 글.~~
- 켠 읽기(1.12.0): 노트 답 → fixEscapedTicks → keptNoteText(답, names) → noteRuleOf가 읽히면 그 판 트리의 ruleFixPlan(screened, rules, 그 줄). 1단이면 ruleFixMade(글, fix, changes) ?? 글, 2단이면 RULE_DRILL_SYSTEM · redactText(ruleDrillPrompt(screened, rules, 그 줄, cands)) · 3500 · 90000으로 부르고 fixEscapedTicks → ruleFixReply가 받은 글 ?? 글, 건너뜀이면 글 그대로.
- 끈 읽기: 같은 노트 답의 keptNoteText 글 그대로.
- 두 호출 모두 redactText, effort low, timeoutMs 90000이고, 그 판 notes.ts 사본의 함수를 그대로 부릅니다.

§2 답이 없거나 상한에 닿은 답
- 노트 호출이 답하지 않으면(빈 답 · 시간 한도 · 오류) 그 견본은 그 회의 L · O에 넣지 않고 수만 적습니다. 그래서 den이 20 아래면 (b), O가 20 아래면 (a)가 못 넘음입니다.
- 규칙 연습 호출이 답하지 않으면 그 노트는 자기 칸 그대로(플러그인과 같음)이고, 그 꼴대로 매깁니다. 상한 닿음 · 빈 답 · 시간 한도는 '답 없음' 줄에 셉니다. API 오류는 수를 적고 다시 부르지 않습니다.
- 상한 닿음은 output_tokens ≥ maxTokens + H_M입니다(계획 고침 D4, M-5: G6의 상한 몫 = H_M, ~~haiku 2048 · sonnet 0, 묶음 1 보정 기록~~ 1.12.0 보정 기록의 haiku 2048 · sonnet 2048). 닿았어도 글이 읽히면 읽힌 대로 매깁니다.
- (1.12.0, 설계 §2를 옮김) 노트 호출이 답하지 않은 견본은 그 회 L · O에서 빼고 수만 적습니다. 규칙 연습 호출의 상한 닿음 · 빈 답(API 거절 포함) · 시간 한도는 '답 없음' 줄에 셉니다(n = 그 모델 두 회의 2단 호출 수). 닿았어도 글이 읽히면 읽힌 대로 매깁니다. 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.12.0 보정).

§3 L과 O
- 노트 답의 keptNoteText 글에서 noteRuleOf(연습 제목 앞, 제목이 없으면 글 전체)가 `팀 규칙과 다를 수 있음:` 줄(없음 아님)을 읽으면 L, 아니면 O입니다. 한 번 정해 켠 읽기와 끈 읽기에 함께 씁니다.
- `팀 규칙:` 줄만 있으면 O입니다.
- den = L 가운데 그 견본의 violations에 들여쓰기 빼고 40자 이하인 줄이 하나라도 있는 노트.

§4 연습의 종류
- 최종 글(켠 읽기는 withRuleDrill 뒤, 끈 읽기는 keptNoteText 글)에 drillOf(글, changes, 그 읽기의 켬 여부)를 돌립니다.
- rule을 주면 규칙 연습, rule 없이 주면 개념 연습, undefined면 연습 없음입니다.

§5 채점 열쇠 (팀 파일에서 나오며 함께 얼림)
| 규칙 | 쓰라는 이름 | 쓰지 말라는 표지 | 낱말 |
| --- | --- | --- | --- |
| 요청 | apiRequest · api_request | fetch( · requests. | 요청 · API · 서버 |
| 기록 | log.info | console.log · print( | 기록 · 로그 |
| 날짜 | toDateText · to_date_text | toISOString · toJSON · toLocaleDateString · toDateString · getFullYear · getMonth · getDate · getUTCFullYear · getUTCMonth · getUTCDate · strftime · isoformat | 날짜 |
| 설정 | config | process.env · os.environ · os.getenv | 설정 · 환경 변수 |
- 이름과 표지는 holdsName처럼 온전한 이름으로 찾습니다(`fetch(`는 `fetch` 뒤에 공백 없이 여는 괄호, `fetcher(` 안이 아님).
- 들인 규칙: 예시 답이 고칠 줄에는 없는 그 규칙의 쓰라는 이름을 품는 규칙들.
- 짚은 규칙: 노트의 `다를 수 있음` 줄 글에 그 규칙의 쓰라는 이름이나 표지가 있는 규칙들. 하나도 없으면 낱말이 있는 규칙들. 그것도 없으면 없음입니다.

§6 바름 (모두 맞아야 함. 다음을 모두 만족하는 규칙 r이 있어야 함)
- (i) 규칙 연습입니다.
- (ii) r이 들인 규칙이고 짚은 규칙입니다.
- (iii) 고칠 줄이 r의 violations 줄입니다(같은 파일, 공백 · 끝 `;` · `,` 빼고 같음).
- (iv) 예시 답이 r을 지킵니다: r의 쓰라는 이름을 품고, r의 표지가 남지 않으며, 그 줄만 예시 답으로 바꾼 파일의 demo 표준 출력(두 번)이 그 violation의 expected_fixed와 §7 정규화로 같습니다. 규칙과 상관없는 부분을 바꿔 출력이 달라지면 지키지 않음입니다.
- (v) 그 파일이 두 번 모두 오류 없이 돕니다. 원래 파일은 얼리기 전에 대역에서 돈다는 것이 확인되었으므로, 오류는 예시 답 탓으로 셉니다(정의되지 않은 이름 · import 없는 이름 포함).
- (vi) 확인 줄이 있고 그 주장이 §7로 참입니다.

§7 확인 줄
- 돌리는 것: 확인 줄 백틱 안의 첫 호출이 바꾼 파일에 정의된 함수를 부르면 그 호출을 돌립니다. 자리표시(`…` · `[A]` · `<…>`)이거나 말로만 쓴 확인이면 견본의 demo를 돌립니다.
- 변경의 파일에 없는 함수를 부르면 거짓입니다(1.9.0 G15). 확인 줄이 없으면 거짓입니다(A01).
- 돌린 결과 = 호출 값(await한 값) · 표준 출력 줄 · 대역 기록 줄(표준 출력과 따로 모음, §8).
- 주장의 꼴
  - (1) 값(백틱 · 따옴표 안, 또는 수): 정규화한 값이 호출 값과 같거나, 표준 출력이나 기록의 한 줄과 같아야 합니다. 값이 여럿이면 모두입니다(1.9.0 C18).
  - (2) 같음 말('같은 · 그대로 · 똑같이 · 변함없이 · 달라지지 않')만 있으면: 호출 값과 표준 출력이 원래 줄로 돌린 것과 같아야 합니다.
  - (3) 효과 말(그 규칙의 쓰라는 이름, '기록 · 로그가 남', '인증 · 재시도', '설정에서 읽', '날짜 글자로'): 기록 줄에 그 규칙 함수가 그 호출 동안 불린 줄이 있어야 합니다.
  - (4) 섞이면 각 부분이 다 맞아야 합니다.
  - (5) '…라고 가정 · …이면' 같은 조건: 견본 env · responses로 돌린 결과로만 매깁니다. 견본이 그 조건을 주지 않으면 거짓입니다.
  - (6) 그 밖의 꼴(값 · 같음 말 · 효과 말이 없음)은 거짓입니다.
- 정규화: 앞뒤 공백을 떼고 공백을 하나로 줄이며, `'`를 `"`로, 끝 `;`를 뗍니다. 둘 다 JSON으로 읽히면 값으로 견주고, 수는 값으로, 파이썬 True · False · None은 true · false · null로 봅니다.
- 줄인 출력: 말한 값이 맞으면 맞음이고, 말한 값이 하나라도 틀리면 거짓입니다.
- 날짜는 TZ=UTC입니다.

§8 대역과 돌리기
- 팀 모듈 넷(js · ts · py)을 둡니다. apiRequest · api_request, 미리 심은 globalThis.fetch, requests.get이 견본 responses로 같은 응답을 줍니다.
- config와 환경 변수는 견본 env로 같은 글자를 줍니다(`config.X` · `config["X"]` · `config.get("X")` 모두). log.info는 console.log · print와 같은 글을 표준 출력에 찍습니다. toDateText는 UTC YYYY-MM-DD를 줍니다.
- 대역은 불릴 때마다 `[apiRequest] 주소` · `[log.info] 인자` · `[config] 이름` · `[toDateText] 값`을 표준 출력이 아닌 기록 파일에 씁니다.
- 빈 임시 폴더에서 `unshare -n timeout 5`, js `node`, ts `node --experimental-transform-types`, py `python3 -I`로 돌립니다. 파일에 import를 덧붙이지 않습니다. 호출 값은 돌리는 틀이 사본 끝에 붙인 한 줄이 `[value] JSON`으로 찍습니다. (계획 고침 D14: py는 B-14대로 `env -i PATH LANG=C.UTF-8 PYTHONHASHSEED=<n> python3 -s -P -B`를 n = 1~5로 다섯 번 돌려 다섯이 모두 같아야 하고, ts 실행은 B-15의 `node --experimental-transform-types`입니다.)
- 구문 오류 = 바꾼 파일을 불러올 때 SyntaxError(파이썬은 py_compile 실패).
- 돌지 않는 연습(대역이 받치지 못한 경우 포함)은 (v)나 (vi)에서 거짓입니다. 읽어서 매기는 갈래는 없습니다.

§9 표지 없는 규칙 연습
- 개념 연습 가운데, 예시 답이 어떤 규칙의 쓰라는 이름을 고칠 줄에 없이 품는 것입니다.
- 할 일 글은 보지 않습니다. 할 일이 팀을 말하지만 이름을 들이지 않는 연습(1.9.0 G19 꼴)은 개념 연습입니다.
- 켠 읽기와 끈 읽기에서 모두 셉니다.

§10 해로움 (규칙 연습인데 다음 가운데 하나)
- (h1) 들인 규칙이 없음(규칙이 아닌 일을 시킴)
- (h2) 고칠 줄이 들인 규칙 어느 것의 violations 줄도 아님(헛짚은 L · 함정 · R_long에서 낸 규칙 연습 포함)
- (h3) 예시 답에 들인 규칙의 표지가 남음(거꾸로 바꿈 포함)
- (h4) 바꾼 파일에 구문 오류
- 확인 줄만 거짓이거나 (ii) · (iv)의 출력만 다른 것은 바르지 않음이지 해로움이 아닙니다.

§11 W 오탐
- 끈 읽기에서 HEAD fca5988의 ruleLabelled 글과 keptNoteText 글이 다른 노트를 봅니다.
- 그 노트의 연습(HEAD 글을 drillOf(…, false)로 읽은 것)이 다음을 모두 만족하지 않으면 오탐입니다: 고칠 줄이 어떤 규칙 r의 violations 줄이고, 예시 답이 r의 쓰라는 이름을 고칠 줄에 없이 품습니다.
- HEAD 글에서 연습이 읽히지 않던 노트(연습 없음)에 표지가 붙은 것은 오탐이 아닙니다.

§12 (c): O 노트마다 켠 읽기와 끈 읽기의 최종 글을 바이트로 견주고, 켠 회의 호출 기록에 O 노트의 규칙 연습 호출이 없는지 봅니다.

§13 할 일 줄 둘: 최종 노트의 직접 해 보기 칸(합친 칸 포함)에 할 일 줄이 둘 이상인 경우입니다.

§14 옛 창: 3f2b4fb · 7a7b08c · 3690021 · fca5988의 notes.ts 사본(꺼진 상수 그대로)으로 모든 회의 켠 · 끈 최종 글에 drillOf · hideDrillAnswer를 돌립니다.
- (1.12.0에서 더함, 엄격하게) 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988에 3d2f251 · de98243을 더한 여섯입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.

§15 판정 파일
- 스크립트가 행마다 근거(돌린 출력 · 들인 규칙 · 짚은 규칙 · 맞춘 주장 꼴)를 verdicts-<꼬리표>-<회>.md에 먼저 쓰고, 표는 그 파일만 셉니다. (계획 고침 D7: 꼬리표마다 따로 돌려 얼리고, N2는 verdicts-<꼬리표>-n2.md. 모든 판정 파일이 얼려진 뒤 짝 파일을 엽니다.)
- 판정 파일을 쓴 뒤에는 입장 · 열쇠 · 기준을 바꾸지 않습니다.
- 이 글이 정하지 않은 꼴이 나오면 넘는 쪽에 불리하게(바르지 않음 · 해로움 · 오탐 · 표지 없는 규칙 연습) 세고, 그 꼴을 견본.md에 적습니다.
- 기록만 하는 것(판정에 넣지 않음): 할 일이 라벨 설명을 옮겨 적었거나 어느 줄을 어떻게 고칠지 말한 것, 1.9.0 정의의 (b), L 노트가 개념 연습을 규칙 연습으로 바꾼 수, 규칙 연습 호출의 출력 토큰 · 시간.

N2 입장: 1.9.0 N2와 같습니다. 얼린 기대 판정과 견주고, parseCheck(text, { rule: true }) 뒤 '안 지킴 + 맞음 → 거의' 낮추기를 거친 판정으로 셉니다. 바른 판정은 지키고 동작함 → 맞음, 어겼지만 동작함 → 거의 또는 틀림, 깨짐 → 틀림 또는 거의, 엉뚱함 → 틀림입니다.

읽는 법(1.10.0 글의 이름을 1.12.0에서 읽는 자리; 글은 바꾸지 않음)
- §4 '켠 읽기는 withRuleDrill 뒤': 1.12.0에는 withRuleDrill이 없습니다(a4ac818에서 지움). 켠 읽기의 최종 글은 §1의 1.12.0 켠 읽기 글입니다(설계 '공통' §1).
- §11 · 세부 15의 'HEAD fca5988': 1.10.0 때의 말 그대로 fca5988(1.9.0)의 ruleLabelled · drillOf입니다.
- '그 판 트리': 짓기 커밋 a4ac818의 트리(`impl112/b1/mtree`, git archive)입니다.
- 세부 20의 label.py · count.py · route.py, 세부 22의 n2verify.py, 세부 23의 n2judge.mjs, 세부 12의 runlib: 아래 '틀과 도구' 표의 1.12.0 도구입니다. N2 요청을 꼬리표의 모델로 보내는 일은 route.py 대신 `tools/n2build.mjs lines`가 짝 파일을 읽어 하고 짝을 찍지 않습니다.

다시 커밋하는 1.10.0 세부 1 ~ 24 (판정 스크립트가 정한 세부, 432ced4 글 그대로; 바꾼 곳은 ~~ ~~와 1.12.0 글)

1. §5 찾기: 쓰라는 이름은 holdsName 그대로 찾습니다(바로 앞이 글자 · 숫자 · `_` · `$` · `.`이 아니고 바로 뒤가 글자 · 숫자 · `_` · `$`가 아님). 표지도 온전한 이름으로 찾되 바로 앞의 `.`은 됩니다(열쇠의 날짜 표지는 `d.toISOString()`처럼 메서드라서). `(` · `.`로 끝나는 표지(`fetch(` · `print(` · `requests.`)는 그 글자가 이름 바로 뒤에 와야 합니다. 낱말은 글자 그대로 들어 있으면 찾은 것이고, `API`는 대소문자를 가리지 않습니다.
2. §5 짚은 규칙: 노트의 `다를 수 있음` 줄(규칙 연습이 든 rule 줄, noteRuleOf가 읽은 것) 글에서 찾습니다.
3. §6 (iii) 같은 파일: drillOf가 준 file(저장소 기준 경로)과 violations의 file이 같고, 두 줄에서 공백을 모두 빼고 끝 `;` · `,`를 뗀 글이 같음.
4. §6 (iv) · (v) 돌리기: 그 연습 줄(drillOf의 n행, 들여쓰기 그대로)만 예시 답으로 바꾼 파일들로 견본 demo를 첫 파일 끝에서 돌립니다. js · ts 두 번, py 다섯 번(B-14)이 종료 코드 · 표준 출력 · 기록 줄 모두 같아야 하고 종료 코드 0이어야 합니다. 표준 출력은 줄마다(빈 줄 빼고) §7 정규화로 expected_fixed와 견주고, 줄 수도 같아야 합니다. 돌리는 틀이 찍는 `[value] …` 줄도 출력에 듭니다(expected · expected_fixed도 그 줄을 품음).
5. 오류: 종료 코드가 0이 아님(시간 한도 124 포함).
6. §7 첫 호출: 확인 줄의 코드 칸(`` ` `` · `` `` ``) 가운데 `이름(`이 처음 나오는 칸에서, 그 이름부터 짝 괄호까지(앞의 `await`는 뗌). 그 호출이 자리표시(`…` · `...` · `[A]` 꼴 · `<…>`)를 품거나 코드 칸에 호출이 없으면 견본 demo를 돌립니다. 호출한 이름이 바꾼 파일의 맨 위 수준에 정의되어 있으면(js · ts의 function · const · let · var · class, py의 def · class · 이름 =) 그 호출을 바꾼 파일 끝에서 돌리고, 아니면(팀 모듈 · 내장 함수 · 변경의 다른 파일에 있는 함수 포함) 거짓입니다(§7 둘째 줄, 다른 파일의 함수는 글이 정하지 않아 §15).
7. §7 주장: 확인 줄에서 처음 나오는 `→`(또는 `->` · `=>`) 뒤의 글. 화살표가 없으면 확인 줄에서 그 호출의 코드 칸을 뺀 글.
8. §7 (1) 값: 주장 안의 코드 칸(규칙의 쓰라는 이름이나 표지 하나만 든 칸은 빼고), 따옴표(`"` · `'` · `“”` · `‘’` · `「」`) 안의 글, 수(앞뒤에 ASCII 글자 · 숫자 · `_` · `.` · `-`가 붙지 않은 것: `3개`의 3은 수, `2026-10-22`는 수가 아님). 값마다 호출 값(JSON으로 읽히면 값으로, 아니면 글자열 값의 글자나 JSON 글과), 표준 출력의 한 줄(돌리는 틀의 `[value]` 줄 빼고), 기록의 한 줄(`[apiRequest] …` 꼴 그 줄 전체) 가운데 하나와 §7 정규화로 같아야 합니다. 조건(§7 (5))의 값도 값으로 셉니다(조건을 기계로 가르는 글이 없어 §15).
9. §7 (2) 같음 말: 코드 칸 · 따옴표 밖의 글에 `같은` · `그대로` · `똑같이` · `변함없이` · `달라지지 않`이 있으면, 같은 호출을 원래 파일(견본 after)로 돌려 호출 값(§7 정규화)과 표준 출력(줄마다)이 같아야 합니다. 둘 다 오류 없이 돌아야 합니다.
10. §7 (3) 효과 말: 코드 칸 · 따옴표 밖의 글에 그 규칙의 쓰라는 이름이 있거나 쓰라는 이름 하나만 든 코드 칸이 있음, 또는 `(기록|로그)…남` → 기록, `인증` · `재시도` → 요청, `설정에서 읽` → 설정, `날짜 글자로` → 날짜. 말한 규칙마다 그 호출의 기록 줄에 그 대역의 줄(`[apiRequest] ` · `[log.info] ` · `[toDateText] ` · `[config] `로 시작)이 있어야 합니다.
11. §7 (4) · (6): 값 · 같음 말 · 효과 말 가운데 있는 것이 모두 맞아야 참이고, 하나도 없으면 거짓입니다. 확인 호출도 js · ts 두 번, py 다섯 번이 모두 같아야 하며, 다르면 거짓입니다.
12. §8 틀: 빈 임시 폴더에 대역(아래 runlib)과 견본 파일(같은 경로면 견본 파일이 대역을 갈음)을 두고, `unshare -n timeout 5 env -i PATH=… LANG=C.UTF-8 TZ=UTC <견본 env>`로 돌립니다(py는 PYTHONHASHSEED=1~5를 더하고 `python3 -s -P -B`로 폴더 맨 위의 실행 파일을 돌려, 그 파일이 폴더를 sys.path에 넣고 모듈을 run_name `__learnrun__`로 돌림. 그래서 `if __name__ == "__main__":` 아래는 돌지 않음). js · ts는 `node`(ts는 `--experimental-transform-types`)에 `--import`로 미리 심은 globalThis.fetch(견본 responses, 기록 없음)를 둡니다. 호출 값 줄은 js · ts `console.log('[value] ' + (JSON.stringify(await (호출)) ?? 'null'))`, py `print('[value] ' + __import__('json').dumps((호출), ensure_ascii=False, default=str))`이고(파일에 import 문을 더하지 않음), 응답은 주소가 품은 첫 키의 값(상태 200), 맞는 키가 없으면 404와 `{}`입니다.
13. §8 구문 오류: js · ts는 바꾼 파일을 그것 하나만 진입점으로 불러(호출 없이) 종료 코드가 0이 아니고 stderr에 `SyntaxError`가 있음(node `--check`는 ts를 검사하지 않음), py는 py_compile이 실패함.
14. §9: 켠 읽기와 끈 읽기의 개념 연습마다, §5 '들인 규칙'이 하나라도 있으면 셉니다.
15. §11: fca5988의 조합 `ruleLabelled(closeConceptBold(cut(답, 9000)))`(= keptNoteText(답, []), 시험으로 고정)과 keptNoteText(답, names)가 다른 노트에서, fca5988 글을 fca5988의 drillOf(…, false)로 읽은 연습을 봅니다.
16. §13: 직접 해 보기 칸(제목에서 다음 제목까지, ruleLabelled가 칸을 가르는 그대로)마다 taskLineOf가 읽는 할 일 줄을 셉니다. 한 칸이라도 둘 이상이면 셉니다. 켠 읽기 · 끈 읽기 모두, 답한 모든 노트에서 셉니다(B-6).
17. (b)의 '해로운 연습 0' · '할 일 줄 둘인 노트 0'은 den만이 아니라 그 회의 답한 모든 노트에서 셉니다(B-6). '바른 규칙 연습 80%'는 den 노트의 켠 읽기 규칙 연습 가운데 바름 수 ÷ den입니다.
18. 규칙 연습 호출의 답 없음 줄: 두 회를 합친 규칙 연습 호출 n번 가운데 상한 닿음 · 빈 답 · 시간 한도인 것이 max(1, ⌊n / 60⌋)개 이하. 상한 닿음은 output_tokens ≥ maxTokens + H_M(~~haiku 2048 · sonnet 0~~ 1.12.0 보정: haiku 2048 · sonnet 2048, 곧 2단 호출 5548)이고, 답한 호출도 닿았으면 셉니다. (1.12.0) 규칙 연습 호출은 2단 호출이고(1단 · 건너뜀은 호출 없음), 빈 답은 API 거절을 포함합니다(E18).
19. §14: 표지 노트 = 최종 글에 `- 할 일 (팀 규칙):`로 시작하는 줄이 있는 노트. 옛 창 ~~넷~~ 여섯(1.12.0, §14)의 drillOf가 연습을 주지 않고, 그 창 패널이 부르는 꼴의 hideDrillAnswer 글에 `고칠 줄` · `예시 답` 라벨 줄이 없어야 합니다. 표지 없는 노트는 그 창의 drillOf가 ~~1.10.0의 그 읽기(켬 · 끔)~~ 3d2f251의 drillOf로 그 읽기(켬 · 끔)를 한 것(1.12.0, §14)과 같은 할 일 · 고칠 줄 · 예시 답 · 파일 · 행을 줘야 합니다. 켠 · 끈 최종 글 모두, ~~네~~ 여섯 창 모두입니다.
20. 꼬리표(M-8, 결정 D7): 회 A · B와 헷갈리지 않게 P · Q로 씁니다. 이 G의 모든 스테이지(N1′ 회 A · B와 N2)에 한 번 뽑은 짝을 쓰고(N2 견본이 그 꼬리표 회 A에서 나오므로), pair.json을 얼려 sha256만 적습니다. label.py가 꼬리표 파일에서 모델 이름 · 시간 · 토큰 · 상한을 빼고, 그 수는 count.py만 셉니다. N2 요청을 그 꼬리표의 모델로 보내는 일은 route.py가 짝 파일을 읽어 하고 짝을 찍지 않습니다. 부르는 쪽(이 묶음을 짓는 쪽)은 어느 모델을 부르는지 압니다. 그래서 두 모델의 그 스테이지 답이 얼려지기 전에는 답 글을 열지 않고(M-3), 판정은 스크립트가 꼬리표 파일로만 합니다.
21. 판정 파일 행 확인(설계 '사람은 스크립트가 입장 글대로 셌는지를 행마다 확인'): 꼬리표마다 새 하위 에이전트 하나(`claude -p --model opus --tools ''`, 그 꼬리표의 판정 파일과 이 절의 입장 · 세부만 받음, 한 하위 에이전트가 두 꼬리표를 보지 않음)가 글대로 세지 않은 행을 적습니다. 적힌 행이 있으면 M-15대로 합니다(글이 이김, 도구를 고쳐 두 꼬리표를 다시 세고 전후 수를 모두 적으며, 못 넘음 → 넘음이면 새 하위 에이전트가 '글을 옮긴 고침'임을 확인해야 그 수를 씀).
22. N2 대역 확인(n2verify.py, 결정 D8 (2)): gradeDrill이 부르지 않는 줄(빈 줄, sameLine으로 예시 답 · 고칠 줄과 같음, 한글 자판)은 못 넘음. 그 연습 줄만 답 줄로 바꾼 파일로 demo를 돌려(js · ts 두 번, py 다섯 번) 갈래마다: keep = 모두 같음 · 종료 0 · r의 쓰라는 이름 있음 · r의 표지 없음 · 출력이 예시 답의 출력과 같음, break = 모두 같음 · 종료 0 · (r의 표지 있음 또는 쓰라는 이름 없음), broken = 쓰라는 이름 있음 · (돌릴 때마다 다름 또는 종료가 0이 아님 또는 출력이 예시 답과 다름), off = 쓰라는 이름 없음 · (종료가 0이 아님 또는 출력이 예시 답과 다름). 못 넘은 본 답은 그 연습의 같은 갈래 예비가 넘으면 그것으로 채우고, 아니면 빼고 그 수를 적습니다(고쳐 쓰지 않음). 기대 판정: keep 맞음, break 거의 · 틀림, broken 틀림 · 거의, off 틀림(N2 입장).
23. N2 셈(n2judge.mjs): 답 없음 · 읽지 못한 답은 바른 판정이 아니고 `규칙:` 줄 빠짐으로도 셉니다(B-8). 회마다 바른 판정 27개 이상 · 어김(break)→맞음 1개 이하 · 깨짐(broken)→맞음 0 · `규칙:` 줄 빠짐 1개 이하, 두 번 모두 넘어야 N2 넘음.
24. 기록만 하는 것(판정에 넣지 않음): 1.9.0 정의의 (b)(L 전체를 분모로), L 노트가 개념 연습인 수 · 연습 없는 수, 할 일에 `한 문장으로` · `어느 줄을`이 든 규칙 연습 수(라벨 설명을 옮긴 꼴의 어림), 규칙 연습 호출 결과의 꼴, 호출마다의 output_tokens · 시간(count.py).

#### 결정 규칙

1. 모델 m ∈ {haiku, sonnet}마다, m의 수로만, 다시 굴리기 없이: isRuleDrill_m = 기준 커밋에서 MODEL_SWITCHES[m].isRuleWide가 true ∧ W 줄이 두 회 모두 넘음(끈 읽기의 §11 오탐 0, 모든 답에서 keptNoteText 멱등) ∧ N1′의 모든 줄이 회 A와 회 B에서 넘음 ∧ N2가 넘음(두 번 모두).
2. isRuleWide_m은 이 회차로 다시 정하지 않습니다. 1.10.0 회차가 정한 그대로입니다. 여기서 나온 W 오탐은 isRuleDrill_m만 막고 적습니다(B-12). 주인이 기준 커밋 전에 주인 물음 12에 달리 답하면 그 답을 따르지만, 답은 오지 않았습니다(기본값).
3. 무효인 회(M-4 기반 규칙, M-10 앞뒤 기록이 1.12.0 보정과 다름) → 그 모델의 isRuleDrill은 끔(1.12.0에서 다시 재지 않음).
4. 다른 모델 글자, level ≠ beginner, 바뀐 · 제공자 · 덮어쓴 · 읽지 못한 별칭: 늘 끔. IS_RULE_DRILL은 false 그대로이고, 결정 커밋 다음 커밋에서 MODEL_SWITCHES 줄만 바꿉니다. 그때 옛 창 확인(notes.ts 여섯)과 coexist19를 켠 값으로 다시 돌립니다(R9).
5. 기준 커밋 뒤에는 잰 요청을 짓거나 읽는 문장 · 코드 · 입장 · 열쇠 · 스크립트를 바꾸지 않습니다. 세는 도구의 결함은 M-15를 따릅니다(두 꼬리표를 다시 세고, 못 넘음이 켬으로 바뀌지 않음).

계획 묶음 1의 글(같은 규칙): isRuleDrill_m = isRuleWide_m true ∧ W가 두 회 모두 넘음 ∧ N1′의 모든 줄이 A와 B에서 넘음 ∧ N2, 아니면 false. isRuleWide_m은 다시 정하지 않습니다(주인 물음 기본값).
- 판정자(계획 judges): 꼬리표마다 얼린 기계 판정자(`tools/judge.py`, 이 커밋에서 다시 짓고 sha256을 적음)와 그 꼬리표만 보는 새 opus 행 확인자 하나(D7, 세부 21). 판정자와 확인자가 갈리면 넘는 쪽에 불리하게 셉니다(M-9).
- 멈춤(계획 stop): 앞선 칸 isRuleWide의 D26 다름을 커밋 전 트리에서 고치지 못하면 멈추고 알림(짓기에서 다름 0이었음). 한 모델의 회가 무효(M-10)거나 M-4면 그 모델의 isRuleDrill만 끄고 다른 모델은 계속함. 회 A의 바른 연습이 5개보다 적은 꼬리표는 그 모델의 N2가 못 넘음(셈; 다른 모델은 멈추지 않음). 끈 읽기의 W 오탐은 그 모델의 isRuleDrill만 막고 isRuleWide는 그대로(적음).

#### 모델마다 (설계 perModel, 기록만 · B-12, 결정에 들지 않음)

- haiku: 잼. 마지막 코드의 개발 기록: den 바름 61/70(87.1%; 세트 14/16 · 15/16 · 16/20 · 16/18), 답한 노트 137개에서 해로움 0, 할 일 둘 0, 함정 0/21, W 오탐 1(세트 1 D1B11, 규칙 모듈 함정; W2 코드를 함께 씀), 2단 호출 44번에서 답 없음 0(가장 큰 것 993토큰), 거절 0, 작은 N2 69/71(어김→맞음 0, 깨짐→맞음 0, 규칙 빠짐 0). 주된 위험: den 여유(두 회 모두 ≥ 80%), 앵커와 os.getenv 놓침, W 오탐 하나가 막을 수 있음.
- sonnet: 잼. 마지막 코드의 개발 기록: den 바름 71/78(91.0%; 17/18 · 16/16 · 19/21 · 19/23), 해로움 0, 함정 0, W 바뀐 노트 0, 답 없음 0/53(가장 큰 것 356토큰), 거절 0, 작은 N2 70/70. 이 설계 밖의 주된 위험: 자기 노트 호출이 세트 4의 노트 40개 가운데 2개에서 할 일 줄 둘을 썼습니다(끈 읽기, 1.8.0 프롬프트). 커밋된 할 일 둘 줄이 그것을 셉니다. 세트 1–3과 1.10.0의 166개에서는 0.

#### 견본의 짜임

설계 samples 글(옮김)
- 모델마다 같은 얼린 견본으로 서로 독립인 두 회 A · B(스테이지마다 haiku 다음 sonnet). 견본 83개 + 예비, 1.10.0의 커밋된 짜임 그대로: R 40(규칙마다 10; js 14 · ts 12 · py 14), R_long 4, F 12, N 12, 함정 7(규칙 모듈 ×4, 규칙마다 하나, py ≥ 1 · ts ≥ 1; 테스트 ×2; 빌드 스크립트 ×1), multi 4, double 4.
- 더함(더 엄격하게, 더 너그럽게가 아님): 커밋된 7개 밖의 함정 2개를 같은 호출에서 쓰고 함정 줄에만 셉니다. 쓰라는 이름을 내보내는 줄기 아닌 모듈 하나(예: toDateText를 내보내는 `utils/…` 파일)와 process.env를 읽는 `*.config.*` 파일 하나. 모두 85개 + 예비.
- 쓰는 쪽: 새 하위 에이전트 넷 `claude -p --model opus --tools ''`(A: R 20; B: R 20 + R_long 4; C: F 12 + N 12; D: 함정 9 + multi 4 + double 4). 각자 팀 파일, 모듈 표, 견본 JSON 꼴, 1.10.0 작성 규칙만 받습니다: 규칙마다 표지 목록(request fetch( · requests.; log console.log · print(; date toISOString · toJSON · toLocaleDateString · toDateString · getFullYear · getMonth · getDate · getUTC… · strftime · isoformat; config process.env · os.environ · os.getenv)이고, 표지 · 호출 꼴 · 인자 수는 마음대로 고릅니다(짓는 쪽이 고른 자리 표 없음, crit 8). RULE_DRILL_SYSTEM, ruleDrillPrompt, ruleFixPlan, notePrompt, RULE_CHECK, ruleLabelled, 이 설계, 입장, 어느 모델을 재는지는 보지 않습니다.
- 팀 파일: 1.10.0 것 그대로(위 넷 규칙, `## 용어` 2). 열쇠 §5 그대로.
- 얼릴 때 확인(모델 호출 0, 못 넘은 견본은 같은 무리 예비로 id 차례대로 바꾸고 고쳐 쓰지 않음): JSON이 읽힘; demo가 §8대로 돌고 expected와 같음; violations마다 fix로 돌린 것이 돌고 (엄격한 S1, S-c) 그 규칙 대역 기록을 적힌 그대로 돌린 것보다 더 많이 쓰며, 그 표준 출력을 expected_fixed로 얼림; violations 줄은 after에 있고 §5 표지를 품으며, fix는 쓰라는 이름을 품고 표지가 없음; 함정이 아닌 견본의 표지 줄은 모두 violation임, 단 F 견본에서 표지 글자가 주석이나 문자열/docstring 글자 안에만 있는 줄은 빼고(F의 꼴; 개발 세트 4는 check.py가 주석 줄만 받아 F 견본 3개를 잃었음); R/multi/double ≤ 40, R_long ≥ 41; R/multi/double은 그 모듈을 import함; F/N/함정의 violations는 빔. samples.json, team.md, 열쇠를 sha256 · 쓴 쪽 · UTC 시각과 함께 견본.md에 얼림; 엄격한 S1 대체 수는 모집단 기록으로 적음(개발 세트 1–4: 짧은 violations 92개 가운데 0개가 엄격한 S1을 못 넘음).
- 겹치지 않을 개발 이름: id D1A01–D1A18, D1B01–D1B16, D2A01–D2A18, D2B01–D2B16, D3A01–D3A22, D3B01–D3B16, D4A01–D4A22, D4B01–D4B24(개발 세트 1–4)와 견본.md의 모든 id(1.10.0 TA/TB/TC/TD, 1.9.0 C/G id). 함수와 파일 이름: `impl112/design/G6/dev/set1..4/names.txt`의 합집합(파일 경로 포함: src/utils/format.js, scripts/printVersion.js, webpack.config.js, tools/makeRelease.js, src/__tests__/cart.spec.js, tests/test_orders.py, …)과 `impl112/design/G6/dev/gen/set4-part-A.md`의 피할 이름 433개; 그리고 storeMap, buildInfo, unansweredCount, searchProducts, format_date, countPassing. 잰 견본의 쓰는 쪽은 이 피할 목록을 받고, check.py는 파일 경로가 개발 경로와 같은 견본을 거절합니다.
- 둘째 스테이지: N2는 꼬리표마다. pick.py가 그 모델 회 A에서 바른 연습 5개를 고릅니다(규칙 넷 모두, py ≥ 1, ts ≥ 1; 채울 수 없는 조건은 빼고 적음; 바른 것이 5개보다 적으면 N2 못 넘음). 새 하위 에이전트 하나(그 꼬리표의 연습 5개를 gradeDrill이 보이는 대로 — 코드가 쓴 할 일과 확인, 줄, 예시, 규칙 줄, 파일, demo — 와 팀 파일만 봄)가 연습마다 지키고 다름 2 · 어겼지만 동작 2 · 이름은 있지만 깨짐 1 · 엉뚱함 1과 갈래마다 예비 하나를 씁니다. n2verify(세부 22)가 얼리기 전에 돌려 봅니다.

계획 묶음 1의 글(같은 짜임을 더 자세히)
- 짜임: 85 + 예비, 두 모델이 함께 씀: R 40(규칙마다 10; js 14 · ts 12 · py 14), R_long 4, F 12, N 12, 함정 9(규칙 모듈 ×4, 테스트 ×2, 빌드 스크립트 ×1, 내보내는 줄기 아닌 모듈 ×1, process.env를 읽는 *.config.* ×1), multi 4, double 4. 팀 파일은 1.10.0 것 그대로(규칙 4, 용어 2).
- 쓰는 쪽 넷(A: R 20; B: R 20 + R_long 4; C: F 12 + N 12; D: 함정 9 + multi 4 + double 4)은 팀 파일, 모듈 표, JSON 꼴, 1.10.0 작성 규칙(규칙마다 표지 목록, 표지 · 호출 꼴은 마음대로)만 받습니다.
- 얼릴 때 확인: JSON이 읽힘; demo를 돌린 것이 expected와 같음; violation마다 fix로 돌린 것이 대역 기록을 더 많이 씀(엄격한 S1); violation 줄은 after에 있고 표지를 품으며 fix는 쓰라는 이름을 품음; R/multi/double ≤ 40, R_long ≥ 41; F/N/함정의 violations는 빔; 예비로 id 차례대로 바꿈; 파일 경로 ≠ 어느 개발 경로.
- 피할 목록: `design/G6/dev/set1..4/names.txt`(id D1A01…D4B24, 파일 경로) + `design/G6/dev/gen/set4-part-A.md`의 이름 433개 + 견본.md의 모든 id + 묶음 0에서 지은 `impl112/NAMES-all.txt`(G1–G6 개발 이름 모두, G3 P1–P6, G5 PC01–PC40, 견본.md 이름).

이 묶음이 정한 것(위 글을 도구로 옮긴 자리, 기록)
- 쓰는 쪽의 id와 예비(1.10.0 '무리마다 예비 2개'): A `GA01`–`GA20` R(규칙마다 5; js 7 · ts 6 · py 7) + 예비 R `GA21` · `GA22`; B `GB01`–`GB20` R(규칙마다 5; js 7 · ts 6 · py 7) + `GB21`–`GB24` R_long + 예비 R `GB25` · `GB26`, R_long `GB27` · `GB28`; C `GC01`–`GC12` F + `GC13`–`GC24` N + 예비 F `GC25` · `GC26`, N `GC27` · `GC28`; D `GD01`–`GD04` 함정(module, 규칙마다 하나, py ≥ 1 · ts ≥ 1) · `GD05` · `GD06`(test) · `GD07`(script) · `GD08`(export) · `GD09`(config) + `GD10`–`GD13` multi + `GD14`–`GD17` double + 예비 함정 `GD18`(module) · `GD19`(test), multi `GD20` · `GD21`, double `GD22` · `GD23`. 규칙마다 R의 언어 수는 A와 B를 합쳐 request js 3 · ts 3 · py 4, log js 4 · ts 3 · py 3, date js 3 · ts 3 · py 4, config js 4 · ts 3 · py 3(합 js 14 · ts 12 · py 14). `G[ABCD]` id는 NAMES-all.txt에 없습니다(확인함).
- 쓰는 쪽 프롬프트 = `gen/common.md`(개발 세트 4의 `common4.md`에서 피할 이름 줄 하나만 바꿈) + `gen/part-<A|B|C|D>.md` + 피할 이름 절(`gen/avoid.py`가 그때의 NAMES-all.txt에서 코드 이름이나 경로가 될 수 있는 것 — 식별자, 점 이름, 빗금 든 경로 — 만 뽑음, 지금 3,577개; 한국어 개념 이름과 구절은 함수 · 파일 이름이 될 수 없어 뺌).
- 피할 이름 확인: check.py는 파일 경로가 NAMES-all.txt의 빗금 든 항목과 같으면 거절합니다(설계 글). 함수 이름이 겹치는 것은 쓰는 쪽에게 피하라고만 하고, 얼릴 때 기록합니다.

팀 파일과 채점 열쇠(1.10.0 것 그대로, 다시 얼림; 저장소 밖 `impl112/b1/team.md` sha256 `18f9d5c755f49db4f9dd767b380bdda569609ffa6a6021ca9f9525881a9b0c9b`, 1.10.0 절의 팀 파일 글과 바이트까지 같음)
- 팀 파일은 1.10.0 절 '팀 파일과 채점 열쇠 (함께 얼림)'의 글 그대로입니다(`## 규칙` 넷, `## 용어` 둘). 채점 열쇠(§5 표)도 그대로이고, 도구에서는 `tools/key.py`입니다.
- 대역 모듈의 자리(작성 프롬프트와 대역에만): js · ts `src/api/apiRequest` · `src/log` · `src/dateText` · `src/config`, py `app/api/api_request.py` · `app/log.py` · `app/date_text.py` · `app/config.py`.

#### 부르기

설계 calls 글(옮김)
- 플러그인과 똑같이(D20): 프로브 mod가 $.model.complete({ model: 'haiku' | 'sonnet'(설정 글자 그대로), effort: 'low', system, prompt: redactText(prompt).text, maxTokens, timeoutMs })로 4개씩 부르고, $.clock으로 시간을 재고, 답은 fixEscapedTicks를 거칩니다. 주 세션은 그 회의 별칭으로 켜고, claude --version · init model · modelUsage 키를 앞뒤로 적습니다(M-10). 내내 DISABLE_AUTOUPDATER=1.
- 노트 호출: SYSTEM, notePrompt(screened, 'beginner', [], team)(1.8.0 바이트), maxTokens NOTE_TOKENS 3500, timeoutMs 90000.
- 연습: 짓기 트리의 writeNote 길을 프로브가 돌림: keptNoteText(답, ruleNamesOf(rules)) → noteRuleOf → ruleFixPlan(screened, rules, said). 1단: 호출 없음. 2단: system RULE_DRILL_SYSTEM, prompt redactText(ruleDrillPrompt(screened, rules, said, cands)).text, maxTokens RULE_DRILL_TOKENS 3500, timeoutMs 90000, 그다음 ruleFixReply. 건너뜀: 호출 없음. (잰 회에서 프로브는 앵커 건너뜀 호출을 하지 않습니다. 그 갈래는 파일럿에만 있었음.)
- N2 채점: CHECK_SYSTEM, redactText(checkPrompt(item, mine, 'beginner', undefined, undefined, { rule })).text, maxTokens 480, timeoutMs 60000, 첫 시도, 두 번.
- 다시 보내지 않음: 빈 답, 상한 닿음, 시간 한도. API 오류는 적고 다시 보내지 않음(§2). 한 모델-스테이지의 10%를 넘으면 → M-4. 스테이지마다 빈 답은 모두 탭으로 한 번 다시 보내 stop_reason/stop_details만 적음(기록, B-12).
- D34(첫 호출 전): 짓기 트리의 플러그인 시험 하네스(level beginner, model 그 별칭, 하네스 models 줄이 그 모델의 isRuleDrill + isRuleWide를 켬, 그리고 하네스 없음)로 견본마다 노트 요청, 2단 요청 모두, (N2를 얼린 뒤) N2 채점 요청(model, effort, system, prompt, maxTokens, timeoutMs)을 잡아 도구의 줄과 바이트까지 견줍니다. 1단과 건너뜀 노트는 둘째 요청이 없어야 합니다. 하네스 없는 잡기는 노트 요청 하나뿐입니다.

계획 묶음 1의 글
- 모델마다 회마다: 노트 호출 85번(SYSTEM, notePrompt 1.8.0 바이트, 3500, 90000) + 2단 호출 약 25–30번(RULE_DRILL_SYSTEM, ruleDrillPrompt, 3500, 90000). 1단과 건너뜀은 호출 없음.
- N2: 꼬리표마다 번마다 채점 호출 30번 × 두 번(CHECK_SYSTEM, checkPrompt(…{ rule }), 480, 60000).
- 모두: haiku 노트 약 170 + 2단 약 55 + N2 60 ≈ 285; sonnet도 ≈ 285; 모두 ≈ 570, 빈 답의 탭 더함.
- 스테이지: 회 A 노트+연습 스테이지: haiku 다음 sonnet; 회 B 같음; 두 모델의 A와 B가 저장되고 해시되기 전에는 아무것도 열지 않음; 그다음 N1′ 판정; 그다음 꼬리표마다 N2 견본; N2 1번째와 2번째: haiku 다음 sonnet.
- 다시 보내기: 빈 답, 상한 닿음, 시간 한도는 다시 보내지 않음. API 오류는 적고 다시 보내지 않음(G6 §2); M-4 10% 규칙을 씀.
- D34: 견본마다 짓기 트리의 시험 하네스(beginner, 별칭 모델, 그 모델의 줄)로 노트 요청, 2단 요청 모두(1단/건너뜀 노트는 둘째 요청이 없음), N2를 얼린 뒤 N2 채점 요청을 잡아 도구 줄과 바이트로 견줌; 하네스 없는 잡기도(노트 요청 하나뿐).

이 묶음이 정한 것(위 글을 도구로 옮긴 자리, 기록)
- 모델-스테이지: `A`(회 A), `B`(회 B), `N2-1`, `N2-2`(N2 1번째 · 2번째), 모델마다 따로. 계획의 사용량 관문 자리 'G6 회 A haiku … N2 2번째 sonnet' 여덟과 하나씩 맞습니다. 회 A · B의 모델-스테이지 하나는 노트 호출 85번(프로브 세션 하나) 뒤에 그 모델 자신의 노트 답으로 2단 줄을 짓고(`tools/build.mjs drill`), 그 2단 요청을 D34로 하네스와 견준 뒤(`d34/make.py real`, 다르면 2단 호출 없이 멈춤), 2단 호출을 합니다(프로브 세션 하나). M-4의 10%는 그 모델-스테이지의 노트 + 2단 호출 모두로 셉니다.
- 떼어 낸 러너(러너 규칙): `tools/stage.sh <A|B|N2-1|N2-2> <haiku|sonnet>`를 setsid nohup으로 띄우고, 에이전트는 STARTED · 세션마다의 status.jsonl · DONE · 러너 로그만 봅니다. 러너는 (1) M-3 차례(haiku 다음 sonnet, B는 A가 두 모델 모두 끝난 뒤, N2-2는 N2-1이 두 모델 모두 끝난 뒤)와 STARTED가 없는지를 보고, (2) 고정한 길로 앞 'ok' 세션(`probe/precheck.sh`)을 돌려 `tools/gate.py pre`로 앞 기록(고정한 `claude --version` 2.1.323, 그때 다시 센 고정 바이너리 sha256, 별칭의 init model과 modelUsage 키가 1.12.0 보정 기록과 같음)과 사용량 관문(five_hour ≤ 0.60, seven_day < 0.80, 회 A haiku는 seven_day + 주간 예측 0.40 < 0.80, 그리고 에이전트가 ONLY_WORKFLOW=1로 '다른 워크플로가 돌지 않음'을 밝힘)을 봅니다. 기록이 다르면 부르지 않고 멈추고(종료 3), 관문을 못 넘으면 STARTED 없이 resetsAt을 찍고 기다립니다(종료 7). (3) STARTED(UTC, 요청 파일 sha256)를 쓰고 부르며, (4) 뒤 기록을 `tools/gate.py after`로 견주어 다르면 무효(종료 4), 던진 호출은 M-4 넷째 줄(종료 5), api-error가 10%를 넘으면 무효(종료 6)이고, 아니면 summary.json(상태 수와 답 파일 sha256)과 DONE을 씁니다. 어떤 호출도 다시 보내지 않습니다.
- 주간 예측(계획 usageGate, 회 A haiku 전): 0.40. 근거: 설계 파일럿 세트 4(호출 약 140번: haiku 노트 40 + 2단 10 + N2 18, sonnet 40 + 14 + 18, 파일럿 에이전트 포함)의 스트림 차이를 계획은 '0.45 → 0.52'로 적었습니다. 그 기록(`design/G6/pilot/set4/*/record.json`)을 다시 보면 이것은 five_hour이고, seven_day는 0.24 → 0.25였습니다. 더 엄한 쪽인 0.07을 세트 하나의 주간 쓰임으로 잡아, 잰 호출 ≈ 570번이면 0.07 × 570 / 140 ≈ 0.29, 여기에 opus 하위 에이전트(쓰는 쪽 4, N2 답 2, 행 확인 2, 번역 확인 1, 감사 1, 검토 2)와 이 묶음의 워크플로 에이전트 몫 0.11을 더해 0.40입니다. 회 A haiku는 seven_day + 0.40 < 0.80, 곧 seven_day < 0.40일 때만 시작합니다. 아니면 주간 초기화 바로 뒤에 시작합니다. (묶음 0의 보정 때 seven_day는 0.28이었습니다.)
- 모델 기록(M-10, D19): 앞 기록은 모델-스테이지마다의 앞 'ok' 세션과 고정한 길의 --record, 뒤 기록은 그 스테이지의 프로브 세션들(세션마다 앞뒤 claude --version, 턴마다 init model, result의 modelUsage 키)과 끝의 --record입니다. 모두 1.12.0 보정 기록(2.1.323, 고정 사본 sha256 `604d29a6…348e` · `d2bc14da…a9e`, haiku · sonnet의 풀린 id)과 같아야 합니다.
- 빈 답의 탭(기록만): 모델-스테이지마다 답 파일별로 `tools/tapsend.py <스테이지> <모델> <note|drill|n2>`.

#### 위험 (재기 전에 적음)

- R1 sonnet 할 일 둘(이 설계 밖): sonnet 자신의 노트 호출이 세트 4 노트 40개 가운데 2개에서 연습 칸 안에서 스스로 고쳐 썼습니다(끈 읽기, 나간 1.8.0 프롬프트 + isRuleWide). 커밋된 줄은 답한 모든 노트의 두 읽기를 셉니다. 본 sonnet 노트 303개(1.10.0 166 + 개발 137)에서 2개였으니, 170개에서 0일 확률 ≈ 30–35%입니다. sonnet이 못 넘을 주된 까닭입니다. 끈 바이트를 바꾸지 않고는 여기서 고칠 수 없습니다(주인 물음 13).
- R2 haiku den 여유: 개발에서 87%; den ≈ 35인 두 회가 모두 80%에 닿아야 합니다. 회마다 구조적 놓침: os.getenv 줄(≈ 1–2), 날짜 노트의 앵커 건너뜀(≈ 1–2), 한 자리 규칙이 받지 않는 메서드 호출 고침(≈ 0–1).
- R3 규칙 모듈 함정의 W 오탐(함께 쓰는 W2 코드, 세트 1 D1B11): 어느 회든 하나면 그 모델의 isRuleDrill을 막습니다.
- R4 ≈ 170개 노트에서 해로움 0(모델마다): 닫힌 길은 시험했습니다. 남은 것: 규칙 글이 이름 짓지 않은 표지가 메서드 호출 밖에서 쓰인 것(예: 템플릿 문자열 `${y}-${m}`)이 날짜 줄의 그대로 둔 앞/끝에 남는 경우, 그리고 헛짚은 노트의 앵커 줄에 대한 모델 고침(본 것 0).
- R5 sonnet 2단 답의 스스로 고쳐 쓰기(세트 4 D4A15 parse): den 줄을 잃습니다. 고침을 더하지 않았습니다(개발 답 하나에 맞추는 것이 되므로).
- R6 보정: H_M은 잠정이고, Claude Code는 지금 2.1.323입니다. 1.12.0 보정 기록이 각 회의 앞 기록과 같아야 합니다(M-10). (이 묶음의 기록: 1.12.0 보정이 H_haiku 2048 · H_sonnet 2048을 냈고, 모든 부르기는 고정한 2.1.323 사본으로 합니다. 설치된 claude는 컨테이너가 다시 켜진 뒤 2.1.325이지만 부르기에 쓰지 않습니다.)
- R7 규칙 글의 말씨: 다른 팀의 규칙 파일은 흔히 닫힌 쪽으로 실패합니다(읽지 않음) → 그 팀에는 연습이 없습니다. 닫힌 실패의 뜻한 값이고, 같은 팀 파일로 재므로 측정에는 보이지 않습니다.
- R8 파일럿 판정자는 견본.md에서 다시 지었고 sha를 얼리지 않았습니다. 잰 판정자는 기준 커밋에서 다시 짓고 얼립니다(이 커밋: `tools/judge.py`).
- sonnet의 따라가기 거절(SCOPE 묶음 3의 사실): 이 설계의 세 요청(노트 notePrompt 1.8.0 바이트, 2단 ruleDrillPrompt — 규칙 · 줄 · 예시 답 세 줄만 묻는 닫힌 꼴, N2 checkPrompt 1.9.0 바이트)은 코드를 한 줄씩 따라간 과정을 적으라고 하지 않습니다. 설계 파일럿에서 거절 0(세트 4: haiku 2단 10 · sonnet 14, N2 각 18; 세트 1–3 포함 모든 호출). 그래도 빈 답 · 거절은 E18대로 '답 없음'에 셉니다(노트 호출이면 §2대로 그 회 L · O에서 빠짐). 탭 기록은 따로 적는 열입니다.

#### 도구가 글을 읽는 방식 (재기 전에 정함)

도구는 설계 파일럿 도구(`impl112/design/G6/final/tools/`, `design/G6/tools/`)를 짓기 커밋의 트리에 맞춰 `impl112/b1/` 아래에 다시 지었습니다. 계획이 '새로'라고 한 것(pick · n2verify · 꼬리표 · 봉인 · 기계 셈 · 프로브 사본 · 탭 사본)도 여기서 지었습니다. `impl112/d26/rulewide.mjs`는 짓기 때 지었고 sha256을 적습니다. 파일럿 판정자는 견본.md에서 다시 지은 것이고 얼린 적이 없어(설계 R8), 잰 판정자 `tools/judge.py`는 이 입장의 조항과 세부를 한 줄씩 대어 다시 지었습니다.

1. 트리: `mtree/`는 짓기 커밋 a4ac818의 `git archive`(docs · README · CHANGELOG 뺌)이고, `mtree/hooks/notes.ts` · `register.tsx`는 위 sha256과 같습니다. 판정의 읽기 트리 `jtree/hooks/notes.ts`는 mtree의 notes.ts에서 `ANY_HEADING` · `DRILL_HEADING` · `taskLineOf` 앞에 `export `만 더한 것입니다(다른 바이트 같음; 세부 16의 칸 나누기를 그대로 쓰려고). 옛 창 여섯 `old/<커밋>/hooks/notes.ts`는 `git show <커밋>:hooks/notes.ts`이고 sha256은 a4ac818 본문과 같습니다(3f2b4fb = 7a7b08c, 3d2f251 = de98243). 프로브 mod의 `probe/mod/hooks/notes.ts`도 mtree의 notes.ts와 바이트까지 같습니다.
2. 견본 쓰기(`gen/common.md` · `gen/part-{A,B,C,D}.md` · `gen/avoid.py` · `gen/run.sh`): 쓰는 쪽마다 새 `claude -p --model opus --tools ''`(고정한 길, 빈 폴더, 프롬프트는 stdin). 답 · 시각 · 쓴 쪽(result의 modelUsage 키)을 `gen/out/<쓰는 쪽>/`에 둡니다. 답은 고치지 않습니다.
3. 꺼내기와 얼리기(`tools/extract.py` · `tools/check.py` · `tools/lexcode.py` · `tools/runlib.py` · `tools/key.py` · `tools/prep.py`): extract가 넷의 답을 `frozen/raw.json`(chmod 444)과 쓴 쪽 기록으로 묶고, check가 위 '얼릴 때 확인'을 모두 해서 `frozen/samples.json` · `frozen/check-report.json`(chmod 444; 무리마다 대체 수와 짜임)을 씁니다. 대역과 돌리기는 runlib(§8, 세부 4 · 5 · 12 · 13: js · ts 두 번, py 씨앗 1–5 다섯 번, `unshare -n timeout 5`, TZ=UTC), 열쇠와 이름 찾기는 key(§5, 세부 1), F의 주석 · 문자열 가르기는 lexcode(템플릿의 `${…}`와 f-string의 `{…}`는 코드로 둠)입니다. prep가 엔진 꼴의 hunk(`frozen/hunks.json`)를 짓습니다(1.11.0 prep.py와 첫 줄만 다름).
4. 짜기(`tools/build.mjs` · `tools/notekit.mjs`): note는 모델마다 노트 줄 85개(`frozen/note-lines-<모델>.jsonl`), drill은 그 모델 회의 노트 답으로 plan.json과 2단 줄(`stage/<회>/<모델>/drill-lines.jsonl`), read는 켠 · 끈 최종 글(§1)입니다. 노트는 notekit이 changeOf · creationHunk · merge로 플러그인처럼 꾸미고 screenNote로 가립니다.
5. D34(`d34/expect.mjs` · `d34/make.py`, 셈에 들지 않음): 짓기 트리 사본의 flowkit에 요청을 통째로 잡는 줄과 얼린 변경의 Edit/Write 결과를 주는 줄만 더하고, 견본마다 시험 하나로 Write/Edit → 턴 끝의 노트를 돌려 잡은 요청을 도구 줄과 견줍니다. pre: 부르기 전, 견본 × 모델마다 O 답(요청 하나), 그 견본의 첫 규칙을 짚는 고정 답(노트 + 2단 요청 또는 없음), 하네스 없는 같은 답(노트 요청 하나). real: 모델-스테이지 안에서 그 모델의 실제 노트 답으로 노트 + 도구의 2단 줄(1단 · 건너뜀은 둘째 요청 없음). n2: N2를 얼린 뒤 그 노트(회 A의 노트 · 2단 답)의 연습 칸에 답을 쳐서 잡은 채점 요청 = N2 줄.
6. 부르기(`tools/stage.sh` · `tools/gate.py` · `probe/precheck.sh` · `probe/call.sh` · `probe/record.py` · `probe/mod/`): 위 '부르기'의 러너. 프로브 mod(명령 `/g6probe <줄> <답 파일> <상태 파일>`)는 1.12.0 보정 프로브의 꼴에 호출마다 상태 줄(id, answered, reason, status, output_tokens, ms; 글 없음)을 더합니다. 엔진에 덧붙이기가 없어 상태 파일을 앞 줄 그대로 두고 통째로 다시 씁니다(늘기만 함).
7. 탭(`tools/tapsend.py` · `tap/`): 1.11.0 탭의 사본(명령 `/g6tap`, `tap/tap.py`는 1.11.0 것과 바이트까지 같음). 기록만.
8. 꼬리표와 읽기(`tools/label.py` · `tools/read2.mjs`): seal은 회 A · B가 두 모델 모두 DONE일 때 P · Q 짝을 난수로 봉하고(`judge/pair.json` chmod 444, sha256만 찍음), read는 꼬리표마다 build.mjs read와 read2.mjs로 `judge/<꼬리표>/read-<회>.json` · `read2-<회>.json`(chmod 444)을 씁니다. read2는 §4(drillOf 켬 · 끔), §13(세부 16), §14(세부 19, 옛 창 여섯), §11(세부 15: fca5988의 ruleLabelled(closeConceptBold(cut(답, 9000)))와 그 drillOf(…, false), 트리의 keptNoteText(답, [])와 같은지도 적음), 멱등을 셉니다.
9. 판정(`tools/judge.py`): 꼬리표 · 회마다 `judge/verdicts-<꼬리표>-<회>.md`(행마다 근거 먼저)와 `.json`(chmod 444). §3 · §6 (i)–(vi) · §7(S-a와 세부 6–11) · §9 · §10 · §11 · §12 · §13 · §14, 세부 17. 모델 이름 · 토큰 · 시간 · 상한은 읽지 않습니다. 글이 정하지 않은 꼴(예: 연습 줄이 after의 그 행에 없음)은 해로움 쪽으로 세고 undecided에 적습니다(§15).
10. 기계 셈(`tools/count.py`): 꼬리표마다 스테이지별 호출 · 답함 · 까닭 · api-error · 상한 닿음 · output_tokens 가장 큰 것과 가운데 · 시간, 탭의 거절 열, 그리고 규칙 연습 답 없음 줄(세부 18)을 `judge/count-<꼬리표>.json`(chmod 444)에. 판정자와 행 확인자는 이 파일을 받지 않습니다.
11. 행 확인(`tools/rowcheck.py` · `judge/tpl-rowcheck.md` · `judge/stance-G6.md`): 세부 21. stance-G6.md는 이 절의 '판정의 입장'에서 '결정 규칙' 앞까지를 그대로 자른 것입니다. 확인자가 적은 행은 넘는 쪽에 불리하게 셉니다(M-9).
12. N2(`tools/pick.py` · `tools/n2prompt.py` · `gen/n2-frame.md` · `gen/n2run.sh` · `tools/n2verify.py` · `tools/n2build.mjs`): pick은 꼬리표의 회 A 판정에서 바른 연습을 id 차례로 다섯씩 묶어 보아 여섯 조건(규칙 넷, py, ts)을 가장 많이 채우는 첫 묶음을 고르고 못 채운 조건을 적습니다. n2prompt가 그 다섯을 gradeDrill이 보이는 대로(할 일 · 확인 · 고칠 줄 · 예시 답 · 규칙 줄 · 파일 · demo, 바뀐 뒤 파일 전체)와 팀 파일로 쓰는 쪽 프롬프트를 짓고, n2run이 새 opus 쓰는 쪽을 부릅니다. n2verify가 세부 22대로 답을 돌려 보고(gradeDrill이 부르지 않는 줄은 n2build.mjs skips: isBlankAnswer · sameLine(예시 답 · 고칠 줄) · isKoreanTyped), 같은 갈래 예비로 채우거나 빼고 적습니다. n2build.mjs lines가 짝 파일로 그 꼬리표의 모델에 줄을 보내고(짝을 찍지 않음), judge가 세부 23대로 셉니다.
13. 결정(`tools/decide.py`): 모든 판정 파일이 얼려진 뒤 위 결정 규칙을 꼬리표마다 기계로 쓰고, 끝에 짝을 열어 모델마다 적습니다(`judge/decision.json` chmod 444). 기준 커밋의 isRuleWide 값은 mtree의 MODEL_SWITCHES에서 읽습니다.
14. 짓기 때 쓴 도구(기록, 이 커밋으로 함께 얼림): `tools/probe_off.mjs`(끈 바이트), `tools/oldwin.mjs`(옛 창 여섯), `tools/mutants.py`(돌연변이 탐침), `impl112/d26/rulewide.mjs`(isRuleWide D26). 값 커밋(R9)과 뒤 묶음의 재확인이 다시 씁니다.
15. 도구 시험(견본 · 모델 호출 0, 저장소 밖 `impl112/b1/test/`): 개발 세트 4(측정에 쓰지 않음)의 견본과 적어 둔 개발 답을 입력으로만 썼습니다.
    - check.py가 개발 세트 4의 42개를 모두 받음(개발 check4가 문자열 안 표지로 잃은 F 3개 포함, S-c대로), 손으로 바꾼 견본 8개(expected 다름, R의 주석 속 표지, N으로 바꾼 F, 40자 넘는 R, 40자 이하 R_long, import 없음, 표지가 남은 fix, 개발 경로)를 모두 거절하고 받아야 할 2개(좋은 R, 문자열 안에만 표지가 있는 F)는 받음.
    - prep.py의 hunk가 개발 세트 4의 hunk와 39/39 같음(나머지 3개는 개발 때 빠진 F). 노트 줄이 파일럿 세트 4의 노트 줄과 모델마다 39/39 바이트까지 같음, 2단 줄이 파일럿 2단 줄과 haiku 9/9 · sonnet 13/13 같음(파일럿에만 있던 앵커 건너뜀 1개 빠짐).
    - 그 답을 회 A · B로 놓고 seal → read → read2 → judge를 돌려 설계 기록과 같은 수: haiku 꼬리표 den 18 · 바름 16, sonnet 꼬리표 den 23 · 바름 19, 해로움 0, 할 일 둘 2(D4B02 · D4B21), 옛 창 나쁜 것 0, W 오탐 0. judge의 손 사례 9개(h3, 다른 규칙의 효과 말, 확인 줄 없음, 함정의 규칙 연습, 할 일 둘, 표지 없는 규칙 연습, O 글 다름 등) 모두 기대대로.
    - pick → n2prompt → (가짜 쓰는 쪽) → n2verify → n2build lines → (가짜 채점 답) → n2build judge → count → (가짜 행 확인) → decide가 끝까지 돌고, 못 넘는 줄(O < 20, den < 20, 할 일 둘, 행 확인으로 깎인 80%, 읽지 못한 N2 답)을 바르게 못 넘음으로 냄.
    - D34(실제 `claude plugin test`, 고정한 CLI, 모델 호출 0): pre 252개 시험의 요청 268개, real 39 + 39개 시험의 요청 48 · 52개, n2 30 + 30개가 모두 바이트까지 같음; 2단 줄 한 글자를 바꾼 사본은 다름 1로 잡힘.
    - 프로브 mod와 탭 mod는 시험 키트로(4개씩 · redactText · fixEscapedTicks · 상태 줄이 늘기만 함 · 글 없음 · 던진 호출 · 다시 부르면 거절), stage.sh는 가짜 `claude`로(관문 넘음 → DONE, 다시 → STARTED로 거절, M-3 차례 거절, ONLY_WORKFLOW 없음, five_hour 0.70 → WAIT, 회 A haiku의 seven_day 0.45 + 0.40 → WAIT, 판 다름 · 고정 sha 다름 → STOP, 세션 id 다름 → VOID, api-error 7/49 → VOID, 던진 호출 → THREW) 시험했습니다. tapsend는 가짜 `claude`로 파일 길만(상류 탭 자체는 1.11.0에서 시험한 tap.py 그대로).

#### 틀과 도구 (sha256, 이 커밋으로 얼림, 저장소 밖 `impl112/b1/` 아래, chmod 444)

{TABLE}

