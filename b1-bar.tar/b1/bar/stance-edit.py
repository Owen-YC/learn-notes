"""Builds the re-committed stance (§0-§15, N2 입장) and details 1-24 from the 1.10.0 text at 432ced4 (= HEAD lines
1508-1605 and 1611-1634), with the design's changes put in as 1.10.0 did: the changed words struck (~~ ~~) and the
1.12.0 text beside them. Writes bar/stance-110.md and bar/details-110.md."""
import sys
B = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1/bar"
t = open("/home/user/learn-notes/docs/qa/견본.md", encoding="utf-8").read().split("\n")
stance = t[1507:1605]   # §0 .. N2 입장 (lines 1508-1605)
details = t[1610:1634]  # 1. .. 24. (lines 1611-1634)
assert stance[0] == "§0 커밋과 스크립트" and stance[-1].startswith("N2 입장:"), (stance[0], stance[-1][:20])
assert details[0].startswith("1. §5 찾기") and details[-1].startswith("24. "), (details[0][:20], details[-1][:20])
S = "\n".join(stance)
D = "\n".join(details)

def rep(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)

S = rep(S, "§1 부르기와 읽기는 플러그인과 같습니다\n", "§1 부르기와 읽기는 플러그인과 같습니다 (1.12.0에서 바꿈: 켠 읽기 한 줄)\n")
S = rep(S, "- 켠 읽기: noteRuleOf가 읽히면 RULE_DRILL_SYSTEM · ruleDrillPrompt(screened, team.rules, 그 줄), maxTokens RULE_DRILL_TOKENS(3500)로 부르고, fixEscapedTicks → withRuleDrill(글, 답, changes, names) ?? 글.\n",
        "- ~~켠 읽기: noteRuleOf가 읽히면 RULE_DRILL_SYSTEM · ruleDrillPrompt(screened, team.rules, 그 줄), maxTokens RULE_DRILL_TOKENS(3500)로 부르고, fixEscapedTicks → withRuleDrill(글, 답, changes, names) ?? 글.~~\n"
        "- 켠 읽기(1.12.0): 노트 답 → fixEscapedTicks → keptNoteText(답, names) → noteRuleOf가 읽히면 그 판 트리의 ruleFixPlan(screened, rules, 그 줄). 1단이면 ruleFixMade(글, fix, changes) ?? 글, 2단이면 RULE_DRILL_SYSTEM · redactText(ruleDrillPrompt(screened, rules, 그 줄, cands)) · 3500 · 90000으로 부르고 fixEscapedTicks → ruleFixReply가 받은 글 ?? 글, 건너뜀이면 글 그대로.\n")
S = rep(S, "- 상한 닿음은 output_tokens ≥ maxTokens + H_M입니다(계획 고침 D4, M-5: G6의 상한 몫 = H_M, haiku 2048 · sonnet 0, 묶음 1 보정 기록). 닿았어도 글이 읽히면 읽힌 대로 매깁니다.",
        "- 상한 닿음은 output_tokens ≥ maxTokens + H_M입니다(계획 고침 D4, M-5: G6의 상한 몫 = H_M, ~~haiku 2048 · sonnet 0, 묶음 1 보정 기록~~ 1.12.0 보정 기록의 haiku 2048 · sonnet 2048). 닿았어도 글이 읽히면 읽힌 대로 매깁니다.\n"
        "- (1.12.0, 설계 §2를 옮김) 노트 호출이 답하지 않은 견본은 그 회 L · O에서 빼고 수만 적습니다. 규칙 연습 호출의 상한 닿음 · 빈 답(API 거절 포함) · 시간 한도는 '답 없음' 줄에 셉니다(n = 그 모델 두 회의 2단 호출 수). 닿았어도 글이 읽히면 읽힌 대로 매깁니다. 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.12.0 보정).")
S = rep(S, "§14 옛 창: 3f2b4fb · 7a7b08c · 3690021 · fca5988의 notes.ts 사본(꺼진 상수 그대로)으로 모든 회의 켠 · 끈 최종 글에 drillOf · hideDrillAnswer를 돌립니다.",
        "§14 옛 창: 3f2b4fb · 7a7b08c · 3690021 · fca5988의 notes.ts 사본(꺼진 상수 그대로)으로 모든 회의 켠 · 끈 최종 글에 drillOf · hideDrillAnswer를 돌립니다.\n"
        "- (1.12.0에서 더함, 엄격하게) 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988에 3d2f251 · de98243을 더한 여섯입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.")
D = rep(D, "상한 닿음은 output_tokens ≥ maxTokens + H_M(haiku 2048 · sonnet 0)이고, 답한 호출도 닿았으면 셉니다.",
        "상한 닿음은 output_tokens ≥ maxTokens + H_M(~~haiku 2048 · sonnet 0~~ 1.12.0 보정: haiku 2048 · sonnet 2048, 곧 2단 호출 5548)이고, 답한 호출도 닿았으면 셉니다. (1.12.0) 규칙 연습 호출은 2단 호출이고(1단 · 건너뜀은 호출 없음), 빈 답은 API 거절을 포함합니다(E18).")
D = rep(D, "옛 창 넷의 drillOf가 연습을 주지 않고,", "옛 창 ~~넷~~ 여섯(1.12.0, §14)의 drillOf가 연습을 주지 않고,")
D = rep(D, "표지 없는 노트는 그 창의 drillOf가 1.10.0의 그 읽기(켬 · 끔)와 같은 할 일 · 고칠 줄 · 예시 답 · 파일 · 행을 줘야 합니다. 켠 · 끈 최종 글 모두, 네 창 모두입니다.",
        "표지 없는 노트는 그 창의 drillOf가 ~~1.10.0의 그 읽기(켬 · 끔)~~ 3d2f251의 drillOf로 그 읽기(켬 · 끔)를 한 것(1.12.0, §14)과 같은 할 일 · 고칠 줄 · 예시 답 · 파일 · 행을 줘야 합니다. 켠 · 끈 최종 글 모두, ~~네~~ 여섯 창 모두입니다.")
open(f"{B}/stance-110.md", "w", encoding="utf-8").write(S + "\n")
open(f"{B}/details-110.md", "w", encoding="utf-8").write(D + "\n")
print(len(S), len(D))
