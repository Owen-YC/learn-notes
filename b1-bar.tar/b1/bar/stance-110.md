§0 커밋과 스크립트
- 판정 스크립트(저장소 밖)를 이 입장대로 먼저 쓰고, 그 sha256을 이 커밋에 적습니다.
- 출력을 본 뒤 스크립트가 이 글과 다르게 센 것이 드러나면 글대로 다시 세고 스크립트 diff를 견본.md에 남깁니다. 글(입장 · 열쇠 · 기준)은 바꾸지 않습니다.

§1 부르기와 읽기는 플러그인과 같습니다 (1.12.0에서 바꿈: 켠 읽기 한 줄)
- 팀 파일은 그 판 트리의 parseTeamFile로 읽습니다. names = ruleNamesOf(team.rules)(잰 모델의 isRuleWide를 켠 상태).
- 노트: SYSTEM, notePrompt(screened, 'beginner', [], team), maxTokens NOTE_TOKENS(3500).
- 노트 답: fixEscapedTicks → keptNoteText(답, names).
- ~~켠 읽기: noteRuleOf가 읽히면 RULE_DRILL_SYSTEM · ruleDrillPrompt(screened, team.rules, 그 줄), maxTokens RULE_DRILL_TOKENS(3500)로 부르고, fixEscapedTicks → withRuleDrill(글, 답, changes, names) ?? 글.~~
- 켠 읽기(1.12.0): 노트 답 → fixEscapedTicks → keptNoteText(답, names) → noteRuleOf가 읽히면 그 판 트리의 ruleFixPlan(screened, rules, 그 줄). 1단이면 ruleFixMade(글, fix, changes) ?? 글, 2단이면 RULE_DRILL_SYSTEM · redactText(ruleDrillPrompt(screened, rules, 그 줄, cands)) · 3500 · 90000으로 부르고 fixEscapedTicks → ruleFixReply가 받은 글 ?? 글, 건너뜀이면 글 그대로.
- 끈 읽기: 같은 노트 답의 keptNoteText 글 그대로.
- 두 호출 모두 redactText, effort low, timeoutMs 90000이고, 그 판 notes.ts 사본의 함수를 그대로 부릅니다.

§2 답이 없거나 상한에 닿은 답
- 노트 호출이 답하지 않으면(빈 답 · 시간 한도 · 오류) 그 견본은 그 회의 L · O에 넣지 않고 수만 적습니다. 그래서 den이 20 아래면 (b), O가 20 아래면 (a)가 못 넘음입니다.
- 규칙 연습 호출이 답하지 않으면 그 노트는 자기 칸 그대로(플러그인과 같음)이고, 그 꼴대로 매깁니다. 상한 닿음 · 빈 답 · 시간 한도는 '답 없음' 줄에 셉니다. API 오류는 수를 적고 다시 부르지 않습니다.
- 상한 닿음은 output_tokens ≥ maxTokens + H_M입니다(계획 고침 D4, M-5: G6의 상한 몫 = H_M, ~~haiku 2048 · sonnet 0, 묶음 1 보정 기록~~ 1.12.0 보정 기록의 haiku 2048 · sonnet 2048). 닿았어도 글이 읽히면 읽힌 대로 매깁니다.
- (1.12.0, 설계 §2를 옮김) 노트 호출이 답하지 않은 견본은 그 회 L · O에서 빼고 수만 적습니다. 규칙 연습 호출의 상한 닿음 · 빈 답(API 거절 포함) · 시간 한도는 '답 없음' 줄에 셉니다(n = 그 모델 두 회의 2단 호출 수). 닿았어도 글이 읽히면 읽힌 대로 매깁니다. 상한 닿음 = output_tokens ≥ maxTokens + H_M(1.12.0 보정).

§3 L과 O
- 노트 답의 keptNoteText 글에서 noteRuleOf(연습 제목 앞, 제목이 없으면 글 전체)가 `팀 규칙과 다를 수 있음:` 줄(없음 아님)을 읽으면 L, 아니면 O입니다. 한 번 정해 켠 읽기와 끈 읽기에 함께 씁니다.
- `팀 규칙:` 줄만 있으면 O입니다.
- den = L 가운데 그 견본의 violations에 들여쓰기 빼고 40자 이하인 줄이 하나라도 있는 노트.

§4 연습의 종류
- 최종 글(켠 읽기는 withRuleDrill 뒤, 끈 읽기는 keptNoteText 글)에 drillOf(글, changes, 그 읽기의 켬 여부)를 돌립니다.
- rule을 주면 규칙 연습, rule 없이 주면 개념 연습, undefined면 연습 없음입니다.

§5 채점 열쇠 (팀 파일에서 나오며 함께 얼림)
| 규칙 | 쓰라는 이름 | 쓰지 말라는 표지 | 낱말 |
| --- | --- | --- | --- |
| 요청 | apiRequest · api_request | fetch( · requests. | 요청 · API · 서버 |
| 기록 | log.info | console.log · print( | 기록 · 로그 |
| 날짜 | toDateText · to_date_text | toISOString · toJSON · toLocaleDateString · toDateString · getFullYear · getMonth · getDate · getUTCFullYear · getUTCMonth · getUTCDate · strftime · isoformat | 날짜 |
| 설정 | config | process.env · os.environ · os.getenv | 설정 · 환경 변수 |
- 이름과 표지는 holdsName처럼 온전한 이름으로 찾습니다(`fetch(`는 `fetch` 뒤에 공백 없이 여는 괄호, `fetcher(` 안이 아님).
- 들인 규칙: 예시 답이 고칠 줄에는 없는 그 규칙의 쓰라는 이름을 품는 규칙들.
- 짚은 규칙: 노트의 `다를 수 있음` 줄 글에 그 규칙의 쓰라는 이름이나 표지가 있는 규칙들. 하나도 없으면 낱말이 있는 규칙들. 그것도 없으면 없음입니다.

§6 바름 (모두 맞아야 함. 다음을 모두 만족하는 규칙 r이 있어야 함)
- (i) 규칙 연습입니다.
- (ii) r이 들인 규칙이고 짚은 규칙입니다.
- (iii) 고칠 줄이 r의 violations 줄입니다(같은 파일, 공백 · 끝 `;` · `,` 빼고 같음).
- (iv) 예시 답이 r을 지킵니다: r의 쓰라는 이름을 품고, r의 표지가 남지 않으며, 그 줄만 예시 답으로 바꾼 파일의 demo 표준 출력(두 번)이 그 violation의 expected_fixed와 §7 정규화로 같습니다. 규칙과 상관없는 부분을 바꿔 출력이 달라지면 지키지 않음입니다.
- (v) 그 파일이 두 번 모두 오류 없이 돕니다. 원래 파일은 얼리기 전에 대역에서 돈다는 것이 확인되었으므로, 오류는 예시 답 탓으로 셉니다(정의되지 않은 이름 · import 없는 이름 포함).
- (vi) 확인 줄이 있고 그 주장이 §7로 참입니다.

§7 확인 줄
- 돌리는 것: 확인 줄 백틱 안의 첫 호출이 바꾼 파일에 정의된 함수를 부르면 그 호출을 돌립니다. 자리표시(`…` · `[A]` · `<…>`)이거나 말로만 쓴 확인이면 견본의 demo를 돌립니다.
- 변경의 파일에 없는 함수를 부르면 거짓입니다(1.9.0 G15). 확인 줄이 없으면 거짓입니다(A01).
- 돌린 결과 = 호출 값(await한 값) · 표준 출력 줄 · 대역 기록 줄(표준 출력과 따로 모음, §8).
- 주장의 꼴
  - (1) 값(백틱 · 따옴표 안, 또는 수): 정규화한 값이 호출 값과 같거나, 표준 출력이나 기록의 한 줄과 같아야 합니다. 값이 여럿이면 모두입니다(1.9.0 C18).
  - (2) 같음 말('같은 · 그대로 · 똑같이 · 변함없이 · 달라지지 않')만 있으면: 호출 값과 표준 출력이 원래 줄로 돌린 것과 같아야 합니다.
  - (3) 효과 말(그 규칙의 쓰라는 이름, '기록 · 로그가 남', '인증 · 재시도', '설정에서 읽', '날짜 글자로'): 기록 줄에 그 규칙 함수가 그 호출 동안 불린 줄이 있어야 합니다.
  - (4) 섞이면 각 부분이 다 맞아야 합니다.
  - (5) '…라고 가정 · …이면' 같은 조건: 견본 env · responses로 돌린 결과로만 매깁니다. 견본이 그 조건을 주지 않으면 거짓입니다.
  - (6) 그 밖의 꼴(값 · 같음 말 · 효과 말이 없음)은 거짓입니다.
- 정규화: 앞뒤 공백을 떼고 공백을 하나로 줄이며, `'`를 `"`로, 끝 `;`를 뗍니다. 둘 다 JSON으로 읽히면 값으로 견주고, 수는 값으로, 파이썬 True · False · None은 true · false · null로 봅니다.
- 줄인 출력: 말한 값이 맞으면 맞음이고, 말한 값이 하나라도 틀리면 거짓입니다.
- 날짜는 TZ=UTC입니다.

§8 대역과 돌리기
- 팀 모듈 넷(js · ts · py)을 둡니다. apiRequest · api_request, 미리 심은 globalThis.fetch, requests.get이 견본 responses로 같은 응답을 줍니다.
- config와 환경 변수는 견본 env로 같은 글자를 줍니다(`config.X` · `config["X"]` · `config.get("X")` 모두). log.info는 console.log · print와 같은 글을 표준 출력에 찍습니다. toDateText는 UTC YYYY-MM-DD를 줍니다.
- 대역은 불릴 때마다 `[apiRequest] 주소` · `[log.info] 인자` · `[config] 이름` · `[toDateText] 값`을 표준 출력이 아닌 기록 파일에 씁니다.
- 빈 임시 폴더에서 `unshare -n timeout 5`, js `node`, ts `node --experimental-transform-types`, py `python3 -I`로 돌립니다. 파일에 import를 덧붙이지 않습니다. 호출 값은 돌리는 틀이 사본 끝에 붙인 한 줄이 `[value] JSON`으로 찍습니다. (계획 고침 D14: py는 B-14대로 `env -i PATH LANG=C.UTF-8 PYTHONHASHSEED=<n> python3 -s -P -B`를 n = 1~5로 다섯 번 돌려 다섯이 모두 같아야 하고, ts 실행은 B-15의 `node --experimental-transform-types`입니다.)
- 구문 오류 = 바꾼 파일을 불러올 때 SyntaxError(파이썬은 py_compile 실패).
- 돌지 않는 연습(대역이 받치지 못한 경우 포함)은 (v)나 (vi)에서 거짓입니다. 읽어서 매기는 갈래는 없습니다.

§9 표지 없는 규칙 연습
- 개념 연습 가운데, 예시 답이 어떤 규칙의 쓰라는 이름을 고칠 줄에 없이 품는 것입니다.
- 할 일 글은 보지 않습니다. 할 일이 팀을 말하지만 이름을 들이지 않는 연습(1.9.0 G19 꼴)은 개념 연습입니다.
- 켠 읽기와 끈 읽기에서 모두 셉니다.

§10 해로움 (규칙 연습인데 다음 가운데 하나)
- (h1) 들인 규칙이 없음(규칙이 아닌 일을 시킴)
- (h2) 고칠 줄이 들인 규칙 어느 것의 violations 줄도 아님(헛짚은 L · 함정 · R_long에서 낸 규칙 연습 포함)
- (h3) 예시 답에 들인 규칙의 표지가 남음(거꾸로 바꿈 포함)
- (h4) 바꾼 파일에 구문 오류
- 확인 줄만 거짓이거나 (ii) · (iv)의 출력만 다른 것은 바르지 않음이지 해로움이 아닙니다.

§11 W 오탐
- 끈 읽기에서 HEAD fca5988의 ruleLabelled 글과 keptNoteText 글이 다른 노트를 봅니다.
- 그 노트의 연습(HEAD 글을 drillOf(…, false)로 읽은 것)이 다음을 모두 만족하지 않으면 오탐입니다: 고칠 줄이 어떤 규칙 r의 violations 줄이고, 예시 답이 r의 쓰라는 이름을 고칠 줄에 없이 품습니다.
- HEAD 글에서 연습이 읽히지 않던 노트(연습 없음)에 표지가 붙은 것은 오탐이 아닙니다.

§12 (c): O 노트마다 켠 읽기와 끈 읽기의 최종 글을 바이트로 견주고, 켠 회의 호출 기록에 O 노트의 규칙 연습 호출이 없는지 봅니다.

§13 할 일 줄 둘: 최종 노트의 직접 해 보기 칸(합친 칸 포함)에 할 일 줄이 둘 이상인 경우입니다.

§14 옛 창: 3f2b4fb · 7a7b08c · 3690021 · fca5988의 notes.ts 사본(꺼진 상수 그대로)으로 모든 회의 켠 · 끈 최종 글에 drillOf · hideDrillAnswer를 돌립니다.
- (1.12.0에서 더함, 엄격하게) 옛 창은 3f2b4fb · 7a7b08c · 3690021 · fca5988에 3d2f251 · de98243을 더한 여섯입니다. 표지 없는 노트의 기준 읽기는 3d2f251의 drillOf입니다.

§15 판정 파일
- 스크립트가 행마다 근거(돌린 출력 · 들인 규칙 · 짚은 규칙 · 맞춘 주장 꼴)를 verdicts-<꼬리표>-<회>.md에 먼저 쓰고, 표는 그 파일만 셉니다. (계획 고침 D7: 꼬리표마다 따로 돌려 얼리고, N2는 verdicts-<꼬리표>-n2.md. 모든 판정 파일이 얼려진 뒤 짝 파일을 엽니다.)
- 판정 파일을 쓴 뒤에는 입장 · 열쇠 · 기준을 바꾸지 않습니다.
- 이 글이 정하지 않은 꼴이 나오면 넘는 쪽에 불리하게(바르지 않음 · 해로움 · 오탐 · 표지 없는 규칙 연습) 세고, 그 꼴을 견본.md에 적습니다.
- 기록만 하는 것(판정에 넣지 않음): 할 일이 라벨 설명을 옮겨 적었거나 어느 줄을 어떻게 고칠지 말한 것, 1.9.0 정의의 (b), L 노트가 개념 연습을 규칙 연습으로 바꾼 수, 규칙 연습 호출의 출력 토큰 · 시간.

N2 입장: 1.9.0 N2와 같습니다. 얼린 기대 판정과 견주고, parseCheck(text, { rule: true }) 뒤 '안 지킴 + 맞음 → 거의' 낮추기를 거친 판정으로 셉니다. 바른 판정은 지키고 동작함 → 맞음, 어겼지만 동작함 → 거의 또는 틀림, 깨짐 → 틀림 또는 거의, 엉뚱함 → 틀림입니다.
