| 파일 | 하는 일 | sha256 |
| --- | --- | --- |
| `team.md` | 팀 파일(1.10.0 것 그대로) | `18f9d5c755f49db4f9dd767b380bdda569609ffa6a6021ca9f9525881a9b0c9b` |
| `gen/common.md` | 쓰는 쪽 공통 프롬프트 | `1d55fe37c23651ab77a8b502b3b99956654c1fdbb2dd8b847cca96a9fdd0de4c` |
| `gen/part-A.md` | 쓰는 쪽 A(R 20 + 예비 2) | `c6a6ff4010041da5a10326e079f8a7d3cac22ad951e7b77abbc4f67b9561d753` |
| `gen/part-B.md` | 쓰는 쪽 B(R 20 + R_long 4 + 예비 4) | `5ffa4358a788d3a5b7ea81f7e5003020f265022a39ef27c3d075bffffa02b33b` |
| `gen/part-C.md` | 쓰는 쪽 C(F 12 + N 12 + 예비 4) | `5f6bc440fcb8c069aea7eb8afa96ce507225ecc7e496117e65711231c15b0977` |
| `gen/part-D.md` | 쓰는 쪽 D(함정 9 + multi 4 + double 4 + 예비 6) | `1cc49c50274cbdaa718facb80fbd987872eabb35f58b597d8045702233f8606b` |
| `gen/avoid.py` | 피할 이름 절 | `1c75fb3e441f31c537353182779014c4d087db704b12b35ac8178679746fadc6` |
| `gen/run.sh` | 견본 쓰는 쪽 실행 | `eb529f9b58072955825e35a08a9730484b895195d0dff3a252e7db5df473be76` |
| `gen/n2-frame.md` | N2 답 쓰는 쪽 틀 | `e5ea60af9d10c260c9ea95529d2d13538a1ee8e446ba1e78fa618ff6393f7d78` |
| `gen/n2run.sh` | N2 답 쓰는 쪽 실행 | `c1775d46cf25d05a558a34cca5ab9a03b8cb9aa72574596a3e2afe27d6086df8` |
| `tools/extract.py` | 쓰는 쪽 답 묶기 | `9961d629cb67a3052ecedf2788cf560cee6573ded5b42f7c96121228b76af60d` |
| `tools/check.py` | 얼릴 때 확인 · 예비 대체 | `3eb72ebfca3caeb22e9d375ef428208b2e5deaa3ef74c4408f5e1614f924075c` |
| `tools/lexcode.py` | 주석 · 문자열 가르기(F) | `fdc422b4e846f17d398ace243e2a09306a47137f5acc24f86c85c0a309ff1e94` |
| `tools/runlib.py` | 대역과 돌리기(§8) | `d30ed6255a3c1cfe0eed147b281868997d87e4b2d14fb5f814bd07398401e7d3` |
| `tools/key.py` | 채점 열쇠(§5) · 이름 찾기 | `d99012f6fb85b1c28b08cda7aeac51d556b5a141eda65facb2cd823ec2f72ceb` |
| `tools/prep.py` | 엔진 꼴 hunk | `ecbd0f9d00a43cd0cffb057e1261004926d24f2c82621565f516fd08b4310cfe` |
| `tools/build.mjs` | 노트 · 2단 줄 짜기, 켠 · 끈 읽기(§1) | `2c73247ac07ee80034331073f50b03d976c4a7f5ce272b3b4b21d45d236da4b6` |
| `tools/notekit.mjs` | 노트 꾸미기 | `ade740be098b73b630a132a98cab6911d9eba8bf0f07d195f38935bb28da1dd6` |
| `tools/read2.mjs` | 판정 입력(§4 · §11 · §13 · §14) | `f966ae79605c40eecd0a985caa00b4331d84eb6bb445fd469a1ee9ee18565e39` |
| `tools/judge.py` | 기계 판정자 | `ae1b0b67e7b2c64a155f68e52bd8e13846dfbc416f6e27e3fa760c3ed5094936` |
| `tools/count.py` | 기계 셈(꼬리표마다) | `e62c005c9947eebaae0b42ce9bf44af96230354a7a16cb99661b9ed8a41cae3f` |
| `tools/label.py` | 꼬리표 봉인 · 읽기 | `dc7512bdb8eb5ab97972f5272046480bef5e12420289ecb1de1db94e037ed771` |
| `tools/pick.py` | N2 고르기 | `56ba1843e8aa5f2b11507ef089ed8d50be7a6096da5fad9be08ff52b9d14addc` |
| `tools/n2prompt.py` | N2 쓰는 쪽 프롬프트 | `c0a8db30c0fea2bf2993f4d7843a620d18fc4e3ac0daf337c49cf53e1bd05978` |
| `tools/n2verify.py` | N2 대역 확인(세부 22) | `4183f036d9ccf3f3c2a3e01573909460f06d556d3a538b7f0a659f5ad393a29c` |
| `tools/n2build.mjs` | N2 줄 · 셈(세부 23) | `2586ff36fc0d9fc1527d20e91839978e7495fe7fdb6d292ae5fe6433e14270ff` |
| `tools/rowcheck.py` | 행 확인(세부 21) | `ee0ae8af543ae701a568ab3678757249ef13d4d550945799586169880b990c91` |
| `tools/decide.py` | 결정 규칙 | `87abae95d180dbb390993716b0dc373ac0a11e4805897677cb3cbf5105f302f4` |
| `tools/gate.py` | 앞뒤 기록 · 사용량 관문 | `d1aabc2e5eea7ba25564a41dddc3e45e95525f1e3bd9c25dc8e356d15dd5276b` |
| `tools/stage.sh` | 떼어 낸 러너 | `0c7fc55cfbb0dc21c1e2dd53592b82f6032a49a71d3d0d0cf89a825d32871789` |
| `tools/tapsend.py` | 빈 답의 탭(기록) | `78487e897bd904d74c2a71eb4d8522a37419dbdd312fcbc9e30745b83a7e7ebb` |
| `tools/probe_off.mjs` | 끈 바이트(짓기 때) | `561da71f29003546ff7ce840adeb8cf438cc89d6443d09485d8b626ef2c9d113` |
| `tools/oldwin.mjs` | 옛 창 여섯(짓기 때) | `3d87ba26828a2216f62813366fcb1c0144bf209313ad02802b169a24c2709f9d` |
| `tools/mutants.py` | 돌연변이 탐침(짓기 때) | `55dd2aeb4185c88f32615bb183f6245e7908e8238311b659d5e964205fd1d564` |
| `d34/expect.mjs` | D34 기대 요청 | `cb79a5240e6bc3b5b24abbff7173ca6f5d561d4de4fbf409f98949ac6d6e32e8` |
| `d34/make.py` | D34 하네스 잡기 · 견줌 | `b534456a205470199825fcb1a3280038ff40a4f97ba8a7d5edd5681e577ed8eb` |
| `probe/call.sh` | 프로브 세션 | `36eb755594c3efb68244de3660b4a0613e733b8776ce82fdd8851a0bcde86925` |
| `probe/precheck.sh` | 앞 'ok' 세션 | `a6117dcd31bd986902a1f152c18d6fce02b4d4217bac9b6f58abdae07215794f` |
| `probe/record.py` | 세션 기록 읽기 | `8fd5eab9f1705d2e75a213edf2d4f3b587e8ed94972f43e53ff097877e21304d` |
| `probe/mod/hooks/register.ts` | 프로브 mod(/g6probe) | `7c6241ebc461ee165eab5437ce79d74d275a90adef03195c0c70596d97c4aae8` |
| `probe/mod/hooks/notes.ts` | 프로브 notes.ts(= mtree) | `c049d63023b649374a1f492cb67ff5237dfb2c108e3f96ebcf4c8de079f13830` |
| `probe/mod/hooks/hooks.json` | 프로브 mod | `c835c92d8e1159d20a40ca78ad654da7433942c3694ffeda0b376b0c4dfd52cf` |
| `probe/mod/.claude-plugin/plugin.json` | 프로브 mod | `0d56a6e38528458209d48b35376bc012279ec76ec3a2a33b87d254b8b7f23f3d` |
| `tap/call.sh` | 탭 세션 | `50e659ccf0a44fec2fdfe493117cd0cfe98827ce0443dad36f0df9d1ffc868db` |
| `tap/tap.py` | 탭(1.11.0과 같음) | `e8d8174b09e11c74e6d744e4c44bc62033436d2ab35be6daa95d27026d17db9b` |
| `tap/mod/hooks/register.ts` | 탭 mod(/g6tap) | `8d6bd239c3790da059daf9daa4de12105a958a5c0473529ff0d03f39e8f6cba6` |
| `tap/mod/hooks/hooks.json` | 탭 mod | `c835c92d8e1159d20a40ca78ad654da7433942c3694ffeda0b376b0c4dfd52cf` |
| `tap/mod/.claude-plugin/plugin.json` | 탭 mod | `679b0e57cbd7a93025915f3f6fa727bdc3763f5085deaaef2da76e51d95598b1` |
| `tap/mod/tsconfig.json` | 탭 mod | `88437ec880f7008b5df208a95a7d47330f0e3a8204d78d6c5cc272e5941c3511` |
| `judge/tpl-rowcheck.md` | 행 확인 틀 | `dc946471c509fdbb787470e696d2087a56dcd98befcd6c48bafdbeb253692dfd` |
| `judge/stance-G6.md` | 행 확인자에게 주는 입장(이 절에서 자름) | `7ab1a619eef4f1f57315020cf8a6d950fb3ba64083ed4c57e162b52e0b3f1169` |
| `mtree/hooks/notes.ts` | 짓기 트리(a4ac818) | `c049d63023b649374a1f492cb67ff5237dfb2c108e3f96ebcf4c8de079f13830` |
| `mtree/hooks/register.tsx` | 짓기 트리(a4ac818) | `411036830322abb22dbe1a7f1a0f981e0d82c3d84aa239061f5d8bed60273ef0` |
| `jtree/hooks/notes.ts` | 읽기 트리(export 셋만 더함) | `13a999a1576ce9ded756f5087da2feb1ddaf27a6190ba4718cde1daea2ecb647` |
| `old/3f2b4fb/hooks/notes.ts` | 옛 창 3f2b4fb notes.ts(git show) | `ff5a9624e030f27e79cfb2532ef1c555e686ea1b3aae723823146efbb74cb5f4` |
| `old/7a7b08c/hooks/notes.ts` | 옛 창 7a7b08c notes.ts(git show) | `ff5a9624e030f27e79cfb2532ef1c555e686ea1b3aae723823146efbb74cb5f4` |
| `old/3690021/hooks/notes.ts` | 옛 창 3690021 notes.ts(git show) | `67412721bfc3b68f7b10278d07af9acdf114bd595614f6d9bb83e0ee16a4e0bd` |
| `old/fca5988/hooks/notes.ts` | 옛 창 fca5988 notes.ts(git show) | `ff4b2cfcbd2bce53d90dad21865f07fbc4b99205868bc27ead0b1990e54bc8f7` |
| `old/3d2f251/hooks/notes.ts` | 옛 창 3d2f251 notes.ts(git show) | `acabacdfbcc85b73518db9ac129585e958f92e726b1c6dad30649500b13b37ee` |
| `old/de98243/hooks/notes.ts` | 옛 창 de98243 notes.ts(git show) | `acabacdfbcc85b73518db9ac129585e958f92e726b1c6dad30649500b13b37ee` |
| `../d26/rulewide.mjs` | isRuleWide D26 재확인(짓기 때) | `c89d0800f3ca4bb0e3aaf5913b359d3273e6ad888ecab31751159d77fc7a5283` |
| `../cli/pinned.sh` | 고정한 길(묶음 0, chmod 555) | `e80f767481780e27fd6915d8f603bb5c07d18d08192efb0639d9629e811e3473` |
