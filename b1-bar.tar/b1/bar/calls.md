설계 calls 글(옮김)
- 플러그인과 똑같이(D20): 프로브 mod가 $.model.complete({ model: 'haiku' | 'sonnet'(설정 글자 그대로), effort: 'low', system, prompt: redactText(prompt).text, maxTokens, timeoutMs })로 4개씩 부르고, $.clock으로 시간을 재고, 답은 fixEscapedTicks를 거칩니다. 주 세션은 그 회의 별칭으로 켜고, claude --version · init model · modelUsage 키를 앞뒤로 적습니다(M-10). 내내 DISABLE_AUTOUPDATER=1.
- 노트 호출: SYSTEM, notePrompt(screened, 'beginner', [], team)(1.8.0 바이트), maxTokens NOTE_TOKENS 3500, timeoutMs 90000.
- 연습: 짓기 트리의 writeNote 길을 프로브가 돌림: keptNoteText(답, ruleNamesOf(rules)) → noteRuleOf → ruleFixPlan(screened, rules, said). 1단: 호출 없음. 2단: system RULE_DRILL_SYSTEM, prompt redactText(ruleDrillPrompt(screened, rules, said, cands)).text, maxTokens RULE_DRILL_TOKENS 3500, timeoutMs 90000, 그다음 ruleFixReply. 건너뜀: 호출 없음. (잰 회에서 프로브는 앵커 건너뜀 호출을 하지 않습니다. 그 갈래는 파일럿에만 있었음.)
- N2 채점: CHECK_SYSTEM, redactText(checkPrompt(item, mine, 'beginner', undefined, undefined, { rule })).text, maxTokens 480, timeoutMs 60000, 첫 시도, 두 번.
- 다시 보내지 않음: 빈 답, 상한 닿음, 시간 한도. API 오류는 적고 다시 보내지 않음(§2). 한 모델-스테이지의 10%를 넘으면 → M-4. 스테이지마다 빈 답은 모두 탭으로 한 번 다시 보내 stop_reason/stop_details만 적음(기록, B-12).
- D34(첫 호출 전): 짓기 트리의 플러그인 시험 하네스(level beginner, model 그 별칭, 하네스 models 줄이 그 모델의 isRuleDrill + isRuleWide를 켬, 그리고 하네스 없음)로 견본마다 노트 요청, 2단 요청 모두, (N2를 얼린 뒤) N2 채점 요청(model, effort, system, prompt, maxTokens, timeoutMs)을 잡아 도구의 줄과 바이트까지 견줍니다. 1단과 건너뜀 노트는 둘째 요청이 없어야 합니다. 하네스 없는 잡기는 노트 요청 하나뿐입니다.

계획 묶음 1의 글
- 모델마다 회마다: 노트 호출 85번(SYSTEM, notePrompt 1.8.0 바이트, 3500, 90000) + 2단 호출 약 25–30번(RULE_DRILL_SYSTEM, ruleDrillPrompt, 3500, 90000). 1단과 건너뜀은 호출 없음.
- N2: 꼬리표마다 번마다 채점 호출 30번 × 두 번(CHECK_SYSTEM, checkPrompt(…{ rule }), 480, 60000).
- 모두: haiku 노트 약 170 + 2단 약 55 + N2 60 ≈ 285; sonnet도 ≈ 285; 모두 ≈ 570, 빈 답의 탭 더함.
- 스테이지: 회 A 노트+연습 스테이지: haiku 다음 sonnet; 회 B 같음; 두 모델의 A와 B가 저장되고 해시되기 전에는 아무것도 열지 않음; 그다음 N1′ 판정; 그다음 꼬리표마다 N2 견본; N2 1번째와 2번째: haiku 다음 sonnet.
- 다시 보내기: 빈 답, 상한 닿음, 시간 한도는 다시 보내지 않음. API 오류는 적고 다시 보내지 않음(G6 §2); M-4 10% 규칙을 씀.
- D34: 견본마다 짓기 트리의 시험 하네스(beginner, 별칭 모델, 그 모델의 줄)로 노트 요청, 2단 요청 모두(1단/건너뜀 노트는 둘째 요청이 없음), N2를 얼린 뒤 N2 채점 요청을 잡아 도구 줄과 바이트로 견줌; 하네스 없는 잡기도(노트 요청 하나뿐).

이 묶음이 정한 것(위 글을 도구로 옮긴 자리, 기록)
- 모델-스테이지: `A`(회 A), `B`(회 B), `N2-1`, `N2-2`(N2 1번째 · 2번째), 모델마다 따로. 계획의 사용량 관문 자리 'G6 회 A haiku … N2 2번째 sonnet' 여덟과 하나씩 맞습니다. 회 A · B의 모델-스테이지 하나는 노트 호출 85번(프로브 세션 하나) 뒤에 그 모델 자신의 노트 답으로 2단 줄을 짓고(`tools/build.mjs drill`), 그 2단 요청을 D34로 하네스와 견준 뒤(`d34/make.py real`, 다르면 2단 호출 없이 멈춤), 2단 호출을 합니다(프로브 세션 하나). M-4의 10%는 그 모델-스테이지의 노트 + 2단 호출 모두로 셉니다.
- 떼어 낸 러너(러너 규칙): `tools/stage.sh <A|B|N2-1|N2-2> <haiku|sonnet>`를 setsid nohup으로 띄우고, 에이전트는 STARTED · 세션마다의 status.jsonl · DONE · 러너 로그만 봅니다. 러너는 (1) M-3 차례(haiku 다음 sonnet, B는 A가 두 모델 모두 끝난 뒤, N2-2는 N2-1이 두 모델 모두 끝난 뒤)와 STARTED가 없는지를 보고, (2) 고정한 길로 앞 'ok' 세션(`probe/precheck.sh`)을 돌려 `tools/gate.py pre`로 앞 기록(고정한 `claude --version` 2.1.323, 그때 다시 센 고정 바이너리 sha256, 별칭의 init model과 modelUsage 키가 1.12.0 보정 기록과 같음)과 사용량 관문(five_hour ≤ 0.60, seven_day < 0.80, 회 A haiku는 seven_day + 주간 예측 0.40 < 0.80, 그리고 에이전트가 ONLY_WORKFLOW=1로 '다른 워크플로가 돌지 않음'을 밝힘)을 봅니다. 기록이 다르면 부르지 않고 멈추고(종료 3), 관문을 못 넘으면 STARTED 없이 resetsAt을 찍고 기다립니다(종료 7). (3) STARTED(UTC, 요청 파일 sha256)를 쓰고 부르며, (4) 뒤 기록을 `tools/gate.py after`로 견주어 다르면 무효(종료 4), 던진 호출은 M-4 넷째 줄(종료 5), api-error가 10%를 넘으면 무효(종료 6)이고, 아니면 summary.json(상태 수와 답 파일 sha256)과 DONE을 씁니다. 어떤 호출도 다시 보내지 않습니다.
- 주간 예측(계획 usageGate, 회 A haiku 전): 0.40. 근거: 설계 파일럿 세트 4(호출 약 140번: haiku 노트 40 + 2단 10 + N2 18, sonnet 40 + 14 + 18, 파일럿 에이전트 포함)의 스트림 차이를 계획은 '0.45 → 0.52'로 적었습니다. 그 기록(`design/G6/pilot/set4/*/record.json`)을 다시 보면 이것은 five_hour이고, seven_day는 0.24 → 0.25였습니다. 더 엄한 쪽인 0.07을 세트 하나의 주간 쓰임으로 잡아, 잰 호출 ≈ 570번이면 0.07 × 570 / 140 ≈ 0.29, 여기에 opus 하위 에이전트(쓰는 쪽 4, N2 답 2, 행 확인 2, 번역 확인 1, 감사 1, 검토 2)와 이 묶음의 워크플로 에이전트 몫 0.11을 더해 0.40입니다. 회 A haiku는 seven_day + 0.40 < 0.80, 곧 seven_day < 0.40일 때만 시작합니다. 아니면 주간 초기화 바로 뒤에 시작합니다. (묶음 0의 보정 때 seven_day는 0.28이었습니다.)
- 모델 기록(M-10, D19): 앞 기록은 모델-스테이지마다의 앞 'ok' 세션과 고정한 길의 --record, 뒤 기록은 그 스테이지의 프로브 세션들(세션마다 앞뒤 claude --version, 턴마다 init model, result의 modelUsage 키)과 끝의 --record입니다. 모두 1.12.0 보정 기록(2.1.323, 고정 사본 sha256 `604d29a6…348e` · `d2bc14da…a9e`, haiku · sonnet의 풀린 id)과 같아야 합니다.
- 빈 답의 탭(기록만): 모델-스테이지마다 답 파일별로 `tools/tapsend.py <스테이지> <모델> <note|drill|n2>`.
