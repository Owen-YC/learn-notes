// learn-notes 1.12.0 G6 (batch 1) D34: the requests the tools expect, per test of d34/make.py (no model call).
//   pre            -> for each frozen sample × model: the note request (frozen/note-lines-<model>.jsonl) for the fixed
//                     O reply; for the fixed SAID reply (a "팀 규칙과 다를 수 있음" line naming the sample's first rule)
//                     the note request and, by build.mjs planOf/drillLine, the tier-2 request or none (tier 1, skip);
//                     with no harness (the shipped rows: isRuleDrill off) the note request alone
//   real <dir> <m> -> the note request and the tool's own drill-lines.jsonl line (or none) per answered note
// prints JSON { tests: [{ name, id, model, harness, texts, want: [request...] }] }
import { readFileSync, existsSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
const S = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1'
const B = await import(pathToFileURL(`${S}/tools/build.mjs`).href)
const FROZEN = process.env.FROZEN ?? `${S}/frozen`
const O_REPLY = '### 한 줄 요약\n값을 바꿨습니다.\n\n### 배울 개념\n- **변수**: 값을 담습니다.'
const SAID = {
  request: '서버 요청을 `fetch`(파이썬은 `requests`)로 바로 보냅니다',
  log: '기록을 `console.log`(파이썬은 `print`)로 남깁니다',
  date: '날짜 글자를 `toISOString`으로 직접 만듭니다',
  config: '설정 값을 `process.env`(파이썬은 `os.environ`)에서 바로 읽습니다',
}
export const saidReply = rule => `${O_REPLY}\n\n팀 규칙과 다를 수 있음: ${SAID[rule]}`
const lines = p => readFileSync(p, 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l))
const req = l => ({ model: l.model, effort: 'low', system: l.system, prompt: l.prompt, maxTokens: l.maxTokens, timeoutMs: l.timeoutMs })
const [mode, dir, model] = process.argv.slice(2)
const tests = []
if (mode === 'pre') {
  for (const m of ['haiku', 'sonnet']) {
    const notes = Object.fromEntries(lines(`${FROZEN}/note-lines-${m}.jsonl`).map(l => [l.id, l]))
    for (const { sample, entry } of B.samples()) {
      const n = notes[sample.id]
      if (JSON.stringify(n) !== JSON.stringify(B.noteLine(sample, entry, m))) throw new Error(`note line not rebuilt the same: ${sample.id}`)
      tests.push({ name: `O ${sample.id} ${m}`, id: sample.id, model: m, harness: true, texts: [O_REPLY], want: [req(n)] })
      const rule = (sample.violations ?? [])[0]?.rule ?? 'request'
      const reply = saidReply(rule)
      const p = B.planOf(sample, entry, reply)
      if (!p.isL) throw new Error(`the SAID reply is not read as L: ${sample.id}`)
      const want = [req(n)]
      if (p.tier === 2) want.push(req(B.drillLine(sample.id, m, p)))
      tests.push({ name: `S ${sample.id} ${m} tier${p.tier}`, id: sample.id, model: m, harness: true, texts: [reply, '- 규칙: 1\n- 줄: 1\n- 예시 답: `x`'], want })
      tests.push({ name: `S-noharness ${sample.id} ${m}`, id: sample.id, model: m, harness: false, texts: [reply, '- 규칙: 1\n- 줄: 1\n- 예시 답: `x`'], want: [req(n)] })
    }
  }
} else if (mode === 'real') {
  const notes = Object.fromEntries(lines(`${FROZEN}/note-lines-${model}.jsonl`).map(l => [l.id, l]))
  const outs = Object.fromEntries(JSON.parse(readFileSync(`${dir}/note/out.json`, 'utf8')).results.map(r => [r.id, r]))
  const drills = existsSync(`${dir}/drill-lines.jsonl`) ? Object.fromEntries(lines(`${dir}/drill-lines.jsonl`).map(l => [l.id, l])) : {}
  for (const { sample } of B.samples()) {
    const o = outs[sample.id]
    if (!o?.isAnswered) continue
    const want = [req(notes[sample.id])]
    if (drills[sample.id]) want.push(req(drills[sample.id]))
    tests.push({ name: `real ${sample.id} ${model}`, id: sample.id, model, harness: true, texts: [o.text, '- 규칙: 1\n- 줄: 1\n- 예시 답: `x`'], want })
  }
} else throw new Error('usage: expect.mjs pre | real <dir> <model>')
console.log(JSON.stringify({ tests }))
