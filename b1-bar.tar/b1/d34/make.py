"""learn-notes 1.12.0 G6 (batch 1) D34: the committed tree's own requests, caught from its plugin test harness, set
against the tools' requests to the byte (model, effort, system, prompt, maxTokens, timeoutMs). Rebuilt from
design/G6/tools/d34.py on the build commit's tree (impl112/b1/mtree): its tests replaced by tests/flowkit.ts (patched
to catch each request whole and to give each frozen change's Edit/Write result) and one d34.test.ts. Each test: model
the alias, level beginner, the team file, the change's request, its files by Edit/Write, the turn ending with its
answer; the harness answers the calls with the test's texts in order. With `harness` the models row of that model
turns isRuleDrill on (isRuleWide is the shipped row's); without, the shipped rows (isRuleDrill off).
  pre                  every frozen sample × model: O reply (one request), SAID reply (note + tier-2 or none), SAID with
                       no harness (one request)                          -> d34/pre/
  real <dir> <model>   that model's real note answers of a stage: note + the tool's tier-2 line or none -> <dir>/d34/
  n2 <model>           after the N2 freeze: each N2 answer typed into the practice of its note (round A's note and
                       tier-2 answers of that model): the grading request = frozen/n2-lines-<model>.jsonl -> d34/n2-<model>/
Exit 0 only when every test ran and every request is the same and no test made a request more.
Runs `claude plugin test .` in the copy (through cli/pinned.sh when run by stage.sh; no model call: the harness answers)."""
import json, os, shutil, subprocess, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1"
FROZEN = os.environ.get("FROZEN", f"{S}/frozen")
OUT = os.environ.get("D34", f"{S}/d34")
PATCHES = [
    ("    w.systems.push(e.system)\n", "    w.systems.push(e.system)\n    CAUGHT.push({ model: e.model, effort: e.effort, system: e.system, prompt: e.prompt, maxTokens: e.maxTokens, timeoutMs: e.timeoutMs })\n"),
    ("  on('tool.call', { tool: 'Edit' }, (_$, e) => {\n", "  on('tool.call', { tool: 'Edit' }, (_$, e) => {\n    if (FROZEN.has(e.file_path)) return FROZEN.get(e.file_path) as never\n"),
    ("  on('tool.call', { tool: 'Write' }, (_$, e) =>\n    e.file_path.endsWith('a.ts')", "  on('tool.call', { tool: 'Write' }, (_$, e) =>\n    FROZEN.has(e.file_path)\n      ? (FROZEN.get(e.file_path) as never)\n      : e.file_path.endsWith('a.ts')"),
]
KEYS = ["model", "effort", "system", "prompt", "maxTokens", "timeoutMs"]


def tree_at(run):
    tree = f"{run}/tree"
    shutil.rmtree(tree, ignore_errors=True)
    shutil.copytree(f"{S}/mtree", tree)
    for f in os.listdir(f"{tree}/tests"):
        if f.endswith(".test.ts"):
            os.remove(f"{tree}/tests/{f}")
    kit = open(f"{tree}/tests/flowkit.ts", encoding="utf-8").read()
    for old, new in PATCHES:
        assert kit.count(old) == 1, old
        kit = kit.replace(old, new)
    kit += "\nexport const CAUGHT: Record<string, unknown>[] = []\nexport const FROZEN = new Map<string, unknown>()\n"
    open(f"{tree}/tests/flowkit.ts", "w", encoding="utf-8").write(kit)
    return tree


def calls_of(entry):
    results, calls = {}, []
    for f in entry["files"]:
        if f["tool"] == "Edit":
            results[f["path"]] = {"result": {"filePath": f["path"], "oldString": "(frozen)", "newString": "(frozen)", "originalFile": f["before"], "structuredPatch": f["hunks"], "userModified": False, "replaceAll": False}}
            calls.append({"tool": "Edit", "tool_use_id": f"u{len(calls) + 1}", "file_path": f["path"], "old_string": "(frozen)", "new_string": "(frozen)"})
        else:
            results[f["path"]] = {"result": {"type": "create", "filePath": f["path"], "content": f["content"], "structuredPatch": [], "originalFile": None}}
            calls.append({"tool": "Write", "tool_use_id": f"u{len(calls) + 1}", "file_path": f["path"], "content": f["content"]})
    return results, calls


def test_src(i, t, s, entry, team):
    results, calls = calls_of(entry)
    data = json.dumps({"i": i, "id": s["id"], "model": t["model"], "harness": t["harness"], "request": s["request"], "answer": s["answer"], "results": results, "calls": calls, "texts": t["texts"], "team": team, "typed": t.get("typed")}, ensure_ascii=False)
    return f"""test({json.dumps(f"D34 {i} {t['name']}")}, {{ options: {{ model: {json.dumps(t['model'])}, level: 'beginner' }}, timeoutMs: 20000 }}, async ($, on) => {{
  const d = {data} as {{ i: number; id: string; model: string; harness: boolean; request: string; answer: string; results: Record<string, unknown>; calls: unknown[]; texts: string[]; team: string; typed: string | null }}
  CAUGHT.length = 0
  FROZEN.clear()
  for (const [path, result] of Object.entries(d.results)) FROZEN.set(path, result)
  const store = new Map<string, unknown>()
  const w = world(on, 'ok', null, true, store)
  w.files.set('/proj/.claude/learn-notes.md', d.team)
  if (d.harness) w.harness = {{ models: {{ [d.model]: {{ isRuleDrill: true }} }} }}
  w.texts = [...d.texts]
  await start($)
  await $.turn.start({{ text: d.request, turnId: d.id }})
  for (const call of d.calls) await $.tool.call(call as never)
  await $.turn.complete({{ answer: d.answer, durationMs: 5, isAborted: false, turnId: d.id, reason: 'answer' }})
  await finish(w)
  if (d.typed !== null) {{
    const notes = (store.get('history') as Record<string, {{ notes: {{ id: string }}[] }}>)['/proj']!.notes
    const ui = await pane($)
    await ui.press({{ key: 'note-drill' }})
    await ui.input({{ key: `drill-${{notes.at(-1)!.id}}`, text: d.typed }})
    await w.clock.settle()
  }}
  console.log('D34CAP ' + JSON.stringify({{ i: d.i, caught: CAUGHT }}))
}})
"""


def run(run_dir, tests):
    os.makedirs(run_dir, exist_ok=True)
    if os.path.exists(f"{run_dir}/capture.log"):
        sys.exit(f"refuse: {run_dir}/capture.log exists")
    tree = tree_at(run_dir)
    samples = {s["id"]: s for s in json.load(open(f"{FROZEN}/samples.json", encoding="utf-8"))}
    hunks = {h["id"]: h for h in json.load(open(f"{FROZEN}/hunks.json", encoding="utf-8"))}
    team = open(f"{S}/team.md", encoding="utf-8").read()
    body = ["import { test } from 'claude-code/testing'", "import { CAUGHT, FROZEN, finish, pane, start, world } from './flowkit'", ""]
    for i, t in enumerate(tests):
        body.append(test_src(i, t, samples[t["id"]], hunks[t["id"]], team))
    open(f"{tree}/tests/d34.test.ts", "w", encoding="utf-8").write("\n".join(body))
    p = subprocess.run(["claude", "plugin", "test", "."], cwd=tree, capture_output=True, text=True, env={**os.environ, "DISABLE_AUTOUPDATER": "1"}, timeout=3000)
    log = p.stdout + p.stderr
    open(f"{run_dir}/capture.log", "w").write(log)
    caught = {}
    for l in log.split("\n"):
        if "D34CAP " in l:
            c = json.loads(l.split("D34CAP ", 1)[1])
            caught[c["i"]] = c["caught"]
    same = bad = 0
    report = []
    for i, t in enumerate(tests):
        got = caught.get(i)
        if got is None:
            bad += 1
            report.append({"i": i, "name": t["name"], "bad": "no capture (test failed?)"})
            continue
        want = t["want"]
        if t.get("lastOnly"):
            got = got[-1:]
        for k, w in enumerate(want):
            g = got[k] if k < len(got) else None
            diff = [x for x in KEYS if g is None or g.get(x) != w.get(x)]
            if diff:
                bad += 1
                report.append({"i": i, "name": t["name"], "request": k, "differs": diff})
            else:
                same += 1
        if len(got) > len(want):
            bad += 1
            report.append({"i": i, "name": t["name"], "extra": len(got) - len(want)})
    out = {"tests": len(tests), "testExit": p.returncode, "requestsSame": same, "bad": bad, "report": report[:50]}
    json.dump(out, open(f"{run_dir}/result.json", "w"), ensure_ascii=False, indent=1)
    shutil.rmtree(tree, ignore_errors=True)
    print(json.dumps({k: out[k] for k in ("tests", "testExit", "requestsSame", "bad")}))
    return bad == 0 and p.returncode == 0


def expect(*args):
    p = subprocess.run(["node", "--experimental-transform-types", "--no-warnings", f"{S}/d34/expect.mjs", *args], capture_output=True, text=True, env={**os.environ, "FROZEN": FROZEN})
    if p.returncode != 0:
        sys.exit("expect.mjs failed: " + p.stderr[-2000:])
    return json.loads(p.stdout)["tests"]


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "pre":
        ok = run(f"{OUT}/pre", expect("pre"))
    elif mode == "real":
        d, m = sys.argv[2], sys.argv[3]
        ok = run(f"{d}/d34", expect("real", d, m))
    elif mode == "n2":
        m = sys.argv[2]
        meta = json.load(open(f"{FROZEN}/n2-meta-{m}.json", encoding="utf-8"))
        lines = {json.loads(l)["id"]: json.loads(l) for l in open(f"{FROZEN}/n2-lines-{m}.jsonl", encoding="utf-8") if l.strip()}
        tests = []
        for lid, one in meta["answers"].items():
            w = lines[lid]
            texts = [one["noteReply"]] + ([one["drillReply"]] if one.get("drillReply") is not None else []) + ["판정: 맞음\n피드백: 좋습니다.\n규칙: 지킴"]
            tests.append({"name": f"n2 {lid} {m}", "id": one["sid"], "model": m, "harness": True, "texts": texts, "typed": one["mine"], "lastOnly": True,
                          "want": [{k: w[k] for k in ("model", "system", "prompt", "maxTokens", "timeoutMs")} | {"effort": "low"}]})
        ok = run(f"{OUT}/n2-{m}", tests)
    else:
        sys.exit("usage: make.py pre | real <dir> <model> | n2 <model>")
    sys.exit(0 if ok else 1)
