"""learn-notes 1.12.0 G6 (batch 1): the four writers' answers as one array (frozen/raw.json, chmod 444) and who wrote
what (frozen/raw.meta.json: part, count, UTC start/end, the writer's modelUsage keys, the answer's sha256). An answer
is read as the first ```json block, else the whole text; nothing in it is changed. Refuses to overwrite.
usage: extract.py"""
import hashlib, json, os, re, sys
S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1"
dst, meta_dst = f"{S}/frozen/raw.json", f"{S}/frozen/raw.meta.json"
if os.path.exists(dst):
    sys.exit(f"refuse: {dst} exists")
rows, meta = [], []
for part in "ABCD":
    o = f"{S}/gen/out/{part}"
    t = open(f"{o}/result.txt", encoding="utf-8").read()
    m = re.search(r"```json\s*\n(.*?)\n```", t, re.S)
    arr = json.loads(m.group(1) if m else t)
    want = {"A": "GA", "B": "GB", "C": "GC", "D": "GD"}[part]
    bad = [s.get("id") for s in arr if not str(s.get("id", "")).startswith(want)]
    if bad:
        sys.exit(f"refuse: part {part} wrote ids outside {want}: {bad}")
    rows += arr
    meta.append({"part": part, "n": len(arr), "started": open(f"{o}/started.txt").read().strip(), "ended": open(f"{o}/ended.txt").read().strip(),
                 "writer": json.loads(open(f"{o}/model.txt").read()), "promptSha256": open(f"{o}/prompt.sha256").read().split()[0],
                 "resultSha256": hashlib.sha256(t.encode("utf-8")).hexdigest()})
ids = [s["id"] for s in rows]
if len(ids) != len(set(ids)):
    sys.exit("refuse: an id twice")
os.makedirs(f"{S}/frozen", exist_ok=True)
txt = json.dumps(rows, ensure_ascii=False, indent=1) + "\n"
open(dst, "w", encoding="utf-8").write(txt)
os.chmod(dst, 0o444)
json.dump({"rawSha256": hashlib.sha256(txt.encode("utf-8")).hexdigest(), "parts": meta, "author": "claude -p --model opus --tools '' (fresh, blind; pinned CLI)"}, open(meta_dst, "w"), ensure_ascii=False, indent=1)
os.chmod(meta_dst, 0o444)
print(len(rows), hashlib.sha256(txt.encode("utf-8")).hexdigest())
