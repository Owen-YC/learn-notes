// learn-notes 1.12.0 G6 (batch 1): the measured calls as the committed tree's writeNote makes them, and their reading
// (stance §1 changed; design calls; rebuilt from design/G6/final/tools/build-final.mjs with the pilot-only anchor-free
// variant taken out). Tree: impl112/b1/mtree (git archive of the build commit a4ac818), its hooks/notes.ts as it is.
//   note                    -> frozen/note-lines-{haiku,sonnet}.jsonl   (SYSTEM · notePrompt(screened,'beginner',[],team) ·
//                              NOTE_TOKENS 3500 · 90000; screened = screenNote(note, team excludes, none denied))
//   drill <dir> <model>     -> <dir>/drill-lines.jsonl + <dir>/plan.json from <dir>/note/out.json: per answered note
//                              keptNoteText(fixEscapedTicks'd reply, ruleNamesOf(rules)) → noteRuleOf → ruleFixPlan(screened,
//                              rules, said); tier 2 only: RULE_DRILL_SYSTEM · redactText(ruleDrillPrompt(screened, rules,
//                              said, cands)).text · RULE_DRILL_TOKENS 3500 · 90000. Tier 1 and skips make no call.
//   read <dir> <out.json>   -> per sample the OFF final text (the keptNoteText text) and the ON final text: tier 1
//                              ruleFixMade(text, fix, changes) ?? text; tier 2 ruleFixReply(text, reply, plan, rules, said,
//                              changes).text ?? text (no answer: text); skip: text. Plus what the judge needs (no model name).
// The probe already passed each reply through fixEscapedTicks (the plugin's askModel does too).
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname } from 'node:path'
import { pathToFileURL } from 'node:url'

export const S = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1'
export const N = await import(pathToFileURL(`${process.env.TREE ?? S + '/mtree'}/hooks/notes.ts`).href)
const K = await import(pathToFileURL(`${S}/tools/notekit.mjs`).href)
export const NUMS = { NOTE_TOKENS: 3500, MODEL_TIMEOUT_MS: 90000 }
export const team = N.parseTeamFile(readFileSync(`${S}/team.md`, 'utf8'))
export const rules = team.rules
export const names = N.ruleNamesOf(rules)
const FROZEN = process.env.FROZEN ?? `${S}/frozen`
const readJson = p => JSON.parse(readFileSync(p, 'utf8'))

export function writeOnce(path, text) {
  if (existsSync(path)) throw new Error(`refuse: ${path} exists`)
  mkdirSync(dirname(path), { recursive: true })
  writeFileSync(path, text)
}
export function samples() {
  const hunks = Object.fromEntries(readJson(`${FROZEN}/hunks.json`).map(one => [one.id, one]))
  return readJson(`${FROZEN}/samples.json`).map(sample => ({ sample, entry: hunks[sample.id] }))
}
export const noteOf = (entry, sample) => K.noteOf(N, entry, sample)
export const shownOf = note => N.screenNote(note, team.excludes ?? [], () => false)
const outOf = path => Object.fromEntries(readJson(path).results.map(r => [r.id, r]))

/** The plan writeNote makes for a note reply. */
export function planOf(sample, entry, reply) {
  const note = noteOf(entry, sample)
  const shown = shownOf(note)
  const text = N.keptNoteText(reply, names)
  const said = N.noteRuleOf(text)
  if (said === undefined) return { note, shown, text, said, isL: false }
  const plan = N.ruleFixPlan(shown, rules, said)
  const tier = 'fix' in plan ? 1 : 'cands' in plan ? 2 : 0
  return { note, shown, text, said, isL: true, plan, tier }
}

export function noteLine(sample, entry, model) {
  return { id: sample.id, model, system: N.SYSTEM, prompt: N.redactText(N.notePrompt(shownOf(noteOf(entry, sample)), 'beginner', [], team)).text, maxTokens: NUMS.NOTE_TOKENS, timeoutMs: NUMS.MODEL_TIMEOUT_MS }
}
export function drillLine(id, model, p) {
  return { id, model, system: N.RULE_DRILL_SYSTEM, prompt: N.redactText(N.ruleDrillPrompt(p.shown, rules, p.said, p.plan.cands)).text, maxTokens: N.RULE_DRILL_TOKENS, timeoutMs: NUMS.MODEL_TIMEOUT_MS }
}

if (process.argv[1]?.endsWith('build.mjs')) {
  const [mode, dir, arg] = process.argv.slice(2)
  if (mode === 'note') {
    for (const m of ['haiku', 'sonnet']) {
      const lines = samples().map(({ sample, entry }) => noteLine(sample, entry, m))
      writeOnce(`${FROZEN}/note-lines-${m}.jsonl`, lines.map(l => JSON.stringify(l)).join('\n') + '\n')
      console.log(m, lines.length)
    }
  } else if (mode === 'drill') {
    const model = arg
    if (model !== 'haiku' && model !== 'sonnet') throw new Error('model')
    const notes = outOf(`${dir}/note/out.json`)
    const lines = []
    const plans = {}
    for (const { sample, entry } of samples()) {
      const got = notes[sample.id]
      if (!got?.isAnswered) { plans[sample.id] = { answered: false }; continue }
      const p = planOf(sample, entry, got.text)
      plans[sample.id] = { answered: true, isL: p.isL, tier: p.isL ? p.tier : undefined, skip: p.plan && 'skip' in p.plan ? p.plan.skip : undefined, cands: p.plan && 'cands' in p.plan ? p.plan.cands.length : undefined }
      if (p.isL && p.tier === 2) lines.push(drillLine(sample.id, model, p))
    }
    writeOnce(`${dir}/drill-lines.jsonl`, lines.map(l => JSON.stringify(l)).join('\n') + (lines.length ? '\n' : ''))
    writeOnce(`${dir}/plan.json`, JSON.stringify(plans, null, 1) + '\n')
    const tally = Object.values(plans).reduce((a, p) => { const k = !p.answered ? 'unanswered' : !p.isL ? 'O' : `tier${p.tier}${p.skip ? '-' + p.skip : ''}`; a[k] = (a[k] ?? 0) + 1; return a }, {})
    console.log('drill calls', lines.length, JSON.stringify(tally))
  } else if (mode === 'read') {
    const out = arg
    const notes = outOf(`${dir}/note/out.json`)
    const drills = existsSync(`${dir}/drill/out.json`) ? outOf(`${dir}/drill/out.json`) : {}
    const sent = new Set(existsSync(`${dir}/drill-lines.jsonl`) ? readFileSync(`${dir}/drill-lines.jsonl`, 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l).id) : [])
    const rows = {}
    for (const { sample, entry } of samples()) {
      const got = notes[sample.id]
      if (!got?.isAnswered) { rows[sample.id] = { answered: false }; continue }
      const p = planOf(sample, entry, got.text)
      const changes = p.note.changes.map(c => ({ file: c.file, path: c.path, diff: c.diff }))
      const row = { answered: true, isL: p.isL, said: p.said ?? null, off: p.text, on: p.text, changes, reply: got.text }
      if (p.isL) {
        row.tier = p.tier
        if (p.tier === 1) {
          const made = N.ruleFixMade(p.text, p.plan.fix, p.note.changes)
          row.on = made ?? p.text
          row.why = made === undefined ? 'made' : 'tier1'
        } else if (p.tier === 2) {
          if (!sent.has(sample.id)) throw new Error(`tier 2 with no drill line: ${sample.id}`)
          const d = drills[sample.id]
          row.drill = d === undefined ? { missing: true } : { answered: !!d.isAnswered, reason: d.reason ?? null, status: d.status ?? null }
          if (d?.isAnswered) {
            const r = N.ruleFixReply(p.text, d.text, p.plan, rules, p.said, p.note.changes)
            row.on = 'text' in r ? r.text : p.text
            row.why = 'text' in r ? 'tier2' : r.why
            row.drillReply = d.text
          } else row.why = 'no-answer'
        } else row.why = p.plan.skip
      }
      rows[sample.id] = row
    }
    writeOnce(out, JSON.stringify(rows, null, 1) + '\n')
    const tally = {}
    for (const r of Object.values(rows)) { const k = !r.answered ? 'unanswered' : !r.isL ? 'O' : r.why; tally[k] = (tally[k] ?? 0) + 1 }
    console.log(JSON.stringify(tally))
  } else throw new Error('usage: build.mjs note | drill <dir> <model> | read <dir> <out.json>')
}
