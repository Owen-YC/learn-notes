"""learn-notes 1.12.0 G6 (batch 1) N2 picking (1.10.0 N2 (1), plan samples.secondStage): from one label's round-A
verdict file, the correct rule practices of the ON reading (den notes the judge counted correct), five of them in
sample id order: all 4 rules, py >= 1, ts >= 1. Of every five in id order (itertools.combinations of the correct ones
sorted by id), the first that meets the most of these six conditions; a condition no five can meet with the others
is dropped and written down. Fewer than 5 correct practices: N2 fails for
that label (written, nothing picked).
usage: pick.py <label>  -> judge/<label>/picks.json (chmod 444)"""
import itertools, json, os, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1"
J = os.environ.get("JUDGE", f"{S}/judge")
FROZEN = os.environ.get("FROZEN", f"{S}/frozen")
label = sys.argv[1]
out_p = f"{J}/{label}/picks.json"
if os.path.exists(out_p):
    sys.exit(f"refuse: {out_p} exists")
v = json.load(open(f"{J}/verdicts-{label}-A.json", encoding="utf-8"))["rows"]
rd = json.load(open(f"{J}/{label}/read2-A.json", encoding="utf-8"))
samples = {s["id"]: s for s in json.load(open(f"{FROZEN}/samples.json", encoding="utf-8"))}
ok = []
for sid in sorted(v):
    e = v[sid].get("rule_drillOn")
    if e and e.get("correct") and v[sid].get("den"):
        ok.append({"id": sid, "rule": e["rule"], "lang": samples[sid]["lang"], "tier": v[sid].get("tier")})
res = {"label": label, "correct": len(ok), "picks": [], "dropped": [], "fails": len(ok) < 5}
if not res["fails"]:
    conds = [("rule", "request"), ("rule", "log"), ("rule", "date"), ("rule", "config"), ("lang", "py"), ("lang", "ts")]
    met = lambda combo: sum(1 for k, want in conds if any(p[k] == want for p in combo))
    best, best_n = None, -1
    for combo in itertools.combinations(ok, 5):  # in id order: the first combination meeting the most conditions
        n = met(combo)
        if n > best_n:
            best, best_n = combo, n
            if n == len(conds):
                break
    picks = list(best)
    res["dropped"] = [f"{k}={want}" for k, want in conds if not any(p[k] == want for p in picks)]
    picks.sort(key=lambda p: p["id"])
    for p in picks:
        p["drill"] = rd[p["id"]]["drillOn"]
        p["said"] = rd[p["id"]]["said"]
    res["picks"] = picks
os.makedirs(os.path.dirname(out_p), exist_ok=True)
open(out_p, "w", encoding="utf-8").write(json.dumps(res, ensure_ascii=False, indent=1) + "\n")
os.chmod(out_p, 0o444)
print(label, json.dumps({"correct": res["correct"], "picks": [(p["id"], p["rule"], p["lang"]) for p in res["picks"]], "dropped": res["dropped"], "fails": res["fails"]}))
