// learn-notes 1.12.0 G6 (batch 1): the judge's reading inputs (stance §4 · §11 · §13 · §14, details 15 · 16 · 19) for
// each answered note of a read file (build.mjs read). Rebuilt from design/G6/final/tools/read2-final.mjs (variant out).
//   drillOn  = drillOf(on, changes, true)  (the committed tree; jtree = mtree's notes.ts with export added to
//              ANY_HEADING, DRILL_HEADING, taskLineOf and nothing else)
//   drillOff = drillOf(off, changes, false)
//   tasksOn / tasksOff: per practice section (a DRILL_HEADING line to the next heading, as ruleLabelled splits them)
//              the count of lines taskLineOf reads (§13, detail 16)
//   old windows (§14 changed, detail 19 changed): the six builds' notes.ts (3f2b4fb 7a7b08c 3690021 fca5988 3d2f251
//              de98243, git show): a marked text (a line starting `- 할 일 (팀 규칙):`) must give no practice
//              (drillOf(text, changes)) and its hideDrillAnswer(text) no `고칠 줄` / `예시 답` label line; an unmarked one
//              the same task · line · example · file · row as 3d2f251's drillOf(text, changes, <that reading's switch>)
//   idempotent: keptNoteText(keptNoteText(reply, names), names) === keptNoteText(reply, names)
//   W (§11, detail 15): offW0 = fca5988's ruleLabelled(closeConceptBold(cut(reply, 9000))) (also checked equal to the
//              tree's keptNoteText(reply, [])); wChanged = off !== offW0; wDrill = fca5988's drillOf(offW0, changes, false)
// usage: read2.mjs <read.json> <out.json>
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
const S = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1'
const J = await import(pathToFileURL(`${S}/jtree/hooks/notes.ts`).href)
const OLD = ['3f2b4fb', '7a7b08c', '3690021', 'fca5988', '3d2f251', 'de98243']
const O = Object.fromEntries(await Promise.all(OLD.map(async c => [c, await import(pathToFileURL(`${S}/old/${c}/hooks/notes.ts`).href)])))
const [inp, outp] = process.argv.slice(2)
if (existsSync(outp)) throw new Error(`refuse: ${outp} exists`)
const rows = JSON.parse(readFileSync(inp, 'utf8'))
const names = J.ruleNamesOf(J.parseTeamFile(readFileSync(`${S}/team.md`, 'utf8')).rules)
const pick = d => (d === undefined ? null : { task: d.task, check: d.check, line: d.line, example: d.example, file: d.file, n: d.n, rule: d.rule ?? null })
const LABEL = /^\s*(?:[-*+•]\s+)?(?:\*\*)?\s*(?:고칠\s*줄|예시\s*답)\s*(?:\*\*)?\s*[:：]/
export function taskCounts(text) {
  const lines = text.split('\n')
  const out = []
  for (let s = 0; s < lines.length; s += 1) {
    if (!J.DRILL_HEADING.test(lines[s].trim())) continue
    let e = s + 1
    while (e < lines.length && !J.ANY_HEADING.test(lines[e].trim()) && !J.DRILL_HEADING.test(lines[e].trim())) e += 1
    out.push(lines.slice(s + 1, e).filter(l => J.taskLineOf(l)).length)
    s = e - 1
  }
  return out
}
function oldOf(text, changes, isOn) {
  const marked = text.split('\n').some(l => l.startsWith('- 할 일 (팀 규칙):'))
  const ref = pick(O['3d2f251'].drillOf(text, changes, isOn))
  const bad = []
  for (const c of OLD) {
    const d = pick(O[c].drillOf(text, changes))
    const shows = O[c].hideDrillAnswer(text).split('\n').some(l => LABEL.test(l))
    if (marked && (d !== null || shows)) bad.push(`${c}: marked: practice=${d !== null} shows=${shows}`)
    const key = x => (x === null ? null : JSON.stringify([x.task, x.line, x.example, x.file, x.n]))
    if (!marked && key(d) !== key(ref)) bad.push(`${c}: unmarked differs from 3d2f251`)
  }
  return { marked, bad }
}
const out = {}
for (const [id, r] of Object.entries(rows)) {
  if (!r.answered) { out[id] = r; continue }
  const kept = J.keptNoteText(r.reply, names)
  const offW0 = O['fca5988'].ruleLabelled(O['fca5988'].closeConceptBold(O['fca5988'].cut(r.reply, 9000)))
  out[id] = {
    ...r,
    drillOn: pick(J.drillOf(r.on, r.changes, true)),
    drillOff: pick(J.drillOf(r.off, r.changes, false)),
    tasksOn: taskCounts(r.on),
    tasksOff: taskCounts(r.off),
    oldOn: oldOf(r.on, r.changes, true),
    oldOff: oldOf(r.off, r.changes, false),
    idempotent: J.keptNoteText(kept, names) === kept,
    offIsKept: r.off === kept,
    offW0,
    offW0SameAsTree: offW0 === J.keptNoteText(r.reply, []),
    wChanged: r.off !== offW0,
    wDrill: pick(O['fca5988'].drillOf(offW0, r.changes, false)),
  }
}
writeFileSync(outp, JSON.stringify(out, null, 1) + '\n')
console.log(Object.keys(out).length)
