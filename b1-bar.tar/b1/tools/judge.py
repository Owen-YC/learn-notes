"""learn-notes 1.12.0 G6 (batch 1) machine judge of one label's one round (N1' and W lines; stance §0-§15 with
details 1-24 re-committed, §1 · §2 · §14 changed, S-a check line, S-b, E1-E18; rebuilt from design/G6/final/tools/
judge-final.py with the anchor-free variant out, the check-line call form of detail 6 run as written, values also
matched against the call's value (detail 8), and no model name read: caps, tokens, time and the rule-drill no-answer
line are count.py's, by label).
usage: judge.py <label> <round A|B> <read2.json>  -> judge/verdicts-<label>-<round>.md (row evidence first) and .json
"""
import json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import runlib as R
from key import KEY, STUB, USE_RULE, holds_use, markers_in, brought, pointed, line_key

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1"
FROZEN = os.environ.get("FROZEN", f"{S}/frozen")
JUDGE = os.environ.get("JUDGE", f"{S}/judge")
SAME_WORDS = ["같은", "그대로", "똑같이", "변함없이", "달라지지 않"]
PLACEHOLDER = re.compile(r"…|\.\.\.|\[[A-Za-z가-힣0-9_ ]+\]|<[^<>]+>")
SPANS = re.compile(r"``\s?(.+?)\s?``|`([^`]+)`")


def spans(text):
    return [m.group(1) or m.group(2) for m in SPANS.finditer(text)]


def changed_files(s, drill):
    files = R.files_of(s)
    text = files.get(drill["file"])
    if text is None:
        return None
    lines = text.split("\n")
    i = (drill.get("n") or 0) - 1
    if i < 0 or i >= len(lines) or line_key(lines[i]) != line_key(drill["line"]):
        return None
    indent = lines[i][: len(lines[i]) - len(lines[i].lstrip())]
    lines[i] = indent + drill["example"]
    return {**files, drill["file"]: "\n".join(lines)}


def call_of(check):
    """detail 6: the first code span holding `name(`, from that name to its matching paren (a leading await off)."""
    for sp in spans(check):
        m = re.search(r"([A-Za-z_$][\w$.]*)\s*\(", sp)
        if not m:
            continue
        start, depth, j = m.start(1), 0, m.end(1)
        while j < len(sp):
            if sp[j] == "(":
                depth += 1
            elif sp[j] == ")":
                depth -= 1
                if depth == 0:
                    return sp, sp[start:j + 1], m.group(1)
            j += 1
        return sp, sp[start:], m.group(1)  # unclosed: run as written (a syntax error is an error)
    return None, None, None


def defined_top(text, lang, name):
    if "." in name:
        return False
    if lang == "py":
        return re.search(rf"^(def|class)\s+{re.escape(name)}\b|^{re.escape(name)}\s*=", text, re.M) is not None
    return re.search(rf"^(export\s+)?(default\s+)?(async\s+)?(function\*?|const|let|var|class)\s+{re.escape(name)}\b", text, re.M) is not None


def check_claim(s, drill, files, rule):
    """§7 with S-a: (true?, form). Effect claims are decided at the line (S-a); the call form runs per detail 6."""
    check = (drill.get("check") or "").strip()
    if check == "":
        return False, "no check line (§7)"
    span, call, name = call_of(check)
    entry = s["files"][0]["path"]
    expr = s["demo"]
    if call is not None and not PLACEHOLDER.search(call):
        if not defined_top(files[drill["file"]], R.lang_of(drill["file"]), name):
            return False, f"call {name} not defined at the top of the changed file (§7, detail 6)"
        entry, expr = drill["file"], call
    arrow = re.search(r"→|->|=>", check)
    claim = check[arrow.end():] if arrow else (check.replace(f"`{span}`", " ", 1) if span is not None and call is not None else check)
    outside = re.sub(r"``.+?``|`[^`]+`", " ", claim)
    outside = re.sub(r"[\"'“”‘’「」].*?[\"'“”‘’「」]", " ", outside)
    sp = spans(claim)
    only_name = lambda x: x.strip() in USE_RULE or any(x.strip() == m for k in KEY.values() for m in k["markers"])
    values = [x for x in sp if not only_name(x)]
    values += re.findall(r"[\"“‘「']([^\"”’」']+)[\"”’」']", outside_q := re.sub(r"``.+?``|`[^`]+`", " ", claim))
    values += re.findall(r"(?<![A-Za-z0-9_.\-])\d+(?:\.\d+)?(?![A-Za-z0-9_.\-])", outside)
    same = any(w in outside for w in SAME_WORDS)
    eff = set()
    for x in sp:
        if x.strip() in USE_RULE:
            eff.add(USE_RULE[x.strip()])
    for u, r in USE_RULE.items():
        if holds_use(outside, u):
            eff.add(r)
    if re.search(r"(기록|로그).*남", outside):
        eff.add("log")
    if "인증" in outside or "재시도" in outside:
        eff.add("request")
    if "설정에서 읽" in outside:
        eff.add("config")
    if "날짜 글자로" in outside:
        eff.add("date")
    if not values and not same and not eff:
        return False, "no claim (§7 (6))"
    run = R.run(s, files, entry, expr)
    if run["exit"] != 0 or not run["same"]:
        return False, f"check run exit={run['exit']} same={run['same']} (detail 11)"
    lines = [l for l in R.out_lines(run["stdout"]) if not l.startswith("[value]")]
    val = next((l[len("[value] "):] for l in R.out_lines(run["stdout"]) if l.startswith("[value]")), None)
    recs = [R.norm(l) for l in run["rec"].split("\n") if l.strip()]
    ok, why = True, []

    def value_ok(v):
        nv = R.norm(v)
        if nv in lines or nv in recs:
            return True
        if val is None:
            return False
        try:
            jv = json.loads(val)
        except Exception:
            jv = val
        for cand in (nv, nv.replace("True", "true").replace("False", "false").replace("None", "null")):
            try:
                if json.loads(cand) == jv:
                    return True
            except Exception:
                pass
        return isinstance(jv, str) and (R.norm(jv) == nv) or R.norm(val) == nv
    for v in values:
        if not value_ok(v):
            ok = False
            why.append(f"value {v!r} not found")
    if same:
        base = R.run(s, R.files_of(s), entry, expr)
        if base["exit"] != 0 or not base["same"] or R.out_lines(base["stdout"]) != R.out_lines(run["stdout"]):
            ok = False
            why.append("same-words: differs from the original line's run")
    if eff:
        demo_new = R.run(s, files, s["files"][0]["path"], s["demo"])
        demo_old = R.run(s, R.files_of(s), s["files"][0]["path"], s["demo"])
        for r in sorted(eff):
            c = lambda rec: sum(l.strip().startswith(STUB[r].strip()) for l in rec.split("\n"))
            if c(demo_new["rec"]) <= c(demo_old["rec"]):
                ok = False
                why.append(f"effect {r}: {c(demo_new['rec'])} stub records with the example, {c(demo_old['rec'])} as written (S-a)")
    return ok, f"values={values} same={same} effect={sorted(eff)} call={'demo' if expr == s['demo'] else call}" + (f" | {'; '.join(why)}" if why else "")


def judge_rule(s, row, drill):
    """§6 and §10 for a rule practice: {correct, harm, why, rule?, undecided?}."""
    line, example = drill["line"], drill["example"]
    br = brought(line, example)
    pt = pointed(row.get("said") or "")
    vs = s.get("violations") or []
    harm = []
    if not br:
        harm.append("h1")
    if br and not any(v["rule"] in br and v["file"] == drill["file"] and line_key(v["line"]) == line_key(line) for v in vs):
        harm.append("h2")
    if any(markers_in(r, example) for r in br):
        harm.append("h3")
    files = changed_files(s, drill)
    if files is None:
        return {"correct": False, "harm": harm + ["undecided:line-not-at-n"], "why": "line not at its row in after (§15: counted as harmful)", "undecided": True}
    if R.syntax_error(s, files, drill["file"]):
        harm.append("h4")
    out = R.run(s, files, s["files"][0]["path"], s["demo"])
    runs = out["exit"] == 0 and out["same"]
    best = None
    both = [x for x in br if x in pt]
    for r in both:
        v = next((v for v in vs if v["rule"] == r and v["file"] == drill["file"] and line_key(v["line"]) == line_key(line)), None)
        if v is None:
            best = best or f"(iii) the line is not a {r} violation line"
            continue
        keeps = any(holds_use(example, u) for u in KEY[r]["use"]) and not markers_in(r, example)
        if not keeps:
            best = f"(iv) {r}: a marker left or no use name"
            continue
        if not runs:
            best = f"(v) run error exit={out['exit']} same={out['same']} {out['stderr'][-200:]}"
            continue
        if R.out_lines(out["stdout"]) != v["expected_fixed"]:
            best = f"(iv) output differs: ran {R.out_lines(out['stdout'])} want {v['expected_fixed']}"
            continue
        ok, form = check_claim(s, drill, files, r)
        if not ok:
            best = f"(vi) check false: {form}"
            continue
        return {"correct": True, "harm": harm, "why": f"rule {r}; check {form}", "rule": r}
    if not both:
        best = best or f"(ii) brought {br} pointed {pt}"
    return {"correct": False, "harm": harm, "why": best}


def judge(rows, samples):
    c = dict(answered=0, unanswered=[], L=0, O=0, den=0, correct=0, harmful=[], twoTask=[], O_rule=[], c_bad=[], trap_rule=[],
             noShort_rule=[], unlabelled=[], old_bad=[], idem_bad=[], off_not_kept=[], w_changed=0, w_fp=[], undecided=[], miss={},
             tiers={}, drill_called=0, offW0_differs_tree=[])
    ev_rows = {}
    for sid in sorted(samples):
        s = samples[sid]
        row = rows.get(sid)
        if row is None or not row.get("answered"):
            c["unanswered"].append(sid)
            continue
        c["answered"] += 1
        isL = row["isL"]
        c["L" if isL else "O"] += 1
        has_short = any(len(v["line"].strip()) <= 40 for v in s.get("violations") or [])
        in_den = isL and has_short
        c["den"] += in_den
        ev = {"kind": s["kind"], "isL": isL, "den": in_den, "tier": row.get("tier"), "why": row.get("why")}
        if isL:
            k = f"tier{row.get('tier')}" + (f"-{row.get('why')}" if row.get("tier") in (0, None) else "")
            c["tiers"][k] = c["tiers"].get(k, 0) + 1
        if row.get("drill") is not None:
            c["drill_called"] += 1
            if not isL:
                c["c_bad"].append(f"{sid}:practice call on an O note")
        for name in ("drillOn", "drillOff"):
            d = row.get(name)
            if d and d.get("rule"):
                j = judge_rule(s, row, d)
                ev[f"rule_{name}"] = {"line": d["line"], "example": d["example"], "check": d["check"], "task": d["task"], **j}
                if j.get("undecided"):
                    c["undecided"].append(f"{sid}:{name}:{j['why']}")
                if j["harm"]:
                    c["harmful"].append(f"{sid}:{name}:{'+'.join(j['harm'])}")
                if name == "drillOn" and in_den and j["correct"]:
                    c["correct"] += 1
                if not isL:
                    c["O_rule"].append(f"{sid}:{name}")
                if s["kind"] == "trap":
                    c["trap_rule"].append(f"{sid}:{name}")
                if not has_short:
                    c["noShort_rule"].append(f"{sid}:{name}")
                if name == "drillOn" and in_den and not j["correct"]:
                    key = (j["why"] or "?").split(":")[0][:48]
                    c["miss"][key] = c["miss"].get(key, 0) + 1
            elif d and brought(d["line"], d["example"]):
                c["unlabelled"].append(f"{sid}:{name}")
        if in_den and not ((row.get("drillOn") or {}).get("rule")):
            key = f"no rule practice ({row.get('why')})"
            c["miss"][key] = c["miss"].get(key, 0) + 1
        if any(n >= 2 for n in row["tasksOn"] + row["tasksOff"]):
            c["twoTask"].append(sid)
        if not isL and row["on"] != row["off"]:
            c["c_bad"].append(f"{sid}:final text differs ON/OFF")
        for k in ("oldOn", "oldOff"):
            for b in row[k]["bad"]:
                c["old_bad"].append(f"{sid}:{k}:{b}")
        if not row["idempotent"]:
            c["idem_bad"].append(sid)
        if not row["offIsKept"]:
            c["off_not_kept"].append(sid)
        if not row["offW0SameAsTree"]:
            c["offW0_differs_tree"].append(sid)
        if row["wChanged"]:
            c["w_changed"] += 1
            wd = row.get("wDrill")
            okw = wd and any(v["file"] == wd["file"] and line_key(v["line"]) == line_key(wd["line"]) and any(holds_use(wd["example"], u) and not holds_use(wd["line"], u) for u in KEY[v["rule"]]["use"]) for v in s.get("violations") or [])
            if wd and not okw:
                c["w_fp"].append(sid)
        ev_rows[sid] = ev
    return {"rows": ev_rows, "c": c}


if __name__ == "__main__":
    label, rnd, path = sys.argv[1], sys.argv[2], sys.argv[3]
    if rnd not in ("A", "B") or not re.fullmatch(r"[PQ]", label):
        sys.exit("usage: judge.py <P|Q> <A|B> <read2.json>")
    base = f"{JUDGE}/verdicts-{label}-{rnd}"
    if os.path.exists(base + ".md"):
        sys.exit(f"refuse: {base}.md exists")
    rows = json.load(open(path, encoding="utf-8"))
    samples = {s["id"]: s for s in json.load(open(f"{FROZEN}/samples.json", encoding="utf-8"))}
    res = judge(rows, samples)
    os.makedirs(JUDGE, exist_ok=True)
    with open(base + ".md", "w", encoding="utf-8") as f:
        f.write(f"# verdicts {label} round {rnd}\n\n")
        for sid, ev in res["rows"].items():
            f.write(f"- {sid} {json.dumps(ev, ensure_ascii=False)}\n")
        f.write("\n## counts\n\n" + json.dumps(res["c"], ensure_ascii=False, indent=1) + "\n")
    json.dump(res, open(base + ".json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    os.chmod(base + ".md", 0o444)
    os.chmod(base + ".json", 0o444)
    c = res["c"]
    print(label, rnd, json.dumps({k: (len(v) if isinstance(v, list) else v) for k, v in c.items() if k != "miss"}, ensure_ascii=False))
