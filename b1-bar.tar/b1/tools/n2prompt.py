"""learn-notes 1.12.0 G6 (batch 1) the N2 answer writer's prompt for one label (1.10.0 N2 (2), plan secondStage): the
frame gen/n2-frame.md with the team file and the label's five picked practices as gradeDrill shows them (file and row,
the code-written task and check, the line, the example, the note's rule line) plus the sample's demo and its changed
file whole. Nothing else: no grading prompt, no RULE_CHECK, no stance, no model name.
usage: n2prompt.py <label>  -> gen/n2/<label>/prompt.md (refuses to overwrite)"""
import json, os, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1"
J = os.environ.get("JUDGE", f"{S}/judge")
FROZEN = os.environ.get("FROZEN", f"{S}/frozen")
label = sys.argv[1]
GEN = os.environ.get("GEN_N2", f"{S}/gen/n2")
out_p = f"{GEN}/{label}/prompt.md"
if os.path.exists(out_p):
    sys.exit(f"refuse: {out_p} exists")
picks = json.load(open(f"{J}/{label}/picks.json", encoding="utf-8"))
if picks["fails"]:
    sys.exit(f"{label}: fewer than 5 correct practices: N2 fails, no writer")
samples = {s["id"]: s for s in json.load(open(f"{FROZEN}/samples.json", encoding="utf-8"))}
parts = []
for p in picks["picks"]:
    s, d = samples[p["id"]], p["drill"]
    f = next(x for x in s["files"] if x["path"] == d["file"])
    parts.append(f"""### 연습 {p['id']}
- 파일: `{d['file']}` ({d['n']}행)
- 할 일: {d['task']}
- 확인: {d['check']}
- 고칠 줄: `{d['line']}`
- 예시 답: `{d['example']}`
- 노트가 짚은 팀 규칙: {p['said']}
- 돌려 보는 호출(첫 파일 끝에서): `{s['demo']}`
- 파일 전체(바뀐 뒤):
```
{f['after']}
```
""")
frame = open(f"{S}/gen/n2-frame.md", encoding="utf-8").read()
team = open(f"{S}/team.md", encoding="utf-8").read()
text = frame.replace("{TEAM}", "```markdown\n" + team + "```").replace("{PRACTICES}", "\n".join(parts))
os.makedirs(os.path.dirname(out_p), exist_ok=True)
open(out_p, "w", encoding="utf-8").write(text)
print(label, len(text))
