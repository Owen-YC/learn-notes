"""learn-notes 1.12.0 G6 (batch 1): a file's text with every comment and string/docstring literal blanked (each such
character a space, newlines kept), so a line's code alone can be searched (the F samples' own shape, design S-c and
samples.measured: a marker whose text is only inside a comment or a string literal is no violation line).
A template literal's ${...} and a Python f-string's {...} are code and stay. js/ts: // and /* */ comments, ' " `
strings. py: # comments, ' " ''' \"\"\" strings with any r/b/u/f prefix."""


def _js(src):
    out, i, n = [], 0, len(src)
    stack = []  # brace depth per open ${ inside templates
    mode = "code"
    while i < n:
        c = src[i]
        if mode == "code":
            if c == "/" and src[i:i + 2] == "//":
                j = src.find("\n", i)
                j = n if j == -1 else j
                out.append(" " * (j - i)); i = j; continue
            if c == "/" and src[i:i + 2] == "/*":
                j = src.find("*/", i + 2)
                j = n if j == -1 else j + 2
                out.append("".join("\n" if ch == "\n" else " " for ch in src[i:j])); i = j; continue
            if c in "'\"":
                j = i + 1
                while j < n and src[j] != c and src[j] != "\n":
                    j += 2 if src[j] == "\\" else 1
                j = min(j + 1, n)
                out.append(" " * (j - i)); i = j; continue
            if c == "`":
                mode = "tpl"; out.append(" "); i += 1; continue
            if c == "{" and stack:
                stack[-1] += 1
            if c == "}" and stack:
                if stack[-1] == 0:
                    stack.pop(); mode = "tpl"; out.append(" "); i += 1; continue
                stack[-1] -= 1
            out.append(c); i += 1; continue
        # template text
        if c == "\\":
            out.append("  " if i + 1 < n and src[i + 1] != "\n" else " "); i += 2; continue
        if c == "`":
            mode = "code"; out.append(" "); i += 1; continue
        if src[i:i + 2] == "${":
            stack.append(0); mode = "code"; out.append("  "); i += 2; continue
        out.append("\n" if c == "\n" else " "); i += 1
    return "".join(out)[:n]


def _py(src):
    out, i, n = [], 0, len(src)
    while i < n:
        c = src[i]
        if c == "#":
            j = src.find("\n", i)
            j = n if j == -1 else j
            out.append(" " * (j - i)); i = j; continue
        k = i
        while k < n and k - i < 2 and src[k] in "rRbBuUfF":
            k += 1
        if k < n and src[k] in "'\"" and (k == i or not (src[i - 1].isalnum() or src[i - 1] == "_") if i > 0 else True):
            prefix = src[i:k].lower()
            q = src[k]
            triple = src[k:k + 3] == q * 3
            close = q * 3 if triple else q
            j = k + (3 if triple else 1)
            body_start = j
            while j < n:
                if src[j] == "\\" and "r" not in prefix:
                    j += 2; continue
                if src.startswith(close, j):
                    break
                if not triple and src[j] == "\n":
                    break
                j += 1
            end = min(j + len(close), n)
            seg = src[i:end]
            blank = ["\n" if ch == "\n" else " " for ch in seg]
            if "f" in prefix:  # {expr} inside an f-string is code
                rel = body_start - i
                depth, s0 = 0, None
                for p in range(rel, len(seg) - (len(close) if end <= n else 0)):
                    ch = seg[p]
                    if ch == "{":
                        if depth == 0 and p + 1 < len(seg) and seg[p + 1] == "{":
                            continue
                        depth += 1
                        if depth == 1:
                            s0 = p + 1
                    elif ch == "}" and depth > 0:
                        depth -= 1
                        if depth == 0 and s0 is not None:
                            for q2 in range(s0, p):
                                blank[q2] = seg[q2]
            out.append("".join(blank)); i = end; continue
        out.append(c); i += 1
    return "".join(out)[:n]


def code_only(src, lang):
    return _py(src) if lang == "py" else _js(src)
