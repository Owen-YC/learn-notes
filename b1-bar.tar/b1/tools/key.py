"""§5 key (docs/qa/견본.md 1.10.0 G6, same team file) and the name finders of tool detail 1."""
import re

KEY = {
    "request": {"use": ["apiRequest", "api_request"], "markers": ["fetch(", "requests."], "words": ["요청", "API", "서버"]},
    "log": {"use": ["log.info"], "markers": ["console.log", "print("], "words": ["기록", "로그"]},
    "date": {"use": ["toDateText", "to_date_text"], "markers": ["toISOString", "toJSON", "toLocaleDateString", "toDateString", "getFullYear", "getMonth", "getDate", "getUTCFullYear", "getUTCMonth", "getUTCDate", "strftime", "isoformat"], "words": ["날짜"]},
    "config": {"use": ["config"], "markers": ["process.env", "os.environ", "os.getenv"], "words": ["설정", "환경 변수"]},
}
STUB = {"request": "[apiRequest] ", "log": "[log.info] ", "date": "[toDateText] ", "config": "[config] "}
USE_RULE = {u: r for r, k in KEY.items() for u in k["use"]}


def holds_use(code, name):
    """detail 1: holdsName (no letter/digit/_/$/. right before, no letter/digit/_/$ right after)."""
    return re.search(r"(?<![\w$.])" + re.escape(name) + r"(?![\w$])", code) is not None


def holds_marker(code, marker):
    """detail 1: whole name, a `.` right before allowed; a marker ending in ( or . needs that char right after the name."""
    if marker.endswith("(") or marker.endswith("."):
        return re.search(r"(?<![\w$])" + re.escape(marker), code) is not None
    return re.search(r"(?<![\w$])" + re.escape(marker) + r"(?![\w$])", code) is not None


def markers_in(rule, code):
    return [m for m in KEY[rule]["markers"] if holds_marker(code, m)]


def brought(line, example):
    """§5 brought-in rules: the example holds a use name of the rule the line lacks."""
    return [r for r, k in KEY.items() if any(holds_use(example, u) and not holds_use(line, u) for u in k["use"])]


def pointed(said):
    """§5 pointed rules: said holds a use name or marker; else a word (API case-insensitive); else none."""
    got = [r for r, k in KEY.items() if any(holds_use(said, u) for u in k["use"]) or any(holds_marker(said, m) for m in k["markers"])]
    if got:
        return got
    return [r for r, k in KEY.items() if any((w.lower() in said.lower()) if w == "API" else (w in said) for w in k["words"])]


def line_key(s):
    return "".join(s.split()).rstrip(";,")
