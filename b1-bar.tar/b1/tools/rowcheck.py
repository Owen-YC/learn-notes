"""learn-notes 1.12.0 G6 (batch 1) row check (1.10.0 detail 21; plan judges): per label one fresh sub-agent
(`claude -p --model opus --tools ''`, empty dir, pinned CLI) that gets only that label's verdict files (rounds A and
B, the row evidence) and the stance with its details (judge/stance-G6.md, the bar commit's text), never the other
label, a model name, tokens, time or caps. It lists rows the script did not count as the text says.
  prompt <label>  -> judge/rowcheck/<label>/prompt.md
  run <label>     -> judge/rowcheck/<label>/out.json, result.txt (the writer's modelUsage keys in model.txt)
  parse <label>   -> judge/rowcheck-<label>.json (chmod 444): the rows listed; decide.py counts each listed row the
                     way unfavourable to passing (M-9: a judge/checker split counts against), and M-15 applies to a
                     tool defect it shows (the text wins; both labels counted again; a fail never turns into ON)."""
import hashlib, json, os, re, subprocess, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1"
P = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh"
J = os.environ.get("JUDGE", f"{S}/judge")
mode, label = sys.argv[1], sys.argv[2]
if label not in ("P", "Q"):
    sys.exit("label P or Q")
d = f"{J}/rowcheck/{label}"
if mode == "prompt":
    os.makedirs(d, exist_ok=True)
    if os.path.exists(f"{d}/prompt.md"):
        sys.exit("refuse: prompt exists")
    stance = open(f"{S}/judge/stance-G6.md", encoding="utf-8").read()
    ver = "\n\n".join(open(f"{J}/verdicts-{label}-{r}.md", encoding="utf-8").read() for r in ("A", "B"))
    tpl = open(f"{S}/judge/tpl-rowcheck.md", encoding="utf-8").read()
    open(f"{d}/prompt.md", "w", encoding="utf-8").write(tpl.replace("{LABEL}", label).replace("{STANCE}", stance).replace("{VERDICTS}", ver))
    print(label, os.path.getsize(f"{d}/prompt.md"))
elif mode == "run":
    if os.path.exists(f"{d}/out.json"):
        sys.exit("refuse: out exists")
    work = f"{S}/work/rowcheck-{label}"
    os.makedirs(work, exist_ok=True)
    with open(f"{d}/prompt.md", "rb") as fin, open(f"{d}/out.json", "wb") as fout, open(f"{d}/err.txt", "wb") as ferr:
        p = subprocess.run([P, "bash", "-c", 'timeout 2400 claude -p --model opus --tools "" --output-format json'], stdin=fin, stdout=fout, stderr=ferr, cwd=work)
    o = json.load(open(f"{d}/out.json", encoding="utf-8"))
    open(f"{d}/result.txt", "w", encoding="utf-8").write(o.get("result") or "")
    open(f"{d}/model.txt", "w").write(json.dumps(sorted((o.get("modelUsage") or {}).keys())) + "\n")
    print(label, "exit", p.returncode, "is_error", o.get("is_error"))
elif mode == "parse":
    out_p = f"{J}/rowcheck-{label}.json"
    if os.path.exists(out_p):
        sys.exit("refuse: exists")
    t = open(f"{d}/result.txt", encoding="utf-8").read()
    m = re.search(r"```json\s*\n(.*?)\n```", t, re.S)
    rows = json.loads(m.group(1) if m else t)
    body = json.dumps({"label": label, "rows": rows, "promptSha256": hashlib.sha256(open(f"{d}/prompt.md", "rb").read()).hexdigest()}, ensure_ascii=False, indent=1) + "\n"
    open(out_p, "w", encoding="utf-8").write(body)
    os.chmod(out_p, 0o444)
    print(label, len(rows))
else:
    sys.exit("usage: rowcheck.py prompt|run|parse <label>")
