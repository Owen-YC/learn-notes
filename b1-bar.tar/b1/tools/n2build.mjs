// learn-notes 1.12.0 G6 (batch 1) N2 (grading bytes unchanged at 1.9.0, rule19; 1.10.0 N2 (3), details 22 · 23):
//   skips <label> <answers.json>  -> per answer whether gradeDrill sends it at all: not when isBlankAnswer, when
//                                    sameLine with the example or with the line, or isKoreanTyped (detail 22)
//   lines <label>                 -> frozen/n2-lines-<model of label>.jsonl (+ n2-meta-<model>.json for D34): gradeDrill's
//                                    first try, CHECK_SYSTEM · redactText(checkPrompt({ name: '팀 규칙', question:
//                                    drillQuestion(sent), answer: sent.example, kind: 'modify' }, `${sent.indent}${mine}`,
//                                    'beginner', undefined, undefined, { rule: sent.rule })).text · 480 · 60000, where
//                                    sent = drillOf(on, changes, true) of the label's round-A ON text
//   judge <label> <run 1|2>       -> judge/n2-<label>-<run>.json/.md: parseCheck(text, { rule: true }) (its 안 지킴 + 맞음
//                                    → 거의 inside); correct: keep 맞음 · break 거의|틀림 · broken 틀림|거의 · off 틀림; an
//                                    unanswered or unread grade is not correct and counts as a missing 규칙 line (B-8);
//                                    pass: correct >= 27 · break→맞음 <= 1 · broken→맞음 0 · missing 규칙 <= 1
import { existsSync, readFileSync, writeFileSync, chmodSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
const S = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1'
const N = await import(pathToFileURL(`${S}/mtree/hooks/notes.ts`).href)
const J = process.env.JUDGE ?? `${S}/judge`
const FROZEN = process.env.FROZEN ?? `${S}/frozen`
const STAGE = process.env.STAGE ?? `${S}/stage`
const rj = p => JSON.parse(readFileSync(p, 'utf8'))
const once = (p, t) => { if (existsSync(p)) throw new Error(`refuse: ${p} exists`); writeFileSync(p, t); chmodSync(p, 0o444) }
const [mode, label, arg] = process.argv.slice(2)
const modelOf = l => Object.entries(rj(`${J}/pair.json`).labels).find(([, x]) => x === l)[0]
const sentOf = (rows, sid) => N.drillOf(rows[sid].on, rows[sid].changes, true)
if (mode === 'skips') {
  const rows = rj(`${J}/${label}/read2-A.json`)
  const ans = rj(arg)
  const out = {}
  for (const [sid, list] of Object.entries(ans)) {
    const d = sentOf(rows, sid)
    out[sid] = list.map(a => N.isBlankAnswer(a.line) || N.sameLine(d, a.line, d.example) || N.sameLine(d, a.line, d.line) || N.isKoreanTyped(a.line, `${d.indent}${d.line}`))
  }
  console.log(JSON.stringify(out))
} else if (mode === 'lines') {
  const m = modelOf(label)
  const rows = rj(`${J}/${label}/read2-A.json`)
  const answers = rj(`${J}/${label}/n2-answers.json`).answers
  const notes = Object.fromEntries(rj(`${STAGE}/A/${m}/note/out.json`).results.map(r => [r.id, r]))
  const drills = existsSync(`${STAGE}/A/${m}/drill/out.json`) ? Object.fromEntries(rj(`${STAGE}/A/${m}/drill/out.json`).results.map(r => [r.id, r])) : {}
  const lines = []
  const meta = { label, answers: {} }
  answers.forEach((a, i) => {
    const sent = sentOf(rows, a.id)
    if (!sent || sent.rule === undefined) throw new Error(`no rule practice for ${a.id}`)
    const prompt = N.checkPrompt({ name: '팀 규칙', question: N.drillQuestion(sent), answer: sent.example, kind: 'modify' }, `${sent.indent}${a.line}`, 'beginner', undefined, undefined, { rule: sent.rule })
    const id = `${a.id}-${String(i).padStart(2, '0')}-${a.kind}`
    lines.push({ id, model: m, system: N.CHECK_SYSTEM, prompt: N.redactText(prompt).text, maxTokens: 480, timeoutMs: 60000 })
    meta.answers[id] = { sid: a.id, kind: a.kind, mine: a.line, noteReply: notes[a.id].text, drillReply: drills[a.id]?.isAnswered ? drills[a.id].text : null }
  })
  once(`${FROZEN}/n2-lines-${m}.jsonl`, lines.map(l => JSON.stringify(l)).join('\n') + '\n')
  once(`${FROZEN}/n2-meta-${m}.json`, JSON.stringify(meta, null, 1) + '\n')
  console.log(label, lines.length)
} else if (mode === 'judge') {
  const m = modelOf(label)
  const base = `${J}/n2-${label}-${arg}`
  const out = rj(`${STAGE}/N2-${arg}/${m}/n2/out.json`).results
  const t = { label, run: Number(arg), n: 0, correct: 0, breakRight: 0, brokenRight: 0, noRuleLine: 0, unread: 0, rows: [] }
  for (const r of out) {
    const kind = r.id.split('-').at(-1)
    const g = r.isAnswered ? N.parseCheck(r.text, { rule: true }) : undefined
    const v = g?.verdict
    const ok = { keep: v === 'right', break: v === 'partial' || v === 'wrong', broken: v === 'wrong' || v === 'partial', off: v === 'wrong' }[kind] === true
    t.n += 1
    t.correct += ok ? 1 : 0
    if (kind === 'break' && v === 'right') t.breakRight += 1
    if (kind === 'broken' && v === 'right') t.brokenRight += 1
    if (!g) t.unread += 1
    if (!g || g.rule === undefined) t.noRuleLine += 1
    t.rows.push({ id: r.id, kind, verdict: v ?? null, rule: g?.rule ?? null, ok })
  }
  t.pass = t.correct >= 27 && t.breakRight <= 1 && t.brokenRight === 0 && t.noRuleLine <= 1
  once(`${base}.json`, JSON.stringify(t, null, 1) + '\n')
  once(`${base}.md`, `# N2 ${label} run ${arg}\n\n` + t.rows.map(x => `- ${x.id} ${x.kind} → ${x.verdict} (규칙: ${x.rule}) ${x.ok ? 'O' : '✗'}`).join('\n') + `\n\n${JSON.stringify({ ...t, rows: undefined })}\n`)
  console.log(label, arg, JSON.stringify({ n: t.n, correct: t.correct, breakRight: t.breakRight, brokenRight: t.brokenRight, noRuleLine: t.noRuleLine, pass: t.pass }))
} else throw new Error('usage: n2build.mjs skips <label> <answers> | lines <label> | judge <label> <1|2>')
