"""G6 measured runlib (learn-notes 1.12.0 batch 1; copy of design/G6/tools/runlib.py, WORK moved; rebuilt for 1.12.0 from docs/qa/견본.md 1.10.0 G6 §8 and tool details 4, 5, 12, 13; record only).

Stubs (team modules) write `[apiRequest] url` · `[log.info] args` · `[config] NAME` · `[toDateText] value` to a record
file (not stdout). fetch (preloaded) / requests return the same response as apiRequest / api_request: the value of the
first `responses` key the URL holds (status 200), else 404 and {}. Runs: empty temp dir, `unshare -n timeout 5 env -i
PATH LANG=C.UTF-8 TZ=UTC <sample env>`; js `node`, ts `node --experimental-transform-types`, both with a preload
(fetch + .js→.ts resolver); py `python3 -s -P -B` of a top runner that puts the folder on sys.path and runs the file with
run_name `__learnrun__`, PYTHONHASHSEED 1..5. js/ts run twice, py five times; all must agree.
"""
import json, os, shutil, subprocess, tempfile

WORK = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1/work/run"
PATH = os.environ.get("PATH", "/usr/bin:/bin")

STUBS = {
    "package.json": '{ "type": "module" }\n',
    "__rec.mjs": """import { appendFileSync } from 'node:fs'
export function rec(line) { appendFileSync(process.env.LEARN_REC, String(line).replace(/\\n/g, ' ') + '\\n') }
export function respond(url) {
  const map = JSON.parse(process.env.LEARN_RESP || '{}')
  const key = Object.keys(map).find(k => String(url).includes(k))
  const body = key === undefined ? {} : map[key]
  return new Response(JSON.stringify(body), { status: key === undefined ? 404 : 200, headers: { 'content-type': 'application/json' } })
}
""",
    "__pre.mjs": """import { register } from 'node:module'
import { respond } from './__rec.mjs'
globalThis.fetch = async (url, options) => respond(url)
register('./__hooks.mjs', import.meta.url)
""",
    "__hooks.mjs": """export async function resolve(specifier, context, next) {
  try { return await next(specifier, context) } catch (error) {
    if (specifier.startsWith('.') && specifier.endsWith('.js')) {
      try { return await next(specifier.slice(0, -3) + '.ts', context) } catch {}
    }
    if (specifier.startsWith('.') && !/\\.[a-z]+$/.test(specifier)) {
      for (const ext of ['.js', '.ts']) { try { return await next(specifier + ext, context) } catch {} }
    }
    throw error
  }
}
""",
    "src/api/apiRequest.js": """import { rec, respond } from '../../__rec.mjs'
export async function apiRequest(url, options) { rec('[apiRequest] ' + url); return respond(url) }
export default apiRequest
""",
    "src/log.js": """import { rec } from './__recpath.js'
export const log = {
  info(...args) { rec('[log.info] ' + args.map(a => typeof a === 'string' ? a : JSON.stringify(a)).join(' ')); console.log(...args) },
}
export default log
""",
    "src/__recpath.js": "export { rec } from '../__rec.mjs'\n",
    "src/dateText.js": """import { rec } from './__recpath.js'
export function toDateText(value) {
  rec('[toDateText] ' + (value instanceof Date ? value.toISOString() : String(value)))
  const d = value instanceof Date ? value : new Date(value)
  return d.toISOString().slice(0, 10)
}
export default toDateText
""",
    "src/config.js": """import { rec } from './__recpath.js'
export const config = new Proxy({}, {
  get(target, key) {
    if (typeof key === 'symbol' || key === 'then' || key === 'toJSON') return undefined
    if (key === 'get') return (name, fallback) => { rec('[config] ' + name); return process.env[name] ?? fallback }
    rec('[config] ' + key)
    return process.env[key]
  },
})
export default config
""",
    "app/__init__.py": "",
    "app/api/__init__.py": "",
    "__rec.py": """import json, os
def rec(line):
    with open(os.environ['LEARN_REC'], 'a', encoding='utf-8') as f:
        f.write(str(line).replace('\\n', ' ') + '\\n')
class Response:
    def __init__(self, url):
        m = json.loads(os.environ.get('LEARN_RESP') or '{}')
        key = next((k for k in m if k in str(url)), None)
        self._body = {} if key is None else m[key]
        self.status_code = 404 if key is None else 200
        self.ok = key is not None
        self.text = json.dumps(self._body, ensure_ascii=False)
        self.url = str(url)
    def json(self):
        return json.loads(self.text)
    def raise_for_status(self):
        if not self.ok:
            raise Exception('HTTP %d' % self.status_code)
""",
    "requests.py": """from __rec import Response
def request(method, url, **kwargs):
    return Response(url)
def get(url, params=None, **kwargs):
    return Response(url)
def post(url, data=None, json=None, **kwargs):
    return Response(url)
def put(url, data=None, **kwargs):
    return Response(url)
def patch(url, data=None, **kwargs):
    return Response(url)
def delete(url, **kwargs):
    return Response(url)
class RequestException(Exception):
    pass
""",
    "app/api/api_request.py": """from __rec import rec, Response
def api_request(url, method="GET", **kwargs):
    rec('[apiRequest] ' + str(url))
    return Response(url)
""",
    "app/log.py": """from __rec import rec
class _Log:
    def info(self, *args, **kwargs):
        rec('[log.info] ' + ' '.join(str(a) for a in args))
        print(*args, **kwargs)
log = _Log()
""",
    "app/date_text.py": """import datetime as _dt
from __rec import rec
def to_date_text(value):
    rec('[toDateText] ' + str(value))
    if isinstance(value, str):
        value = _dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    if isinstance(value, (int, float)):
        value = _dt.datetime.fromtimestamp(value / 1000, _dt.timezone.utc)
    if isinstance(value, _dt.datetime):
        if value.tzinfo is not None:
            value = value.astimezone(_dt.timezone.utc)
        return value.strftime('%Y-%m-%d')
    return value.isoformat()
""",
    "app/config.py": """import os
from __rec import rec
class _Config:
    def __getattr__(self, name):
        if name.startswith('__'):
            raise AttributeError(name)
        rec('[config] ' + name)
        return os.environ.get(name)
    def __getitem__(self, name):
        rec('[config] ' + name)
        return os.environ.get(name)
    def get(self, name, default=None):
        rec('[config] ' + name)
        return os.environ.get(name, default)
config = _Config()
""",
}

RUNPY = """import runpy, sys
sys.path.insert(0, {root!r})
runpy.run_path({file!r}, run_name='__learnrun__')
"""


def lang_of(path):
    return "py" if path.endswith(".py") else "ts" if path.endswith(".ts") or path.endswith(".tsx") else "js"


def stage(files, root=None):
    """files: {path: text}. Returns the temp dir with stubs + files (a sample file replaces a stub of the same path)."""
    os.makedirs(WORK, exist_ok=True)
    root = root or tempfile.mkdtemp(prefix="run-", dir=WORK)
    for path, text in {**STUBS, **files}.items():
        full = os.path.join(root, path)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        open(full, "w", encoding="utf-8").write(text)
    return root


def value_line(lang, expr):
    if lang == "py":
        return f"\nprint('[value] ' + __import__('json').dumps(({expr}), ensure_ascii=False, default=str))\n"
    return f"\nconsole.log('[value] ' + (JSON.stringify(await ({expr})) ?? 'null'))\n"


def _env(sample, rec, extra=None):
    env = {"PATH": PATH, "LANG": "C.UTF-8", "TZ": "UTC", "LEARN_REC": rec, "LEARN_RESP": json.dumps(sample.get("responses") or {}, ensure_ascii=False)}
    for k, v in (sample.get("env") or {}).items():
        env[str(k)] = str(v)
    env.update(extra or {})
    return ["env", "-i"] + [f"{k}={v}" for k, v in env.items()]


def run_once(sample, files, entry, expr, seed=None):
    """Runs `expr` at the end of `entry` (a copy of files). Returns {exit, stdout, stderr, rec}."""
    root = stage(files)
    try:
        lang = lang_of(entry)
        full = os.path.join(root, entry)
        if expr is not None:
            open(full, "a", encoding="utf-8").write(value_line(lang, expr))
        rec = os.path.join(root, "__record.txt")
        open(rec, "w").close()
        if lang == "py":
            open(os.path.join(root, "__run.py"), "w").write(RUNPY.format(root=root, file=full))
            cmd = _env(sample, rec, {"PYTHONHASHSEED": str(seed or 1)}) + ["python3", "-s", "-P", "-B", os.path.join(root, "__run.py")]
        else:
            cmd = _env(sample, rec) + ["node", "--no-warnings"] + (["--experimental-transform-types"] if lang == "ts" else []) + ["--import", os.path.join(root, "__pre.mjs"), full]
        p = subprocess.run(["unshare", "-n", "timeout", "5"] + cmd, cwd=root, capture_output=True, text=True, timeout=30)
        return {"exit": p.returncode, "stdout": p.stdout, "stderr": p.stderr[-1500:], "rec": open(rec, encoding="utf-8").read()}
    finally:
        shutil.rmtree(root, ignore_errors=True)


def run(sample, files, entry, expr):
    """js/ts twice, py five times (seeds 1..5); returns the first result plus `same` (all agree on exit, stdout, rec)."""
    lang = lang_of(entry)
    seeds = [1, 2, 3, 4, 5] if lang == "py" else [None, None]
    outs = [run_once(sample, files, entry, expr, s) for s in seeds]
    key = lambda o: (o["exit"], o["stdout"], o["rec"])
    first = dict(outs[0])
    first["same"] = all(key(o) == key(outs[0]) for o in outs)
    return first


def syntax_error(sample, files, path):
    """B-13 / detail 13: js/ts load the changed file alone (no call): exit != 0 and SyntaxError in stderr; py: py_compile fails."""
    root = stage(files)
    try:
        full = os.path.join(root, path)
        if lang_of(path) == "py":
            p = subprocess.run(["python3", "-s", "-B", "-c", "import py_compile,sys; py_compile.compile(sys.argv[1], doraise=True)", full], capture_output=True, text=True, timeout=30)
            return p.returncode != 0
        cmd = ["node", "--no-warnings"] + (["--experimental-transform-types"] if lang_of(path) == "ts" else []) + ["--import", os.path.join(root, "__pre.mjs"), full]
        rec = os.path.join(root, "__record.txt")
        open(rec, "w").close()
        p = subprocess.run(["unshare", "-n", "timeout", "5"] + _env(sample, rec) + cmd, cwd=root, capture_output=True, text=True, timeout=30)
        return p.returncode != 0 and "SyntaxError" in p.stderr
    finally:
        shutil.rmtree(root, ignore_errors=True)


def files_of(sample, side="after"):
    return {f["path"]: f[side] for f in sample["files"] if f.get(side) is not None}


def norm(s):
    """§7 normalisation of one line: trim, one space, ' -> ", no trailing ;."""
    import re
    s = re.sub(r"\s+", " ", s.strip()).replace("'", '"')
    return s[:-1] if s.endswith(";") else s


def out_lines(stdout):
    return [norm(l) for l in stdout.split("\n") if l.strip() != ""]


def swap_line(text, line, new):
    """`text` with the first line whose key (spaces out, trailing ; , off) is `line`'s replaced by `new`, its indent kept."""
    key = lambda s: "".join(s.split()).rstrip(";,")
    lines = text.split("\n")
    for i, l in enumerate(lines):
        if key(l) == key(line) and key(l) != "":
            indent = l[: len(l) - len(l.lstrip())]
            lines[i] = indent + new.strip()
            return "\n".join(lines), i + 1
    return None, None
