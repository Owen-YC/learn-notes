# learn-notes 1.12.0 batch 1: mutation probes on the batch tree (plan build: >= 2; design/G6/final/mut candidates).
# Each mutant is one exact text change in a copy; the copy's rulefix + drill + flow110 + flow1819 tests are run and the
# failing test names recorded. usage: python3 mutants.py <repo> <out dir>
import json, os, shutil, subprocess, sys
repo, out = sys.argv[1], sys.argv[2]
PIN = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh'
MUT = [
  ('M1 drillOf ON gate dropped (a rule practice code did not make is read on)', 'hooks/notes.ts',
   "  if (isRule && !isMadeRuleDrill(task, parts.get('확인') ?? '', line, example)) return undefined\n", ''),
  ('M2 tier 1 takes any argument count (0, 2, ...)', 'hooks/notes.ts',
   "    if (count !== 1 || /^\\s*(?:\\.\\.\\.|\\*)/.test(after.slice(open[0].length))) return undefined",
   "    if (count === undefined || /^\\s*(?:\\.\\.\\.|\\*)/.test(after.slice(open[0].length))) return undefined"),
  ('M3 one-span check dropped in ruleFixFault', 'hooks/notes.ts',
   "  if (!isOneSpanFix(line, example, side, cand.known)) return { fault: 'not-one-span' }\n", ''),
  ('M4 avoid-left check dropped in ruleFixFault', 'hooks/notes.ts',
   "  if (side.avoid.some(name => holdsName(example, name))) return { fault: 'avoid-left' }\n", ''),
  ('M5 hideDrillAnswer ON gate dropped (a marked practice code did not make shown on)', 'hooks/notes.ts',
   " || ruleOf(lines, span.start) === undefined || !isMade())", " || ruleOf(lines, span.start) === undefined)"),
  ('M6 no alias recheck after the tier-2 call (writeNote)', 'hooks/register.tsx',
   "          if (!(await recheckRemap($))) text = off\n          else if (!('error' in drilled)) {",
   "          if (!('error' in drilled)) {"),
  ('M7 no alias recheck before the plan (writeNote)', 'hooks/register.tsx',
   "      if (!(await recheckRemap($))) text = off\n      else {", "      {"),
]
TESTS = ['rulefix.test.ts', 'drill.test.ts', 'flow110.test.ts', 'flow1819.test.ts']
res = []
for name, f, old, new in MUT:
    d = os.path.join(out, 'run')
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(os.path.join(d, 'tests'))
    for x in ['.claude-plugin', 'hooks', 'types']:
        shutil.copytree(os.path.join(repo, x), os.path.join(d, x))
    shutil.copy(os.path.join(repo, 'tsconfig.json'), d)
    shutil.copytree(os.path.join(repo, 'tests/fixtures'), os.path.join(d, 'tests/fixtures'))
    shutil.copy(os.path.join(repo, 'tests/flowkit.ts'), os.path.join(d, 'tests'))
    for t in TESTS: shutil.copy(os.path.join(repo, 'tests', t), os.path.join(d, 'tests'))
    p = os.path.join(d, f)
    s = open(p, encoding='utf-8').read()
    assert s.count(old) == 1, (name, s.count(old))
    open(p, 'w', encoding='utf-8').write(s.replace(old, new))
    r = subprocess.run([PIN, 'claude', 'plugin', 'test', '.'], cwd=d, capture_output=True, text=True, timeout=900)
    log = r.stdout + r.stderr
    cur, fails = None, []
    for line in log.split('\n'):
        if line.startswith('tests/') and line.endswith(':'): cur = line[:-1]
        if line.startswith('(fail)'): fails.append(f"{cur}: {line[7:].rsplit(' [', 1)[0]}")
    summary = [l for l in log.split('\n') if l.strip().endswith(' pass') or l.strip().endswith(' fail')]
    res.append({'mutant': name, 'killed': len(fails) > 0, 'fails': len(fails), 'summary': summary, 'caughtBy': fails[:6]})
    print(name, 'killed' if fails else 'SURVIVED', len(fails), flush=True)
json.dump(res, open(os.path.join(out, 'mutants.json'), 'w'), ensure_ascii=False, indent=1)
