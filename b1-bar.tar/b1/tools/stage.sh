#!/bin/bash
# learn-notes 1.12.0 G6 (batch 1): one model-stage, run DETACHED (plan runnerRules), e.g.
#   ONLY_WORKFLOW=1 setsid nohup bash tools/stage.sh A haiku > stage/A-haiku.log 2>&1 < /dev/null &
# stage A | B: round A or B, the note calls (frozen/note-lines-<model>.jsonl) then that model's tier-2 calls (built by
#   tools/build.mjs drill from its own note answers; D34 of those requests against the plugin test harness first);
# stage N2-1 | N2-2: the N2 grading calls of that model (frozen/n2-lines-<model>.jsonl).
# Order (M-3): haiku's stage done before sonnet's; B after A of both; N2-1 after the N2 lines are frozen; N2-2 after
# N2-1 of both. Refuses a stage whose STARTED exists (cut-stage rule: the main loop decides). Before: an 'ok' session
# (probe/precheck.sh) = the before record and the usage gate (tools/gate.py pre): record differs -> exit 3 (STOP, not
# called); gate fails -> exit 7 (WAIT, its resetsAt printed; no STARTED written, may run again later). Then STARTED
# (UTC, request file sha256), the probe sessions (each call's status line in <session>/status.jsonl), the after
# record (exit 4 VOID when it differs). A call that threw (the engine refused before sending) -> exit 5 (M-4 line 4).
# API errors above 10% of the model-stage's calls -> exit 6 (M-4: void, nothing opened). No call is ever sent again.
# Only status is printed; never an answer's text. Every claude process goes through cli/pinned.sh.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1
P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh
ST="$1"; M="$2"
case "$ST" in A|B|N2-1|N2-2) ;; *) echo "usage: stage.sh <A|B|N2-1|N2-2> <haiku|sonnet>"; exit 2;; esac
case "$M" in haiku|sonnet) ;; *) echo "usage: stage.sh <stage> <haiku|sonnet>"; exit 2;; esac
D="${S:?}/stage/$ST/$M"
done_of() { [ -e "${S:?}/stage/$1/$2/DONE" ]; }
[ -e "$D/STARTED" ] && { echo "refuse: $D/STARTED exists (cut-stage rule: report to the main loop)"; exit 1; }
[ "$M" = sonnet ] && ! done_of "$ST" haiku && { echo "refuse: haiku's $ST is not done (M-3)"; exit 1; }
[ "$ST" = B ] && ! { done_of A haiku && done_of A sonnet; } && { echo "refuse: round A is not done for both models"; exit 1; }
[ "$ST" = N2-2 ] && ! { done_of N2-1 haiku && done_of N2-1 sonnet; } && { echo "refuse: N2-1 is not done for both models"; exit 1; }
case "$ST" in A|B) LINES="${S:?}/frozen/note-lines-$M.jsonl";; *) LINES="${S:?}/frozen/n2-lines-$M.jsonl";; esac
[ -s "$LINES" ] || { echo "no frozen lines: $LINES"; exit 2; }
mkdir -p "$D"
N=$(ls -d "$D"/pre-*/ 2>/dev/null | wc -l); PRE="$D/pre-$((N + 1))"
"$P" --record > "$PRE.pin.txt" 2>&1
"$P" bash "${S:?}/probe/precheck.sh" "$PRE" "$M" || { echo "precheck failed to run"; exit 3; }
python3 -I "${S:?}/tools/gate.py" pre "$PRE" "$M" "$ST" "$PRE.pin.txt"; rc=$?
[ $rc -eq 3 ] && { echo "STOP: the before record differs from the 1.12.0 calibration: not called"; exit 3; }
[ $rc -eq 7 ] && { echo "WAIT: usage gate failed: not started"; exit 7; }
[ $rc -eq 9 ] && { echo "not started: no statement that no other workflow runs (ONLY_WORKFLOW=1)"; exit 2; }
[ $rc -ne 0 ] && { echo "gate error $rc"; exit 3; }
{ date -u +%FT%TZ; sha256sum "$LINES"; echo "gate $PRE/gate.json"; } > "$D/STARTED"
"$P" --record > "$D/pin-before.txt" 2>&1
threw() { grep -q '"reason": "threw"' "$1/status.jsonl" 2>/dev/null || grep -q '"reason":"threw"' "$1/status.jsonl" 2>/dev/null; }
case "$ST" in
  A|B)
    "$P" bash "${S:?}/probe/call.sh" "$D/note" "$M" "$LINES"
    [ -f "$D/note/out.json" ] || { echo "CUT: no note out.json"; "$P" --record > "$D/pin-after.txt" 2>&1; exit 9; }
    threw "$D/note" && { echo "THREW: the engine refused before sending (M-4 line 4)"; exit 5; }
    chmod 444 "$D/note/out.json"
    node --experimental-transform-types --no-warnings "${S:?}/tools/build.mjs" drill "$D" "$M" || { echo "drill build failed"; exit 9; }
    if [ -s "$D/drill-lines.jsonl" ]; then
      "$P" python3 -I "${S:?}/d34/make.py" real "$D" "$M" > "$D/d34-real.log" 2>&1 || { echo "STOP: D34 of the tier-2 requests differs: no tier-2 call made"; cat "$D/d34-real.log" | tail -5; exit 8; }
      tail -1 "$D/d34-real.log"
      "$P" bash "${S:?}/probe/call.sh" "$D/drill" "$M" "$D/drill-lines.jsonl"
      [ -f "$D/drill/out.json" ] || { echo "CUT: no drill out.json"; "$P" --record > "$D/pin-after.txt" 2>&1; exit 9; }
      threw "$D/drill" && { echo "THREW: the engine refused before sending (M-4 line 4)"; exit 5; }
      chmod 444 "$D/drill/out.json"
    fi
    ;;
  N2-1|N2-2)
    "$P" bash "${S:?}/probe/call.sh" "$D/n2" "$M" "$LINES"
    [ -f "$D/n2/out.json" ] || { echo "CUT: no n2 out.json"; "$P" --record > "$D/pin-after.txt" 2>&1; exit 9; }
    threw "$D/n2" && { echo "THREW: the engine refused before sending (M-4 line 4)"; exit 5; }
    chmod 444 "$D/n2/out.json"
    ;;
esac
"$P" --record > "$D/pin-after.txt" 2>&1
python3 -I "${S:?}/tools/gate.py" after "$D" "$M" "$D/pin-after.txt"; after=$?
python3 -I - "$D" <<'PY'
import hashlib, json, os, sys
d = sys.argv[1]
summ = {"calls": 0, "counts": {}, "sha256": {}}
for sub in ("note", "drill", "n2"):
    p = f"{d}/{sub}/out.json"
    if not os.path.exists(p):
        continue
    summ["sha256"][sub] = hashlib.sha256(open(p, "rb").read()).hexdigest()
    for r in json.load(open(p, encoding="utf-8"))["results"]:
        how = "threw" if "threw" in r else "answered" if r.get("isAnswered") else r.get("reason")
        if how == "api-error":
            how += f"/{r.get('status')}"
        summ["calls"] += 1
        summ["counts"][f"{sub}:{how}"] = summ["counts"].get(f"{sub}:{how}", 0) + 1
api = sum(v for k, v in summ["counts"].items() if ":api-error" in k)
summ["apiErrors"] = api
summ["void10"] = api * 10 > summ["calls"]
for sub in ("drill-lines.jsonl", "plan.json"):
    if os.path.exists(f"{d}/{sub}"):
        summ["sha256"][sub] = hashlib.sha256(open(f"{d}/{sub}", "rb").read()).hexdigest()
open(f"{d}/summary.json", "w").write(json.dumps(summ, indent=1) + "\n")
print(json.dumps(summ))
PY
[ $after -ne 0 ] && { echo "VOID: the after record differs (D19): this model's cell is off"; exit 4; }
grep -q '"void10": true' "$D/summary.json" && { echo "VOID: api-errors above 10% (M-4)"; exit 6; }
date -u +%FT%TZ > "$D/DONE"
echo "DONE $ST $M"
