"""learn-notes 1.12.0 G6 (batch 1) blind labels (M-8; 1.10.0 detail 20: labels P and Q, one pair for every stage of
this G, N2 included).
  seal          once rounds A and B are DONE for both models (answers saved, sha256 in each stage's summary.json):
                a random pair {haiku: P|Q, sonnet: the other} with a nonce -> judge/pair.json (chmod 444); only its
                sha256 is printed (judge/pair.json.sha256). Tools read it only to pick a label's files; none prints it.
  read          for each label and round: build.mjs read (the stage dir of that label's model) -> judge/<label>/read-<R>.json,
                then read2.mjs -> judge/<label>/read2-<R>.json (chmod 444). Prints counts by label only.
  open          after every verdict file is frozen: prints the pair (the decision step).
usage: label.py seal | read | open"""
import hashlib, json, os, secrets, subprocess, sys

S = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1"
J = os.environ.get("JUDGE", f"{S}/judge")
STAGE = os.environ.get("STAGE", f"{S}/stage")
PAIR = f"{J}/pair.json"
NODE = ["node", "--experimental-transform-types", "--no-warnings"]


def pair():
    return json.load(open(PAIR, encoding="utf-8"))["labels"]


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "seal":
        if os.path.exists(PAIR):
            sys.exit("refuse: the pair is sealed already")
        for r in ("A", "B"):
            for m in ("haiku", "sonnet"):
                if not os.path.exists(f"{STAGE}/{r}/{m}/DONE"):
                    sys.exit(f"refuse: round {r} of {m} is not done")
        first = secrets.choice(["P", "Q"])
        data = {"nonce": secrets.token_hex(16), "labels": {"haiku": first, "sonnet": "Q" if first == "P" else "P"}}
        os.makedirs(J, exist_ok=True)
        open(PAIR, "w", encoding="utf-8").write(json.dumps(data) + "\n")
        os.chmod(PAIR, 0o444)
        digest = hashlib.sha256(open(PAIR, "rb").read()).hexdigest()
        open(PAIR + ".sha256", "w").write(digest + "\n")
        print(json.dumps({"pairSha256": digest}))
    elif mode == "read":
        for m, label in pair().items():
            for r in ("A", "B"):
                d = f"{J}/{label}"
                os.makedirs(d, exist_ok=True)
                a = subprocess.run(NODE + [f"{S}/tools/build.mjs", "read", f"{STAGE}/{r}/{m}", f"{d}/read-{r}.json"], capture_output=True, text=True)
                if a.returncode != 0:
                    sys.exit(f"read failed for {label} {r}: {a.stderr[-500:]}")
                b = subprocess.run(NODE + [f"{S}/tools/read2.mjs", f"{d}/read-{r}.json", f"{d}/read2-{r}.json"], capture_output=True, text=True)
                if b.returncode != 0:
                    sys.exit(f"read2 failed for {label} {r}: {b.stderr[-500:]}")
                for f in (f"{d}/read-{r}.json", f"{d}/read2-{r}.json"):
                    os.chmod(f, 0o444)
                print(label, r, a.stdout.strip())
    elif mode == "open":
        print(json.dumps(pair()))
    else:
        sys.exit("usage: label.py seal | read | open")
