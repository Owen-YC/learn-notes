// learn-notes 1.11.0 G5 (docs/qa/견본.md, 1.10.0 G5 '도구가 글을 읽는 방식' 2 · 3): a frozen change made into the note
// the plugin keeps for it, as its hooks do (register.tsx tool.call Edit/Write → changeOf → collect: withheldOf, merge;
// turn.complete: the request cut 2000 and masked, the answer cut(redactText, 2000); screened → screenNote), from a
// tree's notes.ts; and each change's isThinkCode. build-a.mjs builds its notes with noteOf, so both read one way.
//
// CLI: node --experimental-transform-types think-code.mjs <tree dir> <hunks-G5.json> <changes-G5.json>
//   → prints {"<id>": true|false, …} (isThinkCode of the note's screened changes)
import { readFileSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
import { resolve } from 'node:path'

export const ROOT = '/proj'
/** The note's time: its prompts never say it; a fixed one keeps every build the same. */
export const NOTE_AT = Date.UTC(2026, 10, 4, 0, 0, 0)

export async function tree(dir) {
  return import(pathToFileURL(resolve(dir, 'notes.ts')).href)
}

/** The note's changes from one frozen change's files, in their order, as collect folds them (withheld named). */
export function changesOf(N, entry) {
  let changes = []
  const withheld = []
  for (const f of entry.files) {
    const hunks = f.tool === 'Write' && f.kind === 'create' && f.hunks.length === 0 ? [N.creationHunk(f.content)] : f.hunks
    const change = N.changeOf({ path: f.path, root: ROOT, tool: f.tool, kind: f.kind, hunks })
    const why = N.withheldOf(change.file, change.path, [])
    if (why !== undefined) {
      if (!withheld.some(one => one.file === change.file)) withheld.push({ file: change.file, why })
      continue
    }
    changes = N.merge(changes, change).changes
  }
  return { changes, withheld }
}

/** The note turn.complete keeps for the change (status writing, no text yet). */
export function noteOf(N, entry, sample) {
  const { changes, withheld } = changesOf(N, entry)
  const request = N.cut(sample.request ?? '', 2000)
  return {
    id: `${sample.id}-${NOTE_AT}`,
    turnId: sample.id,
    at: NOTE_AT,
    prompt: request !== '' ? N.redactText(request).text : '',
    answer: N.cut(N.redactText(sample.answer ?? '').text, 2000),
    changes,
    moreFiles: 0,
    ...(withheld.length > 0 ? { withheld } : {}),
    status: 'writing',
    text: '',
    savedAs: null,
    isPast: false,
    concepts: [],
    root: ROOT,
    updatedAt: NOTE_AT,
  }
}

/** The note as it goes to a model (screened: no excludePaths, no team file, no permission rule). */
export function shownOf(N, note) {
  return N.screenNote(note, [], () => false)
}

export function readJson(path) {
  return JSON.parse(readFileSync(path, 'utf8'))
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) {
  const [dir, hunksPath, changesPath] = process.argv.slice(2)
  const N = await tree(dir)
  const hunks = readJson(hunksPath)
  const samples = Object.fromEntries(readJson(changesPath).map(one => [one.id, one]))
  const out = {}
  for (const entry of hunks) out[entry.id] = N.isThinkCode(shownOf(N, noteOf(N, entry, samples[entry.id])).changes)
  console.log(JSON.stringify(out))
}
