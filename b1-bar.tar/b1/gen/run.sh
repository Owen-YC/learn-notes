#!/bin/bash
# learn-notes 1.12.0 G6 (batch 1): one fresh blind sample writer (plan samples.writers; SCOPE step 3).
# usage: run.sh <part: A|B|C|D>
# prompt = gen/common.md + gen/part-<part>.md + the avoid section (gen/avoid.py from NAMES-all.txt now), on stdin to
# `claude -p --model opus --tools ''` in an empty dir, through the pinned CLI (cli/pinned.sh, DISABLE_AUTOUPDATER=1).
# The writer sees only the team file, the module table, the JSON form, the writing rules and the avoid list: never a
# prompt, the rule drill code, the stance, the design or which model is measured. Refuses when the part's out exists.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1
P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh
PART="$1"
case "$PART" in A|B|C|D) ;; *) echo "usage: run.sh <A|B|C|D>"; exit 2;; esac
O="${S:?}/gen/out/$PART"
[ -e "$O" ] && { echo "refuse: $O exists"; exit 1; }
mkdir -p "$O" "${S:?}/work/gen-$PART"
python3 -I "${S:?}/gen/avoid.py" "$O/avoid.md" > "$O/avoid-count.txt" || exit 1
cat "${S:?}/gen/common.md" "${S:?}/gen/part-$PART.md" "$O/avoid.md" > "$O/prompt.md"
sha256sum "$O/prompt.md" > "$O/prompt.sha256"
cd "${S:?}/work/gen-$PART" || exit 1
date -u +%FT%TZ > "$O/started.txt"
"$P" bash -c 'timeout 2400 claude -p --model opus --tools "" --output-format json' < "$O/prompt.md" > "$O/out.json" 2> "$O/err.txt"
echo "exit=$?" > "$O/exit.txt"
date -u +%FT%TZ > "$O/ended.txt"
"$P" --record > "$O/pin.txt" 2>&1
python3 -I - "$O" <<'PY'
import json, sys
o = sys.argv[1]
d = json.load(open(o + "/out.json", encoding="utf-8"))
open(o + "/result.txt", "w", encoding="utf-8").write(d.get("result") or "")
open(o + "/model.txt", "w").write(json.dumps(sorted((d.get("modelUsage") or {}).keys())) + "\n")
print("writer", o, "is_error", d.get("is_error"))
PY
cat "$O/exit.txt"
