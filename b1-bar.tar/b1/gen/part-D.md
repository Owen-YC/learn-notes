
## 이번에 쓸 견본: 23개 (id GD01 ~ GD23)

trap 견본(kind "trap")은 `"trap": "module | test | script | export | config"` 칸을 더한다. violations는 빈 배열이다.

| id | kind | 꼴 |
| --- | --- | --- |
| GD01 | trap (module) | 팀 모듈 자신을 고침, request 규칙: 위 표의 request 모듈 파일 하나(그 경로)가 안에서 `fetch(`(파이썬은 `requests.`)를 씀 |
| GD02 | trap (module) | 팀 모듈 자신을 고침, log 규칙: 위 표의 log 모듈 파일 하나가 안에서 `console.log`(파이썬은 `print(`)를 씀 |
| GD03 | trap (module) | 팀 모듈 자신을 고침, date 규칙: 위 표의 date 모듈 파일 하나가 안에서 날짜 글자를 직접 만듦 |
| GD04 | trap (module) | 팀 모듈 자신을 고침, config 규칙: 위 표의 config 모듈 파일 하나가 안에서 `process.env`(파이썬은 `os.environ`)를 읽음 |
| GD05 · GD06 | trap (test) | 테스트 파일(새 파일)이 표지를 씀. 테스트 틀 없이 `export function`이나 `def` 꼴 |
| GD07 | trap (script) | 빌드 · 도구 스크립트(앱 코드가 아닌 곳, 예: 스크립트 폴더)가 표지를 씀. `export function`이나 `def` 꼴 |
| GD08 | trap (export) | 팀 모듈이 아닌 앱 모듈 하나(예: `src/utils/` 아래 파일)가 규칙의 쓰라는 이름과 같은 이름(예: `toDateText`)을 export하고, 그 안에서 표지를 씀 |
| GD09 | trap (config) | 이름에 `.config.`가 든 설정 파일(예: `something.config.js`)이 `process.env`를 읽음 |
| GD10 · GD11 · GD12 · GD13 | multi | 서로 다른 두 규칙을 어긴 줄 둘(각각 들여쓰기 빼고 40자 이하). violations 둘. 두 규칙의 팀 모듈을 그 파일이 이미 import함 |
| GD14 · GD15 · GD16 · GD17 | double | 같은 규칙 하나를 어긴 줄 둘(각각 들여쓰기 빼고 40자 이하, 서로 다른 줄). violations 둘. 그 팀 모듈을 그 파일이 이미 import함 |
| GD18 · GD19 | trap | 예비: GD18은 module(아무 규칙), GD19는 test |
| GD20 · GD21 | multi | 예비 |
| GD22 · GD23 | double | 예비 |

- GD01 ~ GD04의 lang: py 하나 이상, ts 하나 이상(js · ts 모듈 파일은 위 표의 경로에서 확장자만 `.ts`로 바꿔도 된다).
- trap이 아닌 견본(multi · double)의 lang은 네가 고르되 셋이 고루 섞이게 하고, 규칙도 고루 섞이게 한다.
- 요청 견본은 `responses`에 그 주소의 JSON을 준다. 설정 견본은 `env`에 그 이름의 값을 준다.
