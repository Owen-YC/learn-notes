#!/bin/bash
# learn-notes 1.12.0 G6 (batch 1): the fresh N2 answer writer of one label (`claude -p --model opus --tools ''`, empty
# dir, prompt on stdin, pinned CLI). usage: n2run.sh <label>   (gen/n2/<label>/prompt.md from tools/n2prompt.py)
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1
P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh
L="$1"
case "$L" in P|Q) ;; *) echo "usage: n2run.sh <P|Q>"; exit 2;; esac
O="${S:?}/gen/n2/$L"
[ -s "$O/prompt.md" ] || { echo "no prompt"; exit 2; }
[ -e "$O/out.json" ] && { echo "refuse: $O/out.json exists"; exit 1; }
mkdir -p "${S:?}/work/n2-$L" && cd "${S:?}/work/n2-$L" || exit 1
sha256sum "$O/prompt.md" > "$O/prompt.sha256"
date -u +%FT%TZ > "$O/started.txt"
"$P" bash -c 'timeout 2400 claude -p --model opus --tools "" --output-format json' < "$O/prompt.md" > "$O/out.json" 2> "$O/err.txt"
echo "exit=$?" > "$O/exit.txt"
date -u +%FT%TZ > "$O/ended.txt"
python3 -I - "$O" <<'PY'
import json, sys
o = sys.argv[1]
d = json.load(open(o + "/out.json", encoding="utf-8"))
open(o + "/result.txt", "w", encoding="utf-8").write(d.get("result") or "")
open(o + "/model.txt", "w").write(json.dumps(sorted((d.get("modelUsage") or {}).keys())) + "\n")
print("writer", o, "is_error", d.get("is_error"))
PY
