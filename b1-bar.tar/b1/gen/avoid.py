"""learn-notes 1.12.0 G6 (batch 1): the writers' avoid section, from impl112/NAMES-all.txt as it is when a writer
runs (plan samples.avoid; it holds every G1-G6 dev name, G3 P1-P6, G5 PC01-PC40 and every 견본.md name). Only the
entries a code name or a path can be (an identifier, a dotted name, or a path with a slash) are listed: the others
(Korean concept names and phrases the 견본.md extraction kept) cannot be a function or file name. Sorted, one per name.
usage: avoid.py <out.md>   (refuses to overwrite)"""
import os, re, sys
NAMES = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/NAMES-all.txt"
CODE = re.compile(r"^([A-Za-z_$][A-Za-z0-9_$.]*|[A-Za-z0-9_./$-]+/[A-Za-z0-9_./$-]+)$")
out = sys.argv[1]
if os.path.exists(out):
    sys.exit(f"refuse: {out} exists")
names = sorted({l.split("\t", 1)[0] for l in open(NAMES, encoding="utf-8") if l.strip() and CODE.match(l.split("\t", 1)[0])})
open(out, "w", encoding="utf-8").write("\n## 피할 이름 (함수 · 파일 이름, 경로로 쓰지 마라)\n\n" + ", ".join(names) + "\n")
print(len(names))
