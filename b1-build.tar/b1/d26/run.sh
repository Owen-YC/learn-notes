#!/bin/bash
# batch 1 build: D26 recheck on the working-tree snapshot impl113/b1/tree (0 model calls).
# isRuleWide haiku + sonnet: impl113/d26/rulewide113.mjs --extra impl112/b1/audit/d26x/extra.json (no G6 1.13.0 frozen samples yet).
# G2 haiku: impl113/d26/g2haiku.sh.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b1
H=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/d26
X=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1/audit/d26x/extra.json
export DISABLE_AUTOUPDATER=1
cd "${S:?}/d26" || exit 1
[ -e STARTED ] && { echo "refuse: STARTED exists"; exit 9; }
date -u +%FT%TZ > STARTED
node --experimental-transform-types --no-warnings "$H/rulewide113.mjs" "$S/tree" "$S/d26/out-rw" --extra "$X" > rw.log 2> rw.err; echo $? > rw.exit
"$H/g2haiku.sh" "$S/tree" "$S/d26/out-g2" > g2.log 2>&1; echo $? > g2.exit
date -u +%FT%TZ > DONE
