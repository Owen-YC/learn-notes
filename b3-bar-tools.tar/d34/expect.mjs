// learn-notes 1.13.0 G5 sonnet (batch 3) D34: the requests the tools expect (tools/kit.mjs), per test of d34/make.py,
// which catches the committed tree's own requests from its plugin test harness and sets them against these to the byte
// (model · effort · system · prompt · maxTokens · timeoutMs; a tool line's effort is the probe's 'low'). From
// impl112/b4/d34/expect.mjs (1.12.0 G5c) with the G5e text plan (code: no call; check; fallback). No model call.
// Each test: the alias, level beginner, the harness row `models: { <alias>: { isThinkAsked: true } }` (the rest of the
// committed row), with or without the team file (d34/team.md); the change's request, its files by Edit · Write, the
// turn's answer; the note's call; r's key; a minute on, the typed words. Its requests in order: note, r, then the
// text's request (check or fallback when a line opened and the plan calls; the question when none opened; NONE when the
// plugin's code answers: the test then must catch exactly two requests). Modes (print JSON { tests: [...] }):
//   set <set dir> <model> [team]   every change of a frozen set, fixed replies (note, r and the third request) before
//                                  any call of that set
//   real-r <set dir> <note out.json> <r lines.jsonl> <model>
//                                  each answered note's real reply: note request and r request = the frozen r line itself
//   real-text <set dir> <note out.json> <r out.json> <text lines.jsonl> <plan.json> <model>
//                                  each text: its note's and r's real replies, its typed words: the third request = the
//                                  frozen text line itself (check, fallback), or none (code)
//   fallback <harness note.json> <model> <typed> <at>
//                                  the fallback kind on a harness's stored note (a line calc cannot run in the note as it
//                                  now is): the request kit.textPlanOfNote makes
import { readFileSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
const S = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b3'
const K = await import(pathToFileURL(`${S}/tools/kit.mjs`).href)

export const NOTE_ANSWER = ['### 한 줄 요약', '함수가 받은 값을 검사한 뒤 결과를 돌려주게 바꿨습니다.', '', '### 무엇이 바뀌었나', '- 입력을 먼저 검사하고, 맞지 않으면 다른 값을 돌려줍니다.', '', '### 배울 개념', '- **조건문**: 값에 따라 다른 길로 가게 합니다.'].join('\n')
export const CHECK_REPLY = ['종류: 질문', '짐작값: 없음', '다른 호출: 없음', '식: 없음', '답: 값을 다시 계산합니다.', '판정: 없음'].join('\n')
export const TYPED = '왜 이 값이 나와요?'
const TEAM = readFileSync(`${S}/d34/team.md`, 'utf8')
const lines = p => readFileSync(p, 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l))
const req = l => ({ model: l.model, effort: 'low', system: l.system, prompt: l.prompt, maxTokens: l.maxTokens, timeoutMs: l.timeoutMs })
const outs = p => Object.fromEntries(JSON.parse(readFileSync(p, 'utf8')).results.map(r => [r.id, r]))

/** A walk-through of the first callee's anchor (or an example call of its arity), or a plain one with no call. */
export function rAnswerOf(callees) {
  const c = callees[0]
  if (!c) return ['1. 예시 입력으로 함수를 부릅니다.', '2. 조건을 보고 다음 줄로 갑니다.', '3. 마지막에 결과를 돌려줍니다.'].join('\n')
  const call = c.anchor ?? `${c.name}(${Array.from({ length: Math.max(1, c.params?.length ?? 1) }, () => '1').join(', ')})`
  return [`예시 호출: \`${call}\``, '', '1. 예시 입력으로 함수를 부릅니다.', '2. 조건을 보고 다음 줄로 갑니다.', '3. 마지막에 결과를 돌려줍니다.', '', '결과: `1`'].join('\n')
}

/** note, r and the third request (or none) for one change, model, team, replies and typed words. */
export function wantOf(model, sample, entry, team, noteAnswer, rAnswer, typed) {
  const want = [req(K.noteLine(model, sample, entry, team))]
  const r = K.rLine(model, sample, entry, noteAnswer, team)
  want.push(req(r.line))
  const got = K.readR(model, sample, entry, noteAnswer, K.N.fixEscapedTicks(rAnswer), team)
  let third = 'question'
  if (got.think) {
    const p = K.textPlan(model, 'x', sample, entry, noteAnswer, got.stored, typed, team)
    third = p.plan.kind
    if (p.req) want.push(req(p.req))
  } else {
    const note = { ...K.keptNote(model, sample, entry, noteAnswer, team), asks: [{ question: K.N.TRACE_LABEL, answer: got.stored, at: K.R_AT }] }
    const shown = K.shownOf(note, team)
    want.push({ model, effort: 'low', system: K.N.ASK_SYSTEM, prompt: K.N.redactText(K.N.askPrompt(shown, K.N.redactText(typed).text, K.LEVEL, team, undefined, true)).text, maxTokens: K.NUMS.ASK_TOKENS, timeoutMs: K.NUMS.MODEL_TIMEOUT_MS })
  }
  return { want, kind: r.isCode ? (r.scope.callees.some(c => c.anchor) ? 'r-anchor' : 'r-noanchor') : 'r-out', third }
}

const [mode, ...args] = process.argv.slice(2)
const tests = []
if (mode === 'set') {
  const [dir, model, withTeam] = args
  const team = withTeam === 'team' ? K.teamOf(TEAM) : undefined
  for (const { sample, entry } of K.samplesOf(dir)) {
    const rs = K.rLine(model, sample, entry, NOTE_ANSWER, team)
    const rAnswer = rAnswerOf(rs.scope.callees)
    const w = wantOf(model, sample, entry, team, NOTE_ANSWER, rAnswer, TYPED)
    tests.push({ name: `set ${sample.id} ${model} ${team ? 'team' : 'noteam'} ${w.kind} ${w.third}`, sample, entry, model, team: team ? TEAM : null, texts: [NOTE_ANSWER, rAnswer, CHECK_REPLY], typed: TYPED, want: w.want, kind: w.kind, third: w.third })
  }
} else if (mode === 'real-r') {
  const [dir, noteOut, rLines, model] = args
  const notes = outs(noteOut)
  const rl = Object.fromEntries(lines(rLines).map(l => [l.id, l]))
  for (const { sample, entry } of K.samplesOf(dir)) {
    const o = notes[sample.id]
    if (!o?.isAnswered || !o.text?.trim()) continue
    if (!rl[sample.id]) throw new Error(`${sample.id}: answered note with no r line`)
    tests.push({ name: `real-r ${sample.id} ${model}`, sample, entry, model, team: null, texts: [o.text, rAnswerOf([]), CHECK_REPLY], typed: null, want: [req(K.noteLine(model, sample, entry)), req(rl[sample.id])], kind: 'r' })
  }
} else if (mode === 'real-text') {
  const [dir, noteOut, rOut, textLines, planPath, model] = args
  const notes = outs(noteOut)
  const rs = outs(rOut)
  const plan = JSON.parse(readFileSync(planPath, 'utf8')).plans
  const tl = Object.fromEntries(lines(textLines).map(l => [l.id, l]))
  const byId = Object.fromEntries(K.samplesOf(dir).map(one => [one.sample.id, one]))
  for (const [id, m] of Object.entries(plan)) {
    const { sample, entry } = byId[m.sid]
    const want = [req(K.noteLine(model, sample, entry)), req(K.rLine(model, sample, entry, notes[m.sid].text).line)]
    if (m.kind !== 'code') {
      if (!tl[id]) throw new Error(`${id}: no frozen line`)
      want.push(req(tl[id]))
    } else if (tl[id]) throw new Error(`${id}: a code text has a line`)
    tests.push({ name: `real-text ${id} ${model} ${m.kind}`, sample, entry, model, team: null, texts: [notes[m.sid].text, rs[m.sid].text, CHECK_REPLY], typed: m.typed, want, kind: 'r', third: m.kind })
  }
} else if (mode === 'fallback') {
  const [notePath, model, typed, at] = args
  const note = JSON.parse(readFileSync(notePath, 'utf8'))
  const p = K.textPlanOfNote(model, 'x', note, typed, undefined, Number(at))
  console.log(JSON.stringify({ kind: p.plan.kind, want: p.req ? req(p.req) : null }))
  process.exit(0)
} else throw new Error('usage: expect.mjs set … | real-r … | real-text … | fallback …')
console.log(JSON.stringify({ tests }))
