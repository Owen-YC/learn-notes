"""learn-notes 1.13.0 G5 sonnet (batch 3): the GO gate's PH writer parts (gen/parts.json is the layout; the make/read/
assemble interface of impl113/b2/gen/parts.py). A writer sees only the scene form, the product-level layout of its own
part and the avoid section: never a prompt of the app, the code, the stance, the design or which model is measured.
  make <root> <part> <out prompt.md>   PH-I: gen/writer-I.md + avoid section + gen/writer-I-end.md; PH-O likewise with -O.
       The avoid section is the frozen builder's (gen/avoid113.py on impl113/NAMES-all.txt as it is when the prompt is
       made, written beside the prompt: names only), unchanged. A top-up (TU-I, TU-O; run.sh topup with CHAIN_ROOT = the
       samples root) uses the same frame with its '## 짜임' list replaced mechanically: <CHAIN_ROOT>/topup-need.json
       (written by tools/check.py) names the missing slots in layout order; each missing slot's own line is written
       twice, first under the next top-up id and then under the one after it as that slot's spare (at most 10
       records), the line's text kept and only its id changed. Refuses to overwrite.
  read <part dir> <part>               result.txt: one ```json block, else the whole reply from its first '[' to its
       last ']', as a JSON array of objects whose ids are exactly the part's ids (a top-up: the ids its prompt names).
       Exit 0 readable (reply.json), 5 not. Never edits a reply.
  assemble <root>                      every main part read -> <root>/raw.json (records in layout order, each with
       its 'part'; exit 6 when a main part has no reply.json)."""
import json, os, re, subprocess, sys

G = os.path.dirname(os.path.abspath(__file__))
L = json.load(open(f"{G}/parts.json", encoding="utf-8"))
LAYOUT = L["parts"]
TOPUPS = L["topups"]
BY = {p["part"]: p for p in LAYOUT + TOPUPS}
SLOT = re.compile(r"^- (PH\d\d)(.*)$", re.M)


def latest(root, part):
    for t in range(9, 0, -1):
        d = f"{root}/parts/{part}-{t}"
        if os.path.exists(f"{d}/reply.json") and not os.path.exists(f"{d}/VOIDED"):
            return d
    return None


def topup_lines(p):
    """The top-up's slot lines and ids: the missing slots' own lines from the main frame, each twice."""
    need = json.load(open(os.path.join(os.environ["CHAIN_ROOT"], "topup-need.json"), encoding="utf-8"))[p["part"]]
    frame = open(f"{G}/writer-{p['kind']}.md", encoding="utf-8").read()
    own = {m.group(1): m.group(2) for m in SLOT.finditer(frame)}
    lines, ids = [], []
    for slot in need:
        for _ in (0, 1):
            if len(ids) == len(p["ids"]):
                break
            i = p["ids"][len(ids)]
            ids.append(i)
            lines.append(f"- {i}{own[slot]}")
    return lines, ids


def make(root, part, out):
    if os.path.exists(out):
        sys.exit(f"refuse: {out} exists")
    p = BY[part]
    d = os.path.dirname(out)
    av, keep, tools = f"{d}/avoid.md", f"{d}/avoid-names.txt", f"{d}/avoid-toolnames.txt"
    r = subprocess.run(["python3", "-I", f"{G}/avoid113.py", av, keep, tools], capture_output=True, text=True)
    if r.returncode:
        sys.exit("avoid113.py: " + r.stderr)
    open(f"{d}/avoid-build.json", "w").write(r.stdout)
    section = open(av, encoding="utf-8").read()
    body = open(f"{G}/writer-{p['kind']}.md", encoding="utf-8").read()
    end = open(f"{G}/writer-{p['kind']}-end.md", encoding="utf-8").read()
    if p.get("topup"):
        lines, ids = topup_lines(p)
        if not ids:
            sys.exit("nothing missing")
        head, rest = body.split("## 짜임 (id는 아래 차례 그대로)\n", 1)
        intro, tail = rest.split("\n\n공통:", 1)
        first = intro.strip().split("\n\n")[0]
        body = head + "## 짜임 (id는 아래 차례 그대로)\n\n" + first + "\n\n" + "\n".join(lines) + "\n\n공통:" + tail
        body = re.sub(r"장면 \d+개", f"장면 {len(ids)}개", body)
        open(f"{d}/ids.json", "w").write(json.dumps(ids) + "\n")
    open(out, "w", encoding="utf-8").write(body + section + end)


def ids_of(d, part):
    """A top-up's ids are those its first try's prompt names (a second try sends that prompt's bytes again)."""
    p = BY[part]
    if p.get("topup"):
        first = re.sub(r"-\d+$", "-1", d)
        return json.load(open(f"{first}/ids.json"))
    return p["ids"]


def read(d, part):
    text = open(f"{d}/result.txt", encoding="utf-8").read() if os.path.exists(f"{d}/result.txt") else ""
    blocks = re.findall(r"```json[ \t]*\n(.*?)\n```", text, re.S)
    if len(blocks) == 1:
        body = blocks[0]
    elif not blocks and "[" in text and "]" in text:
        body = text[text.index("["): text.rindex("]") + 1]
    else:
        body = None
    v = None
    if body is not None:
        try:
            v = json.loads(body)
        except Exception:
            v = None
    try:
        want = ids_of(d, part)
    except Exception:
        want = None
    ok = isinstance(v, list) and all(isinstance(x, dict) for x in v) and want is not None and sorted(str(x.get("id")) for x in v) == sorted(want)
    json.dump({"part": part, "readable": ok, "blocks": len(blocks), "records": len(v) if isinstance(v, list) else 0},
              open(f"{d}/readable.json", "w"), indent=1)
    if not ok:
        sys.exit(5)
    json.dump(v, open(f"{d}/reply.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def assemble(root):
    out = f"{root}/raw.json"
    if os.path.exists(out):
        sys.exit(f"refuse: {out} exists")
    rows = []
    for p in LAYOUT:
        d = latest(root, p["part"])
        if not d:
            print(f"no reply for {p['part']}")
            sys.exit(6)
        rows += [{"part": p["part"], **r} for r in json.load(open(f"{d}/reply.json", encoding="utf-8"))]
    open(out, "w", encoding="utf-8").write(json.dumps(rows, ensure_ascii=False, indent=1) + "\n")
    print(len(rows))


if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "make":
        make(sys.argv[2], sys.argv[3], sys.argv[4])
    elif cmd == "read":
        read(sys.argv[2], sys.argv[3])
    elif cmd == "assemble":
        assemble(sys.argv[2])
    else:
        sys.exit(2)
