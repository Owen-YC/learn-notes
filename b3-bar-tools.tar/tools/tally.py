"""learn-notes 1.13.0 G5 sonnet (batch 3): the counts of a label from frozen files only (no model call, no notes.ts: the
mechanical parts by tools/same.py, the stance's [공통] 4). From impl112/b4/tools/tally.py with the G5e (가)-1 conditions
and the (나) machine clauses. Cap hit = output_tokens >= maxTokens + H_sonnet (2048, '보정 기록 (1.13.0)', never
re-measured): note >= 5548, r and check >= 2948; an empty reply, a call cut by its time limit and an api-error left after
its one resend are misses and cap hits (stance [공통]); an in-scope note with no text is an r cap hit (r is not called)
and a usable-line miss.
  a <set> <label>          -> <set>/tally-a.json
     usable (in-scope only) = (1) the line opened (stored.json) AND (2) the runner gave one result AND (3) the line is
     code's fixed sentence ('를 실행한 결과를 값 하나로 적어 보세요') AND (4) both judges 'ok' on exposure AND (5) the
     line's call is not the walked call (anchor, else the walk-through's 예시 호출: same.canon_same False) AND both judges
     'ok' on input (a split or an undecided = miss, M-9 · M-11); opened must-open-0 lines; exposure = opened lines
     (either group) that are not 'ok' on exposure by both judges; cap hits of the note and r stages; the largest r
     output_tokens of every answered r call; calc vs runner mismatches (record, [러너] S13 · S20 STOP flag)
  n <set> <label> <round>  -> <set>/tally-n-<label>-<round>.json
     guess: answered AND machine (a) the shown head equals the expected verdict (texts.py apply) AND (b) every value the
     reply shows as computed equals its runner value (runner.py exprs; under 틀림 a `바른 결과:` line must be there) AND
     (d) no new 생각해 보기 AND (e) at most three sentences AND (g) no labelled block AND both judges 'ok'; a '?' form
     with no verdict head (the question branch) is held to the question's machine clauses and the judges.
     question: answered AND no verdict head (S6) AND not SLOT_UNREAD alone (S25) AND no new 생각해 보기 AND every shown
     computed value equals its runner value AND both judges 'ok'.
     blank: answered AND not SLOT_UNREAD alone AND a computed value shown that equals the line's runner result and none
     that differs AND both judges 'ok'.
     check cap hits; refusals (the tap's stop_reason 'refusal' of the stage's empty replies).
Groups: go: guesses = guess (24, '?' forms included), questions = question kinds (22), blanks (4). Writes once, chmod 444."""
import hashlib, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import same as SAME  # noqa: E402

S = os.environ.get("G5_ROOT", os.path.dirname(HERE))  # G5_ROOT: synthetic tests only
H = 2048
CAP = {"note": 3500 + H, "r": 900 + H, "check": 900 + H}
UNREAD = "답을 제대로 읽지 못했습니다. 질문을 한 번 더 적어 주세요."
LINE_FORM = re.compile(r"^`[^`\n]+`를 실행한 결과를 값 하나로 적어 보세요 \(오류면 `오류`\)$")
load = lambda p: json.load(open(p, encoding="utf-8"))


def write_once(path, data):
    if os.path.exists(path):
        sys.exit(f"refuse: {path} exists")
    body = json.dumps(data, ensure_ascii=False, indent=1) + "\n"
    open(path, "w", encoding="utf-8").write(body)
    os.chmod(path, 0o444)
    return hashlib.sha256(body.encode()).hexdigest()


def verdicts(root):
    p = f"{root}/verdicts.json"
    v = load(p) if os.path.exists(p) else {}
    parts = sorted(v)
    return [v[k]["items"] for k in parts] if len(parts) == 2 else [{}, {}]


def stage_final(set_name, st):
    p = f"{S}/{set_name}/stage/{st}/sonnet/summary.json"
    return load(p)["final"] if os.path.exists(p) else {}


def cap_of(st, f):
    if f is None:
        return True
    if f["how"] != "answered":
        return f["how"] in ("empty-reply", "aborted", "no-status") or f["how"].startswith("api-error")
    return (f.get("output_tokens") or 0) >= CAP[st]


def walked(s):
    if s.get("anchor"):
        return s["anchor"]
    return s.get("exampleCall")


def tally_a(set_name, label):
    d = f"{S}/{set_name}"
    changes = load(f"{d}/frozen/changes.json")
    stored = load(f"{d}/stored.json")
    runner = load(f"{d}/runner.json")["runner"]
    j1, j2 = verdicts(f"{d}/judge-a-{label}")
    note, r = stage_final(set_name, "note"), stage_final(set_name, "r")
    rows, usable, exposure, opened_out = {}, [], [], []
    caps = {"note": [], "r": []}
    r_max, calc_diff = 0, []
    for c in changes:
        i, g = c["id"], c["group"]
        s = stored.get(i, {})
        if cap_of("note", note.get(i)):
            caps["note"].append(i)
        if s.get("note") == "no text" and g == "in":
            caps["r"].append(i)
        rf = r.get(i)
        if rf is not None:
            if cap_of("r", rf) and i not in caps["r"]:
                caps["r"].append(i)
            if rf["how"] == "answered":
                r_max = max(r_max, rf.get("output_tokens") or 0)
        opened = bool(s.get("line"))
        rr = runner.get(i, {}) if opened else {}
        run_ok = bool(rr.get("runner"))
        if opened and rr and not rr.get("calcAgrees"):
            calc_diff.append(i)
        one = bool(opened and LINE_FORM.match(s["line"]))
        w = walked(s) if opened else None
        lang = "py" if (s.get("calleeFile") or "").endswith(".py") else "js"
        differs = bool(opened and s.get("call") and not (w and SAME.canon_same(s["call"], w, lang)))
        e = [jx.get(i, {}).get("exposure") for jx in (j1, j2)]
        n = [jx.get(i, {}).get("input") for jx in (j1, j2)]
        if opened and e != ["ok", "ok"]:
            exposure.append(i)
        if opened and g == "out":
            opened_out.append(i)
        ok = g == "in" and opened and run_ok and one and e == ["ok", "ok"] and differs and n == ["ok", "ok"]
        if ok:
            usable.append(i)
        rows[i] = {"group": g, "opened": opened, "runner": run_ok, "oneResult": one, "walked": w, "inputDiffers": differs, "exposure": e, "input": n, "usable": ok}
    data = {"set": set_name, "label": label, "inScope": sum(1 for c in changes if c["group"] == "in"), "mustOpen0": sum(1 for c in changes if c["group"] == "out"),
            "usable": len(usable), "usableIds": usable, "openedOut": opened_out, "exposure": exposure, "capHits": caps,
            "capHitsTotal": len(caps["note"]) + len(caps["r"]), "rCapHits": len(caps["r"]), "rMax": r_max, "rCalls": len(r), "calcRunnerMismatch": calc_diff, "rows": rows}
    print(json.dumps({k: data[k] for k in ("usable", "inScope", "openedOut", "exposure", "capHits", "rMax", "rCalls", "calcRunnerMismatch")}))
    print(json.dumps({"sha256": write_once(f"{d}/tally-a.json", data)}))


def tally_n(set_name, label, rnd):
    d = f"{S}/{set_name}"
    texts = load(f"{d}/texts-{label}.json")["texts"]
    shown = load(f"{d}/read-{label}-{rnd}.json")
    vals = load(f"{d}/exprs-{label}-{rnd}.json")["values"]
    j1, j2 = verdicts(f"{d}/judge-n-{label}-{rnd}")
    st = "check" if set_name == "go" else rnd
    final = stage_final(set_name, st)
    tap_p = f"{d}/stage/{st}/sonnet/tap.json"
    tap = load(tap_p) if os.path.exists(tap_p) else {"sent": {}}
    groups = {"guesses": [0, 0, []], "questions": [0, 0, []], "blanks": [0, 0, []]}
    rows = {}
    for t in texts:
        row = shown[t["id"]]
        s = row.get("shown") or ""
        jv = [jx.get(t["id"], {}).get("verdict") for jx in (j1, j2)]
        judged = jv == ["ok", "ok"]
        v = vals.get(t["id"], [])
        values_ok = all(x["same"] is True for x in v)
        h = SAME.head(s) if row["answered"] else None
        unread = s.strip() == UNREAD
        miss = []
        if not row["answered"]:
            miss.append("no answer")
        if t["kind"] == "guess" or t["kind"] == "questionGuess":
            grp = "guesses" if (t["kind"] == "guess" or set_name == "go") else "questions"
            if t["kind"] == "guess" and t.get("mark") != "?" or h in ("맞음", "틀림", "거의"):
                if t.get("expect") is None or h != t["expect"]:
                    miss.append(f"a (head {h}, expect {t.get('expect')})")
                if h == "틀림" and not any(x["kind"] == "right" for x in v):
                    miss.append("b (no 바른 결과)")
                if not values_ok:
                    miss.append("b/S20 (a shown value differs from the runner or was not run)")
                if SAME.think(s):
                    miss.append("d")
                if SAME.sentences(s) > 3:
                    miss.append("e")
                if SAME.labelled(s):
                    miss.append("g")
            else:
                if unread:
                    miss.append("S25")
                if SAME.think(s):
                    miss.append("c/d")
                if not values_ok:
                    miss.append("S20")
        elif t["kind"] == "blank":
            grp = "blanks"
            if unread:
                miss.append("S25")
            if not v or not values_ok:
                miss.append("result (no shown result, or one that differs)")
        else:
            grp = "questions"
            if h != "없음":
                miss.append(f"S6 (head {h})")
            if unread:
                miss.append("S25")
            if SAME.think(s):
                miss.append("c")
            if not values_ok:
                miss.append("S20")
        if not judged:
            miss.append(f"judges {jv}")
        ok = not miss
        g = groups[grp]
        g[1] += 1
        if ok:
            g[0] += 1
        else:
            g[2].append(t["id"])
        rows[t["id"]] = {"group": grp, "kind": t["kind"], "path": row.get("path"), "head": h, "expect": t.get("expect"), "judges": jv, "miss": miss, "ok": ok}
    caps = [i for i, f in final.items() if cap_of("check", f)]
    outs = [f.get("output_tokens") or 0 for f in final.values() if f.get("how") == "answered"]
    refusals = [i for i, v in tap.get("sent", {}).items() if v.get("stop_reason") == "refusal"]
    data = {"set": set_name, "label": label, "round": rnd, **{k: {"ok": v[0], "of": v[1], "misses": v[2]} for k, v in groups.items()},
            "checkCapHits": caps, "checkCalls": len(final), "checkMax": max(outs) if outs else 0, "refusals": refusals, "tapped": len(tap.get("sent", {})), "rows": rows}
    print(json.dumps({k: data[k] for k in ("guesses", "questions", "blanks", "checkCapHits", "checkCalls", "checkMax", "refusals")}, ensure_ascii=False))
    print(json.dumps({"sha256": write_once(f"{d}/tally-n-{label}-{rnd}.json", data)}))


if __name__ == "__main__":
    if sys.argv[1] == "a":
        tally_a(sys.argv[2], sys.argv[3])
    elif sys.argv[1] == "n":
        tally_n(sys.argv[2], sys.argv[3], sys.argv[4])
    else:
        sys.exit("usage: tally.py a <set> <label> | n <set> <label> <round>")
