// learn-notes 1.13.0 G5 sonnet (batch 3) measurement kit: every G5 request and every reading of a reply, built by
// importing the build commit's notes.ts (impl113/b3/mtree = git archive 5ac71f2; hooks/notes.ts 239c7838…67ab, calc.ts
// e6c27b5a…e9f5, newrun.ts 393ed29b…1943), the way register.tsx's writeNote and askNote use it with only that model's
// isThinkAsked on (the rest of that model's MODEL_SWITCHES row as committed, M-13). Rebuilt from impl112/b4/tools/kit.mjs
// (the 1.12.0 G5c kit) with the G5e calls of the design's pilot tools (impl113/design/G5/final/tools build.mjs,
// nstage.mjs). The note is made as impl111/b7 think-code.mjs makes it (tool.call Edit/Write -> changeOf -> withheldOf,
// merge; turn.complete: request cut 2000 masked, answer cut(redactText, 2000)); screened -> screenNote with the team
// file's `## 빼기` patterns when a team file is given.
//   note   SYSTEM + notePrompt(shown, beginner, knownNames({}), team), NOTE_TOKENS
//   r      ASK_SYSTEM + askPrompt(shown, redactText(callees ? traceCalcQuestion(callees) : traceQuestion(false)).text,
//          beginner, team, undefined, true), 900; shown = the kept note (keptNoteText(reply, isRuleWide ? ruleNames : [])),
//          callees = thinkCalcScope(shown.changes).callees
//   stored cut(callees ? thinkCalcKept(text, scope, shown.text, diffs) : thinkKept(text, false), 4000) at R_AT
//   line   openThink(asks, R_AT + 60000, true, true)
//   text   plan = thinkCalcPlan(shown, think, redactText(typed).text, beginner, thinkVariantOf(model)):
//            code      no call; shown = cut(plan.text, 4000)
//            check     plan.system + plan.prompt, THINK_CHECK_TOKENS; shown = cut(thinkCalcReply(text, plan.facts, masked,
//                      [shown.text, think.trace, masked, ...diffs].join('\n')), 4000)
//            fallback  ASK_SYSTEM + askPrompt(shown, masked, beginner, team, undefined, false), 900; shown = cut(text, 4000)
// Every prompt in a line is redactText's output (askModel masks it; the probe masks it again, a no-op). Numbers are read
// from the tree's register.tsx and checked against the design's (3500, 900, 900, 90000).
import { readFileSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
import { createHash } from 'node:crypto'

export const S = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b3'
export const TREE = process.env.G5_TREE ?? `${S}/mtree`
export const N = await import(pathToFileURL(`${TREE}/hooks/notes.ts`).href)
/** The calc engine module (calcCall for the line's own result: the STOP flag of [러너] S13 · S20 only). */
export const C = await import(pathToFileURL(`${TREE}/hooks/calc.ts`).href)
export const ROOT = '/proj'
export const LEVEL = 'beginner'
/** The note's time (its prompts never say it); r answered two minutes on; the line read and texts typed a minute after. */
export const NOTE_AT = Date.UTC(2026, 10, 4, 0, 0, 0)
export const R_AT = NOTE_AT + 120_000
export const ASKED_AT = R_AT + 60_000
export const sha = text => createHash('sha256').update(text).digest('hex')
export const readJson = path => JSON.parse(readFileSync(path, 'utf8'))

/** The numbers register.tsx gives each call, read from the tree itself (a different tree fails here, not silently). */
export function registerNumbers() {
  const src = readFileSync(`${TREE}/hooks/register.tsx`, 'utf8')
  const num = name => Number(new RegExp(`^const ${name} = ([\\d_]+)$`, 'm').exec(src)?.[1]?.replaceAll('_', ''))
  const got = { NOTE_TOKENS: num('NOTE_TOKENS'), THINK_CHECK_TOKENS: num('THINK_CHECK_TOKENS'), MODEL_TIMEOUT_MS: num('MODEL_TIMEOUT_MS') }
  const check = "? { system: plan.system, prompt: plan.prompt, maxTokens: THINK_CHECK_TOKENS }"
  const ask = ": { system: ASK_SYSTEM, prompt: askPrompt(shown, masked, level, rules, plan?.kind === 'fallback' ? undefined : think, plan?.kind === 'fallback' ? false : isThinkAsked), maxTokens: 900 },"
  got.ASK_TOKENS = src.includes(check) && src.includes(ask) ? 900 : NaN
  const want = { NOTE_TOKENS: 3500, THINK_CHECK_TOKENS: 900, MODEL_TIMEOUT_MS: 90000, ASK_TOKENS: 900 }
  for (const [k, v] of Object.entries(want)) if (got[k] !== v) throw new Error(`register.tsx ${k} is ${got[k]}, the design says ${v}`)
  return got
}
export const NUMS = registerNumbers()

/** The committed row of a model with isThinkAsked on (M-13: nothing else changed). */
export function switchesOf(model) {
  return { ...N.MODEL_SWITCHES[model], isThinkAsked: true }
}

/** The note's changes from one frozen change's files, in their order, as collect folds them (withheld named). */
export function changesOf(entry) {
  let changes = []
  const withheld = []
  for (const f of entry.files) {
    const hunks = f.tool === 'Write' && f.kind === 'create' && f.hunks.length === 0 ? [N.creationHunk(f.content)] : f.hunks
    const change = N.changeOf({ path: f.path, root: ROOT, tool: f.tool, kind: f.kind, hunks })
    const why = N.withheldOf(change.file, change.path, [])
    if (why !== undefined) {
      if (!withheld.some(one => one.file === change.file)) withheld.push({ file: change.file, why })
      continue
    }
    changes = N.merge(changes, change).changes
  }
  return { changes, withheld }
}

/** The note turn.complete keeps for the change (status writing, no text yet). */
export function noteOf(entry, sample) {
  const { changes, withheld } = changesOf(entry)
  const request = N.cut(sample.request ?? '', 2000)
  return {
    id: `${sample.id}-${NOTE_AT}`,
    turnId: sample.id,
    at: NOTE_AT,
    prompt: request !== '' ? N.redactText(request).text : '',
    answer: N.cut(N.redactText(sample.answer ?? '').text, 2000),
    changes,
    moreFiles: 0,
    ...(withheld.length > 0 ? { withheld } : {}),
    status: 'writing',
    text: '',
    savedAs: null,
    isPast: false,
    concepts: [],
    root: ROOT,
    updatedAt: NOTE_AT,
  }
}

/** The team file as loadTeam parses it (undefined: no team file). */
export const teamOf = markdown => (markdown === undefined || markdown === null ? undefined : N.parseTeamFile(markdown))

/** screened(): excludePaths none, the team file's `## 빼기`, no permission rule. */
export const shownOf = (note, team) => N.screenNote(note, team?.exclude ?? [], () => false)

const line = (id, model, system, prompt, maxTokens) => ({ id, model, system, prompt: N.redactText(prompt).text, maxTokens, timeoutMs: NUMS.MODEL_TIMEOUT_MS })

/** writeNote's call. */
export function noteLine(model, sample, entry, team) {
  const shown = shownOf(noteOf(entry, sample), team)
  return line(sample.id, model, N.SYSTEM, N.notePrompt(shown, LEVEL, N.knownNames({}), team), NUMS.NOTE_TOKENS)
}

/** The note as writeNote keeps it (isRuleWide on in both committed rows; isRuleDrill off: no practice made). */
export function keptNote(model, sample, entry, noteAnswer, team) {
  const names = team && switchesOf(model).isRuleWide ? N.ruleNamesOf(team.rules) : []
  return { ...noteOf(entry, sample), status: 'ready', text: N.keptNoteText(noteAnswer, names) }
}

/** askNote for r's key, ON: the calc scope read from the screened note; the question built from it (or 1.7.0's). */
export function rLine(model, sample, entry, noteAnswer, team) {
  const shown = shownOf(keptNote(model, sample, entry, noteAnswer, team), team)
  const scope = N.thinkCalcScope(shown.changes)
  const isCode = scope.callees.length > 0
  const masked = N.redactText(isCode ? N.traceCalcQuestion(scope.callees) : N.traceQuestion(false)).text
  return { line: line(sample.id, model, N.ASK_SYSTEM, N.askPrompt(shown, masked, LEVEL, team, undefined, true), NUMS.ASK_TOKENS), shown, scope, isCode }
}

/** What askNote stores of r's reply (text as the probe gives it: fixEscapedTicks applied) and the line a minute on. */
export function readR(model, sample, entry, noteAnswer, rText, team) {
  const { shown, scope, isCode } = rLine(model, sample, entry, noteAnswer, team)
  const diffs = shown.changes.map(one => one.diff)
  const stored = N.cut(isCode ? N.thinkCalcKept(rText, scope, shown.text, diffs) : N.thinkKept(rText, false), 4000)
  const asks = [{ question: N.TRACE_LABEL, answer: stored, at: R_AT }]
  const think = N.openThink(asks, ASKED_AT, true, true)
  return { isCode, scope, stored, think, shown }
}

/** askNote for words typed under the open line: the plan, and the request when the plan calls the model. */
export function textPlan(model, id, sample, entry, noteAnswer, stored, typed, team) {
  const note = { ...keptNote(model, sample, entry, noteAnswer, team), asks: [{ question: N.TRACE_LABEL, answer: stored, at: R_AT }] }
  return textPlanOfNote(model, id, note, typed, team, ASKED_AT)
}

/** The same for a note as kept (its asks holding r's stored answer), typed at `at` (D34 also feeds a harness's note). */
export function textPlanOfNote(model, id, note, typed, team, at) {
  const shown = shownOf(note, team)
  const masked = N.redactText(typed).text
  const think = N.openThink(shown.asks, at, true, true)
  if (!think) throw new Error(`${id}: line not open`)
  const plan = N.thinkCalcPlan(shown, think, masked, LEVEL, N.thinkVariantOf(model))
  const seen = [shown.text, think.trace, masked, ...shown.changes.map(one => one.diff)].join('\n')
  let req = null
  if (plan.kind === 'check') req = line(id, model, plan.system, plan.prompt, NUMS.THINK_CHECK_TOKENS)
  else if (plan.kind === 'fallback') req = line(id, model, N.ASK_SYSTEM, N.askPrompt(shown, masked, LEVEL, team, undefined, false), NUMS.ASK_TOKENS)
  return { plan, req, masked, seen, shown, think }
}

/** What a text's reply shows the learner (code: no reply; check: thinkCalcReply; fallback: the reply as is). */
export function shownReply(p, text) {
  if (p.plan.kind === 'code') return N.cut(p.plan.text, 4000)
  if (p.plan.kind === 'check') return N.cut(N.thinkCalcReply(text, p.plan.facts, p.masked, p.seen), 4000)
  return N.cut(text, 4000)
}

/** A frozen set: changes.json (+ group/lang as frozen) and the engine-shaped hunks.json, in order. */
export function samplesOf(dir) {
  const changes = readJson(`${dir}/changes.json`)
  const hunks = Object.fromEntries(readJson(`${dir}/hunks.json`).map(one => [one.id, one]))
  return changes.map(sample => ({ sample, entry: hunks[sample.id] }))
}
