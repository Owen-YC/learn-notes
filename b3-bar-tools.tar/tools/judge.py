"""learn-notes 1.13.0 G5 sonnet (batch 3): the judges' reports and verdicts (stance [공통]: per label two fresh sub-agents
that get only the stance text and the report, never each other's verdict, never the model's name; a split is a miss; a
case the stance does not decide is a miss). From impl112/b4/tools/judge.py; the calls run as detached writer-runner
calls (gen/run.sh <root> files json, plan commonPerBatch.writerRunner), not from here. The stance is the frozen text
go/stance-G5.json (sha256 ea8efdb6…59ab, the design's stance as the build commit 5ac71f2 froze it), rendered whole into
every report, section by section, word for word.
  report-a <set> <label>          -> <set>/judge-a-<label>/inputs/a-<label>-J1.md and -J2.md (the same report): every
                                     opened line (in scope and must-open-0) with the line, the walk-through as stored, the
                                     call r was told (anchor) or none, the note text, the '## 바뀐 코드' diffs and the
                                     runner's call and result; each judge marks exposure ([가] 노출) and input ((가)-1
                                     (5)) per line, citing clauses
  report-n <set> <label> <round>  -> <set>/judge-n-<label>-<round>/inputs/n-<label>-<round>-J1.md and -J2.md: every
                                     text with its kind, the line, the runner result, the code, the learner's words and
                                     the shown reply; each judge marks every text ok / miss / undecided by the [나]
                                     clauses of its kind, citing clauses (the machine's expected verdict is not shown)
  collect <root>                  -> <root>/verdicts.json: each judge part's reply read as {"items": [...]} (a reply
                                     with none: every item undecided), chmod 444
Every output chmod 444; refuses to overwrite."""
import hashlib, json, os, re, sys

S = os.environ.get("G5_ROOT", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # G5_ROOT: synthetic tests only
STANCE = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b3/go/stance-G5.json"
STANCE_SHA = "ea8efdb63021b623a4bb7f220575362488bbf265e90da2df3cb0db111e0b59ab"
KIND_KO = {"guess": "짐작", "questionGuess": "물음표 짐작", "blank": "모르겠어요", "question": "질문", "questionYesNo": "질문(예/아니요로 성질을 물음)", "questionNoMark": "질문(물음표 없음)"}


def sha(b):
    return hashlib.sha256(b if isinstance(b, bytes) else b.encode("utf-8")).hexdigest()


def write_once(path, text):
    if os.path.exists(path):
        sys.exit(f"refuse: {path} exists")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w", encoding="utf-8").write(text)
    os.chmod(path, 0o444)
    return sha(text)


def stance_text():
    raw = open(STANCE, "rb").read()
    if sha(raw) != STANCE_SHA:
        sys.exit("the stance file is not the frozen one")
    st = json.loads(raw)
    out = []
    for k, v in st.items():
        out += ["", f"### [{k}]", ""]
        out += [f"- {x}" for x in v] if isinstance(v, list) else [v]
    return "\n".join(out).strip()


def load(p):
    return json.load(open(p, encoding="utf-8"))


def fence(text):
    return "````\n" + text + "\n````"


def report_a(set_name, label):
    d = f"{S}/{set_name}"
    stored, runner = load(f"{d}/stored.json"), load(f"{d}/runner.json")["runner"]
    items = []
    n = 0
    for i, s in stored.items():
        if not s.get("line"):
            continue
        n += 1
        r = runner.get(i)
        res = (r["final"]["text"] if r and r["runner"] else "러너 결과 없음") if r else "러너 결과 없음"
        diffs = "\n\n".join(f"{c['file']} ({c['kind']})\n{c['diff']}" for c in s["changes"])
        items += [f"### {i}", "", f"- 줄(열린 생각해 보기): {s['line']}", f"- r이 따르라고 받은 호출(앵커): {('`' + s['anchor'] + '`') if s.get('anchor') else '없음'}",
                  f"- 러너가 돌린 호출: `{r['call'] if r else ''}` → 최종 결과: {res}", "", "따라가기 글(저장된 그대로, 마지막 줄이 위의 줄):", "", fence(s["stored"]), "", "노트 글:", "", fence(s["noteText"]), "", "## 바뀐 코드:", "", fence(diffs), ""]
    head = f"""# (가) 판정 (꼬리표 {label})

당신은 한 꼬리표의 (가) 보고서를 매기는 채점자입니다. 아래 '입장'의 글자만 따르고, 보고서 밖의 것을 짐작하지 않습니다. 코드를 돌리지 않습니다. 바른 결과는 보고서에 적힌 러너 결과입니다.

열린 줄마다 두 가지를 매깁니다.
- exposure: 입장 [가]의 답 노출 조항(과 S10)에 따라 노출이 없으면 "ok", 있으면 "miss", 입장으로 정해지지 않으면 "undecided".
- input: 입장 [가]와 (가)-1 (5)에 따라 줄의 호출이 따라가기의 예시 입력과 다른 입력이면 "ok"(결과가 같아도 됨), 같은 입력이면 "miss", 정해지지 않으면 "undecided".
항목마다 근거 조항(예: "[가] 답 노출", "S10", "(가)-1 (5)")과 한두 문장의 까닭을 적습니다.

## 입장

{stance_text()}

## 보고서 ({n}줄)
"""
    tail = """
## 답의 꼴

```json 울타리 안에 이 꼴의 JSON 하나만 적으세요. 다른 말은 쓰지 않습니다. 보고서의 줄마다 항목 하나씩입니다.

{"items": [{"id": "…", "exposure": "ok", "input": "ok", "clauses": ["…"], "why": "…"}]}
"""
    body = head + "\n" + "\n".join(items) + tail
    root = f"{d}/judge-a-{label}"
    print(json.dumps({"items": n, "J1": write_once(f"{root}/inputs/a-{label}-J1.md", body), "J2": write_once(f"{root}/inputs/a-{label}-J2.md", body)}))


def report_n(set_name, label, rnd):
    d = f"{S}/{set_name}"
    qs = {q["q"]: q for q in load(f"{d}/questions-{label}.json")["questions"]}
    stored = load(f"{d}/stored.json")
    texts = load(f"{d}/texts-{label}.json")["texts"]
    shown = load(f"{d}/read-{label}-{rnd}.json")
    parts = []
    for qn, q in qs.items():
        s = stored[q["sid"]]
        diffs = "\n\n".join(f"{c['file']} ({c['kind']})\n{c['diff']}" for c in s["changes"])
        parts += [f"## {qn}", "", f"- 생각해 보기 물음: {q['line']}", f"- 러너 결과(바른 결과): {q['result']}", "", "## 바뀐 코드:", "", fence(diffs), ""]
        for t in texts:
            if t["q"] != qn:
                continue
            row = shown[t["id"]]
            kind = KIND_KO[t["kind"]] + (" (물음표 꼴)" if t.get("mark") == "?" and t["kind"] == "guess" else "")
            parts += [f"### {t['id']}", "", f"- 종류: {kind}", f"- 학습자의 글: {t['text']}", "- 보인 글:", "",
                      fence(row["shown"]) if row["answered"] else "(답 없음: 빈 답 · 시간 한도 · 전송 실패, 입장 [공통]대로 놓침)", ""]
    head = f"""# (나) 판정 (꼬리표 {label}, 회 {rnd})

당신은 한 꼬리표의 (나) 한 회 보고서를 매기는 채점자입니다. 아래 '입장'의 글자만 따르고, 보고서 밖의 것을 짐작하지 않습니다. 코드를 돌리지 않습니다. 바른 결과는 보고서에 적힌 러너 결과입니다(돌려주는 값은 그 값, 오류로 끝남은 그 오류).

글마다 입장 [나]의 그 종류 기준(짐작 (a)~(g), 모르겠어요, 질문 (a)~(d), 물음표 꼴 짐작은 [나]가 정한 대로)을 모두 보고, 모두 만족하면 "ok", 하나라도 어기면 "miss", 입장으로 정해지지 않으면 "undecided"를 적습니다. 짐작의 (a)는 학습자의 짐작이 러너 결과와 [같음]으로 같은지로 정한 기대 판정과 보인 머리를 견줍니다. 어긴 기준(예: "(b)")과 근거 조항, 한두 문장의 까닭을 적습니다.

## 입장

{stance_text()}

# 보고서 ({len(texts)}글)
"""
    tail = """
## 답의 꼴

```json 울타리 안에 이 꼴의 JSON 하나만 적으세요. 다른 말은 쓰지 않습니다. 보고서의 글마다 항목 하나씩입니다.

{"items": [{"id": "…", "verdict": "ok", "failed": [], "clauses": ["…"], "why": "…"}]}
"""
    body = head + "\n" + "\n".join(parts) + tail
    root = f"{d}/judge-n-{label}-{rnd}"
    print(json.dumps({"items": len(texts), "J1": write_once(f"{root}/inputs/n-{label}-{rnd}-J1.md", body), "J2": write_once(f"{root}/inputs/n-{label}-{rnd}-J2.md", body)}))


def read_items(text):
    blocks = re.findall(r"```json[ \t]*\n(.*?)\n```", text, re.S)
    for cand in blocks + [text]:
        try:
            v = json.loads(cand)
        except Exception:
            continue
        if isinstance(v, dict) and isinstance(v.get("items"), list):
            return v["items"]
    return None


def collect(root):
    out = {}
    for name in sorted(os.listdir(f"{root}/inputs")):
        part = name[:-3]
        text = None
        for t in range(9, 0, -1):
            p = f"{root}/parts/{part}-{t}"
            if os.path.exists(f"{p}/reply.json") and not os.path.exists(f"{p}/VOIDED"):
                text = json.load(open(f"{p}/reply.json", encoding="utf-8"))["text"]
                break
        items = read_items(text) if text is not None else None
        out[part] = {"readable": items is not None, "items": {str(it.get("id")): it for it in (items or []) if isinstance(it, dict)}}
    print(json.dumps({"parts": {k: {"readable": v["readable"], "items": len(v["items"])} for k, v in out.items()}, "sha256": write_once(f"{root}/verdicts.json", json.dumps(out, ensure_ascii=False, indent=1) + "\n")}))


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "report-a":
        report_a(sys.argv[2], sys.argv[3])
    elif mode == "report-n":
        report_n(sys.argv[2], sys.argv[3], sys.argv[4])
    elif mode == "collect":
        collect(sys.argv[2])
    else:
        sys.exit("usage: judge.py report-a <set> <label> | report-n <set> <label> <round> | collect <root>")
