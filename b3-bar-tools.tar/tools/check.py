"""learn-notes 1.13.0 G5 sonnet (batch 3): the GO gate's PH freeze check (no model call, no plugin code, no calc code;
plan batches[3].preBarGate with samples.layoutA's static checks and replacement rule, as the build commit 5ac71f2 fixed
them in 견본.md before any PH record existed).
usage: check.py <samples root> <frozen dir>     env TOPUPS (a JSON list of top-up roots, default none), NAMESALL (default
       impl113/NAMES-all.txt), CORPUS_GLOBS (JSON list)
Reads <samples root>/raw.json (gen/parts.py assemble) and each top-up root's reply. Never edits a record.
Slots (fixed before writing; gen/writer-I.md, writer-O.md): in-scope PH01 js edit · PH02 js new · PH03 ts edit · PH04 py
  edit · PH05 py new · PH06 js+js · PH07 py+md · PH08 ts+json, spares PH13 js edit · PH14 py edit; must-open-0 PH09
  class-method ts · PH10 async js · PH11 random-time py · PH12 helper-other-file js, spares PH15-PH18 of the same kinds.
Record checks (a failing record is left out, never mended):
  (1) the record form: id, group, lang as its slot, kind and request and answer non-empty strings, files a non-empty
      list of {path (relative, no '..'), before (string or null), after (string)}, each text ending in exactly one
      newline, an edit's before different from its after; a must-open-0 record's nearMiss its slot's label ((6)).
  (2) engine-shaped: tools/prep.py's hunks of each edited file (difflib, three lines of context) applied to its before
      give its after; a new file is one creation (content = after).
  (3) language and file mix: the slot's languages by file extension in order (js .js · ts .ts · py .py · md .md ·
      json .json), one file for a single-file slot, two for a two-file slot; the slot's new file / edit where it names one
      (PH01 PH03 PH04 PH13 PH14 and every must-open-0 slot: edits; PH02 PH05: new files).
  (5) names: each file path, file name (last part) and defined code name (js `function f`, `const f = (…) =>` /
      `function`, `class C`; py `def f`, `class C`; 3+ characters) not an entry of NAMESALL (the first column, all
      rows), not a file name or path of the overlap corpora (every 'path' / 'file' value with a slash in the JSON record
      files under CORPUS_GLOBS; and every defined code name in their 'after' / 'content' / 'code' texts), and not used by
      an earlier record of this set (written order: PH-I, PH-O, then the top-ups). Concept names: the G5 records carry
      none (no concept field), so the concept part of (5) has nothing to compare (recorded).
Replacement: a failing in-scope slot takes the first passing unused spare of its sub-kind in id order (sub-kind = the
  first file's language and single/two-file: PH13 js single, PH14 py single); a failing must-open-0 slot the spare of its
  own kind (PH15 for PH09, PH16 PH10, PH17 PH11, PH18 PH12). Spares are never measured unless they replace a slot.
(4) quotas on the final in-scope 8 (each class at least once; counted from the after texts of the code files, by these
  fixed definitions, independent of notes.ts): rounding (`Math.round(`, `.toFixed(`, py `round(`, or a format precision
  `:.<digits>f`/`:.<digits>` in a py f-string or format call); tuple unpacking / destructuring (py `a, b = …` or
  `for a, b in`, js/ts `const|let|var {…} =` / `[…] =`, or a destructured parameter `({` / `([`); py keyword-argument
  caller (a py line at column 0, not a def/class, calling a function defined in that record with `name=value`); module-
  level list/dict read (a column-0 assignment of a `[` or `{` literal, js/ts with const/let/var, whose name appears on an
  indented line); new file (a file with before null); edit (a file with before not null); literal caller (a column-0
  line, not a definition, calling a function defined in that record whose arguments, keyword names and strings taken
  out, hold no other name than true/false/null/undefined/True/False/None).
Unmet: a slot with no passing record or a quota short after the spares -> 'TOPUP I' / 'TOPUP O' (exit 3) and
  <samples root>/topup-need.json names the slots to write (a quota short names its first carrier slot: rounding PH01,
  destructuring PH03, keyword caller PH04, module-level read PH02, new file PH02, edit PH01, literal caller PH01; the
  top-up record then replaces that slot's record). With its top-up given and still unmet -> 'STOP' (exit 6): the gate is
  not run and counts as NO-GO (recorded). Otherwise frozen (exit 0): <frozen dir>/changes.json (the 12 in slot order,
  each with 'slot'), hunks.json (tools/prep.py), check.json, NAMES.txt (id, files, defined names), raw.json, all
  chmod 444."""
import glob, hashlib, json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.dirname(HERE)
SP = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad"
NAMES = os.environ.get("NAMESALL", f"{SP}/impl113/NAMES-all.txt")
TOPUPS = json.loads(os.environ.get("TOPUPS", "[]"))
CORPUS_GLOBS = [f"{SP}/impl113/design/*/dev/**/*.json", f"{SP}/impl113/design/*/pilot/**/*.json", f"{SP}/impl113/b*/frozen/**/*.json",
                f"{SP}/impl112/design/*/dev/**/*.json", f"{SP}/impl112/b1/frozen/**/*.json", f"{SP}/impl112/b2/frozen/**/*.json",
                f"{SP}/impl112/b3r/frozen/**/*.json", f"{SP}/impl112/b3r/dev/**/*.json", f"{SP}/impl112/b4/frozen/**/*.json",
                f"{SP}/impl112/b4/go/frozen/**/*.json"]
if os.environ.get("CORPUS_GLOBS"):
    CORPUS_GLOBS = json.loads(os.environ["CORPUS_GLOBS"])
SLOTS = {"PH01": ("in", "js", "edit"), "PH02": ("in", "js", "new"), "PH03": ("in", "ts", "edit"), "PH04": ("in", "py", "edit"),
         "PH05": ("in", "py", "new"), "PH06": ("in", "js+js", None), "PH07": ("in", "py+md", None), "PH08": ("in", "ts+json", None),
         "PH09": ("out", "ts", "edit"), "PH10": ("out", "js", "edit"), "PH11": ("out", "py", "edit"), "PH12": ("out", "js", "edit")}
SPARES = {"PH13": ("in", "js", "edit"), "PH14": ("in", "py", "edit"), "PH15": ("out", "ts", "edit"), "PH16": ("out", "js", "edit"),
          "PH17": ("out", "py", "edit"), "PH18": ("out", "js", "edit")}
NEAR = {"PH09": "class-method", "PH10": "async", "PH11": "random-time", "PH12": "helper-other-file",
        "PH15": "class-method", "PH16": "async", "PH17": "random-time", "PH18": "helper-other-file"}
OUT_SPARE = {"PH09": "PH15", "PH10": "PH16", "PH11": "PH17", "PH12": "PH18"}
IN_SLOTS = [k for k, v in SLOTS.items() if v[0] == "in"]
OUT_SLOTS = [k for k, v in SLOTS.items() if v[0] == "out"]
QUOTAS = ["rounding", "destructuring", "pyKeywordCaller", "moduleLevelRead", "newFile", "edit", "literalCaller"]
CARRIER = {"rounding": "PH01", "destructuring": "PH03", "pyKeywordCaller": "PH04", "moduleLevelRead": "PH02", "newFile": "PH02", "edit": "PH01", "literalCaller": "PH01"}
EXT = {"js": ".js", "ts": ".ts", "py": ".py", "md": ".md", "json": ".json"}
JS_DEF = re.compile(r"\bfunction\s*\*?\s*([A-Za-z_$][\w$]*)|\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*(?::[^=]+)?=\s*(?:async\s+)?(?:function\b|\([^)]*\)\s*(?::[^=]+)?=>|[A-Za-z_$][\w$]*\s*=>)|\bclass\s+([A-Za-z_$][\w$]*)")
PY_DEF = re.compile(r"^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)|^\s*class\s+([A-Za-z_]\w*)", re.M)
FILE_RX = re.compile(r"^[\w./@-]+\.(js|mjs|cjs|ts|mts|cts|tsx|jsx|py|json|md|css|scss|html|go|rb|sh|vue|txt|yml|yaml|toml)$")
sha = lambda t: hashlib.sha256(t.encode("utf-8")).hexdigest()
sys.path.insert(0, HERE)
import prep  # noqa: E402


def code_files(rec):
    return [f for f in rec.get("files", []) if isinstance(f, dict) and re.search(r"\.(m?[jt]s|py)$", f.get("path", ""))]


def defs(rec):
    out = set()
    for f in code_files(rec):
        t = f.get("after") or ""
        if f["path"].endswith(".py"):
            out |= {a or b for a, b in PY_DEF.findall(t)}
        else:
            out |= {next(g for g in m if g) for m in JS_DEF.findall(t)}
    return sorted(n for n in out if len(n) >= 3)


def corpus():
    files = set()
    for g in CORPUS_GLOBS:
        for f in glob.glob(g, recursive=True):
            if os.path.getsize(f) <= 30_000_000:
                files.add(f)
    paths, names = set(), set()

    def walk(v):
        if isinstance(v, dict):
            for k, x in v.items():
                if k in ("path", "file") and isinstance(x, str) and "/" in x and "\n" not in x and len(x) < 200:
                    paths.add(x.lstrip("/").removeprefix("proj/"))
                if k in ("after", "content", "code") and isinstance(x, str) and "\n" in x:
                    names.update(a or b for a, b in PY_DEF.findall(x))
                    names.update(next(g for g in m if g) for m in JS_DEF.findall(x))
                walk(x)
        elif isinstance(v, list):
            for x in v:
                walk(x)
    for f in sorted(files):
        try:
            walk(json.load(open(f, encoding="utf-8")))
        except Exception:
            pass
    return paths, {n for n in names if n and len(n) >= 3}, len(files)


def apply_hunks(before, hunks):
    a = before.split("\n")
    out, i = [], 0
    for h in hunks:
        start = h["oldStart"] - 1 if h["oldLines"] else h["oldStart"]
        out += a[i:start]
        i = start
        for line in h["lines"]:
            if line.startswith(" "):
                out.append(a[i])
                i += 1
            elif line.startswith("-"):
                i += 1
            elif line.startswith("+"):
                out.append(line[1:])
    out += a[i:]
    return "\n".join(out)


def form_bad(rec, spec, near=None):
    g, lang, kind = spec
    bad = []
    if rec.get("group") != g:
        bad.append(f"group {rec.get('group')}")
    if rec.get("lang") != lang:
        bad.append(f"lang {rec.get('lang')}")
    for k in ("kind", "request", "answer"):
        if not isinstance(rec.get(k), str) or not rec[k].strip():
            bad.append(k)
    fs = rec.get("files")
    if not isinstance(fs, list) or not fs:
        return bad + ["files"]
    for f in fs:
        p = f.get("path") if isinstance(f, dict) else None
        if not isinstance(p, str) or not p or p.startswith("/") or ".." in p.split("/"):
            bad.append(f"path {p}")
            continue
        a = f.get("after")
        if not isinstance(a, str) or not a.endswith("\n") or a.endswith("\n\n"):
            bad.append(f"{p} after end")
        b = f.get("before")
        if b is not None and (not isinstance(b, str) or not b.endswith("\n")):
            bad.append(f"{p} before end")
        if b is not None and b == a:
            bad.append(f"{p} unchanged")
    if g == "out" and rec.get("nearMiss") != near:
        bad.append(f"nearMiss {rec.get('nearMiss')}")
    return bad


def mix_bad(rec, spec):
    g, lang, kind = spec
    fs = rec.get("files") or []
    want = lang.split("+")
    got = [os.path.splitext(f.get("path", ""))[1] for f in fs if isinstance(f, dict)]
    bad = []
    if got != [EXT[x] for x in want]:
        bad.append(f"files {got} for {lang}")
    if kind == "edit" and any(f.get("before") is None for f in fs if isinstance(f, dict)):
        bad.append("not an edit")
    if kind == "new" and any(f.get("before") is not None for f in fs if isinstance(f, dict)):
        bad.append("not a new file")
    return bad


def engine_bad(rec):
    bad = []
    try:
        entry = prep.prep([{"id": rec["id"], "files": rec["files"]}])[0]
    except Exception as e:
        return [f"prep {e}"]
    for f, e in zip(rec["files"], entry["files"]):
        if e["kind"] == "create":
            if e["content"] != f["after"]:
                bad.append(f"{f['path']} creation")
        elif apply_hunks(f["before"], e["hunks"]) != f["after"]:
            bad.append(f"{f['path']} hunks do not give the after file")
    return bad


def quotas(rec):
    got = set()
    names = defs(rec)
    for f in rec.get("files", []):
        if f.get("before") is None:
            got.add("newFile")
        else:
            got.add("edit")
    for f in code_files(rec):
        t, py = f["after"], f["path"].endswith(".py")
        if re.search(r"Math\.round\s*\(|\.toFixed\s*\(", t) or (py and (re.search(r"(?<![\w.])round\s*\(", t) or re.search(r"\{[^{}\n]*:[^{}\n]*\.\d+f?\}", t) or re.search(r"['\"][^'\"\n]*\{[^{}\n]*:\.\d+f?\}", t))):
            got.add("rounding")
        if (py and (re.search(r"^\s*[A-Za-z_]\w*\s*,\s*[A-Za-z_][\w\s,]*=(?!=)", t, re.M) or re.search(r"\bfor\s+[A-Za-z_]\w*\s*,\s*[A-Za-z_]", t))) or \
           (not py and (re.search(r"\b(?:const|let|var)\s*[\[{]", t) or re.search(r"\(\s*[\[{]", t) and re.search(r"(?:function\s*\w*|=>|\w)\s*\(\s*[\[{][^)]*[\]}]\s*(?::[^)]*)?\)", t))):
            got.add("destructuring")
        lines = t.split("\n")
        for i, line in enumerate(lines):
            if line[:1].strip() and not re.match(r"^(?:export\s+)?(?:async\s+)?(?:function|def|class)\b", line):
                for n in names:
                    for m in re.finditer(rf"(?<![\w$.]){re.escape(n)}\s*\(", line):
                        depth, j = 1, m.end()
                        while j < len(line) and depth:
                            depth += {"(": 1, ")": -1}.get(line[j], 0)
                            j += 1
                        args = line[m.end(): j - 1]
                        if py and re.search(r"(?<![=!<>])\b[A-Za-z_]\w*\s*=(?!=)", args):
                            got.add("pyKeywordCaller")
                        bare = re.sub(r"(['\"])(?:\\.|(?!\1).)*\1", "", args)
                        bare = re.sub(r"\b[A-Za-z_]\w*\s*=(?!=)", "", bare)
                        left = set(re.findall(r"[A-Za-z_$][\w$]*", bare)) - {"true", "false", "null", "undefined", "True", "False", "None"}
                        if not left:
                            got.add("literalCaller")
            m = re.match(r"^(?:export\s+)?(?:(?:const|let|var)\s+)?([A-Za-z_$][\w$]*)\s*(?::[^=]+)?=\s*[\[{]", line) if (not py and re.match(r"^(?:export\s+)?(?:const|let|var)\s", line)) or (py and not line.startswith(" ")) else None
            if m and any(l[:1] in (" ", "\t") and re.search(rf"(?<![\w$.]){re.escape(m.group(1))}(?![\w$])", l) for l in lines):
                got.add("moduleLevelRead")
    return sorted(got)


def load_rows(root):
    rows = json.load(open(f"{root}/raw.json", encoding="utf-8"))
    return rows


def topup_rows(root):
    for t in range(9, 0, -1):
        for d in sorted(glob.glob(f"{root}/parts/TU-*-{t}")):
            if os.path.exists(f"{d}/reply.json") and not os.path.exists(f"{d}/VOIDED"):
                part = os.path.basename(d).rsplit("-", 1)[0]
                ids = json.load(open(re.sub(r"-\d+$", "-1", d) + "/ids.json"))
                return part, ids, json.load(open(f"{d}/reply.json", encoding="utf-8"))
    return None


def main(root, frozen):
    if os.path.exists(f"{frozen}/changes.json"):
        sys.exit(f"refuse: {frozen}/changes.json exists")
    rows = load_rows(root)
    tops = []
    for t in TOPUPS:
        got = topup_rows(t)
        if got:
            tops.append(got)
    need_prev = json.load(open(f"{root}/topup-need.json")) if os.path.exists(f"{root}/topup-need.json") else {}
    reg = set(l.split("\t", 1)[0].strip() for l in open(NAMES, encoding="utf-8") if l.strip())
    cpaths, cnames, ncorpus = corpus()
    cfiles = {p.rsplit("/", 1)[-1] for p in cpaths}
    seen_paths, seen_names = set(), set()
    report, ok = {}, {}
    spec_of = dict(SLOTS, **SPARES)
    top_spec = {}
    for part, ids, recs in tops:
        slots = need_prev.get(part, [])
        for k, i in enumerate(ids):
            top_spec[i] = (spec_of[slots[k // 2]], slots[k // 2])
    written = [r for r in rows] + [r for _, _, recs in tops for r in recs]
    for r in written:
        i = r.get("id")
        spec = spec_of.get(i) or (top_spec.get(i, (None,))[0])
        if spec is None:
            report[i] = {"bad": ["unknown id"]}
            continue
        bad = form_bad(r, spec, NEAR.get(top_spec[i][1] if i in top_spec else i))
        if not bad:
            bad += mix_bad(r, spec) + engine_bad(r)
        files = [f["path"] for f in r.get("files", []) if isinstance(f, dict) and isinstance(f.get("path"), str)]
        names = defs(r) if not bad or "files" not in bad else []
        hits = []
        for p in files:
            base = p.rsplit("/", 1)[-1]
            if p in reg or base in reg:
                hits.append(f"registry {p}")
            if p in cpaths or base in cfiles:
                hits.append(f"corpus file {p}")
            if p in seen_paths or base in {x.rsplit('/', 1)[-1] for x in seen_paths}:
                hits.append(f"set file {p}")
        for n in names:
            if n in reg:
                hits.append(f"registry name {n}")
            if n in cnames:
                hits.append(f"corpus name {n}")
            if n in seen_names:
                hits.append(f"set name {n}")
        bad += hits
        seen_paths.update(files)
        seen_names.update(names)
        report[i] = {"bad": bad, "files": files, "names": names, "quotas": quotas(r) if spec[0] == "in" and not bad else []}
        if not bad:
            ok[i] = r
    final, used, filled = {}, set(), {}
    for s in IN_SLOTS + OUT_SLOTS:
        if s in ok:
            final[s] = s
    for s in IN_SLOTS:
        if s in final:
            continue
        sub = (SLOTS[s][1].split("+")[0], "+" in SLOTS[s][1])
        for sp in ("PH13", "PH14"):
            if sp in ok and sp not in used and (SPARES[sp][1].split("+")[0], "+" in SPARES[sp][1]) == sub and (SLOTS[s][2] is None or SPARES[sp][2] == SLOTS[s][2] or SLOTS[s][2] == "edit"):
                final[s] = sp
                used.add(sp)
                break
    for s in OUT_SLOTS:
        if s not in final and OUT_SPARE[s] in ok:
            final[s] = OUT_SPARE[s]
    for i, (spec, slot) in top_spec.items():
        # a top-up record (written for a slot topup-need.json named) replaces that slot's record; the slot's second
        # top-up record is its spare
        if i in ok and slot not in filled:
            final[slot] = i
            filled[slot] = i
    q = {k: [s for s in IN_SLOTS if s in final and k in report[final[s]]["quotas"]] for k in QUOTAS}
    short = [k for k in QUOTAS if not q[k]]
    missing_in = [s for s in IN_SLOTS if s not in final]
    missing_out = [s for s in OUT_SLOTS if s not in final]
    need = {"TU-I": sorted(set(missing_in + [CARRIER[k] for k in short])), "TU-O": missing_out}
    chk = {"records": len(written), "report": report, "final": final, "quotas": q, "short": short, "need": need,
           "corpusFiles": ncorpus, "corpusPaths": len(cpaths), "corpusNames": len(cnames), "namesAllSha256": sha(open(NAMES, encoding="utf-8").read()),
           "concepts": "the G5 records carry no concept field: nothing to compare", "topups": [t[0] for t in tops]}
    if need["TU-I"] or need["TU-O"]:
        given = {t[0] for t in tops}
        if any(k in given for k, v in need.items() if v) or need_prev:
            os.makedirs(frozen, exist_ok=True)
            open(f"{frozen}/check-stop.json", "w").write(json.dumps(chk, ensure_ascii=False, indent=1) + "\n")
            print("STOP: unmet after the top-up", json.dumps(need))
            sys.exit(6)
        open(f"{root}/topup-need.json", "w").write(json.dumps(need) + "\n")
        open(f"{root}/check-topup.json", "w").write(json.dumps(chk, ensure_ascii=False, indent=1) + "\n")
        for k, v in need.items():
            if v:
                print(f"TOPUP {k[3:]}", v)
        sys.exit(3)
    os.makedirs(frozen, exist_ok=True)
    changes = []
    for s in IN_SLOTS + OUT_SLOTS:
        r = dict(ok[final[s]])
        r["slot"] = s
        changes.append(r)
    out = {}
    raw = json.dumps({"rows": written}, ensure_ascii=False, indent=1) + "\n"
    open(f"{frozen}/raw.json", "w", encoding="utf-8").write(raw)
    ch = json.dumps(changes, ensure_ascii=False, indent=1) + "\n"
    open(f"{frozen}/changes.json", "w", encoding="utf-8").write(ch)
    out["changes"] = sha(ch)
    h = subprocess.run(["python3", "-I", f"{HERE}/prep.py", f"{frozen}/changes.json", f"{frozen}/hunks.json"], capture_output=True, text=True, check=True)
    out["hunks"] = json.loads(h.stdout)["sha256"]
    names_txt = "\n".join(f"{r['id']}\tfiles: {' '.join(report[r['id']]['files'])}\tnames: {' '.join(report[r['id']]['names'])}" for r in changes) + "\n"
    open(f"{frozen}/NAMES.txt", "w", encoding="utf-8").write(names_txt)
    chk["sha256"] = out
    cj = json.dumps(chk, ensure_ascii=False, indent=1) + "\n"
    open(f"{frozen}/check.json", "w", encoding="utf-8").write(cj)
    for n in ("raw.json", "changes.json", "hunks.json", "NAMES.txt", "check.json"):
        os.chmod(f"{frozen}/{n}", 0o444)
    print(json.dumps({"frozen": frozen, "final": final, "quotas": {k: len(v) for k, v in q.items()}, "sha256": {**out, "check": sha(cj)}}, ensure_ascii=False))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
