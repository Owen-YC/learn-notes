"""learn-notes 1.13.0 G5 sonnet (batch 3): the independent [같음] and the mechanical (나) checks (design bar.scoring and
stance [공통] 4: every mechanical verdict comes from measurement tools that never import notes.ts). Pure Python, no
model call, no plugin code. It reads values in code notation (py and js literals) and in a learner's words, and decides
'same' / 'diff' / None (cannot read: the label check or the judges decide) by the frozen stance's [같음] clauses:
  [같음] 1  white space outside quotes, the quote kind, a final period, particles and '약 · 쯤' are matched away
  [같음] 2  digit grouping (14000 = 14,000) and trailing decimal zeros (97.5 = 97.50) are the same
  S18       py int and float differ (600 != 600.0, 4.0 != 4); js has one number kind (4 = 4.0); 7 != "7"; py list != tuple
  S18b      a number result: unit words after the number are dropped (14,000원 = 14000, 25% = 25); a string result: an
            unquoted number or truth word (12.6, 7, true) differs from the string "12.6"; a text with unit words (5개,
            14,000원, 25%) or an unquoted word (A, B) is the same when its characters equal the string's content (the
            space between number and unit not looked at; commas looked at)
  [같음] 5  characters, case and spaces inside a string count
  [같음] 6  빈 배열 = [], 빈 문자열 = "", 참 = true, 거짓 = false; py None = js null; js undefined != null; dict keys unordered
  [같음] 7  an error word (에러 · 오류 · 예외 · 멈춤 · 터짐) is the same as any error; a named error must be that name (S4);
            a value against an error result differs, an error against a value result differs
  [같음] 8  py None = '아무것도 돌려주지 않음'; js undefined differs from '아무것도 출력되지 않음'
  [같음] 9  a NaN or Infinity guess differs from a number result
  S29       a text naming two or more values: the last one claimed is the guess
Runner results are the runner's output line: 'RETURN <py repr | js JSON.stringify ?? String>' or 'ERROR <name>'.
Also: head(shown) (the plugin's verdict head words), sentences(shown) ([(나)] (e)), labelled(shown) ((g)), think(shown)
((d)), shown_values(shown) (S13 · S20: '바른 결과', '`call`를 실행하면 … `v`', '- `식`의 값: `v`').
usage (self test): same.py test"""
import json, math, re, sys

UNIT = r"(?:원|개|초|분|시간|점|명|번|살|cm|km|m|kg|g|ml|L|%|달러|권|장|마리|잔|일|주|개월|년|층|칸|줄|자|글자|배|도|퍼센트)"
PARTICLE = r"(?:이에요|예요|이요|요|입니다|이다|이고|이며|이면|이|가|은|는|을|를|으로|로|과|와|도|만|이나|나|일까|인가|일 것|일걸|이죠|죠|네요|겠죠|이겠죠|일 거예요|일 겁니다|이 나와요|가 나와요|이 나올 것|가 나올 것|이 될 것|가 될 것|이 돼요|가 돼요)"
ERROR_WORD = re.compile(r"(오류|에러|예외|멈[춰추췄출]|멈춤|터[져지짐졌]|터짐|(?:Error|Exception)(?![A-Za-z]))")
ERROR_NAME = re.compile(r"(?<![A-Za-z])([A-Z][A-Za-z]*(?:Error|Exception))(?![A-Za-z])")
KOR = {"빈 배열": ("list", ()), "빈 목록": ("list", ()), "빈 리스트": ("list", ()), "빈 문자열": ("str", ""), "빈 글자": ("str", ""),
       "참": ("bool", True), "거짓": ("bool", False), "빈 객체": ("dict", ()), "빈 사전": ("dict", ()), "빈 튜플": ("tuple", ())}
NONE_WORDS = re.compile(r"(아무것도 (돌려주지|반환하지) 않|돌려주는 (것|값)(이)? 없|반환(값)?(이)? 없|None)")


class P:
    """A small literal parser: numbers, strings, true/false/null/undefined/None/True/False, NaN, Infinity, [..], (..), {..}."""

    def __init__(self, s, lang):
        self.s, self.i, self.lang = s, 0, lang

    def ws(self):
        while self.i < len(self.s) and self.s[self.i] in " \t\n":
            self.i += 1

    def value(self):
        self.ws()
        if self.i >= len(self.s):
            raise ValueError("end")
        c = self.s[self.i]
        if c in "\"'`":
            return self.string(c)
        if c == "[":
            return ("list", self.seq("]"))
        if c == "(":
            items, comma = self.seq(")", tup=True)
            if len(items) == 1 and not comma:
                return items[0]
            return ("tuple", items)
        if c == "{":
            return self.obj()
        m = re.compile(r"-?(?:\d[\d_]*\.?\d*(?:[eE][-+]?\d+)?|\.\d+(?:[eE][-+]?\d+)?)").match(self.s, self.i)
        if m and m.group(0) not in ("-", ""):
            self.i = m.end()
            t = m.group(0).replace("_", "")
            if self.lang == "py" and not re.search(r"[.eE]", t):
                return ("int", int(t))
            if self.lang == "py":
                return ("float", float(t))
            return ("num", float(t))
        m = re.compile(r"-?[A-Za-z_$][\w$]*").match(self.s, self.i)
        if m:
            w = m.group(0)
            self.i = m.end()
            table = {"true": ("bool", True), "True": ("bool", True), "false": ("bool", False), "False": ("bool", False),
                     "null": ("null",), "None": ("null",), "undefined": ("undefined",), "NaN": ("nan",), "nan": ("nan",),
                     "Infinity": ("inf", 1), "-Infinity": ("inf", -1), "inf": ("inf", 1), "-inf": ("inf", -1)}
            if w in table:
                return table[w]
            raise ValueError("word " + w)
        raise ValueError("char " + c)

    def string(self, q):
        j = self.i + 1
        out = []
        while j < len(self.s):
            c = self.s[j]
            if c == "\\" and j + 1 < len(self.s):
                n = self.s[j + 1]
                out.append({"n": "\n", "t": "\t", "\\": "\\", "'": "'", '"': '"', "`": "`", "r": "\r", "0": "\0"}.get(n, "\\" + n))
                j += 2
                continue
            if c == q:
                self.i = j + 1
                return ("str", "".join(out))
            out.append(c)
            j += 1
        raise ValueError("open string")

    def seq(self, end, tup=False):
        self.i += 1
        items, comma = [], False
        while True:
            self.ws()
            if self.i < len(self.s) and self.s[self.i] == end:
                self.i += 1
                return (tuple(items), comma) if tup else tuple(items)
            items.append(self.value())
            self.ws()
            if self.i < len(self.s) and self.s[self.i] == ",":
                comma = True
                self.i += 1
                continue
            self.ws()
            if self.i < len(self.s) and self.s[self.i] == end:
                self.i += 1
                return (tuple(items), comma) if tup else tuple(items)
            raise ValueError("seq")

    def obj(self):
        self.i += 1
        pairs = []
        while True:
            self.ws()
            if self.i < len(self.s) and self.s[self.i] == "}":
                self.i += 1
                return ("dict", tuple(sorted(pairs, key=repr)))
            m = re.compile(r"[A-Za-z_$][\w$]*").match(self.s, self.i)
            if m and self.lang != "py":
                k = ("str", m.group(0))
                self.i = m.end()
            else:
                k = self.value()
            self.ws()
            if self.i >= len(self.s) or self.s[self.i] != ":":
                raise ValueError("colon")
            self.i += 1
            v = self.value()
            pairs.append((k, v))
            self.ws()
            if self.i < len(self.s) and self.s[self.i] == ",":
                self.i += 1


def literal(s, lang):
    """The whole of s as one literal, or None."""
    try:
        p = P(s.strip(), lang)
        v = p.value()
        p.ws()
        return v if p.i == len(p.s) else None
    except Exception:
        return None


def norm(v, lang):
    """One comparable form per [같음]: js numbers one kind; py int and float kept apart (S18)."""
    k = v[0]
    if k in ("int", "float", "num"):
        x = v[1]
        if lang != "py":
            return ("num", float(x))
        return v
    if k in ("list", "tuple"):
        return (k, tuple(norm(x, lang) for x in v[1]))
    if k == "dict":
        return ("dict", tuple(sorted(((norm(a, lang), norm(b, lang)) for a, b in v[1]), key=repr)))
    return v


def result_of(out, lang):
    """The runner's output line as ('error', name) | ('none',) | a value; None when it cannot be read."""
    kind, _, rest = out.partition(" ")
    if kind == "ERROR":
        return ("error", rest)
    if lang == "py" and rest == "None":
        return ("none",)
    if lang != "py" and rest == "undefined":
        return ("undefined",)
    v = literal(rest, lang)
    return norm(v, lang) if v is not None else None


def num_eq(a, b, lang):
    if a[0] != b[0]:
        return False
    return a[1] == b[1]


def eq(a, b, lang):
    """Two normalised values ([같음] 4 · 6 · S18)."""
    if a[0] in ("null",) and b[0] in ("null", "none"):
        return True
    if a[0] == "none" and b[0] in ("null", "none"):
        return True
    if a[0] != b[0]:
        return False
    if a[0] in ("int", "float", "num"):
        return num_eq(a, b, lang)
    if a[0] in ("list", "tuple"):
        return len(a[1]) == len(b[1]) and all(eq(x, y, lang) for x, y in zip(a[1], b[1]))
    if a[0] == "dict":
        return len(a[1]) == len(b[1]) and all(eq(x[0], y[0], lang) and eq(x[1], y[1], lang) for x, y in zip(a[1], b[1]))
    return a == b


def strip_words(t):
    t = t.strip()
    t = re.sub(r"^(?:답은|결과는|아마|제 생각엔|제 생각에는|음,?|그럼)\s*", "", t)
    t = re.sub(r"^(?:약|쯤|대략)\s*", "", t)
    t = re.sub(r"[.!?。~]+$", "", t).strip()
    for _ in range(3):
        t = re.sub(r"\s*(?:이|가)?\s*(?:나오나요|되나요|맞나요|맞아요|인가요|일까요|나와요|돼요)$", "", t).strip()
        t = re.sub(r"\s*(?:일|이|가)?\s*(?:것|거)\s*같아요$|\s*(?:나올|될)\s*(?:것|거)\s*같아요$|\s*(?:이|가)\s*(?:나와요|나올 거예요|돼요|될 거예요)$|\s*(?:나와요|돼요|입니다|이에요|예요|이요|요|쯤|정도)$", "", t).strip()
    t = re.sub(r"\s*(?:쯤|정도)$", "", t).strip()
    return t


def guess_of(text, lang, result):
    """A learner's guess (or a writer's claim) as one comparable value, ('error', name|None), ('none',), or None
    (cannot read: a description, several unrelated things). Reads the last value the text claims (S29)."""
    t = text.strip()
    if re.search(r"NaN|Infinity|무한", t):
        return ("nan",) if "NaN" in t else ("inf", 1)
    if ERROR_WORD.search(t):
        n = ERROR_NAME.search(t)
        return ("error", n.group(1) if n else None)
    if NONE_WORDS.search(t) and not re.search(r"`", t):
        return ("none",)
    cands = re.findall(r"`([^`\n]+)`", t)
    if cands:
        v = literal(cands[-1], lang)
        return norm(v, lang) if v is not None else None
    for k, v in KOR.items():
        if strip_words(t) == k:
            return v
    core = strip_words(t)
    v = literal(core, lang)
    if v is not None:
        return ("bare", norm(v, lang), core)
    m = re.fullmatch(r"(-?[\d,]+(?:\.\d+)?)\s*" + UNIT + r"?(?:\s*" + PARTICLE + r")?", core)
    if m:
        raw = m.group(1)
        if re.fullmatch(r"-?\d{1,3}(?:,\d{3})+(?:\.\d+)?|-?\d+(?:\.\d+)?", raw):
            num = raw.replace(",", "")
            vv = ("int", int(num)) if (lang == "py" and "." not in num) else ("float", float(num)) if lang == "py" else ("num", float(num))
            return ("unit", vv, core)
    if re.fullmatch(r"[A-Za-z가-힣][\w가-힣]*", core):
        return ("word", None, core)
    return None


def same(text, out, lang):
    """'same' | 'diff' | None for a guess text against the runner's output line."""
    r = out.partition(" ")
    if r[0] not in ("RETURN", "ERROR"):
        return None
    res = result_of(out, lang)
    if res is None:
        return None
    g = guess_of(text, lang, res)
    if g is None:
        return None
    if g[0] == "error":
        if res[0] != "error":
            return "diff"
        return "same" if g[1] is None or g[1] == res[1] else "diff"
    if res[0] == "error":
        return "diff"
    if g[0] in ("nan", "inf"):
        return "diff" if res[0] in ("int", "float", "num") else ("same" if eq(g, res, lang) else "diff")
    if g[0] == "none":
        return "same" if res[0] in ("none", "null") and lang == "py" else ("diff" if res[0] != "none" else "same")
    if res[0] == "str":
        if g[0] == "bare":
            return "same" if g[1][0] == "str" and g[1][1] == res[1] else "diff"
        if g[0] in ("unit", "word"):
            return "same" if re.sub(r"(?<=\d)\s+(?=\D)", "", g[2]) == re.sub(r"(?<=\d)\s+(?=\D)", "", res[1]) and g[2] == g[2].strip() else "diff"
        return "same" if eq(g, res, lang) else "diff"
    if g[0] == "bare":
        return "same" if eq(g[1], res, lang) else "diff"
    if g[0] == "unit":
        return "same" if eq(g[1], res, lang) else "diff"
    if g[0] == "word":
        return None
    return "same" if eq(g, res, lang) else "diff"


HEAD = {"**맞혔습니다.**": "맞음", "**아쉽지만 틀렸습니다.**": "틀림", "**거의 맞았습니다.**": "거의"}


def head(shown):
    for h, v in HEAD.items():
        if shown.startswith(h):
            return v
    return "없음"


def sentences(shown):
    """[(나)] (e): sentences after the head and the `바른 결과:` line; a period inside backticks is not an end; a list
    item is one sentence."""
    body = shown
    for h in HEAD:
        if body.startswith(h):
            body = body[len(h):]
    n = 0
    for line in body.split("\n"):
        s = line.strip()
        if not s or s.startswith("바른 결과:"):
            continue
        if re.match(r"^(?:[-*•]|\d+[.)])\s", s):
            n += 1
            continue
        code, k = False, 0
        for i, c in enumerate(s):
            if c == "`":
                code = not code
            elif not code and c in ".!?。" and (i + 1 == len(s) or s[i + 1] in " \t\"'”)"):
                k += 1
        n += max(k, 1)
    return n


LABELLED = re.compile(r"^\s*(?:종류|따라가기|근거|짐작값|다른 호출|식|판정|답)\s*:", re.M)


def labelled(shown):
    return bool(LABELLED.search(shown))


def think(shown):
    return "생각해 보기" in shown


def shown_values(shown):
    """S13 · S20: the values the plugin shows as computed: ('right', v), ('call', call, v), ('expr', expr, v)."""
    out = []
    for m in re.finditer(r"바른 결과:\s*`([^`\n]+)`", shown):
        out.append(("right", None, m.group(1)))
    for m in re.finditer(r"`([^`\n]+)`(?:를|을) 실행하면 결과는 `([^`\n]+)`", shown):
        out.append(("call", m.group(1), m.group(2)))
    for m in re.finditer(r"^- `([^`\n]+)`의 값:\s*`([^`\n]+)`", shown, re.M):
        out.append(("expr", m.group(1), m.group(2)))
    return out


def shown_same(v, out, lang):
    """A value the plugin shows (code notation, or '오류'/'<Name> 오류') against a runner output line."""
    res = result_of(out, lang)
    if res is None:
        return None
    if re.search(r"오류|Error|에러", v):
        if res[0] != "error":
            return False
        n = ERROR_NAME.search(v)
        return n is None or n.group(1) == res[1]
    if res[0] == "error":
        return False
    g = literal(v, lang)
    if g is None:
        if res[0] in ("none", "undefined") and v in ("None", "undefined"):
            return True
        return None
    return eq(norm(g, lang), res, lang)


def split_args(s):
    out, depth, cur, q = [], 0, "", None
    i = 0
    while i < len(s):
        c = s[i]
        if q:
            cur += c
            if c == "\\" and i + 1 < len(s):
                cur += s[i + 1]
                i += 1
            elif c == q:
                q = None
        elif c in "\"'`":
            q = c
            cur += c
        elif c in "([{":
            depth += 1
            cur += c
        elif c in ")]}":
            depth -= 1
            cur += c
        elif c == "," and depth == 0:
            out.append(cur.strip())
            cur = ""
        else:
            cur += c
        i += 1
    if cur.strip():
        out.append(cur.strip())
    return out


def canon(call, lang):
    """(가)-1 (5): a call as its function name and its arguments read as values (py keyword names kept), white space
    outside strings and the quote kind matched away; an argument that is not a literal kept as its squeezed text."""
    m = re.match(r"^\s*([A-Za-z_$][\w$.]*)\s*\((.*)\)\s*;?\s*$", call, re.S)
    if not m:
        return ("text", re.sub(r"\s+", "", call))
    args = []
    for a in split_args(m.group(2)):
        k = None
        km = re.match(r"^([A-Za-z_]\w*)\s*=(?!=)\s*(.*)$", a, re.S) if lang == "py" else None
        if km:
            k, a = km.group(1), km.group(2)
        v = literal(a, lang)
        args.append((k, repr(norm(v, lang)) if v is not None else "text:" + re.sub(r"\s+", "", a)))
    return (m.group(1), tuple(args))


def canon_same(a, b, lang):
    return canon(a, lang) == canon(b, lang)


def selftest():
    cases = [
        ("14,000원", "RETURN 14000", "js", "same"), ("14000", "RETURN 14000", "py", "same"), ("600", "RETURN 600.0", "py", "diff"),
        ("600.0", "RETURN 600.0", "py", "same"), ("4", "RETURN 4", "js", "same"), ("4.0", "RETURN 4", "js", "same"),
        ("4.0", "RETURN 4", "py", "diff"), ("97.50", "RETURN 97.5", "py", "same"), ("7", 'RETURN "7"', "js", "diff"),
        ('"7"', 'RETURN "7"', "js", "same"), ("'7'", "RETURN '7'", "py", "same"), ("12.6", 'RETURN "12.6"', "js", "diff"),
        ("5개", 'RETURN "5개"', "js", "same"), ("5 개", 'RETURN "5개"', "js", "same"), ("14,000원", 'RETURN "14000원"', "js", "diff"),
        ("A", 'RETURN "A"', "js", "same"), ("a", 'RETURN "A"', "js", "diff"), ('"hi"', 'RETURN "Hi"', "js", "diff"),
        ("빈 배열", "RETURN []", "js", "same"), ("빈 문자열이요", 'RETURN ""', "js", "same"), ("참", "RETURN true", "js", "same"),
        ("null", "RETURN None", "py", "same"), ("undefined", "RETURN null", "js", "diff"), ("[1, 2]", "RETURN (1, 2)", "py", "diff"),
        ("(1, 2)", "RETURN (1, 2)", "py", "same"), ("{'b': 2, 'a': 1}", "RETURN {'a': 1, 'b': 2}", "py", "same"),
        ("에러가 날 것 같아요", "ERROR TypeError", "js", "same"), ("TypeError가 나요", "ERROR TypeError", "js", "same"),
        ("ValueError가 나요", "ERROR TypeError", "py", "diff"), ("3", "ERROR TypeError", "js", "diff"), ("에러 나요", "RETURN 3", "js", "diff"),
        ("아무것도 돌려주지 않아요", "RETURN None", "py", "same"), ("NaN", "RETURN 3", "js", "diff"), ("25%", "RETURN 25", "js", "same"),
        ("2000이 나올 것 같아요", "RETURN 2000", "js", "same"), ("`2000`", "RETURN 2000", "js", "same"), ("3이 아니라 5요", "RETURN 5", "js", None),
        ("값이 두 배가 될 것 같아요", "RETURN 5", "js", None), ("True", "RETURN True", "py", "same"), ("true", "RETURN True", "py", "same"),
        ("-3", "RETURN -3", "js", "same"), ("1,234.50", "RETURN 1234.5", "py", "same"), ("`2000?`", "RETURN 2000", "js", None),
        ("2000?", "RETURN 2000", "js", "same"), ("2000이 나오나요?", "RETURN 2001", "js", "diff"), ("에러 나나요?", "ERROR TypeError", "js", "same"),
    ]
    bad = [(t, o, l, w, same(t, o, l)) for t, o, l, w in cases if same(t, o, l) != w]
    assert sentences("**맞혔습니다.** 한 문장. 두 문장이고 `a.b` 코드.\n바른 결과: `3`") == 2
    assert sentences("- 하나\n- 둘\n셋.") == 3
    assert head("**아쉽지만 틀렸습니다.** x") == "틀림" and head("그냥") == "없음"
    assert labelled("종류: 짐작\n") and not labelled("근거로 보면")
    assert shown_values("바른 결과: `3`\n`f(1)`를 실행하면 결과는 `4`입니다.\n- `1 + 1`의 값: `2`") == [("right", None, "3"), ("call", "f(1)", "4"), ("expr", "1 + 1", "2")]
    assert shown_same("3", "RETURN 3", "js") and shown_same('""', 'RETURN ""', "js") and shown_same("TypeError 오류", "ERROR TypeError", "js")
    assert shown_same("600", "RETURN 600.0", "py") is False
    assert canon_same("f(1, 'a')", "f( 1 , \"a\" )", "js") and not canon_same("f(1, 'a')", "f(2, 'a')", "js")
    assert canon_same("g(x=3, y=[1,2])", "g(x = 3, y = [1, 2])", "py") and not canon_same("g(x=3)", "g(3)", "py")
    assert not canon_same("h(1)", "h(1.0)", "py") and canon_same("h(1)", "h(1.0)", "js")
    print(json.dumps({"cases": len(cases), "bad": bad}, ensure_ascii=False))
    return not bad


if __name__ == "__main__":
    if sys.argv[1:] == ["test"]:
        sys.exit(0 if selftest() else 1)
    sys.exit("usage: same.py test (a library: tools/tally.py imports it)")
