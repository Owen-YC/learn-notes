#!/bin/bash
# learn-notes 1.13.0 G5 sonnet (batch 3; copy of impl112/b4/tools/stage.sh c47277f0…f210, the 1.12.0 G5 stage runner; only
# the paths, the calibration named, the empty check stage and this text changed): one model-stage, sonnet only (haiku is
# not measured for G5 in 1.13.0), run DETACHED (plan runnerRules), e.g.
#   ONLY_WORKFLOW=1 setsid nohup bash tools/stage.sh go note sonnet > go/stage/note.log 2>&1 < <empty file> &
# Sets: go (the pre-bar GO pilot, records only, B-12) and m (the measured round, after the bar commit). Stages and their
# frozen lines (each refused unless its D34 result shows every compared request the same, bad 0, and the lines are 444):
#   note   <set>/frozen/note-lines-sonnet.jsonl      D34 <set>/frozen/d34-set/result.json   (fixed replies, before calls)
#   r      <set>/r-lines-sonnet.jsonl                D34 <set>/d34-real-r/result.json       (the real note replies)
#   check  <set>/check-lines-sonnet.jsonl  (go)      D34 <set>/d34-real-check/result.json   (the real note and r replies)
#          (texts the plugin's own code answers make no line: a check stage with no line calls nothing and is DONE with
#          0 requests, no session)
#   n1, n2 <set>/check-lines-sonnet.jsonl  (m)       D34 <set>/d34-real-check/result.json
# Order: r after note is DONE, check (n1) after r, n2 after n1. Refuses a stage whose STARTED exists (cut-stage rule: the
# main loop decides). Before: an 'ok' session (probe/precheck.sh) = the before record and the usage gate (tools/gate.py
# pre, check point 'G5 GO <stage> sonnet' or 'G5 round <stage> sonnet'): record differs -> exit 3 (STOP, not
# called); gate fails -> exit 7 (WAIT, its resetsAt printed; no STARTED written, may run again later); no
# ONLY_WORKFLOW=1 -> exit 2. Then STARTED (UTC, request file sha256), attempt 1 (probe session call-1: each call's
# status line in call-1/status.jsonl), then the stance's resend rule ([공통]): a call whose reply is an api-error (any
# status) is sent again once, its frozen line as it is; in a note stage also a call cut by its own time limit (aborted
# at timeoutMs - 1000 or later: transientOf 'timeout', D6, 1.11.0's tool); nothing else is ever sent again (an empty
# reply, another abort, a cap hit stay as they are) (call-2); the after record (exit 4 VOID when it differs). A call
# that threw (the engine refused before sending) -> exit 5 (M-4 line 4). Then M-4's 10% rule on each request's final
# status: api-errors (and requests with no status) left above 10% -> exit 6 (void, nothing opened). DONE, exit 0.
# Only status is printed; never an answer's text. Every claude process goes through cli/pinned.sh.
S=${G5_ROOT:-/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b3}  # G5_ROOT: synthetic tests only
P=${PINNED:-/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/cli/pinned.sh}
SET="$1"; ST="$2"; M="$3"
[ "$M" = sonnet ] || { echo "refuse: only sonnet is measured for G5 in 1.13.0"; exit 2; }
case "$SET:$ST" in
  go:note|m:note) LINES="${S:?}/$SET/frozen/note-lines-sonnet.jsonl"; CMP="${S:?}/$SET/frozen/d34-set/result.json"; PREV= ;;
  go:r|m:r) LINES="${S:?}/$SET/r-lines-sonnet.jsonl"; CMP="${S:?}/$SET/d34-real-r/result.json"; PREV=note ;;
  go:check) LINES="${S:?}/$SET/check-lines-sonnet.jsonl"; CMP="${S:?}/$SET/d34-real-check/result.json"; PREV=r ;;
  m:n1) LINES="${S:?}/$SET/check-lines-sonnet.jsonl"; CMP="${S:?}/$SET/d34-real-check/result.json"; PREV=r ;;
  m:n2) LINES="${S:?}/$SET/check-lines-sonnet.jsonl"; CMP="${S:?}/$SET/d34-real-check/result.json"; PREV=n1 ;;
  *) echo "usage: stage.sh <go|m> <note|r|check (go)|n1|n2 (m)> sonnet"; exit 2 ;;
esac
GST="$ST"; [ "$SET" = go ] && GST="go-$ST"
D="${S:?}/$SET/stage/$ST/$M"
[ -e "$D/STARTED" ] && { echo "refuse: $D/STARTED exists (cut-stage rule: report to the main loop)"; exit 1; }
[ -n "$PREV" ] && [ ! -e "${S:?}/$SET/stage/$PREV/$M/DONE" ] && { echo "refuse: stage $PREV is not done"; exit 1; }
[ -f "$LINES" ] || { echo "no frozen lines: $LINES"; exit 2; }
[ "$(stat -c %a "$LINES")" = 444 ] || { echo "refuse: $LINES is not frozen (chmod 444)"; exit 2; }
if [ ! -s "$LINES" ]; then
  [ "$ST" = check ] || [ "$ST" = n1 ] || [ "$ST" = n2 ] || { echo "no frozen lines: $LINES"; exit 2; }
  mkdir -p "$D"
  { date -u +%FT%TZ; sha256sum "$LINES"; echo "no line: nothing called"; } > "$D/STARTED"
  echo '{"requests": 0, "final": {}, "counts": {}, "apiErrorsLeft": 0, "void10": false, "sha256": {}}' > "$D/summary.json"
  date -u +%FT%TZ > "$D/DONE"
  echo "DONE $SET $ST $M (0 requests)"
  exit 0
fi
NL=$(grep -c . "$LINES")
python3 -I - "$CMP" "$NL" <<'PY' || { echo "refuse: no D34 for this stage ($CMP)"; exit 2; }
import json, sys
p, n = sys.argv[1], int(sys.argv[2])
try:
    c = json.load(open(p, encoding="utf-8"))
except Exception:
    sys.exit(1)
sys.exit(0 if c.get("bad") == 0 and c.get("testExit") == 0 and c.get("tests", 0) >= 1 else 1)
PY
mkdir -p "$D"
N=$(ls -d "$D"/pre-*/ 2>/dev/null | wc -l); PRE="$D/pre-$((N + 1))"
"$P" --record > "$PRE.pin.txt" 2>&1
"$P" bash "${S:?}/probe/precheck.sh" "$PRE" "$M" || { echo "precheck failed to run"; exit 3; }
python3 -I "${S:?}/tools/gate.py" pre "$PRE" "$M" "$GST" "$PRE.pin.txt"; rc=$?
[ $rc -eq 3 ] && { echo "STOP: the before record differs from the 1.13.0 calibration: not called"; exit 3; }
[ $rc -eq 7 ] && { echo "WAIT: usage gate failed: not started"; exit 7; }
[ $rc -eq 9 ] && { echo "not started: no statement that no other workflow runs (ONLY_WORKFLOW=1)"; exit 2; }
[ $rc -ne 0 ] && { echo "gate error $rc"; exit 3; }
{ date -u +%FT%TZ; sha256sum "$LINES"; echo "gate $PRE/gate.json"; } > "$D/STARTED"
"$P" --record > "$D/pin-before.txt" 2>&1
threw() { grep -q '"reason": *"threw"' "$1/status.jsonl" 2>/dev/null; }
CUR="$LINES"
for A in 1 2; do
  "$P" bash "${S:?}/probe/call.sh" "$D/call-$A" "$M" "$CUR"
  [ -f "$D/call-$A/out.json" ] || { echo "CUT: no call-$A out.json"; "$P" --record > "$D/pin-after.txt" 2>&1; exit 9; }
  threw "$D/call-$A" && { echo "THREW: the engine refused before sending (M-4 line 4)"; exit 5; }
  chmod 444 "$D/call-$A/out.json"
  [ $A -eq 2 ] && break
  python3 -I - "$D/call-$A/out.json" "$LINES" "$D/again-2.jsonl" "$ST" <<'PY'
import json, sys
out, lines_p, nxt, st = sys.argv[1:5]
lines = {json.loads(x)["id"]: x for x in open(lines_p, encoding="utf-8") if x.strip()}
again = []
for r in json.load(open(out, encoding="utf-8"))["results"]:
    if r.get("isAnswered"):
        continue
    if r.get("reason") == "api-error" or (st == "note" and r.get("reason") == "aborted" and (r.get("ms") or 0) >= r.get("timeoutMs", 90000) - 1000):
        again.append(lines[r["id"]].rstrip("\n"))
if again:
    open(nxt, "w", encoding="utf-8").write("\n".join(again) + "\n")
print(f"to send again once: {len(again)}")
PY
  [ -s "$D/again-2.jsonl" ] || break
  CUR="$D/again-2.jsonl"
done
"$P" --record > "$D/pin-after.txt" 2>&1
python3 -I "${S:?}/tools/gate.py" after "$D" "$M" "$D/pin-after.txt"; after=$?
python3 -I - "$D" "$LINES" <<'PY'
import hashlib, json, os, sys
d, lines_p = sys.argv[1:3]
ids = [json.loads(x)["id"] for x in open(lines_p, encoding="utf-8") if x.strip()]
final, summ = {}, {"attempts": [], "sha256": {}}
results = {}
for a in (1, 2):
    p = f"{d}/call-{a}/out.json"
    if not os.path.exists(p):
        continue
    summ["sha256"][f"call-{a}"] = hashlib.sha256(open(p, "rb").read()).hexdigest()
    rs = json.load(open(p, encoding="utf-8"))["results"]
    summ["attempts"].append({"attempt": a, "calls": len(rs)})
    for r in rs:
        how = "answered" if r.get("isAnswered") else r.get("reason")
        if how == "api-error":
            how += f"/{r.get('status')}"
        final[r["id"]] = {"attempt": a, "how": how, "output_tokens": (r.get("usage") or {}).get("output_tokens"), "ms": r.get("ms")}
        results[r["id"]] = dict(r, attempt=a)
for i in ids:
    final.setdefault(i, {"attempt": None, "how": "no-status", "output_tokens": None, "ms": None})
counts = {}
for v in final.values():
    counts[v["how"]] = counts.get(v["how"], 0) + 1
api = sum(n for k, n in counts.items() if k.startswith("api-error") or k == "no-status")
# The stage's final replies, one per request, in line order (the second attempt's where there was one): what readers read.
body = json.dumps({"lines": lines_p, "results": [results[i] for i in ids if i in results]}, ensure_ascii=False, indent=1) + "\n"
open(f"{d}/out.json", "w", encoding="utf-8").write(body)
os.chmod(f"{d}/out.json", 0o444)
summ["sha256"]["out"] = hashlib.sha256(body.encode("utf-8")).hexdigest()
summ.update({"requests": len(ids), "final": final, "counts": counts, "apiErrorsLeft": api, "void10": api * 10 > len(ids)})
open(f"{d}/summary.json", "w").write(json.dumps(summ, indent=1) + "\n")
print(json.dumps({k: summ[k] for k in ("requests", "counts", "apiErrorsLeft", "void10", "sha256")}))
PY
[ $after -ne 0 ] && { echo "VOID: the after record differs (D19): this model's cell is off"; exit 4; }
grep -q '"void10": true' "$D/summary.json" && { echo "VOID: api-errors above 10% (M-4)"; exit 6; }
date -u +%FT%TZ > "$D/DONE"
echo "DONE $SET $ST $M"
