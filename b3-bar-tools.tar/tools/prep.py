"""learn-notes 1.13.0 G5 sonnet (batch 3; copy of impl112/b4/tools/prep.py a97b4e04…ad23 = the impl111 prep rule, unchanged
but for this line). learn-notes 1.11.0 G5 (docs/qa/견본.md, 1.10.0 G5 '견본의 짜임' (가) 꼴): the engine-shaped hunks of each frozen
change. A new file (before null) is what Write gives (tool Write, kind create, structuredPatch empty: the plugin makes
creationHunk of its content); a file changed is what Edit gives (tool Edit, kind update, structuredPatch = difflib's
hunks of the before and after texts split on newline, three lines of context each side). Paths are under /proj, in the
change's order. Nothing of the change is altered.

usage: prep.py <frozen/changes-G5.json> <frozen/hunks-G5.json>   (refuses to overwrite; chmod 444)
"""
import difflib
import hashlib
import json
import os
import sys

ROOT = "/proj"


def hunks_of(before, after, n=3):
    a, b = before.split("\n"), after.split("\n")
    out = []
    for group in difflib.SequenceMatcher(None, a, b, autojunk=False).get_grouped_opcodes(n):
        i1, i2, j1, j2 = group[0][1], group[-1][2], group[0][3], group[-1][4]
        lines = []
        for tag, x1, x2, y1, y2 in group:
            if tag == "equal":
                lines += [" " + s for s in a[x1:x2]]
                continue
            if tag in ("replace", "delete"):
                lines += ["-" + s for s in a[x1:x2]]
            if tag in ("replace", "insert"):
                lines += ["+" + s for s in b[y1:y2]]
        old_len, new_len = i2 - i1, j2 - j1
        out.append({"oldStart": i1 + 1 if old_len else i1, "oldLines": old_len,
                    "newStart": j1 + 1 if new_len else j1, "newLines": new_len, "lines": lines})
    return out


def prep(changes):
    out = []
    for one in changes:
        files = []
        for f in one["files"]:
            path = f"{ROOT}/{f['path'].lstrip('/')}"
            if f.get("before") is None:
                files.append({"path": path, "tool": "Write", "kind": "create", "content": f["after"], "hunks": []})
            else:
                files.append({"path": path, "tool": "Edit", "kind": "update", "before": f["before"], "after": f["after"],
                              "hunks": hunks_of(f["before"], f["after"])})
        out.append({"id": one["id"], "files": files})
    return out


if __name__ == "__main__":
    src, dst = sys.argv[1], sys.argv[2]
    if os.path.exists(dst):
        sys.exit(f"refuse: {dst} exists")
    data = prep(json.load(open(src, encoding="utf-8")))
    text = json.dumps(data, ensure_ascii=False, indent=1) + "\n"
    open(dst, "w", encoding="utf-8").write(text)
    os.chmod(dst, 0o444)
    print(json.dumps({"hunks": dst, "sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(), "changes": len(data)}))
