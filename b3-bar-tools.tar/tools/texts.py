"""learn-notes 1.13.0 G5 sonnet (batch 3), the (나) texts of the GO gate and the measured round (no model call here; the
writers and the label check are fresh sub-agents run by gen/run.sh in 'files' mode). From impl112/b4/tools/texts.py with
the 1.13.0 layout: the stance's (나)-0 (no filter table), writers of at most 10 texts per call and one kind per call
(plan preBarGate: guesses 3 calls 8 · 8 · 8, questions 3 calls 8 · 7 · 7, blanks 1 call; samples.layoutB for the round).
Sets: go (the GO gate: every usable line in frozen order, at most 8; 50 texts = 24 guesses incl. the '?' forms, 22
questions, 4 blanks, the 1.12.0 go slots) and m (the measured round; layoutB: 10 lines js 5 · ts 2 · py 3 by the 1996cf1
pick and fill rule; 54 texts). A slot's line k maps to line ((k - 1) mod u) + 1 when fewer lines than the layout's are
usable.
  pick <set> <label>         -> <set>/questions-<label>.json  (from <set>/stored.json, runner.json, tally-a.json)
  prompts <set> <label>      -> <set>/texts-in-<label>/inputs/<call>.md, one prompt per writer call (judge/tpl-texts.md
                                + per line of the call: its question, the walk-through as stored, the note, the right
                                result, the slots to write); the root is run by gen/run.sh <root> files json
  parse <set> <label>        -> <set>/texts-raw-<label>.json (every writer call's reply.json; a missing slot -> STOP:
                                the run.sh 'files' readability check already re-sent an unreadable reply once)
  labelprompt <set> <label>  -> <set>/label-in-<label>/inputs/labelcheck.md (judge/tpl-labelcheck.md + the frozen
                                stance's [같음] + every guess with its question and right result); gen/run.sh files json
  apply <set> <label>        -> <set>/texts-<label>.json: each guess's expected verdict: tools/same.py's [같음] on the
                                guess text against the runner's output line when it reads one claim; else the label
                                check's same; else none (undecided: the guess counts as a miss); disagreements recorded
Kinds: guess (g1 · g2 · g3, and in go the '?' forms), questionGuess (m: gq), blank (b), question (q · q2),
questionYesNo (y), questionNoMark (n). Every output chmod 444; refuses to overwrite."""
import hashlib, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import same as SAME  # noqa: E402

S = os.environ.get("G5_ROOT", os.path.dirname(HERE))  # G5_ROOT: synthetic tests only
STANCE = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b3/go/stance-G5.json"
STANCE_SHA = "ea8efdb63021b623a4bb7f220575362488bbf265e90da2df3cb0db111e0b59ab"
N_FORMS = {1: "`뭐가 달라요` 꼴", 2: "`어디서 값이 바뀌어요` 꼴", 3: "`여기가 헷갈려요` 꼴", 4: "`…설명해 주세요` 꼴", 5: "`왜 …` 꼴"}
SLOT_TEXT = {
    "g1": "- g1 맞는 짐작: 바른 결과를 맞게 짐작한 평서문(40자 이하). 값만 적어도 됩니다(예: `2000`). 바른 결과가 오류로 끝나면 문제 꼴(예: 에러가 날 것 같아요)로 씁니다.",
    "g2": "- g2 틀린 값 짐작: 바른 결과와 다른 값을 짐작한 평서문(40자 이하). 바른 결과가 오류로 끝나면 값 하나를 짐작합니다. '물음표 꼴'이라고 적힌 g2는 같은 뜻을 값 뒤에 물음표만 붙이거나(예: `2000?`) 값을 묻는 꼴(예: 2000이 나오나요?)로 씁니다.",
    "g3": "- g3 문제 짐작: 코드가 멈추거나 오류가 나거나 이상하게 돌 것이라고 짐작하는 평서문(40자 이하). '물음표 꼴'이라고 적힌 g3은 같은 뜻을 문제를 묻는 꼴(예: 에러 나나요?)로 씁니다.",
    "gq": "- gq 물음표 짐작: 짐작을 물음표로 끝나는 꼴로 씁니다. 적힌 꼴을 따릅니다: '문제 꼴'(예: 에러 나나요?), '값에 물음표'(예: `2000?`), '값을 묻는 꼴'(예: 2000이 나오나요?). 맞는 값인지 틀린 값인지는 자유입니다.",
    "b": "- b 모르겠어요: 모르겠다는 말 한마디(예: 모르겠어요).",
    "q": "- q 물음표 질문: 결과를 짐작하지 않고 코드에 대해 새로 묻는 물음표 질문.",
    "y": "- y 성질 질문: 결과가 아니라 코드나 값의 성질을 예/아니요로 묻는 물음표 질문(예: 이 함수는 원래 배열을 바꾸나요?).",
    "n": "- n 물음표 없는 질문: 물음표 없이 끝나는 질문. 적힌 꼴을 따릅니다(`뭐가 달라요` 꼴, `어디서 값이 바뀌어요` 꼴, `여기가 헷갈려요` 꼴, `…설명해 주세요` 꼴, `왜 …` 꼴).",
    "q2": "- q2 두 번째 물음표 질문: q와 다른 것을 묻는 물음표 질문.",
}
GUESS_SLOTS = ("g1", "g2", "g3", "gq")


def slots(set_name):
    """(line k, slot, kind, form) in writing order; go: 8 lines, 50; m: 10 lines, 54."""
    out = []
    if set_name == "go":
        for k in range(1, 9):
            out.append((k, "g1", "guess", None))
            out.append((k, "g2", "guess", "물음표 꼴" if k in (5, 7) else None))
            out.append((k, "g3", "guess", "물음표 꼴" if k in (1, 3) else None))
            if k % 2 == 0:
                out.append((k, "b", "blank", None))
            out.append((k, "q", "question", None))
            if k <= 4:
                out.append((k, "y", "questionYesNo", None))
            else:
                out.append((k, "n", "questionNoMark", N_FORMS[k - 4]))
            if k <= 6:
                out.append((k, "q2", "question", None))
        return out
    gq = {1: "문제 꼴", 3: "문제 꼴", 5: "문제 꼴", 7: "값에 물음표", 9: "값을 묻는 꼴"}
    for k in range(1, 11):
        out += [(k, "g1", "guess", None), (k, "g2", "guess", None), (k, "g3", "guess", None)]
        if k in (2, 4, 6, 8):
            out.append((k, "b", "blank", None))
        out.append((k, "y" if k in (1, 4, 7) else "q", "questionYesNo" if k in (1, 4, 7) else "question", None))
        if k in gq:
            out.append((k, "gq", "questionGuess", gq[k]))
        if k % 2 == 0:
            out.append((k, "n", "questionNoMark", N_FORMS[k // 2]))
    return out


def calls(set_name):
    """Writer calls: (call name, kind, [(k, slot)]): one kind per call, at most 10 texts."""
    if set_name == "go":
        return [("G1", "guess", [(k, "g1") for k in range(1, 9)]), ("G2", "guess", [(k, "g2") for k in range(1, 9)]),
                ("G3", "guess", [(k, "g3") for k in range(1, 9)]), ("Q1", "question", [(k, "q") for k in range(1, 9)]),
                ("Q2", "question", [(k, "y") for k in range(1, 5)] + [(k, "q2") for k in range(1, 4)]),
                ("Q3", "question", [(k, "n") for k in range(5, 9)] + [(k, "q2") for k in range(4, 7)]),
                ("B", "blank", [(k, "b") for k in (2, 4, 6, 8)])]
    sys.exit("set m: the measured round's writer layout (samples.layoutB) is not part of the GO gate's tools; it is fixed with the bar commit's tool table")


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_once(path, data):
    if os.path.exists(path):
        sys.exit(f"refuse: {path} exists")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    body = data if isinstance(data, str) else json.dumps(data, ensure_ascii=False, indent=1) + "\n"
    open(path, "w", encoding="utf-8").write(body)
    os.chmod(path, 0o444)
    return sha(body)


def load(path):
    return json.load(open(path, encoding="utf-8"))


def is_edge(final):
    if final["kind"] in ("error", "none"):
        return True
    return final.get("value") in ("null", "None", "false", "False", "[]", "''", '""', "{}", "()")


def lang_of(stored_one):
    f = stored_one.get("calleeFile") or ""
    return "py" if f.endswith(".py") else "js"


def pick(set_name, label):
    d = f"{S}/{set_name}"
    stored, runner, tally = load(f"{d}/stored.json"), load(f"{d}/runner.json")["runner"], load(f"{d}/tally-a.json")
    usable = [i for i in stored if i in set(tally["usableIds"])]
    if set_name == "go":
        chosen = usable[:8]
    else:
        lang = lambda i: "ts" if stored[i]["lang"].split("+")[0] == "ts" else stored[i]["lang"].split("+")[0]
        want = {"js": 5, "ts": 2, "py": 3}
        picked = {k: [i for i in usable if lang(i) == k][:n] for k, n in want.items()}
        rest = {k: [i for i in usable if lang(i) == k][n:] for k, n in want.items()}
        edge = lambda i: is_edge(runner[i]["final"])
        count = lambda: sum(1 for k in picked for i in picked[k] if edge(i))
        for k in list(want) + list(want):
            while count() < 3:
                cand = [i for i in rest[k] if edge(i)]
                swap = [i for i in reversed(picked[k]) if not edge(i)]
                if not cand or not swap:
                    break
                picked[k][picked[k].index(swap[0])] = cand[0]
                rest[k].remove(cand[0])
        chosen = [i for i in usable if any(i in v for v in picked.values())]
    qs = []
    for n, i in enumerate(chosen, 1):
        s = stored[i]
        trace = "\n".join(l for l in s["stored"].split("\n") if not l.startswith("**생각해 보기:**")).rstrip()
        qs.append({"q": f"L{n}", "sid": i, "line": s["line"], "call": s.get("call"), "lang": lang_of(s), "trace": trace, "note": s["noteText"],
                   "result": runner[i]["final"]["text"], "resultKind": runner[i]["final"]["kind"], "out": runner[i]["out"], "edge": is_edge(runner[i]["final"])})
    print(json.dumps({"questions": len(qs), "ids": [q["sid"] for q in qs], "edge": sum(q["edge"] for q in qs), "sha256": write_once(f"{d}/questions-{label}.json", {"set": set_name, "label": label, "questions": qs})}))


def line_of(k, u):
    return ((k - 1) % u) + 1


def expected_ids(set_name, u):
    ids, seen = [], {}
    for k, slot, kind, form in slots(set_name):
        n = line_of(k, u)
        seen[(n, slot)] = seen.get((n, slot), 0) + 1
        sid = slot if seen[(n, slot)] == 1 else f"{slot}-{seen[(n, slot)]}"
        ids.append({"id": f"L{n}-{sid}", "k": k, "line": n, "slot": slot, "kind": kind, "form": form})
    return ids


def prompts(set_name, label):
    d = f"{S}/{set_name}"
    qs = load(f"{d}/questions-{label}.json")["questions"]
    u = len(qs)
    want = expected_ids(set_name, u)
    by_k = {(w["k"], w["slot"]): w for w in want}
    tpl = open(f"{S}/judge/tpl-texts.md", encoding="utf-8").read().rstrip()
    out = {}
    for name, kind, members in calls(set_name):
        ws = [by_k[m] for m in members if m in by_k]
        if not ws:
            continue
        used = sorted({w["slot"] for w in ws}, key=list(SLOT_TEXT).index)
        guess = kind == "guess"
        body = tpl.replace("{SLOTS}", "\n".join(SLOT_TEXT[s] for s in used)).replace("{FIRST}", ws[0]["id"])
        body = body.replace("{CLAIM}", "짐작 글에는 claim도 적습니다: 그 글이 짐작한 최종 결과를 코드 값 하나로(문자열은 따옴표째) 적거나, 오류를 짐작했으면 `오류`(이름을 댔으면 그 이름)로 적습니다." if guess else "")
        body = body.replace("{FORM}", '{"texts": [{"id": "' + ws[0]["id"] + '", "text": "…"' + (', "claim": "…"' if guess else "") + "}]}")
        parts = [body, "", "## 물음"]
        for n in sorted({w["line"] for w in ws}):
            q = qs[n - 1]
            names = [w["id"].split("-", 1)[1] + (f"({w['form']})" if w["form"] else "") for w in ws if w["line"] == n]
            parts += ["", f"### {q['q']}", "", f"생각해 보기 물음: {q['line']}", "", "따라가기 글:", "", "````", q["trace"], "````", "", "노트:", "", "````", q["note"], "````", "", f"바른 결과: {q['result']}", "", f"쓸 글: {' · '.join(names)}"]
        out[name] = write_once(f"{d}/texts-in-{label}/inputs/{name}.md", "\n".join(parts) + "\n")
    print(json.dumps({"calls": out, "texts": len(want)}))


def latest_reply(root, part):
    for t in range(9, 0, -1):
        p = f"{root}/parts/{part}-{t}"
        if os.path.exists(f"{p}/reply.json") and not os.path.exists(f"{p}/VOIDED"):
            return json.load(open(f"{p}/reply.json", encoding="utf-8"))["text"], f"{part}-{t}"
    return None, None


def read_json(text):
    blocks = re.findall(r"```json[ \t]*\n(.*?)\n```", text, re.S)
    for cand in ([blocks[0]] if len(blocks) == 1 else []) + [text]:
        try:
            return json.loads(cand)
        except Exception:
            pass
    return None


def parse(set_name, label):
    d = f"{S}/{set_name}"
    qs = load(f"{d}/questions-{label}.json")["questions"]
    want = expected_ids(set_name, len(qs))
    root = f"{d}/texts-in-{label}"
    by, writers = {}, {}
    for name in sorted(os.listdir(f"{root}/inputs")):
        part = name[:-3]
        text, who = latest_reply(root, part)
        writers[part] = who
        v = read_json(text) if text is not None else None
        for x in (v or {}).get("texts", []) if isinstance(v, dict) else []:
            if isinstance(x, dict) and isinstance(x.get("id"), str) and isinstance(x.get("text"), str) and x["text"].strip():
                by.setdefault(x["id"], x)
    missing = [w["id"] for w in want if w["id"] not in by]
    if missing:
        print(json.dumps({"missing": missing}))
        print("STOP: texts missing")
        sys.exit(6)
    texts = []
    for w in want:
        x = by[w["id"]]
        q = qs[w["line"] - 1]
        texts.append({"id": w["id"], "q": q["q"], "sid": q["sid"], "slot": w["slot"], "kind": w["kind"], "form": w["form"],
                      "mark": "?" if w["form"] == "물음표 꼴" or w["kind"] == "questionGuess" else None, "text": x["text"].strip(),
                      "claim": x.get("claim") if w["slot"] in GUESS_SLOTS else None})
    print(json.dumps({"texts": len(texts), "writers": writers, "sha256": write_once(f"{d}/texts-raw-{label}.json", {"set": set_name, "label": label, "writers": writers, "texts": texts})}))


def is_guess(t):
    return t["slot"] in GUESS_SLOTS


def stance():
    raw = open(STANCE, "rb").read()
    if hashlib.sha256(raw).hexdigest() != STANCE_SHA:
        sys.exit("the stance file is not the frozen one")
    return json.loads(raw)


def labelprompt(set_name, label):
    d = f"{S}/{set_name}"
    qs = {q["q"]: q for q in load(f"{d}/questions-{label}.json")["questions"]}
    texts = load(f"{d}/texts-raw-{label}.json")["texts"]
    same_text = "\n".join(f"- {c}" for c in stance()["같음"])
    parts = [open(f"{S}/judge/tpl-labelcheck.md", encoding="utf-8").read().rstrip(), "", "## [같음]", "", same_text, "", "## 짐작"]
    for t in texts:
        if is_guess(t):
            q = qs[t["q"]]
            parts += ["", f"### {t['id']}", f"물음: {q['line']}", f"바른 결과: {q['result']}", f"짐작: {t['text']}"]
    print(json.dumps({"sha256": write_once(f"{d}/label-in-{label}/inputs/labelcheck.md", "\n".join(parts) + "\n")}))


def apply(set_name, label):
    d = f"{S}/{set_name}"
    qs = {q["q"]: q for q in load(f"{d}/questions-{label}.json")["questions"]}
    texts = load(f"{d}/texts-raw-{label}.json")["texts"]
    text, who = latest_reply(f"{d}/label-in-{label}", "labelcheck")
    v = read_json(text) if text is not None else None
    items = v if isinstance(v, list) else (v or {}).get("items", []) if isinstance(v, dict) else []
    by = {str(c.get("id")): c for c in items if isinstance(c, dict)}
    out, disagree, undecided = [], [], []
    for t in texts:
        if is_guess(t):
            q = qs[t["q"]]
            m = SAME.same(t["text"], q["out"], q["lang"]) if q.get("out") else None
            c = by.get(t["id"])
            lab = c.get("same") if c is not None and isinstance(c.get("same"), bool) else None
            if m is not None:
                expect, how = ("맞음" if m == "same" else "틀림"), "machine"
            elif lab is not None:
                expect, how = ("맞음" if lab else "틀림"), "labelcheck"
            else:
                expect, how = None, "undecided"
                undecided.append(t["id"])
            if m is not None and lab is not None and (m == "same") != lab:
                disagree.append({"id": t["id"], "machine": m, "labelcheck": lab})
            t = {**t, "expect": expect, "expectBy": how, "machine": m, "labelcheck": lab}
        else:
            t = {**t, "expect": None}
        out.append(t)
    print(json.dumps({"disagree": disagree, "undecided": undecided, "sha256": write_once(f"{d}/texts-{label}.json", {"set": set_name, "label": label, "texts": out, "disagree": disagree, "undecided": undecided, "labelcheck": who})}, ensure_ascii=False))


if __name__ == "__main__":
    mode, set_name, label = sys.argv[1:4]
    {"pick": pick, "prompts": prompts, "parse": parse, "labelprompt": labelprompt, "apply": apply}[mode](set_name, label)
