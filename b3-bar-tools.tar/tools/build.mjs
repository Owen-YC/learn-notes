// learn-notes 1.13.0 G5 sonnet (batch 3): the request lines of each call kind and the readings of the replies, for one
// frozen set (the GO gate's go/frozen or the measured round's), through tools/kit.mjs (the build commit's notes.ts).
// From impl112/b4/tools/build.mjs (1.12.0 G5c) with the G5e calls. No model call. Every output is written once
// (refuses to overwrite) and chmod 444.
//   note   <set dir> <model> <out.jsonl>                               writeNote's call per change (no team file)
//   r      <set dir> <model> <note out.json> <out.jsonl>               r's key per change whose note has text, in set
//                                                                      order; the rest listed (an in-scope one is a
//                                                                      (가)-1 miss and an r cap hit; must-open-0: no r)
//   stored <set dir> <model> <note out.json> <r out.json> <out.json>   per change: what askNote stores of r's reply, the
//                                                                      line openThink opens a minute on, its call, the
//                                                                      callee file, the walked call r was told (anchor)
//                                                                      or wrote as 예시 호출, calc's own result of the
//                                                                      line's call (for the STOP flag only), the kept
//                                                                      note's text and changes (runner, judges)
//   text   <set dir> <model> <note out.json> <stored.json> <texts.json> <out.jsonl> <plan.json>
//                                                                      per text: thinkCalcPlan's kind; code -> its shown
//                                                                      text (no call); check / fallback -> one line
//   read   <plan.json> <check out.json> <out.json>                     the shown reply of every text (code, check,
//                                                                      fallback) and its answered state
import { existsSync, mkdirSync, writeFileSync, chmodSync } from 'node:fs'
import { dirname } from 'node:path'
import * as K from './kit.mjs'

function writeOnce(path, text) {
  if (existsSync(path)) throw new Error(`refuse: ${path} exists`)
  mkdirSync(dirname(path), { recursive: true })
  writeFileSync(path, text)
  chmodSync(path, 0o444)
  return K.sha(text)
}
const jsonl = lines => (lines.length ? lines.map(l => JSON.stringify(l)).join('\n') + '\n' : '')
const outOf = path => Object.fromEntries(K.readJson(path).results.map(r => [r.id, r]))
const hasText = o => o?.isAnswered === true && typeof o.text === 'string' && o.text.trim() !== ''

const [mode, ...a] = process.argv.slice(2)
if (mode === 'note') {
  const [dir, model, out] = a
  const lines = K.samplesOf(dir).map(({ sample, entry }) => K.noteLine(model, sample, entry))
  console.log(JSON.stringify({ lines: lines.length, sha256: writeOnce(out, jsonl(lines)) }))
} else if (mode === 'r') {
  const [dir, model, noteOut, out] = a
  const notes = outOf(noteOut)
  const lines = []
  const left = []
  const kinds = {}
  for (const { sample, entry } of K.samplesOf(dir)) {
    if (!hasText(notes[sample.id])) {
      left.push(sample.id)
      continue
    }
    const r = K.rLine(model, sample, entry, notes[sample.id].text)
    const kind = r.isCode ? (r.scope.callees.some(c => c.anchor) ? 'anchor' : 'noanchor') : 'out'
    kinds[kind] = (kinds[kind] ?? 0) + 1
    const q = /## 학습자의 질문\n([\s\S]*?)\n\n## /.exec(r.line.prompt)?.[1] ?? ''
    if (q.endsWith('…')) throw new Error(`${sample.id}: r question cut at 1000`)
    lines.push(r.line)
  }
  console.log(JSON.stringify({ lines: lines.length, kinds, noText: left, sha256: writeOnce(out, jsonl(lines)) }))
} else if (mode === 'stored') {
  const [dir, model, noteOut, rOut, out] = a
  const notes = outOf(noteOut)
  const rs = outOf(rOut)
  const res = {}
  for (const { sample, entry } of K.samplesOf(dir)) {
    const n = notes[sample.id]
    const r = rs[sample.id]
    const base = { group: sample.group, lang: sample.lang, nearMiss: sample.nearMiss ?? null }
    if (!hasText(n)) {
      res[sample.id] = { ...base, note: 'no text', line: null }
      continue
    }
    if (!r?.isAnswered) {
      // askNote returns an error: nothing stored, nothing opens.
      res[sample.id] = { ...base, note: 'text', r: r ? r.reason ?? 'threw' : 'not called', line: null }
      continue
    }
    const got = K.readR(model, sample, entry, n.text, r.text)
    const call = got.think?.call ?? null
    const name = call ? /^([A-Za-z_$][\w$]*)\(/.exec(call)?.[1] : undefined
    const callee = name ? got.scope.callees.find(c => c.name === name) : undefined
    let calc = null
    if (call && callee) {
      const v = K.C.calcCall(got.scope.mods.get(callee.file), call)
      calc = v.kind === 'value' ? `RETURN ${v.show}` : v.kind === 'error' ? `ERROR ${v.name}` : 'UNKNOWN'
    }
    const anchor = got.scope.callees.find(c => c.anchor)?.anchor ?? null
    const example = /^\s*(?:[-*+•]\s+)?\**예시 호출\**\s*:\s*\**\s*`([^`\n]+)`/m.exec(got.stored)?.[1] ?? null
    res[sample.id] = {
      ...base,
      note: 'text',
      r: 'answered',
      isCode: got.isCode,
      callees: got.scope.callees.map(c => ({ name: c.name, file: c.file, params: c.params, anchor: c.anchor ?? null })),
      line: got.think?.question ?? null,
      call,
      calleeFile: callee?.file ?? null,
      anchor,
      exampleCall: example,
      calc,
      stored: got.stored,
      noteText: got.shown.text,
      changes: got.shown.changes.map(c => ({ file: c.file, kind: c.kind, diff: c.diff })),
    }
  }
  const opened = Object.entries(res).filter(([, v]) => v.line).map(([k]) => k)
  console.log(JSON.stringify({ changes: Object.keys(res).length, opened, sha256: writeOnce(out, JSON.stringify(res, null, 1) + '\n') }))
} else if (mode === 'text') {
  const [dir, model, noteOut, storedPath, textsPath, out, planOut] = a
  const notes = outOf(noteOut)
  const stored = K.readJson(storedPath)
  const texts = K.readJson(textsPath).texts
  const byId = Object.fromEntries(K.samplesOf(dir).map(one => [one.sample.id, one]))
  const lines = []
  const plans = {}
  const kinds = {}
  for (const t of texts) {
    const { sample, entry } = byId[t.sid]
    if (!stored[t.sid]?.line) throw new Error(`${t.id}: no open line under ${t.sid}`)
    const p = K.textPlan(model, t.id, sample, entry, notes[t.sid].text, stored[t.sid].stored, t.text)
    kinds[p.plan.kind] = (kinds[p.plan.kind] ?? 0) + 1
    plans[t.id] = { sid: t.sid, typed: t.text, kind: p.plan.kind, ...(p.plan.kind === 'code' ? { shown: K.shownReply(p, '') } : {}) }
    if (p.req) {
      if (p.plan.kind === 'check' && !p.req.prompt.includes(stored[t.sid].line.split('`')[1] ?? '\u0000')) throw new Error(`${t.id}: the check does not carry the line's call`)
      lines.push(p.req)
    }
  }
  const sha = writeOnce(out, jsonl(lines))
  console.log(JSON.stringify({ texts: texts.length, kinds, lines: lines.length, sha256: sha, planSha256: writeOnce(planOut, JSON.stringify({ model, dir, noteOut, storedPath, textsPath, plans }, null, 1) + '\n') }))
} else if (mode === 'read') {
  const [planPath, checkOut, out] = a
  const P = K.readJson(planPath)
  const res = checkOut === '-' ? {} : outOf(checkOut)
  const notes = outOf(P.noteOut)
  const stored = K.readJson(P.storedPath)
  const byId = Object.fromEntries(K.samplesOf(P.dir).map(one => [one.sample.id, one]))
  const rows = {}
  for (const [id, m] of Object.entries(P.plans)) {
    if (m.kind === 'code') {
      rows[id] = { path: 'code', answered: true, shown: m.shown, out: null }
      continue
    }
    const r = res[id]
    if (!r?.isAnswered) {
      rows[id] = { path: m.kind, answered: false, reason: r ? r.reason ?? 'threw' : 'no status', shown: null, out: r?.usage?.output_tokens ?? null }
      continue
    }
    const { sample, entry } = byId[m.sid]
    const p = K.textPlan(P.model, id, sample, entry, notes[m.sid].text, stored[m.sid].stored, m.typed)
    if (p.plan.kind !== m.kind) throw new Error(`${id}: plan kind changed`)
    rows[id] = { path: m.kind, answered: true, shown: K.shownReply(p, r.text), out: r.usage?.output_tokens ?? null }
  }
  console.log(JSON.stringify({ rows: Object.keys(rows).length, sha256: writeOnce(out, JSON.stringify(rows, null, 1) + '\n') }))
} else {
  console.error('usage: build.mjs note|r|stored|text|read …')
  process.exit(2)
}
