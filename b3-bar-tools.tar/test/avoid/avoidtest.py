"""Batch 3 avoid synthetic test (plan calibration.avoidBuilder.test): the assembled PH writer prompts (PH-I, PH-O and a
TU-I top-up) through gen/parts.py make with the frozen builder gen/avoid113.py on impl113/NAMES-all.txt as it is now."""
import json, os, re, subprocess, sys
B = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b3"
T = f"{B}/test/avoid"
sys.path.insert(0, f"{B}/gen")
import importlib.util
spec = importlib.util.spec_from_file_location("av", f"{B}/gen/avoid113.py"); av = importlib.util.module_from_spec(spec); spec.loader.exec_module(av)
root, tu = f"{T}/root", f"{T}/tu"
prompts = []
for part in ("PH-I", "PH-O"):
    d = f"{root}/parts/{part}-1"; os.makedirs(d, exist_ok=True)
    if not os.path.exists(f"{d}/prompt.md"):
        subprocess.run(["python3", "-I", f"{B}/gen/parts.py", "make", root, part, f"{d}/prompt.md"], check=True)
    prompts.append(f"{d}/prompt.md")
open(f"{root}/topup-need.json", "w").write(json.dumps({"TU-I": ["PH03", "PH05"], "TU-O": ["PH11"]}))
for part in ("TU-I", "TU-O"):
    d = f"{tu}/parts/{part}-1"; os.makedirs(d, exist_ok=True)
    if not os.path.exists(f"{d}/prompt.md"):
        subprocess.run(["python3", "-I", f"{B}/gen/parts.py", "make", tu, part, f"{d}/prompt.md"], check=True, env={**os.environ, "CHAIN_ROOT": root})
    prompts.append(f"{d}/prompt.md")
tools = [l.strip() for l in open(f"{root}/parts/PH-I-1/avoid-toolnames.txt", encoding="utf-8") if l.strip() and not l.startswith("#")]
t1 = []
for p in prompts:
    text = open(p, encoding="utf-8").read()
    t1.append({"prompt": p, "patternHits": sorted(set(m.group(0) for m in av.WORDS.finditer(text))), "toolNameHits": sorted(t for t in tools if re.search(rf"(?<![\w.-]){re.escape(t)}(?![\w-])", text))})
seven = ["calib/hm-sonnet.json", "haiku 줄을 다시 모두 끔", "isRuleWide", "judge/stance-G5.md", "sonnet 줄에 isRuleDrill도 켬", "tools/stance.py", "판정은 얼린 n2judge.mjs가 기계로 했습니다"]
sec = open(f"{root}/parts/PH-I-1/avoid.md", encoding="utf-8").read()
lists = [l.strip() for l in open(f"{root}/parts/PH-I-1/avoid-names.txt", encoding="utf-8") if l.strip() and not l.startswith("#")]
rows = [l.rstrip("\n").split("\t") for l in open(av.NAMES, encoding="utf-8") if l.strip()]
ws = [r[0] for r in rows if len(r) > 1 and r[1] == "견본" and re.search(r"\s", r[0])]
rec = {r[0] for r in rows if len(r) > 1 and r[1] != "견본"}
t2 = {"seven": seven, "sevenPresent": [s for s in seven if f"`{s}`" in sec], "gyeonbonWhitespaceEntries": len(ws),
      "presentAsRecordConcept": len([w for w in ws if w in lists and w in rec]), "gyeonbonWhitespacePresent": [w for w in ws if w in lists and w not in rec][:10]}
t3 = {}
for tag in ("G1-dev-113", "G2-dev-113", "G3-dev-113", "G4-dev-113", "G5-dev-113", "G6-dev-113"):
    mine = [r[0] for r in rows if len(r) > 1 and r[1] == tag]
    pick = lambda pred: next((x for x in mine if pred(x) and not av.WORDS.search(x) and x in lists), None)
    t3[tag] = {"file": pick(lambda x: bool(av.FILE.match(x))), "code": pick(lambda x: bool(av.IDENT.match(x)) and len(x) >= 3 and not av.ID.match(x)),
               "concept": pick(lambda x: bool(av.HANGUL.search(x)))}
fails = [x["prompt"] for x in t1 if x["patternHits"] or x["toolNameHits"]] + t2["sevenPresent"] + t2["gyeonbonWhitespacePresent"] + [k for k, v in t3.items() if not (v["file"] or v["code"] or v["concept"])]
out = {"test1": t1, "test2": t2, "test3": t3, "fails": fails, "build": json.load(open(f"{root}/parts/PH-I-1/avoid-build.json"))}
json.dump(out, open(f"{T}/avoidtest.json", "w"), ensure_ascii=False, indent=1)
print(json.dumps({"fails": fails, "test3": t3, "sevenPresent": t2["sevenPresent"]}, ensure_ascii=False))
sys.exit(1 if fails else 0)
