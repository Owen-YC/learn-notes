#!/bin/bash
# Detached runner for one calibration probe round (plan runnerRules), learn-notes 1.12.0 batch 0.
# usage: runner.sh <round-label> <alias> <lines.jsonl>
# Refuses when <round>/STARTED exists. Writes STARTED (UTC, lines sha256), pin records before/after,
# runs probe/call.sh through cli/pinned.sh, then status.jsonl (id, answered, reason, status, output_tokens, ms; no text)
# and RUNNER-EXIT.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b0
P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh
L="$1"; A="$2"; LINES="$3"
D="${S:?}/calib/rounds/$L"
[ -e "$D/STARTED" ] && { echo "refuse: $D/STARTED exists"; exit 1; }
mkdir -p "$D"
{ date -u +%FT%TZ; sha256sum "$LINES"; } > "$D/STARTED"
"$P" --record > "$D/pin-before.txt" 2>&1
"$P" bash "${S:?}/probe/call.sh" "$L" "$A" "$LINES" > "$D/runner.log" 2>&1
rc=$?
"$P" --record > "$D/pin-after.txt" 2>&1
python3 -I - "$D/out.json" > "$D/status.jsonl" <<'PY'
import json, sys
try:
    res = json.load(open(sys.argv[1], encoding="utf-8"))["results"]
except Exception as e:
    print(json.dumps({"error": "no out.json: " + str(e)[:200]})); raise SystemExit
for r in res:
    print(json.dumps({"id": r.get("id"), "answered": r.get("isAnswered"), "reason": ("threw" if "threw" in r else r.get("reason")),
                      "status": r.get("status"), "output_tokens": (r.get("usage") or {}).get("output_tokens"), "ms": r.get("ms")}))
PY
echo "rc=$rc $(date -u +%FT%TZ)" > "$D/RUNNER-EXIT"
