#!/bin/bash
# learn-notes 1.13.0 batch 0: impl113/backup/b0-calib.tar (plan calibration.backup, after the calibration), paths relative to the scratchpad.
# Raw pre/ and rounds/ session folders (stream.jsonl, debug.log, record.json: resolved model ids) are left out; their id-free
# copies are in impl113/b0/calibtar/stage (redact.py). Any listed file still holding a model id is left out by path.
SP=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad
OUT="$SP/impl113/backup/b0-calib.tar"
[ -e "$OUT" ] && { echo "refuse: $OUT exists"; exit 1; }
cd "${SP:?}" || exit 1
L="$SP/impl113/b0/calibtar/list.txt"
{
  echo impl113/cli/PIN.txt; echo impl113/cli/pinned.sh; echo impl113/cli/pinned.diff
  echo impl113/NAMES-all.txt; echo impl113/b0/names
  echo impl113/b0/probe
  for f in prompt.txt lines-haiku.jsonl lines-sonnet.jsonl runner.sh runner.diff tools.sha256 dry hm-haiku.json hm-sonnet.json gate-haiku-1.json gate-sonnet-1.json results.sha256; do echo impl113/b0/calib/$f; done
  echo impl113/b0/calibtar/redact.py; echo impl113/b0/calibtar/make-calib-tar.sh; echo impl113/b0/calibtar/stage
  for f in alias/one.sh alias/run.sh alias/jobs.txt alias/STARTED alias/DONE real/one.sh real/run.sh real/jobs.txt real/STARTED real/DONE alias-one.sh.diff alias-run.sh.diff real-one.sh.diff real-run.sh.diff SHA256SUMS; do echo impl113/b0/alias/$f; done
} > "$L"
X="$SP/impl113/b0/calibtar/excluded-model-id.txt"
while read -r p; do
  if [ -d "$p" ]; then grep -rlE 'claude-(haiku|sonnet|opus|fable)-[0-9]' "$p" 2>/dev/null; elif [ -f "$p" ]; then grep -lE 'claude-(haiku|sonnet|opus|fable)-[0-9]' "$p" 2>/dev/null; fi
done < "$L" | sort -u > "$X"
tar --create --file "$OUT" --owner=0 --group=0 --sort=name --exclude-from="$X" --files-from="$L"
chmod 444 "$OUT"
sha256sum "$OUT"; stat -c %s "$OUT"; tar -tf "$OUT" | grep -vc '/$'
