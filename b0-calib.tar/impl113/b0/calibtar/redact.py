"""Id-free copies for the b0-calib backup tar (plan backup (2)): small per-session files as they are,
record.json and the alias tables with every resolved model id replaced by a placeholder.
usage: redact.py <impl113/b0 dir> <out dir>"""
import json, os, re, shutil, sys
B, OUT = sys.argv[1], sys.argv[2]
ID = re.compile(r"(?:us\.)?(?:anthropic\.)?claude-[a-z]+-[0-9][A-Za-z0-9.@:_-]*")
names = {}
def ph(m):
    s = m.group(0)
    if s not in names:
        fam = re.search(r"claude-([a-z]+)-", s).group(1)
        base = {"haiku": "haiku", "sonnet": "sonnet"}.get(fam, fam)
        names[s] = f"<{base}-id-{sum(1 for v in names.values() if v.startswith('<'+base+'-'))+1}>"
    return names[s]
def red(text): return ID.sub(ph, text)
KEEP = {"STARTED", "RUNNER-EXIT", "started.txt", "ended.txt", "exit.txt", "version.txt", "version-before.txt",
        "version-after.txt", "pin-before.txt", "pin-after.txt", "status.jsonl", "input.jsonl", "out.json", "record.json"}
for kind in ("pre", "rounds"):
    for lab in sorted(os.listdir(os.path.join(B, "calib", kind))):
        src = os.path.join(B, "calib", kind, lab); dst = os.path.join(OUT, "calib-redacted", f"{kind}-{lab}")
        os.makedirs(dst, exist_ok=True)
        for f in sorted(os.listdir(src)):
            if f in KEEP:
                t = open(os.path.join(src, f), encoding="utf-8").read()
                open(os.path.join(dst, f), "w", encoding="utf-8").write(red(t))
for rel in ("alias/table.tsv", "real/table-real.txt"):
    t = open(os.path.join(B, "alias", rel), encoding="utf-8").read()
    os.makedirs(os.path.join(OUT, "alias-redacted"), exist_ok=True)
    open(os.path.join(OUT, "alias-redacted", rel.replace("/", "-")), "w", encoding="utf-8").write(red(t))
# the mapping itself holds ids: it is NOT written into the tar folder; only the placeholder count is
print(json.dumps({"placeholders": len(names)}, ensure_ascii=False))
