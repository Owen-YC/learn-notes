#!/bin/bash
F="/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b3r/fix"
for m in head mD mA; do (cd "$F/$m" && "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh" claude plugin test . > "$F/sub-$m.log" 2>&1; echo $? > "$F/sub-$m.exit"); done
echo DONE > "$F/run.status"
