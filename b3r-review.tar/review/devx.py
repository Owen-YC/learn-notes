"""Review (G3 retry, audit point 4): compare the 83 frozen G3-retry records with the G3-dev-retry records
(every JSON value with a name and code in the result.txt files NAMES-dev-retry.txt names) by name, quote (n6) and
runlib.clause3 (가)(다), the way tools/check.py does for the earlier corpus. Read only; prints JSON."""
import json, re, sys, os
S = sys.argv[1]
sys.path.insert(0, f"{S}/b3r/tools")
import runlib
from check import quote_of

def walk(x, out):
    if isinstance(x, dict):
        if isinstance(x.get("name"), str) and any(isinstance(x.get(k), str) for k in ("code", "lines", "after", "blurb")):
            out.append(x)
        for v in x.values(): walk(v, out)
    elif isinstance(x, list):
        for v in x: walk(v, out)

def values(text):
    dec, i, out = json.JSONDecoder(), 0, []
    while i < len(text):
        j = min([p for p in (text.find("{", i), text.find("[", i)) if p >= 0], default=-1)
        if j < 0: break
        try:
            v, e = dec.raw_decode(text, j); out.append(v); i = e
        except ValueError:
            i = j + 1
    return out

srcs = sorted({l.rstrip("\n").split("\t")[2] for l in open(f"{S}/b3r/dev/NAMES-dev-retry.txt", encoding="utf-8") if l.strip()})
dev = []
for s in srcs:
    p = os.path.join(os.path.dirname(S), s)
    for v in values(open(p, encoding="utf-8").read()):
        recs = []; walk(v, recs)
        for r in recs: r["_src"] = s; dev.append(r)
raw = json.load(open(f"{S}/b3/frozen/raw.json", encoding="utf-8"))
new = []; walk(raw, new)
code = lambda r: r.get("code") if isinstance(r.get("code"), str) else r.get("lines") if isinstance(r.get("lines"), str) else r.get("after") if isinstance(r.get("after"), str) else None
lang = lambda r: runlib.lang_of_file(r.get("file") or "") if r.get("file") else None
key = lambda n: re.sub(r"\s+", "", n)
hits = {"name": [], "quote": [], "code": []}
for r in new:
    _, q = quote_of(r.get("blurb")); qn = runlib.n6(q) if q else None
    for o in dev:
        if key(r["name"]) == key(o["name"]): hits["name"].append([r.get("id"), o["name"], o["_src"]])
        _, oq = quote_of(o.get("blurb"))
        if qn and oq and runlib.n6(oq) == qn: hits["quote"].append([r.get("id"), o.get("id"), o["_src"]])
        a, b = code(r), code(o)
        if a and b and lang(r) and lang(r) == lang(o):
            c = runlib.clause3(a, b, lang(r)) or runlib.clause3(b, a, lang(r))
            if c in ("가", "다"): hits["code"].append([r.get("id"), o.get("id"), c, o["_src"]])
print(json.dumps({"frozen": len(new), "dev": len(dev), "srcs": len(srcs), "hits": {k: len(v) for k, v in hits.items()}, "detail": hits}, ensure_ascii=False, indent=1))
