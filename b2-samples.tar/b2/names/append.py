"""learn-notes 1.12.0 G2 (batch 2; from b1/names/append.py): append this batch's measured names to impl112/NAMES-all.txt
right after the sample freeze (견본.md '이름 목록' 덧붙임). Names = every id, concept name and file path of
frozen/raw.json (every record as written, used or not), and every name a record's code defines (function/def/class,
export const/let, top-level const NAME = ( / function / arrow). Tag G2-measured, source impl112/b2/frozen/raw.json.
Also writes names/overlap.json: names and paths already in NAMES-all.txt before the append (record only). Sorted in
byte order, duplicate lines dropped; chmod 444 again.
usage: append.py   (model calls 0; refuses when G2-measured lines are already there)"""
import hashlib, json, os, re
SP = "/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad"
NAMES = SP + "/impl112/NAMES-all.txt"
RAW = SP + "/impl112/b2/frozen/raw.json"
SRC = os.path.relpath(RAW, SP)
old = [l for l in open(NAMES, "rb").read().decode("utf-8").split("\n") if l]
if any(l.split("\t")[1] == "G2-measured" for l in old if "\t" in l):
    raise SystemExit("refuse: G2-measured already appended")
before = {l.split("\t")[0] for l in old}
DEF = [re.compile(p, re.M) for p in (r"\bfunction\s*\*?\s*([A-Za-z_$][\w$]*)", r"^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)",
       r"^\s*class\s+([A-Za-z_$][\w$]*)", r"^\s*export\s+(?:const|let|var)\s+([A-Za-z_$][\w$]*)",
       r"^(?:const|let)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\(|function|[A-Za-z_$][\w$]*\s*=>)")]
ids, cnames, defined, paths = set(), set(), set(), set()
for s in json.load(open(RAW, encoding="utf-8")):
    ids.add(s["id"])
    if s.get("name"):
        cnames.add(s["name"].replace("\t", " ").replace("\n", " "))
    if s.get("file"):
        paths.add(s["file"])
    for t in (s.get("code") or "", s.get("before") or "", s.get("after") or ""):
        for p in DEF:
            defined.update(m.group(1) for m in p.finditer(t))
names = ids | cnames | paths | defined
rows = set(old) | {f"{n}\tG2-measured\t{SRC}" for n in names}
lines = sorted(rows, key=lambda s: s.encode("utf-8"))
os.chmod(NAMES, 0o644)
open(NAMES, "wb").write(("\n".join(lines) + "\n").encode("utf-8"))
os.chmod(NAMES, 0o444)
ov = {"namesAlready": sorted(cnames & before), "definedAlready": sorted(defined & before), "pathsAlready": sorted(paths & before)}
json.dump(ov, open(SP + "/impl112/b2/names/overlap.json", "w"), ensure_ascii=False, indent=1)
print(json.dumps({"lines": len(lines), "added": len(lines) - len(old), "measuredNames": len(names), "ids": len(ids),
                  "conceptNames": len(cnames), "paths": len(paths), "defined": len(defined),
                  "overlapNames": len(ov["namesAlready"]), "overlapDefined": len(ov["definedAlready"]), "overlapPaths": ov["pathsAlready"],
                  "sha256": hashlib.sha256(open(NAMES, "rb").read()).hexdigest()}, ensure_ascii=False))
