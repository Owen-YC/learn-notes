#!/bin/bash
# strip D26: the frozen tools on a clone of main with the strip patch applied (strip/check/repo); pinned CLI first on PATH.
export DISABLE_AUTOUPDATER=1
cd /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/strip/d26
date -u +%FT%TZ > STARTED
node --experimental-transform-types --no-warnings /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/d26/rulewide113.mjs /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/strip/check/repo /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/strip/d26/out-rw --extra /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/../impl112/b1/audit/d26x/extra.json > rw.log 2> rw.err; echo $? > rw.exit
/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/cli/pinned.sh /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/d26/g2haiku.sh /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/strip/check/repo /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/strip/d26/out-g2 > g2.log 2>&1; echo $? > g2.exit
date -u +%FT%TZ > DONE
