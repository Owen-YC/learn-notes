# s1: the alias re-check after the grading call (5b9acb0, 'during the call') removed: the cap writes code's feedback although modelOverrides changed mid-call.
import sys
p=sys.argv[1]+'/hooks/register.tsx'; s=open(p,encoding='utf8').read()
a="""parsed.verdict === 'right' && (await recheckRemap($)) ? ruleFixUse"""
assert s.count(a)==1; s=s.replace(a,"""parsed.verdict === 'right' ? ruleFixUse"""); open(p,'w',encoding='utf8').write(s); print('s1 ok')
