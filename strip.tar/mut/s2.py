# s2: the cap's same-shape swap check dropped (batch-1 M8): a swap of a name the rule avoids is no longer capped.
import sys
p=sys.argv[1]+'/hooks/notes.ts'; s=open(p,encoding='utf8').read()
a="    if (isShape && moved.length > 0 && !isReorder) return { why: 'swap', from: moved[0]!.from, to: moved[0]!.to }\n"
assert s.count(a)==1; s=s.replace(a,""); open(p,'w',encoding='utf8').write(s); print('s2 ok')
