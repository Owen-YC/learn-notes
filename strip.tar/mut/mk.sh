#!/bin/bash
# usage: mk.sh <name> <python-replace-file> <test file>  -- copy the stripped repo working tree, apply one mutation, run one test file (pinned CLI)
X=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/strip/mut
N="$1"; P="$2"; T="$3"
D="$X/$N"
[ -n "$N" ] && [ ! -e "$D" ] || { echo "refuse $D"; exit 2; }
mkdir -p "$D" && cd /home/user/learn-notes && git ls-files -z | xargs -0 -I{} sh -c 'test -e "$1" && cp --parents "$1" "$2"/' _ {} "$D"
git -c core.quotePath=false diff --name-only --diff-filter=M -z | xargs -0 -I{} cp {} "$D/{}"
cp -r /home/user/learn-notes/.claude-plugin/types "$D/.claude-plugin/"
python3 -I "$P" "$D" > "$D.mut.txt" 2>&1 || { echo "mutation failed"; cat "$D.mut.txt"; exit 3; }
cd "$D" && /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/cli/pinned.sh claude plugin test --file "$T" . > "$D.log" 2>&1
echo "exit=$?" >> "$D.log"
python3 -I - "$D.log" > "$D.sum" <<'PY'
import sys,json
for line in open(sys.argv[1],encoding='utf8'):
    if line.startswith('claude-plugin-test-report '):
        r=json.loads(line[len('claude-plugin-test-report '):])
        print(r['file'], 'tests', len(r['results']), 'failed', sum(1 for x in r['results'] if x['failure']))
        for x in r['results']:
            if x['failure']: print('FAIL', x['title'][-200:])
PY
