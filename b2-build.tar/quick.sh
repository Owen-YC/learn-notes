#!/bin/bash
# quick.sh <test file names...>: run only these test files from the repo working tree in a scratch copy (pinned CLI)
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2
P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/cli/pinned.sh
export DISABLE_AUTOUPDATER=1
rm -rf "${S:?}/quick"; mkdir -p "$S/quick/tests"
cd /home/user/learn-notes || exit 1
cp -r hooks types .claude-plugin tsconfig.json "$S/quick/"; cp tests/flowkit.ts "$S/quick/tests/"; cp -r tests/fixtures "$S/quick/tests/"
for t in "$@"; do cp "tests/$t" "$S/quick/tests/"; done
cd "$S/quick" && "$P" claude plugin test .
