import * as A from '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/trees/de98243/hooks/notes.ts'
import * as B from '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2/tree/hooks/notes.ts'
let same = 0, diff = 0; const bad: string[] = []
const base = { count: 3, firstAt: 0, lastAt: 0, files: ['a.js'] }
const exts = ['a.js', 'a.py', 'a.ts', 'a.mjs', 'a.go']
const cmp = (label: string, a: unknown, b: unknown) => { const x = JSON.stringify(a), y = JSON.stringify(b); x === y ? same++ : (diff++, bad.push(label)) }
// rungOf with the default (OFF) constants for many step / file / due combos; and B with rungNewStep Infinity explicit
for (const step of [0, 1, 2, 3, 4, 5, 6]) for (const f of exts) for (const isDue of [true, false]) for (const missed of [false, true]) {
  const one = { ...base, key: 'k', name: 'n', blurb: '비동기 `setTimeout(f)` 타입 힌트', step } as any
  const how = { code: { file: f, text: 'setTimeout(()=>1)\nx: int = 3' }, isAsking: false, isTeam: false, isDue }
  cmp(`rungOf ${step} ${f} ${isDue}`, A.rungOf(one, how), B.rungOf(one, { ...how, isNewMissed: missed }))
}
// quizPrompt & checkPrompt with real-ish 1.9.0 shapes (worked, mine, slip, team, codeless)
for (const level of ['beginner', 'intermediate', 'advanced'] as const) for (const r of [undefined, 'mine', 'worked'] as const) for (const team of [false, true]) {
  const mk = (i: number) => ({ ...base, key: 'k' + i, name: 'n' + i, blurb: 'b `x = 1`', ...(team && i === 2 ? { team: true } : {}), code: { file: 'a.js', text: 'x = 1\nconsole.log(x)' } })
  const picks = [mk(1), mk(2), { ...base, key: 'k3', name: 'n3', blurb: 'b3', slip: { what: 'w', question: 'q', mine: 'm' } }].map((p, i) => A.pickForRung(p as any, i === 0 ? r : undefined))
  const picksB = [mk(1), mk(2), { ...base, key: 'k3', name: 'n3', blurb: 'b3', slip: { what: 'w', question: 'q', mine: 'm' } }].map((p, i) => B.pickForRung(p as any, i === 0 ? r : undefined))
  cmp(`quizPrompt ${level} ${r} ${team}`, A.quizPrompt(picks as any, level), B.quizPrompt(picksB as any, level))
  const reply = 'T1: 예측\nQ1: 다음을 보세요\n```js\nconsole.log(1)\n```\nH1: h\nA1: 1\nT2: 왜\nQ2: q2\nH2: h\nA2: a2\nT3: 바꿔 보기\nQ3: q3\nH3: h3\nA3: a3'
  cmp(`parseQuiz ${level} ${r} ${team}`, A.parseQuiz(reply, picks as any), B.parseQuiz(reply, picksB as any))
}
for (const level of ['beginner', 'intermediate', 'advanced'] as const) for (const kind of [undefined, 'predict', 'why', 'modify'] as const) for (const rung of [undefined, 'mine', 'worked', 'new'] as const)
  for (const first of [undefined, { mine: '3', verdict: 'wrong', feedback: 'f', nudge: 'n' }, { mine: '모르겠어요', verdict: 'wrong', feedback: '', nudge: 'h' }, { mine: '3', verdict: 'partial', feedback: 'f', nudge: 'n' }] as any[])
    for (const bases of [undefined, ['b1']]) for (const rule of [undefined, '규칙']) {
      const item = { name: 'n', question: '처음 보는 코드입니다. 이 코드를 실행하면 무엇이 출력될까요? 찍히는 줄마다 차례로 쓰세요. 여러 줄이면 쉼표로 이어 한 줄에 써도 됩니다.\n```js\nconsole.log(1)\n```', answer: '1\n2', kind, ...(rung ? { rung } : {}) }
      const ex: any = { ...(bases ? { bases } : {}), ...(rule ? { rule } : {}) }
      cmp(`checkPrompt ${level} ${kind} ${rung}`, A.checkPrompt(item as any, 'ans', level, first, undefined, ex), B.checkPrompt(item as any, 'ans', level, first, undefined, ex))
    }
for (const t of ['판정: 거의\n피드백: f\n되묻기: n', '판정: 맞음\n피드백: f', '{"verdict":"틀림","feedback":"x"}', '값 1: 3\n판정: 맞음\n피드백: f', '판정: 틀림\n피드백: f\n헷갈린 점: x\n유형: 값과 참조'])
  cmp('parseCheck', A.parseCheck(t), B.parseCheck(t, {}))
console.log(`vs 1.11.0 OFF: ${same} same, ${diff} different`); console.log(bad.slice(0, 20).join('\n'))
