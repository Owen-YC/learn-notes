"""learn-notes 1.13.0 batch 2 build: mutation probes on a fresh copy of the repo working tree (records only).
The design's 12 mutants (impl113/design/G2/proofs/mut3/muts3.py) with the evaluator ones pointed at hooks/newrun.ts
(the module layout), plus 'run-missed-off' (an empty reply or timeout of a run-route quiz no longer writes changedMissed)."""
import sys, shutil, subprocess
S = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2'
R = '/home/user/learn-notes'
MUTS = {
 'skip-own-cert': ('hooks/notes.ts', "return 'lines' in ran && isCertified(ran.lines, run.out) ? { changedLine, changed, lines: ran.lines } : undefined", "return 'lines' in ran ? { changedLine, changed, lines: ran.lines } : undefined"),
 'store-model-N': ('hooks/notes.ts', "      answer: use.lines.join('\\n'),", "      answer: (parts.get(`N${n}`) ?? use.lines).join('\\n').trim(),"),
 'no-fallback': ('hooks/notes.ts', "  const use = own ?? cert\n", "  if (!own) return { reason: 'value' } as unknown as ChangedRunRead\n  const use = own\n"),
 'allow-decimal-own': ('hooks/notes.ts', "(site.kind === 'number' && (!/^\\d+$/.test(said) || Number(said) > numberBound(site.token)))", "(site.kind === 'number' && Number(said) > numberBound(site.token))"),
 'drop-certs-2': ('hooks/notes.ts', "(how.code.run?.certs.length ?? 0) >= 2", "(how.code.run?.certs.length ?? 0) >= 0"),
 'drop-subset': ('hooks/notes.ts', "    if (o.some((_, at) => at + n.length <= o.length && n.every((line, i) => line === o[at + i]))) return false\n    if (n.every((line, i) => i < o.length && line === o[i])) return false\n  }\n  return true", "  }\n  return true"),
 'allow-container': ('hooks/newrun.ts', "  throw new Refuse('print-value', 'print of an object')\n}\n/** console.log of two", "  return String(v)\n}\n/** console.log of two"),
 'allow-format': ('hooks/newrun.ts', "  if (typeof args[0] === 'string' && args[0].includes('%')) throw new Refuse('print-value', 'print of a format')\n", ""),
 'allow-decimal': ('hooks/notes.ts', "    if (!/^\\d+$/.test(site.token)) return []\n    const n = Number(site.token)", "    const n = Number(site.token)"),
 'isown-always': ('hooks/notes.ts', "    isOwn: own !== undefined,", "    isOwn: true,"),
 'drop-loose-key': ('hooks/notes.ts', "  for (const key of [outputSame, looseSame]) {", "  for (const key of [outputSame]) {"),
 'run-without-flag': ('hooks/register.tsx', "const run = isWhole && changedRun ? changedRunFor", "const run = isWhole ? changedRunFor"),
 'run-missed-off': ('hooks/register.tsx', "      await miss('changedMissed', keysOf(picks, 'changed'))\n      await miss('newMissed', keysOf(picks, 'new'))", "      await miss('newMissed', keysOf(picks, 'new'))"),
}
name = sys.argv[1]
f, a, b = MUTS[name]
d = f'{S}/mut/{name}'
shutil.rmtree(d, ignore_errors=True)
for p in ['hooks', 'types', '.claude-plugin', 'tests']:
    shutil.copytree(f'{R}/{p}', f'{d}/{p}')
shutil.copy(f'{R}/tsconfig.json', f'{d}/tsconfig.json')
t = open(f'{d}/{f}').read(); assert t.count(a) == 1, name
open(f'{d}/{f}', 'w').write(t.replace(a, b))
print('mutated', name, f)
