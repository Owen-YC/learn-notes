// 1.13.0 batch 2 build: NEW = impl113/b2/tree (copy of the repo working tree), OLD = impl113/b2/oldprobe/30adc2f. Was batch 1 build (NEW b1/tree, OLD b1/oldprobe/30adc2f). Was: 1.12.0 batch 1 build (copy of design/G6/final/tools/probe_off.mjs, NEW = the batch tree copy b1/tree): every OFF read and request of the final tree equals 1.11.0's (de98243) to the byte, over the
// pilot's note texts (ON, OFF, the anchor-free variant, W2 off), the same texts with the final task, and the rule19
// fixture: drillOf / hideDrillAnswer / shareText with the switch off and by default, askPrompt, keptNoteText (with and
// without the rule names), notePrompt, drillQuestion, checkPrompt (with and without a rule) and parseCheck.
import { readFileSync, existsSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
const D = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/design/G6'
const NEW = await import(pathToFileURL(`/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2/tree/hooks/notes.ts`).href)
const OLD = await import(pathToFileURL(`/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2/oldprobe/30adc2f/hooks/notes.ts`).href)
const K = await import(pathToFileURL(`${D}/tools/notekit.mjs`).href)
const FX = await import(pathToFileURL(`/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2/tree/tests/fixtures/rule19.ts`).href)
const PROTO_TASK = '바뀐 코드에서 팀 규칙과 다른 한 줄을 규칙대로 고쳐 보세요.'
const teamMd = readFileSync(`${D}/team.md`, 'utf8')
const tn = NEW.parseTeamFile(teamMd), to = OLD.parseTeamFile(teamMd)
const J = p => JSON.parse(readFileSync(p, 'utf8'))
let n = 0
const bad = []
const same = (what, a, b) => { n += 1; if (JSON.stringify(a) !== JSON.stringify(b)) bad.push({ what, a: JSON.stringify(a)?.slice(0, 300), b: JSON.stringify(b)?.slice(0, 300) }) }
function reads(id, t, changes) {
  for (const M of [[NEW, 'n'], [OLD, 'o']]) void M
  same(`${id} drillOf off`, NEW.drillOf(t, changes, false), OLD.drillOf(t, changes, false))
  same(`${id} drillOf default`, NEW.drillOf(t, changes), OLD.drillOf(t, changes))
  for (const how of [undefined, { isRuleDrill: false }, { isTool: true }, { isRuleDrill: false, isTool: true }, { isRuleDrill: true, isTool: true }]) {
    same(`${id} hide ${JSON.stringify(how)}`, NEW.hideDrillAnswer(t, changes[0]?.file, how), OLD.hideDrillAnswer(t, changes[0]?.file, how))
  }
  const note = { at: Date.UTC(2026, 10, 4), text: t, changes, moreFiles: 0, withheld: [], root: '/proj', prompt: '요청', status: 'ready', asks: [] }
  same(`${id} share off`, NEW.shareText(note, ['개념'], false), OLD.shareText(note, ['개념'], false))
  same(`${id} share default`, NEW.shareText(note, ['개념']), OLD.shareText(note, ['개념']))
  same(`${id} ask`, NEW.askPrompt(note, '왜요?', 'beginner', tn), OLD.askPrompt(note, '왜요?', 'beginner', to))
  const dn = NEW.drillOf(t, changes, false), dold = OLD.drillOf(t, changes, false)
  if (dn && dold) {
    same(`${id} question`, NEW.drillQuestion(dn), OLD.drillQuestion(dold))
    const item = { name: '개념', question: NEW.drillQuestion(dn), answer: dn.example, kind: 'modify' }
    same(`${id} check`, NEW.checkPrompt(item, 'x = 1', 'beginner'), OLD.checkPrompt(item, 'x = 1', 'beginner'))
    same(`${id} check rule`, NEW.checkPrompt(item, 'x = 1', 'beginner', undefined, undefined, { rule: 'r' }), OLD.checkPrompt(item, 'x = 1', 'beginner', undefined, undefined, { rule: 'r' }))
  }
}
let texts = 0
for (const set of ['set1', 'set2', 'set3']) {
  const samples = J(`${D}/dev/${set}/samples.json`)
  const hunks = Object.fromEntries(J(`${D}/dev/${set}/hunks.json`).map(o => [o.id, o]))
  for (const model of ['haiku', 'sonnet']) {
    const path = `${D}/pilot/${set}/read${set === 'set1' ? '-r1' : ''}-${model}.json`
    const rows = J(path)
    for (const s of samples) {
      const r = rows[s.id]
      if (!r?.answered) continue
      same(`${set}/${model}/${s.id} kept []`, NEW.keptNoteText(r.reply, []), OLD.keptNoteText(r.reply, []))
      same(`${set}/${model}/${s.id} kept names`, NEW.keptNoteText(r.reply, NEW.ruleNamesOf(tn.rules)), OLD.keptNoteText(r.reply, OLD.ruleNamesOf(to.rules)))
      const nn = K.noteOf(NEW, hunks[s.id], s), no = K.noteOf(OLD, hunks[s.id], s)
      same(`${set}/${model}/${s.id} notePrompt`, NEW.notePrompt(NEW.screenNote(nn, [], () => false), 'beginner', [], tn), OLD.notePrompt(OLD.screenNote(no, [], () => false), 'beginner', [], to))
      const all = [r.on, r.off, r.offW0, r.variant].filter(x => typeof x === 'string')
      for (const t of new Set([...all, ...all.map(x => x.split(PROTO_TASK).join(NEW.RULE_FIX_TASK))])) { reads(`${set}/${model}/${s.id}`, t, r.changes); texts += 1 }
    }
  }
}
const B1 = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1'
const bs = J(`${B1}/frozen/samples.json`)
const bh = Object.fromEntries(J(`${B1}/frozen/hunks.json`).map(o => [o.id, o]))
for (const L of ['P', 'Q']) for (const R of ['A', 'B']) {
  const rows = J(`${B1}/audit/n2j/${L}/read-${R}.json`)
  for (const s of bs) {
    const r = rows[s.id]
    if (!r?.answered) continue
    same(`b1/${L}${R}/${s.id} kept []`, NEW.keptNoteText(r.reply, []), OLD.keptNoteText(r.reply, []))
    same(`b1/${L}${R}/${s.id} kept names`, NEW.keptNoteText(r.reply, NEW.ruleNamesOf(tn.rules)), OLD.keptNoteText(r.reply, OLD.ruleNamesOf(to.rules)))
    const nn = K.noteOf(NEW, bh[s.id], s), no = K.noteOf(OLD, bh[s.id], s)
    same(`b1/${s.id} notePrompt`, NEW.notePrompt(NEW.screenNote(nn, [], () => false), 'beginner', [], tn), OLD.notePrompt(OLD.screenNote(no, [], () => false), 'beginner', [], to))
    for (const t of new Set([r.on, r.off])) { reads(`b1/${L}${R}/${s.id}`, t, r.changes); texts += 1 }
  }
}
const I = FX.INPUT_RULE19
const USER = I.note.changes
reads('rule19', I.note.text, USER)
for (const reply of I.replies) for (const asked of [{}, { rule: true }]) same(`parseCheck ${JSON.stringify(asked)}`, NEW.parseCheck(reply, asked), OLD.parseCheck(reply, asked))
same('CHECK_SYSTEM', NEW.CHECK_SYSTEM, OLD.CHECK_SYSTEM)
console.log(JSON.stringify({ texts, comparisons: n, differ: bad.length, bad: bad.slice(0, 10) }, null, 1))
