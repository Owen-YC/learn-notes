// batch 2 build (records): newRun of hooks/newrun.ts (batch tree) vs newRun of the design's tree-final notes.ts on the wide programs, both under node.
import { readFileSync } from 'node:fs'
const A = await import('/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2/tree/hooks/newrun.ts')
const B = await import('/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G2/proto/tree-final/hooks/notes.ts')
const rows = readFileSync('/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/design/G2/final/wide/progs.jsonl', 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l))
let differ = 0
for (const r of rows) for (const opts of [{ printArgs: true }, {}]) if (JSON.stringify(A.newRun(r.code, r.lang, opts)) !== JSON.stringify(B.newRun(r.code, r.lang, opts))) differ++
console.log(`programs ${rows.length} × 2 (printArgs on / off): differ ${differ}`)
