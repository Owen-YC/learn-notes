#!/bin/bash
# batch 2 build: each mutant (tools/mut.py) against run113, flow113g2, d34g2, changed112, route (+ flow110, flow1819 where named); records only.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2
P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/cli/pinned.sh
export DISABLE_AUTOUPDATER=1
M=$S/mut
[ -e "$M/STARTED" ] && { echo "refuse: STARTED exists"; exit 9; }
date -u +%FT%TZ > "$M/STARTED"
: > "$M/result.txt"
for m in "$@"; do
  python3 -I "$S/tools/mut.py" "$m" > /dev/null || { echo "== $m APPLY-FAILED" >> "$M/result.txt"; continue; }
  echo "== $m" >> "$M/result.txt"
  keep="run113.test.ts flow113g2.test.ts d34g2.test.ts changed112.test.ts route.test.ts"
  case $m in run-without-flag|drop-certs-2|isown-always) keep="$keep flow110.test.ts";; run-missed-off) keep="$keep flow1819.test.ts";; esac
  ( cd "$M/$m/tests" && for f in *.test.ts; do case " $keep " in *" $f "*) ;; *) rm -f "$f";; esac; done )
  ( cd "$M/$m" && "$P" claude plugin test . > "$M/$m.out" 2>&1 )
  grep -E "^\(fail\)| fail$| pass$" "$M/$m.out" | sed 's/ \[[0-9.]*ms\]//' | cut -c1-200 >> "$M/result.txt"
  rm -rf "${M:?}/$m"
done
echo DONE >> "$M/result.txt"
date -u +%FT%TZ > "$M/DONE"
