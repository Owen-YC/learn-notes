// module probe (batch 2): one function moved out of notes.ts

export function unquoted(text: string): string {
  return text
    .replace(/``(.+?)``|`([^`]+)`/g, '')
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/\s*[—–:,·-]\s*$/, '')
    .trim()
}
