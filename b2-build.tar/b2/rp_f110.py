import sys; sys.path.insert(0,'/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2'); import tblock as T
p='tests/flow110.test.ts'; s=open(p).read()
def rep(block, old, new, n=1):
    assert block.count(old)==n, (old[:90], block.count(old)); return block.replace(old,new)
s=rep(s,"  BASE_LEAD,\n  DRILL_RULE_AFTER,","  BASE_LEAD,\n  CHANGED_HINT,\n  CHANGED_LEAD,\n  DRILL_RULE_AFTER,")
# --- G7 every switch on: alias reads
t="a route with every switch on (a harness"
b=T.get(s,t)
b=rep(b,"""    // Read at session start, again by each of the day's three questions while 생각해 보기 is on (r, e and /learn 질문:
    // askNote, 1.11.0 review) and by /learn 진단.
    expect(reads).toEqual(Array.from({ length: 5 }, () => SONNET_ALIAS))""","""    // Read at session start, again by each of the day's three questions while 생각해 보기 is on (r, e and /learn 질문:
    // askNote, 1.11.0 review), by each of its two quizzes while code changed or code never seen is on (makeQuiz's
    // recheckRemap, 1.12.0 G2 · G3; re-pinned on purpose) and by /learn 진단.
    expect(reads).toEqual(Array.from({ length: 7 }, () => SONNET_ALIAS))""")
s=T.put(s,t,b)
# --- cross-route rung test (changed variant)
old="""        // Code never seen is asked of js and py alone (1.12.0 G3): its concepts are met in a.js.
        const editA = rung === 'new' ? { ...EDIT_A, file_path: '/proj/src/a.js' } : EDIT_A
        if (rung === 'new') w.files.set('/proj/src/a.js', 'const a = 1\\nconst b = 2\\n')"""
new="""        // Code never seen is asked of js and py alone (1.12.0 G3): its concepts are met in a.js. Code changed only of a
        // JavaScript or Python file written whole (1.12.0 G2): its concepts are met in a.js written so (ROUTE_WHOLE).
        const editA = rung === 'new' ? { ...EDIT_A, file_path: '/proj/src/a.js' } : { tool: 'Write', tool_use_id: 'u1', file_path: '/proj/src/a.js', content: ROUTE_WHOLE }
        if (rung === 'new') w.files.set('/proj/src/a.js', 'const a = 1\\nconst b = 2\\n')
        else w.files.set('/proj/src/a.js', ROUTE_WHOLE)"""
s=rep(s,old,new)
old="""        const quizReply = () => [routeCode(1, isNew), routeCode(2, isNew), routeCode(3, isNew)].join('\\n')"""
new="""        const quizReply = () => [routeCode(1, isNew, !isNew), routeCode(2, isNew, !isNew), routeCode(3, isNew, !isNew)].join('\\n')"""
s=rep(s,old,new)
old="""  const routeCode = (n: number, isNew: boolean) =>
    [
      `T${n}: 예측`,"""
new="""  const routeCode = (n: number, isNew: boolean, isChanged = false) =>
    [
      // Where code changed is asked (1.12.0 G2), its C · O · N lines over ROUTE_WHOLE, read for that pick alone.
      ...(isChanged ? [`C${n}: ${n}a 10`, 'const items = [10, 4]', `O${n}:`, '7', `N${n}:`, '14'] : []),
      `T${n}: 예측`,"""
s=rep(s,old,new)
old="""  type RouteNote = { id: string; text: string }"""
new="""  /** A file written whole in code changed's scope (1.12.0 G2): three places to change, one print. */
  const ROUTE_WHOLE = ['const items = [3, 4]', 'let total = 0', 'for (const item of items) total += item', 'console.log(total)', ''].join('\\n')
  type RouteNote = { id: string; text: string }"""
s=rep(s,old,new)

# --- G2 describe
old="""  const CHANGED_TRACE = 'R1: (칸이 "비슷한 코드"인 문제만: 보인 코드를 한 줄씩 따라간 과정)'"""
new="""  /**
   * 1.12.0 (G2): REPLY with COMP's C · O · N for its first number (the plugin makes its question from them: the code
   * changed at 1e, `!=`, and what it prints); the other two numbers read as before.
   */
  const REPLY_CON = [
    'C1: 1e !=',
    'evens = [n for n in nums if n % 2 != 0]',
    'O1:',
    '[2, 4]',
    'N1:',
    '[1, 3]',
    'T2: 예측',
    'Q2: 아래 코드는 무엇을 찍을까요?\\n```js\\nconsole.log([1, 2].length)\\n```',
    'H2: 길이를 세어 보세요',
    'A2: 2',
    'T3: 왜',
    'Q3: 왜 화살표 함수로 썼을까요?',
    'A3: 짧게 쓰려고',
  ].join('\\n')
  const CHANGED_TRACE = 'R1: (칸이 "비슷한 코드"인 문제만: 보인 코드를 한 줄씩 따라간 과정)'"""
s=rep(s,old,new)
old="""    reads.isArmed = true
    const before = calls.length
    w.answer = REPLY
    const listed = (await learn($, '퀴즈 새로')).text ?? ''"""
new="""    reads.isArmed = true
    const before = calls.length
    w.answer = reply
    const listed = (await learn($, '퀴즈 새로')).text ?? ''"""
s=rep(s,old,new)
s=rep(s,"async function quizWorld($: Engine, on: On, harness: Record<string, unknown> | null, store = storeOf(), setup: (w: World) => void = () => {}) {",
       "async function quizWorld($: Engine, on: On, harness: Record<string, unknown> | null, store = storeOf(), setup: (w: World) => void = () => {}, reply = REPLY) {")
t="the request pinned, made outside the plugin as the design"
b=T.get(s,t)
head=b[:b.index("    const { w, store, calls, reads, listed }")]
new=head+"""    // 1.12.0 (G2, re-pinned on purpose): code changed asks only of a JavaScript or Python file written whole (COMP in
    // EVENS; REDUCE and ARROW, met in an edit to CART, in their own code), by the plugin's own sentence and C · O · N,
    // its question made by the plugin; no file is read for it (1.10.0 read CART for its imports). The request's bytes
    // are pinned by d34g2 and changed112; 1.10.0's (CHANGED_QUIZ_ON) is sent no more.
    const { w, store, calls, reads, listed } = await quizWorld($, on, { rungChangedStep: 2 }, storeOf(), () => {}, REPLY_CON)
    expect(calls).toHaveLength(1)
    expect(calls[0]).toMatchObject({ model: 'haiku', effort: 'low', system: QUIZ_SYSTEM, maxTokens: 4600, timeoutMs: 90_000 })
    expect(calls[0]!.prompt).not.toBe(CHANGED_QUIZ_ON.prompt)
    expect(calls[0]!.prompt).toContain(`1. ${COMP} — 조건에 맞는 것만 모아 새 리스트를 만듭니다 — \\`[n for n in nums if n % 2 == 0]\\`\\n   칸: 비슷한 코드\\n   학습자가 만든 코드 (evens.py):\\n\\`\\`\\`\\n${EVENS_TEXT}\\`\\`\\`\\n   바꿀 수 있는 곳 (줄은 위 코드의 첫 줄을 1로 셈):\\n   1a: 1번째 줄의 \\`1\\` (`)
    expect(calls[0]!.prompt.split('   칸: 비슷한 코드\\n').length).toBe(2)
    expect(calls[0]!.prompt.split('   칸: 내 코드\\n   학습자가 만든 코드 (cart.js)').length).toBe(3)
    expect(calls[0]!.prompt).toContain('\\nC1: (고른 곳 이름, 한 칸 띄우고 새 값만. 예: 1b 20)\\n')
    expect(calls[0]!.prompt).not.toContain('R1:')
    expect(reads).toMatchObject({ cart: 0, evens: 0 })
    expect(calls[0]!.prompt).not.toContain('console.log(total([{ price: 3, qty: 2 }]))')
    expect(itemsOf(store)[0]).toMatchObject({ name: COMP, rung: 'changed', kind: 'predict', answer: '[1, 3]', hint: CHANGED_HINT(2, 'evens = [n for n in nums if n % 2 != 0]') })
    expect(String(itemsOf(store)[0]!.question)).toBe(`${CHANGED_LEAD}\\n\\`\\`\\`python\\n${EVENS_TEXT.replace('== 0', '!= 0')}\\`\\`\\``)
    expect(JSON.stringify(store.get('quiz'))).not.toContain('[2, 4]')
    expect(listed).toContain(`\\n1. (비슷한 코드) ${CHANGED_LEAD}`)
    const ui = await pane($, 'terminal', { ...PANE_PROPS, isFocused: true })
    await ui.press({ key: 'view-quiz' })
    expect(await ui.find({ type: 'Text', text: /^문제 1\\/3 · 비슷한 코드 · 예측$/ })).toBeDefined()
    await ui.unmount()
    const version = ((await learn($, '진단')).text ?? '').split('\\n').find(line => line.startsWith('- 버전: '))
    expect(version).toContain('시험 스위치: 비슷한 코드 단계 2')
    expect(w.budgets.at(-1)).toBe(4600)
  })

"""
s=T.put(s,t,new)
old="""      const { calls, reads } = await quizWorld($, on, { models: { sonnet: { rungChangedStep: 2 } } })
      expect(calls).toEqual([{ ...(model === 'haiku' ? CHANGED_QUIZ_OFF : CHANGED_QUIZ_ON), model }])
      expect(reads.cart).toBe(model === 'haiku' ? 0 : 2)"""
new="""      const { calls, reads } = await quizWorld($, on, { models: { sonnet: { rungChangedStep: 2 } } })
      // 1.12.0 (G2, re-pinned on purpose): on, the plugin's own sentence and C · O · N (1.10.0's CHANGED_QUIZ_ON no
      // more), sent as sonnet; no file read either way.
      if (model === 'haiku') expect(calls).toEqual([{ ...CHANGED_QUIZ_OFF, model }])
      else {
        expect(calls).toHaveLength(1)
        expect(calls[0]).toMatchObject({ model, effort: 'low', system: QUIZ_SYSTEM, maxTokens: 4600, timeoutMs: 90_000 })
        expect(calls[0]!.prompt).toContain('\\n   칸: 비슷한 코드\\n   학습자가 만든 코드 (evens.py):')
        expect(calls[0]!.prompt).toContain('\\nC1: (고른 곳 이름, 한 칸 띄우고 새 값만. 예: 1b 20)\\n')
      }
      expect(reads.cart).toBe(0)"""
s=rep(s,old,new)
old="""    expect(prompt).not.toContain('비슷한 코드')
    expect(prompt).toContain(NEW_TRACE)
    expect(prompt).not.toContain(CHANGED_TRACE)
    expect(fresh.calls[0]!.maxTokens).toBe(4600)"""
new="""    expect(prompt).not.toContain('비슷한 코드')
    // 1.12.0 (G3, re-pinned on purpose): code never seen's K · L · A, no R line.
    expect(prompt).toContain('\\nK1:\\n```python\\n(코드)\\n```\\nL1: ')
    expect(prompt).not.toContain('R1:')
    expect(prompt).not.toContain(CHANGED_TRACE)
    expect(fresh.calls[0]!.maxTokens).toBe(4600)"""
s=rep(s,old,new)
old="""    expect(prompt).not.toContain("from './math'")
    expect(reads).toMatchObject({ cart: 2, evens: 0 })"""
new="""    expect(prompt).not.toContain("from './math'")
    // 1.12.0 (G2, re-pinned on purpose): code changed asks only of a file written whole, so the edited file is not read.
    expect(reads).toMatchObject({ cart: 0, evens: 0 })"""
s=rep(s,old,new)
old="""    expect([reads.cart, prompt.includes('   칸: 비슷한 코드\\n   학습자가 만든 코드 (cart.js)')]).toEqual([2, false])"""
new="""    // 1.12.0 (G2, re-pinned on purpose): an edited file is never read for code changed (it asks of files written whole).
    expect([reads.cart, prompt.includes('   칸: 비슷한 코드\\n   학습자가 만든 코드 (cart.js)')]).toEqual([0, false])"""
s=rep(s,old,new)
old="""    expect(prompt).not.toContain('비슷한 코드')
    expect(reads).toMatchObject({ cart: 1, evens: 0 })"""
new="""    expect(prompt).not.toContain('비슷한 코드')
    // 1.12.0 (G2, re-pinned on purpose): its file not read either (code changed asks of files written whole alone).
    expect(reads).toMatchObject({ cart: 0, evens: 0 })"""
s=rep(s,old,new)

# --- G3 describe
old="""  const OTHER_Q = '아래 코드의 b는 무엇일까요?\\n```js\\nconst { a, b } = { a: 1, b: 2 }\\nconsole.log(b)\\n```'"""
new="""  const OTHER_Q = '아래 코드의 b는 무엇일까요?\\n```js\\nconst { a, b } = { a: 1, b: 2 }\\nconsole.log(b)\\n```'
  /**
   * 1.12.0 (G3): a grade of the prediction as the exact grade now asks it, the learner's values copied line by line (the
   * second one 3, so the plugin reads it wrong), with a question back; and the same with no question back.
   */
  const VALUES = ['값 1: 7', '값 2: 3', `피드백: ${WRONG_FIRST.feedback}`, `되묻기: ${WRONG_FIRST.nudge}`, '헷갈린 점: 배열 길이를 마지막 값으로 봄', '유형: 경계값'].join('\\n')
  const VALUES_AGAIN = '값 1: 7\\n값 2: 3\\n피드백: 둘째 줄이 아직 다릅니다.'
  /** The stored item as the grade reads it. */
  const ITEM = { name: NAME, question: CHECK_ITEM_110.question, answer: CHECK_ITEM_110.answer, kind: 'predict' as const, rung: 'new' as const }"""
s=rep(s,old,new)
t="on (a harness\\'s 4): the prediction graded line by line, the design"
b=T.get(s,t)
head=b[:b.index("    const { w, store, calls } = await opened($, on, { rungNewStep: 4 })")]
new=head+"""    // 1.12.0 (G3, re-pinned on purpose): graded by copying the learner's values line by line, the plugin deciding
    // right or wrong (1.10.0's preview, NEW_EXACT_110, is sent no more); its try again right from the values alone, no call.
    const { w, store, calls } = await opened($, on, { rungNewStep: 4 })
    const ui = await pane($, 'terminal', { ...PANE_PROPS, isFocused: true })
    await ui.press({ key: 'view-quiz' })
    w.answer = VALUES
    await ui.input({ key: mineKey(store, 0), text: MINE })
    await w.clock.settle()
    expect(calls.at(-1)).toEqual({ model: 'haiku', effort: 'low', system: CHECK_SYSTEM, prompt: checkPrompt(ITEM, MINE, 'beginner', undefined, undefined, { exact: true }), maxTokens: 480, timeoutMs: 60_000 })
    expect(calls.at(-1)!.prompt).not.toBe(NEW_EXACT_110['none · beginner'])
    expect((await ui.find({ type: 'Text', text: '✗ 아직입니다 · 한 번 더 떠올려 보세요' }))?.props.color).toBe('red')
    expect(await ui.find({ type: 'Text', text: '△ 아직입니다 · 방향은 맞습니다' })).toBeUndefined()
    expect(itemsOf(store)[0]!.firstTry).toMatchObject({ mine: MINE, verdict: 'wrong', feedback: WRONG_FIRST.feedback, nudge: WRONG_FIRST.nudge })
    expect(JSON.stringify(store.get('quiz'))).not.toContain('값 2')
    // Its try again, right: every value in order, the plugin's own grade; right, its step as it was.
    const count = calls.length
    await ui.input({ key: `${mineKey(store, 0)}-again`, text: '7, 2' })
    await w.clock.settle()
    expect(calls).toHaveLength(count)
    expect(itemsOf(store)[0]).toMatchObject({ result: 'right', rung: 'new' })
    expect(conceptOf(store, NAME).step).toBe(4)
    // The 내 코드 question of the same quiz: 1.9.0's grade, no 값 lines.
    w.answer = RIGHT
    await ui.input({ key: mineKey(store, 1), text: '2요' })
    await w.clock.settle()
    const other = itemsOf(store)[1]! as { name: string; question: string; answer: string; kind: 'predict' }
    expect(calls.at(-1)).toEqual({ model: 'haiku', effort: 'low', system: CHECK_SYSTEM, prompt: checkPrompt(other, '2요', 'beginner'), maxTokens: 480, timeoutMs: 60_000 })
    expect(calls.at(-1)!.prompt).not.toContain('값 1:')
    expect(calls.at(-1)!.prompt).toContain('판정은 셋 중 하나다.')
    await ui.unmount()
  })

"""
s=T.put(s,t,new)
t="on: 거의 both times, read 틀림 each time"
b=T.get(s,t)
head=b[:b.index("    const { w, store, calls } = await opened($, on, { rungNewStep: 4 })")]
new=head+"""    // 1.12.0 (G3, re-pinned on purpose): no verdict is asked at all (거의 neither); the learner's values copied, short of
    // right both times: one step back, no missedAt, the sentence for code never seen.
    const { w, store, calls } = await opened($, on, { rungNewStep: 4 })
    w.answer = VALUES
    expect((await learn($, `퀴즈 1 ${MINE}`)).text).toContain('1번 ✗ 아직입니다 · 한 번 더 떠올려 보세요 · ')
    const first = itemsOf(store)[0]!.firstTry as never
    w.answer = VALUES_AGAIN
    await learn($, `퀴즈 1 ${MINE}`)
    expect(calls.at(-1)!.prompt).toBe(checkPrompt(ITEM, MINE, 'beginner', first, undefined, { exact: true }))
    expect(calls.at(-1)!.prompt).not.toContain('거의')
    expect(itemsOf(store)[0]).toMatchObject({ result: 'wrong', verdict: 'wrong', rung: 'new' })
    expect(conceptOf(store, NAME).step).toBe(3)
    expect(conceptOf(store, NAME).missedAt).toBeUndefined()
    w.answer = RIGHT
    expect((await learn($, '퀴즈 2 2요')).text).toContain(`${NEW_MISS}.`)
  })

"""
s=T.put(s,t,new)
t="on: 모르겠어요, its hint, then an answer"
b=T.get(s,t)
old="""    w.answer = '대조: 1줄 같음, 2줄 다름\\n판정: 틀림\\n피드백: 둘째 줄이 다릅니다.\\n헷갈린 점: 배열 길이를 마지막 값으로 봄\\n유형: 경계값'
    await learn($, `퀴즈 1 ${MINE}`)
    expect(calls.at(-1)!.prompt).toBe(NEW_EXACT_110['hint · beginner'])"""
new="""    // 1.12.0 (G3, re-pinned on purpose): the values copied, the hint said, no question back (1.10.0's preview no more).
    w.answer = '값 1: 7\\n값 2: 3\\n피드백: 둘째 줄이 다릅니다.\\n헷갈린 점: 배열 길이를 마지막 값으로 봄\\n유형: 경계값'
    await learn($, `퀴즈 1 ${MINE}`)
    expect(calls.at(-1)!.prompt).toBe(checkPrompt(ITEM, MINE, 'beginner', { mine: '모르겠어요', verdict: 'wrong', feedback: '', nudge: HINT }, undefined, { exact: true }))
    expect(calls.at(-1)!.prompt).not.toBe(NEW_EXACT_110['hint · beginner'])
    expect(calls.at(-1)!.prompt).toContain(`\\n받은 힌트: ${HINT}\\n`)
    expect(calls.at(-1)!.prompt).not.toContain('\\n되묻기: (')"""
b=rep(b,old,new)
s=T.put(s,t,b)
t="(6/7 검토) its first try graded 거의 by a window with it off (haiku as shipped)"
b=T.get(s,t)
old="""    w.answer = '대조: 1줄 같음, 2줄 다름\\n판정: 거의\\n피드백: 둘째 줄이 아직 다릅니다.'
    await learn($, `퀴즈 1 ${MINE}`)
    expect(calls.at(-1)).toEqual({ model: 'haiku', effort: 'low', system: CHECK_SYSTEM, prompt: NEW_EXACT_110['wrong · beginner'], maxTokens: 480, timeoutMs: 60_000 })
    expect(calls.at(-1)!.prompt.match(/거의/g)).toHaveLength(1)
    expect(itemsOf(store)[0]).toMatchObject({ result: 'wrong', verdict: 'wrong', rung: 'new' })
    expect(JSON.stringify(store.get('quiz'))).not.toContain('2줄 다름')"""
new="""    // 1.12.0 (G3, re-pinned on purpose): the try again copies the learner's values; its first try's 거의 is not said at
    // all (its answer only, said wrong), so 거의 is nowhere; short of right again: one step back.
    w.answer = VALUES_AGAIN
    await learn($, `퀴즈 1 ${MINE}`)
    expect(calls.at(-1)).toEqual({ model: 'haiku', effort: 'low', system: CHECK_SYSTEM, prompt: checkPrompt(ITEM, MINE, 'beginner', itemsOf(store)[0]!.firstTry as never, undefined, { exact: true }), maxTokens: 480, timeoutMs: 60_000 })
    expect(calls.at(-1)!.prompt).not.toBe(NEW_EXACT_110['wrong · beginner'])
    expect(calls.at(-1)!.prompt.match(/거의/g)).toBeNull()
    expect(itemsOf(store)[0]).toMatchObject({ result: 'wrong', verdict: 'wrong', rung: 'new' })
    expect(JSON.stringify(store.get('quiz'))).not.toContain('값 2')"""
b=rep(b,old,new)
s=T.put(s,t,b)
# stamps loop
old="""  for (const [v, isOpen] of [
    ['1.9.0', true],
    ['1.8.0', true],
    ['1.10.0', false],
  ] as const) {
    test(`on, a ${v} window stamped 20 minutes ago: ${isOpen ? 'asked in its own code, no sentence for code never seen (NEW_GRADER_SINCE)' : 'nothing kept off, asked in code never seen'}`, async ($, on) => {
      const { prompt, maxTokens } = await quizOf($, on, { rungNewStep: 4 }, (_w, store) => store.set('sessions', { 'session-other': { v, at: NOW - 20 * 60_000 } }))
      expect(prompt.includes('   칸: 처음 보는 코드 (ts로)')).toBe(!isOpen)
      expect(prompt.includes('처음 보는 코드:')).toBe(!isOpen)
      expect(prompt.includes(`1. ${NAME} — `)).toBe(true)
      expect(prompt.includes('\\n   칸: 내 코드\\n   학습자가 만든 코드 (a.ts):')).toBe(isOpen)
      expect(maxTokens).toBe(isOpen ? 3400 : 4600)
    })
  }"""
new="""  // 1.12.0 (G3, re-pinned on purpose): NEW_GRADER_SINCE is 1.12.0, so a 1.10 or 1.11 window keeps it off too; its
  // concept met in a.js written whole (TypeScript is out of its scope), with KLA_REPLY.
  for (const [v, isOpen] of [
    ['1.9.0', true],
    ['1.8.0', true],
    ['1.10.0', true],
    ['1.11.0', true],
    ['1.12.0', false],
  ] as const) {
    test(`on, a ${v} window stamped 20 minutes ago: ${isOpen ? 'asked in its own code, no sentence for code never seen (NEW_GRADER_SINCE)' : 'nothing kept off, asked in code never seen'}`, async ($, on) => {
      const { prompt, maxTokens } = await quizOf($, on, { rungNewStep: 4 }, (_w, store) => store.set('sessions', { 'session-other': { v, at: NOW - 20 * 60_000 } }), FILLERS, { path: '/proj/src/a.js', content: [...LINES, ''].join('\\n') }, KLA_REPLY)
      expect(prompt.includes('   칸: 처음 보는 코드 (js로)')).toBe(!isOpen)
      expect(prompt.includes('처음 보는 코드:')).toBe(!isOpen)
      expect(prompt.includes(`1. ${NAME} — `)).toBe(true)
      expect(prompt.includes('\\n   칸: 내 코드\\n   학습자가 만든 코드 (a.js):')).toBe(isOpen)
      expect(maxTokens).toBe(isOpen ? 3400 : 4600)
    })
  }"""
s=rep(s,old,new)
# move LINES above quizOf use: define LINES earlier (it is defined after the loop); define KLA_REPLY near QUIZ_REPLY
old="""  /** Two concepts met in no note and not due for weeks: they fill a quiz to three picks (D33). */
  const FILLERS = ['채움 하나', '채움 둘']"""
new="""  /**
   * 1.12.0 (G3): a reply whose first number is code never seen's K · L · A (code not the learner's, printing 10) and a
   * prediction in code too (for a pick in its own code), the two after it plain.
   */
  const KLA_REPLY = [
    'K1:',
    '```js',
    'const scores = [5, 1, 4]',
    'let best = 0',
    'for (const s of scores) best += s',
    'console.log(best)',
    '```',
    'L1: for (const s of scores) best += s',
    'T1: 예측',
    'Q1: 아래 코드는 무엇을 찍을까요?\\n```js\\nconsole.log(1 + 9)\\n```',
    'A1:',
    '10',
    'T2: 왜',
    'Q2: 문제 2',
    'A2: 답 2',
    'T3: 왜',
    'Q3: 문제 3',
    'A3: 답 3',
  ].join('\\n')
  /** Two concepts met in no note and not due for weeks: they fill a quiz to three picks (D33). */
  const FILLERS = ['채움 하나', '채움 둘']
  /** A file written whole, its loop the line NAME's words quote (`for (const n of nums)`). */
  const LINES = ['const nums = [1, 2]', 'for (const n of nums) console.log(n)', ...Array.from({ length: 14 }, (_, i) => `// line ${i + 1}`)]"""
s=rep(s,old,new)
s=rep(s,"""  const LINES = ['const nums = [1, 2]', 'for (const n of nums) console.log(n)', ...Array.from({ length: 14 }, (_, i) => `// line ${i + 1}`)]
  for (const isFetched of [true, false]) {""","""  for (const isFetched of [true, false]) {""")
s=rep(s,"""  async function quizOf($: Engine, on: On, harness: Record<string, unknown> | null, setup: (w: World, store: Map<string, unknown>) => void = () => {}, fillers = FILLERS, write?: { path: string; content: string }) {""",
"""  async function quizOf($: Engine, on: On, harness: Record<string, unknown> | null, setup: (w: World, store: Map<string, unknown>) => void = () => {}, fillers = FILLERS, write?: { path: string; content: string }, reply = QUIZ_REPLY) {""")
s=rep(s,"""    w.answer = QUIZ_REPLY
    await learn($, '퀴즈 새로')
    return { w, store, prompt: w.models.at(-1)!, maxTokens: w.budgets.at(-1)! }""","""    w.answer = reply
    await learn($, '퀴즈 새로')
    return { w, store, prompt: w.models.at(-1)!, maxTokens: w.budgets.at(-1)! }""")
old="""      const { store, prompt } = await quizOf($, on, { rungNewStep: 4 }, () => {}, FILLERS, { path: '/proj/src/a.js', content: [...LINES, last, ''].join('\\n') })"""
new="""      // 1.12.0 (G3, re-pinned on purpose): read from K · L · A (KLA_REPLY).
      const { store, prompt } = await quizOf($, on, { rungNewStep: 4 }, () => {}, FILLERS, { path: '/proj/src/a.js', content: [...LINES, last, ''].join('\\n') }, KLA_REPLY)"""
s=rep(s,old,new)
open(p,'w').write(s); print('ok')
