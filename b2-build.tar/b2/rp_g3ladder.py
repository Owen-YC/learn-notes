import sys,re; sys.path.insert(0,'/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2'); import tblock as T
p='tests/ladder.test.ts'; s=open(p).read()
t="with `exact`: the design"
b=T.get(s,t)
head=b[:b.index("    for (const level")]
new="""    // 1.12.0 (G3, re-pinned on purpose): the exact grade is for a question the plugin made from K · L · A (its lead);
    // a 1.10.0 question in code never seen (NEW, the model's own words) is graded by 1.9.0's grade even with `exact`,
    // and 1.10.0's exact bytes (NEW_EXACT_110) are no request's.
    for (const level of ['beginner', 'intermediate', 'advanced'] as const) {
      for (const f of ['none', 'wrong', 'hint'] as const) {
        const got = checkPrompt(NEW, CHECK_MINE_110, level, CHECK_FIRSTS_110[f], undefined, { exact: true })
        expect(got).toBe(checkPrompt(NEW, CHECK_MINE_110, level, CHECK_FIRSTS_110[f], undefined))
        expect(got).not.toBe(NEW_EXACT_110[`${f} · ${level}`]!)
      }
    }
    // The plugin's own question: its values copied line by line, no verdict asked, 거의 nowhere.
    const KLA = { ...NEW, question: `${NEW_LEAD}\\n${NEW.question.slice(NEW.question.indexOf('```'))}` }
    const first = checkPrompt(KLA, CHECK_MINE_110, 'beginner', undefined, undefined, { exact: true })
    expect(first).toContain('\\n이 문제는 판정을 쓰지 않는다. 값 줄에 옮긴 값을 플러그인이 모범 답과 줄마다 견주어 맞음과 틀림을 정한다.')
    expect(first).toContain('\\n값 1: (학습자가 1줄에 찍힌다고 말한 값만. 말하지 않았으면 (말하지 않음))\\n값 2: (')
    expect(first).not.toContain(THREE_WAY)
    expect(first).not.toContain(PREDICT_CHECK)
    expect(first).not.toContain('판정: (')
    expect(first.match(/거의/g)).toBeNull()
    const again = checkPrompt(KLA, CHECK_MINE_110, 'beginner', CHECK_FIRSTS_110.wrong, undefined, { exact: true })
    expect(again).toContain('\\n마지막 시도다. 되묻기는 쓰지 않는다.\\n')
    expect(again).not.toContain('\\n되묻기: (')
    expect(again.match(/거의/g)).toBeNull()
    expect(again.endsWith('\\n피드백: (한두 문장)')).toBe(true)
  })

"""
s=T.put(s,t,head+new)
t="with `exact`, a try again whose first try a window with it off graded"
b=T.get(s,t)
head=b[:b.index("    // The first try")]
new="""    // 1.12.0 (G3, re-pinned on purpose): on the plugin's own question the first try's verdict is not said at all (its
    // answer only, said wrong), so 거의 is nowhere; a 1.10.0 question (NEW) is graded by 1.9.0's grade, 거의 said as it says it.
    const KLA = { ...NEW, question: `${NEW_LEAD}\\n${NEW.question.slice(NEW.question.indexOf('```'))}` }
    const partial = { ...CHECK_FIRSTS_110.wrong!, verdict: 'partial' as const }
    for (const level of ['beginner', 'intermediate', 'advanced'] as const) {
      const got = checkPrompt(KLA, CHECK_MINE_110, level, partial, undefined, { exact: true })
      expect(got).toContain('\\n첫 답: (틀렸다. 이번 답의 값을 옮길 때 보지 않는다)\\n')
      expect(got).not.toContain('첫 판정')
      expect(got.match(/거의/g)).toBeNull()
      expect(checkPrompt(NEW, CHECK_MINE_110, level, partial, undefined, { exact: true })).toBe(checkPrompt(NEW, CHECK_MINE_110, level, partial, undefined))
    }
    for (const past of Object.values(CHECK_PASTS_110)) {
      const again = checkPrompt(KLA, CHECK_MINE_110, 'beginner', CHECK_FIRSTS_110.partial, past, { exact: true })
      expect(again).not.toContain('첫 판정: 거의')
      expect(again.match(/거의/g)).toBeNull()
    }
    // A window with it off (no `exact`), or a question it does not take: the first try's 거의 said as 1.9.0 says it.
    expect(checkPrompt(NEW, CHECK_MINE_110, 'beginner', CHECK_FIRSTS_110.partial, undefined)).toBe(CHECK_19['predict · partial · none · beginner']!)
    expect(CHECK_19['predict · partial · none · beginner']).toContain('\\n첫 판정: 거의\\n')
    expect(checkPrompt(itemOf('why', 'new'), CHECK_MINE_110, 'beginner', CHECK_FIRSTS_110.partial, undefined, { exact: true })).toBe(CHECK_19['why · partial · none · beginner']!)
  })

"""
s=T.put(s,t,head+new)
t="(D29) code of the five patterns"
b=T.get(s,t)
old="""        rungOf: rungOf(one, { ...plain, code }, Infinity, { changedStep: 2 }) ?? null,
      }
      expect([row.id, got]).toEqual([
        row.id,
        { isUnrunnableCode: row.isUnrunnableCode, isUnrunnableChangeCreate: row.isUnrunnableChangeCreate, isUnrunnableChangeEdit: row.isUnrunnableChangeEdit, workedBranch: row.workedBranch, rungOf: row.rungOf },
      ])
      // Code never seen on (4): none of them is asked so; each is asked as it would be with that rung off.
      expect([row.id, rungOf(one, { ...plain, code }, 4, { changedStep: 2 })]).toEqual([row.id, row.rungOf])"""
new="""        rungOf: rungOf(one, { ...plain, code }, Infinity, { changedStep: 2 }) ?? null,
      }
      // 1.12.0 (G2, re-pinned on purpose): none of these is a file shown whole, so where the tree before G3 asked it in
      // code changed it is asked in its own code; every other reading as it was.
      const rung110 = row.rungOf === 'changed' ? 'mine' : row.rungOf
      expect([row.id, got]).toEqual([
        row.id,
        { isUnrunnableCode: row.isUnrunnableCode, isUnrunnableChangeCreate: row.isUnrunnableChangeCreate, isUnrunnableChangeEdit: row.isUnrunnableChangeEdit, workedBranch: row.workedBranch, rungOf: rung110 },
      ])
      // Code never seen on (4): none of them is asked so; each is asked as it would be with that rung off.
      expect([row.id, rungOf(one, { ...plain, code }, 4, { changedStep: 2 })]).toEqual([row.id, rung110])"""
assert b.count(old)==1,'d29'; s=T.put(s,t,b.replace(old,new))
t="rungOf and the change: a due .js concept at its fifth step"
b=T.get(s,t)
old="""    expect(rungOf(at(4), { ...plain, code: { ...quoted, isNewLibrary: true } }, 4, ON)).toBe('changed')"""
new="""    // 1.12.0 (G2, re-pinned on purpose): lines of an edit are no file shown whole: its own code, not code changed.
    expect(rungOf(at(4), { ...plain, code: { ...quoted, isNewLibrary: true } }, 4, ON)).toBe('mine')"""
assert b.count(old)==1,'rc'; s=T.put(s,t,b.replace(old,new))
open(p,'w').write(s); print('ok')
