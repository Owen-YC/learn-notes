#!/bin/bash
# b2 OFF-byte proofs (the G3 prototype's off tools, A = the released build, B = the tree given): offbytes and off111
# against de98243 (1.11.0), off190b against fca5988 (1.9.0). usage: run.sh <tree notes.ts> <outdir>
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2
B=$1; O=$2; mkdir -p "$O"
for spec in offbytes.mts:de98243 offsplit.mts:de98243 off111.ts:de98243 off190b.ts:fca5988; do
  f=${spec%%:*}; c=${spec##*:}
  sed -e "s#__A__#$S/trees/$c/hooks/notes.ts#" -e "s#__B__#$B#" $S/off/$f > "$O/run-$f"
  ext=${f##*.}; cp "$O/run-$f" "$O/run-${f%.*}.mts"
  node --experimental-transform-types --no-warnings "$O/run-${f%.*}.mts" > "$O/${f%.*}.out" 2>&1
  echo "$f vs $c: $(head -1 $O/${f%.*}.out)"
done
