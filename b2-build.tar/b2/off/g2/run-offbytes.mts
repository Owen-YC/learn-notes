import * as A from '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/trees/de98243/hooks/notes.ts'
import * as B from '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/off/../wt-g2/hooks/notes.ts'
let same = 0, diff = 0
const base = { count: 3, firstAt: 0, lastAt: 0, files: ['a.js'] }
const mk = (rung: any, i: number) => ({ ...base, key: 'k' + i, name: 'n' + i, blurb: '설명 `x = 1` ' + i, code: { file: i % 2 ? 'a.py' : 'a.js', text: 'x = 1\nprint(x)' } })
const rungs = [undefined, 'mine', 'changed', 'worked']
for (const level of ['beginner', 'intermediate', 'advanced'] as const)
  for (const r1 of rungs) for (const r2 of rungs) for (const slip of [false, true]) {
    const picks = [mk(r1, 1), mk(r2, 2), { ...base, key: 'k3', name: 'n3', blurb: 'b', ...(slip ? { slip: { what: 'w', question: 'q', mine: 'm' } } : {}) }]
      .map((p, i) => A.pickForRung(p as any, [r1, r2, undefined][i] as any))
    const a = A.quizPrompt(picks as any, level), b = B.quizPrompt(picks as any, level)
    a === b ? same++ : diff++
    const items = 'T1: 예측\nQ1: q\nH1: h\nA1: a\nT2: 왜\nQ2: q2\nA2: a2\nR3: r\nQ3: x\nA3: y'
    JSON.stringify(A.parseQuiz(items, picks as any)) === JSON.stringify(B.parseQuiz(items, picks as any)) ? same++ : diff++
  }
const item = (rung: any, kind: any) => ({ name: 'n', question: 'q', answer: '1\n2', kind, ...(rung ? { rung } : {}) })
for (const level of ['beginner', 'intermediate', 'advanced'] as const)
  for (const rung of [undefined, 'mine', 'changed', 'worked', 'new']) for (const kind of [undefined, 'predict', 'why', 'modify'])
    for (const first of [undefined, { mine: '3', verdict: 'wrong', feedback: 'f', nudge: 'n' }, { mine: '모르겠어요', verdict: 'wrong', feedback: '', nudge: 'h' }, { mine: '3', verdict: 'partial', feedback: 'f', nudge: 'n' }])
      for (const past of [undefined, { what: 'w', mine: 'm' }]) {
        const a = A.checkPrompt(item(rung, kind) as any, 'ans', level, first as any, past as any, {})
        const b = B.checkPrompt(item(rung, kind) as any, 'ans', level, first as any, past as any, {})
        a === b ? same++ : diff++
      }
for (const t of ['판정: 거의\n피드백: f\n되묻기: n', '판정: 맞음\n피드백: f', '{"verdict":"틀림","feedback":"x"}', '피드백: f\n판정: 틀림\n대조: 1줄 같음'])
  JSON.stringify(A.parseCheck(t, {})) === JSON.stringify(B.parseCheck(t, {})) ? same++ : diff++
console.log(`OFF paths: ${same} same, ${diff} different`)
