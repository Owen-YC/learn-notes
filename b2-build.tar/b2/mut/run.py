# b2 mutation probes: each mutation on a copy of the repo working tree; the G2/G3/joint test files run; record which fail.
import json, os, shutil, subprocess, sys, concurrent.futures as cf
S='/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/mut'
R='/home/user/learn-notes'; PIN='/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh'
TESTS=['changed112.test.ts','new112.test.ts','flow112g3.test.ts','d34g2.test.ts','d34g3.test.ts','flow1819.test.ts']
def one(m):
    name, f, old, new = m
    d=os.path.join(S,name)
    if os.path.isdir(d): shutil.rmtree(d)
    os.makedirs(d+'/tests')
    for x in ['hooks','types','.claude-plugin']: shutil.copytree(os.path.join(R,x), os.path.join(d,x))
    shutil.copy(os.path.join(R,'tsconfig.json'), d)
    os.symlink(os.path.join(R,'node_modules'), os.path.join(d,'node_modules'))
    shutil.copytree(os.path.join(R,'tests/fixtures'), os.path.join(d,'tests/fixtures')); shutil.copy(os.path.join(R,'tests/flowkit.ts'), d+'/tests/')
    for t in TESTS: shutil.copy(os.path.join(R,'tests',t), d+'/tests/')
    p=os.path.join(d,f); s=open(p).read()
    if s.count(old)!=1: return f'{name}: NOT APPLIED (count {s.count(old)})'
    open(p,'w').write(s.replace(old,new))
    out=subprocess.run([PIN,'claude','plugin','test','.'],cwd=d,capture_output=True,text=True,timeout=1200).stdout
    open(d+'.out','w').write(out)
    fails=[l for l in out.splitlines() if l.startswith('(fail)')]
    cur=''; per={}
    for l in out.splitlines():
        if l.startswith('tests/') and l.endswith(':'): cur=l[6:-1]
        if l.startswith('(fail)'): per[cur]=per.get(cur,0)+1
    shutil.rmtree(d)
    return f"{name}: {len(fails)} fail {json.dumps(per)} :: " + ' | '.join(x.split(' > ')[-1][:90] for x in fails[:3])
muts=json.load(open(S+'/muts.json'))
with cf.ThreadPoolExecutor(3) as ex:
    for r in ex.map(one, muts): print(r, flush=True)
