import sys; sys.path.insert(0,'/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2'); import tblock as T
p='tests/flow1819.test.ts'; s=open(p).read()
def rep(block, old, new, n=1):
    assert block.count(old)==n, (old[:80], block.count(old)); return block.replace(old,new)
# ---- shared helpers after imports
anchor="import { THINK19_R, THINK19_SYSTEM, THINK19_TYPED } from './fixtures/think19'\n"
s=rep(s, "  checkPrompt,\n  cleanConcepts,", "  CHANGED_HINT,\n  CHANGED_LEAD,\n  NEW_LEAD,\n  checkPrompt,\n  cleanConcepts,")
i=s.index("\ndescribe(")
helpers='''
/**
 * 1.12.0 (G2 · G3): the file code changed and code never seen ask of now, a.js written whole (a JavaScript file shown
 * whole, in their scope), its line `for (const item of items)` the one CONCEPT_NOTE's words quote; the Write that makes it.
 */
const FILE_JS = ['const items = [3, 4]', 'let total = 0', 'for (const item of items) total += item', 'console.log(total)', ''].join('\\n')
const WRITE_JS = { tool: 'Write', tool_use_id: 'w1', file_path: '/proj/src/a.js', content: FILE_JS } as const
/** A reply's slot `n` for code never seen (K · L · A, 1.12.0 G3), its code not the learner's (isLikeMine); it prints 10. */
const KLA = (n: number) => [`K${n}:`, '```js', 'const scores = [5, 1, 4]', 'let best = 0', 'for (const s of scores) best += s', 'console.log(best)', '```', `L${n}: for (const s of scores) best += s`, `A${n}:`, '10'].join('\\n')
/** A reply's slot `n` for code changed in FILE_JS (C · O · N, 1.12.0 G2): its first place (`3`) made 10. */
const CON = (n: number) => [`C${n}: ${n}a 10`, 'const items = [10, 4]', `O${n}:`, '7', `N${n}:`, '14'].join('\\n')
/**
 * A reply's slot `n` read either way (1.12.0 G3): K · L · A where its pick is in code never seen, T · Q · A where it is
 * not; A the same printed value, so a test need not know which number each concept took.
 */
const EITHER = (n: number) => [KLA(n).replace(`A${n}:\\n10`, ''), `T${n}: 예측`, `Q${n}: 아래 코드는 무엇을 찍을까요?`, '```js', 'console.log(1 + 9)', '```', `A${n}:`, '10'].join('\\n')
'''
s=s[:i]+helpers+s[i:]

# ---- E3 1.8.0 test
t="a concept at its third step is asked in its code changed: 비슷한 코드 in the pane"
b=T.get(s,t)
head=b[:b.index("    const w = world(on, 'ok', null, true, store)")]
new=head+'''    const w = world(on, 'ok', null, true, store)
    // On as 1.8.0 shipped it, whatever its constant (1.9.0 F4 turned it off by its sample): a harness's step.
    w.harness = { rungChangedStep: 2 }
    // 1.12.0 (G2, re-pinned on purpose): code changed is made by the plugin from the model's C · O · N, only for a
    // JavaScript or Python file written whole (a.js here); its question the plugin's own, over the code it changed.
    w.files.set('/proj/src/a.js', FILE_JS)
    await start($)
    w.answer = CONCEPT_NOTE([name])
    await turn($, () => $.tool.call(WRITE_JS))
    await finish(w)
    expect(conceptOf(store, name).step).toBe(2)
    const ui = await quizIn($, w, CON(1))
    const prompt = w.models.at(-1)!
    expect(prompt).toContain(`\\n   칸: 비슷한 코드\\n   학습자가 만든 코드 (a.js):\\n\\`\\`\\`\\n${FILE_JS.trimEnd()}\\n\\`\\`\\`\\n   바꿀 수 있는 곳 (줄은 위 코드의 첫 줄을 1로 셈):\\n   1a: `)
    expect(prompt).toContain('\\n2. 채움 하나 — 채움 하나 설명\\n3. 채움 둘 — 채움 둘 설명\\n')
    expect(prompt).toContain('비슷한 코드: 이 칸은 문제 글을 쓰지 않는다. 문제와 바꾼 코드는 플러그인이 만든다.')
    expect(prompt).toContain('\\nC1: (고른 곳 이름, 한 칸 띄우고 새 값만. 예: 1b 20)\\n')
    expect(prompt).not.toContain('R1:')
    expect(prompt).not.toContain('내 코드:')
    expect(prompt).not.toContain("'처음 보는 코드'·'풀이 보고 풀기' 칸은")
    expect(w.budgets.at(-1)).toBe(4600)
    expect(await ui.find({ type: 'Text', text: /^문제 1\\/1 · 비슷한 코드 · 예측$/ })).toBeDefined()
    expect(quizItems(store)[0]).toMatchObject({ rung: 'changed', kind: 'predict', answer: '14', hint: CHANGED_HINT(1, 'const items = [10, 4]') })
    expect(String(quizItems(store)[0]!.question)).toBe(`${CHANGED_LEAD}\\n\\`\\`\\`js\\n${FILE_JS.trimEnd().replace('[3, 4]', '[10, 4]')}\\n\\`\\`\\``)
    expect((await learn($, '퀴즈')).text).toContain(`\\n1. (비슷한 코드) ${CHANGED_LEAD}`)
    await ui.unmount()

    // Written as 1.8.0 asked it (T · Q · A, the model's own changed code): no question for it, and it is asked from the
    // learner's own code until the window closes (quizRun.changedMissed).
    await w.clock.advance(60_000)
    w.answer = ['T1: 예측', 'Q1: 아래 코드는 b를 무엇으로 찍을까요?', '```', 'const a = 10', 'const b = a * 2', 'console.log(b)', '```', 'A1: 20'].join('\\n')
    expect((await learn($, '퀴즈 새로')).text).toContain('바꾼 코드 문제를 확인하지 못했습니다')
    await w.clock.advance(60_000)
    w.answer = ['T1: 예측', 'Q1: 아래 코드의 total은?', 'A1: 7'].join('\\n')
    await learn($, '퀴즈 새로')
    expect(w.models.at(-1)).toContain('\\n   칸: 내 코드\\n   학습자가 만든 코드 (a.js):')
    expect(w.models.at(-1)).not.toContain('비슷한 코드')
  })

'''
s=T.put(s,t,new)

# ---- F3 describe: helper openedJs after opened()
anchor='''  async function quizIn($: Engine, w: World, reply: string) {'''
add='''  /**
   * 1.12.0 (G2 · G3): as `opened`, the concepts met in a.js written whole (FILE_JS), the file code never seen and code
   * changed now ask of; the 1.9.0/1.10.0 tests that asked them of a.ts are re-pinned on purpose to this world.
   */
  async function openedJs($: Engine, on: On, store: Map<string, unknown>, names: string[], harness: Record<string, unknown> | null = { rungNewStep: 4 }) {
    const w = world(on, 'ok', null, true, store)
    if (harness) w.harness = harness
    w.files.set('/proj/src/a.js', FILE_JS)
    await start($)
    w.answer = CONCEPT_NOTE(names)
    await turn($, () => $.tool.call(WRITE_JS))
    await finish(w)
    return w
  }
  /** A grade of a prediction in code never seen (1.12.0 G3): the learner's value copied, the plugin's verdict wrong. */
  const VALUE_WRONG = '값 1: 9\\n피드백: 아닙니다.'
'''
k=s.index("describe('1.9.0: 처음 보는 코드 behind its switch"); j=s.index(anchor,k); s=s[:j]+add+s[j:]

t="on: a concept due at its fifth step met in a .ts file is asked in code never seen"
b=T.get(s,t)
head=b[:b.index("    const w = await opened(")]
new=head+'''    // 1.12.0 (G3, re-pinned on purpose): met in a.js written whole (TypeScript is out of its scope); asked by K · L · A,
    // its question the plugin's own; a scene of names under its head, none of the learner's code or quotes sent.
    const w = await openedJs($, on, store, [NAME])
    expect(conceptOf(store, NAME).step).toBe(4)
    const ui = await quizIn($, w, KLA(1))
    const prompt = w.models.at(-1)!
    expect(prompt).toContain('\\n   칸: 처음 보는 코드 (js로)\\n   상황: ')
    expect(prompt).toContain('\\n2. 채움 하나 — 채움 하나 설명\\n3. 채움 둘 — 채움 둘 설명\\n\\n개념마다 하나씩')
    expect(prompt).toContain('처음 보는 코드: 이 칸은 문제 글·힌트·유형을 쓰지 않는다.')
    expect(prompt).toContain('\\nK1:\\n```js\\n(코드)\\n```\\nL1: ')
    expect(prompt).not.toMatch(/R1:|따라간 과정/)
    expect(prompt).not.toContain('학습자가 만든 코드')
    expect(prompt).not.toContain('const items = [3, 4]')
    expect(prompt).not.toContain('for (const n of nums)')
    expect(prompt).not.toContain('for (const item of items)')
    // One budget for every quiz that writes code of its own (1.10.0 G2, D12; 3600 in 1.9.0).
    expect(w.budgets.at(-1)).toBe(4600)
    expect(await ui.find({ type: 'Text', text: /^문제 1\\/1 · 처음 보는 코드 · 예측$/ })).toBeDefined()
    expect(quizItems(store)[0]).toMatchObject({ rung: 'new', kind: 'predict', answer: '10' })
    expect(String(quizItems(store)[0]!.question).startsWith(NEW_LEAD)).toBe(true)
    expect((await learn($, '퀴즈')).text).toContain(`\\n1. (처음 보는 코드) ${NEW_LEAD}`)
    await ui.unmount()
    // A new session reads the rung back from the store.
    await start($)
    const again = await pane($, 'terminal', { ...PANE_PROPS, isFocused: true })
    expect(await again.find({ type: 'Text', text: /^문제 1\\/1 · 처음 보는 코드 · 예측$/ })).toBeDefined()
    await again.unmount()
  })

'''
s=T.put(s,t,new)

t="off while a window before 1.10.0 (1.8.0 in 1.9.0) stamped within the day"
b=T.get(s,t)
head=b[:b.index("    store.set('sessions'")]
new=head+'''    // The newer window a 1.12.0 one (1.12.0 G3: 1.10 and 1.11 windows now keep it off as well, NEW_GRADER_SINCE).
    store.set('sessions', { 'session-old': { v: '1.7.1', at: NOW - 20 * 60_000 }, 'session-new': { v: '1.12.0', at: NOW - 60_000 } })
    // 1.12.0 (G2 · G3, re-pinned on purpose): met in a.js written whole, the file both ask of now.
    const w = await openedJs($, on, store, [NAME], { rungNewStep: 4, rungChangedStep: 2 })
    const ui = await quizIn($, w, CON(1))
    expect(w.models.at(-1)).toContain('\\n   칸: 비슷한 코드\\n   학습자가 만든 코드 (a.js):')
    expect(w.models.at(-1)).not.toContain('처음 보는 코드:')
    // Code changed's own C · O · N (1.12.0 G2), none of code never seen's.
    expect(w.models.at(-1)).not.toContain('K1:')
    expect(w.models.at(-1)).toContain('\\nC1: (고른 곳 이름, 한 칸 띄우고 새 값만. 예: 1b 20)\\n')
    expect(w.budgets.at(-1)).toBe(4600)
    expect(quizItems(store)[0]).toMatchObject({ rung: 'changed' })
    expect(await ui.find({ type: 'Text', text: /^문제 1\\/1 · 비슷한 코드 · 예측$/ })).toBeDefined()
    await ui.unmount()
    // Past the half hour (3/5 검토): a 1.7 window stamps only as it starts and as it keeps a note, so one left open
    // grading this quiz may have written none since. Still in its code changed.
    await w.clock.advance(11 * 60_000)
    w.answer = CON(1)
    await learn($, '퀴즈 새로')
    expect(w.models.at(-1)).toContain('\\n   칸: 비슷한 코드\\n')
    expect(w.models.at(-1)).not.toContain('처음 보는 코드:')
    // Past the day its stamp is gone: the next quiz asks it in code never seen.
    await w.clock.advance(STAMP_KEPT_MS - 31 * 60_000 + 60_000)
    w.answer = KLA(1)
    expect((await learn($, '퀴즈 새로')).text).toContain(`\\n1. (처음 보는 코드) ${NEW_LEAD}`)
    expect(w.models.at(-1)).toContain('   칸: 처음 보는 코드 (js로)')
  })

'''
s=T.put(s,t,new)

# group of grading tests: switch opened -> openedJs, fresh -> EITHER, WRONG for the new slot -> VALUE_WRONG
def jsify(b):
    b=b.replace("await opened($, on, store,","await openedJs($, on, store,")
    b=b.replace("fresh(1)","EITHER(1)").replace("fresh(2)","EITHER(2)")
    return b
t="a miss in code never seen steps the concept back one, not missed; the pane says so"
b=jsify(T.get(s,t))
b=rep(b,"    await answer(ui, w, mineKey(store, 0), '9요', WRONG)","    // 1.12.0 (G3, re-pinned on purpose): a.js written whole and K · L · A; its grade copies the value (VALUE_WRONG).\n    await answer(ui, w, mineKey(store, 0), '9요', VALUE_WRONG)")
s=T.put(s,t,b)
t="beside a miss in the learner"
b=jsify(T.get(s,t))
b=rep(b,"    await answer(ui, w, mineKey(store, 0), '9요', WRONG)\n    await answer(ui, w, mineKey(store, 1), '몰라서 아무거나', WRONG)",
"    // 1.12.0 (G3, re-pinned on purpose): a.js written whole and K · L · A; each slot's grade as its rung takes it.\n    await answer(ui, w, mineKey(store, 0), at.new === 0 ? '9요' : '몰라서 아무거나', at.new === 0 ? VALUE_WRONG : WRONG)\n    await answer(ui, w, mineKey(store, 1), at.new === 1 ? '9요' : '몰라서 아무거나', at.new === 1 ? VALUE_WRONG : WRONG)")
s=T.put(s,t,b)
t="beside one almost right, that one"
b=jsify(T.get(s,t))
b=rep(b,"    w.answer = WRONG\n    expect((await learn($, `퀴즈 ${next.new} 9요`))","    // 1.12.0 (G3, re-pinned on purpose): a.js written whole and K · L · A; its grade copies the value.\n    w.answer = VALUE_WRONG\n    expect((await learn($, `퀴즈 ${next.new} 9요`))")
s=T.put(s,t,b)
t="in the conversation, a miss in code never seen alone ends on its sentence"
b=jsify(T.get(s,t))
b=rep(b,"    w.answer = WRONG\n","    // 1.12.0 (G3, re-pinned on purpose): a.js written whole and K · L · A; its grade copies the value.\n    w.answer = VALUE_WRONG\n")
s=T.put(s,t,b)
t="in the conversation, beside a plain miss: that one"
b=jsify(T.get(s,t))
b=rep(b,"    expect((await learn($, `퀴즈 ${indexOf(store, NAME) + 1} 9요`))","    // 1.12.0 (G3, re-pinned on purpose): a.js written whole and K · L · A; its grade copies the value.\n    w.answer = VALUE_WRONG\n    expect((await learn($, `퀴즈 ${indexOf(store, NAME) + 1} 9요`))")
s=T.put(s,t,b)
for t in ["/learn 퀴즈 틀림 on code never seen alone says it steps back one","/learn 퀴즈 틀림 on code never seen and another question","right at the last step graduates the concept"]:
    b=jsify(T.get(s,t))
    b=b.replace("  test(","  // 1.12.0 (G3, re-pinned on purpose): met in a.js written whole, asked by K · L · A.\n  test(",1)
    s=T.put(s,t,b)
t="a miss turned right with f is a step on from where it was"
b=jsify(T.get(s,t))
b=rep(b,"    await answer(ui, w, mineKey(store, 0), '7이요 아마', WRONG)","    // 1.12.0 (G3, re-pinned on purpose): a.js written whole and K · L · A; a miss's grade copies the value, a right\n    // answer the plugin grades alone.\n    await answer(ui, w, mineKey(store, 0), '7이요 아마', '값 1: 7\\n피드백: 아닙니다.')")
b=rep(b,"    await answer(ui, w, mineKey(store, 1), '7', RIGHT)","    await answer(ui, w, mineKey(store, 1), '10', RIGHT)")
s=T.put(s,t,b)

# file-read tests
t="an edit far down a file that imports a library at its top"
b=T.get(s,t)
b=rep(b,"""    // The same edit in a file that imports nothing from a package: code never seen.
    w.files.set(POSTS, "import { axios } from './http.js'\\n\\nexport async function fetchPosts() {}\\n")
    await w.clock.advance(60_000)
    w.answer = fresh(1)
    await learn($, '퀴즈 새로')
    expect(w.models.at(-1)).toContain('   칸: 처음 보는 코드 (js로)')
    expect(quizItems(store)[0]!.rung).toBe('new')""","""    // The same edit in a file that imports nothing from a package: 1.12.0 (G3, re-pinned on purpose) its lines await, a
    // run-order use code never seen leaves out (isNewInScope), so its own code there too.
    w.files.set(POSTS, "import { axios } from './http.js'\\n\\nexport async function fetchPosts() {}\\n")
    await w.clock.advance(60_000)
    w.answer = fresh(1)
    await learn($, '퀴즈 새로')
    expect(w.models.at(-1)).toContain('\\n   칸: 내 코드\\n   학습자가 만든 코드 (posts.js):')
    expect(w.models.at(-1)).not.toContain('처음 보는 코드:')
    expect(quizItems(store)[0]!.rung).toBe('mine')""")
s=T.put(s,t,b)
t="with code never seen and code changed off (the release"
b=T.get(s,t)
b=rep(b,"""    // Code changed on (1.10.0 G2), code never seen off: read once a quiz for its imports; a library, so its own code.
    w.harness = { rungNewStep: null, rungChangedStep: 2 }
    await start($)
    await w.clock.advance(60_000)
    w.answer = fresh(1)
    await learn($, '퀴즈 새로')
    expect(reads).toBe(before + 1)
    expect(quizItems(store)[0]!.rung).toBe('mine')
    // Both on: still once a quiz.
    w.harness = { rungNewStep: 4, rungChangedStep: 2 }
    await start($)
    await w.clock.advance(60_000)
    w.answer = fresh(1)
    await learn($, '퀴즈 새로')
    expect(reads).toBe(before + 2)""","""    // Code changed on, code never seen off: 1.12.0 (G2, re-pinned on purpose) code changed asks only of a file written
    // whole, so an edit's file is never read for it; its own code.
    w.harness = { rungNewStep: null, rungChangedStep: 2 }
    await start($)
    await w.clock.advance(60_000)
    w.answer = fresh(1)
    await learn($, '퀴즈 새로')
    expect(reads).toBe(before)
    expect(quizItems(store)[0]!.rung).toBe('mine')
    // Both on: read once a quiz, for code never seen.
    w.harness = { rungNewStep: 4, rungChangedStep: 2 }
    await start($)
    await w.clock.advance(60_000)
    w.answer = fresh(1)
    await learn($, '퀴즈 새로')
    expect(reads).toBe(before + 1)""")
s=T.put(s,t,b)
t="the file as the tests below start from"
b=T.get(s,t)
b=rep(b,"""    expect(w.models.at(-1)).toContain('   칸: 처음 보는 코드 (js로)')
    expect(quizItems(store)[0]!.rung).toBe('new')""","""    // 1.12.0 (G3, re-pinned on purpose): its lines await, a run-order use code never seen leaves out (isNewInScope).
    expect(w.models.at(-1)).toContain('\\n   칸: 내 코드\\n')
    expect(quizItems(store)[0]!.rung).toBe('mine')""")
s=T.put(s,t,b)
t="with code never seen off, a quiz reads no stamps for it"
b=T.get(s,t)
b=rep(b,"""    expect(quizItems(store)[0]!.rung).toBe('changed')""","""    // 1.12.0 (G2, re-pinned on purpose): an edit is no file written whole, so its own code; the stamps unread all the same.
    expect(quizItems(store)[0]!.rung).toBe('mine')""")
s=T.put(s,t,b)
t="the stamps unreadable: code never seen off for that quiz"
b=T.get(s,t)
b=rep(b,"    const w = await opened($, on, store, [NAME], { rungNewStep: 4, rungChangedStep: 2 })","    // 1.12.0 (G2 · G3, re-pinned on purpose): met in a.js written whole, the file both ask of now.\n    const w = await openedJs($, on, store, [NAME], { rungNewStep: 4, rungChangedStep: 2 })")
b=rep(b,"    w.answer = fresh(1)\n    await learn($, '퀴즈 새로')\n    expect(w.models.at(-1)).toContain('\\n   칸: 비슷한 코드\\n   학습자가 만든 코드 (a.ts):')","    w.answer = CON(1)\n    await learn($, '퀴즈 새로')\n    expect(w.models.at(-1)).toContain('\\n   칸: 비슷한 코드\\n   학습자가 만든 코드 (a.js):')")
b=rep(b,"    w.answer = fresh(1)\n    await learn($, '퀴즈 새로')\n    expect(w.models.at(-1)).toContain('   칸: 처음 보는 코드 (ts로)')","    w.answer = KLA(1)\n    await learn($, '퀴즈 새로')\n    expect(w.models.at(-1)).toContain('   칸: 처음 보는 코드 (js로)')")
s=T.put(s,t,b)

# caps
old="""      w.harness = { rungNewStep: isOn ? 4 : null, rungChangedStep: null }
      await start($)
      w.answer = CONCEPT_NOTE(['for...of 반복문'])
      await turn($, () => $.tool.call(EDIT_A))
      await finish(w)
      w.answer = isOn ? fresh(1) : plainQ(1)"""
new="""      w.harness = { rungNewStep: isOn ? 4 : null, rungChangedStep: null }
      // 1.12.0 (G3, re-pinned on purpose): on, met in a.js written whole and asked by K · L · A; off as before.
      if (isOn) w.files.set('/proj/src/a.js', FILE_JS)
      await start($)
      w.answer = CONCEPT_NOTE(['for...of 반복문'])
      await turn($, () => $.tool.call(isOn ? WRITE_JS : EDIT_A))
      await finish(w)
      w.answer = isOn ? KLA(1) : plainQ(1)"""
assert s.count(old)==1; s=s.replace(old,new)
old="""      w.harness = { rungNewStep: null, rungChangedStep: step }
      await start($)
      w.answer = CONCEPT_NOTE(['for...of 반복문'])
      await turn($, () => $.tool.call(EDIT_A))
      await finish(w)
      w.answer = ['T1: 예측', 'Q1: 아래 코드의 b는?', '```ts', 'const a = 5', 'const b = a * 2', 'console.log(b)', '```', 'H1: a부터', 'R1: a는 5, b는 10', 'A1: 10'].join('\\n')
      await learn($, '퀴즈 새로')
      expect(quizItems(store).map(one => one.rung)).toEqual([step === 2 ? 'changed' : 'mine'])
      expect(callsOf(w)).toEqual([{ budget: NOTE, system: SYSTEM }, { budget: step === 2 ? QUIZ_TRACE : QUIZ, system: QUIZ_SYSTEM }])
      // The trace is dropped with code changed on; with it off, the R line is the hint's as in 1.9.0.
      expect(quizItems(store)[0]!.hint).toBe(step === 2 ? 'a부터' : 'a부터\\nR1: a는 5, b는 10')"""
new="""      w.harness = { rungNewStep: null, rungChangedStep: step }
      // 1.12.0 (G2, re-pinned on purpose): on, met in a.js written whole and asked by C · O · N; off as before.
      if (step === 2) w.files.set('/proj/src/a.js', FILE_JS)
      await start($)
      w.answer = CONCEPT_NOTE(['for...of 반복문'])
      await turn($, () => $.tool.call(step === 2 ? WRITE_JS : EDIT_A))
      await finish(w)
      w.answer = step === 2 ? CON(1) : ['T1: 예측', 'Q1: 아래 코드의 b는?', '```ts', 'const a = 5', 'const b = a * 2', 'console.log(b)', '```', 'H1: a부터', 'R1: a는 5, b는 10', 'A1: 10'].join('\\n')
      await learn($, '퀴즈 새로')
      expect(quizItems(store).map(one => one.rung)).toEqual([step === 2 ? 'changed' : 'mine'])
      expect(callsOf(w)).toEqual([{ budget: NOTE, system: SYSTEM }, { budget: step === 2 ? QUIZ_TRACE : QUIZ, system: QUIZ_SYSTEM }])
      // With code changed on, the plugin's hint by the line; with it off, the R line is the hint's as in 1.9.0.
      expect(quizItems(store)[0]!.hint).toBe(step === 2 ? CHANGED_HINT(1, 'const items = [10, 4]') : 'a부터\\nR1: a는 5, b는 10')"""
assert s.count(old)==1; s=s.replace(old,new)
open(p,'w').write(s); print('ok')
