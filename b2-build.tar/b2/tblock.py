# Helper: get/replace a test block by a unique substring of its title.
import re
def find(s, title):
    i = s.find(title)
    assert i >= 0 and s.find(title, i + 1) < 0, title
    start = s.rfind('\n', 0, i) + 1
    # block ends at the next line starting with two spaces + "test(" or "})" at column 0/2 after start
    m = re.compile(r'\n  (?:test|test\.skip|describe)\(|\n\}\)\n').search(s, i)
    return start, m.start() + 1
def get(s, title):
    a, b = find(s, title); return s[a:b]
def put(s, title, new):
    a, b = find(s, title); return s[:a] + new + s[b:]
