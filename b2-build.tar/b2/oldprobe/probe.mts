// learn-notes 1.12.0 batch 2 old-window probe (R9; record): a question in code changed (1.12.0 G2) and one in code
// never seen (1.12.0 G3), each made by the batch tree's own reader (changedItem / newItem) from a model's C · O · N /
// K · L · A, then read by six real builds' functions (git archive of 3f2b4fb 1.7.0 · 7a7b08c 1.7.1 · 3690021 1.8.0 ·
// fca5988 1.9.0 · 3d2f251 1.10.0 · de98243 1.11.0) and the tree: how the stored item loads (register.tsx quizItemOf's
// field checks, read from its source), the step a right / wrong / 거의 grade moves it to (each build's own marks), the
// stock grade it builds (no 값 lines), 거의 read as partial, and the answer as a list line.
// usage: node --experimental-transform-types probe.mts <tree dir>
import { readFileSync } from 'node:fs'
const TREES = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2/trees'
const TREE = process.argv[2] ?? '/home/user/learn-notes'
const T = await import(`${TREE}/hooks/notes.ts`)
const FILE = ['const items = [3, 4]', 'let total = 0', 'for (const item of items) total += item', 'console.log(total)'].join('\n')
const BLURB = '반복문 설명 — `for (const item of items)`'
const base = { key: 'c:k', name: 'k', count: 3, firstAt: 0, lastAt: 0, blurb: BLURB, files: [], noteId: 'n1' }
const parts = (o: Record<string, string>) => new Map(Object.entries(o).map(([k, v]) => [k, v.split('\n')]))
const changed = T.changedItem(parts({ C1: '1a 10\nconst items = [10, 4]', O1: '7', N1: '14' }), 1, { ...base, rung: 'changed', code: { file: 'a.js', text: FILE, isWhole: true } })
const fresh = T.newItem(parts({ K1: '\n```js\nconst scores = [5, 1, 4]\nlet best = 0\nfor (const s of scores) best += s\nconsole.log(best)\n```', L1: 'for (const s of scores) best += s', A1: '\n10' }), 1, { ...base, rung: 'new', lang: 'js', seen: `${FILE}\n${BLURB}` })
if (!('item' in changed) || !('item' in fresh)) throw new Error(`tree reader refused: ${JSON.stringify(changed)} ${JSON.stringify(fresh)}`)
const items = { changed: changed.item, new: fresh.item }
const stored = (item: Record<string, unknown>) => JSON.parse(JSON.stringify(item))
const out: Record<string, unknown> = { items }
for (const c of ['3f2b4fb', '7a7b08c', '3690021', 'fca5988', '3d2f251', 'de98243', 'TREE']) {
  const dir = c === 'TREE' ? TREE : `${TREES}/${c}`
  const N = c === 'TREE' ? T : await import(`${dir}/hooks/notes.ts`)
  const reg = readFileSync(`${dir}/hooks/register.tsx`, 'utf8')
  const qi = reg.slice(reg.indexOf('function quizItemOf'), reg.indexOf('function quizItemOf') + 4000)
  const row: Record<string, unknown> = {}
  for (const [rung, item0] of Object.entries(items)) {
    const item = stored(item0)
    const idx = () => ({ 'c:k': { key: 'c:k', name: 'k', count: 3, firstAt: 0, lastAt: 0, blurb: '', files: [], step: 4, reviewedAt: 1 } })
    // 1.7.x has no markFor in notes.ts: its register picks markReviewed / markPartial / markMissed∘markReviewed (as 3f2b4fb register.tsx markFor).
    const mark = (result: 'right' | 'wrong', verdict: string) =>
      N.markFor
        ? N.markFor(result, verdict, false, item.rung)
        : result === 'right'
          ? N.markReviewed
          : verdict === 'partial'
            ? N.markPartial
            : (i: never, k: never, at: never) => N.markMissed(N.markReviewed(i, k, at), k, at)
    const st = (m: (i: unknown, k: string[], at: number) => Record<string, { step?: number }>) => m(idx(), ['c:k'], 1000)['c:k']!.step
    const grade = N.checkPrompt(item, '14요', 'beginner')
    row[rung] = {
      loads: /typeof key !== 'string' \|\| typeof name !== 'string' \|\| typeof question !== 'string' \|\| typeof answer !== 'string'\) return undefined/.test(qi) && /typeof hint === 'string'/.test(qi) && /kind === 'predict'/.test(qi) && /typeof noteId === 'string'/.test(qi),
      keepsRung: new RegExp(`one\\.rung === '${rung}'`).test(qi),
      right: st(mark('right', 'right')),
      wrong: st(mark('wrong', 'wrong')),
      partial: st(mark('wrong', 'partial')),
      stockGrade: grade.includes('## 모범 답') && !grade.includes('값 1:') && grade.includes(item.answer),
      partialRead: N.parseCheck('판정: 거의\n피드백: f', {})?.verdict,
      listLine: N.listItem(1, item.answer).slice(0, 12),
    }
  }
  out[c] = row
}
console.log(JSON.stringify(out, null, 1))
