import sys,re; sys.path.insert(0,'/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b2'); import tblock as T
p='tests/ladder.test.ts'; s=open(p).read()
t="preview made it where code changed is left in a quiz of three"
b=T.get(s,t)
old="""          const want = QUIZ_OUTPUT_110_ON[key] ?? QUIZ_OUTPUT_19_OFF[key]!
          if (QUIZ_OUTPUT_110_ON[key]) kept.push(keyOf(one.id, newStep, workedAfter))"""
new="""          // 1.12.0 (G2, re-pinned on purpose): code changed only for a file shown whole (isChangedShaped); quiz18.ts's
          // code is no such file, so every quiz is as with it off, and 1.10.0's preview (QUIZ_OUTPUT_110_ON) is no quiz's.
          const want = QUIZ_OUTPUT_19_OFF[key]!
          if (QUIZ_OUTPUT_110_ON[key]) kept.push(keyOf(one.id, newStep, workedAfter))"""
assert b.count(old)==1; b=b.replace(old,new)
old="""    // Two picks (retry) or a team term (blank) take it off. 1.10.0 (G1): worked's worked example is off with worked
    // examples on (its code holds no line its words quote), so code changed stays beside it (1.9.0 F4 took it off there).
    expect(kept)"""
new="""    // The keys 1.10.0 asked in code changed, each now asked as with it off.
    expect(kept)"""
assert b.count(old)==1; b=b.replace(old,new)
s=T.put(s,t,b)
t="458 characters, and 1.9.0"
b=T.get(s,t)
old="""    expect(prompt.split('\\n').filter(line => line.startsWith('비슷한 코드:'))).toEqual([CHANGED_110])
    expect(prompt).toContain(`\\n내 코드: 학습자가 만든 코드를 그대로 보여 주고 묻는다.\\n${CHANGED_110}\\n`)"""
new="""    // 1.12.0 (G2, re-pinned on purpose): its sentence is 1.12.0's, after 내 코드's; 1.10.0's (CHANGED_110) is nowhere.
    expect(prompt.split('\\n').filter(line => line.startsWith('비슷한 코드:')).map(line => line.slice(0, 44))).toEqual(['비슷한 코드: 이 칸은 문제 글을 쓰지 않는다. 문제와 바꾼 코드는 플러그인이 만든다.'.slice(0, 44)])
    expect(prompt).toContain('\\n내 코드: 학습자가 만든 코드를 그대로 보여 주고 묻는다.\\n비슷한 코드: 이 칸은 문제 글을 쓰지 않는다.')
    expect(prompt).not.toContain(CHANGED_110)"""
assert b.count(old)==1, 'b2'; b=b.replace(old,new)
s=T.put(s,t,b)
t="its R line stands right after H1"
b=T.get(s,t)
old="""    expect(changed).toContain('\\nC1: (바꿀 곳 이름과 새 값)\\n(그 값으로 바꾼 줄 통째로)\\nO1:\\n(원래 코드가 찍는 줄들)\\nN1:\\n(바꾼 코드가 찍는 줄들)\\nT2: (예측 · 왜 · 바꿔 보기 중 하나)\\nQ2: (문제 한두 문장)\\nH2: (힌트 한 문장)\\nA2: (답 한두 문장)\\nT3:')
    expect(changed).not.toContain(NEW_TRACE)
    const fresh = quizPrompt([pickForRung(pick('A', { code: CODE }), 'new'), pickForRung(pick('B', { code: CODE }), 'mine'), pick('C')], 'beginner')
    expect(fresh).toContain(`\\nH1: (힌트 한 문장)\\n${NEW_TRACE}\\nA1: (답 한두 문장)\\n`)
    expect(fresh).not.toContain(CHANGED_TRACE)"""
new="""    expect(changed).toContain('\\nC1: (고른 곳 이름, 한 칸 띄우고 새 값만. 예: 1b 20)\\n(그 값으로 바꾼 줄 통째로)\\nO1:\\n(원래 코드가 찍는 줄들)\\nN1:\\n(바꾼 코드가 찍는 줄들)\\nT2: (예측 · 왜 · 바꿔 보기 중 하나)\\nQ2: (문제 한두 문장)\\nH2: (힌트 한 문장)\\nA2: (답 한두 문장)\\nT3:')
    expect(changed).not.toContain(NEW_TRACE)
    // 1.12.0 (G3, re-pinned on purpose): code never seen has no R line either; K · L · A per number.
    const fresh = quizPrompt([pickForRung(pick('A', { code: CODE }), 'new'), pickForRung(pick('B', { code: CODE }), 'mine'), pick('C')], 'beginner')
    expect(fresh).not.toContain('R1:')
    expect(fresh).toContain('\\nK1:\\n```js\\n(코드)\\n```\\nL1: (K1 코드에서 눈여겨볼 줄 하나를 그대로. 찍는 줄은 빼고)\\nA1:\\n(찍히는 글자. 찍는 호출마다 한 줄)\\nT2:')
    expect(fresh).not.toContain(CHANGED_TRACE)"""
assert b.count(old)==1, 'b3'; b=b.replace(old,new)
s=T.put(s,t,b)
t="its scope: code that runs alone in js, mjs"
b=T.get(s,t)
old="""    const rung = (file: string, text: string, step = 2, more: { isLibrary?: boolean; isImporting?: boolean } = {}) => rungOf(at(step), { ...plain, code: { file, text, ...more } }, Infinity, ON2)
    const plainCode = 'let a = 1\\nconsole.log(a + 1)'
    for (const file of ['a.js', 'a.mjs', 'a.cjs', 'src/a.ts', 'A.JS']) expect([file, rung(file, plainCode)]).toEqual([file, 'changed'])"""
new="""    // 1.12.0 (G2, re-pinned on purpose): code changed is asked only of a JavaScript or Python file shown whole with
    // places the plugin can change (isChangedShaped): each text here is that file with two lines more giving it three
    // places (TAIL), so what decides is the 1.10.0 scope below, kept as it was.
    const TAIL = (file: string) => (/\\.py$/i.test(file) ? 'p = [3, 4, 5]\\nprint(p[0] * 2)' : 'const p = [3, 4, 5]\\nconsole.log(p[0] * 2)')
    const rung = (file: string, text: string, step = 2, more: { isLibrary?: boolean; isImporting?: boolean } = {}) =>
      rungOf(at(step), { ...plain, code: { file, text: `${text}\\n${TAIL(file)}`, isWhole: true, ...more } }, Infinity, ON2)
    const plainCode = 'let a = 1\\nconsole.log(a + 1)'
    for (const file of ['a.js', 'A.JS']) expect([file, rung(file, plainCode)]).toEqual([file, 'changed'])
    // 1.12.0 (G2): .mjs, .cjs and TypeScript are no longer asked in code changed (its samples were js and py).
    for (const file of ['a.mjs', 'a.cjs', 'src/a.ts']) expect([file, rung(file, plainCode)]).toEqual([file, 'mine'])"""
assert b.count(old)==1, 'b4'; b=b.replace(old,new)
s=T.put(s,t,b)
t="its R line is a marker, dropped"
b=T.get(s,t)
head=b[:b.index("    const picks")]
new="""    // 1.12.0 (G2, re-pinned on purpose): the slot in code changed is read from C · O · N; an R line written there is a
    // marker dropped, the item the plugin's own (the changed code, its hint by the line, N as the answer).
    const picks = [pickForRung(pick('A', { blurb: 'A 설명 — `total += n`', code: CODE_W }), 'changed'), pickForRung(pick('B', { code: CODE }), 'mine'), pick('C')]
    const code = '```js\\nlet total = 10\\nfor (const n of [1, 2]) total += n\\nconsole.log(total)\\n```'
    const text = [
      'C1: 1a 10',
      'let total = 10',
      'R1: total은 10에서 11, 다시 13이 된다',
      'O1:',
      '3',
      'N1:',
      '13',
      'T2: 왜',
      'Q2: 아래 코드에서 let을 const로 바꾸면?\\n```js\\nlet total = 0\\nfor (const n of [1, 2]) total += n\\nconsole.log(total)\\n```',
      'H2: 다시 대입',
      'A2: 오류',
      'T3: 왜',
      'Q3: 왜 그렇게 썼을까요?',
      'A3: 그래서',
    ].join('\\n')
    const items = parseQuiz(text, picks)
    expect(items.map(one => [one.rung, one.kind])).toEqual([['changed', 'predict'], ['mine', 'why'], [undefined, 'why']])
    expect(items[0]).toMatchObject({ question: `${CHANGED_LEAD}\\n${code}`, hint: CHANGED_HINT(1, 'let total = 10'), answer: '13' })
    expect(JSON.stringify(items)).not.toContain('10에서 11')
    expect(JSON.stringify(items)).not.toContain('R1')
    // With it off (no pick on the rung), an R line is the hint's, as in 1.9.0.
    const off = parseQuiz('Q1: 문제\\nH1: 실마리\\nR1: 따라가기\\nA1: 답', [pickForRung(pick('A', { code: CODE }), 'mine')])[0]!
    expect(off.hint).toBe('실마리\\nR1: 따라가기')
  })

"""
s=T.put(s,t,head+new)
t="a question with no code shown keeps no rung, nor one showing the learner"
b=T.get(s,t)
head=b[:b.index("    const picks")]
new="""    // 1.12.0 (G2, re-pinned on purpose): a pick in code changed takes no T · Q · A item, whatever its code shows; the
    // plugin makes the question from C · O · N.
    const picks = [pickForRung(pick('A', { code: { file: 'a.js', text: 'const limit = 3\\nconsole.log(limit * 2)' } }), 'changed')]
    const asked = (question: string) => parseQuiz(`T1: 예측\\nQ1: ${question}\\nA1: 답`, picks)
    expect(asked('제한을 늘리면 무엇이 달라질까요?')).toEqual([])
    expect(asked('아래 코드는?\\n```js\\n```')).toEqual([])
    expect(asked('아래 코드는?\\n```js\\nconst limit = 3\\nconsole.log(limit * 2)\\n```')).toEqual([])
    expect(asked('아래 코드는?\\n```js\\nconst limit = 5\\nconsole.log(limit * 2)\\n```')).toEqual([])
    expect(asked('아래 코드에서 `3`을 `4`로 바꾸면 무엇이 찍힐까요?\\n```js\\nconst limit = 3\\nconsole.log(limit * 2)\\n```')).toEqual([])
    // The grade marks it as 1.8.0 did: wrong to the first step, 거의 one step back.
    expect(markFor('wrong', undefined, false, 'changed')).toBe(markWrong)
    expect(markFor('wrong', 'partial', false, 'changed')).toBe(markPartial)
  })
"""
s=T.put(s,t,head+new)
# imports
s=s.replace("import {\n  NEW_GRADER_SINCE,\n  NEW_LEAD,\n","import {\n  CHANGED_HINT,\n  CHANGED_LEAD,\n  NEW_GRADER_SINCE,\n  NEW_LEAD,\n",1)
open(p,'w').write(s)
print('ok')
