import re,sys
def resolve(path, choices):
    s=open(path).read()
    pat=re.compile(r'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>> g3\n', re.S)
    blocks=pat.findall(s)
    assert len(blocks)==len(choices),(path,len(blocks))
    it=iter(choices)
    def rep(m):
        c=next(it)
        return c(m.group(1),m.group(2)) if callable(c) else c
    s=pat.sub(rep,s)
    open(path,'w').write(s)
N=[
# 1 QuizPick.code
"  code?: { file: string; text: string; isLibrary?: true; isImporting?: true; isNewLibrary?: true; isWhole?: true; around?: string }\n",
# 2 rungOf
"""  if (isNewAskable(one, how.code.file, how.isDue, newStep) && isNewRunnable && isNewInScope(how.code.file, one.blurb, how.code.text, how.isNewMissed === true)) return 'new'
  // 1.12.0 (G2): only a JavaScript or Python file shown whole, in the shape the plugin can change one token of (isChangedShaped).
  return stepOf(one) >= changedStep && isRunnable && isChangedRunnable(how.code) && isChangedShaped(how.code, one.blurb) ? 'changed' : 'mine'
""",
# 3 parseQuiz
"""  // Code changed (1.12.0 G2) is read from its C, O and N (changedItem), each a marker too; code never seen (1.12.0 G3) from
  // its K, L and A (newItem). Each of these written twice counts by its last text (quizParts' lastWins); the two never
  // share a quiz (ladderMixed).
  const isChanged = picks.some(one => one.rung === 'changed')
  const isNew = picks.some(one => one.rung === 'new')
  const markers = `QHAT${isNew || isChanged ? 'R' : ''}${isNew ? 'KL' : ''}${isChanged ? 'CON' : ''}${picks.some(one => one.rung === 'worked') ? 'P' : ''}`
  const late = isNew ? 'KLA' : isChanged ? 'CON' : ''
  const read = (isFenceAware: boolean) => quizItems(quizParts(text, isFenceAware, markers, late), picks)
  const aware = read(true)
  // A fence the model left open would hide every marker after it: then read it as if there were no code.
  const items = aware.length >= picks.length ? aware : [aware, read(false)].reduce((a, b) => (b.length > a.length ? b : a))
""",
# 4 quizItems
"""    // Code changed (1.12.0 G2) and code never seen (1.12.0 G3): only the plugin's own item from C · O · N or K · L · A, or none.
    if (one.rung === 'changed' || one.rung === 'new') {
      const made = one.rung === 'changed' ? changedItem(parts, i + 1, one) : newItem(parts, i + 1, one)
""",
]
resolve('hooks/notes.ts',N)
R=[
"""          ...(isWhole ? { isWhole: true as const } : {}),
          // The file already read, for code never seen's setting and clause-3 check (1.12.0 G3): on this device only.
          ...(isNew && file !== undefined ? { around: file } : {}),
""",
"""  // Code changed is on only in a row of MODEL_SWITCHES (1.12.0 G2), and so is code never seen (1.12.0 G3): the alias is
  // asked again where either acts, before any switch of the quiz is read (recheckRemap's rule).
  if (Number.isFinite(build.rungChangedStep) || Number.isFinite(build.rungNewStep)) await recheckRemap($)
""",
"""  const gone = picks.filter(one => (one.rung === 'changed' || one.rung === 'new') && !items.some(item => item.key === one.key))
  // A question in code changed or code never seen the plugin could not check is asked another way for the rest of the session.
  const goneChanged = gone.filter(one => one.rung === 'changed').map(one => one.key)
  const goneNew = gone.filter(one => one.rung === 'new').map(one => one.key)
  if (goneChanged.length > 0) await update($, quizRun, run => ({ ...run, changedMissed: [...new Set([...(run.changedMissed ?? []), ...goneChanged])].slice(-50) }))
  if (goneNew.length > 0) await update($, quizRun, run => ({ ...run, newMissed: [...new Set([...(run.newMissed ?? []), ...goneNew])].slice(-50) }))
  if (items.length === 0 && picks.every(one => one.rung === 'new')) {
    // Counted in /learn 진단 like an unreadable quiz (a code and a time; no concept, no text).
    void fault($, 'quiz', 'new-unchecked', '처음 보는 코드 문제를 확인하지 못했습니다')
    return { error: NEW_NONE_TEXT }
  }
""",
lambda a,b: b,
lambda a,b: b,
lambda a,b: b,
]
resolve('hooks/register.tsx',R)
T=[
"""  /**
   * The concepts whose question in code changed this window's reply gave none (1.12.0 G2): asked from the learner's own
   * code for the rest of the session. Session state only, never stored.
   */
  changedMissed?: string[]
  /** The concepts whose question in code never seen this session could not check (1.12.0 G3): asked another way for the rest of the session. Session state only; never in the store. */
  newMissed?: string[]
""",
]
resolve('types/index.d.ts',T)
