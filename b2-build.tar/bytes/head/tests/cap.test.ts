// crit: capture real quiz requests in several windows (OFF and haiku ON); same file run on HEAD and on tree-r2.
import { describe, expect, test } from 'claude-code/testing'
import { conceptKey } from '../hooks/notes'
import { NOW, finish, learn, ownSteps, routeCalls, start, turn, world } from './flowkit'
const DAY = 86_400_000, HOUR = 3_600_000
const CODES: Record<string, string> = {
  'a.js': ['const scores = [72, 85, 91]', 'let total = 0', 'for (const s of scores) {', '  if (s >= 80) total += s', '}', 'const avg = Math.round(total / 2)', "console.log('합계:', total)", "console.log('평균 ' + avg)"].join('\n'),
  'b.py': ['prices = [1200, 800, 450]', 'total = 0', 'for p in prices:', '    if p > 500:', '        total += p', 'print("합계:", total)', 'print(f"평균 {total // 2}")'].join('\n'),
}
const BLURBS: Record<string, string> = { 'a.js': '80점 이상만 더합니다 — `if (s >= 80) total += s`', 'b.py': '500보다 비싼 것만 더합니다 — `if p > 500:`' }
async function q($: any, on: any, file: string, harness: any) {
  const calls = routeCalls(on)
  const NAME = '조건문'
  const steps: Record<string, number> = { [NAME]: 2, 배열: 1, 반복문: 1 }
  const concepts = Object.fromEntries(Object.entries(steps).map(([name, step], i) => [conceptKey(name), { name, count: 3, firstAt: NOW - 60 * DAY, lastAt: NOW - 60 * DAY, blurb: name === NAME ? BLURBS[file] : `${name} 설명`, files: [], step, reviewedAt: NOW - 31 * DAY - (10 - i) * HOUR }]))
  const store = new Map<string, unknown>([['stepsFrom', 0], ['concepts', concepts], ['steps', ownSteps(concepts as never)]])
  const w = world(on, 'ok', null, true, store)
  if (harness) w.harness = harness
  await start($)
  w.answer = ['### 한 줄 요약', '만들었습니다', '### 배울 개념', `- **${NAME}**: ${BLURBS[file]}`, '- **배열**: 배열 설명', '- **반복문**: 반복문 설명', '### 직접 확인해 볼 것', '- 실행해 보기'].join('\n')
  await turn($, () => $.tool.call({ tool: 'Write', tool_use_id: 'u1', file_path: `/proj/${file}`, content: `${CODES[file]}\n` }), 't1')
  w.files.set(`/proj/${file}`, `${CODES[file]}\n`)
  await finish(w)
  const before = calls.length
  w.answer = 'T1: 예측\nQ1: x\nH1: y\nA1: z'
  await learn($, '퀴즈 새로')
  ;(globalThis as any).console.log('CAP ' + JSON.stringify({ file, harness: harness ?? null, got: calls.slice(before) }))
  expect(true).toBe(true)
}
const cases: [string, string, string, any][] = []
for (const model of ['sonnet', 'haiku', 'opus']) for (const level of ['beginner', 'intermediate']) for (const file of ['a.js', 'b.py']) cases.push([model, level, file, undefined])
for (const file of ['a.js', 'b.py']) cases.push(['sonnet', 'beginner', file, { models: { sonnet: { isChangedRun: true } } }])
describe('crit capture', () => {
  for (const [model, level, file, h] of cases)
    test(`cap ${model} ${level} ${file} ${h ? 'h' : ''}`, { options: { model, level }, timeoutMs: 30000 }, async ($, on) => { await q($, on, file, h) })
})
