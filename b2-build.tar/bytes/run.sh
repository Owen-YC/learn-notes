#!/bin/bash
# batch 2 build: the 14 real quiz requests (3 models × 2 levels × js/py, plus a sonnet harness with isChangedRun alone)
# captured by design/G2/crit/bytes/cap.test.ts at HEAD (6a32a29) and at the build tree; 0 model calls.
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2/bytes
P=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/cli/pinned.sh
export DISABLE_AUTOUPDATER=1
cd "${S:?}" || exit 1
[ -e STARTED ] && exit 9
date -u +%FT%TZ > STARTED
for t in head build; do (cd "$S/$t" && "$P" claude plugin test . > "$S/$t.out" 2>&1; echo $? > "$S/$t.exit"); done
python3 -I - "$S/head.out" "$S/build.out" > "$S/cmp.txt" <<'PY'
import json, sys
def caps(p):
    return {(d['file'], json.dumps(d['harness']), d['got'][0]['model'] if d['got'] else None, i): d for i, d in enumerate(json.loads(l[4:]) for l in open(p) if l.startswith('CAP '))}
a, b = [ [json.loads(l[4:]) for l in open(p) if l.startswith('CAP ')] for p in sys.argv[1:3] ]
print('head', len(a), 'build', len(b))
same = sum(1 for x in a if x in b)
print('identical requests (each head capture found byte-identical in build):', same, 'of', len(a))
for x in a:
    if x not in b: print('DIFF', x['file'], x['harness'], [g.get('model') for g in x['got']])
PY
date -u +%FT%TZ > DONE
