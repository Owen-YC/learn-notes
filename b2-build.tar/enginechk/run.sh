#!/bin/bash
S=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2/enginechk
export DISABLE_AUTOUPDATER=1
cd "${S:?}" || exit 1
[ -e STARTED ] && exit 9
date -u +%FT%TZ > STARTED
/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/cli/pinned.sh claude plugin test . > engine.out 2>&1; echo $? > engine.exit
date -u +%FT%TZ > DONE
