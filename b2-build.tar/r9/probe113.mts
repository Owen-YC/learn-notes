// learn-notes 1.13.0 batch 2 build, old-window probe (R9; records only). Run-route changed items (1.13.0 G2, sonnet ON
// value) made through the real plugin path (b2/r9/items.jsonl from r9cap.test.ts: own value, own number, fallback),
// and for reference a 1.12.0 haiku-route changed item (the tree's changedItem from C · O · N, as impl112/b2/oldprobe/
// probe.mts made it), each read by seven real builds' functions (git archive under impl113/b2/oldprobe: 3f2b4fb 1.7.0 ·
// 7a7b08c 1.7.1 · 3690021 1.8.0 · fca5988 1.9.0 · 3d2f251 1.10.0 · de98243 1.11.0 · 30adc2f 1.12.0) and the batch tree:
// how the stored item loads (register.tsx quizItemOf's field checks, read from its source), the step a right / wrong /
// 거의 grade moves it to (each build's own marks, from step 4), the stock grade it builds, 거의 read as partial, the answer
// as a list line. sameAsHaiku: every column but the answer's own text equals the haiku item's in that build.
// usage: node --experimental-transform-types probe113.mts
import { readFileSync } from 'node:fs'
const B = '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2'
const TREE = `${B}/tree`
const T = await import(`${TREE}/hooks/notes.ts`)
const FILE = ['const items = [3, 4]', 'let total = 0', 'for (const item of items) total += item', 'console.log(total)'].join('\n')
const BLURB = '반복문 설명 — `for (const item of items)`'
const base = { key: 'c:k', name: 'k', count: 3, firstAt: 0, lastAt: 0, blurb: BLURB, files: [], noteId: 'n1' }
const parts = (o: Record<string, string>) => new Map(Object.entries(o).map(([k, v]) => [k, v.split('\n')]))
const haiku = T.changedItem(parts({ C1: '1a 10\nconst items = [10, 4]', O1: '7', N1: '14' }), 1, { ...base, rung: 'changed', code: { file: 'a.js', text: FILE, isWhole: true } })
if (!('item' in haiku)) throw new Error('tree reader refused the haiku item')
const items: Record<string, Record<string, unknown>> = { haiku: haiku.item }
for (const line of readFileSync(`${B}/r9/items.jsonl`, 'utf8').split('\n').filter(Boolean)) {
  const { label, item } = JSON.parse(line)
  items[`run-${label}`] = { ...item, key: 'c:k', name: 'k' }
}
const out: Record<string, unknown> = { items }
const bad: string[] = []
for (const c of ['3f2b4fb', '7a7b08c', '3690021', 'fca5988', '3d2f251', 'de98243', '30adc2f', 'TREE']) {
  const dir = c === 'TREE' ? TREE : `${B}/oldprobe/${c}`
  const N = c === 'TREE' ? T : await import(`${dir}/hooks/notes.ts`)
  const reg = readFileSync(`${dir}/hooks/register.tsx`, 'utf8')
  const qi = reg.slice(reg.indexOf('function quizItemOf'), reg.indexOf('function quizItemOf') + 4000)
  const row: Record<string, Record<string, unknown>> = {}
  for (const [name, item0] of Object.entries(items)) {
    const item = JSON.parse(JSON.stringify(item0))
    const idx = () => ({ 'c:k': { key: 'c:k', name: 'k', count: 3, firstAt: 0, lastAt: 0, blurb: '', files: [], step: 4, reviewedAt: 1 } })
    const mark = (result: 'right' | 'wrong', verdict: string) =>
      N.markFor
        ? N.markFor(result, verdict, false, item.rung)
        : result === 'right'
          ? N.markReviewed
          : verdict === 'partial'
            ? N.markPartial
            : (i: never, k: never, at: never) => N.markMissed(N.markReviewed(i, k, at), k, at)
    const st = (m: (i: unknown, k: string[], at: number) => Record<string, { step?: number }>) => m(idx(), ['c:k'], 1000)['c:k']!.step
    const grade = N.checkPrompt(item, '14요', 'beginner')
    row[name] = {
      loads: /typeof key !== 'string' \|\| typeof name !== 'string' \|\| typeof question !== 'string' \|\| typeof answer !== 'string'\) return undefined/.test(qi) && /typeof hint === 'string'/.test(qi) && /kind === 'predict'/.test(qi) && /typeof noteId === 'string'/.test(qi),
      keepsRung: /one\.rung === 'changed'/.test(qi),
      right: st(mark('right', 'right')),
      wrong: st(mark('wrong', 'wrong')),
      partial: st(mark('wrong', 'partial')),
      stockGrade: grade.includes('## 모범 답') && !grade.includes('값 1:') && grade.includes(item.answer),
      partialRead: N.parseCheck('판정: 거의\n피드백: f', {})?.verdict,
      listLine: N.listItem(1, item.answer).slice(0, 16),
    }
  }
  const strip = (r: Record<string, unknown>) => JSON.stringify({ ...r, listLine: undefined })
  for (const name of Object.keys(items)) {
    if (name === 'haiku') continue
    row[name]!.sameAsHaiku = strip(row[name]!) === strip(row.haiku!)
    if (!row[name]!.sameAsHaiku || row[name]!.loads !== true || row[name]!.stockGrade !== true) bad.push(`${c} ${name}`)
  }
  out[c] = row
}
out.bad = bad
console.log(JSON.stringify(out, null, 1))
