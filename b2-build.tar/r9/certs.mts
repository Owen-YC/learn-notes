const T = await import('/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl113/b2/tree/hooks/notes.ts')
const CODE = ['const scores = [72, 85, 91]', 'let total = 0', 'for (const s of scores) {', '  if (s >= 80) total += s', '}', 'const avg = Math.round(total / 2)', "console.log('합계:', total)", "console.log('평균 ' + avg)"].join('\n')
const run = T.changedRunFor(CODE, 'a.js', '80점 이상만 더합니다 — `if (s >= 80) total += s`')
console.log(JSON.stringify(run.out), run.certs.map((c: any, i: number) => `${'abcdef'[i]} L${c.site.line + 1} ${c.site.kind} ${c.site.token} -> ${c.value} | ${c.lines.join(' / ')}`).join('\n'))
