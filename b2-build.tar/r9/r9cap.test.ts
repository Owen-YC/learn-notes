// learn-notes 1.13.0 batch 2 build (records only, outside the repo): run-route changed items made through the real plugin
// path at the sonnet ON value (harness models.sonnet { rungChangedStep: 2, isChangedRun: true }), printed as stored, for
// the R9 old-window probe (b2/r9/probe113.mts). The world is tests/flow113g2.test.ts's.
import { describe, expect, test } from 'claude-code/testing'
import { conceptKey } from '../hooks/notes'
import { NOW, finish, learn, ownSteps, start, turn, world } from './flowkit'

const DAY = 86_400_000
const HOUR = 3_600_000
const CODE = ['const scores = [72, 85, 91]', 'let total = 0', 'for (const s of scores) {', '  if (s >= 80) total += s', '}', 'const avg = Math.round(total / 2)', "console.log('합계:', total)", "console.log('평균 ' + avg)"].join('\n')
const NAME = '조건문'
const BLURB = '80점 이상만 더합니다 — `if (s >= 80) total += s`'
// Every slot gets the same C (only the changed pick reads it); `{k}` is the slot's number.
const reply3 = (c: string) => [1, 2, 3].map(k => [c.replaceAll('{k}', String(k)), `T${k}: 예측`, `Q${k}: x`, `H${k}: y`, `A${k}: z`].join('\n')).join('\n')

async function made($: any, on: any, reply: string) {
  const steps: Record<string, number> = { [NAME]: 2, 배열: 1, 반복문: 1 }
  const concepts = Object.fromEntries(Object.entries(steps).map(([name, step], i) => [conceptKey(name), { name, count: 3, firstAt: NOW - 60 * DAY, lastAt: NOW - 60 * DAY, blurb: name === NAME ? BLURB : `${name} 설명`, files: [], step, reviewedAt: NOW - 31 * DAY - (10 - i) * HOUR }]))
  const store = new Map<string, unknown>([['stepsFrom', 0], ['concepts', concepts], ['steps', ownSteps(concepts as never)]])
  const w = world(on, 'ok', null, true, store)
  w.harness = { models: { sonnet: { rungChangedStep: 2, isChangedRun: true } } }
  await start($)
  w.answer = ['### 한 줄 요약', '만들었습니다', '### 배울 개념', `- **${NAME}**: ${BLURB}`, '- **배열**: 배열 설명', '- **반복문**: 반복문 설명', '### 직접 확인해 볼 것', '- 실행해 보기'].join('\n')
  await turn($, () => $.tool.call({ tool: 'Write', tool_use_id: 'u1', file_path: '/proj/a.js', content: `${CODE}\n` }), 't1')
  w.files.set('/proj/a.js', `${CODE}\n`)
  await finish(w)
  w.answer = reply
  await learn($, '퀴즈 새로')
  const items = (((store.get('quiz') ?? {}) as { items?: { name: string; rung?: string }[] }).items ?? []).filter(one => one.name === NAME)
  return items
}

describe('R9 capture (1.13.0 batch 2 build, records only)', () => {
  for (const [label, c1] of [['own', 'C{k}: {k}d <'], ['own-number', 'C{k}: {k}b 90'], ['fallback', 'C{k}: {k}a 99999']] as const) {
    test(`a run-route item, ${label}`, { options: { model: 'sonnet', level: 'beginner' }, timeoutMs: 30000 }, async ($, on) => {
      const items = await made($, on, reply3(c1))
      expect(items.length).toBe(1)
      expect(items[0]!.rung).toBe('changed')
      ;(globalThis as any).console.log('R9ITEM ' + JSON.stringify({ label, item: items[0] }))
    })
  }
})
