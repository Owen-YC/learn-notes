
### 기준 전 GO 관문 결과: NO-GO → sonnet 재지 않음 (2026-11-14 11:52~11:58 UTC, 기록만 · B-12; 기준 커밋 · 잰 회차 없음)

위 '기준 전 GO 관문'의 규칙대로, 짓기 커밋 9f0dff1의 트리와 프롬프트로 sonnet만 불렀습니다. (가)의 '쓸 수 있는 줄 8개 가운데 7 이상'을 못 넘어(4/8) NO-GO입니다. 그래서 커밋된 규칙대로 1.12.0에서 G5 sonnet의 기준 커밋도 잰 회차도 없고, 더 다듬지 않습니다. MODEL_SWITCHES.sonnet.isThinkAsked는 false 그대로입니다(아래 '1.12.0 설계만 하고 재지 않음'의 G5 sonnet).

- 도구(관문 호출 전에 얼림, 2026-11-14 ~11:50 UTC, 저장소 밖 `impl112/b4/` 아래, chmod 444; 표 `impl112/b4/bar-tools.sha256` sha256 `dc8956f583c0b3d487bb1860cb94f67add0e7e9a83f5f2921534d0da7ba2913e`, 46파일; 백업 `impl112/backup/b4-bar-tools.tar` sha256 `0e18927274a05071a67c63314d08fb787cb79eb69b5092b7b9d3272796917656`, 50항목, 모델 id 0). 설계 파일럿 도구(`design/G5/pilot/tools`, 시제품 트리에 맞춰 지음)는 그대로 쓰지 않고, 9f0dff1 트리(`impl112/b4/mtree` = `git archive 9f0dff1`)를 가져오는 도구로 다시 지었습니다(아래 표). 관문의 차례는 호출 전에 얼린 `impl112/b4/go/procedure.txt`(`81e575924b2bae7b1d7a4960e5303afe1c857e0ae7edf6333586a89acac1bdb8`)입니다.
- 도구 시험(합성 입력과 설계 파일럿의 기록만): 러너 합성 9경우(A/B 넘김, input(), 끝나지 않는 반복, 씨앗마다 다른 출력, 이름으로 넘긴 도움 함수, None/undefined, 오류)와 파일럿 set3의 열린 줄 9/9가 파일럿 러너와 같은 결과; stage.sh 가짜 CLI로 관문 실패 7 · 기록 다름 3 · 다시 보내기 · 다시 시작 거부 · 10% 무효 6 · 던짐 5 · 차례 거부; check.py 얼림 · 'WRITE 2'; 파일럿 set3 기록으로 stored · 러너 · 보고서 · 셈 · 글 고르기 · 거르기 · 꼬리표 · 확인 줄 · 읽기 · go.py 끝까지; 판정자 실행 연기 시험(opus 1번); D34 시험 set 30/30 · real-r 20/20 · real-check 150/150.
- D34(켠 값, 하네스가 답함, 모델 호출 0): 합성 호출 종류 16시험 48/48 같음 — 노트 16, 앵커가 있는 범위 안 r 4, 앵커가 없는 범위 안 r 4, 범위 밖 r(TRACE_170) 8, 확인 8, 줄이 열리지 않은 질문 8; haiku와 sonnet, 팀 파일 없이와 있을 때(팀 파일이 있으면 노트와 r에 팀 규칙이 들고 확인에는 들지 않음; isRuleDrill은 두 모델 모두 꺼져 단계 2 요청 없음). 일부러 틀린 기대 3시험은 다름 5개를 모두 잡음. 관문 세트: 호출 전 12시험 36/36(노트 12, r 12 = 앵커 2 · 앵커 없음 3 · 범위 밖 7, 셋째 요청 12 = 확인 5 · 질문 7), 노트 답 뒤 real-r 12시험 24/24(r 줄 파일 그 자체와 바이트까지 같음).
- 환경 기록: 이 컨테이너의 `/dev/null`이 글이 든 보통 파일이라(셸 시작 글이 써 넣음; 장치로 되돌리는 것은 허락되지 않음), 도구는 표준 입력으로 `impl112/b4/work/empty-stdin`(빈 파일)을 씁니다(앞 'ok' 세션, 러너). 앞 묶음들의 앞 'ok' 세션은 `< /dev/null`이었으나 그 세션은 판 · 별칭 기록과 사용량만 읽으므로 기록 값은 영향받지 않습니다.
- 견본(개발 세트, 잰 견본으로 결코 쓰지 않음): `gen/run.sh gate 1`, 새 눈가림 쓰는 쪽(고정한 길 2.1.323, 빈 폴더, `claude -p --model opus --tools ''`, 프롬프트는 stdin; 제품 수준 말씨 `gen/writer-gate.md` + 그때의 NAMES-all.txt에서 지은 피할 이름(파일 1,211 · 이름 1,243) + `gen/writer-gate-end.md`, 다 지은 프롬프트 sha256 `632587e26b500883be9ee48ac7dd13c67e2365ea428136b2ff9ec2bf868e435a`), 11:52:04Z → 11:54:12Z, 한 번에 읽힘. `tools/check.py gate`로 얼림: changes.json `358c5597ca1ab2689099b6a0acc31252fd7d836058f9b38c2316a4fe1a646f91` · hunks.json `e0fdfec2854bdbcd1f7c90c3fc276661ecca40f60383d98a3d4b14885e7f51c1` · check.json `0edab3c98f6b6b23fa64fe66fa9ed1733d3da7553c05a8337544ead3c360be7c`; 이름 겹침 0; 짜임(쓴 이의 것, 고치지 않음): 범위 안 새 파일 3 · 고침 7, 맨 위 수준 호출 있음 6 · 없음 2(요청은 3 이상씩), 가장자리 3. 이름은 `design/G5/dev/NAMES.txt`(지금 sha256 `2d70e604c42335f866e3bea5f97572a1269d7c4824b3bcc226a935cf2982be38`)와 `impl112/NAMES-all.txt`(G5-dev 39줄 더함, 지금 `2cd558815461b730014f34b5bc7b3a3729a44e15970824cb2421debb9f3769dd`, 6,521줄)에 덧붙였습니다. 백업 `impl112/backup/b4-go-samples.tar` `0e1f95f581db1b1a9c334aca672152ecf4ff6e35adc9196599c39c8b9047a57b`.
- 부르기(상태만, 고정한 길, 떼어 낸 러너 `tools/stage.sh`): 노트 스테이지 11:55:55Z → 11:56:27Z(줄 파일 `61b8033b…d825`), r 스테이지 11:57:00Z → 11:57:27Z(줄 파일 `12ee4f8c…40cb`). 두 스테이지 모두 12/12 답함, 다시 보낸 것 0, api-error 0, 빈 답 0, 시간 한도 0, 거절 0(탭 보낼 것 없음). 사용량 관문: 노트 앞 five_hour 0.17 · seven_day 0.45(주간 예상 0.10을 더해 0.55 < 0.80) → 넘음; r 앞 0.17 · 0.45 → 넘음. 그동안 이 묶음의 에이전트 말고 다른 워크플로는 돌지 않았습니다. 모델 기록: 앞 'ok' 세션과 프로브 세션의 판 · 고정 sha256 · 별칭 id가 묶음 0과 같음(두 스테이지 모두 after.json same). 답 파일 sha256: 노트 `74c886c2eb1014a1fe891027738eb94b0cc9c7e79e049a5b47686f5a1eed5344` · r `8b192f4c7bf0e11abbe5064c0de178650972455c16c520bde24d9a08600e018d`. 백업 `impl112/backup/b4-go-a.tar` `4835f17a2bc91a4a138633b0f40e69ce17de06b160966147c3d3262a69a27659`.
- (가) 수(얼린 파일에서 기계적으로, `go/tally-a.json` `f70b1345…659a`)
  - 쓸 수 있는 줄 **4/8**(선 7): 열린 줄은 PG01 · PG02 · PG03 · PG04 넷뿐이고, 넷 모두 러너 결과가 있고(방법 A, js 2 · ts 2) 두 판정자 모두 노출 ok · 입력 ok(근거 [(가)] 노출 (i)–(iv), S10, S7; 판정 파일 `6c0b2358…dd07` · `d78da0e0…64fc`, 보고서 `6a813dea…e251`).
  - 열리지 않은 범위 안 넷: PG06 · PG07 · PG08은 플러그인 코드의 범위(thinkCallees)가 빼서 r이 1.7.0 말씨(TRACE_170)로 갔습니다(호출 전 D34에서 이미 보임: 범위 안 r은 5개). 까닭(관문 뒤 기록, 시제품 함수를 바꾼 사본으로 확인, 결정에 들지 않음): PG07(js+js)은 `Math.round`(반올림 자름), PG08(py+md)은 `round(`(반올림 자름), PG06(py)은 `mins, secs = length_text.split(":")`처럼 튜플로 나눠 받는 지역 이름을 코드가 아는 이름으로 읽지 못함(같은 몸을 `parts = …`로 쓰면 범위 안). PG05(py)는 범위 안이었으나 r이 쓴 생각해 보기 줄을 thinkCallKept가 받지 않아 열리지 않았습니다(따라간 예시 호출이 `beans_for_cups(4, extra_shots=2)`처럼 이름 붙은 인자를 써서, 인자 하나를 바꾼 호출도 이름 붙은 인자가 되어 거부됨).
  - 열면 안 되는 4개 가운데 연 것 0/4, 노출 0, 상한 닿음 0(노트 가장 큰 것 1,130 < 5,548; r 가장 큰 것 865 < 2,948), r의 가장 큰 output_tokens **865** ≤ 2,300, 거절 0.
- (나): 돌리지 않았습니다. 얼린 차례 6('(가)가 GO 줄 하나라도 못 넘으면 (나)는 NO-GO를 바꿀 수 없으므로 돌리지 않음')대로이고, 그래서 글 쓰는 쪽 · 꼬리표 확인 · 확인 호출 50번 · (나) 판정자는 없습니다. 관문의 호출은 sonnet 24번 + opus 쓰는 쪽 1 + 판정자 2입니다(계획의 약 74 + 2 + 2보다 적음).
- 판정(`tools/go.py X` → `go/go.json` `5600f0bd5bfd7e4a6fab15342e4281bc78164f8c2aa7479778cc094e6df1c49b`): **NO-GO**. 못 넘은 줄은 '(가) 쓸 수 있는 줄 ≥ 7/8' 하나(4/8)입니다. 백업 `impl112/backup/b4-go-verdict.tar` `d2a595d62d46b57640a0dc49c3dd290755898953b6f4d527828b0f83cfecbbe0`(86항목, 모델 id가 든 두 파일은 tar 안에서 `<model-id>`로 가림).
- 관문 뒤: hooks/ · 시험 · 프롬프트를 짓는 도구는 하나도 바꾸지 않았습니다(이 커밋은 견본.md만). 이 결과로 다듬지 않습니다(G5.json: 관문 뒤 다듬기 없음).

관문에 쓴 도구(sha256, 위 표 파일의 46줄 그대로; `impl112/b4/` 아래)

| 파일 | sha256 |
| --- | --- |
| `tools/kit.mjs` | `6e81e1d4e768231218b51336a857d651205a75337dab9c877133de391dc9fa77` |
| `tools/build.mjs` | `fed2160c49b74cc01d777a445c0a995e802581a3f217e295315442b8f335d293` |
| `tools/prep.py` | `a97b4e04aab723f866b8d40e30670b6d9a615a539b3a6c567c74e55aeb1dad23` |
| `tools/check.py` | `1bd15c1505bd46c744b6448a3cc4c194e64f730c805f34569d1871f7bf31b42a` |
| `tools/runner.py` | `97e987008c141a0ebd0c3e9897a4428026c471cbea11a1b6a30ae11af6d119c5` |
| `tools/stage.sh` | `c47277f0081dbe08e18dc1facf0858d760bbde689fd78ed7e8eb0598d5a1f210` |
| `tools/gate.py` | `a40a84e7ecdd5e94e9a59036107c199fda28b30d0b5127cc9d856fca5e2f49c0` |
| `tools/tapsend.py` | `337bc7bc788d1f57300de34d597b50ba5d0758a4c473007e88352693a4454eaa` |
| `tools/texts.py` | `713fa0535a05e8d497d16f7ad7655e633ee8aa3bdd42410c91233c995e7e4008` |
| `tools/judge.py` | `cc6e5c4220cdd157414974deed5ff7cbdd195ef727c5b2c6697f27488dbd3f07` |
| `tools/tally.py` | `1dabe386510c7945b6b9b531e06a2673772a2c93e54512969f6516a8a47167df` |
| `tools/go.py` | `887cd00998e91ace5847ea96d1ad4fb29ed046c641f33589a8fd79c9c33dfe52` |
| `tools/decide.py` | `9c18a4269a6c31e9a51c46978b1e7ea5501820b84dade7052558dfdc2ad3237a` |
| `tools/label.py` | `ff99986293cb339998bb5d8f349e137211881ff086a23e42b6863c201fe2b5b5` |
| `d34/make.py` | `33c2ccb540245978957a7c6af2981690af38a477ee5d986dea39233d979b071b` |
| `d34/expect.mjs` | `76e53700795d27d7329177c4b1253293ee8d46d2d95a82b1dc31b138bcc64744` |
| `d34/team.md` | `18f9d5c755f49db4f9dd767b380bdda569609ffa6a6021ca9f9525881a9b0c9b` |
| `d34/syn/changes.json` | `c91c4412ea175d676f170fc05b3b6d8a9909b02cd73cb552c03cff591276c0c9` |
| `d34/syn/hunks.json` | `18b080cf8f0e73756a3d780b5d45e1b50aa09102618eb04a3d1c5dd06e04bf8c` |
| `probe/call.sh` | `873f5bde02c1709e68ff121b866778fd1b2fd494a284544dbd75482939974c00` |
| `probe/precheck.sh` | `f58ed45959f30fe97bac969cce97fc63027eb85973e9c60a3ef0bd0d2ee86d5b` |
| `probe/record.py` | `56e7d112d6ee4b248bac0fac3f8a3bf4128d49a150d766ccd249831ff7bdd0a2` |
| `probe/mod/hooks/register.ts` | `139620927ab47ebca581de14e38d64a7d9cfd296324a98ed4da095220bb42680` |
| `probe/mod/hooks/notes.ts` | `d899d0c160beabe0375d5fb59fd65d122f0403a87ffd1aaeeacd779124e680f0` |
| `probe/mod/hooks/hooks.json` | `c835c92d8e1159d20a40ca78ad654da7433942c3694ffeda0b376b0c4dfd52cf` |
| `probe/mod/.claude-plugin/plugin.json` | `d68a0d2ea837ae12188ad5e454f01ae142276fc32b5fd9b2b48d4f89b2d794f5` |
| `tap/call.sh` | `b590511f4ad1a485fe34c2ecb2dd29cb79a371239869df38a9a02e3fdfab58bb` |
| `tap/tap.py` | `e8d8174b09e11c74e6d744e4c44bc62033436d2ab35be6daa95d27026d17db9b` |
| `tap/mod/hooks/register.ts` | `fdcf1a5818aa87ee63582994b7c7be68c711b299a97780add324814cb9fad44f` |
| `tap/mod/hooks/hooks.json` | `c835c92d8e1159d20a40ca78ad654da7433942c3694ffeda0b376b0c4dfd52cf` |
| `tap/mod/.claude-plugin/plugin.json` | `df71541c4b831779c994aaa2611d7a45a1678948478118e647f13b2c37b2e51a` |
| `tap/mod/tsconfig.json` | `88437ec880f7008b5df208a95a7d47330f0e3a8204d78d6c5cc272e5941c3511` |
| `gen/writer-gate.md` | `f742e7b4231c9a3df0f40fb4bc0109f7876839ca88b7038d17b58b8dba4f3524` |
| `gen/writer-gate-end.md` | `67c75049cecae58e52abedb0b6a35f3ab5ecfd4aa403b8dd323d741898f51d30` |
| `gen/writer-A.md` | `6122aa5fb1fbc116923c15c01918773b987d10ff6e74262f12783cf4db98ee11` |
| `gen/writer-A-end.md` | `636d2f0d7040f9d23c51d01a762c74ab93bdf70424bebcc8d2238a7fa6ca852b` |
| `gen/avoid.py` | `37e176b25e313b9513ab0c9b66ba1ca5825eb93ff2028cbb07ecb4e6f5275aa5` |
| `gen/run.sh` | `84be679d57cd93ca80c0181fec25b49fe74b4a60e428d1152bda3348ee2c05ed` |
| `judge/tpl-texts.md` | `b1dfbf27e5b8905ba39dbf863402ec2491afdf8540066bdf75aac74e0b72424f` |
| `judge/tpl-labelcheck.md` | `ddf12823c225ee65e51bdca744261d54dda675b7ecfe5163ddde2c08e9e0606b` |
| `go/stance-G5.json` | `ef1b377a4f16455a0380c2604420f89c80836d974f29bf7561228c653a2c631e` |
| `go/preBarGate-plan.json` | `2de6efddb78cca6693082ae92e0ac054fbb497ff86baa88b2c5fd8858a763dbe` |
| `go/procedure.txt` | `81e575924b2bae7b1d7a4960e5303afe1c857e0ae7edf6333586a89acac1bdb8` |
| `mtree/hooks/notes.ts` | `d899d0c160beabe0375d5fb59fd65d122f0403a87ffd1aaeeacd779124e680f0` |
| `mtree/hooks/register.tsx` | `fe7c80dff6ee38d835fc15eda11fd6df3029b0c059ce015e768db59e47c4ef74` |
| `mtree/tests/flowkit.ts` | `37a8b6371bbec5f665a86547f48a4283b459283913df7e2038e2d03fa628a8d3` |

