
#### 결정 규칙

설계 decisionRule(옮김)
- 모델 m ∈ {haiku, sonnet}마다, m의 수로만: A_m = (가)-1 ≥ 20/24 ∧ (가)-2 = 0/22 ∧ (가)-3 = 0 ∧ (가)-4 = 0/46 ∧ (가)-5 가장 큰 r ≤ 2,500에 해당하는 값. B_m = A_m의 쓸 수 있는 줄 ≥ 10 ∧ n1과 n2 두 회 모두: 짐작 ≥ 27/30 ∧ 질문 ≥ 19/20 ∧ 모르겠어요 ≥ 3/4 ∧ 확인 상한 닿음 0.
- MODEL_SWITCHES[m].isThinkAsked = true는 A_m ∧ B_m일 때만; 아니면 false. 재지 않는 모델(이 설계의 권고로 haiku)은 false 그대로. IS_THINK_ASKED는 false 그대로. THINK_VARIANT는 기준 커밋 뒤에 결코 바꾸지 않습니다.
- 스위치는 결정 커밋 다음 커밋에서만 바뀌고, 옛 창 탐침(R9: 3f2b4fb, 7a7b08c, 3690021, fca5988이 저장된 정해진 줄을 열고 답함), 끈 바이트 고정물, 켠 값에서 돌연변이 탐침 둘 이상이 통과해야 합니다(R6).
- 기준 전 GO 관문(pilot.preBarGate)이 sonnet에서 못 넘으면 잰 회차는 없고 칸은 false 그대로입니다(견본.md에 적음).

계획 묶음 4의 결정(barSource.decision): MODEL_SWITCHES.sonnet.isThinkAsked = true는 A_sonnet ∧ B_sonnet일 때만; 아니면 false. haiku는 false 그대로. IS_THINK_ASKED는 false 그대로. THINK_VARIANT는 기준 커밋 뒤에 바뀌지 않습니다. 넘으면 값 커밋(switchCommit): MODEL_SWITCHES.sonnet = { ...SWITCHES_OFF, isRuleWide: true, isThinkAsked: true }에 이미 켜진 다른 sonnet 칸을 더함; 옛 창 탐침 R9(실제 빌드 여섯 3f2b4fb (1.7.0) · 7a7b08c (1.7.1) · 3690021 (1.8.0) · fca5988 (1.9.0) · 3d2f251 (1.10.0) · de98243 (1.11.0))과 coexist19; 끈 고정물; 켠 값에서 돌연변이 탐침 둘 이상; 잰 프롬프트를 값 트리에서 다시 지어 바이트까지 같음. (이 묶음의 기록, 원문 밖: 계획의 R9 여섯 빌드가 설계 decisionRule의 넷보다 엄해 여섯을 따릅니다.)

계획 묶음 4의 멈춤(stop): H_sonnet ≠ 2048 → 관문 · 기준 커밋 · 회차 없음(해당 없음: 2048). GO 파일럿의 기록 ≠ 묶음 0 → GO 판정 없음, M-10 멈춤. GO 관문을 못 넘거나 관문 뒤에 G5 요청을 짓거나 읽는 것이 바뀜 → 기준 커밋 · 회차 없음. (가) 쓸 수 있음 < 10 → (나)를 돌리지 않음; 못 넘음.

#### 모델마다 (설계 perModel, 기록만 · B-12, 결정에 들지 않음)

- haiku: THINK_VARIANT.haiku = 'trace'(1.11.0이 잰 확인의 한 줄 따라가기, 좁은 종류 말씨). 권고는 재지 않음: 칸은 false 그대로이고 회차를 쓰지 않습니다. 개발 (가)는 괜찮습니다(쓸 수 있음 16/16, 14/16, 9/10; 범위 밖 28개 가운데 연 것 0; r 최대 1,774). 그러나 (나) 질문이 파일럿 다섯 회에서 17, 17, 16, 16, 16/18이고 마지막 말씨로 17/18이었는데, 모델 한계의 답 오류(덧붙인 답의 틀린 사실, 예: parseInt("1e", 10)) 때문입니다. 모르겠어요는 1/4, 마지막 말씨로 3/4; 짐작은 25–29/30과 25/27.
- sonnet: THINK_VARIANT.sonnet = 'basis'(결과를 정하는 식 하나, 적은 따라가기 없음; 넓은 종류 말씨). 권고는 잼, 기준 전 GO 관문 뒤에, 그리고 보정이 H_sonnet을 정할 때만(위험 R1). 개발: (가) 쓸 수 있음 14/16, 14/16(py 범위 거짓 음성 하나, 그 뒤 고침), 9/10; 범위 밖 28개 가운데 연 것 0; r 최대 792; (나) 짐작 28, 27, 29, 30, 25/27(정해지지 않은 돌려줌-대-찍음 2개, 지금 S9)과 짐작 27/27, 질문 18/18, 모르겠어요 4/4, 가장 큰 확인 출력 461, 거절 0(set3 글을 한 번 다시 보냄, 판정자 하나, 기록만); 질문 18, 16, 19, 17, 18/18, 마지막 말씨로 18/18; 모르겠어요는 모든 회에서 4/4; sonnet 개발 호출 454번에서 거절 0.

#### 견본의 짜임

설계 samples(옮김)
- (가) 변경 46개, 두 모델이 같이 씀(앞선 37개를 가까운 꼴 9가지로 키움; id · 파일 · 함수 이름은 K01–K37, impl111 gen/names.json, 1.8/1.9 이름, design/G5/dev/NAMES.txt의 모든 개발 이름, 범위 집합 PC01–PC40(design/G5/dev/cov/changes.json)과 겹치지 않음).
- 범위 안 묶음 24: 쓰는 이의 요청이 '입력에서 값을 계산해 돌려주는 짧은 함수를 고치거나 써 줘'인 변경. js 7(node 스크립트 1 포함, 그런 함수를 중심으로 짠 것), ts 5, py 6, 두 파일 6(js+js, ts+ts, py+py, 함수가 js에 있는 js+css, ts+json, py+md). 새 파일(Write) 8 이상, 있던 파일 고침 10 이상; 파일이 이미 맨 위 수준에서 함수를 리터럴 값으로 부르는 것 8 이상, 그렇지 않은 것 8 이상; 자연스러운 다른 입력이 오류 · 가드 값 · 바뀌지 않음 · 빈 결과로 끝나는 것 5 이상. 쓰는 쪽에게는 범위 규칙을 하나도 알리지 않습니다(API 목록, hunk 모양, '±3줄 안에 통째로', '찍지 않음' 없음): 위 제품 수준 정의와 '초보의 사실적인 파일'만. 이 묶음은 플러그인 코드로 거르지 않습니다: 쓴 이가 뜻한 변경을 thinkCallees가 빼면 (가)-1 놓침입니다(코드의 거짓 음성은 비용).
- 열면 안 되는 묶음 22(기준: 열린 줄 0): 흐름 없음 9(앞과 같음: 설정 json, 도구 설정 js와 ts, 스타일 2, md, script 없는 html, jsx className/글자, 값만 든 js/ts, py 상수); 흐름 있는 다른 언어 4(go, rb, sh, vue); 그리고 쓰는 쪽에게 규칙이 아니라 자연스러운 장면으로만 말한 가까운 꼴 9가지: (1) 페이지를 바꾸는 버튼 클릭 핸들러, (2) useState를 쓰는 React 카운터 컴포넌트, (3) TSX 목록 컴포넌트, (4) js+css 메뉴 여닫기, (5) 표나 목록을 찍고 아무것도 돌려주지 않는 함수, (6) 모듈 수준에 둔 목록이나 개수에 더하는 함수, (7) 메서드를 고치는 클래스, (8) 다른 파일에 정의된 설정을 쓰는 한 줄 화살표 함수나 기본 매개변수, (9) 가운데를 고친 긴 함수(20줄 이상). 파일럿 코드가 겨냥해 지은 꼴(Math.round/round, argv 스크립트, 보이지 않는 상수)은 개발 세트에 한 번도 없던 (5)–(8)로 바꿨습니다(비평).
- r 호출: 모델마다 46번((가)-4는 46번 가운데 0을 셈).
- 새 하위 에이전트 `claude -p --model opus --tools ''`가 빈 폴더에서, 프롬프트를 표준 입력으로 받아 씁니다. 프롬프트 · 입장 · 설계 · 어느 모델을 재는지 · 이 기능의 코드를 본 적이 없습니다. 어떤 호출보다 먼저 얼립니다(chmod 444, sha256, 쓴 이, UTC). 엔진 꼴 hunk는 impl111 prep.py 규칙으로 짓습니다(difflib, 위아래 세 줄; Write = creationHunk).
- (나) 꼬리표마다, 그 모델의 (가) 쓸 수 있는 줄이 10 이상일 때만: 그 모델의 쓸 수 있는 줄에서 얼린 차례로 기계적으로 고른 물음 10개(js 5 — 두 파일 js는 js로 셈; ts 2; py 3; 러너 결과가 오류 · 가드 값 · 바뀌지 않음 · 빈 것인 것 3 이상; 가장자리 하한은 1.11.0의 바꿔 넣기 규칙).
- 꼬리표마다 글 54개를 새 하위 에이전트가 씁니다. 그는 줄, 따라가기, 노트, 꼬리표만 봅니다: 짐작 30(물음마다 맞음, 틀린 값, 문제 짐작; '맞음'은 학습자가 쓰듯, 따옴표가 있든 없든), '모르겠어요' 4, 질문 20 = '?' 질문 10(결과가 아니라 성질을 묻는 예/아니요 질문 3 이상 포함), '?' 짐작 5('…터지나요?', 'NaN?' 꼴), '?' 없는 질문 5. 부르기 전에 1.11.0의 거르기 표를 질문 글에 씁니다. 글마다 쓴 이가 뜻한 갈래가 붙고(판정 파일을 얼릴 때까지 봉인), 두 번(n1, n2) 부르고 따로 셉니다.
- 겹치지 않을 개발 이름: set1 PD01–PD30, set2 PE01–PE30, set3 PF01–PF10(design/G5/dev/NAMES.txt의 모든 파일과 함수; changes sha256 set1 0173b633…, set2 1bd2971a…, set3 0081574e…); 범위 집합 PC01–PC40(design/G5/dev/cov/changes.json, sha256 de1aea35b2329cdb5225115c4af21ea86e46b6c62ba4916624a1f27b5d6983eb); 1.11.0 K01–K37과 impl111/b7/gen/names.json(1.8.0, 1.9.0 이름).
- 기준 전 관문 견본: pilot.preBarGate의 새 개발 세트 PG01–PG12(잰 쓰는 쪽의 제품 수준 말씨로 범위 안 8, 열면 안 되는 가까운 꼴 4), 이름은 NAMES.txt에 적음; 잰 견본으로 결코 쓰지 않음.

계획 묶음 4의 견본(samples): layoutA — (가) 변경 46: 범위 안 24(js 7, node 스크립트 1 포함, ts 5, py 6, 두 파일 6; 새 파일 ≥ 8, 고침 ≥ 10; 맨 위 수준 리터럴 호출이 있는 것 ≥ 8, 없는 것 ≥ 8; 가장자리 결과 ≥ 5), 플러그인 코드로 거르지 않음; 열면 안 되는 22(흐름 없음 9, 흐름 있는 다른 언어 4, 장면으로만 말한 가까운 꼴 9가지). 엔진 꼴 hunk는 impl111 prep.py 규칙. layoutB — (나)는 쓸 수 있음 ≥ 10일 때만: 쓸 수 있는 줄에서 기계적으로 고른 물음 10(js 5, ts 2, py 3; 가장자리 ≥ 3), 꼬리표마다 새 쓰는 쪽이 쓴 글 54(짐작 30, 모르겠어요 4, 질문 20 = '?' 10(예/아니요 성질 ≥ 3 포함), '?' 짐작 5, '?' 없음 5), 1.11.0 거르기 표, 뜻한 갈래 봉인; 두 번(n1, n2) 부름. avoid — design/G5/dev/NAMES.txt(PD01–PD30, PE01–PE30, PF01–PF10, 관문의 PG01–PG12), 범위 집합 PC01–PC40, 1.11.0 K01–K37과 impl111/b7/gen/names.json, impl112/NAMES-all.txt.

#### 부르기

설계 calls(옮김)
- 플러그인이 부르는 그대로(D20): design/G5/pilot/probe의 impl111/probe 사본이 $.model.complete({model: 'haiku' | 'sonnet'(설정 글자), effort: 'low', system, prompt: redactText(prompt).text, maxTokens, timeoutMs: 90000})로 4개씩 부르고, 답은 fixEscapedTicks를 거칩니다. (이 묶음의 기록, 원문 밖: 이 묶음은 같은 꼴의 묶음 3 프로브 사본 `impl112/b4/probe/mod`(명령 `/g5probe`, notes.ts = 9f0dff1)을 씁니다.)
- 호출 종류마다: 노트 SYSTEM + notePrompt, maxTokens 3500(NOTE_TOKENS); r ASK_SYSTEM + askPrompt(shown, redactText(traceCallQuestion(callees) | traceQuestion(false)).text, 'beginner', teamOf → 없음, undefined, true), maxTokens 900; 확인 THINK_SLOT_SYSTEM + thinkSlotCheckPrompt(shown, think, masked, 'beginner', THINK_VARIANT[model]), maxTokens 900(THINK_CHECK_TOKENS). 프롬프트는 기준 커밋의 notes.ts를 가져와, 그 모델의 isThinkAsked만 켜고 짓습니다.
- 시각: r은 NOTE_AT + 120000에 답함; 줄은 openThink(asks, at + 60000, true, true)로 읽음; 확인 호출은 askNote가 저장하는 asks로.
- 잴 호출 전 D34: 호출 종류마다(노트; 앵커가 있는 범위 안 r; 앵커가 없는 범위 안 r; 범위 밖 r = TRACE_170; 확인) 켠 값에서 플러그인 시험 하네스로 요청 하나를 잡아, 모델마다, 팀 파일 없이 그리고 팀 파일이 있을 때(askPrompt의 rules 인자) 도구의 프롬프트 파일 · maxTokens와 바이트까지 같아야 합니다.
- 먼저 설치된 2.1.323에서 DISABLE_AUTOUPDATER=1로 보정(M-5): 모두 maxTokens + H에 닿는 상한으로 H_haiku와 H_sonnet(G1 파일럿의 128 상한 sonnet 호출은 459/392에서 상한 아래로 멈춰 'H_sonnet 0'이 정해지지 않았고; 64와 256 상한은 2112와 2304 = 상한 + 2048을 냄). 그 기록이 모든 회차의 앞 기록입니다. 판과 init 모델을 회차 앞뒤로 적습니다.
- 차례: 스테이지마다 haiku를 모두, 그다음 sonnet(haiku를 재지 않으면 sonnet만 부름); 스테이지의 답을 sha256과 함께 저장하기 전에는 아무 답도 열지 않음; 빈 답은 탭으로 한 번 다시 보냄(기록만); 코드 돌리기는 빈 임시 폴더에서 오프라인(unshare -n timeout 5; py 씨앗 다섯).

계획 묶음 4의 부르기(calls): sonnet — 노트 46(3500) + r 46(ASK_SYSTEM, traceCallQuestion/traceQuestion(false)의 askPrompt, 900) + 확인 108(THINK_SLOT_SYSTEM, thinkSlotCheckPrompt(…THINK_VARIANT.sonnet), 900) = 200; timeout 90000; r은 NOTE_AT + 120000에 답함, 줄은 openThink(asks, at + 60000, true, true)로 읽음. 다시 받기: G5 (가) 노트 호출만 transientOf 실패에 한 번 다시 받음(D6); 빈 답 · 시간 한도 · 상한 닿음은 다시 보내지 않음; 빈 답은 탭으로(기록). 스테이지: 노트, r, 그다음 (나) n1, n2 — sonnet만(haiku는 재지 않음). 판정자: (가)에 가린 판정자 둘, sonnet 꼬리표의 (나) 회마다 둘(opus 6번); 갈림 = 놓침. (이 묶음의 기록, 원문 밖: 1.11.0 도구와 같이 노트 스테이지의 다시 받기는 api-error와 자기 시간 한도로 끊긴 호출(transientOf 'timeout')에 한 번이고, 입장 [공통]의 전송 실패 줄대로 r · 확인의 api-error도 한 번 다시 보냅니다.)
