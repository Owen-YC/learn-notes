import * as K from '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4/tools/kit.mjs'
for (const {sample, entry} of K.samplesOf(K.S + '/go/frozen')) {
  const sh = K.shownOf(K.noteOf(entry, sample))
  const c = K.N.thinkCallees(sh.changes)
  console.log(sample.id, sample.group, sample.lang, sample.edge, c.map(x=>x.name+(x.anchor?'@'+x.anchor:'')).join(',')||'-', sh.changes.map(x=>x.file+':'+x.kind).join(' '))
}
