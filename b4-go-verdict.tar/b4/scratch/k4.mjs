import * as K from '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b4/tools/kit.mjs'
const N = K.N
const scope = (path, content) => { const ch = N.changeOf({ path: '/proj/' + path, root: '/proj', tool: 'Write', kind: 'create', hunks: [N.creationHunk(content)] }); return N.thinkCallees([ch]).map(c => c.name) }
const pg06 = 'def song_seconds(length_text):\n    """x"""\n    mins, secs = length_text.split(":")\n    return int(mins) * 60 + int(secs)\n'
console.log('PG06 fn only', scope('song_length.py', pg06))
console.log('PG06 + main input', scope('song_length.py', pg06 + '\n\nif __name__ == "__main__":\n    typed = input("x")\n    print(f"{song_seconds(typed)}초")\n'))
console.log('PG06 + main no input', scope('song_length.py', pg06 + '\n\nif __name__ == "__main__":\n    print(song_seconds("3:25"))\n'))
console.log('PG06 no docstring', scope('song_length.py', 'def song_seconds(length_text):\n    mins, secs = length_text.split(":")\n    return int(mins) * 60 + int(secs)\n'))
const pg08 = 'def percent_right(right, asked):\n    if asked == 0:\n        return 0\n    return round(right / asked * 100)\n'
console.log('PG08', scope('spelling_test.py', pg08), 'no round', scope('s.py', pg08.replace('round(right / asked * 100)', 'right * 100 // asked')))
const pg07 = 'function wonPer100g(won, grams) {\n  return Math.round((won / grams) * 100);\n}\n\nfunction cheaperPackLabel(packA, packB) {\n  const perA = wonPer100g(packA.won, packA.grams);\n  const perB = wonPer100g(packB.won, packB.grams);\n  if (perA < perB) return "A";\n  if (perB < perA) return "B";\n  return "같음";\n}\n\nmodule.exports = { wonPer100g, cheaperPackLabel };\n'
console.log('PG07', scope('src/unitPrice.js', pg07), 'no round', scope('src/unitPrice.js', pg07.replace('Math.round((won / grams) * 100)', '(won / grams) * 100')))
