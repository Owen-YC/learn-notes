#!/bin/bash
# usage: one.sh <out-name> <test files...>  copy the repo's mod (hooks, types, fixtures, flowkit) and the given tests, run them with the pinned CLI
R=/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1/rv
N=$1; shift
D="${R:?}/run-$N"
rm -rf "${D:?}"; mkdir -p "$D/tests"
cd /home/user/learn-notes && cp -r .claude-plugin hooks types tsconfig.json "$D/" && cp -r tests/fixtures tests/flowkit.ts "$D/tests/"
for t in "$@"; do cp "tests/$t" "$D/tests/"; done
cd "$D" && /tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/cli/pinned.sh claude plugin test . > "$R/$N.log" 2>&1; echo "exit $?"
grep -E "^\(fail\)| pass$| fail$" "$R/$N.log" | head -30
