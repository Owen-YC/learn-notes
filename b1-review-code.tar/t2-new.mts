import * as N from '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1/rv/newtree/hooks/notes.ts'
const TEAM_MD = ['# 팀','','## 규칙','- 기록은 `console.log`(파이썬은 `print`) 대신 `log.info`로 남긴다',''].join('\n')
const RULES = N.parseTeamFile(TEAM_MD).rules
const mk = (file, added) => ({ file, path: '/p/'+file, tool:'Write', kind:'create', added: added.length, removed:0, diff: ['@@ -0,0 +1,'+added.length+' @@', ...added.map(l=>'+'+l)].join('\n'), isCut:false })
for (const [file, added, said] of [
  ['user.js', ['export async function getUser(id) {', '  const res = await getJson(`/u/${id}`) // console.log(res)', '  return res', '}'], '기록은 `log.info`로 남기라는 규칙과 달리 `console.log`가 남아 있습니다'],
  ['app.py', ['def total(rows):', '    s = sum(rows)  # print(s)', '    return s'], '기록은 `log.info`로 남기라는 규칙과 달리 `print`가 보입니다'],
]) {
  const note = { changes: [mk(file, added)] }
  const plan = N.ruleFixPlan(note, RULES, said)
  console.log(JSON.stringify(plan, (k,v)=> k==='known'?undefined:v))
  if ('fix' in plan) {
    const text = '## 무엇이 바뀌었나\n설명\n\n## 왜 이렇게 바꿨을까\n- 팀 규칙과 다를 수 있음: ' + said + '\n\n### 직접 해 보기\n- 할 일: 없음'
    const made = N.ruleFixMade(text, plan.fix, note.changes)
    console.log(made)
    console.log('drill', JSON.stringify(N.drillOf(made, note.changes, true)))
    console.log('---shown---\n' + N.hideDrillAnswer(made, file, { isRuleDrill: true }))
  }
}
