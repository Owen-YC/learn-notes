import * as N from '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1/rv/newtree/hooks/notes.ts'
const TEAM_MD = ['# 팀','','## 규칙','- 기록은 `console.log`(파이썬은 `print`) 대신 `log.info`로 남긴다',''].join('\n')
const RULES = N.parseTeamFile(TEAM_MD).rules
const mk = (file, added) => ({ file, path: '/p/'+file, tool:'Write', kind:'create', added: added.length, removed:0, diff: ['@@ -0,0 +1,'+added.length+' @@', ...added.map(l=>'+'+l)].join('\n'), isCut:false })
const said='기록은 `log.info`로 남기라는 규칙과 달리 `console.log`가 남아 있습니다'
for (const added of [
 ['async function getUser(id) {', '  const res = await getJson(url) // console.log(res)', '  return res', '}'],
 ['function add(a, b) {', '  const sum = a + b // console.log(sum)', '  return sum', '}'],
]) {
 const note = { changes: [mk('user.js', added)] }
 console.log(JSON.stringify(N.ruleFixLines(note, RULES, said).cands,(k,v)=>k==='known'?undefined:v))
 const plan = N.ruleFixPlan(note, RULES, said); console.log(JSON.stringify(plan,(k,v)=>k==='known'?undefined:v))
}
