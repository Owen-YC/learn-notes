import * as A from './orig/hooks/notes.ts'
import * as B from './mut/hooks/notes.ts'
const rules = A.parseTeamFile(['# 팀','','## 규칙','- 서버 요청은 `fetch`(파이썬은 `requests`)를 바로 쓰지 말고 `apiRequest`(파이썬은 `api_request`)를 쓴다','- 기록은 `console.log`(파이썬은 `print`) 대신 `log.info`로 남긴다','- 날짜를 글자로 보일 때는 직접 만들지 말고 `toDateText`를 쓴다',''].join('\n')).rules
const pool = ['const res = await fetch(url)', 'console.log(x)', '  console.log(x);', 'const  res = await fetch(url),', 'return x', 'const s = d.toISOString()', 'print(x)', 'x', 'console.log(x)  ', '// c', 'let a = 1']
const files = ['src/a.js', 'tests/a.test.js', 'src/b.js', 'app/a.py', 'scripts/x.js']
let seed = 7; const rnd = (n: number) => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed % n }
const saids = ['기록은 `log.info`로 남기라는 규칙과 달리 `console.log`가 남아 있습니다', '서버 요청은 `apiRequest`로 하라는 규칙과 달리 `fetch`를 바로 씁니다', '날짜는 `toDateText`로 보이라는 규칙과 달리 `d.toISOString()`로 직접 만듭니다']
let diff = 0, n = 0
for (let t = 0; t < 20000; t++) {
  const changes = Array.from({ length: 1 + rnd(3) }, () => {
    const file = files[rnd(files.length)]!
    const hunks = Array.from({ length: 1 + rnd(2) }, (_, k) => {
      const lines = Array.from({ length: 1 + rnd(4) }, () => (['+', ' ', '-'][rnd(3)]) + pool[rnd(pool.length)])
      return [`@@ -${k*10+1},${lines.length} +${k*10+1},${lines.length} @@`, ...lines].join('\n')
    })
    return { file, path: '/p/' + file, diff: hunks.join('\n') }
  })
  const said = saids[rnd(saids.length)]!
  const a = JSON.stringify(A.ruleFixLines({ changes } as any, rules, said).cands, (k, v) => k === 'known' ? undefined : v)
  const b = JSON.stringify(B.ruleFixLines({ changes } as any, rules, said).cands, (k, v) => k === 'known' ? undefined : v)
  n++; if (a !== b) { diff++; if (diff < 3) console.log(JSON.stringify(changes), said, a, b) }
}
console.log('cases', n, 'differ', diff)
