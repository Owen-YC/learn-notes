import * as N from '/tmp/claude-0/-home-user-telescope/afabaf14-925e-529a-90e5-17412af3d310/scratchpad/impl112/b1/rv/newtree/hooks/notes.ts'
const TEAM_MD = ['# 팀','','## 규칙','- 기록은 `console.log`(파이썬은 `print`) 대신 `log.info`로 남긴다',''].join('\n')
const RULES = N.parseTeamFile(TEAM_MD).rules
const mk = (file, added) => ({ file, path: '/p/'+file, tool:'Write', kind:'create', added: added.length, removed:0, diff: ['@@ -0,0 +1,'+added.length+' @@', ...added.map(l=>'+'+l)].join('\n'), isCut:false })
const said='기록은 `log.info`로 남기라는 규칙과 달리 `console.log`가 남아 있습니다'
const note = { changes: [mk('a.js', ['function g(a, b) {', '  save(a, b) // console.log(a, b)', '}'])] }
const plan = N.ruleFixPlan(note, RULES, said); console.log(JSON.stringify(plan,(k,v)=>k==='known'?undefined:v))
const text = '## 왜 이렇게 바꿨을까\n- 팀 규칙과 다를 수 있음: ' + said
if ('cands' in plan) console.log(JSON.stringify(N.ruleFixReply(text, '- 규칙: 1\n- 줄: 1\n- 예시 답: `save(a, b) // log.info(a, b)`', plan, RULES, said, note.changes)))
